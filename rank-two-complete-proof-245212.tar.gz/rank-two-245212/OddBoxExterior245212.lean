import OddBoxCheck245212

/-! The geometric subdivision and its finite certificate. The coverage
proof uses only integer comparisons, including for ceilings and empty boxes. -/
namespace OMA.OddBox245212

def scan : ℕ → ℕ → ℕ → ℕ → ℕ → ℕ → Bool → Bool
  | 0,_,_,_,_,_,_ => false
  | f+1,m,kl,kh,ml,mh,swap =>
    let top := min mh (min (64*m^2*kh) (32768*m^6))
    if kh < kl ∨ top < ml then true else
    let out := if swap then veto kl kh m m ml top 13 (3*kh)
      else veto kl kh ml top m m 13 (3*kh)
    if out then true else
    if kh*ml ≥ top*kl ∧ kl < kh then
      let mid := Nat.sqrt (kl*kh)
      scan f m kl mid ml top swap && scan f m (mid+1) kh ml top swap
    else
      let mid := Nat.sqrt (ml*top)
      scan f m kl kh ml mid swap && scan f m kl kh (mid+1) top swap

theorem scan_misses {K m M : ℕ} (swap : Bool) (fit : M ≤ 64*m^2*K) (global : M ≤ 32768*m^6)
    (retain : ∀ kl kh ml mh, kl ≤ K → K ≤ kh → ml ≤ M → M ≤ mh →
      (if swap then veto kl kh m m ml mh 13 (3*kh) else veto kl kh ml mh m m 13 (3*kh))=false)
    (fuel kl kh ml mh : ℕ) (lk : kl ≤ K) (hk : K ≤ kh) (lm : ml ≤ M) (hm : M ≤ mh) :
    scan fuel m kl kh ml mh swap=false := by
  induction fuel generalizing kl kh ml mh with
  | zero => rfl
  | succ f ih =>
    let top := min mh (min (64*m^2*kh) (32768*m^6))
    have ht : M ≤ top := le_min hm (le_min (fit.trans (Nat.mul_le_mul_left _ hk)) global)
    change (if kh < kl ∨ top < ml then _ else _) = false
    rw [if_neg (by omega),retain kl kh ml top lk hk lm ht]
    simp only [Bool.false_eq_true,↓reduceIte]
    split
    · let mid := Nat.sqrt (kl*kh)
      change (scan f m kl mid ml top swap && scan f m (mid+1) kh ml top swap)=false
      by_cases h : K ≤ mid
      · simp [ih kl mid ml top lk h lm ht]
      · simp [ih (mid+1) kh ml top (by omega) hk lm ht]
    · let mid := Nat.sqrt (ml*top)
      change (scan f m kl kh ml mid swap && scan f m kl kh (mid+1) top swap)=false
      by_cases h : M ≤ mid
      · simp [ih kl kh ml mid lk hk lm h]
      · simp [ih kl kh (mid+1) top lk hk (by omega) ht]

def exterior (m : ℕ) : Bool :=
  [false,true].all fun swap =>
    let ml := if swap then m+1 else m
    scan 40 m 1251 (512*m^4) ml (32768*m^6) swap &&
      scan 40 m 6 1250 (max 226 ml) (32768*m^6) swap

set_option maxRecDepth 8192 in
set_option maxHeartbeats 16000000 in
theorem table {m : ℕ} (lo : 6 ≤ m) (hi : m ≤ 32) : exterior m=true := by
  interval_cases m <;> decide +kernel

theorem rectangle {m M K : ℕ} (swap : Bool) (hm : 6 ≤ m) (small : m ≤ 32)
    (order : (if swap then m+1 else m) ≤ M) (hk : 6 ≤ K) (kb : K ≤ 512*m^4)
    (mb : M ≤ 64*m^2*K) (mg : M ≤ 32768*m^6)
    (retain : ∀ kl kh ml mh, kl ≤ K → K ≤ kh → ml ≤ M → M ≤ mh →
      (if swap then veto kl kh m m ml mh 13 (3*kh) else veto kl kh ml mh m m 13 (3*kh))=false) :
    K ≤ 1250 ∧ M ≤ 225 := by
  have h := table hm small
  unfold exterior at h
  have member : swap∈[false,true] := by cases swap <;> simp
  have both := List.all_eq_true.mp h swap member
  simp only [Bool.and_eq_true] at both
  obtain ⟨one,two⟩ := both
  have bound : K ≤ 1250 := by
    by_contra! large
    have := scan_misses swap mb mg retain 40 _ _ _ _ (by omega : 1251 ≤ K) kb order mg
    grind
  refine ⟨bound,?_⟩
  by_contra! large
  have := scan_misses swap mb mg retain 40 _ _ _ _ hk bound (max_le (by omega : 226 ≤ M) order) mg
  grind

end OMA.OddBox245212
