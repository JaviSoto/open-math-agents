OEIS A245212: for n>0 with at most two distinct odd prime factors, a(n)=sigma(n) if and only if n is a power of two.

Pin: google-deepmind/formal-conjectures, 9097e2f90e66d2f6244209cb1c07f7120d17ec53.
Extract this archive, then from the pinned Lake environment run:
  lake env python3 /absolute/path/to/rank_two_all_245212.py --workers 4
Use --workers 1 if RAM is limited. The output ends with the axiom audit of OMA.RankTwoAll245212.iff_power. No prebuilt research files are used.
