import PairSweep245212

/-! No A245212 equality with least odd prime 7 and exactly two odd primes. -/
namespace OMA.Least7Pair245212
open Nat Finset ArithmeticFunction OMA.PairSweep245212
open scoped ArithmeticFunction.sigma

set_option maxHeartbeats 50000000 in
private theorem at_0 {q e f : ℕ} (hq : q.Prime) (pq : 7<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^0*7^e*q^f)≠(σ 1 (2^0*7^e*q^f):ℤ) := by
  by_cases big : 8≤q
  · exact OMA.DyadicEuler245212.pair_small (by decide) hq (by decide) pq ep (u:=7) (v:=8)
      (by decide) (by decide) le_rfl big (by decide +kernel)
  interval_cases q <;> norm_num at *

set_option maxHeartbeats 50000000 in
private theorem at_1 {q e f : ℕ} (hq : q.Prime) (pq : 7<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^1*7^e*q^f)≠(σ 1 (2^1*7^e*q^f):ℤ) := by
  by_cases big : 8≤q
  · exact OMA.DyadicEuler245212.pair_small (by decide) hq (by decide) pq ep (u:=7) (v:=8)
      (by decide) (by decide) le_rfl big (by decide +kernel)
  interval_cases q <;> norm_num at *

set_option maxHeartbeats 50000000 in
private theorem at_2 {q e f : ℕ} (hq : q.Prime) (pq : 7<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^2*7^e*q^f)≠(σ 1 (2^2*7^e*q^f):ℤ) := by
  by_cases big : 8≤q
  · exact OMA.DyadicEuler245212.pair_small (by decide) hq (by decide) pq ep (u:=7) (v:=8)
      (by decide) (by decide) le_rfl big (by decide +kernel)
  interval_cases q <;> norm_num at *

set_option maxHeartbeats 50000000 in
private theorem at_3 {q e f : ℕ} (hq : q.Prime) (pq : 7<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^3*7^e*q^f)≠(σ 1 (2^3*7^e*q^f):ℤ) := by
  by_cases big : 10≤q
  · exact OMA.DyadicEuler245212.pair_small (by decide) hq (by decide) pq ep (u:=7) (v:=10)
      (by decide) (by decide) le_rfl big (by decide +kernel)
  interval_cases q <;> norm_num at *

set_option maxHeartbeats 50000000 in
private theorem at_4 {q e f : ℕ} (hq : q.Prime) (pq : 7<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^4*7^e*q^f)≠(σ 1 (2^4*7^e*q^f):ℤ) := by
  by_cases big : 17≤q
  · exact OMA.DyadicEuler245212.pair_small (by decide) hq (by decide) pq ep (u:=7) (v:=17)
      (by decide) (by decide) le_rfl big (by decide +kernel)
  have cases : q=11 ∨ q=13 := by
    interval_cases q <;> norm_num at *
  rcases cases with rfl|rfl
  · apply known_case (B:=6) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=12) (by decide) hq (by decide) pq ep fp <;> decide +kernel

set_option maxHeartbeats 50000000 in
private theorem at_5 {q e f : ℕ} (hq : q.Prime) (pq : 7<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^5*7^e*q^f)≠(σ 1 (2^5*7^e*q^f):ℤ) := by
  by_cases big : 41≤q
  · exact OMA.DyadicEuler245212.pair_small (by decide) hq (by decide) pq ep (u:=7) (v:=41)
      (by decide) (by decide) le_rfl big (by decide +kernel)
  have cases : q=11 ∨ q=13 ∨ q=17 ∨ q=19 ∨ q=23 ∨ q=29 ∨ q=31 ∨ q=37 := by
    interval_cases q <;> norm_num at *
  rcases cases with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · apply known_case (B:=2) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=3) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=5) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=6) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=10) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=19) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=24) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=81) (by decide) hq (by decide) pq ep fp <;> decide +kernel

set_option maxHeartbeats 50000000 in
private theorem at_6 {q e f : ℕ} (hq : q.Prime) (pq : 7<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^6*7^e*q^f)≠(σ 1 (2^6*7^e*q^f):ℤ) := by
  apply free_case (B:=127) (by decide) hq (by decide) pq ep fp <;> decide +kernel

set_option maxHeartbeats 50000000 in
private theorem at_7 {q e f : ℕ} (hq : q.Prime) (pq : 7<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^7*7^e*q^f)≠(σ 1 (2^7*7^e*q^f):ℤ) := by
  apply free_case (B:=6) (by decide) hq (by decide) pq ep fp <;> decide +kernel

set_option maxHeartbeats 50000000 in
private theorem at_8 {q e f : ℕ} (hq : q.Prime) (pq : 7<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^8*7^e*q^f)≠(σ 1 (2^8*7^e*q^f):ℤ) := by
  apply free_case (B:=3) (by decide) hq (by decide) pq ep fp <;> decide +kernel

set_option maxHeartbeats 50000000 in
private theorem at_9 {q e f : ℕ} (hq : q.Prime) (pq : 7<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^9*7^e*q^f)≠(σ 1 (2^9*7^e*q^f):ℤ) := by
  apply free_case (B:=2) (by decide) hq (by decide) pq ep fp <;> decide +kernel

set_option maxHeartbeats 50000000 in
private theorem at_10 {q e f : ℕ} (hq : q.Prime) (pq : 7<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^10*7^e*q^f)≠(σ 1 (2^10*7^e*q^f):ℤ) := by
  apply free_case (B:=1) (by decide) hq (by decide) pq ep fp <;> decide +kernel

set_option maxHeartbeats 50000000 in
private theorem at_11 {q e f : ℕ} (hq : q.Prime) (pq : 7<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^11*7^e*q^f)≠(σ 1 (2^11*7^e*q^f):ℤ) := by
  apply free_case (B:=1) (by decide) hq (by decide) pq ep fp <;> decide +kernel

set_option maxHeartbeats 50000000 in
private theorem at_12 {q e f : ℕ} (hq : q.Prime) (pq : 7<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^12*7^e*q^f)≠(σ 1 (2^12*7^e*q^f):ℤ) := by
  apply free_case (B:=1) (by decide) hq (by decide) pq ep fp <;> decide +kernel

set_option maxHeartbeats 50000000 in
private theorem at_13 {q e f : ℕ} (hq : q.Prime) (pq : 7<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^13*7^e*q^f)≠(σ 1 (2^13*7^e*q^f):ℤ) := by
  apply free_case (B:=1) (by decide) hq (by decide) pq ep fp <;> decide +kernel

theorem no_pair {k q e f : ℕ} (hq : q.Prime) (pq : 7<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^k*7^e*q^f)≠(σ 1 (2^k*7^e*q^f):ℤ) := by
  intro eq
  have oq := hq.odd_of_ne_two (by omega)
  have odd : Odd (7^e*q^f) := ((by decide : Odd 7).pow).mul oq.pow
  have mem : 7∈(7^e*q^f).primeFactors := Nat.mem_primeFactors.mpr
    ⟨by decide,dvd_mul_of_dvd_left (dvd_pow_self 7 ep.ne') _,by have := hq.pos; positivity⟩
  have hi : k<14 := OMA.DyadicLeast245212.exponent_lt_twice_prime odd mem (by simpa [mul_assoc] using eq)
  interval_cases k
  · exact at_0 hq pq ep fp eq
  · exact at_1 hq pq ep fp eq
  · exact at_2 hq pq ep fp eq
  · exact at_3 hq pq ep fp eq
  · exact at_4 hq pq ep fp eq
  · exact at_5 hq pq ep fp eq
  · exact at_6 hq pq ep fp eq
  · exact at_7 hq pq ep fp eq
  · exact at_8 hq pq ep fp eq
  · exact at_9 hq pq ep fp eq
  · exact at_10 hq pq ep fp eq
  · exact at_11 hq pq ep fp eq
  · exact at_12 hq pq ep fp eq
  · exact at_13 hq pq ep fp eq

#print axioms no_pair
end OMA.Least7Pair245212
