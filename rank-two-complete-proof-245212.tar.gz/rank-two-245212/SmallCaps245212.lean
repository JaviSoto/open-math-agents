import SmallLength245212
import OddBoxFixed245212

/-! Finite interval bounds uniform in the smaller odd exponent.
The two orientations keep the base of that exponent separate. -/
namespace OMA.SmallCaps245212
open scoped ArithmeticFunction.sigma

def smallCore (d a p q _K b : ℕ) := 3*(d+1)*b*p^a*q^d
def highCore (d p q K b : ℕ) := 1+2*(d+1)*b*K*p^2*q^d+
    6*(d+1)^2*b*(K+p)*(q^d)^2

/-- The three implications bound the unbounded prime with the same
polynomial at every point in the current interval. -/
def caps (d l t : ℕ) (few reversed : Bool) : Bool :=
  let h:=d+1
  let z:=2^(min l 4096)
  let b:=if few then 2*d+4 else 64*h^2*t
  let s:=5*t
  let (test,p,q):=if reversed then
    (decide (t*b*h*s^d<z),6*b*t*h*s^d,s)
    else (decide (4*t*h*b*s<z ∧ (6*h*t*b*(4*h*t))^h<z),s,6*h*t*b*s^2)
  test && decide ((if few then smallCore d (2*d+3) p q t b else highCore d p q t b)<z)

theorem retain {p q a d k l t : ℕ} (hp : p.Prime) (hq : q.Prime)
    (op : 3≤p) (oq : 3≤q) (pq : p≠q) (hd : 2≤d) (order : d≤a)
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ))
    (lk : l≤k+1) (hk : k+1≤t) :
    caps d l t (decide (a<2*d+4)) (decide (q<p))=false := by
  let h:=d+1
  let K:=k+1
  let z:ℕ:=2^(min l 4096)
  let b:=if a<2*d+4 then 2*d+4 else 64*h^2*t
  let s:=5*t
  have kz : z≤2^K := Nat.pow_le_pow_right (by decide) ((min_le_left _ _).trans lk)
  have ba : a+1≤b := by
    dsimp only [b];split
    · omega
    · exact (OMA.ComplementaryExp245212.exponent hp hq op oq pq (by omega) eqn).trans
        (Nat.mul_le_mul_left _ hk)
  have many : 5≤(a+1)*(d+1) := by nlinarith only [hd,order,Nat.zero_le (a*d)]
  have small := OMA.ComplementaryBase245212.small_prime hp hq op oq pq many eqn
  have flip : OeisA245212.a (2^k*q^d*p^a)=(σ 1 (2^k*q^d*p^a):ℤ) := by rwa [mul_right_comm]
  have denial (P Q : ℕ) (pmax : p≤P) (qmax : q≤Q) :
      ¬ (if a<2*d+4 then smallCore d (2*d+3) P Q t b else highCore d P Q t b)<z := by
    apply not_lt_of_ge
    apply kz.trans
    split
    · rename_i low
      apply (OMA.ComplementaryDyad245212.level hp hq op oq pq (by omega) eqn).trans
      unfold smallCore
      gcongr <;> omega
    · rename_i high
      apply (OMA.SmallLength245212.complement hp hq op oq pq (by omega) (by omega) eqn).trans
      unfold highCore
      gcongr
  by_contra! yes
  have yes' : caps d l t (decide (a<2*d+4)) (decide (q<p))=true := by simpa using yes
  unfold caps at yes'
  by_cases rev : q<p
  · simp only [if_pos rev,Bool.and_eq_true,decide_eq_true_eq] at yes'
    change t*b*h*s^d<z ∧ _ at yes'
    have qs : q ≤ s := by dsimp [s];omega
    have lim : K*(a+1)*h*q^d<2^K := calc
      _ ≤ t*b*h*s^d := by gcongr
      _ < _ := yes'.1
      _ ≤ _ := kz
    have ps : p≤6*b*t*h*s^d := (OMA.ComplementaryDyad245212.near hq hp oq op pq.symm (by omega) flip lim).trans
      (by change 6*(a+1)*K*h*q^d≤_;gcongr)
    exact denial _ _ ps qs yes'.2
  · simp only [if_neg rev,Bool.and_eq_true,decide_eq_true_eq] at yes'
    change (4*t*h*b*s<z ∧ (6*h*t*b*(4*h*t))^h<z) ∧ _ at yes'
    have ps : p ≤ s := by dsimp [s];omega
    have gc : 4*K*h*(a+1)*p<2^K := calc
      _ ≤ 4*t*h*b*s := by gcongr
      _ < _ := yes'.1.1
      _ ≤ _ := kz
    have pc : 4*h*K≤p^a := by
      by_contra! low
      have pow := OMA.ComplementaryDyad245212.power_floor hp hq op oq pq (by omega) eqn
      change 2^K≤(6*h*K*(a+1)*p^a)^h at pow
      have cmp : (6*h*K*(a+1)*p^a)^h≤(6*h*t*b*(4*h*t))^h := by
        gcongr
        exact low.le.trans (Nat.mul_le_mul_left _ hk)
      exact (not_lt_of_ge (kz.trans (pow.trans cmp))) yes'.1.2
    have qs : q≤6*h*t*b*s^2 :=
      (OMA.ComplementaryFar245212.far hp hq op oq pq (by omega) (by omega) eqn gc pc).trans
        (by change 6*h*K*(a+1)*p^2≤_;gcongr)
    exact denial _ _ ps qs yes'.2

def search : ℕ → ℕ → ℕ → ℕ → Bool → Bool → Bool
  | 0,_,_,_,_,_ => false
  | n+1,d,l,t,f,r =>
    if caps d l t f r then true else
    let mid:=(l+t)/2
    search n d l mid f r && search n d (mid+1) t f r

theorem stays {K d : ℕ} {f r : Bool}
    (keep : ∀ l t, l≤K → K≤t → caps d l t f r=false)
    (n l t : ℕ) (lt : l≤K) (ut : K≤t) : search n d l t f r=false := by
  induction n generalizing l t with
  | zero => rfl
  | succ n ih =>
    rw [search,keep l t lt ut];simp only [Bool.false_eq_true,↓reduceIte]
    by_cases lower : K≤(l+t)/2
    · simp [ih l _ lt lower]
    · simp [ih ((l+t)/2+1) t (by omega) ut]

def ceiling (d : ℕ) (few reversed : Bool) :=
  match d,few,reversed with
  | 2,false,false => 230 | 2,false,true => 137 | 2,true,false => 138 | 2,true,true => 280
  | 3,false,false => 354 | 3,false,true => 174 | 3,true,false => 203 | 3,true,true => 497
  | _,false,false => 485 | _,false,true => 212 | _,true,false => 271 | _,true,true => 779

set_option maxRecDepth 4096 in
set_option maxHeartbeats 16000000 in
private theorem checked {d : ℕ} (lo : 2≤d) (hi : d≤4) (f r : Bool) :
    search 32 d (ceiling d f r+1) (512*(d+1)^4) f r=true := by
  interval_cases d <;> cases f <;> cases r <;> decide +kernel

theorem dyadic {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime)
    (op : 3≤p) (oq : 3≤q) (pq : p≠q) (hd : 2≤d) (small : d≤4) (order : d≤a)
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) :
    k+1≤ceiling d (decide (a<2*d+4)) (decide (q<p)) := by
  by_contra! big
  have upper := (OMA.ComplementaryFinish245212.exponents hp hq op oq pq hd eqn).1
  have ok := checked hd small (decide (a<2*d+4)) (decide (q<p))
  have no := stays (fun l t => retain hp hq op oq pq hd order eqn (l:=l) (t:=t))
    32 (ceiling d (decide (a<2*d+4)) (decide (q<p))+1) _ big upper
  grind

end OMA.SmallCaps245212
