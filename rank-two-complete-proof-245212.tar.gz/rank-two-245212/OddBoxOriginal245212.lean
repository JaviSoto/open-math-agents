import OddBoxSound245212
import OddBoxExterior245212
import OddBoxFixed245212
import TwoOddEffectiveOriginal245212

/-! The original OEIS equality implies the two-dimensional enclosure in
the high-exponent sector, for both relative orders of the odd exponents. -/
namespace OMA.OddBox245212
open scoped ArithmeticFunction.sigma

theorem original {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 13≤p)
    (pq : p<q) (ha : 5≤a) (hd : 5≤d)
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) :
    6≤k+1 ∧ k+1≤1250 ∧ max (a+1) (d+1)≤225 := by
  have prime := prime_bound hp hq op pq ha hd eqn
  have leanK : 6≤k+1 := by omega
  have minBound := OMA.TwoOddEffectiveOriginal245212.bound hp hq (by omega) pq (by omega) eqn
  refine ⟨leanK,?_⟩
  have small := OMA.ComplementaryExp245212.exponent hp hq (by omega) (by omega) pq.ne (by omega) eqn
  have flip : OeisA245212.a (2^k*q^d*p^a)=(σ 1 (2^k*q^d*p^a):ℤ) := by rwa [mul_right_comm]
  by_cases h : d≤a
  · have ⟨kb,mg⟩ := OMA.ComplementaryFinish245212.exponents hp hq (by omega) (by omega) pq.ne (by omega) eqn
    rw [max_eq_left (by omega)]
    apply rectangle (m:=d+1) (M:=a+1) false (by omega) (by omega) (by simp;omega) leanK kb small mg
    intro kl kh ml mh lk uk lm hm
    exact veto_false hp hq op pq ha hd eqn lk uk lm hm le_rfl le_rfl op (by omega)
  · have ⟨kb,mg⟩ := OMA.ComplementaryFinish245212.exponents hq hp (by omega) (by omega) pq.ne.symm (by omega) flip
    have ms := OMA.ComplementaryExp245212.exponent hq hp (by omega) (by omega) pq.ne.symm (by omega) flip
    rw [max_eq_right (by omega)]
    apply rectangle (m:=a+1) (M:=d+1) true (by omega) (by omega) (by simp;omega) leanK kb ms mg
    intro kl kh ml mh lk uk lm hm
    exact veto_false hp hq op pq ha hd eqn lk uk le_rfl le_rfl lm hm op (by omega)

end OMA.OddBox245212
