import TwoOddGrowth245212

/-! Uniform large-dyadic-index exclusion from four explicit power
comparisons. The constants are chosen to keep the arithmetic integral. -/
namespace OMA.TwoOddLargeScale245212
open OMA.TwoOddGrowth245212

theorem estimates {K m p : ℕ} (big : 256≤K) (ml : 33 ≤ m) (ms : m≤5*K) (least : K≤3*p) :
    let h:=5*K; let u:=64*m^2*K; let t:=m*u; let R:=p^(m-1); let g:=2^K-1
    let y:=6*t*K*h^2
    4*K*t*h<2^K ∧ 4*u*K≤R ∧
      4*g*((y^2*(K*u+h)+h^2*(K*u+y))*R+(K+h*y))+
      9*K*h^2*y^2*t*R^2 < 4*g*R^2 := by
  let h:=5*K
  let u:=64*m^2*K
  let t:=m*u
  let R:=p^(m-1)
  let g:=2^K-1
  let y:=6*t*K*h^2
  change 4*K*t*h<2^K ∧ 4*u*K≤R ∧
    4*g*((y^2*(K*u+h)+h^2*(K*u+y))*R+(K+h*y))+9*K*h^2*y^2*t*R^2<4*g*R^2
  have kp : 1≤K := by omega
  have pp : 64≤p := by omega
  have r0 : 1≤R := Nat.one_le_pow _ _ (by omega)
  have zk := (at256 big).2.2
  have ub : u≤2^11*K^3 := calc
    _ ≤ 64*(5*K)^2*K := by dsimp [u];gcongr
    _ ≤ _ := by nlinarith only [Nat.zero_le (K^3)]
  have tb : t≤2^13*K^4 := calc
    _ ≤ (5*K)*(1600*K^3) := Nat.mul_le_mul ms
      (by dsimp [u];nlinarith only [Nat.mul_le_mul_right (64*K) (Nat.pow_le_pow_left ms 2)])
    _ ≤ _ := by nlinarith only [Nat.zero_le (K^4)]
  have yb : y≤2^21*K^7 := calc
    _ ≤ 6*(2^13*K^4)*K*(5*K)^2 := by dsimp only [y,h];gcongr
    _ ≤ _ := by nlinarith only [Nat.zero_le (K^7)]
  have high (c e : ℕ) (cc : c<2^65) (ee : e≤21) : c*K^e<2^K :=
    (Nat.mul_lt_mul_of_lt_of_le cc (Nat.pow_le_pow_right kp ee) (Nat.pow_pos kp)).trans_le zk
  have gc : 4*K*t*h<2^K := calc
    _ ≤ 4*K*(2^13*K^4)*(5*K) := by dsimp only [h];gcongr
    _ = 163840*K^6 := by ring
    _ < _ := high _ _ (by decide) (by decide)
  have p5 : K^4≤p^5 := by
    have lo := Nat.pow_le_pow_left least 5
    have w := Nat.mul_le_mul_right (K^4) (show 243≤K by omega)
    rw [mul_pow] at lo
    nlinarith only [lo,w]
  have p32 : K^24*p^2≤R := calc
    _ = (K^4)^6*p^2 := by ring
    _ ≤ (p^5)^6*p^2 := by gcongr
    _ = p^32 := by ring
    _ ≤ _ := Nat.pow_le_pow_right (by omega) (by omega)
  have room : 2^57*K^18≤R := calc
    _ ≤ (K^6*p^2)*K^18 := Nat.mul_le_mul_right _ ((show 2^57≤(256:ℕ)^6*64^2 by decide).trans
      (Nat.mul_le_mul (Nat.pow_le_pow_left big 6) (Nat.pow_le_pow_left pp 2)))
    _ = K^24*p^2 := by ring
    _ ≤ R := p32
  have pack {v c e : ℕ} (vb : v≤c*K^e) (cb : 2*c≤2^57) (eb : e≤18) : 2*v≤R := by
    have ext := Nat.mul_le_mul cb (Nat.pow_le_pow_right kp eb)
    nlinarith only [room,ext,vb]
  have pc : 4*u*K≤R := (show 4*u*K≤2*(4*u*K) by omega).trans
    (pack (c:=8192) (e:=4) (by nlinarith only [Nat.mul_le_mul_right (4*K) ub]) (by decide) (by decide))
  let aa:=y^2*(K*u+h)+h^2*(K*u+y)
  let bb:=K+h*y
  have sum : aa+bb≤2^56*K^18 := by
    have X (n : ℕ) (hn : n≤18) := Nat.pow_le_pow_right kp hn
    have M : aa+bb≤(2^21*K^7)^2*(K*(2^11*K^3)+5*K)+(5*K)^2*(K*(2^11*K^3)+2^21*K^7)+(K+(5*K)*(2^21*K^7)) := by
      dsimp only [aa,bb,h];gcongr
    nlinarith only [M,X 15 (by decide),X 6 (by decide),X 9 (by decide),X 8 (by decide),
      (show K≤K^18 by simpa using X 1 (by decide)),Nat.zero_le (K^18)]
  have ab := pack sum (by decide) (by decide)
  have drift : 9*K*h^2*y^2*t≤g := by
    have drift0 : 9*K*h^2*y^2*t≤9*K*(5*K)^2*(2^21*K^7)^2*(2^13*K^4) := by
      dsimp only [h];gcongr
    have iso : 9*K*(5*K)^2*(2^21*K^7)^2*(2^13*K^4)=8106479329266892800*K^21 := by ring
    rw [iso] at drift0
    have lt:=drift0.trans_lt (high _ _ (by decide) (by decide))
    dsimp [g];omega
  have gp : 0<g := by dsimp [g];have := Nat.one_lt_pow (by omega : K≠0) (by decide : 1<2);omega
  refine ⟨gc,pc,?_⟩
  change 4*g*(aa*R+bb)+(9*K*h^2*y^2*t)*R^2<4*g*R^2
  have margin := Nat.mul_le_mul_left (2*g*R) ab
  have br := Nat.mul_le_mul_left bb r0
  have plus := Nat.mul_le_mul_left (4*g) br
  nlinarith only [margin,plus,Nat.mul_le_mul_right (R^2) drift,Nat.mul_pos gp (pow_pos r0 2)]

end OMA.TwoOddLargeScale245212
