import ComplementaryDyad245212
import ComplementaryNonres245212

/-! A separated integral cofactor pole bounds the dyadic power
polynomially once the prime bases and divisor exponents are bounded. -/
namespace OMA.ComplementaryHeight245212
open ArithmeticFunction OMA.Smooth245212 OMA.ComplementaryPole245212 OMA.ComplementaryLocal245212
open OMA.QuadraticPowerGap245212
open scoped ArithmeticFunction.sigma

private theorem gap {k : ℕ} {P L H p V S R : ℤ} (pp : 0<P) (pv : 0≤V) (ps : 0 ≤ S)
    (p1 : 1≤p) (ph : 0≤H) (sep : L≠0)
    (clear : P*(G k*L-(k+1)*H)=F k*V-G k*(p-1)*S) (level : G k≤P*R) :
    G k≤(k+1)*H+R*((k+1)*V+p*S) := by
  have gp := (dyad k).1
  have fp := (dyad k).2.1
  have fc := mul_le_mul_of_nonneg_right (dyad k).2.2.1 pv
  have ep : (0:ℤ)≤(k+1)*V+p*S := by positivity
  have rr := mul_le_mul_of_nonneg_right level ep
  have common : P*G k≤P*((k+1)*H+R*((k+1)*V+p*S)) := by
    rcases lt_or_gt_of_ne sep with lt | gt
    · nlinarith only [clear,rr,mul_nonneg (mul_nonneg pp.le gp.le) (show 0≤ -L-1 by omega),
        mul_nonneg fp.le pv,mul_nonneg (mul_nonneg pp.le (show (0:ℤ)≤k+1 by positivity)) ph,
        mul_nonneg gp.le ps,mul_nonneg (mul_nonneg gp.le (show (0:ℤ)≤k+1 by positivity)) pv]
    · nlinarith only [clear,rr,fc,mul_nonneg (mul_nonneg pp.le gp.le) (show 0≤L-1 by omega),
        mul_nonneg (mul_nonneg gp.le (show 0≤p-1 by omega)) ps,
        mul_nonneg (mul_nonneg gp.le (show 0≤p by omega)) ps]
  exact (mul_le_mul_iff_right₀ pp).mp common

theorem height {p q a d k B : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 3≤p) (oq : 3≤q) (pq : p≠q)
    (hd : 2≤d) (ha : 2*d+4≤a) (pb : p≤B) (qb : q≤B) (ab : a+1≤B) (kb : k+1≤B)
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) :
    2^(k+1)≤16*(d+1)^2*B^(2*d+3) := by
  let h : ℤ := (d:ℤ)+1
  let b : ℤ := (a:ℤ)+1
  let K : ℤ := (k:ℤ)+1
  let Q : ℤ := (q:ℤ)^d
  let P : ℤ := (p:ℤ)^a
  let U : ℤ := p-1
  let V : ℤ := W (q^d)
  let S : ℤ := σ 1 (q^d)
  let J : ℤ := h*Q
  let H0 := H p b J V
  let A0 := A p b J S
  have op' : (3:ℤ)≤p := by omega
  have oq' : (3:ℤ)≤q := by omega
  have pz : (0:ℤ)≤p := by omega
  have uz : 0≤U := by dsimp [U];omega
  have hh : 3≤h := by dsimp [h];omega
  have bh : 3≤b := by dsimp [b];omega
  have b0 : 0≤b := by omega
  have u : U≤(p:ℤ) := by dsimp [U];omega
  have ppos : 0<P := by dsimp [P];positivity
  have qp : 0<Q := by dsimp [Q];positivity
  have v0 : 0≤V := by dsimp [V];positivity
  have s0 : 0 ≤ S := by dsimp [S];positivity
  have j0 : 0≤J := by dsimp [J];positivity
  have bd := bounds hq oq d
  have jv : J≤V := by dsimp [J,V,h,Q];exact_mod_cast bd.2.2.1
  have vh : 2*V≤3*h*Q := by dsimp [V,h,Q];exact_mod_cast bd.2.1
  have sh : 2*S≤3*Q := by dsimp [S,Q];exact_mod_cast bd.1
  have bu : p≤b*U := by dsimp [U];nlinarith only [bh,op',mul_nonneg (show 0≤b-3 by omega) uz]
  have Hpos : 0≤H0 := by
    change 0≤b*U*(p*V-U*J)-p*V
    have id : b*U*(p*V-U*J)-p*V=(b*U-p)*V+b*U^2*(V-J) := by dsimp [U];ring
    rw [id];exact add_nonneg (mul_nonneg (sub_nonneg.mpr bu) v0)
      (mul_nonneg (mul_nonneg b0 (sq_nonneg _)) (sub_nonneg.mpr jv))
  have Hub : H0≤b*(p:ℤ)^2*V := by
    change b*U*(p*V-U*J)-p*V≤_
    nlinarith only [mul_nonneg (mul_nonneg b0 (sq_nonneg U)) j0,mul_nonneg pz v0,
      mul_le_mul_of_nonneg_right u (mul_nonneg (mul_nonneg b0 pz) v0)]
  have raw := OMA.ComplementaryNonres245212.cleared hp hq op oq pq eqn
  change P*(G k*(A0-k*H0)-K*H0)=G k*C p k V S+K*V at raw
  have clr : P*(G k*(A0-k*H0)-(k+1)*H0)=F k*V-G k*(p-1)*S := by
    dsimp only [K,C] at raw
    have fg : F k=(k:ℤ)*G k+(k+1) := by dsimp [F,G];ring
    rw [fg];linear_combination raw
  have nz : A0-k*H0≠0 := sub_ne_zero.mpr
    (OMA.ComplementaryNonres245212.original hp hq op oq pq hd ha eqn)
  have lev := OMA.ComplementaryDyad245212.level hp hq op oq pq (by omega) eqn
  have zz : z k≤3*h*b*P*Q := by dsimp [z,h,b,P,Q];exact_mod_cast lev
  have lev' : G k≤P*(3*h*b*Q) := by dsimp [G];linarith only [zz]
  have g := gap ppos v0 s0 (by omega) Hpos nz clr lev'
  change G k≤K*H0+(3*h*b*Q)*(K*V+p*S) at g
  have bp' : (p:ℤ)≤B := by omega
  have bb : b≤B := by dsimp [b];omega
  have kb' : K≤B := by dsimp [K];omega
  have bB : (1:ℤ)≤B := by omega
  have qB : Q≤(B:ℤ)^d := by dsimp [Q];exact pow_le_pow_left₀ (by omega) (by omega) _
  have VU : V≤2*h*B^d := by
    nlinarith only [vh,mul_le_mul_of_nonneg_left qB (show 0≤h by omega),
      mul_nonneg (show 0≤h by omega) qp.le]
  have SU : S≤2*(B:ℤ)^d := by nlinarith only [sh,qB,qp.le]
  have HH : K*H0≤2*h*(B:ℤ)^(d+4) := calc
    _ ≤ K*(b*p^2*V) := mul_le_mul_of_nonneg_left Hub (by dsimp [K];positivity)
    _ ≤ (B:ℤ)*(B*B^2*(2*h*B^d)) := by gcongr
    _ = _ := by rw [pow_add];ring
  have RR : 3*h*b*Q≤3*h*(B:ℤ)^(d+1) := calc
    _ ≤ 3*h*(B:ℤ)*B^d := by gcongr
    _ = _ := by rw [pow_succ];ring
  have VV : K*V+p*S≤4*h*(B:ℤ)^(d+1) := calc
    _ ≤ (B:ℤ)*(2*h*B^d)+B*(2*(B:ℤ)^d) := by gcongr
    _ ≤ _ := by
      rw [pow_succ]
      have pos := mul_nonneg (show 0≤h-1 by omega)
        (mul_nonneg (show 0≤(B:ℤ) by omega) (show 0≤(B:ℤ)^d by positivity))
      nlinarith only [pos]
  have R : (3*h*b*Q)*(K*V+p*S)≤(3*h*(B:ℤ)^(d+1))*(4*h*B^(d+1)) :=
    mul_le_mul RR VV (by dsimp [K];positivity) (by positivity)
  have rb : (3*h*(B:ℤ)^(d+1))*(4*h*B^(d+1))=12*h^2*(B:ℤ)^(2*d+2) := by
    rw [show 2*d+2=(d+1)+(d+1) by omega,pow_add];ring
  rw [rb] at R
  have pb₁ := pow_le_pow_right₀ bB (show d+4≤2*d+3 by omega)
  have pb₂ := pow_le_pow_right₀ bB (show 2*d+2≤2*d+3 by omega)
  have pb₀ : (1:ℤ)≤(B:ℤ)^(2*d+3) := one_le_pow₀ bB
  have cap : z k≤16*h^2*(B:ℤ)^(2*d+3) := by
    dsimp only [G] at g
    nlinarith only [g,HH,R,mul_le_mul_of_nonneg_left pb₁ (show 0≤2*h by omega),
      mul_le_mul_of_nonneg_left pb₂ (show 0≤12*h^2 by positivity),pb₀,
      mul_nonneg (show 0≤4*h^2-2*h-1 by nlinarith only [hh,sq_nonneg (h-1)])
        (show 0≤(B:ℤ)^(2*d+3) by positivity)]
  dsimp [z,h] at cap;exact_mod_cast cap

end OMA.ComplementaryHeight245212
