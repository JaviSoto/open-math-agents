import SmallFacts245212
import SmallExponent245212
import RankTwoReplay245212

/-! Exhaust the allowed residues of the variable exponent. For either
prime order only the smaller prime is enumerated. -/
namespace OMA.SmallReplay245212
open OMA.Large245212 OMA.RankTwoReplay245212 OMA.SmallCaps245212
open scoped ArithmeticFunction.sigma

def first (d : ℕ) (few : Bool) := if few then d else 2*d+4
def stride (d : ℕ) := if d=2 then 2 else 4
def offset (d : ℕ) := if d=2 then 1 else if d=3 then 2 else 0

private theorem index_fits {d a b H : ℕ} (lo : 2≤d) (hi : d≤4) (ba : b≤a) (aH : a≤H)
    (par : (d=2 → a%2=1) ∧ (d=3 → a%4=2) ∧ (d=4 → a%4=0)) :
    (b+stride d-1-offset d)/stride d≤a/stride d ∧
    a/stride d≤(H-offset d)/stride d ∧ stride d*(a/stride d)+offset d=a := by
  rcases (show d=2 ∨ d=3 ∨ d=4 by omega) with rfl|rfl|rfl <;> simp [stride,offset] at * <;> omega

def row (d r k : ℕ) (few rev : Bool) : Bool :=
  let K:=k+1
  let low:=first d few
  let baseLen:=(if rev then d else low)+1
  if r<OMA.TwoOddEffectiveTable245212.floorPrime K baseLen ||
      decide (13≤r ∧ 36≤(low+1)*(d+1) ∧ 9*K≤4*(r-1)) then true else
  let high:=if few then 2*d+3 else 1+Nat.log r (OMA.SmallExponent245212.cap d K r rev)
  let start:=(low+stride d-1-offset d)/stride d
  let hi:=(high-offset d)/stride d
  let w:=wt 2 k
  let s:=sig 2 k
  let t:=OMA.Large245212.tax 2 k
  let fixedA:=w*wt r d
  let fixedS:=s*sig r d
  let fixedT:=t*OMA.Large245212.tax r d
  (List.range' start (hi+1-start)).all fun j =>
    let a:=stride d*j+offset d
    if rev then excluded r a fixedA fixedS fixedT else
      excluded r d (w*wt r a) (s*sig r a) (t*OMA.Large245212.tax r a)

def stripe (d : ℕ) (few rev : Bool) (lo hi : ℕ) :=
  (List.range' lo (hi+1-lo)).all fun r =>
  !decide r.Prime || (List.range' ((r+4)/5-1) (ceiling d few rev+1-(r+4)/5)).all
    (fun k => row d r k few rev)

theorem use_stripe {p q a d k lo hi : ℕ} (hp : p.Prime) (hq : q.Prime)
    (op : 3 ≤ p) (oq : 3 ≤ q) (pq : p≠q) (hd : 2≤d) (ed : d≤4) (order : d≤a)
    (lower : lo ≤ min p q) (upper : min p q≤hi)
    (ok : stripe d (decide (a<2*d+4)) (decide (q<p)) lo hi=true)
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) : False := by
  let r:=min p q
  let f:=decide (a<2*d+4)
  let v:=decide (q<p)
  let b:=first d f
  let low:=(if v then d else b)+1
  have r3 : 3≤r := le_min op oq
  have pr : r.Prime := by rcases le_total p q with l|l <;> simp_all [r]
  have ba : b≤a := by by_cases c : a<2*d+4 <;> simp [b,first,f,c] <;> omega
  have small := OMA.ComplementaryBase245212.small_prime hp hq op oq pq (by nlinarith only [hd,order,Nat.zero_le (a*d)] : 5≤(a+1)*(d+1)) eqn
  have dy := OMA.SmallCaps245212.dyadic hp hq op oq pq hd ed order eqn
  have par := OMA.SmallFacts245212.parity hp hq op oq pq eqn
  have flip : OeisA245212.a (2^k*q^d*p^a)=(σ 1 (2^k*q^d*p^a):ℤ) := by rwa [mul_right_comm]
  have cut : OMA.TwoOddEffectiveTable245212.floorPrime (k+1) low≤r := by
    dsimp [low,v,r]
    split
    · rename_i rev
      have smaller : q<p := by simpa using rev
      rw [min_eq_right smaller.le]
      exact OMA.TwoOddParameters245212.floor hq hp oq op pq.symm (by omega) (by omega) le_rfl flip
    · rename_i rev
      have smaller : p≤q := by simpa using rev
      rw [min_eq_left smaller]
      exact OMA.TwoOddParameters245212.floor hp hq op oq pq (by omega) (by omega) (by omega) eqn
  have wide : ¬(13≤r ∧ 36≤(b+1)*(d+1) ∧ 9*(k+1)≤4*(r-1)) := by
    rintro ⟨room,size,bad⟩
    have h:=OMA.SmallFacts245212.either hp hq pq room (size.trans (Nat.mul_le_mul_right _ (by omega))) eqn
    omega
  have rpass := List.all_eq_true.mp ok r (List.mem_range'_1.mpr ⟨lower,by omega⟩)
  simp only [pr,decide_true,Bool.not_true,Bool.false_or] at rpass
  have rowpass := List.all_eq_true.mp rpass k (List.mem_range'_1.mpr ⟨by dsimp [r] at *;omega,by dsimp [r] at *;omega⟩)
  change row d r k f v=true at rowpass
  unfold row at rowpass
  have rn : ¬r<OMA.TwoOddEffectiveTable245212.floorPrime (k+1) low := not_lt_of_ge cut
  change (if (decide (r<OMA.TwoOddEffectiveTable245212.floorPrime (k+1) low) || decide (13≤r ∧ 36≤(b+1)*(d+1) ∧ 9*(k+1)≤4*(r-1))) then _ else _)=true at rowpass
  simp only [rn,wide,decide_false,Bool.false_or,Bool.false_eq_true,↓reduceIte] at rowpass
  let H:=if f then 2*d+3 else 1+Nat.log r (OMA.SmallExponent245212.cap d (k+1) r v)
  let j:=a/stride d
  have aH : a≤H := by
    by_cases few : a<2*d+4
    · simp [H,f,few];omega
    · simp only [H,f,few,decide_false,Bool.false_eq_true,↓reduceIte]
      have pw:=OMA.SmallExponent245212.power hp hq op oq pq hd order eqn
      have e:=Nat.le_log_of_pow_le (by omega : 1<r) pw
      change a-1≤Nat.log r (OMA.SmallExponent245212.cap d (k+1) r v) at e
      omega
  have idx : (b+stride d-1-offset d)/stride d≤j ∧ j≤(H-offset d)/stride d ∧ stride d*j+offset d=a := by
    exact index_fits hd ed ba aH par
  have point:=List.all_eq_true.mp rowpass j (List.mem_range'_1.mpr ⟨idx.1,by dsimp [H,b] at *;omega⟩)
  simp only [idx.2.2] at point
  by_cases rev : q<p
  · have qv : v=true := by simp [v,rev]
    have rq : r=q := min_eq_right rev.le
    simp only [qv,↓reduceIte,rq] at point
    exact leaf hq (by omega) hp rev (by omega) point flip
  · have qv : v=false := by simp [v,rev]
    have rp : r=p := min_eq_left (by omega)
    simp only [qv,Bool.false_eq_true,↓reduceIte,rp] at point
    exact leaf hp (by omega) hq (by omega) (by omega) point eqn

end OMA.SmallReplay245212
