import ComplementaryLocal245212
import QuadraticPowerGap245212

/-! The ordinary A245212 equality separates the integer dyadic parameter
from its complementary-cofactor pole for every exponent d≥2. -/
namespace OMA.ComplementaryNonres245212
open ArithmeticFunction OMA.Smooth245212 OMA.QuadraticPowerGap245212 OMA.ComplementaryLocal245212
open scoped ArithmeticFunction.sigma

theorem cleared {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 3≤p) (oq : 3≤q) (pq : p≠q)
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) :
    let J := ((d:ℤ)+1)*q^d
    let V : ℤ := W (q^d)
    let S : ℤ := σ 1 (q^d)
    (p:ℤ)^a*(((2:ℤ)^(k+1)-1)*(A p (a+1) J S-(k:ℤ)*H p (a+1) J V)-
      (k+1)*H p (a+1) J V)=((2:ℤ)^(k+1)-1)*C p k V S+(k+1)*V := by
  dsimp only
  have weight := OMA.PrimePowerDiv245212.weighted hp a
  zify [Nat.cast_sub hp.pos] at weight
  apply clear p (a+1) k (2^(k+1)) (p^a) (W (p^a)) (σ 1 (p^a))
    (((d:ℤ)+1)*q^d) (W (q^d)) (σ 1 (q^d))
    (by linear_combination weight) (moments hp a).1
  linear_combination physical hp hq (by omega) (by omega) pq a d k eqn

private theorem moments_sep {q d : ℕ} (hq : q.Prime) (oq : 3≤q) (hd : 1≤d) :
    (d:ℤ)*q^d ≤ (W (q^d):ℤ)-(σ 1 (q^d):ℤ) ∧
    2*q*((W (q^d):ℤ)-((d:ℤ)+1)*q^d) ≤ 3*d*(q:ℤ)^d := by
  obtain ⟨e,rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : d≠0)
  have ends := last hq oq e
  have rest := (bounds hq oq e).2.2.2
  rw [ends.1,ends.2.1]
  have b : 2*(W (q^e):ℤ)≤3*((e:ℤ)+1)*q^e := by exact_mod_cast ends.2.2
  have l : (σ 1 (q^e):ℤ)≤W (q^e) := by exact_mod_cast rest
  push_cast
  rw [pow_succ]
  constructor
  · linarith only [l]
  · nlinarith only [mul_le_mul_of_nonneg_right b (by positivity : (0:ℤ)≤q)]

private theorem ordered {p q d Q V S : ℤ} (hs : 0 ≤ S) (hQ : 0<Q) (hd : 2≤d)
    (lower : d*Q≤V-S) (error : 0≤V-(d+1)*Q) (up : 2*q*(V-(d+1)*Q)≤3*d*Q)
    (su : 2*S≤3*Q) (strict : (d+1)*Q*(V-S)<p*S*(V-(d+1)*Q)) : q<p := by
  by_contra! pq
  have h1 := mul_le_mul_of_nonneg_right pq (mul_nonneg hs error)
  have h2 := mul_le_mul_of_nonneg_left lower (mul_nonneg (by omega : 0≤d+1) hQ.le)
  have h3 := mul_le_mul_of_nonneg_left up (show 0≤2*S by positivity)
  have h4 := mul_le_mul_of_nonneg_right su (show 0≤3*d*Q by positivity)
  have pos := mul_pos (by omega : 0<4*d-5) (mul_pos (by omega : 0<d) (sq_pos_of_pos hQ))
  nlinarith only [strict,h1,h2,h3,h4,pos]

/-- With a sufficiently high cofactor exponent, an actual equality cannot
annul the limiting integer obtained by replacing gamma with k. -/
theorem original {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 3≤p) (oq : 3≤q)
    (pq : p≠q) (hd : 2≤d) (ha : 2*d+4≤a)
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) :
    A p (a+1) (((d:ℤ)+1)*q^d) (σ 1 (q^d)) ≠ (k:ℤ)*H p (a+1) (((d:ℤ)+1)*q^d) (W (q^d)) := by
  intro hit
  have clr := cleared hp hq op oq pq eqn
  have bd := bounds hq oq d
  have ps : 0<σ 1 (q^d) := by
    rw [sigma_one_apply_prime_pow hq]
    exact Finset.sum_pos (fun i _ => pow_pos hq.pos i) (by simp)
  obtain ⟨hk,dv,sep,ub⟩ := resonance (J:=(d+1)*q^d) (b:=a+1) hp op (by omega)
    ps bd.2.2.2 bd.2.2.1 (by exact_mod_cast hit) (by exact_mod_cast clr)
  push_cast at sep
  have loc := moments_sep hq oq (by omega : 1≤d)
  have vj : ((d:ℤ)+1)*q^d≤W (q^d) := by exact_mod_cast bd.2.2.1
  have su : 2*(σ 1 (q^d):ℤ)≤3*(q:ℤ)^d := by exact_mod_cast bd.1
  have qq : (0:ℤ)<q := by omega
  have ordering : q<p := by
    exact_mod_cast ordered (by positivity) (pow_pos qq d) (show (2:ℤ)≤d by omega)
      loc.1 (sub_nonneg.mpr vj) loc.2 su sep
  have pp : (4:ℕ)≤p := by omega
  have notq : ¬p∣q^d := fun eq => Nat.not_dvd_of_pos_of_lt hq.pos ordering (hp.dvd_of_dvd_pow eq)
  have exp : k+1≤2*(a-d-2) := by
    by_cases hsmall : p≤2*d+4
    · omega
    · have nj : ¬p∣(d+1)*q^d := by
        intro bad
        exact ((hp.dvd_mul.mp bad).elim (Nat.not_dvd_of_pos_of_lt (by omega) (by omega)) notq)
      have bp := Nat.le_of_dvd (by omega : 0<a+1) ((hp.dvd_mul.mp dv).resolve_right nj)
      omega
  have zz : 2^(k+1)≤p^(a-d-2) := calc
    _ ≤ 2^(2*(a-d-2)) := Nat.pow_le_pow_right (by decide) exp
    _ = 4^(a-d-2) := by rw [pow_mul];norm_num
    _ ≤ _ := Nat.pow_le_pow_left pp _
  have fact := Nat.mul_le_mul_right (p^(d+2)) zz
  rw [←pow_add,show a-d-2+(d+2)=a by omega] at fact
  have smax : (σ 1 (q^d):ℤ)≤(p:ℤ)^d*p := by
    have qp := pow_le_pow_left₀ qq.le (show (q:ℤ)≤p by omega) d
    nlinarith only [su,qp,mul_nonneg (show (0:ℤ)≤p-2 by omega) (show (0:ℤ)≤p^d by positivity)]
  have cap : ((p:ℤ)-1)*(σ 1 (q^d):ℤ)≤(p:ℤ)^(d+2) := by
    rw [pow_succ,pow_succ]
    nlinarith only [mul_le_mul_of_nonneg_left smax (by omega : (0:ℤ)≤p-1),
      mul_nonneg (by positivity : (0:ℤ)≤p^d) (by positivity : (0:ℤ)≤p)]
  have ff : (2:ℤ)^(k+1)*p^(d+2)≤(p:ℤ)^a := by exact_mod_cast fact
  nlinarith only [ff,ub,mul_le_mul_of_nonneg_left cap (by positivity : (0:ℤ)≤2^(k+1))]

end OMA.ComplementaryNonres245212
