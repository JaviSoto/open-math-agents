import SmallLinearClosed245212
import SmallSecondBlocks245212
import SmallThirdBlocks245212
import SmallFourthBlocks245212

/-! The complete small-exponent sector of the two-odd-prime divisor equation. -/
namespace OMA.SmallOriginal245212
open scoped ArithmeticFunction.sigma

private theorem ordered {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime)
    (op : 3≤p) (oq : 3≤q) (pq : p≠q) (hd : 1≤d) (small : d≤4) (order : d≤a) :
    OeisA245212.a (2^k*p^a*q^d)≠(σ 1 (2^k*p^a*q^d):ℤ) := by
  interval_cases d
  · simpa using OMA.SmallLinear245212.closed (a:=a) (k:=k) hp hq op oq pq
  · exact OMA.SmallSecondBlocks245212.closed hp hq op oq pq order
  · exact OMA.SmallThirdBlocks245212.closed hp hq op oq pq order
  · exact OMA.SmallFourthBlocks245212.closed hp hq op oq pq order

theorem closed {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime)
    (op : 3≤p) (oq : 3≤q) (pq : p≠q) (ha : 1≤a) (hd : 1≤d) (small : min a d≤4) :
    OeisA245212.a (2^k*p^a*q^d)≠(σ 1 (2^k*p^a*q^d):ℤ) := by
  rcases le_total d a with da|ad
  · exact ordered hp hq op oq pq hd (by omega) da
  · rw [mul_right_comm (2^k)]
    exact ordered hq hp oq op pq.symm ha (by omega) ad

#print axioms closed
end OMA.SmallOriginal245212
