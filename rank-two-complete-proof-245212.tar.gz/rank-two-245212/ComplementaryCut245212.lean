import ComplementaryBox245212
import ComplementaryHeight245212

/-! Polynomial/exponential cutoff in the dyadic exponent. -/
namespace OMA.ComplementaryCut245212
open scoped ArithmeticFunction.sigma

private theorem scalar {h K : ℕ} (hh : 3≤h)
    (growth : 2^K≤2^(16*h^2*(2*h+2))*K^((h+1)*(2*h+1))) :
    K≤512*h^4 := by
  let T:=16*h^2*(2*h+2)
  let s:=(h+1)*(2*h+1)
  let t:=K.sqrt
  change 2^K≤2^T*K^s at growth
  by_contra! wide
  have hs : s≤4*h^2 := by
    dsimp [s];nlinarith only [hh,Nat.mul_le_mul_left h hh]
  have tbound : 2*T≤512*h^4 := by
    dsimp [T]
    have h34:=Nat.pow_le_pow_right (show 1≤h by omega) (show 3≤4 by decide)
    have h24:=Nat.pow_le_pow_right (show 1≤h by omega) (show 2≤4 by decide)
    nlinarith only [h34,h24,Nat.zero_le (h^4)]
  have ss : 4*s≤t := Nat.le_sqrt'.mpr (calc
    (4*s)^2 ≤ (4*(4*h^2))^2 := Nat.pow_le_pow_left (Nat.mul_le_mul_left _ hs) _
    _ ≤ 512*h^4 := by nlinarith only [Nat.zero_le (h^4)]
    _ ≤ K := wide.le)
  have tt : t^2≤K := Nat.sqrt_le' K
  have tt' : K<(t+1)^2 := Nat.lt_succ_sqrt' K
  have two : 2≤t := by dsimp [s] at ss;nlinarith only [ss,hh,Nat.zero_le (h^2)]
  have pk : K≤2^(2*t) := calc
    _ ≤ 2*t^2+1 := by nlinarith only [tt',Nat.mul_le_mul_left t two]
    _ ≤ _ := Nat.two_mul_sq_add_one_le_two_pow_two_mul t
  have powers := growth.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left pk s))
  rw [←pow_mul,←pow_add] at powers
  have rem := (pow_le_pow_iff_right₀ (a:=(2:ℕ)) (by decide)).mp powers
  nlinarith only [rem,tt,Nat.mul_le_mul_left t ss,wide,tbound]

theorem large {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 3≤p) (oq : 3≤q) (pq : p≠q)
    (hd : 2≤d) (ha : 2*d+4≤a)
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) :
    k+1≤512*(d+1)^4 := by
  let h:=d+1
  let K:=k+1
  let E:ℕ:=2^(16*h^2)
  let B:=E*K^(d+2)
  let D:=E*K^(d+3)
  let s:=(h+1)*(2*h+1)
  let T:=16*h^2*(2*h+2)
  have hK : 1≤K := by dsimp [K];omega
  have hh : 3≤h := by dsimp [h];omega
  have he : 1≤E := Nat.one_le_pow _ _ (by decide)
  apply scalar hh
  change 2^K≤2^T*K^s
  by_cases small : 2^K≤D^h
  · have comp : E^h≤2^T := by
      dsimp [E,T];rw [←pow_mul]
      apply Nat.pow_le_pow_right (by decide)
      exact Nat.mul_le_mul_left _ (by omega)
    have kcomp : K^((d+3)*h)≤K^s := Nat.pow_le_pow_right hK (by
      dsimp [s,h];nlinarith only [Nat.zero_le d,Nat.zero_le (d^2)])
    change 2^K≤(E*K^(d+3))^h at small
    rw [mul_pow,←pow_mul K (d+3) h] at small
    exact small.trans (Nat.mul_le_mul comp kcomp)
  · obtain ⟨pb,qb,ab,kb⟩:=OMA.ComplementaryBox245212.box hp hq op oq pq (by omega) hd eqn (lt_of_not_ge small)
    have bound := OMA.ComplementaryHeight245212.height hp hq op oq pq hd ha pb qb ab kb eqn
    change 2^K≤16*h^2*B^(2*d+3) at bound
    have initial : 16*h^2≤E := (Nat.lt_pow_self (by decide : 1<2)).le
    have eqE : E*E^(2*d+3)=2^T := by
      rw [←pow_succ'];dsimp [E,T,h];rw [←pow_mul];congr 2
    have eqK : (K^(d+2))^(2*d+3)=K^s := by dsimp [s,h];rw [←pow_mul];congr 1
    dsimp only [B] at bound
    rw [mul_pow,eqK,←mul_assoc] at bound
    exact bound.trans (Nat.mul_le_mul_right _ ((Nat.mul_le_mul_right _ initial).trans_eq eqE))

end OMA.ComplementaryCut245212
