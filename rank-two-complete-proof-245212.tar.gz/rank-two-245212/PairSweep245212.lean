import PairExtension245212
import DyadicEuler245212
import DyadicLeast245212

/-! Finite kernel checks for fixed-dyadic two-prime exclusions, including
the unbounded-prime case. Only one exponent is enumerated at fixed bases. -/
namespace OMA.PairSweep245212
open Nat Finset ArithmeticFunction OMA.Smooth245212 OMA.Large245212 OMA.PairExtension245212
open scoped ArithmeticFunction.sigma
open private OMA.Large245212.moments from LargeExact245212
open private OMA.FixedExponents245212.y_pos from FixedExponents245212

def run (test : ℕ → ℕ → ℕ → Bool) (k p e : ℕ) :=
  test (wt 2 k*wt p e) (sig 2 k*sig p e) (OMA.Large245212.tax 2 k*OMA.Large245212.tax p e)

private theorem run_true {k p e : ℕ} (hp : p.Prime) (po : 2<p) (test : ℕ → ℕ → ℕ → Bool)
    (ok : run test k p e=true) :
    test (W (2^k*p^e)) (σ 1 (2^k*p^e)) ((2^k*p^e)*(σ 0 (2^k*p^e)))=true := by
  have cp := (((Nat.coprime_primes prime_two hp).mpr (by omega)).pow_left k).pow_right e
  rw [w_mult.map_mul_of_coprime cp,isMultiplicative_sigma.map_mul_of_coprime cp,
    isMultiplicative_sigma.map_mul_of_coprime cp,sigma_zero_apply_prime_pow prime_two,
    sigma_zero_apply_prime_pow hp]
  have two := OMA.Large245212.moments prime_two k
  have odd := OMA.Large245212.moments hp e
  simpa [run,two.1,two.2,odd.1,odd.2,OMA.Large245212.tax,mul_comm,mul_assoc,mul_left_comm] using ok

private theorem cop {k p q e : ℕ} (hp : p.Prime) (hq : q.Prime) (oq : 2<q) (diff : p≠q) :
    (2^k*p^e).Coprime q := (((Nat.coprime_primes prime_two hq).mpr (by omega)).pow_left k).mul_left
      (((Nat.coprime_primes hp hq).mpr diff).pow_left e)

private theorem test_free {k p q e f : ℕ} (hp : p.Prime) (hq : q.Prime) (po : 2<p) (pq : p<q)
    (fp : 0<f) (ok : run (free (p+1)) k p e=true) :
    OeisA245212.a (2^k*p^e*q^f)≠(σ 1 (2^k*p^e*q^f):ℤ) :=
  free_sound (by have := hp.pos; positivity) hq (by omega) (cop hp hq (by omega) pq.ne) fp pq
    (run_true hp po _ ok)

private theorem test_known {k p q e f : ℕ} (hp : p.Prime) (hq : q.Prime) (po : 2<p)
    (qo : 2<q) (diff : p≠q) (fp : 0<f) (ok : run (fun a s t => known a s t q) k p e=true) :
    OeisA245212.a (2^k*p^e*q^f)≠(σ 1 (2^k*p^e*q^f):ℤ) :=
  known_sound (by have := hp.pos; positivity) hq (by omega) (cop hp hq qo diff) fp
    (run_true hp po _ ok)

private theorem x_mono {p : ℕ} (hp : 1<p) {e f : ℕ} (ef : e≤f) : X p (some e)≤X p (some f) := by
  have pp : (1:ℚ)<p := by exact_mod_cast hp
  unfold X; gcongr; exact y_anti hp ef

private theorem strict {k p q e f : ℕ} (hp : p.Prime) (hq : q.Prime) (po : 2<p) (pq : p<q)
    (eq : OeisA245212.a (2^k*p^e*q^f)=(σ 1 (2^k*p^e*q^f):ℤ)) :
    X 2 (some k)*(X p (some e)*X q (some f))<2 := by
  have := OMA.DyadicEuler245212.pair_norm k p q e f hp hq po pq eq
  exact lt_of_lt_of_eq (lt_add_of_pos_right _ (mul_pos (OMA.FixedExponents245212.y_pos prime_two k)
    (mul_pos (OMA.FixedExponents245212.y_pos hp e) (OMA.FixedExponents245212.y_pos hq f)))) this

def many (test : ℕ → ℕ → ℕ → Bool) (k p B : ℕ) :=
  (List.range B).all fun i => run test k p (i+1)

private theorem each {test : ℕ → ℕ → ℕ → Bool} {k p B e : ℕ}
    (all : many test k p B=true) (ep : 0<e) (eb : e≤B) : run test k p e=true := by
  obtain ⟨i,rfl⟩ := Nat.exists_eq_succ_of_ne_zero ep.ne'
  exact List.all_eq_true.mp all i (List.mem_range.mpr (by omega))

/-- Above B the smaller prime's weighted factor already crosses 2/c.
Below B recover the unknown last prime, once per possible last exponent. -/
theorem free_case {k p q e f B : ℕ} (hp : p.Prime) (hq : q.Prime) (po : 2<p) (pq : p<q)
    (ep : 0<e) (fp : 0<f) (high : 2≤X 2 (some k)*X p (some (B+1)))
    (check : many (free (p+1)) k p B=true) :
    OeisA245212.a (2^k*p^e*q^f)≠(σ 1 (2^k*p^e*q^f):ℤ) := by
  by_cases eb : e≤B
  · exact test_free hp hq po pq fp (each check ep eb)
  intro eq
  have q1 : 1≤X q (some f) := le_add_of_nonneg_right (div_nonneg (sub_nonneg.mpr (y_one hq.one_lt _))
    (sub_nonneg.mpr (by exact_mod_cast hq.one_le)))
  have step := mul_le_mul (x_mono hp.one_lt (by omega : B+1≤e)) q1 (by norm_num) (x_nonneg hp.one_lt _)
  rw [mul_one] at step
  exact ((high.trans (mul_le_mul_of_nonneg_left step (x_nonneg (by decide) _))).not_gt
    (strict hp hq po pq eq))

/-- Both bases are fixed. At least one exponent must be small; from it
the signed reverse-digit identity determines the other exponent. -/
theorem known_case {k p q e f B : ℕ} (hp : p.Prime) (hq : q.Prime) (po : 2<p) (pq : p<q)
    (ep : 0<e) (fp : 0<f)
    (high : 2≤X 2 (some k)*(X p (some (B+1))*X q (some (B+1))))
    (left : many (fun a s t => known a s t q) k p B=true)
    (right : many (fun a s t => known a s t p) k q B=true) :
    OeisA245212.a (2^k*p^e*q^f)≠(σ 1 (2^k*p^e*q^f):ℤ) := by
  by_cases eb : e≤B
  · exact test_known hp hq po (by omega) pq.ne fp (each left ep eb)
  by_cases fb : f≤B
  · simpa only [mul_right_comm (2^k)] using
      test_known hq hp (po.trans pq) po pq.ne' ep (each right fp fb)
  intro eq
  have steps := mul_le_mul (x_mono hp.one_lt (by omega : B+1≤e)) (x_mono hq.one_lt (by omega : B+1≤f))
    (x_nonneg hq.one_lt _) (x_nonneg hp.one_lt _)
  exact (high.trans (mul_le_mul_of_nonneg_left steps (x_nonneg (by decide) _))).not_gt (strict hp hq po pq eq)

end OMA.PairSweep245212
