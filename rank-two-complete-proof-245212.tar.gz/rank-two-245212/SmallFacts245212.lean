import SmallCaps245212
import OddBoxPrime245212
import ExponentParity245212
import DyadicPower245212

/-! Exact admissibility restrictions at the lower prime and the variable odd exponent. -/
namespace OMA.SmallFacts245212
open ArithmeticFunction OMA.Smooth245212 OMA.ComplementaryLocal245212 OMA.ComplementaryPole245212
open private OMA.OddBox245212.ratio from OddBoxPrime245212
open scoped ArithmeticFunction.sigma

private theorem ordered {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 13≤p)
    (pq : p<q) (bc : 36≤(a+1)*(d+1))
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) :
    4*(p-1)<9*(k+1) := by
  let P : ℤ := (p:ℤ)^a
  let Q : ℤ := (q:ℤ)^d
  let D : ℤ := (a+1)*P
  let E : ℤ := (d+1)*Q
  let W : ℤ := OMA.Smooth245212.W (p^a)
  let V : ℤ := OMA.Smooth245212.W (q^d)
  let S : ℤ := σ 1 (p^a)
  let T : ℤ := σ 1 (q^d)
  let u : ℤ := (p:ℤ)-1
  let v : ℤ := (q:ℤ)-1
  have up : 12≤u := by dsimp [u];omega
  have uv : u≤v := by dsimp [u,v];omega
  have pw := OMA.PrimePowerDiv245212.weighted hp a
  have qw := OMA.PrimePowerDiv245212.weighted hq d
  zify [Nat.cast_sub hp.pos] at pw
  zify [Nat.cast_sub hq.pos] at qw
  change u*W+S=(p:ℤ)*D at pw
  change v*V+T=(q:ℤ)*E at qw
  have wl : D≤W := by dsimp [D,P,W];exact_mod_cast (bounds hp (by omega) a).2.2.1
  have vl : E≤V := by dsimp [E,Q,V];exact_mod_cast (bounds hq (by omega) d).2.2.1
  have ss : 2*S≤3*P := by dsimp [S,P];exact_mod_cast (bounds hp (by omega) a).1
  have tt : 2*T≤3*Q := by dsimp [T,Q];exact_mod_cast (bounds hq (by omega) d).1
  have s0 : 0 ≤ S := by dsimp [S];positivity
  have t0 : 0≤T := by dsimp [T];positivity
  have p0 : 0<P := by dsimp [P];positivity
  have q0 : 0<Q := pow_pos (by omega : (0:ℤ)<q) _
  have vu : u*V≤(u+1)*E := by
    have scale := mul_le_mul_of_nonneg_right uv (sub_nonneg.mpr vl)
    dsimp only [v] at qw scale
    nlinarith only [scale,qw,t0]
  have st := mul_le_mul ss tt (by positivity : 0≤2*T) (by positivity : 0≤3*P)
  have bc : (36:ℤ) ≤ ((a:ℤ)+1)*(d+1) := by exact_mod_cast bc
  have sm : 16*S*T≤D*E := by dsimp only [D,E];nlinarith only [st,mul_le_mul_of_nonneg_right bc (mul_nonneg p0.le q0.le)]
  have eq := physical hp hq (by omega) (by omega) pq.ne a d k eqn
  change F k*W*V+G k*S*T=z k*(k+1)*(a+1)*(d+1)*P*Q at eq
  rw [←(dyad k).2.2.2] at eq
  have r := OMA.OddBox245212.ratio up (dyad k).1 (dyad k).2.1 (dyad k).2.2.1
    (by dsimp [D];positivity : 0<D) (by dsimp [E];positivity : 0<E) wl vl
    (by dsimp [u] at pw ⊢;nlinarith only [pw,s0]) vu sm (by dsimp [D,E];linear_combination eq)
  dsimp only [u] at r;zify [Nat.cast_sub hp.pos];exact r


theorem either {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime) (pq : p≠q)
    (op : 13 ≤ min p q) (bc : 36≤(a+1)*(d+1))
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) :
    4*(min p q-1)<9*(k+1) := by
  rcases lt_or_gt_of_ne pq with h|h
  · rw [min_eq_left h.le];exact ordered hp hq (op.trans (min_le_left ..)) h bc eqn
  · rw [min_eq_right h.le]
    exact ordered hq hp (op.trans (min_le_right ..)) h (by rwa [Nat.mul_comm])
      (by rwa [mul_right_comm])

private theorem square_factors {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime)
    (op : 3≤p) (oq : 3≤q) (pq : p≠q) (ea : Even a) (ed : Even d)
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) : 4∣a := by
  obtain ⟨e,rfl⟩:=ea
  obtain ⟨s,rfl⟩:=ed
  let u:=p^e*q^s
  have ue : p^(e+e)*q^(s+s)=u^2 := by dsimp [u];rw [mul_pow,←pow_mul,←pow_mul];congr 2 <;> omega
  have ou := ((hp.odd_of_ne_two (by omega)).pow (n:=e)).mul ((hq.odd_of_ne_two (by omega)).pow (n:=s))
  rw [mul_assoc,ue] at eqn
  obtain ⟨v,hv⟩:=OMA.DyadicPower245212.square_root_is_square ou eqn
  have notq : ¬p∣q^s := fun div => pq ((Nat.prime_dvd_prime_iff_eq hp hq).mp (hp.dvd_of_dvd_pow div))
  have exactp : u.factorization p=e := by
    unfold u
    rw [Nat.factorization_mul (pow_ne_zero _ hp.ne_zero) (pow_ne_zero _ hq.ne_zero),
      Finsupp.add_apply,Nat.factorization_pow_self hp,Nat.factorization_eq_zero_of_not_dvd notq,add_zero]
  change u = v*v at hv
  rw [hv,←pow_two,Nat.factorization_pow] at exactp
  simp only [Finsupp.smul_apply,smul_eq_mul] at exactp
  omega

theorem parity {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime)
    (op : 3≤p) (oq : 3≤q) (pq : p≠q)
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) :
    (d=2 → a%2=1) ∧ (d=3 → a%4=2) ∧ (d=4 → a%4=0) := by
  let primes : Fin 2 → ℕ := ![p,q]
  let exps : Fin 2 → ℕ := ![a,d]
  have pr : ∀ i, (primes i).Prime := by intro i;fin_cases i <;> assumption
  have odd : ∀ i, Odd (primes i) := fun i => (pr i).odd_of_ne_two (by fin_cases i <;> dsimp [primes] <;> omega)
  have inj : Function.Injective primes := by
    intro i j h;fin_cases i <;> fin_cases j <;> simp_all [primes]
  have total : OMA.Smooth245212.total primes exps=p^a*q^d := by
    simp [OMA.Smooth245212.total,Fin.prod_univ_two,primes,exps]
  have eq := OMA.ExponentParity245212.exponent_product primes exps pr odd inj k (by
    rw [total,←mul_assoc];exact eqn)
  simp [Fin.prod_univ_two,exps] at eq
  have flip : OeisA245212.a (2^k*q^d*p^a)=(σ 1 (2^k*q^d*p^a):ℤ) := by rwa [mul_right_comm]
  refine ⟨fun v => ?_,fun v => ?_,fun v => ?_⟩ <;> subst d
  · by_contra! bad
    have ea : Even a := Nat.even_iff.mpr (by omega)
    have := square_factors hq hp oq op pq.symm (by decide : Even 2) ea flip
    omega
  · change 4 ∣ (a+2)*(3+2) at eq
    omega
  · change 4 ∣ (a+2)*(4+2) at eq
    have even : Even a := Nat.even_iff.mpr (by omega)
    exact Nat.dvd_iff_mod_eq_zero.mp (square_factors hp hq op oq pq even (by decide) eqn)

end OMA.SmallFacts245212
