import FormalConjectures.OEIS.«245212»

/-! The dyadic box checker uses signed integers in units of a sixteenth
of a binary logarithm. The real interpretation is used only in its proof. -/
namespace OMA.OddBox245212

noncomputable def logSize (x : ℝ) := 16*Real.logb 2 x
def down (n : ℕ) : ℤ := Nat.log 2 (n^16)
def up (n : ℕ) : ℤ := Nat.clog 2 (n^16)
def roundedQuot (n : ℤ) (d : ℕ) := -((-n)/(d:ℤ))

theorem mono {x y : ℝ} (hx : 0<x) (xy : x≤y) : logSize x≤logSize y :=
  mul_le_mul_of_nonneg_left (Real.logb_le_logb_of_le (by norm_num) hx xy) (by norm_num)

theorem reflect {x y : ℝ} (hx : 0<x) (hy : 0<y) : logSize x≤logSize y ↔ x≤y := by
  unfold logSize; rw [mul_le_mul_iff_right₀ (by norm_num : (0:ℝ)<16)]
  exact Real.logb_le_logb (by norm_num) hx hy

theorem enclosed (n : ℕ) (pos : 0<n) : (down n:ℝ)≤logSize n ∧ logSize n≤up n := by
  have x : 0≤Real.logb 2 ((n:ℝ)^16) :=
    Real.logb_nonneg (by norm_num) (one_le_pow₀ (by exact_mod_cast pos : (1:ℝ)≤n))
  have fid := Nat.floor_le x
  have cid := Nat.le_ceil (Real.logb 2 ((n:ℝ)^16))
  have fn := Real.natFloor_logb_natCast 2 (n^16)
  have cn := Real.natCeil_logb_natCast 2 (n^16)
  norm_num only [Nat.cast_ofNat,Nat.cast_pow] at fn cn
  rw [fn] at fid
  rw [cn] at cid
  dsimp [down,up,logSize]
  push_cast at fid cid ⊢
  rw [Real.logb_pow] at fid cid
  norm_num at fid cid
  exact ⟨fid,cid⟩

theorem mul {x y : ℝ} (hx : 0<x) (hy : 0<y) : logSize (x*y)=logSize x+logSize y := by
  simp only [logSize,Real.logb_mul hx.ne' hy.ne',mul_add]
theorem pow (x : ℝ) (n : ℕ) : logSize (x^n)=n*logSize x := by
  simp only [logSize,Real.logb_pow];ring
theorem div {x y : ℝ} (hx : 0<x) (hy : 0<y) : logSize (x/y)=logSize x-logSize y := by
  simp only [logSize,Real.logb_div hx.ne' hy.ne',mul_sub]
@[simp] theorem two : logSize 2=16 := by norm_num [logSize,Real.logb_self_eq_one]
@[simp] theorem one : logSize 1=0 := by simp [logSize]
theorem nat_nonneg (n : ℕ) (hn : 0<n) : 0≤logSize n := by
  simpa using mono (by norm_num : (0:ℝ)<1) (show (1:ℝ)≤n by exact_mod_cast hn)
theorem over_bound {x : ℝ} {a : ℤ} {d : ℕ} (hd : 0<d) (h : (d:ℝ)*x≤a) : x≤roundedQuot a d := by
  have pos : (0:ℤ)<d := by exact_mod_cast hd
  have cut := Int.ediv_mul_le (-a) pos.ne'
  have z : a≤d*roundedQuot a d := by dsimp [roundedQuot];nlinarith only [cut]
  have lift : (a:ℝ)≤(d:ℝ)*(roundedQuot a d:ℝ) := by exact_mod_cast z
  exact (mul_le_mul_iff_right₀ (show (0:ℝ)<d by exact_mod_cast hd)).mp (h.trans lift)

theorem max_sum {x y : ℝ} (hx : 0<x) (hy : 0<y) :
    logSize (x+y)≤16+max (logSize x) (logSize y) := by
  rcases le_total x y with h|h
  · rw [max_eq_right (mono hx h),←two,←mul (by norm_num) hy]
    exact mono (by positivity) (by linarith)
  · rw [max_eq_left (mono hy h),←two,←mul (by norm_num) hx]
    exact mono (by positivity) (by linarith)

end OMA.OddBox245212
