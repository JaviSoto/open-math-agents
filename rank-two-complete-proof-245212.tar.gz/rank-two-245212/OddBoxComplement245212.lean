import ComplementaryHeight245212

/-! Preserve the two actual bases in the integer complementary-pole estimate. -/
namespace OMA.OddBox245212
open ArithmeticFunction OMA.Smooth245212 OMA.ComplementaryPole245212 OMA.ComplementaryLocal245212
open OMA.QuadraticPowerGap245212
open scoped ArithmeticFunction.sigma
open private OMA.ComplementaryHeight245212.gap from ComplementaryHeight245212

theorem complement {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 3≤p) (oq : 3≤q) (pq : p≠q)
    (hd : 2≤d) (ha : 2*d+4≤a)
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) :
    2^(k+1)≤1+2*(d+1)*(a+1)*(k+1)*p^2*q^d+
      6*(d+1)^2*(a+1)*(k+1+p)*(q^d)^2 := by
  let h : ℤ := (d:ℤ)+1
  let b : ℤ := (a:ℤ)+1
  let K : ℤ := (k:ℤ)+1
  let Q : ℤ := (q:ℤ)^d
  let P : ℤ := (p:ℤ)^a
  let U : ℤ := p-1
  let V : ℤ := W (q^d)
  let S : ℤ := σ 1 (q^d)
  let J : ℤ := h*Q
  let H0 := H p b J V
  let A0 := A p b J S
  have op' : (3:ℤ)≤p := by omega
  have oq' : (3:ℤ)≤q := by omega
  have pz : (0:ℤ)≤p := by omega
  have uz : 0≤U := by dsimp [U];omega
  have hh : 3≤h := by dsimp [h];omega
  have bh : 3≤b := by dsimp [b];omega
  have b0 : 0≤b := by omega
  have u : U≤(p:ℤ) := by dsimp [U];omega
  have ppos : 0<P := by dsimp [P];positivity
  have qp : 0<Q := by dsimp [Q];positivity
  have v0 : 0≤V := by dsimp [V];positivity
  have s0 : 0 ≤ S := by dsimp [S];positivity
  have j0 : 0≤J := by dsimp [J];positivity
  have bd := bounds hq oq d
  have jv : J≤V := by dsimp [J,V,h,Q];exact_mod_cast bd.2.2.1
  have vh : 2*V≤3*h*Q := by dsimp [V,h,Q];exact_mod_cast bd.2.1
  have sh : 2*S≤3*Q := by dsimp [S,Q];exact_mod_cast bd.1
  have bu : p≤b*U := by dsimp [U];nlinarith only [bh,op',mul_nonneg (show 0≤b-3 by omega) uz]
  have Hpos : 0≤H0 := by
    change 0≤b*U*(p*V-U*J)-p*V
    have id : b*U*(p*V-U*J)-p*V=(b*U-p)*V+b*U^2*(V-J) := by dsimp [U];ring
    rw [id];exact add_nonneg (mul_nonneg (sub_nonneg.mpr bu) v0)
      (mul_nonneg (mul_nonneg b0 (sq_nonneg _)) (sub_nonneg.mpr jv))
  have Hub : H0≤b*(p:ℤ)^2*V := by
    change b*U*(p*V-U*J)-p*V≤_
    nlinarith only [mul_nonneg (mul_nonneg b0 (sq_nonneg U)) j0,mul_nonneg pz v0,
      mul_le_mul_of_nonneg_right u (mul_nonneg (mul_nonneg b0 pz) v0)]
  have raw := OMA.ComplementaryNonres245212.cleared hp hq op oq pq eqn
  change P*(G k*(A0-k*H0)-K*H0)=G k*C p k V S+K*V at raw
  have clr : P*(G k*(A0-k*H0)-(k+1)*H0)=F k*V-G k*(p-1)*S := by
    dsimp only [K,C] at raw
    have fg : F k=(k:ℤ)*G k+(k+1) := by dsimp [F,G];ring
    rw [fg];linear_combination raw
  have nz : A0-k*H0≠0 := sub_ne_zero.mpr
    (OMA.ComplementaryNonres245212.original hp hq op oq pq hd ha eqn)
  have lev := OMA.ComplementaryDyad245212.level hp hq op oq pq (by omega) eqn
  have zz : z k≤3*h*b*P*Q := by dsimp [z,h,b,P,Q];exact_mod_cast lev
  have lev' : G k≤P*(3*h*b*Q) := by dsimp [G];linarith only [zz]
  have g := OMA.ComplementaryHeight245212.gap ppos v0 s0 (by omega) Hpos nz clr lev'
  change G k≤K*H0+(3*h*b*Q)*(K*V+p*S) at g
  have vr : V≤2*h*Q := by nlinarith only [vh,mul_nonneg (by omega : 0≤h) qp.le]
  have sr : S≤2*h*Q := by nlinarith only [sh,mul_nonneg (show 0≤h-1 by omega) qp.le,qp.le]
  have Hcap := Hub.trans (mul_le_mul_of_nonneg_left vr (mul_nonneg b0 (sq_nonneg _)))
  have Fcap := mul_le_mul_of_nonneg_left Hcap (by dsimp [K];positivity : 0≤K)
  have Ecap : K*V+p*S≤2*h*(K+p)*Q := by
    nlinarith only [mul_le_mul_of_nonneg_left vr (by dsimp [K];positivity : 0≤K),mul_le_mul_of_nonneg_left sr pz]
  have Rcap := mul_le_mul_of_nonneg_left Ecap (show 0≤3*h*b*Q by positivity)
  have result : z k≤1+2*h*b*K*p^2*Q+6*h^2*b*(K+p)*Q^2 := by
    dsimp only [G] at g
    nlinarith only [g,Rcap,Fcap]
  dsimp only [z,h,b,K,Q] at result
  exact_mod_cast result

end OMA.OddBox245212
