import RankTwoInteriorWalk245212

/-! Arithmetic checkpoints carry literal interval endpoints. Adjacent
checkpoints compose by one checked bisection, so the kernel need not
reconstruct a large ancestry while reducing an expensive leaf. -/
namespace OMA.RankTwoInteriorCover245212
open OMA.RankTwoInteriorBox245212 OMA.RankTwoInteriorWalk245212
open private OMA.RankTwoInteriorWalk245212.split_covers from RankTwoInteriorWalk245212

deriving instance DecidableEq for OMA.RankTwoInteriorBox245212.Cell

structure World where
  k : ℕ
  B : ℕ
  C : ℕ
  p : ℕ
  floor : ∀ j, 0<j → j≤B → 1+k*(j-1)/j≤p
  upper : p≤3*(k+1)
  noEasy : ∀ t, Fits t (k+1) B C p → Good t → easy t=false
  noExact : ∀ t, Fits t (k+1) B C p → exact t=false

def Closed (t : Cell) := ∀ w : World, Fits t (w.k+1) w.B w.C w.p → Good t → False

theorem tile (t : Cell) (ok : check 40 t=true) : Closed t := by
  intro w ft gt
  have h := walk_false w.floor w.upper w.noEasy w.noExact 40 t ft gt
  simp [ok] at h

/-- A replay certificate records which inexpensive obstruction worked. The
kernel need not evaluate the unsuccessful tests earlier in the search. -/
inductive Reason where
  | empty | pole | exterior | arithmetic
  deriving Repr

def certificate (r : Reason) (t : Cell) : Bool :=
  match r with
  | .empty => decide (t.ph<t.pl)
  | .pole => OMA.RankTwoInteriorBox245212.veto t
  | .exterior => OMA.OddBox245212.veto t.kl t.kh t.bl t.bh t.cl t.ch t.pl t.ph
  | .arithmetic => exact t

theorem certify {r : Reason} (raw t : Cell) (same : trim raw=t)
    (ok : certificate r t=true) : Closed raw := by
  intro w ft gt
  obtain ⟨f,g⟩ := trim_fits ft gt w.floor w.upper
  rw [same] at f g
  have e := w.noEasy t f g
  have a := w.noExact t f
  cases r <;> simp_all [certificate,easy]
  exact (Nat.not_lt_of_ge e.1.1) ok

theorem join (t : Cell) {l r : Cell} (left : Closed l) (right : Closed r)
    (ident : halves (trim t)=(l,r)) : Closed t := by
  intro w ft gt
  obtain ⟨f,g⟩ := trim_fits ft gt w.floor w.upper
  have sub := OMA.RankTwoInteriorWalk245212.split_covers f g
  rw [ident] at sub
  exact sub.elim (fun h => left w h.1 h.2) (fun h => right w h.1 h.2)

/-- A small proof tree of the successful arithmetic tests only. -/
inductive Script where
  | leaf : Reason → Script
  | fork : Script → Script → Script

def verify : Script → Cell → Bool
  | .leaf r, t => certificate r (trim t)
  | .fork l r, t =>
    let (a,b) := halves (trim t)
    verify l a && verify r b

theorem of_script (s : Script) (t : Cell) (ok : verify s t=true) : Closed t := by
  induction s generalizing t with
  | leaf r => exact certify t _ rfl ok
  | fork l r il ir =>
    simp only [verify,Bool.and_eq_true] at ok
    exact join t (il _ ok.1) (ir _ ok.2) rfl

#print axioms tile
#print axioms join
end OMA.RankTwoInteriorCover245212
