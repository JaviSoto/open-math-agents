import ComplementaryPole245212

/-! Explicit integer lower bounds on both rounded defects of the
two-prime divisor balance; terms retain the separate powers P and Q. -/
namespace OMA.SimultaneousBound245212
open OMA.TwoOddGlobalGap245212 OMA.ComplementaryPole245212 OMA.ComplementaryLocal245212
open OMA.Smooth245212 ArithmeticFunction
open scoped ArithmeticFunction.sigma

def error (p q K B C P Q : ℕ) :=
  q^2*(K*C+p)*Q+p^2*(K*B+q)*P+K+p*q

private theorem alpha_bound {f g p q C K : ℤ} (hp : 2≤p) (hq : 2≤q) (hc : 1≤C)
    (fg : f≤K*g) (f0 : 0≤f) (g0 : 0≤g) (k0 : 0≤K) :
    |alpha f g p q C|≤g*q^2*(K*C+p) := by
  have vp : 0≤q-1 := by omega
  have up : 0≤p-1 := by omega
  have pos : 0≤C*(q-1)-1 := by
    nlinarith only [mul_nonneg (show 0≤C-1 by omega) vp,hq]
  have top : C*(q-1)-1≤C*q := by nlinarith only [hc]
  have down : (p-1)*(q-1)≤p*q := by nlinarith only [hp,hq]
  have fterm := mul_le_mul fg top pos (mul_nonneg k0 g0)
  have gterm := mul_le_mul_of_nonneg_left down g0
  dsimp [alpha]
  apply abs_le.mpr
  constructor
  · nlinarith only [mul_le_mul_of_nonneg_left gterm (show 0≤q by omega),
      mul_nonneg (mul_nonneg (show 0≤q by omega) f0) pos,
      mul_nonneg (mul_nonneg g0 (sq_nonneg q)) (mul_nonneg k0 (show 0≤C by omega))]
  · nlinarith only [mul_le_mul_of_nonneg_left fterm (show 0≤q by omega),
      mul_nonneg (mul_nonneg (mul_nonneg g0 up) vp) (show 0≤q by omega),
      mul_nonneg (mul_nonneg g0 (sq_nonneg q)) (show 0≤p by omega)]

private theorem abs_terms {f g p q B C P Q K : ℤ} (hp : 2≤p) (hq : 2≤q) (hb : 1≤B)
    (hc : 1≤C) (fg : f≤K*g) (f0 : 0≤f) (g0 : 0≤g) (k0 : 0≤K) (p0 : 0≤P) (q0 : 0≤Q) :
    |alpha f g p q C*Q+beta f g p q B*P+f+g*(p-1)*(q-1)| ≤
    g*(q^2*(K*C+p)*Q+p^2*(K*B+q)*P+K+p*q) := by
  have ab := alpha_bound hp hq hc fg f0 g0 k0
  have ba := alpha_bound hq hp hb fg f0 g0 k0
  have sym : alpha f g q p B=beta f g p q B := by dsimp [alpha,beta];ring
  rw [sym] at ba
  have uv : g*(p-1)*(q-1)≤g*(p*q) := by
    have h : (p-1)*(q-1)≤p*q := by nlinarith only [hp,hq]
    nlinarith only [mul_le_mul_of_nonneg_left h g0]
  have s : 0≤g*(p-1)*(q-1) := mul_nonneg (mul_nonneg g0 (by omega)) (by omega)
  calc
    _ ≤ (|alpha f g p q C*Q|+|beta f g p q B*P|)+|f|+|g*(p-1)*(q-1)| := by
      have t1 := abs_add_le (alpha f g p q C*Q) (beta f g p q B*P)
      have t2 := abs_add_le (alpha f g p q C*Q+beta f g p q B*P) f
      have t3 := abs_add_le (alpha f g p q C*Q+beta f g p q B*P+f) (g*(p-1)*(q-1))
      linarith only [t1,t2,t3]
    _ ≤ _ := by
      rw [abs_mul,abs_of_nonneg q0,abs_mul,abs_of_nonneg p0,abs_of_nonneg f0,abs_of_nonneg s]
      nlinarith only [mul_le_mul_of_nonneg_right ab q0,mul_le_mul_of_nonneg_right ba p0,fg,uv]

theorem of_separations {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 3≤p) (oq : 3≤q)
    (pq : p≠q) (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ))
    (s1 : defect k 1 p q (a+1) (d+1) ≠ 0)
    (s2 : defect (F k) (G k) p q (a+1) (d+1) ≠ 0) :
    let K:=k+1; let B:=a+1; let C:=d+1; let gn:=2^K-1; let P:=p^a; let Q:=q^d
    P*Q ≤ gn*error p q K B C P Q ∧
    4*gn*P*Q ≤ 4*gn*error p q K B C P Q + 9*K*p^2*q^2*B*C*P*Q := by
  let K:ℤ:=k+1
  let B:ℤ:=a+1
  let C:ℤ:=d+1
  let W : ℤ:=OMA.Smooth245212.W (p^a)
  let V : ℤ:=OMA.Smooth245212.W (q^d)
  let S : ℤ:=σ 1 (p^a)
  let T : ℤ:=σ 1 (q^d)
  let P : ℤ:=(p:ℤ)^a
  let Q : ℤ:=(q:ℤ)^d
  let err := (q:ℤ)^2*(K*C+p)*Q+(p:ℤ)^2*(K*B+q)*P+K+p*q
  let terms (f g : ℤ) := alpha f g p q C*Q+beta f g p q B*P+f+g*(p-1)*(q-1)
  have gp := (dyad k).1
  have fp := (dyad k).2.1
  have zz := (dyad k).2.2.2
  have op' : (3:ℤ)≤p := by omega
  have oq' : (3:ℤ)≤q := by omega
  have pp : 0<P := by dsimp [P];positivity
  have qq : 0<Q := by dsimp [Q];positivity
  have phys := physical hp hq (by omega) (by omega) pq a d k eqn
  change F k*W*V+G k*S*T=z k*(k+1)*B*C*P*Q at phys
  rw [←zz] at phys
  have bound (f g : ℤ) (fg : f≤K*g) (f0 : 0≤f) (g0 : 0≤g) : |terms f g|≤g*err :=
    abs_terms (by omega) (by omega) (by dsimp [B];omega) (by dsimp [C];omega)
      fg f0 g0 (by dsimp [K];omega) pp.le qq.le
  have iden (f g : ℤ) :
      (p-1:ℤ)^2*(q-1:ℤ)^2*(f*W*V+g*S*T-(f+g)*B*C*P*Q) =
      -defect f g p q B C*P*Q+terms f g := by
    simpa only [terms,add_assoc] using expansion f g p q B C P Q W V S T
      (moments hp a).2 (moments hq d).2 (moments hp a).1 (moments hq d).1
  have l := iden (F k) (G k)
  rw [phys,sub_self,mul_zero] at l
  have l' : defect (F k) (G k) p q B C*P*Q=terms (F k) (G k) := by linarith only [l]
  have mag (e : ℤ) (ne : e≠0) : P*Q≤|e*P*Q| := by
    rw [abs_mul,abs_mul,abs_of_pos pp,abs_of_pos qq]
    nlinarith only [mul_nonneg (show 0≤|e|-1 by have := abs_pos.mpr ne;omega) (mul_pos pp qq).le]
  have lhs := mag _ s2
  change P*Q≤|defect (F k) (G k) p q B C*P*Q| at lhs
  rw [l'] at lhs
  have lfinal := lhs.trans (bound _ _ (dyad k).2.2.1 fp.le gp.le)
  have km := iden k 1
  let U : ℤ := (p-1:ℤ)^2*(q-1:ℤ)^2
  have fg : F k=(k:ℤ)*G k+K := by dsimp [K,F,G,z]; ring
  have rel : G k*((k:ℤ)*W*V+S*T-(k+1)*B*C*P*Q) = -K*(W*V-B*C*P*Q) := by
    rw [fg] at phys; dsimp [K] at phys ⊢;linear_combination phys
  have k' : G k*(defect k 1 p q B C*P*Q)=G k*terms k 1+K*U*(W*V-B*C*P*Q) := by
    simp only [one_mul] at km
    dsimp only [U]
    linear_combination (G k)*km - ((p:ℤ)-1)^2*((q:ℤ)-1)^2*rel
  have bp := bounds hp op a
  have bq := bounds hq oq d
  have wmin : B*P≤W := by dsimp [B,P,W];exact_mod_cast bp.2.2.1
  have vmin : C*Q≤V := by dsimp [C,Q,V];exact_mod_cast bq.2.2.1
  have wmax : 2*W≤3*B*P := by dsimp [B,P,W];exact_mod_cast bp.2.1
  have vmax : 2*V≤3*C*Q := by dsimp [C,Q,V];exact_mod_cast bq.2.1
  have w0 : 0≤W := by dsimp [W];positivity
  have v0 : 0≤V := by dsimp [V];positivity
  have bpos : 0<B := by dsimp [B];positivity
  have cpos : 0<C := by dsimp [C];positivity
  have rmin : 0≤W*V-B*C*P*Q := by
    nlinarith only [mul_le_mul wmin vmin (mul_pos cpos qq).le w0]
  have rmax : 4*(W*V-B*C*P*Q)≤9*B*C*P*Q := by
    have lim := mul_le_mul wmax vmax (show 0≤2*V by positivity) (show 0≤3*B*P by positivity)
    nlinarith only [lim,mul_nonneg (mul_nonneg (mul_nonneg bpos.le cpos.le) pp.le) qq.le]
  have u0 : 0≤U := by dsimp [U];positivity
  have uc : U≤(p:ℤ)^2*q^2 := mul_le_mul
    (show ((p:ℤ)-1)^2≤(p:ℤ)^2 by nlinarith only [op'])
    (show ((q:ℤ)-1)^2≤(q:ℤ)^2 by nlinarith only [oq']) (sq_nonneg _) (sq_nonneg _)
  have kp : 0<K := by dsimp [K];positivity
  have product := mul_le_mul uc rmax (mul_nonneg (show (0:ℤ)≤4 by decide) rmin)
    (mul_nonneg (sq_nonneg _) (sq_nonneg _))
  have dmag := mul_le_mul_of_nonneg_left (mag _ s1) gp.le
  change G k*(P*Q)≤G k*|defect k 1 p q B C*P*Q| at dmag
  rw [←abs_of_pos gp,←abs_mul,k',abs_of_pos gp] at dmag
  have triangle := abs_add_le (G k*terms k 1) (K*U*(W*V-B*C*P*Q))
  have target := dmag.trans triangle
  rw [abs_mul,abs_of_pos gp,abs_of_nonneg (mul_nonneg (mul_nonneg kp.le u0) rmin)] at target
  have tb := bound k 1 (by dsimp [K];omega) (by positivity) (by decide)
  have final : 4*G k*P*Q≤4*G k*err+9*K*(p:ℤ)^2*q^2*B*C*P*Q := by
    nlinarith only [target,mul_le_mul_of_nonneg_left tb gp.le,mul_le_mul_of_nonneg_left product kp.le]
  have gcast : ((2^(k+1)-1:ℕ):ℤ)=G k := by
    dsimp [G,z];push_cast [Nat.cast_sub (Nat.one_le_pow _ _ (by decide : 0<2))];rfl
  dsimp only [error]
  constructor
  · zify;rw [gcast];exact lfinal
  · zify;rw [gcast];exact final

theorem original {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 3≤p)
    (pq : p<q) (ha : 1≤a) (hd : 15≤d) (hk : 2≤k) (small : p≤5*(k+1))
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) :
    let K:=k+1; let B:=a+1; let C:=d+1; let gn:=2^K-1; let P:=p^a; let Q:=q^d
    P*Q ≤ gn*error p q K B C P Q ∧
    4*gn*P*Q ≤ 4*gn*error p q K B C P Q + 9*K*p^2*q^2*B*C*P*Q := by
  obtain ⟨a,b⟩ := original_separations hp hq op pq ha hd hk small eqn
  exact of_separations hp hq op (by omega) pq.ne eqn a b

end OMA.SimultaneousBound245212
