import SmallLinearReplay245212

/-! No solution of the A245212 divisor equation with a complementary
first-power odd prime, with no restrictions on the other prime or exponents. -/
namespace OMA.SmallLinear245212
open OMA.SmallLinearReplay245212
open scoped ArithmeticFunction.sigma

set_option maxRecDepth 8192 in
set_option maxHeartbeats 16000000 in
private theorem tables {j : ℕ} (bound : j≤24) :
    stripe (3+32*j) (34+32*j)=true := by
  interval_cases j <;> decide +kernel

theorem closed {p q a k : ℕ} (hp : p.Prime) (hq : q.Prime)
    (op : 3≤p) (oq : 3≤q) (pq : p≠q) :
    OeisA245212.a (2^k*p^a*q)≠(σ 1 (2^k*p^a*q):ℤ) := by
  intro eqn
  have info := box hp hq op oq pq eqn
  let j := (min p q-3)/32
  have r3 : 3 ≤ min p q := le_min op oq
  have rmax : min p q≤795 := by omega
  exact use_stripe hp hq op oq pq (by dsimp [j];omega : 3+32*j ≤ min p q)
    (by dsimp [j];omega : min p q≤34+32*j) (tables (by dsimp [j];omega)) eqn

#print axioms closed
end OMA.SmallLinear245212
