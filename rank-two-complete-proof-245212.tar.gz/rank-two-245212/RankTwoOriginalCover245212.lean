import OddBoxOriginal245212
import RankTwoInteriorCover245212

/-! The two sets of 27 root certificates suffice for the entire
large-exponent two-odd-prime sector of the original divisor equation. -/
namespace OMA.RankTwoOriginalCover245212
open OMA.RankTwoInteriorBox245212 OMA.RankTwoInteriorWalk245212 OMA.RankTwoInteriorCover245212
open scoped ArithmeticFunction.sigma

theorem of_roots
    (closed : ∀ m : ℕ, 6 ≤ m → m ≤ 32 → ∀ swap : Bool, Closed (root m 6 1250 swap))
    {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 13 ≤ p)
    (pq : p<q) (ha : 5≤a) (hd : 5≤d) :
    OeisA245212.a (2^k*p^a*q^d)≠(σ 1 (2^k*p^a*q^d):ℤ) := by
  intro eqn
  obtain ⟨e,rfl⟩:=Nat.exists_eq_succ_of_ne_zero (by omega : d≠0)
  obtain ⟨K0,K1,exp⟩:=OMA.OddBox245212.original hp hq op pq ha hd eqn
  have minb := OMA.TwoOddEffectiveOriginal245212.bound hp hq (by omega) pq (by omega) eqn
  have pbound := OMA.OddBox245212.prime_bound hp hq op pq ha hd eqn
  have upper : p≤3*(k+1) := by omega
  obtain ⟨i,pi⟩ := hp.odd_of_ne_two (by omega)
  obtain ⟨j,qj⟩ := hq.odd_of_ne_two (by omega)
  have gap : p+2≤q := by omega
  have generic (s : Cell) (fit : Fits s (k+1) (a+1) (e+2) p)
      (balance : OeisA245212.a (2^k*p^a*q^(e+1))=(σ 1 (2^k*p^a*q^(e+1)):ℤ)) :
      OMA.OddBox245212.veto s.kl s.kh s.bl s.bh s.cl s.ch s.pl s.ph=false := by
    obtain ⟨lK,hK,lB,hB,lC,hC,lp,rp⟩:=fit
    exact OMA.OddBox245212.veto_false hp hq op pq ha hd balance lK hK lB hB lC hC lp rp
  obtain ⟨floor,easy,exactS⟩:=solution_facts hp hq op gap (by omega) ha (by omega) upper generic eqn
  let w : World := ⟨k,a+1,e+2,p,floor,upper,easy,exactS⟩
  have cover (m : ℕ) (dir : Bool) (lo : 6 ≤ m) (hi : m≤32) (fit : Fits (root m 6 1250 dir) (k+1) (a+1) (e+2) p) : False :=
    closed m lo hi dir w fit (by cases dir <;> simp [Good,root] <;> omega)
  by_cases h : e+2≤a+1
  · apply cover (e+2) false (by omega) (by omega)
    simp only [root,Bool.false_eq_true,↓reduceIte,Fits];omega
  · apply cover (a+1) true (by omega) (by omega)
    simp only [root,↓reduceIte,Fits];omega

end OMA.RankTwoOriginalCover245212
