import RankTwoPoleInterior245212
import SimultaneousBound245212

/-! Certified endpoint bounds for interior prime ranges. Each test uses
integer budgets for the three tails of the simultaneous defect. -/
namespace OMA.RankTwoInteriorBox245212
open OMA.RankTwoPoleInterior245212 OMA.ComplementaryPole245212
open ArithmeticFunction OMA.SimultaneousBound245212
open scoped ArithmeticFunction.sigma

theorem no_exact {A B C P Q G : ℕ} (pp : 0<P) (qp : 0<Q)
    (necessary : P*Q≤G*(A*Q+B*P+C)) (a : 3*G*A<P) (b : 3*G*B<Q)
    (c : 3*G*C<P*Q) : False := by
  nlinarith only [necessary,Nat.mul_lt_mul_of_pos_right a qp,Nat.mul_lt_mul_of_pos_right b pp,c]

theorem no_integer {A B C P Q G F : ℕ} (pp : 0<P) (qp : 0<Q) (gp : 0<G)
    (necessary : 4*G*P*Q≤4*G*(A*Q+B*P+C)+F*P*Q)
    (a : 4*A<P) (b : 4*B<Q) (c : 4*C<P*Q) (drift : F<G) : False := by
  have three : 4*(A*Q+B*P+C)<3*P*Q := by
    nlinarith only [Nat.mul_lt_mul_of_pos_right a qp,Nat.mul_lt_mul_of_pos_right b pp,c]
  nlinarith only [necessary,Nat.mul_lt_mul_of_pos_left three gp,
    Nat.mul_lt_mul_of_pos_right drift (Nat.mul_pos pp qp)]

structure Cell where
  kl : ℕ
  kh : ℕ
  bl : ℕ
  bh : ℕ
  cl : ℕ
  ch : ℕ
  pl : ℕ
  ph : ℕ
  deriving Repr

def Fits (t : Cell) (K B C p : ℕ) : Prop :=
  t.kl≤K ∧ K≤t.kh ∧ t.bl≤B ∧ B≤t.bh ∧ t.cl≤C ∧ C≤t.ch ∧ t.pl≤p ∧ p≤t.ph

def gLow (t : Cell) := 2^t.kl-1
def gHigh (t : Cell) := 2^t.kh-1
def pLow (t : Cell) := t.pl^(t.bl-1)
def qLow (t : Cell) := (t.pl+2)^(t.cl-1)
def low (t : Cell) := lowPole ((t.kl:ℤ)-1) ((t.kh:ℤ)-1) t.bl t.bh t.cl t.ch t.pl t.ph
def high (t : Cell) := highPole ((t.kl:ℤ)-1) ((t.kh:ℤ)-1) t.bl t.bh t.cl t.ch t.pl t.ph
def e₁ (t : Cell) := (t.kh*t.ch*t.bh*(t.ph-1)+gLow t-1)/gLow t
def e₂ (t : Cell) := (t.ch*t.kh+pLow t-1)/pLow t
def gap (t : Cell) : ℤ := low t-e₁ t-e₂ t
def numerator (t : Cell) := 3*t.ch*t.bh*t.kh*(t.ph-1)^2
def yCap (t : Cell) := numerator t/(gap t).toNat

/-- The checks on the rounded witnesses make their calculation independent
of the proof of soundness. -/
def witness (t : Cell) : Bool := decide (
  t.kh*t.ch*t.bh*(t.ph-1)≤e₁ t*gLow t ∧ t.ch*t.kh≤e₂ t*pLow t ∧
  0<gap t ∧ numerator t<(yCap t+1)*(gap t).toNat)

def budget (t : Cell) (y : ℕ) : Bool :=
  let x := y^2*(t.kh*t.ch+t.ph)
  let z := t.ph^2*(t.kh*t.bh+y)
  let w := t.kh+t.ph*y
  let P := pLow t
  let Q := qLow t
  let G := gHigh t
  decide (3*G*x<P ∧ 3*G*z<Q ∧ 3*G*w<P*Q) ||
    decide (4*x<P ∧ 4*z<Q ∧ 4*w<P*Q ∧ 9*t.kh*t.ph^2*y^2*t.bh*t.ch<gLow t)

def veto (t : Cell) : Bool :=
  decide (high t≤0) || (witness t && (decide (yCap t<t.pl+2) || budget t (yCap t)))

theorem budget_false {t : Cell} {p q K B C P Q G y : ℕ}
    (fit : Fits t K B C p) (qy : q≤y)
    (pp : 0<P) (qp : 0<Q) (gp : 0<G)
    (rp : pLow t≤P) (rq : qLow t≤Q) (gl : gLow t≤G) (gh : G≤gHigh t)
    (ex : P*Q≤G*error p q K B C P Q)
    (int : 4*G*P*Q≤4*G*error p q K B C P Q+9*K*p^2*q^2*B*C*P*Q) :
    budget t y=false := by
  obtain ⟨_,kh,_,bh,_,ch,_,ph⟩ := fit
  have ae : q^2*(K*C+p)≤y^2*(t.kh*t.ch+t.ph) := by gcongr
  have be : p^2*(K*B+q)≤t.ph^2*(t.kh*t.bh+y) := by gcongr
  have ce : K+p*q≤t.kh+t.ph*y := by gcongr
  have de : 9*K*p^2*q^2*B*C≤9*t.kh*t.ph^2*y^2*t.bh*t.ch := by gcongr
  have prod := Nat.mul_le_mul rp rq
  by_contra! bad
  have ok : budget t y=true := Bool.eq_true_of_not_eq_false bad
  simp only [budget,Bool.or_eq_true,decide_eq_true_eq] at ok
  rcases ok with ⟨a,b,c⟩ | ⟨a,b,c,d⟩
  · apply no_exact pp qp (by simpa [error,add_assoc] using ex)
    · exact (Nat.mul_le_mul (Nat.mul_le_mul_left _ gh) ae).trans_lt (a.trans_le rp)
    · exact (Nat.mul_le_mul (Nat.mul_le_mul_left _ gh) be).trans_lt (b.trans_le rq)
    · exact (Nat.mul_le_mul (Nat.mul_le_mul_left _ gh) ce).trans_lt (c.trans_le prod)
  · apply no_integer pp qp gp (by simpa [error,add_assoc] using int)
    · exact (Nat.mul_le_mul_left _ ae).trans_lt (a.trans_le rp)
    · exact (Nat.mul_le_mul_left _ be).trans_lt (b.trans_le rq)
    · exact (Nat.mul_le_mul_left _ ce).trans_lt (c.trans_le prod)
    · exact de.trans_lt (d.trans_le gl)

#print axioms budget_false

theorem veto_false {t : Cell} {p q a d k : ℕ}
    (hp : p.Prime) (hq : q.Prime) (op : 3≤p) (pq : p+2≤q) (ha : 2≤a)
    (kl : 1≤t.kl) (pl : 1≤t.pl) (fit : Fits t (k+1) (a+1) (d+2) p)
    (small : (p:ℤ)-1≤((d:ℤ)+2)*k)
    (eqn : OeisA245212.a (2^k*p^a*q^(d+1))=(σ 1 (2^k*p^a*q^(d+1)):ℤ))
    (ex : p^a*q^(d+1)≤(2^(k+1)-1)*error p q (k+1) (a+1) (d+2) (p^a) (q^(d+1)))
    (int : 4*(2^(k+1)-1)*p^a*q^(d+1)≤4*(2^(k+1)-1)*error p q (k+1) (a+1) (d+2) (p^a) (q^(d+1))+
      9*(k+1)*p^2*q^2*(a+1)*(d+2)*p^a*q^(d+1)) : veto t=false := by
  obtain ⟨k₀,k₁,b₀,b₁,c₀,c₁,p₀,p₁⟩ := fit
  have qpos := hq.pos
  have ppos := hp.pos
  have rp : pLow t≤p^a := by
    exact (Nat.pow_le_pow_left p₀ _).trans (Nat.pow_le_pow_right hp.pos (by omega))
  have rq : qLow t≤q^(d+1) := by
    exact (Nat.pow_le_pow_left (by omega : t.pl+2≤q) _).trans
      (Nat.pow_le_pow_right hq.pos (by omega))
  have gl : gLow t≤2^(k+1)-1 :=
    Nat.sub_le_sub_right (Nat.pow_le_pow_right (by decide) k₀) 1
  have gh : 2^(k+1)-1≤gHigh t :=
    Nat.sub_le_sub_right (Nat.pow_le_pow_right (by decide) k₁) 1
  have pow2 : 2≤2^(k+1) := by simpa only [pow_one] using
    (Nat.pow_le_pow_right (by decide : 0<2) (by omega : 1≤k+1))
  have pole := point hp hq op (by omega) (by omega) ha small eqn
  dsimp only at pole
  have lim := pole_interval (p:=p) (b:=(a:ℤ)+1) (c:=(d:ℤ)+2) (k:=k)
    (kl:=(t.kl:ℤ)-1) (kh:=(t.kh:ℤ)-1) (bl:=t.bl) (bh:=t.bh) (cl:=t.cl)
    (ch:=t.ch) (pl:=t.pl) (ph:=t.ph)
    (by omega) (Int.natCast_nonneg _) (Int.natCast_nonneg _) (by omega)
    (by omega) (by omega) (by omega) (by omega) (by omega) (by omega) (by omega) (by omega) small
  change low t≤L k p (a+1) (d+2) ∧ L k p (a+1) (d+2)≤high t at lim
  have pos := pole.1.trans_le lim.2
  by_cases test : witness t=true
  · have pieces := test
    simp only [witness,decide_eq_true_eq] at pieces
    obtain ⟨ex₁,ex₂,gapp,cover⟩ := pieces
    have xu : (k+1)*(d+2)*(a+1)*(p-1)≤e₁ t*(2^(k+1)-1) := calc
      _ ≤ t.kh*t.ch*t.bh*(t.ph-1) := by gcongr
      _ ≤ _ := ex₁.trans (Nat.mul_le_mul_left _ gl)
    have yu : (d+2)*(k+1)≤e₂ t*p^a :=
      (Nat.mul_le_mul c₁ k₁).trans (ex₂.trans (Nat.mul_le_mul_left _ rp))
    zify [Nat.cast_sub hp.pos,Nat.cast_sub (by omega : 1≤2^(k+1))] at xu
    have bound := pole.2 (e₁ t) (e₂ t) (by simpa [G,z,mul_assoc] using xu)
      (by exact_mod_cast yu)
    have gp : gap t≤L k p (a+1) (d+2)-(e₁ t+e₂ t) := by
      dsimp [gap];linarith only [lim.1]
    have num : 3*(d+2)*(k+1)*(a+1)*(p-1)^2≤numerator t := by
      unfold numerator
      rw [show 3*t.ch*t.bh*t.kh=3*t.ch*t.kh*t.bh by ring]
      gcongr
    zify [Nat.cast_sub hp.pos] at num
    have l : (q:ℤ)*gap t≤numerator t :=
      (mul_le_mul_of_nonneg_left gp (Int.natCast_nonneg q)).trans (bound.trans num)
    have yi : q≤yCap t := by
      have val : (((gap t).toNat:ℕ):ℤ)=gap t := Int.toNat_of_nonneg gapp.le
      rw [←val] at l
      have qg : q*(gap t).toNat≤numerator t := by exact_mod_cast l
      by_contra! bad
      exact (not_lt_of_ge (Nat.mul_le_mul_right _ (by omega : yCap t+1≤q))) (qg.trans_lt cover)
    have order : ¬yCap t<t.pl+2 := by omega
    have b := budget_false ⟨k₀,k₁,b₀,b₁,c₀,c₁,p₀,p₁⟩ yi (pow_pos ppos _) (pow_pos qpos _)
      (by omega : 0<2^(k+1)-1) rp rq gl gh ex int
    simp [veto,not_le_of_gt pos,test,order,b]
  · simp [veto,not_le_of_gt pos,Bool.eq_false_of_not_eq_true test]

#print axioms veto_false
end OMA.RankTwoInteriorBox245212
