import ComplementaryExp245212
import ComplementaryFar245212
import TwoOddJoint245212
import TwoOddParameters245212
import TwoOddCoarse245212
import TwoOddLargeScale245212

/-! The finite scalar table and the unbounded dyadic estimate apply to
the same original integer equality, with all substitutions proved here. -/
namespace OMA.TwoOddEffectiveOriginal245212
open ArithmeticFunction OMA.TwoOddEffectiveTable245212
open scoped ArithmeticFunction.sigma

theorem bound {p q k a d : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 3≤p) (pq : p<q)
    (hk : 2≤k) (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) :
    min (a+1) (d+1)≤32 := by
  by_contra! outside
  let K:=k+1
  let B:=a+1
  let C:=d+1
  let m:=min B C
  let u:=64*m^2*K
  let t:=m*u
  let h:=5*K
  let y:=6*t*K*h^2
  let z:ℕ:=2^K
  let g:=z-1
  let P:=p^a
  let Q:=q^d
  let R:=p^(m-1)
  have ml : 33 ≤ m := outside
  have mb : m≤B := min_le_left _ _
  have mc : m≤C := min_le_right _ _
  have a32 : 32≤a := by dsimp [B] at mb;omega
  have d32 : 32≤d := by dsimp [C] at mc;omega
  have k3 : 3≤K := by dsimp [K];omega
  have many : 5≤(a+1)*(d+1) := by nlinarith only [a32,d32,Nat.zero_le (a*d)]
  have sm := OMA.ComplementaryBase245212.small_prime hp hq op (by omega) pq.ne many eqn
  have ph : p≤h := sm.elim id (fun z=>pq.le.trans z)
  have swap : OeisA245212.a (2^k*q^d*p^a)=(σ 1 (2^k*q^d*p^a):ℤ) := by rwa [mul_right_comm]
  have both : B≤u ∧ C≤u ∧ B*C≤t := by
    have easy : m≤u := by
      dsimp [u];nlinarith only [Nat.mul_le_mul_left (64*m^2) (show 1≤K by omega),Nat.mul_le_mul_left m ml]
    by_cases ord : B≤C
    · have me : m=B := min_eq_left ord
      have c : C≤u := by
        dsimp [u];rw [me]
        exact OMA.ComplementaryExp245212.exponent hq hp (by omega) op pq.ne' (by omega) swap
      exact ⟨me ▸ easy,c,by dsimp only [t];rw [me];exact Nat.mul_le_mul_left _ c⟩
    · have me : m=C := min_eq_right (by omega)
      have b : B≤u := by
        dsimp [u];rw [me]
        exact OMA.ComplementaryExp245212.exponent hp hq op (by omega) pq.ne (by omega) eqn
      exact ⟨b,me ▸ easy,by dsimp only [t];rw [me,mul_comm C u];exact Nat.mul_le_mul_right _ b⟩
  obtain ⟨bu,cu,bc⟩:=both
  have r0 : 0<R := pow_pos hp.pos _
  have rP : R≤P := Nat.pow_le_pow_right hp.pos (by dsimp [B] at mb;omega)
  have rQ : R≤Q := (Nat.pow_le_pow_left pq.le _).trans (Nat.pow_le_pow_right hq.pos (by dsimp [C] at mc;omega))
  have eqm : m-1=m-2+1 := by omega
  have qR : q*R≤h*Q := calc
    _ = p*(p^(m-2)*q) := by dsimp [R];rw [eqm,pow_succ];ring
    _ ≤ h*(q^(m-2)*q) := Nat.mul_le_mul ph (Nat.mul_le_mul_right _ (Nat.pow_le_pow_left pq.le _))
    _ = h*q^(m-1) := by rw [eqm,pow_succ]
    _ ≤ h*Q := Nat.mul_le_mul_left _ (Nat.pow_le_pow_right hq.pos (by dsimp [C] at mc;omega))
  have co := OMA.TwoOddParameters245212.cofactor hp hq op (by omega) pq.ne (by omega) eqn
  have qcap : q^(m-2)≤3*z*K*u*P := calc
    _ ≤ q^(d-1) := Nat.pow_le_pow_right hq.pos (by dsimp [C] at mc;omega)
    _ ≤ 3*z*K*B*P := co
    _ ≤ _ := by gcongr
  have errs := OMA.SimultaneousBound245212.original hp hq op pq (by omega) (by omega) hk ph eqn
  change P*Q≤g*OMA.SimultaneousBound245212.error p q K B C P Q ∧
    4*g*P*Q≤4*g*OMA.SimultaneousBound245212.error p q K B C P Q+9*K*p^2*q^2*B*C*P*Q at errs
  have cg := OMA.TwoOddCoarse245212.coarse (m:=m) (by omega : 1≤K)
    (by dsimp [u];exact Nat.mul_pos (Nat.mul_pos (by decide) (pow_pos (by omega) _)) (by omega))
    r0 rP rQ qR ph bu cu (le_refl _) (Nat.sub_le z 1) errs.1
    ((Nat.pow_le_pow_right hq.pos (show 4 ≤ m-2 by omega)).trans qcap)
  have near {r : ℕ} (pr : 0<r) (lower : r≤R) (box : 2*(K*t*h*r+g*u*K)≤g*r) : q≤y := by
    have actu : K*C*B*p*r+g*C*K≤K*t*h*r+g*u*K := calc
      _ = K*(B*C)*p*r+g*C*K := by ring
      _ ≤ _ := by gcongr
    have sm' : p-1≤(d+1)*k := by
      dsimp [h,K] at ph;nlinarith only [ph,hk,Nat.mul_le_mul_left k d32,Nat.sub_le p 1]
    have hq':=OMA.TwoOddJoint245212.near hp hq op (by omega) pq.ne (by omega) (by omega) eqn
      sm' pr (lower.trans rP) ((Nat.mul_le_mul_left _ actu).trans box)
    change q≤6*C*K*B*p^2 at hq'
    exact hq'.trans (calc
      _ = 6*(B*C)*K*p^2 := by ring
      _ ≤ y := Nat.mul_le_mul (Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ bc)) (Nat.pow_le_pow_left ph _))
  by_cases big : 256≤K
  · have ms := OMA.TwoOddGrowth245212.m_large big op cg
    have lo := OMA.TwoOddParameters245212.reciprocal hp hq op (by omega) pq.ne (by omega) eqn
    have least : K≤3*p := by
      dsimp [K];by_contra! bad
      nlinarith only [lo,Nat.mul_le_mul_right a (show 2*p≤k by omega),Nat.mul_le_mul_left p a32]
    obtain ⟨gc,pc,fin⟩:=OMA.TwoOddLargeScale245212.estimates big ml ms least
    change 4*K*t*h<z at gc
    change 4*u*K≤R at pc
    have gc' : 4*K*C*B*p<z := (show 4*K*C*B*p≤4*K*t*h by
      nlinarith only [Nat.mul_le_mul_left (4*K) (Nat.mul_le_mul bc ph)]).trans_lt gc
    have qsmall := OMA.ComplementaryFar245212.far hp hq op (by omega) pq.ne (by omega) (by omega)
      eqn gc' (((Nat.mul_le_mul_right K (Nat.mul_le_mul_left 4 cu)).trans pc).trans rP)
    have qy : q≤y := qsmall.trans (calc
      _ = 6*(B*C)*K*p^2 := by dsimp [B,C,K];ring
      _ ≤ y := Nat.mul_le_mul (Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ bc)) (Nat.pow_le_pow_left ph 2))
    exact OMA.TwoOddErrorCells245212.second_excluded r0 rP rQ ph qy bu cu bc errs.2 fin
  · have klow : K≤255 := by omega
    have mmax : m≤118 := by
      by_contra! tail
      have pmin := OMA.TwoOddParameters245212.floor hp hq op (by omega) pq.ne (by omega) (by decide : 1≤119)
        (show 119≤a+1 by dsimp [B] at mb;omega) eqn
      exact (not_lt_of_ge cg) (OMA.TwoOddGrowth245212.table_tail k3 klow tail pmin op)
    let rr:=(floorPrime K m)^(m-1)
    have lp : floorPrime K m≤p := OMA.TwoOddParameters245212.floor hp hq op (by omega) pq.ne
      (by omega) (by omega) mb eqn
    have rr0 : 0<rr := pow_pos (lt_of_lt_of_le (by decide : 0<3) (le_max_left _ _)) _
    have rrR : rr≤R := Nat.pow_le_pow_left lp _
    have data := of_decide_eq_true (ranges k3 klow ml mmax).2
    change (3*g*h^2*(K*u+h)<rr ∧ 3*g*(K+h^2)<rr^2 ∧ (3*g*(K*u+h))^(m-2)*(3*z*K*u)^2<rr^(m-4)) ∨
      (2*(K*t*h*rr+g*u*K)≤g*rr ∧ 4*g*((y^2*(K*u+h)+h^2*(K*u+y))*rr+(K+h*y))+
        9*K*h^2*y^2*t*rr^2<4*g*rr^2) at data
    rcases data with ⟨l1,l2,l3⟩|⟨j,jt⟩
    · have first := OMA.TwoOddErrorCells245212.first_excluded (by omega : 4 ≤ m) (rrR.trans rP)
        (r0.trans_le rP) qcap l3
      rcases OMA.TwoOddErrorCells245212.alternatives r0 rP rQ qR ph bu cu errs.1 with bad|bad|bad
      · omega
      · omega
      · exact (not_lt_of_ge (bad.trans' (Nat.pow_le_pow_left rrR 2))) l2
    · exact OMA.TwoOddErrorCells245212.second_excluded rr0 (rrR.trans rP) (rrR.trans rQ)
        ph (near rr0 rrR j) bu cu bc errs.2 jt

end OMA.TwoOddEffectiveOriginal245212
