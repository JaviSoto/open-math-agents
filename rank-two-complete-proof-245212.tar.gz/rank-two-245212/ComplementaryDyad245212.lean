import ComplementaryPole245212

/-! Integer bounds at both dyadic poles. No roots or logarithms are
needed, so the statements also cover small positive exponents. -/
namespace OMA.ComplementaryDyad245212
open ArithmeticFunction OMA.Smooth245212 OMA.ComplementaryPole245212 OMA.ComplementaryLocal245212
open scoped ArithmeticFunction.sigma

private theorem integer_round {k : ℕ} {b h P W S : ℤ} (hh : 0<h)
    (low : b*P≤W) (high : 2*W≤3*b*P)
    (plus : 0<den k b h P W S) (cut : ((k:ℤ)+1)*h*b*P≤G k) :
    G k≤2*den k b h P W S := by
  let u:=((k:ℤ)+1)*b*h*P-h*k*W-S
  have iden : G k*u=den k b h P W S+((k:ℤ)+1)*h*(W-b*P) := by
    dsimp [u,den,G,F]; ring
  have Kh : (0:ℤ)≤(k+1)*h := by positivity
  have gp := (dyad k).1
  have pos : 0<u := by
    apply pos_of_mul_pos_right (a:=G k) _ gp.le
    rw [iden]; exact add_pos_of_pos_of_nonneg plus (mul_nonneg Kh (sub_nonneg.mpr low))
  have gu : G k≤G k*u := by nlinarith only [mul_nonneg gp.le (by omega : 0≤u-1)]
  nlinarith only [iden,cut,gu,mul_le_mul_of_nonneg_left high Kh]

theorem near {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 3≤p) (oq : 3≤q)
    (pq : p≠q) (hd : 1≤d)
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ))
    (cut : (k+1)*(d+1)*(a+1)*p^a<2^(k+1)) :
    q≤6*(d+1)*(k+1)*(a+1)*p^a := by
  obtain ⟨e,rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : d≠0)
  let D:=den k (a+1) (e+2) ((p:ℤ)^a) (W (p^a)) (σ 1 (p^a))
  obtain ⟨dp,qu⟩ := tail hp hq op oq pq a e k eqn
  change 0<D at dp
  have cut' : ((k:ℤ)+1)*(e+2)*(a+1)*(p:ℤ)^a≤G k := by
    have h : ((k:ℤ)+1)*(e+1+1)*(a+1)*(p:ℤ)^a<(2:ℤ)^(k+1) := by exact_mod_cast cut
    dsimp [G,z]; linarith only [h]
  have bd := bounds hp op a
  have dg := integer_round (by positivity : (0:ℤ)<e+2)
    (by exact_mod_cast bd.2.2.1) (by exact_mod_cast bd.2.1) dp cut'
  change (q:ℤ)*D≤3*(e+2)*(k+1)*(a+1)*G k*(p:ℤ)^a at qu
  have gg : (q:ℤ)*G k≤(6*(e+2)*(k+1)*(a+1)*(p:ℤ)^a)*G k := by
    nlinarith only [qu,mul_le_mul_of_nonneg_left dg (by positivity : (0:ℤ)≤q)]
  exact_mod_cast (mul_le_mul_iff_left₀ (dyad k).1).mp gg

/-- The dyadic power divides the positive difference of the two
cofactor products, independently of the sizes of the exponents. -/
theorem level {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 3≤p) (oq : 3≤q)
    (pq : p≠q) (hd : 1≤d)
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) :
    2^(k+1) ≤ 3*(d+1)*(a+1)*p^a*q^d := by
  obtain ⟨e,rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : d≠0)
  let Wp : ℤ:=W (p^a)
  let Sp : ℤ:=σ 1 (p^a)
  let Wq : ℤ:=W (q^(e+1))
  let Sq : ℤ:=σ 1 (q^(e+1))
  let J:ℤ:=((k:ℤ)+1)*(a+1)*(e+1+1)*p^a*q^(e+1)
  have phy := physical hp hq (by omega) (by omega) pq a (e+1) k eqn
  change (1+k*z k)*Wp*Wq+(z k-1)*Sp*Sq=z k*(k+1)*(a+1)*(e+1+1)*p^a*q^(e+1) at phy
  have dv : z k∣Wp*Wq-Sp*Sq := ⟨J-k*Wp*Wq-Sp*Sq,by dsimp [J];linear_combination phy⟩
  have bd := bounds hp op a
  have bq := bounds hq oq (e+1)
  have sub : Sq<Wq := by
    dsimp [Sq,Wq]
    have endq := last hq oq e
    rw [endq.1,endq.2.1]
    have rest := (bounds hq oq e).2.2.2
    have top : 0<q^(e+1) := pow_pos hq.pos _
    exact_mod_cast (show q^(e+1)+σ 1 (q^e)<(e+2)*q^(e+1)+W (q^e) by
      nlinarith only [top,rest,Nat.zero_le (e*q^(e+1))])
  have sp : 0<Sp := by
    dsimp [Sp]; exact_mod_cast (show 0<σ 1 (p^a) by
      rw [sigma_one_apply_prime_pow hp];exact Finset.sum_pos (fun i _ => pow_pos hp.pos i) (by simp))
  have sw : Sp≤Wp := by dsimp [Sp,Wp];exact_mod_cast bd.2.2.2
  have lt : 0<Wp*Wq-Sp*Sq := by
    have sq : 0≤Sq := by dsimp [Sq];positivity
    nlinarith only [mul_pos sp (sub_pos.mpr sub),
      mul_nonneg (sub_nonneg.mpr sw) (by omega : 0≤Wq)]
  have dz := Int.le_of_dvd lt dv
  have wp : 2*Wp≤3*((a:ℤ)+1)*p^a := by dsimp [Wp];exact_mod_cast bd.2.1
  have wq : 2*Wq≤3*((e:ℤ)+1+1)*q^(e+1) := by dsimp [Wq];exact_mod_cast bq.2.1
  have qs : 0≤Sq := by dsimp [Sq];positivity
  have zz : z k≤3*(e+1+1)*(a+1)*(p:ℤ)^a*q^(e+1) := by
    nlinarith only [dz,mul_le_mul wp wq (by dsimp [Wq];positivity) (by positivity),
      mul_nonneg sp.le qs, show (0:ℤ)≤(e+1+1)*(a+1)*(p:ℤ)^a*q^(e+1) by positivity]
  dsimp [z] at zz;exact_mod_cast zz

theorem power_floor {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 3≤p) (oq : 3≤q)
    (pq : p≠q) (hd : 1≤d)
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) :
    2^(k+1)≤(6*(d+1)*(k+1)*(a+1)*p^a)^(d+1) := by
  let B := 6*(d+1)*(k+1)*(a+1)*p^a
  have bpos : 0<B := by dsimp [B];have := hp.pos;positivity
  change _ ≤ B^(d+1)
  by_cases cut : (k+1)*(d+1)*(a+1)*p^a<2^(k+1)
  · have qB : q≤B := near hp hq op oq pq hd eqn cut
    have small : 3*(d+1)*(a+1)*p^a≤B := by
      dsimp [B];nlinarith only [Nat.zero_le ((d+1)*k*(a+1)*p^a), Nat.zero_le ((d+1)*(a+1)*p^a)]
    exact (level hp hq op oq pq hd eqn).trans (by rw [pow_succ'];exact Nat.mul_le_mul small (Nat.pow_le_pow_left qB _))
  · apply (show 2^(k+1)≤B by dsimp [B];nlinarith only [cut,Nat.zero_le ((d+1)*(k+1)*(a+1)*p^a)]).trans
    simpa using (Nat.pow_le_pow_right bpos (show 1≤d+1 by omega))

end OMA.ComplementaryDyad245212
