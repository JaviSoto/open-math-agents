import SmallLength245212
import ExponentParity245212
import OddBoxFixed245212

/-! Quantitative bounds for a single linear complementary prime. The base
carrying the large exponent need not be the smaller prime. -/
namespace OMA.SmallLinear245212
open ArithmeticFunction
open scoped ArithmeticFunction.sigma

theorem exponential {C s start : ℕ} (nz : 0<start)
    (first : C*start^s < 2^start) (ratio : (start+1)^s≤2*start^s) :
    ∀ K, start≤K → C*K^s<2^K := by
  intro K hk
  induction K,hk using Nat.le_induction with
  | base => exact first
  | succ n hn ih =>
    have comp : (n+1)*start ≤ (start+1)*n := by nlinarith only [hn]
    have step := Nat.pow_le_pow_left comp s
    simp only [mul_pow] at step
    have limit : (n+1)^s*start^s ≤ (2*n^s)*start^s := calc
      _ ≤ (start+1)^s*n^s := step
      _ ≤ (2*start^s)*n^s := Nat.mul_le_mul_right _ ratio
      _ = _ := by ring
    have r := Nat.le_of_mul_le_mul_right limit (pow_pos nz s)
    rw [pow_succ];nlinarith only [Nat.mul_le_mul_left C r,ih]

theorem parity {p q a k : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 3≤p)
    (oq : 3≤q) (pq : p≠q)
    (eqn : OeisA245212.a (2^k*p^a*q)=(σ 1 (2^k*p^a*q):ℤ)) : a%4=2 := by
  let primes : Fin 2 → ℕ := ![p,q]
  let exp : Fin 2 → ℕ := ![a,1]
  have pr : ∀ i, (primes i).Prime := by intro i;fin_cases i <;> assumption
  have odd : ∀ i, Odd (primes i) := fun i => (pr i).odd_of_ne_two (by fin_cases i <;> dsimp [primes] <;> omega)
  have inj : Function.Injective primes := by
    intro i j h;fin_cases i <;> fin_cases j <;> simp_all [primes]
  have total : OMA.Smooth245212.total primes exp = p^a*q := by
    simp [OMA.Smooth245212.total,Fin.prod_univ_two,primes,exp]
  have eq := OMA.ExponentParity245212.exponent_product primes exp pr odd inj k (by
    rw [total,←mul_assoc];exact eqn)
  simp [Fin.prod_univ_two, exp] at eq
  omega

theorem dyadic {p q a k : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 3≤p)
    (oq : 3≤q) (pq : p≠q) (ha : 6≤a)
    (eqn : OeisA245212.a (2^k*p^a*q)=(σ 1 (2^k*p^a*q):ℤ)) : k+1<160 := by
  let K:=k+1
  let b:=a+1
  have eq' : OeisA245212.a (2^k*p^a*q^1)=(σ 1 (2^k*p^a*q^1):ℤ) := by simpa
  have flip : OeisA245212.a (2^k*q^1*p^a)=(σ 1 (2^k*q^1*p^a):ℤ) := by rwa [mul_right_comm]
  have cap := OMA.ComplementaryExp245212.exponent hp hq op oq pq (by decide : 1≤1) eq'
  have bnd : b≤256*K := by simpa [b,K] using cap
  have small := OMA.ComplementaryBase245212.small_prime hp hq op oq pq (by omega : 5≤(a+1)*(1+1)) eq'
  change p≤5*K ∨ q≤5*K at small
  have fin := OMA.SmallLength245212.complement hp hq op oq pq (by decide : 1≤1) (by omega) eq'
  change 2^K≤1+2*(1+1)*b*K*p^2*q^1+6*(1+1)^2*b*(K+p)*(q^1)^2 at fin
  norm_num only [pow_one,show (1+1:ℕ)=2 by rfl,show (2*2:ℕ)=4 by rfl,show (6*2^2:ℕ)=24 by rfl] at fin
  by_contra! h
  change 160≤K at h
  have fast : 2^56*K^12 < 2^K := exponential (by decide : 0<160) (by decide) (by decide) K h
  have hk : 1 ≤ K := by omega
  have cmp {i c : ℕ} (hi : i≤12) (hc : c≤2^56) : c*K^i<2^K :=
    (Nat.mul_le_mul hc (Nat.pow_le_pow_right hk hi)).trans_lt fast
  rcases small with ps | qs
  · have gc : 4*K*2*b*p<2^K := calc
      _ ≤ 4*K*2*(256*K)*(5*K) := by gcongr
      _ = 10240*K^3 := by ring
      _ < _ := cmp (by decide) (by decide)
    have pc : 8*K≤p^a := by
      by_contra! below
      have low := OMA.ComplementaryDyad245212.power_floor hp hq op oq pq (by decide : 1≤1) eq'
      change 2^K≤(6*2*K*b*p^a)^2 at low
      have limit : (6*2*K*b*p^a)^2 ≤ (6*2*K*(256*K)*(8*K))^2 := by gcongr
      have th : (6*2*K*(256*K)*(8*K))^2=603979776*K^6 := by ring
      exact (not_lt_of_ge (low.trans (limit.trans_eq th))) (cmp (by decide) (by decide))
    have qlim := OMA.ComplementaryFar245212.far hp hq op oq pq (by omega) (by decide : 1≤1) eq' gc pc
    have qmax : q ≤ 76800*K^4 := calc
      _ ≤ 6*2*K*b*p^2 := qlim
      _ ≤ 6*2*K*(256*K)*(5*K)^2 := by gcongr
      _ = _ := by ring
    have upper : 1+4*b*K*p^2*q+24*b*(K+p)*q^2 ≤
        1+4*(256*K)*K*(5*K)^2*(76800*K^4)+24*(256*K)*(K+5*K)*(76800*K^4)^2 := by gcongr
    have growth : 1+4*(256*K)*K*(5*K)^2*(76800*K^4)+24*(256*K)*(K+5*K)*(76800*K^4)^2
        ≤ 2^56*K^12 := by
      nlinarith only [Nat.one_le_pow 12 K (by omega),Nat.pow_le_pow_right hk (show 8≤12 by decide),
        Nat.pow_le_pow_right hk (show 10≤12 by decide)]
    exact (not_lt_of_ge (fin.trans (upper.trans growth))) fast
  · have gate : K*(a+1)*(1+1)*q^1<2^K := calc
      _ ≤ K*(256*K)*2*(5*K) := by rw [pow_one];change K*b*2*q≤_;gcongr
      _ = 2560*K^3 := by ring
      _ < _ := cmp (by decide) (by decide)
    have pbound := OMA.ComplementaryDyad245212.near hq hp oq op pq.symm (by omega) flip gate
    have pmax : p≤15360*K^3 := calc
      _ ≤ 6*b*K*2*q^1 := pbound
      _ ≤ 6*(256*K)*K*2*(5*K) := by rw [pow_one];gcongr
      _ = _ := by ring
    have upper : 1+4*b*K*p^2*q+24*b*(K+p)*q^2 ≤
        1+4*(256*K)*K*(15360*K^3)^2*(5*K)+24*(256*K)*(K+15360*K^3)*(5*K)^2 := by gcongr
    have growth : 1+4*(256*K)*K*(15360*K^3)^2*(5*K)+24*(256*K)*(K+15360*K^3)*(5*K)^2
        ≤ 2^56*K^12 := by
      nlinarith only [Nat.one_le_pow 12 K (by omega),Nat.pow_le_pow_right hk (show 9≤12 by decide),
        Nat.pow_le_pow_right hk (show 4≤12 by decide),Nat.pow_le_pow_right hk (show 6≤12 by decide)]
    exact (not_lt_of_ge (fin.trans (upper.trans growth))) fast

def limit (K : ℕ) := 4194304*(2^K)^2*K^5

theorem box {p q a k : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 3≤p)
    (oq : 3≤q) (pq : p≠q)
    (eqn : OeisA245212.a (2^k*p^a*q)=(σ 1 (2^k*p^a*q):ℤ)) :
    k+1<160 ∧ a%4=2 ∧ p^(a-1)≤limit (k+1) ∧ a≤240 ∧ min p q≤5*(k+1) := by
  let K:=k+1
  let z:ℕ:=2^K
  have res := parity hp hq op oq pq eqn
  have ha : 2≤a := by omega
  have eq' : OeisA245212.a (2^k*p^a*q^1)=(σ 1 (2^k*p^a*q^1):ℤ) := by simpa
  have dy : K<160 := by
    by_cases big : 6≤a
    · exact dyadic hp hq op oq pq big eqn
    have a2 : a=2 := by omega
    subst a
    have odd := ((hp.odd_of_ne_two (by omega)).pow (n:=2)).mul (hq.odd_of_ne_two (by omega))
    have size : 1<p^2*q := by nlinarith only [hp.pos,hq.pos,op,oq,Nat.mul_le_mul_left (p^2) oq]
    have t := (OMA.DivisorHeight245212.effective_box odd size (by simpa only [←mul_assoc] using eqn)).1
    have cp := ((Nat.coprime_primes hp hq).mpr pq).pow_left 2
    have card : (p^2*q).divisors.card=6 := by
      have one : (σ 0) (q^1) = 1+1 := sigma_zero_apply_prime_pow hq
      simp only [pow_one] at one
      rw [←sigma_zero_apply,isMultiplicative_sigma.map_mul_of_coprime cp,
        sigma_zero_apply_prime_pow hp,one]
      decide
    rw [card] at t
    exact lt_of_le_of_lt t (by decide)
  have hk : 1≤K := by dsimp [K];omega
  have hz : 1≤z := Nat.one_le_pow _ _ (by decide)
  have bnd := OMA.ComplementaryExp245212.exponent hp hq op oq pq (by decide : 1≤1) eq'
  change a+1≤256*K at bnd
  have small := OMA.ComplementaryBase245212.small_prime hp hq op oq pq (by omega : 5≤(a+1)*(1+1)) eq'
  change p≤5*K ∨ q≤5*K at small
  have orig := OMA.ComplementaryBase245212.cofactor hp hq op oq pq eq'
  simp only [pow_one] at orig
  change p^a≤4*z*(K+p)*q at orig
  have power : p^(a-1)≤limit K := by
    change p^(a-1)≤4194304*z^2*K^5
    rcases small with ps | qs
    · have alt := OMA.ComplementaryPole245212.alternative hp hq op oq pq a 0 k ha eq'
      change p^a≤2*z*2*K ∨ q≤12*K*(a+1)*z*p^2 at alt
      apply (Nat.pow_le_pow_right hp.pos (Nat.sub_le _ _)).trans
      rcases alt with smallP | upper
      · have cf : 4*z*K^1≤4194304*z^2*K^5 :=
          Nat.mul_le_mul (Nat.mul_le_mul (by decide) (by simpa using Nat.pow_le_pow_right hz (show 1≤2 by decide)))
            (Nat.pow_le_pow_right hk (by decide))
        rw [pow_one] at cf
        exact smallP.trans (by nlinarith only [cf])
      · have bound : 4*z*(K+p)*q≤4*z*(K+5*K)*(12*K*(256*K)*z*(5*K)^2) := by
          apply Nat.mul_le_mul (by gcongr) (upper.trans (by gcongr))
        exact orig.trans (bound.trans (by nlinarith only [Nat.zero_le (z^2*K^5)]))
    · have kp : K+p≤2*K*p := by nlinarith only [Nat.mul_le_mul_left K hp.pos,Nat.mul_le_mul_right p hk]
      have bound : 4*z*(K+p)*q≤4*z*(2*K*p)*(5*K) := by gcongr
      have cancel : p^(a-1)≤40*z*K^2 := by
        apply Nat.le_of_mul_le_mul_right _ hp.pos
        rw [←pow_succ,show a-1+1=a by omega]
        exact orig.trans (bound.trans_eq (by ring))
      exact cancel.trans (Nat.mul_le_mul (Nat.mul_le_mul (by decide)
        (by simpa using Nat.pow_le_pow_right hz (show 1≤2 by decide))) (Nat.pow_le_pow_right hk (by decide)))
  refine ⟨dy,res,power,?_,by omega⟩
  by_contra! big
  have bigger : 3^240≤p^(a-1) :=
    (Nat.pow_le_pow_left op 240).trans (Nat.pow_le_pow_right hp.pos (by omega))
  have cut : limit K≤limit 160 := by unfold limit;gcongr;omega
  exact (not_le_of_gt (by decide : limit 160<3^240)) (bigger.trans (power.trans cut))

end OMA.SmallLinear245212
