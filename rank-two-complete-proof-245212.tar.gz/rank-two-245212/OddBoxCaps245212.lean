import OddBoxModel245212

/-! Bounds for the logarithm of the larger prime and for its square divided
by the smaller prime power, including the two conditional pole refinements. -/
namespace OMA.OddBox245212

structure Fits (f : Frame) (K B C p q : ℕ) : Prop where
  kl0 : 6≤f.kl
  bl0 : 6≤f.bl
  cl0 : 6≤f.cl
  lo0 : 1≤f.lo
  lk : f.kl≤K
  hk : K≤f.kh
  lb : f.bl≤B
  hb : B≤f.bh
  lc : f.cl≤C
  hc : C≤f.ch
  lp : f.lo≤p
  hp : p≤f.hi
  lq : f.qlo≤q
  pq : p≤q

namespace Fits
variable {f : Frame} {K B C p q : ℕ} (t : Fits f K B C p q)
include t
theorem pos : 0<K ∧ 0<B ∧ 0<C ∧ 0<p ∧ 0<q := by
  obtain ⟨_,_,_,_,_,_,_,_,_,_,_,_,_,_⟩:=t;omega
theorem xp_lower : (f.xp:ℝ)≤(B-1:ℕ)*L p := by
  have lo:=down_le t.lo0 t.lp
  have l0 : 0≤(down f.lo:ℝ) := by unfold down;positivity
  have b : (f.bl-1:ℕ)≤B-1 := Nat.sub_le_sub_right t.lb 1
  simp only [Frame.xp,Int.cast_mul,Int.cast_natCast]
  exact mul_le_mul (by exact_mod_cast b) lo l0 (by positivity)

theorem xp_upper : (B-1:ℕ)*L p≤((f.bh-1:ℕ)*up f.hi:ℤ) := by
  have u:=le_up t.pos.2.2.2.1 t.hp
  have b := Nat.sub_le_sub_right t.hb 1
  push_cast
  exact mul_le_mul (by exact_mod_cast b) u (nat_nonneg _ t.pos.2.2.2.1) (by positivity)

theorem rhs : 16*(K:ℝ)+L (3*K*B)≤f.cap := by
  obtain ⟨k,b,c,p',q'⟩:=t.pos
  have ha := le_up (by positivity : 0<3*K*B) (show 3*K*B≤3*f.kh*f.bh by gcongr <;> first | exact t.hk | exact t.hb)
  have hK : (K:ℝ)≤f.kh := by exact_mod_cast t.hk
  simp only [Frame.cap,Frame.dz,Int.cast_add,Int.cast_mul,Int.cast_natCast,Int.cast_ofNat]
  linarith

theorem caps (model : Model K B C p q) :
    (f.cl-2:ℕ)*L q≤(f.capY:ℝ) ∧
    ((f.cl:ℝ)-f.bh-1)*L q≤f.cap ∧
    L q≤f.y ∧ 2*L q-(B-1:ℕ)*L p≤f.normalized := by
  obtain ⟨kp,bp,cp,pp,qp⟩:=t.pos
  have qn:=nat_nonneg q qp
  have pn:=nat_nonneg p pp
  have kU : (K:ℝ)≤f.kh := by exact_mod_cast t.hk
  have kL : (f.kl-1:ℕ)≤K-1 := Nat.sub_le_sub_right t.lk _
  have c0:=t.cl0
  have clc : (f.cl-2:ℕ)≤C-2 := Nat.sub_le_sub_right t.lc _
  have bt := t.xp_upper
  have bi := t.xp_lower
  have co := model.co
  have right := t.rhs
  have cc := mul_le_mul_of_nonneg_right (show ((f.cl-2:ℕ):ℝ)≤(C-2:ℕ) by exact_mod_cast clc) qn
  have reduced : (f.cl-2:ℕ)*L q≤(f.cap:ℝ)+(B-1:ℕ)*L p := by linarith only [cc,co,right]
  have cY : (f.cl-2:ℕ)*L q≤(f.capY:ℝ) := by
    simp only [Frame.capY,Int.cast_add,Int.cast_mul,Int.cast_natCast] at bt ⊢
    linarith only [reduced,bt]
  have ordered : ((f.cl:ℝ)-f.bh-1)*L q≤f.cap := by
    have cb := Nat.sub_le_sub_right t.hb 1
    have mul := mul_le_mul (show ((B-1:ℕ):ℝ)≤(f.bh-1:ℕ) by exact_mod_cast cb)
      (lmono pp t.pq) pn (by positivity : (0:ℝ)≤(f.bh-1:ℕ))
    have bhp : 1≤f.bh := bp.trans_le t.hb
    simp only [Nat.cast_sub (by omega : 2≤f.cl),Nat.cast_sub bhp,Nat.cast_ofNat,Nat.cast_one] at reduced mul
    nlinarith only [reduced,mul]
  have y₁ := over_bound (show 0<f.cl-2 by omega) cY
  have rest : L (rest K B C p)≤f.residue := by
    unfold Frame.residue
    apply le_up (by dsimp [rest];positivity)
    unfold OddBox245212.rest
    gcongr <;> first | exact t.hk | exact t.hc | exact t.hb | exact t.hp
  have kdz : 16*(K:ℝ)≤f.dz := by
    simp only [Frame.dz,Int.cast_mul,Int.cast_ofNat,Int.cast_natCast]
    linarith only [kU]
  have dgl : (f.dg:ℝ)≤16*(K-1:ℕ) := by
    simp only [Frame.dg,Int.cast_mul,Int.cast_ofNat,Int.cast_natCast]
    exact mul_le_mul_of_nonneg_left (by exact_mod_cast kL) (by norm_num)
  have y₂ : f.dz+up (2*f.ch*f.kh)≤f.xp → L q≤(f.dz+f.residue:ℤ) := by
    intro pre
    have pre' : (f.dz:ℝ)+up (2*f.ch*f.kh)≤f.xp := by exact_mod_cast pre
    have cv:=le_up (by positivity : 0<2*C*K) (show 2*C*K≤2*f.ch*f.kh by gcongr <;> first | exact t.hc | exact t.hk)
    have nz := model.near (by linarith only [pre',cv,kdz,bi])
    push_cast;linarith only [nz,kdz,rest]
  have y₃ : max (up (f.ch*f.kh*f.bh*f.hi)-f.dg) (up (f.ch*f.kh)-f.xp)≤ -32 → L q≤f.residue := by
    intro pre
    obtain ⟨u,v⟩:=max_le_iff.mp pre
    have wt:=le_up (by positivity : 0<C*K*B*p) (show C*K*B*p≤f.ch*f.kh*f.bh*f.hi by gcongr <;> first | exact t.hc | exact t.hk | exact t.hb | exact t.hp)
    have kt:=le_up (by positivity : 0<C*K) (show C*K≤f.ch*f.kh by gcongr <;> first | exact t.hc | exact t.hk)
    have u' : (up (f.ch*f.kh*f.bh*f.hi):ℝ)-f.dg≤ -32 := by exact_mod_cast u
    have v' : (up (f.ch*f.kh):ℝ)-f.xp≤ -32 := by exact_mod_cast v
    exact (model.far (by linarith only [wt,u',dgl]) (by linarith only [kt,v',bi])).trans rest
  have bound : L q≤f.y := by
    simp only [Int.cast_add] at y₂
    unfold Frame.y
    split <;> split <;> push_cast <;> try simp only [le_min_iff]
    all_goals tauto
  have ratio : (f.cl-2:ℕ)*(2*L q-(B-1:ℕ)*L p)≤(2*f.cap-(f.cl-4:ℕ)*f.xp:ℤ) := by
    have factor := mul_le_mul_of_nonneg_left bi (show (0:ℝ)≤(f.cl-4:ℕ) by positivity)
    simp only [Int.cast_sub,Int.cast_mul,Int.cast_ofNat,Int.cast_natCast,Nat.cast_sub (by omega : 4≤f.cl),
      Nat.cast_sub (by omega : 2≤f.cl),Nat.cast_ofNat] at factor reduced ⊢
    nlinarith only [reduced,factor]
  have y₄ := over_bound (show 0<f.cl-2 by omega) ratio
  refine ⟨cY,ordered,bound,?_⟩
  simp only [Frame.normalized,Int.cast_min,Int.cast_sub,Int.cast_mul,Int.cast_ofNat,le_min_iff]
  exact ⟨y₄,by linarith only [bound,bi]⟩

end Fits
end OMA.OddBox245212
