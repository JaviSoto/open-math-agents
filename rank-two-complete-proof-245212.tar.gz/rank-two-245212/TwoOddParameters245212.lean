import ComplementaryBase245212
import TwoOddEffectiveTable245212

/-! Elementary bounds on the prime bases and on powers appearing in the
simultaneous rounding estimates. -/
namespace OMA.TwoOddParameters245212
open OMA.Smooth245212 OMA.ComplementaryLocal245212 OMA.ComplementaryPole245212 ArithmeticFunction
open scoped ArithmeticFunction.sigma

theorem cofactor {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 3≤p) (oq : 3≤q) (pq : p≠q)
    (hd : 1≤d) (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) :
    q^(d-1)≤3*2^(k+1)*(k+1)*(a+1)*p^a := by
  have eq' : OeisA245212.a (2^k*q^d*p^a)=(σ 1 (2^k*q^d*p^a):ℤ) := by rwa [mul_right_comm]
  have cap := OMA.ComplementaryBase245212.cofactor hq hp oq op pq.symm eq'
  have cq : 2*((k+1)+q)≤3*(k+1)*q := by
    nlinarith only [oq,Nat.mul_le_mul_left k oq]
  apply (mul_le_mul_iff_left₀ hq.pos).mp
  rw [←pow_succ,show d-1+1=d by omega]
  nlinarith only [cap,Nat.mul_le_mul_right ((a+1)*2^(k+1)*p^a) cq]

theorem reciprocal {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 3≤p) (oq : 3≤q) (pq : p≠q)
    (ha : 1≤a) (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) :
    k*a<(a+1)*p := by
  obtain ⟨e,rfl⟩:=Nat.exists_eq_succ_of_ne_zero (by omega : a≠0)
  let B : ℤ := e+2
  let C : ℤ := d+1
  let P : ℤ := (p:ℤ)^(e+1)
  let Q : ℤ := (q:ℤ)^d
  let x : ℤ := (p:ℤ)^e
  let W0 : ℤ := W (p^(e+1))
  let V : ℤ := W (q^d)
  let S : ℤ := σ 1 (p^(e+1))
  let T : ℤ := σ 1 (q^d)
  have pp : (0:ℤ)<p := by omega
  have qq : (0:ℤ)<q := by omega
  have xp : 0<x := pow_pos pp _
  have qp : 0<Q := pow_pos qq _
  have cp : 0<C := by dsimp [C];positivity
  have bp : 0<B := by dsimp [B];positivity
  have px : P=x*p := by dsimp [P,x];rw [pow_succ]
  have first : B*P+((e:ℤ)+1)*x≤W0 := by
    dsimp [B,P,x,W0];rw [(last hp op e).1];push_cast
    have low : ((e:ℤ)+1)*(p:ℤ)^e≤W (p^e) := by exact_mod_cast (bounds hp op e).2.2.1
    linarith only [low]
  have second : C*Q≤V := by dsimp [C,Q,V];exact_mod_cast (bounds hq oq d).2.2.1
  have w0 : 0≤W0 := by dsimp [W0];positivity
  have pos (r t : ℕ) (prime : r.Prime) : (0:ℤ)<σ 1 (r^t) := by
    exact_mod_cast (show 0<σ 1 (r^t) by
      rw [sigma_one_apply_prime_pow prime]
      exact Finset.sum_pos (fun i _=>pow_pos prime.pos i) (by simp))
  have phy := physical hp hq (by omega) (by omega) pq (e+1) d k eqn
  change F k*W0*V+G k*S*T=z k*(k+1)*(e+1+1)*C*P*Q at phy
  have ar : ((e:ℤ)+1+1)=B := by dsimp [B];ring
  rw [←(dyad k).2.2.2, ar] at phy
  have prod := mul_le_mul first second (mul_pos cp qp).le w0
  have f : (k:ℤ)*G k≤F k := by dsimp [F,G];nlinarith only [show (0:ℤ)≤k by positivity]
  have up := mul_le_mul_of_nonneg_right f (mul_nonneg (mul_nonneg (by positivity : (0:ℤ)≤e+1) xp.le) (mul_pos cp qp).le)
  have g0 := (dyad k).1
  have st : 0<G k*S*T := mul_pos (mul_pos g0 (pos p (e+1) hp)) (pos q d hq)
  have fact : ((k:ℤ)*(e+1))*(G k*x*C*Q)<(B*p)*(G k*x*C*Q) := by
    rw [px] at phy prod
    nlinarith only [phy,mul_le_mul_of_nonneg_left prod (dyad k).2.1.le,up,st]
  have res := (mul_lt_mul_iff_left₀ (mul_pos (mul_pos (mul_pos g0 xp) cp) qp)).mp fact
  dsimp [B] at res;exact_mod_cast res

theorem floor {p q a d k m : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 3≤p) (oq : 3≤q) (pq : p≠q)
    (ha : 1≤a) (hm : 1 ≤ m) (mb : m≤a+1)
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) :
    OMA.TwoOddEffectiveTable245212.floorPrime (k+1) m≤p := by
  have r := reciprocal hp hq op oq pq ha eqn
  unfold OMA.TwoOddEffectiveTable245212.floorPrime
  apply max_le op
  have lt : k*(m-1)<p*m := by
    by_contra! ge
    have sub := Nat.sub_add_cancel hm
    nlinarith only [Nat.mul_le_mul_left (a+1) ge,Nat.mul_lt_mul_of_pos_left r hm,
      Nat.mul_le_mul_left k mb,congrArg (fun x:ℕ=>k*(a+1)*x) sub]
  change 1+k*(m-1)/m≤p
  exact (Nat.div_lt_iff_lt_mul hm).mpr lt |> (by omega : _ → _)

end OMA.TwoOddParameters245212
