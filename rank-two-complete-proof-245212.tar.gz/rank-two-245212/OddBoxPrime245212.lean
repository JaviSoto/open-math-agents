import TwoOddParameters245212
import OddBoxCheck245212

/-! Bounds on the least odd prime follow from the two-prime balance. -/

namespace OMA.OddBox245212
open ArithmeticFunction OMA.Smooth245212 OMA.ComplementaryLocal245212 OMA.ComplementaryPole245212
open scoped ArithmeticFunction.sigma

private theorem ratio {K G F u D E S T W V : ℤ} (u12 : 12≤u) (gg : 0<G)
    (ff : 0<F) (kg : F≤K*G) (dd : 0<D) (ee : 0<E)
    (wl : D≤W) (vl : E≤V) (wu : u*W≤(u+1)*D) (vu : u*V≤(u+1)*E)
    (ss : 16*S*T≤D*E) (eqn : F*W*V+G*S*T=(F+G)*D*E) : 4*u<9*K := by
  have ww := mul_le_mul wu vu (mul_nonneg (by omega) (ee.le.trans vl))
    (mul_nonneg (by omega) dd.le)
  have sur := mul_le_mul wl vl ee.le (dd.le.trans wl)
  have wz : 0≤W*V-D*E := sub_nonneg.mpr sur
  have upper : u^2*(W*V-D*E)≤(2*u+1)*D*E := by nlinarith only [ww]
  have fst : 15*G*D*E≤16*F*(W*V-D*E) := by
    nlinarith only [eqn,mul_le_mul_of_nonneg_left ss gg.le]
  have limit : (15*u^2)*(G*D*E)≤(16*K*(2*u+1))*(G*D*E) := by
    nlinarith only [mul_le_mul_of_nonneg_left fst (sq_nonneg u),
      mul_le_mul_of_nonneg_left upper (show 0≤16*F by omega),
      mul_le_mul_of_nonneg_right kg (show 0≤16*(2*u+1)*D*E by positivity)]
  have cap := (mul_le_mul_iff_left₀ (mul_pos (mul_pos gg dd) ee)).mp limit
  have kp : 0<K := pos_of_mul_pos_left (ff.trans_le kg) gg.le
  have bound : (180*u)*u≤(400*K)*u := by
    nlinarith only [cap,mul_le_mul_of_nonneg_left (show 12*(2*u+1)≤25*u by omega) (show 0≤16*K by omega)]
  have := (mul_le_mul_iff_left₀ (show 0<u by omega)).mp bound
  omega

theorem prime_bound {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 13≤p)
    (pq : p<q) (ha : 5≤a) (hd : 5≤d)
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) :
    4*(p-1)<9*(k+1) := by
  let P : ℤ := (p:ℤ)^a
  let Q : ℤ := (q:ℤ)^d
  let D : ℤ := (a+1)*P
  let E : ℤ := (d+1)*Q
  let W : ℤ := OMA.Smooth245212.W (p^a)
  let V : ℤ := OMA.Smooth245212.W (q^d)
  let S : ℤ := σ 1 (p^a)
  let T : ℤ := σ 1 (q^d)
  let u : ℤ := (p:ℤ)-1
  let v : ℤ := (q:ℤ)-1
  have up : 12≤u := by dsimp [u];omega
  have uv : u≤v := by dsimp [u,v];omega
  have pw := OMA.PrimePowerDiv245212.weighted hp a
  have qw := OMA.PrimePowerDiv245212.weighted hq d
  zify [Nat.cast_sub hp.pos] at pw
  zify [Nat.cast_sub hq.pos] at qw
  change u*W+S=(p:ℤ)*D at pw
  change v*V+T=(q:ℤ)*E at qw
  have wl : D≤W := by dsimp [D,P,W];exact_mod_cast (bounds hp (by omega) a).2.2.1
  have vl : E≤V := by dsimp [E,Q,V];exact_mod_cast (bounds hq (by omega) d).2.2.1
  have ss : 2*S≤3*P := by dsimp [S,P];exact_mod_cast (bounds hp (by omega) a).1
  have tt : 2*T≤3*Q := by dsimp [T,Q];exact_mod_cast (bounds hq (by omega) d).1
  have s0 : 0 ≤ S := by dsimp [S];positivity
  have t0 : 0≤T := by dsimp [T];positivity
  have p0 : 0<P := by dsimp [P];positivity
  have q0 : 0<Q := pow_pos (by omega : (0:ℤ)<q) _
  have vu : u*V≤(u+1)*E := by
    have scale := mul_le_mul_of_nonneg_right uv (sub_nonneg.mpr vl)
    dsimp only [v] at qw scale
    nlinarith only [scale,qw,t0]
  have st := mul_le_mul ss tt (by positivity : 0≤2*T) (by positivity : 0≤3*P)
  have bc := mul_le_mul (show (6:ℤ)≤a+1 by omega) (show (6:ℤ)≤d+1 by omega) (by decide) (by positivity)
  have sm : 16*S*T≤D*E := by dsimp only [D,E];nlinarith only [st,mul_le_mul_of_nonneg_right bc (mul_nonneg p0.le q0.le)]
  have eq := physical hp hq (by omega) (by omega) pq.ne a d k eqn
  change F k*W*V+G k*S*T=z k*(k+1)*(a+1)*(d+1)*P*Q at eq
  rw [←(dyad k).2.2.2] at eq
  have r := ratio up (dyad k).1 (dyad k).2.1 (dyad k).2.2.1
    (by dsimp [D];positivity : 0<D) (by dsimp [E];positivity : 0<E) wl vl
    (by dsimp [u] at pw ⊢;nlinarith only [pw,s0]) vu sm (by dsimp [D,E];linear_combination eq)
  dsimp only [u] at r;zify [Nat.cast_sub hp.pos];exact r

theorem prime_window {p q a d k kl kh bl pl ph : ℕ} (hp : p.Prime) (hq : q.Prime)
    (op : 13≤p) (pq : p<q) (ha : 5≤a) (hd : 5≤d) (lk : kl≤k+1) (uk : k+1≤kh)
    (lb : 1≤bl) (ba : bl≤a+1) (plp : pl≤p) (php : p≤ph)
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) :
    lowPrime kl bl pl≤p ∧ p≤highPrime kh ph ∧ lowPrime kl bl pl+2≤q := by
  have lo := OMA.TwoOddParameters245212.floor hp hq (by omega) (by omega) pq.ne (by omega) lb ba eqn
  unfold OMA.TwoOddEffectiveTable245212.floorPrime at lo
  have le : (kl-1)*(bl-1)/bl≤k*(bl-1)/bl :=
    Nat.div_le_div_right (Nat.mul_le_mul_right _ (by omega))
  obtain ⟨i,po⟩ := hp.odd_of_ne_two (by omega)
  obtain ⟨j,qo⟩ := hq.odd_of_ne_two (by omega)
  have small : lowPrime kl bl pl≤p := by
    unfold lowPrime
    simp only [Nat.add_sub_cancel] at lo
    generalize h : max 13 (max pl (1+(kl-1)*(bl-1)/bl))=b
    have b0 : b≤p := by rw [←h];omega
    change b+(1-b%2)≤p
    omega
  have pb := prime_bound hp hq op pq ha hd eqn
  exact ⟨small,by unfold highPrime;omega,by omega⟩

end OMA.OddBox245212
