import OddBoxCaps245212

/-! Endpoint substitution and soundness for any closed parameter box and
any least-prime subinterval. -/
namespace OMA.OddBox245212
open scoped ArithmeticFunction.sigma
set_option maxHeartbeats 1400000

private theorem down_nonneg (n : ℕ) : 0≤(down n:ℝ) := by
  simp only [down,Int.cast_natCast,Nat.cast_nonneg]

private theorem comp_false {kl kh bl bh ch K B C : ℕ} {x y : ℝ} {X Y : ℤ}
    (kp : 0<K) (bp : 0<B) (cp : 0<C) (klK : kl≤K) (Kkh : K≤kh)
    (blB : bl≤B) (Bbh : B≤bh) (Cch : C≤ch) (y0 : 0≤y) (lx : x≤X) (ly : y≤Y)
    (hit : 2*C+3≤B → 16*(K:ℝ)≤compLimit K B C x y) : compVeto kl kh bl bh ch X Y=false := by
  unfold compVeto
  simp only [decide_eq_false_iff_not,not_and]
  intro big fail
  have bound:=hit (by omega)
  have low : 16*(kl:ℝ)≤16*K := by gcongr
  have cut := le_up (a:=2*C*B*K) (by positivity)
    (show 2*C*B*K≤2*ch*bh*kh by gcongr)
  have cut' := le_up (a:=6*C^2*B) (by positivity)
    (show 6*C^2*B≤6*ch^2*bh by gcongr)
  have Y0 : 0≤(Y:ℝ) := y0.trans ly
  have cy : (C-1:ℕ)*y≤(ch-1:ℕ)*(Y:ℝ) :=
    mul_le_mul (by exact_mod_cast Nat.sub_le_sub_right Cch 1) ly y0 (by positivity)
  have mk := max_le_max (le_up kp Kkh) lx
  have a := (enclosed 3 (by decide)).2
  have z : 16*(kl:ℤ) ≤ max 0 (max (up (2*ch*bh*kh)+2*X+(ch-1:ℕ)*Y)
      (up (6*ch^2*bh)+16+max (up kh) X+2*(ch-1:ℕ)*Y))+up 3 := by
    apply Int.cast_le (R:=ℝ) |>.mp
    push_cast
    unfold compLimit at bound
    have le := max_le_max (a:= (0:ℝ)) le_rfl (max_le_max
      (show L (2*C*B*K)+2*x+(C-1:ℕ)*y≤(up (2*ch*bh*kh):ℝ)+2*X+(ch-1:ℕ)*(Y:ℝ) by linarith only [cut,lx,cy])
      (show L (6*C^2*B)+16+max (L K) x+2*(C-1:ℕ)*y≤(up (6*ch^2*bh):ℝ)+16+max (up kh:ℝ) (X:ℝ)+2*(ch-1:ℕ)*(Y:ℝ)
        by nlinarith only [cut',mk,cy]))
    linarith only [low,bound,le,a]
  omega

attribute [local irreducible] Frame.y Frame.normalized Frame.capY Frame.xp Frame.dz Frame.dg
  Frame.largest Frame.drift Frame.yq down up logSize

theorem Fits.retain {f : Frame} {K B C p q : ℕ} (t : Fits f K B C p q) (m : Model K B C p q) :
    f.reject=false := by
  obtain ⟨kp,bp,cp,pp,qp⟩:=t.pos
  obtain ⟨co,ord,y,norm⟩:=t.caps m
  have lo:=t.lo0
  have lq0 : 0<f.qlo := by dsimp [Frame.qlo];omega
  have dl := down_le lo t.lp
  have dq := down_le lq0 t.lq
  have dqn := down_nonneg f.qlo
  have hp := le_up pp t.hp
  have pn := nat_nonneg p pp
  have qn := nat_nonneg q qp
  have ch : ((C-1:ℕ):ℝ)≤(f.ch-1:ℕ) := by exact_mod_cast Nat.sub_le_sub_right t.hc 1
  have yd : (C-1:ℕ)*L q≤(f.ch-1:ℕ)*(f.y:ℝ) :=
    mul_le_mul ch y qn (Nat.cast_nonneg (α:=ℝ) _)
  have xp := t.xp_lower
  have pU := t.xp_upper
  have kmin : 16*(f.kl:ℝ)≤16*K := mul_le_mul_of_nonneg_left (by exact_mod_cast t.lk) (by norm_num)
  have kmax : 16*(K:ℝ)≤f.dz := by
    simp only [Frame.dz,Int.cast_mul,Int.cast_ofNat,Int.cast_natCast]
    exact mul_le_mul_of_nonneg_left (by exact_mod_cast t.hk) (by norm_num)
  have dg : (f.dg:ℝ)≤16*(K-1:ℕ) := by
    simp only [Frame.dg,Int.cast_mul,Int.cast_ofNat,Int.cast_natCast]
    exact mul_le_mul_of_nonneg_left (by exact_mod_cast Nat.sub_le_sub_right t.lk 1) (by norm_num)
  have rev : (f.bl-2:ℕ)*down f.lo≤f.dz+up (3*f.kh*f.ch)+(f.ch-1:ℕ)*f.y := by
    apply Int.cast_le (R:=ℝ) |>.mp
    push_cast
    have scale:= mul_le_mul (show ((f.bl-2:ℕ):ℝ)≤(B-2:ℕ) by exact_mod_cast Nat.sub_le_sub_right t.lb 2)
      dl (down_nonneg f.lo) (Nat.cast_nonneg (α:=ℝ) _)
    have u:=le_up (by positivity : 0<3*K*C) (show 3*K*C≤3*f.kh*f.ch by gcongr <;> first | exact t.hk | exact t.hc)
    linarith only [scale,m.rev,yd,kmax,u]
  have z : 16*(f.kl:ℤ)≤up (3*f.bh*f.ch)+(f.bh-1:ℕ)*up f.hi+(f.ch-1:ℕ)*f.y := by
    apply Int.cast_le (R:=ℝ) |>.mp
    push_cast at pU ⊢
    have u:=le_up (by positivity : 0<3*B*C) (show 3*B*C≤3*f.bh*f.ch by gcongr <;> first | exact t.hb | exact t.hc)
    linarith only [kmin,m.level,yd,pU,u]
  have yl : (f.cl-1:ℕ)*(down f.qlo:ℝ)≤(C-1:ℕ)*L f.qlo :=
    mul_le_mul (by exact_mod_cast Nat.sub_le_sub_right t.lc 1) (enclosed _ lq0).1 dqn (by positivity)
  have termle : terms K B C p q≤f.largest := by
    have c2 : 1≤C-1 := by have := t.cl0;have := t.lc;omega
    have nr := increasing_gap (a:=K*B) (b:=1) c2 lq0 t.lq (by positivity)
    simp only [one_mul] at nr
    have ns := increasing_gap (a:=K) (b:=p) c2 lq0 t.lq (by positivity)
    have u1:=le_up (by positivity : 0<K*C+p) (show K*C+p≤f.kh*f.ch+f.hi by gcongr <;> first | exact t.hk | exact t.hc | exact t.hp)
    have u2:=le_up (by positivity : 0<K*B+f.qlo) (show K*B+f.qlo≤f.kh*f.bh+f.qlo by gcongr <;> first | exact t.hk | exact t.hb)
    have u3:=le_up (by positivity : 0<K+p*f.qlo) (show K+p*f.qlo≤f.kh+f.hi*f.qlo by gcongr <;> first | exact t.hk | exact t.hp)
    unfold terms Frame.largest Frame.e1 Frame.e2 Frame.e3 Frame.yq
    push_cast
    exact max_le_max (by linarith only [norm,u1]) (max_le_max (by linarith only [nr,hp,yl,u2]) (by linarith only [ns,xp,yl,u3]))
  have drift : L (3*K*B*C)+2*L p+2*L q-16*(K-1:ℕ)≤f.drift := by
    have u:=le_up (by positivity : 0<3*K*B*C) (show 3*K*B*C≤3*f.kh*f.bh*f.ch by gcongr <;> first | exact t.hk | exact t.hb | exact t.hc)
    unfold Frame.drift;push_cast;linarith only [dg,hp,y,u]
  have ex : 0≤f.largest+up 3+f.dz := by
    apply Int.cast_le (R:=ℝ) |>.mp
    push_cast
    linarith only [m.exactInt,kmax,termle,(enclosed 3 (by decide)).2]
  have lim : 0 ≤ max f.largest f.drift+32 := by
    apply Int.cast_le (R:=ℝ) |>.mp
    push_cast
    linarith only [m.limiting,max_le_max termle drift]
  have pl : f.lo≤f.hi := t.lp.trans t.hp
  have qco : (f.cl-2:ℕ)*down f.qlo≤f.capY := by
    apply Int.cast_le (R:=ℝ) |>.mp
    push_cast;exact (mul_le_mul_of_nonneg_left dq (by positivity)).trans co
  have order : ((f.cl:ℤ)-f.bh-1)*down f.qlo≤f.cap := by
    apply Int.cast_le (R:=ℝ) |>.mp
    push_cast
    by_cases h : 0≤(f.cl:ℝ)-f.bh-1
    · exact (mul_le_mul_of_nonneg_left dq h).trans ord
    · have plus := t.rhs
      have c0:=nat_nonneg _ (by positivity : 0<3*K*B)
      nlinarith only [mul_nonpos_of_nonpos_of_nonneg (le_of_not_ge h) dqn,plus,c0,(Nat.cast_nonneg (α:=ℝ) K)]
  have qcut : down f.qlo≤f.y := by exact_mod_cast dq.trans y
  have cmp := comp_false kp bp cp t.lk t.hk t.lb t.hb t.hc qn hp y m.comp
  have swp := comp_false kp cp bp t.lk t.hk t.lc t.hc t.hb pn y hp m.revComp
  unfold Frame.reject
  rw [cmp,swp]
  simp only [Bool.or_false,decide_eq_false_iff_not]
  omega

theorem veto_false {p q a d k kl kh bl bh cl ch pl ph : ℕ}
    (hp : p.Prime) (hq : q.Prime) (op : 13≤p) (pq : p<q) (ha : 5≤a) (hd : 5≤d)
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ))
    (lk : kl≤k+1) (uk : k+1≤kh) (lb : bl≤a+1) (ub : a+1≤bh)
    (lc : cl≤d+1) (uc : d+1≤ch) (plp : pl≤p) (php : p≤ph) :
    veto kl kh bl bh cl ch pl ph=false := by
  unfold veto;split
  · rename_i cond
    obtain ⟨L,U,Q⟩:=prime_window hp hq op pq ha hd lk uk (by omega) lb plp php eqn
    have pos : 0<lowPrime kl bl pl := by dsimp [lowPrime];omega
    apply Fits.retain _ (model hp hq op pq ha hd eqn)
    exact ⟨cond.1,cond.2.1,cond.2.2,pos,lk,uk,lb,ub,lc,uc,L,U,Q,pq.le⟩
  · rfl

end OMA.OddBox245212
