import OddBoxLogRules245212
import OddBoxComplement245212
import OddBoxSeparation245212
import OddBoxPrime245212
import SimultaneousBound245212
import ComplementaryFar245212

/-! Necessary inequalities, before either exponent or prime is replaced
by a box endpoint. All quantities refer to the actual divisor equation. -/
namespace OMA.OddBox245212
open ArithmeticFunction
open scoped ArithmeticFunction.sigma

def rest (K B C p : ℕ) := 6*C*B*K*p^2
noncomputable def terms (K B C p q : ℕ) :=
  max (L (K*C+p)+2*L q-(B-1:ℕ)*L p)
    (max (2*L p+L (K*B+q)-(C-1:ℕ)*L q)
      (L (K+p*q)-(B-1:ℕ)*L p-(C-1:ℕ)*L q))

noncomputable def compLimit (K B C : ℕ) (x y : ℝ) :=
  L 3+max 0 (max (L (2*C*B*K)+2*x+(C-1:ℕ)*y)
    (L (6*C^2*B)+16+max (L K) x+2*(C-1:ℕ)*y))

structure Model (K B C p q : ℕ) : Prop where
  co : (C-2:ℕ)*L q≤16*K+L (3*K*B)+(B-1:ℕ)*L p
  rev : (B-2:ℕ)*L p≤16*K+L (3*K*C)+(C-1:ℕ)*L q
  level : 16*(K:ℝ)≤L (3*B*C)+(B-1:ℕ)*L p+(C-1:ℕ)*L q
  near : 16*K+L (2*C*K)≤(B-1:ℕ)*L p → L q≤16*K+L (rest K B C p)
  far : L (C*K*B*p)+32≤16*(K-1:ℕ) → L (C*K)+32≤(B-1:ℕ)*L p → L q≤L (rest K B C p)
  exactInt : 0≤L 3+16*K+terms K B C p q
  limiting : 0≤32+max (terms K B C p q) (L (3*K*B*C)+2*L p+2*L q-16*(K-1:ℕ))
  comp : 2*C+3≤B → 16*(K:ℝ)≤compLimit K B C (L p) (L q)
  revComp : 2*B+3≤C → 16*(K:ℝ)≤compLimit K C B (L q) (L p)

private theorem comp_log {K B C x y : ℕ} (k0 : 0<K) (b0 : 0<B) (c0 : 0<C) (x0 : 0<x) (y0 : 0<y)
    (ub : 2^K≤1+2*C*B*K*x^2*y^(C-1)+6*C^2*B*(K+x)*(y^(C-1))^2) :
    16*(K:ℝ)≤compLimit K B C (L x) (L y) := by
  let U:=2*C*B*K;let V:=6*C^2*B
  have u : 0<U := by dsimp [U];positivity
  have v : 0<V := by dsimp [V];positivity
  change 2^K≤1+U*x^2*y^(C-1)+V*(K+x)*(y^(C-1))^2 at ub
  have h := sum_three (by positivity) (by decide : 0<1) (by positivity) (by positivity) ub
  rw [lpow,ltwo,lone,lmul (a:=U*x^2) (by positivity) (by positivity),lmul u (by positivity),
    lmul (a:=V*(K+x)) (by positivity) (by positivity),lmul v (by positivity),lpow,lpow,lpow] at h
  have plus : L (K+x)≤16+max (L K) (L x) := by
    simpa only [L,Nat.cast_add] using max_sum (by exact_mod_cast k0 : 0<(K:ℝ)) (by exact_mod_cast x0 : 0<(x:ℝ))
  unfold compLimit
  simp only [lpow,Nat.cast_ofNat] at h
  rw [mul_comm (K:ℝ)] at h
  refine h.trans ?_
  simp only [U,V] at *
  exact add_le_add le_rfl (max_le_max le_rfl (max_le_max le_rfl (by nlinarith only [plus])))

private theorem cofactor_log {x y a d k : ℕ} (xp : 0<x) (yp : 0<y)
    (h : y^(d-1)≤3*2^(k+1)*(k+1)*(a+1)*x^a) :
    (d-1:ℕ)*L y≤16*(k+1:ℕ)+L (3*(k+1)*(a+1))+a*L x := by
  rw [show 3*2^(k+1)*(k+1)*(a+1)*x^a=2^(k+1)*(3*(k+1)*(a+1))*x^a by ring] at h
  have g:=lmono (by positivity) h
  rw [lmul (by positivity) (by positivity),lmul (by positivity) (by positivity),lpow,lpow,lpow,ltwo] at g
  linarith only [g]

private theorem exact_logs {p q K B C : ℕ} (p0 : 0<p) (q0 : 0<q) (k0 : 0<K) (b0 : 0<B) (c0 : 0<C)
    (first : p^(B-1)*q^(C-1)≤(2^K-1)*OMA.SimultaneousBound245212.error p q K B C (p^(B-1)) (q^(C-1)))
    (second : 4*(2^K-1)*(p^(B-1)*q^(C-1))≤4*(2^K-1)*OMA.SimultaneousBound245212.error p q K B C (p^(B-1)) (q^(C-1))+
      9*K*p^2*q^2*B*C*p^(B-1)*q^(C-1)) :
    0≤L 3+16*K+terms K B C p q ∧
    0≤32+max (terms K B C p q) (L (3*K*B*C)+2*L p+2*L q-16*(K-1:ℕ)) := by
  let P:=p^(B-1);let Q:=q^(C-1);let G:=2^K-1
  let A:=(K*C+p)*q^2*Q;let D:=p^2*(K*B+q)*P;let E:=K+p*q;let H:=3*K*B*C
  have pp : 0<P := pow_pos p0 _
  have qq : 0<Q := pow_pos q0 _
  have gp : 0<G := by dsimp [G]; have:=Nat.one_lt_pow (by omega : K≠0) (by decide : 1<(2:ℕ));omega
  have ap : 0<A := by dsimp [A];positivity
  have dp : 0<D := by dsimp [D];positivity
  have ep : 0<E := by dsimp [E];positivity
  have hp : 0<H := by dsimp [H];positivity
  have err : OMA.SimultaneousBound245212.error p q K B C P Q=A+D+E := by
    dsimp [OMA.SimultaneousBound245212.error,A,D,E];ring
  change P*Q≤G*OMA.SimultaneousBound245212.error p q K B C P Q at first
  change 4*G*(P*Q)≤4*G*OMA.SimultaneousBound245212.error p q K B C P Q+9*K*p^2*q^2*B*C*P*Q at second
  rw [err] at first second
  have second' : G*P*Q≤G*A+G*D+G*E+H*p^2*q^2*P*Q := by
    dsimp [H];nlinarith only [second,Nat.zero_le (K*p^2*q^2*B*C*P*Q)]
  have fst : L (P*Q)≤L 3+max (L (G*A)) (max (L (G*D)) (L (G*E))) := by
    apply sum_three <;> first | positivity | nlinarith only [first]
  have snd := sum_four (by positivity) (by positivity) (by positivity) (by positivity) (by positivity) second'
  have gmax : L G≤K*16 := by simpa only [lpow,ltwo] using lmono gp (Nat.sub_le (2^K) 1)
  have gmin : (K-1:ℕ)*16≤L G := by
    have tw : 0<(2:ℕ)^(K-1) := by positivity
    have sm : 2^(K-1)≤G := by dsimp [G];have:=pow_succ (2:ℕ) (K-1);rw [Nat.sub_add_cancel k0] at this;omega
    simpa only [lpow,ltwo] using lmono tw sm
  dsimp only [A,D,E] at fst snd
  simp (disch:=positivity) only [lmul,lpow,Nat.cast_ofNat] at fst snd
  dsimp [P,Q] at fst snd
  simp only [lpow] at fst snd
  dsimp only [H] at snd
  let t:=terms K B C p q
  let lp:=(B-1:ℕ)*L p
  let lq:=(C-1:ℕ)*L q
  have t1 : L (K*C+p)+2*L q-lp≤t := le_max_left _ _
  have t2 : 2*L p+L (K*B+q)-lq≤t := (le_max_left _ _).trans (le_max_right _ _)
  have t3 : L (K+p*q)-lp-lq≤t := (le_max_right _ _).trans (le_max_right _ _)
  have cap : max (L G+(L (K*C+p)+2*L q+lq))
      (max (L G+(2*L p+L (K*B+q)+lp)) (L G+L (K+p*q))) ≤ L G+lp+lq+t := by
    exact max_le (by linarith only [t1]) (max_le (by linarith only [t2]) (by linarith only [t3]))
  change lp+lq ≤ L 3+_ at fst
  change L G+lp+lq ≤ 32+_ at snd
  constructor
  · change 0≤L 3+16*K+t
    linarith only [fst,cap,gmax]
  · let h:=L (3*K*B*C)+2*L p+2*L q-16*(K-1:ℕ)
    have th : t ≤ max t h := le_max_left _ _
    have hh : h ≤ max t h := le_max_right _ _
    change 0≤32+max t h
    have all := max_le (cap.trans (by linarith only [th] : L G+lp+lq+t≤L G+lp+lq+max t h))
      (show L (3*K*B*C)+2*L p+2*L q+lp+lq≤L G+lp+lq+max t h by dsimp only [h] at hh;linarith only [gmin,hh])
    linarith only [snd,all]

theorem model {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 13≤p) (pq : p<q)
    (ha : 5≤a) (hd : 5≤d) (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) :
    Model (k+1) (a+1) (d+1) p q := by
  let K:=k+1;let B:=a+1;let C:=d+1
  have k0 : 0<K := Nat.succ_pos _
  have b0 : 0<B := Nat.succ_pos _
  have c0 : 0<C := Nat.succ_pos _
  have p0:=hp.pos;have q0:=hq.pos
  have flip : OeisA245212.a (2^k*q^d*p^a)=(σ 1 (2^k*q^d*p^a):ℤ) := by rwa [mul_right_comm]
  have a2 : B-2=a-1 := by dsimp [B];omega
  have d2 : C-2=d-1 := by dsimp [C];omega
  have a1 : B-1=a := Nat.add_sub_cancel _ _
  have d1 : C-1=d := Nat.add_sub_cancel _ _
  have k1 : K-1=k := Nat.add_sub_cancel _ _
  have lx := OMA.TwoOddParameters245212.cofactor hp hq (by omega) (by omega) pq.ne (by omega) eqn
  have ly := OMA.TwoOddParameters245212.cofactor hq hp (by omega) (by omega) pq.ne.symm (by omega) flip
  have zc := OMA.ComplementaryDyad245212.level hp hq (by omega) (by omega) pq.ne (by omega) eqn
  change 2^K≤3*C*B*p^a*q^d at zc
  rw [show 3*C*B=3*B*C by ring] at zc
  have zl := lmono (by positivity : 0<(2:ℕ)^K) zc
  rw [lmul (a:=3*B*C*p^a) (by positivity) (by positivity),lmul (a:=3*B*C) (by positivity) (by positivity),
    lpow,lpow,lpow,ltwo] at zl
  have pb := prime_bound hp hq op pq ha hd eqn
  have kd := Nat.mul_le_mul_left k hd
  have sm : p-1<k*d := by omega
  have sm' : (p:ℤ)-1<(k:ℤ)*d := by zify [Nat.cast_sub hp.pos] at sm;exact sm
  have sep := separations hp hq (by omega) pq (by omega) (by omega) (by omega) sm' eqn
  obtain ⟨fi,se⟩ := OMA.SimultaneousBound245212.of_separations hp hq (by omega) (by omega) pq.ne eqn sep.1 sep.2
  have er := exact_logs (K:=K) (B:=B) (C:=C) p0 q0 k0 b0 c0 (by rw [a1,d1];exact fi)
    (by rw [a1,d1];simpa only [Nat.mul_assoc] using se)
  change Model K B C p q
  refine ⟨?_,?_,?_,?_,?_,er.1,er.2,?_,?_⟩
  · rw [d2,a1];exact cofactor_log p0 q0 lx
  · rw [a2,d1];exact cofactor_log q0 p0 ly
  · rw [a1,d1];linarith only [zl]
  · rw [a1]
    intro pole
    obtain ⟨s,succ⟩:=Nat.exists_eq_succ_of_ne_zero (by omega : d≠0)
    have raw := OMA.ComplementaryPole245212.alternative hp hq (by omega) (by omega) pq.ne a s k (by omega) (by simpa [succ] using eqn)
    change p^a≤2*2^K*(s+2)*K ∨ q≤6*(s+2)*K*B*2^K*p^2 at raw
    have Cs : C=s+2 := by dsimp [C];omega
    rw [←Cs] at raw
    have poles : 2^K*(2*C*K)≤p^a := (lreflect (by positivity) (by positivity)).mp (by
      rw [lmul (by positivity) (by positivity),lpow,lpow,ltwo];linarith only [pole])
    rcases raw with le|qt
    · have equal : p^a=2*(2^K*C*K) := by nlinarith only [le,poles]
      obtain ⟨i,hi⟩ := (hp.odd_of_ne_two (by omega)).pow (n:=a)
      omega
    · have qt' : q≤2^K*rest K B C p := by dsimp [rest];nlinarith only [qt]
      have tmp := lmono q0 qt'
      rw [lmul (by positivity) (by dsimp [rest];positivity),lpow,ltwo] at tmp
      linarith only [tmp]
  · rw [a1,k1];intro first second
    have g : 4*(C*K*B*p)≤2^k := (lreflect (by positivity) (by positivity)).mp (by
      rw [lmul (by decide) (by positivity),lfour,lpow,ltwo];linarith only [first])
    have s : 4*(C*K)≤p^a := (lreflect (by positivity) (by positivity)).mp (by
      rw [lmul (by decide) (by positivity),lfour,lpow];linarith only [second])
    have longer : 2^k<2^K := by dsimp [K];rw [pow_succ];have:=Nat.two_pow_pos k;omega
    have qcap := OMA.ComplementaryFar245212.far hp hq (by omega) (by omega) pq.ne (by omega) (by omega) eqn
      (by change 4*K*C*B*p<2^K;nlinarith only [g,longer]) (by change 4*C*K≤p^a;nlinarith only [s])
    apply lmono q0
    dsimp [rest,K,B,C];nlinarith only [qcap]
  · intro med
    apply comp_log k0 b0 c0 p0 q0
    rw [d1];apply complement hp hq (by omega) (by omega) pq.ne (by omega) (by dsimp [C,B] at med;omega) eqn
  · intro med
    apply comp_log k0 c0 b0 q0 p0
    rw [a1];apply complement hq hp (by omega) (by omega) pq.ne.symm (by omega) (by dsimp [C,B] at med;omega) flip

end OMA.OddBox245212
