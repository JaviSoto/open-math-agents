import PairSweep245212

/-! Sound finite replay for both free odd primes. Each rectangular slice
checks the last base via a single leading-digit division; the actual
prime bases outside the cofactor are never truncated. -/
namespace OMA.RankTwoReplay245212
open Nat ArithmeticFunction OMA.Smooth245212 OMA.Large245212 OMA.LastDigit245212
open scoped ArithmeticFunction.sigma
open private OMA.Large245212.force from LargeExact245212
open private OMA.PairExtension245212.fit from PairExtension245212
open private OMA.PairSweep245212.run_true from PairSweep245212

def excluded (p f A S T : ℕ) : Bool :=
  let D := denom A S T f
  if D=0 then true else
  let q := candidate A S T f
  decide (q≤p) || !OMA.PairExtension245212.permitted A S T q f

theorem leaf {k p e q f : ℕ} (hp : p.Prime) (po : 2<p) (hq : q.Prime) (pq : p<q)
    (fp : 0<f) (ok : OMA.PairSweep245212.run (excluded p f) k p e=true) :
    OeisA245212.a (2^k*p^e*q^f)≠(σ 1 (2^k*p^e*q^f):ℤ) := by
  intro eq
  let b := 2^k*p^e
  have bp : 0<b := by dsimp [b]; have := hp.pos; positivity
  have cop : b.Coprime q :=
    (((Nat.coprime_primes prime_two hq).mpr (by omega)).pow_left k).mul_left
      (((Nat.coprime_primes hp hq).mpr pq.ne).pow_left e)
  obtain ⟨pos,low,high,_⟩ := balance_digits bp hq cop fp eq
  have value := OMA.Large245212.force (sigma_pos 1 b bp.ne') hq.one_lt pos low high
  have r := OMA.PairSweep245212.run_true hp po _ ok
  change excluded p f (W b) (σ 1 b) (b*(σ 0 b))=true at r
  simp [excluded,pos.ne',value,not_le_of_gt pq,OMA.PairExtension245212.fit bp hq cop fp eq] at r

def allIn (lo hi : ℕ) (f : ℕ → Bool) : Bool :=
  (List.range' lo (hi+1-lo)).all f

private theorem member {lo hi n : ℕ} {f : ℕ → Bool} (h : allIn lo hi f=true)
    (l : lo≤n) (u : n≤hi) : f n=true :=
  List.all_eq_true.mp h n (List.mem_range'_1.mpr ⟨l,by omega⟩)

/-- k=powers of two's exponent; e, f are the odd exponents (not lengths). -/
def slice (kl kh pl ph el eh fl fh : ℕ) : Bool :=
  allIn pl ph fun p => !decide p.Prime || allIn kl kh fun k =>
    let w := wt 2 k
    let s := sig 2 k
    let t := OMA.Large245212.tax 2 k
    allIn el eh fun e =>
      let a := w*wt p e
      let o := s*sig p e
      let u := t*OMA.Large245212.tax p e
      allIn fl fh fun f => excluded p f a o u

theorem of_slice {kl kh pl ph el eh fl fh k p e q f : ℕ}
    (hp : p.Prime) (po : 2<p) (hq : q.Prime) (pq : p<q) (fp : 0<f)
    (p₀ : pl≤p) (p₁ : p≤ph) (k₀ : kl≤k) (k₁ : k≤kh)
    (e₀ : el≤e) (e₁ : e≤eh) (f₀ : fl≤f) (f₁ : f≤fh)
    (ok : slice kl kh pl ph el eh fl fh=true) :
    OeisA245212.a (2^k*p^e*q^f)≠(σ 1 (2^k*p^e*q^f):ℤ) := by
  have base := member ok p₀ p₁
  simp only [hp,decide_true,Bool.not_true,Bool.false_or] at base
  have row := member base k₀ k₁
  have exp := member row e₀ e₁
  have point := member exp f₀ f₁
  exact leaf hp po hq pq fp point

#print axioms of_slice
end OMA.RankTwoReplay245212
