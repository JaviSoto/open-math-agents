import SimultaneousBound245212

/-! Compare integer defect errors against the scalar cell tests, with
no approximations to the prime powers. -/
namespace OMA.TwoOddErrorCells245212
open OMA.SimultaneousBound245212

/-- Lower-cofactor and ordered prime-power comparisons reduce the exact
dyadic defect to three scalar alternatives. -/
theorem alternatives {p q K B C P Q G R h u : ℕ}
    (rpos : 0<R) (rP : R≤P) (rQ : R≤Q) (qR : q*R≤h*Q) (ph : p≤h) (bu : B≤u) (cu : C≤u)
    (necessary : P*Q≤G*error p q K B C P Q) :
    P≤3*G*(K*u+h)*q^2 ∨ R≤3*G*h^2*(K*u+h) ∨ R^2≤3*G*(K+h^2) := by
  by_contra! no
  have A : 3*G*q^2*(K*C+p)<P := calc
    _ ≤ 3*G*q^2*(K*u+h) := by gcongr
    _ = _ := by ring
    _ < _ := no.1
  have second : 3*G*p^2*(K*B+q)<Q := by
    apply (mul_lt_mul_iff_left₀ rpos).mp
    calc
      _ = 3*G*p^2*(K*B*R+q*R) := by ring
      _ ≤ 3*G*h^2*(K*u*Q+h*Q) := by gcongr
      _ = (3*G*h^2*(K*u+h))*Q := by ring
      _ < R*Q := Nat.mul_lt_mul_of_pos_right no.2.1 (lt_of_lt_of_le rpos rQ)
      _ = _ := by ring
  have third : 3*G*(K+p*q)<P*Q := by
    apply (mul_lt_mul_iff_left₀ rpos).mp
    calc
      _ = 3*G*(K*R+p*(q*R)) := by ring
      _ ≤ 3*G*(K*Q+h*(h*Q)) := by gcongr
      _ = 3*G*(K+h^2)*Q := by ring
      _ < R^2*Q := Nat.mul_lt_mul_of_pos_right no.2.2 (lt_of_lt_of_le rpos rQ)
      _ ≤ (P*Q)*R := by nlinarith only [Nat.mul_le_mul_right (R*Q) rP]
  unfold error at necessary
  nlinarith only [necessary,Nat.mul_lt_mul_of_pos_right A (rpos.trans_le rQ),
    Nat.mul_lt_mul_of_pos_right second (rpos.trans_le rP),third]

/-- A scalar power comparison eliminates the first of the alternatives. -/
theorem first_excluded {m G K u h q R P v : ℕ} (hm : 4 ≤ m) (rP : R≤P) (pp : 0<P)
    (qcap : q^(m-2)≤v*P)
    (test : (3*G*(K*u+h))^(m-2)*v^2<R^(m-4)) :
    3*G*(K*u+h)*q^2<P := by
  let a:=3*G*(K*u+h)
  change a^(m-2)*v^2<R^(m-4) at test
  change a*q^2<P
  apply lt_of_not_ge
  intro bad
  have hw := Nat.pow_le_pow_left bad (m-2)
  rw [mul_pow,←pow_mul,mul_comm 2 (m-2),pow_mul] at hw
  have qq := Nat.pow_le_pow_left qcap 2
  rw [mul_pow] at qq
  have big := hw.trans (Nat.mul_le_mul_left (a^(m-2)) qq)
  have tight := Nat.mul_lt_mul_of_pos_right (test.trans_le (Nat.pow_le_pow_left rP (m-4)))
    (pow_pos pp 2)
  rw [←pow_add,show m-4+2=m-2 by omega] at tight
  rw [←mul_assoc] at big
  exact (not_lt_of_ge big) tight

/-- The integer-dyadic obstruction after bounding q itself. -/
theorem second_excluded {p q K B C P Q G R h y u t : ℕ} (rpos : 0<R) (rP : R≤P) (rQ : R≤Q)
    (ph : p≤h) (qy : q≤y) (bu : B≤u) (cu : C≤u) (prod : B*C≤t)
    (necessary : 4*G*P*Q≤4*G*error p q K B C P Q+9*K*p^2*q^2*B*C*P*Q)
    (test : 4*G*((y^2*(K*u+h)+h^2*(K*u+y))*R+(K+h*y))+
      9*K*h^2*y^2*t*R^2 < 4*G*R^2) : False := by
  let a:=y^2*(K*u+h)
  let b:=h^2*(K*u+y)
  let c:=K+h*y
  have aa : q^2*(K*C+p)≤a := by dsimp [a];gcongr
  have bb : p^2*(K*B+q)≤b := by dsimp [b];gcongr
  have cc : K+p*q≤c := by dsimp [c];gcongr
  have re : R^2*error p q K B C P Q≤((a+b)*R+c)*(P*Q) := by
    have lo1 := Nat.mul_le_mul aa (Nat.mul_le_mul_right (R*Q) rP)
    have lo2 := Nat.mul_le_mul bb (Nat.mul_le_mul_right (R*P) rQ)
    have lo3 := Nat.mul_le_mul cc (Nat.mul_le_mul rP rQ)
    dsimp [error];nlinarith only [lo1,lo2,lo3]
  have tr : 9*K*p^2*q^2*B*C≤9*K*h^2*y^2*t := calc
    _ = 9*K*p^2*q^2*(B*C) := by ring
    _ ≤ _ := by gcongr
  change 4*G*((a+b)*R+c)+9*K*h^2*y^2*t*R^2<4*G*R^2 at test
  have cmp := Nat.mul_lt_mul_of_pos_right test (Nat.mul_pos (rpos.trans_le rP) (rpos.trans_le rQ))
  nlinarith only [cmp,Nat.mul_le_mul_left (R^2) necessary,Nat.mul_le_mul_left (4*G) re,
    Nat.mul_le_mul_right (P*Q*R^2) tr]

end OMA.TwoOddErrorCells245212
