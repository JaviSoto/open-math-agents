import ComplementaryLocal245212
import ComplementaryPole245212

/-! A least-prime bound retaining the deficit in each weighted
prime-power divisor sum. It applies without lower bounds on the primes
beyond oddness and does not require many odd divisors. -/
namespace OMA.SmallLeast245212
open ArithmeticFunction OMA.Smooth245212 OMA.ComplementaryLocal245212 OMA.ComplementaryPole245212
open scoped ArithmeticFunction.sigma

private theorem local_upper {p : ℕ} (hp : p.Prime) (op : 3≤p) (a : ℕ) {r : ℤ}
    (rp : r≤p) :
    (r-1)*(σ 1 (p^a):ℤ) ≤ r*p^a ∧
    (r-1)*(W (p^a):ℤ) ≤ (((a:ℤ)+1)*r-1)*p^a := by
  let P:ℤ:=(p:ℤ)^a
  let S:ℤ:=σ 1 (p^a)
  let V:ℤ:=W (p^a)
  let b:ℤ:=(a:ℤ)+1
  have geo : ((p:ℤ)-1)*S=p*P-1 := (moments hp a).1
  have w := OMA.PrimePowerDiv245212.weighted hp a
  zify [Nat.cast_sub hp.pos] at w
  change ((p:ℤ)-1)*V+S=p*(b*P) at w
  have positive : 0<P := pow_pos (by omega : (0:ℤ)<p) a
  have sl : P≤S := by
    apply (mul_le_mul_iff_right₀ (by omega : 0<(p:ℤ)-1)).mp
    nlinarith only [geo,positive]
  have wl : b*P≤V := by dsimp [b,P,V];exact_mod_cast (bounds hp op a).2.2.1
  change (r-1)*S≤r*P ∧ (r-1)*V≤(b*r-1)*P
  constructor
  · nlinarith only [geo,mul_nonneg (sub_nonneg.mpr rp) (sub_nonneg.mpr sl)]
  · nlinarith only [w,sl,mul_nonneg (sub_nonneg.mpr rp) (sub_nonneg.mpr wl)]

private theorem scalar {r b h m K F G : ℤ} (rr : 1≤r) (bb : 1≤b) (hh : 1≤h)
    (mm : 1 ≤ m) (mb : m≤b) (kk : 0≤K) (gg : 0<G) (fk : F≤K*G)
    (eqn : (F+G)*b*h*(r-1)^2 ≤ F*(b*r-1)*(h*r-1)+G*r^2) :
    (m*h-1)*r ≤ m*(2*h+K*(2*h-1)) := by
  have diff : 0 ≤ (b*r-1)*(h*r-1)-b*h*(r-1)^2 := by
    have u:=mul_le_mul (show b*(r-1)≤b*r-1 by nlinarith only [bb])
      (show h*(r-1)≤h*r-1 by nlinarith only [hh])
      (mul_nonneg (by omega) (by omega)) (by nlinarith only [mul_nonneg (by omega : 0≤b) (by omega : 0≤r-1),bb])
    nlinarith only [u]
  have limit : b*h*(r-1)^2-r^2 ≤ K*((b*r-1)*(h*r-1)-b*h*(r-1)^2) := by
    apply (mul_le_mul_iff_right₀ gg).mp
    nlinarith only [eqn,mul_le_mul_of_nonneg_right fk diff]
  have large : (b*h-1)*r ≤ b*(2*h+K*(2*h-1)) := by
    apply (mul_le_mul_iff_left₀ (by omega : 0<r)).mp
    have bh : 1≤b*h := by nlinarith only [mul_nonneg (show 0≤b-1 by omega) (show 0≤h-1 by omega),bb,hh]
    nlinarith only [limit, mul_nonneg kk (by omega : 0≤b*h-1),
      mul_nonneg (mul_nonneg kk (by omega : 0≤h)) (by omega : 0≤r),bh]
  apply (mul_le_mul_iff_right₀ (by omega : 0<b)).mp
  nlinarith only [mul_le_mul_of_nonneg_left large (by omega : 0 ≤ m),
    mul_nonneg (sub_nonneg.mpr mb) (by omega : 0≤r)]

theorem bound {p q a d k M : ℕ} (hp : p.Prime) (hq : q.Prime)
    (op : 3≤p) (oq : 3≤q) (pq : p≠q) (mh : 1≤M) (mb : M≤a+1)
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) :
    (M*(d+1)-1)*min p q ≤ M*(2*(d+1)+(k+1)*(2*(d+1)-1)) := by
  let r:ℤ:=min p q
  let b:ℤ:=(a:ℤ)+1
  let h:ℤ:=(d:ℤ)+1
  let P:ℤ:=(p:ℤ)^a
  let Q:ℤ:=(q:ℤ)^d
  have rr : 3≤r := by dsimp [r];exact_mod_cast le_min op oq
  have r₁ : r≤p := by dsimp [r];exact_mod_cast min_le_left p q
  have r₂ : r≤q := by dsimp [r];exact_mod_cast min_le_right p q
  have up:=local_upper hp op a r₁
  have uq:=local_upper hq oq d r₂
  have gp := (dyad k).1
  have fp := (dyad k).2.1
  have Ppos : 0<P := pow_pos (by omega : (0:ℤ)<p) _
  have Qpos : 0<Q := pow_pos (by omega : (0:ℤ)<q) _
  have b1 : 1≤b := by dsimp [b];omega
  have h1 : 1≤h := by dsimp [h];omega
  have wu := mul_le_mul up.2 uq.2 (mul_nonneg (by omega) (by positivity))
    (mul_nonneg (by nlinarith only [mul_nonneg (by omega : 0≤b) (by omega : 0≤r-1),b1] : 0≤b*r-1) Ppos.le)
  have su := mul_le_mul up.1 uq.1 (mul_nonneg (by omega) (by positivity)) (mul_nonneg (by omega : 0≤r) Ppos.le)
  have phy := physical hp hq (by omega) (by omega) pq a d k eqn
  change F k*_*_+G k*_*_=z k*(k+1)*b*h*P*Q at phy
  rw [←(dyad k).2.2.2] at phy
  have ratio : (F k+G k)*b*h*(r-1)^2 ≤ F k*(b*r-1)*(h*r-1)+G k*r^2 := by
    apply (mul_le_mul_iff_left₀ (mul_pos Ppos Qpos)).mp
    change (r-1)*_*((r-1)*_) ≤ ((b*r-1)*P)*((h*r-1)*Q) at wu
    change (r-1)*_*((r-1)*_) ≤ (r*P)*(r*Q) at su
    nlinarith only [congrArg (fun x:ℤ=>x*(r-1)^2) phy,
      mul_le_mul_of_nonneg_left wu fp.le,mul_le_mul_of_nonneg_left su gp.le]
  have ans := scalar (by omega : 1≤r) b1 h1 (by exact_mod_cast mh : (1:ℤ)≤M)
    (by dsimp [b];exact_mod_cast mb) (by positivity : (0:ℤ)≤k+1) gp (dyad k).2.2.1 ratio
  dsimp [b,h,r] at ans
  zify [show 1≤M*(d+1) by nlinarith only [mh,Nat.zero_le (M*d)],show 1≤2*(d+1) by omega]
  exact ans

end OMA.SmallLeast245212
