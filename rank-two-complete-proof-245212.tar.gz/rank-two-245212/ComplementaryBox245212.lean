import ComplementaryDyad245212
import ComplementaryFar245212
import ComplementaryExp245212

/-! When the dyadic power is above the cutoff, both prime bases lie in
an explicit box of degree d+2 in the dyadic exponent. -/
namespace OMA.ComplementaryBox245212
open scoped ArithmeticFunction.sigma

theorem room (d : ℕ) :
    10000*(d+1)^4*5^d≤2^(16*(d+1)^2) := by
  by_cases hd : d=0
  · subst d;decide
  have h : d+1≤2^(d+1) := (Nat.lt_pow_self (by decide : 1<2)).le
  have f : 5^d≤(2^3)^d := Nat.pow_le_pow_left (by decide) d
  have full := Nat.mul_le_mul (Nat.mul_le_mul (show 10000≤(2:ℕ)^14 by decide)
    (Nat.pow_le_pow_left h 4)) f
  rw [←pow_mul,←pow_mul,←pow_add,←pow_add] at full
  exact full.trans (Nat.pow_le_pow_right (by decide) (by nlinarith only [show 1≤d by omega,Nat.zero_le (d^2)]))

theorem box {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 3≤p) (oq : 3≤q) (pq : p≠q)
    (ha : 2≤a) (hd : 2≤d)
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ))
    (large : (2^(16*(d+1)^2)*(k+1)^(d+3))^(d+1)<2^(k+1)) :
    let B:=2^(16*(d+1)^2)*(k+1)^(d+2)
    p≤B ∧ q≤B ∧ a+1≤B ∧ k+1≤B := by
  let h:=d+1
  let K:=k+1
  let b:=a+1
  let E:ℕ:=2^(16*h^2)
  let B:=E*K^(d+2)
  let D:=E*K^(d+3)
  change p≤B ∧ q≤B ∧ b≤B ∧ K≤B
  change D^h<2^K at large
  have hK : 1≤K := by dsimp [K];omega
  have hh : 3≤h := by dsimp [h];omega
  have he : 1≤E := Nat.one_le_pow _ _ (by decide)
  have hD : 1≤D := Nat.mul_pos he (Nat.one_le_pow _ _ hK)
  have pr : D<2^K := (show D≤D^h by simpa using
    (Nat.pow_le_pow_right hD (show 1≤h by omega))).trans_lt large
  have BD : B≤D := Nat.mul_le_mul_left _ (Nat.pow_le_pow_right hK (by omega))
  have hb : b≤64*h^2*K := OMA.ComplementaryExp245212.exponent hp hq op oq pq (by omega) eqn
  have room' : 10000*h^4*5^d≤E := room d
  have h34 : h^3≤h^4 := Nat.pow_le_pow_right (by omega) (by decide)
  have h24 : h^2≤h^4 := Nat.pow_le_pow_right (by omega) (by decide)
  have h₄ : 10000*h^4≤E := (show 10000*h^4≤10000*h^4*5^d by
    simpa using (Nat.mul_le_mul_left (10000*h^4) (Nat.one_le_pow d 5 (by decide)))).trans room'
  have c₃ {x : ℕ} (hx : x≤10000) : x*h^3≤E := (Nat.mul_le_mul hx h34).trans h₄
  have cov {v w : ℕ} (u : v≤E) (g : w≤d+2) : v*K^w≤B :=
    Nat.mul_le_mul u (Nat.pow_le_pow_right hK g)
  have ek : 5*K≤B := by
    have five : 5≤E := (show 5≤10000*h^4 from (show 5≤10000*1 by decide).trans
      (Nat.mul_le_mul_left _ (Nat.one_le_pow _ _ (by omega)))).trans h₄
    simpa using (cov five (show 1≤d+2 by omega))
  have bB : b≤B := hb.trans (by
    simpa using cov ((Nat.mul_le_mul (show 64≤10000 by decide) h24).trans h₄) (show 1≤d+2 by omega))
  have many : 5≤(a+1)*(d+1) := by nlinarith only [ha,hd,Nat.zero_le (a*d)]
  have bases := OMA.ComplementaryBase245212.small_prime hp hq op oq pq many eqn
  change p≤5*K ∨ q≤5*K at bases
  refine ⟨?_,?_,bB,(show K≤5*K by omega).trans ek⟩
  · rcases bases with h | hqK
    · exact h.trans ek
    have grow : 6*b*K*h*q^d≤B := calc
      _ ≤ 6*(64*h^2*K)*K*h*(5*K)^d := by gcongr
      _ = (384*h^3*5^d)*K^(d+2) := by rw [mul_pow,pow_add (m:=d) (n:=2)];ring
      _ ≤ _ := cov ((Nat.mul_le_mul_right _ (Nat.mul_le_mul (show 384≤10000 by decide) h34)).trans room') (by omega)
    have cut : K*(a+1)*(d+1)*q^d<2^K := by
      change K*b*h*q^d<2^K
      exact (show K*b*h*q^d≤6*b*K*h*q^d by nlinarith only [Nat.zero_le (b*K*h*q^d)]).trans_lt
        (grow.trans_lt (BD.trans_lt pr))
    have swap : OeisA245212.a (2^k*q^d*p^a)=(σ 1 (2^k*q^d*p^a):ℤ) := by
      rwa [mul_right_comm]
    exact (OMA.ComplementaryDyad245212.near hq hp oq op pq.symm (by omega) swap cut).trans grow
  · rcases bases with hpK | h
    · have gc : 4*K*h*b*p<2^K := calc
        _ ≤ 4*K*h*(64*h^2*K)*(5*K) := by gcongr
        _ = (1280*h^3)*K^3 := by ring
        _ ≤ B := cov (c₃ (by decide)) (by omega)
        _ < _ := BD.trans_lt pr
      have pc : 4*h*K≤p^a := by
        by_contra! smaller
        have low := OMA.ComplementaryDyad245212.power_floor hp hq op oq pq (by omega) eqn
        change 2^K≤(6*h*K*b*p^a)^h at low
        have scale : 6*h*K*b*p^a≤D := calc
          _ ≤ 6*h*K*(64*h^2*K)*(4*h*K) := by gcongr
          _ = (1536*h^4)*K^3 := by ring
          _ ≤ B := cov ((Nat.mul_le_mul_right _ (show 1536≤10000 by decide)).trans h₄) (by omega)
          _ ≤ D := BD
        exact (not_lt_of_ge (low.trans (Nat.pow_le_pow_left scale h))) large
      apply (OMA.ComplementaryFar245212.far hp hq op oq pq ha (by omega) eqn gc pc).trans
      change 6*h*K*b*p^2≤B
      calc
        _ ≤ 6*h*K*(64*h^2*K)*(5*K)^2 := by gcongr
        _ = (9600*h^3)*K^4 := by ring
        _ ≤ _ := cov (c₃ (by decide)) (by omega)
    · exact h.trans ek

end OMA.ComplementaryBox245212
