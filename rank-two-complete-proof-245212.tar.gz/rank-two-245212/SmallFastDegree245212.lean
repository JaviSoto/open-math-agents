import SmallFastReplay245212

/-! Cover just the primes admitted by the least-prime bound. -/
namespace OMA.SmallFastDegree245212
open OMA.SmallCaps245212 OMA.SmallFastReplay245212
open scoped ArithmeticFunction.sigma

def lastPrime (d : ℕ) (f v : Bool) :=
  let m:=OMA.SmallReplay245212.first d f+1
  m*(2*(d+1)+ceiling d f v*(2*(d+1)-1))/(m*(d+1)-1)

def Checked (d : ℕ) (f v : Bool) : Prop :=
  ∀ j : ℕ, j≤(lastPrime d f v-3)/32 → stripe d f v (3+32*j) (34+32*j)=true

theorem of_tables {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 3≤p)
    (oq : 3≤q) (pq : p≠q) (hd : 2≤d) (ed : d≤4) (order : d≤a)
    (tables : ∀ f v, Checked d f v) :
    OeisA245212.a (2^k*p^a*q^d)≠(σ 1 (2^k*p^a*q^d):ℤ) := by
  intro eqn
  let f:=decide (a<2*d+4)
  let v:=decide (q<p)
  let b:=OMA.SmallReplay245212.first d f
  have ba : b≤a := by by_cases c : a<2*d+4 <;> simp [b,OMA.SmallReplay245212.first,f,c] <;> omega
  have dy : k+1≤ceiling d f v := OMA.SmallCaps245212.dyadic hp hq op oq pq hd ed order eqn
  have sep := OMA.SmallLeast245212.bound hp hq op oq pq (Nat.succ_pos b) (Nat.add_le_add_right ba 1) eqn
  have factor : 2≤(b+1)*(d+1) := by nlinarith only [hd,Nat.zero_le b,Nat.zero_le (b*d)]
  have pos : 0<(b+1)*(d+1)-1 := by omega
  have upper : min p q≤lastPrime d f v := by
    apply (Nat.le_div_iff_mul_le pos).mpr
    rw [Nat.mul_comm]
    exact sep.trans (Nat.mul_le_mul_left _ (Nat.add_le_add_left (Nat.mul_le_mul_right _ dy) _))
  let j:=(min p q-3)/32
  have size : j≤(lastPrime d f v-3)/32 := by dsimp [j];omega
  have lb : 3+32*j ≤ min p q := by dsimp [j];omega
  have ub : min p q≤34+32*j := by dsimp [j];omega
  exact use_stripe hp hq op oq pq hd ed order lb ub (tables f v j size) eqn

end OMA.SmallFastDegree245212
