import TwoOddErrorCells245212

/-! Coarse growth inequality obtained from the three positive-error
alternatives before splitting the dyadic exponent into ranges. -/
namespace OMA.TwoOddCoarse245212
open OMA.SimultaneousBound245212 OMA.TwoOddErrorCells245212

theorem coarse {p q K B C P Q G R m u : ℕ} (hK : 1≤K) (hu : 1≤u)
    (rpos : 0<R) (rP : R≤P) (rQ : R≤Q) (qR : q*R≤(5*K)*Q) (ph : p≤5*K)
    (bu : B≤u) (cu : C≤u) (uB : u≤64*m^2*K) (gz : G≤2^K)
    (necessary : P*Q≤G*error p q K B C P Q) (fourth : q^4≤3*2^K*K*u*P) :
    R≤2^(37+3*K)*K^10*m^8 := by
  let z:ℕ:=2^K
  change q^4≤3*z*K*u*P at fourth
  have zp : 1≤z := Nat.one_le_pow _ _ (by decide)
  have KK : K*u+5*K≤6*K*u := by nlinarith only [Nat.mul_le_mul_left K hu]
  have target : R≤6400*z^3*K^6*u^4 := by
    rcases alternatives rpos rP rQ qR ph bu cu necessary with x|x|x
    · have w : P≤3*z*(6*K*u)*q^2 := x.trans (by gcongr)
      have sq := Nat.pow_le_pow_left w 2
      simp only [mul_pow] at sq
      rw [←pow_mul q 2 2] at sq
      have sq' := sq.trans (Nat.mul_le_mul_left _ fourth)
      have shrink : P≤972*z^3*K^3*u^3 := by
        apply (mul_le_mul_iff_left₀ (rpos.trans_le rP)).mp
        nlinarith only [sq']
      have gain := Nat.mul_le_mul (Nat.pow_le_pow_right hK (show 3≤6 by decide))
        (Nat.pow_le_pow_right hu (show 3≤4 by decide))
      have gain' := Nat.mul_le_mul (Nat.mul_le_mul_right (z^3) (show 972≤6400 by decide)) gain
      exact rP.trans (shrink.trans (by nlinarith only [gain']))
    · have z3 : z≤z^3 := by simpa using (Nat.pow_le_pow_right zp (show 1≤3 by decide))
      have ub : u≤u^4 := by simpa using (Nat.pow_le_pow_right hu (show 1≤4 by decide))
      have w : R≤3*z*(5*K)^2*(6*K*u) := x.trans (by gcongr)
      have lo := Nat.mul_le_mul (Nat.mul_le_mul z3 (Nat.pow_le_pow_right hK (show 3≤6 by decide))) ub
      nlinarith only [w,Nat.mul_le_mul (show 450≤6400 by decide) lo]
    · have rr : R≤R^2 := by simpa using (Nat.pow_le_pow_right rpos (show 1≤2 by decide))
      have zz : z≤z^3 := by simpa using (Nat.pow_le_pow_right zp (show 1≤3 by decide))
      have k2 : K≤K^2 := by simpa using (Nat.pow_le_pow_right hK (show 1≤2 by decide))
      have w : R≤3*z*(26*K^2) := rr.trans (x.trans
        (Nat.mul_le_mul (Nat.mul_le_mul_left 3 gz) (by nlinarith only [k2])))
      have lower := Nat.mul_le_mul (Nat.mul_le_mul zz (Nat.pow_le_pow_right hK (show 2≤6 by decide)))
        (Nat.one_le_pow 4 u hu)
      nlinarith only [w,Nat.mul_le_mul (show 78≤6400 by decide) lower]
  have scale := target.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left uB 4))
  have eqn : 6400*z^3*K^6*(64*m^2*K)^4 = (6400*64^4)*(2^(3*K))*K^10*m^8 := by
    dsimp [z];rw [pow_mul 2 3 K,←pow_mul 2 K 3,mul_comm K 3,pow_mul];ring
  rw [eqn] at scale
  rw [pow_add]
  exact scale.trans (Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _
    (Nat.mul_le_mul_right _ (show 6400*64^4≤(2:ℕ)^37 by decide))))

end OMA.TwoOddCoarse245212
