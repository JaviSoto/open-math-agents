import SmallReplay245212
import SmallLeast245212

/-! Jump to the admissible dyadic interval before testing the variable exponent. -/
namespace OMA.SmallFastReplay245212
open OMA.Large245212 OMA.RankTwoReplay245212 OMA.SmallCaps245212 OMA.SmallReplay245212
open private OMA.SmallReplay245212.index_fits from SmallReplay245212
open scoped ArithmeticFunction.sigma

def beginAt (d b r : ℕ) := ((b*(d+1)-1)*r-2*b*(d+1)-1)/(b*(2*(d+1)-1))

private theorem enter {d b r k : ℕ} (_r3 : 3≤r) (bh : 1≤b) (_hd : 2≤d)
    (h : (b*(d+1)-1)*r≤b*(2*(d+1)+(k+1)*(2*(d+1)-1))) : beginAt d b r≤k := by
  have hp : 0<b*(2*(d+1)-1) := Nat.mul_pos (by omega) (by omega)
  have h' : (b*(d+1)-1)*r≤2*b*(d+1)+(k+1)*(b*(2*(d+1)-1)) := by nlinarith only [h]
  unfold beginAt
  apply Nat.le_of_lt_succ
  apply (Nat.div_lt_iff_lt_mul hp).mpr
  change (b*(d+1)-1)*r-2*b*(d+1)-1 < (k+1)*(b*(2*(d+1)-1))
  have pos : 0<(k+1)*(b*(2*(d+1)-1)) := Nat.mul_pos (Nat.succ_pos _) hp
  omega

private theorem leave {e K r : ℕ} (he : 0<e)
    (h : OMA.TwoOddEffectiveTable245212.floorPrime (K+1) (e+1)≤r) : K<r*(e+1)/e+1 := by
  unfold OMA.TwoOddEffectiveTable245212.floorPrime at h
  simp only [Nat.add_sub_cancel,max_le_iff] at h
  have ht := (Nat.div_lt_iff_lt_mul (Nat.succ_pos e)).mp (by omega : K*e/(e+1)<r)
  have cut := (Nat.le_div_iff_mul_le he).mpr ht.le
  exact Nat.lt_succ_of_le cut

def stripe (d : ℕ) (few rev : Bool) (lo hi : ℕ) :=
  (List.range' lo (hi+1-lo)).all fun r =>
    let b:=first d few
    let e:=if rev then d else b
    let start:=beginAt d (b+1) r
    let top:=min (ceiling d few rev) (r*(e+1)/e+1)
    !decide r.Prime || (List.range' start (top-start)).all (fun k => row d r k few rev)

theorem use_stripe {p q a d k lo hi : ℕ} (hp : p.Prime) (hq : q.Prime)
    (op : 3 ≤ p) (oq : 3 ≤ q) (pq : p≠q) (hd : 2≤d) (ed : d≤4) (order : d≤a)
    (lower : lo ≤ min p q) (upper : min p q≤hi)
    (ok : stripe d (decide (a<2*d+4)) (decide (q<p)) lo hi=true)
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) : False := by
  let r:=min p q
  let f:=decide (a<2*d+4)
  let v:=decide (q<p)
  let b:=first d f
  let low:=(if v then d else b)+1
  have r3 : 3≤r := le_min op oq
  have pr : r.Prime := by rcases le_total p q with l|l <;> simp_all [r]
  have ba : b≤a := by by_cases c : a<2*d+4 <;> simp [b,first,f,c] <;> omega
  have small := OMA.ComplementaryBase245212.small_prime hp hq op oq pq (by nlinarith only [hd,order,Nat.zero_le (a*d)] : 5≤(a+1)*(d+1)) eqn
  have dy := OMA.SmallCaps245212.dyadic hp hq op oq pq hd ed order eqn
  have par := OMA.SmallFacts245212.parity hp hq op oq pq eqn
  have flip : OeisA245212.a (2^k*q^d*p^a)=(σ 1 (2^k*q^d*p^a):ℤ) := by rwa [mul_right_comm]
  have cut : OMA.TwoOddEffectiveTable245212.floorPrime (k+1) low≤r := by
    dsimp [low,v,r]
    split
    · rename_i rev
      have smaller : q<p := by simpa using rev
      rw [min_eq_right smaller.le]
      exact OMA.TwoOddParameters245212.floor hq hp oq op pq.symm (by omega) (by omega) le_rfl flip
    · rename_i rev
      have smaller : p≤q := by simpa using rev
      rw [min_eq_left smaller]
      exact OMA.TwoOddParameters245212.floor hp hq op oq pq (by omega) (by omega) (by omega) eqn
  have wide : ¬(13≤r ∧ 36≤(b+1)*(d+1) ∧ 9*(k+1)≤4*(r-1)) := by
    rintro ⟨room,size,bad⟩
    have h:=OMA.SmallFacts245212.either hp hq pq room (size.trans (Nat.mul_le_mul_right _ (by omega))) eqn
    omega
  have rpass := List.all_eq_true.mp ok r (List.mem_range'_1.mpr ⟨lower,by omega⟩)
  simp only [pr,decide_true,Bool.not_true,Bool.false_or] at rpass
  have bh : 1≤b := by dsimp [b,first];split <;> omega
  have nh := OMA.SmallLeast245212.bound hp hq op oq pq (Nat.succ_pos b) (Nat.add_le_add_right ba 1) eqn
  change ((b+1)*(d+1)-1)*r ≤ (b+1)*(2*(d+1)+(k+1)*(2*(d+1)-1)) at nh
  have lowerK := enter (d:=d) r3 (Nat.succ_pos b) (by omega) nh
  have ul := leave (K:=k) (e:=if v then d else b) (r:=r) (by split <;> omega) cut
  have ur : k < min (ceiling d f v) (r*((if v then d else b)+1)/(if v then d else b)+1) := lt_min (by exact dy) ul
  have rowpass := List.all_eq_true.mp rpass k (List.mem_range'_1.mpr ⟨lowerK,by change k<beginAt d (b+1) r+(min (ceiling d f v) (r*((if v then d else b)+1)/(if v then d else b)+1)-beginAt d (b+1) r);omega⟩)
  change row d r k f v=true at rowpass
  unfold row at rowpass
  have rn : ¬r<OMA.TwoOddEffectiveTable245212.floorPrime (k+1) low := not_lt_of_ge cut
  change (if (decide (r<OMA.TwoOddEffectiveTable245212.floorPrime (k+1) low) || decide (13≤r ∧ 36≤(b+1)*(d+1) ∧ 9*(k+1)≤4*(r-1))) then _ else _)=true at rowpass
  simp only [rn,wide,decide_false,Bool.false_or,Bool.false_eq_true,↓reduceIte] at rowpass
  let H:=if f then 2*d+3 else 1+Nat.log r (OMA.SmallExponent245212.cap d (k+1) r v)
  let j:=a/stride d
  have aH : a≤H := by
    by_cases few : a<2*d+4
    · simp [H,f,few];omega
    · simp only [H,f,few,decide_false,Bool.false_eq_true,↓reduceIte]
      have pw:=OMA.SmallExponent245212.power hp hq op oq pq hd order eqn
      have e:=Nat.le_log_of_pow_le (by omega : 1<r) pw
      change a-1≤Nat.log r (OMA.SmallExponent245212.cap d (k+1) r v) at e
      omega
  have idx : (b+stride d-1-offset d)/stride d≤j ∧ j≤(H-offset d)/stride d ∧ stride d*j+offset d=a := by
    exact OMA.SmallReplay245212.index_fits hd ed ba aH par
  have point:=List.all_eq_true.mp rowpass j (List.mem_range'_1.mpr ⟨idx.1,by dsimp [H,b] at *;omega⟩)
  simp only [idx.2.2] at point
  by_cases rev : q<p
  · have qv : v=true := by simp [v,rev]
    have rq : r=q := min_eq_right rev.le
    simp only [qv,↓reduceIte,rq] at point
    exact leaf hq (by omega) hp rev (by omega) point flip
  · have qv : v=false := by simp [v,rev]
    have rp : r=p := min_eq_left (by omega)
    simp only [qv,Bool.false_eq_true,↓reduceIte,rp] at point
    exact leaf hp (by omega) hq (by omega) (by omega) point eqn


end OMA.SmallFastReplay245212
