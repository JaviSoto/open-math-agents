import PairSweep245212

/-! No exception at 2^k 5^e q^f for any prime q>5. -/
namespace OMA.FiveMovingPair245212
open Finset Nat ArithmeticFunction OMA.Smooth245212 OMA.PairSweep245212 OMA.PairExtension245212
open scoped ArithmeticFunction.sigma

private theorem sharp {k q e f : ℕ} (hq : q.Prime) (pq : 5<q) (ep : 0<e)
    (eq : OeisA245212.a (2^k*5^e*q^f)=(σ 1 (2^k*5^e*q^f):ℤ)) : k<10 := by
  have oq := hq.odd_of_ne_two (by omega)
  have odd : Odd (5^e*q^f) := ((by decide : Odd 5).pow).mul oq.pow
  have mem : 5∈(5^e*q^f).primeFactors := Nat.mem_primeFactors.mpr
    ⟨by decide,dvd_mul_of_dvd_left (dvd_pow_self 5 ep.ne') _,by have := hq.pos; positivity⟩
  exact OMA.DyadicLeast245212.exponent_lt_twice_prime odd mem (by simpa [mul_assoc] using eq)

private theorem at_three {q e f : ℕ} (hq : q.Prime) (pq : 5<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^3*5^e*q^f)≠(σ 1 (2^3*5^e*q^f):ℤ) := by
  by_cases big : 24≤q
  · exact OMA.DyadicEuler245212.pair_small (by decide) hq (by decide) pq ep (u:=5) (v:=24)
      (by decide) (by decide) le_rfl big (by decide +kernel)
  have cases : q=7 ∨ q=11 ∨ q=13 ∨ q=17 ∨ q=19 ∨ q=23 := by
    interval_cases q <;> norm_num at *
  rcases cases with rfl|rfl|rfl|rfl|rfl|rfl
  · apply known_case (B:=2) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=5) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=8) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=17) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=29) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · set_option maxHeartbeats 40000000 in
    apply known_case (B:=553) (by decide) hq (by decide) pq ep fp <;> decide +kernel

/-- All three exponents and the larger odd prime are unrestricted. -/
theorem no_five {k q e f : ℕ} (hq : q.Prime) (pq : 5<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^k*5^e*q^f)≠(σ 1 (2^k*5^e*q^f):ℤ) := by
  intro eq
  have bound := sharp hq pq ep eq
  by_cases small : k≤2
  · by_cases kp : 0<k
    · exact OMA.DyadicEuler245212.no_two_small_k kp small (by decide) hq (by decide) pq ep fp eq
    · have z : k=0 := by omega
      subst k
      exact OMA.DyadicEuler245212.pair_small (by decide) hq (by decide) pq ep (u:=5) (v:=6)
        (by decide) (by decide) le_rfl pq (by decide +kernel) eq
  have lower : 3≤k := by omega
  interval_cases k
  · exact at_three hq pq ep fp eq
  · exact free_case (B:=31) (by decide) hq (by decide) pq ep fp (by decide +kernel) (by decide +kernel) eq
  · exact free_case (B:=4) (by decide) hq (by decide) pq ep fp (by decide +kernel) (by decide +kernel) eq
  · exact free_case (B:=2) (by decide) hq (by decide) pq ep fp (by decide +kernel) (by decide +kernel) eq
  · exact free_case (B:=1) (by decide) hq (by decide) pq ep fp (by decide +kernel) (by decide +kernel) eq
  · exact free_case (B:=1) (by decide) hq (by decide) pq ep fp (by decide +kernel) (by decide +kernel) eq
  · exact free_case (B:=1) (by decide) hq (by decide) pq ep fp (by decide +kernel) (by decide +kernel) eq

#print axioms no_five
end OMA.FiveMovingPair245212
