import RankTwoInteriorBox245212
import OddBoxCheck245212
import OddBoxSeparation245212
import RankTwoReplay245212
import TwoOddParameters245212

/-! Deterministic exhaustive bisection. The exact last-prime check is a
fallback even if the recursion fuel is exhausted. Bounds are inclusive. -/
namespace OMA.RankTwoInteriorWalk245212
open OMA.RankTwoInteriorBox245212

def trim (t : Cell) : Cell :=
  {t with pl:=max t.pl (1+(t.kl-1)*(t.bl-1)/t.bl), ph:=min t.ph (3*t.kh)}

def exact (t : Cell) : Bool := OMA.RankTwoReplay245212.slice (t.kl-1) (t.kh-1)
  t.pl t.ph (t.bl-1) (t.bh-1) (t.cl-1) (t.ch-1)

def spend (t : Cell) :=
  (t.kh+1-t.kl)*(t.bh+1-t.bl)*(t.ch+1-t.cl)*(t.ph+1-t.pl)

def cut (a b : ℕ) := if 2*a≤b then Nat.sqrt (a*b) else (a+b)/2

def halves (t : Cell) : Cell × Cell :=
  let wk := t.kh-t.kl
  let wb := t.bh-t.bl
  let wc := t.ch-t.cl
  let wp := (t.ph-t.pl)/7
  if 3*t.kl<t.kh || (wk≥max wp (max wb wc) && 0<wk) then
    let j := cut t.kl t.kh
    ({t with kh:=j},{t with kl:=j+1})
  else if 3*t.bl<t.bh || (wb≥max wp wc && 0<wb) then
    let j := cut t.bl t.bh
    ({t with bh:=j},{t with bl:=j+1})
  else if 3*t.cl<t.ch || (wc≥wp && 0<wc) then
    let j := cut t.cl t.ch
    ({t with ch:=j},{t with cl:=j+1})
  else
    let j := (t.pl+t.ph)/2
    ({t with ph:=j},{t with pl:=j+1})

def easy (t : Cell) : Bool :=
  decide (t.ph<t.pl) || OMA.OddBox245212.veto t.kl t.kh t.bl t.bh t.cl t.ch t.pl t.ph ||
    veto t

def check (fuel : ℕ) (raw : Cell) : Bool :=
  let t := trim raw
  if easy t then true else
  match fuel with
  | 0 => exact t
  | fuel+1 =>
    if spend t≤160 then exact t else
    let (l,r) := halves t
    check fuel l && check fuel r

def root (m kl kh : ℕ) (swap : Bool) : Cell :=
  if swap then ⟨kl,kh,m,m,m+1,225,13,3*kh⟩ else ⟨kl,kh,m,225,m,m,13,3*kh⟩

def test (m kl kh : ℕ) := check 40 (root m kl kh false) && check 40 (root m kl kh true)

def Good (t : Cell) := 0<t.kl ∧ 0<t.bl ∧ 0<t.pl

private theorem split_covers {t : Cell} {K B C p : ℕ} (h : Fits t K B C p) (g : Good t) :
    (Fits (halves t).1 K B C p ∧ Good (halves t).1) ∨
    (Fits (halves t).2 K B C p ∧ Good (halves t).2) := by
  unfold halves
  dsimp only
  split
  · simp only [Fits,Good] at *;omega
  · split
    · simp only [Fits,Good] at *;omega
    · split <;> simp only [Fits,Good] at * <;> omega

theorem trim_fits {t : Cell} {k B C p : ℕ} (h : Fits t (k+1) B C p) (g : Good t)
    (floor : ∀ j, 0<j → j≤B → 1+k*(j-1)/j≤p) (upper : p≤3*(k+1)) :
    Fits (trim t) (k+1) B C p ∧ Good (trim t) := by
  obtain ⟨k₀,k₁,b₀,b₁,c₀,c₁,p₀,p₁⟩ := h
  have a := Nat.div_le_div_right (c:=t.bl) (Nat.mul_le_mul_right (t.bl-1) (show t.kl-1≤k by omega))
  have b := floor t.bl g.2.1 b₀
  have ceil : p≤3*t.kh := upper.trans (Nat.mul_le_mul_left 3 k₁)
  refine ⟨⟨k₀,k₁,b₀,b₁,c₀,c₁,max_le p₀ ?_,le_min p₁ ceil⟩,g.1,g.2.1,lt_of_lt_of_le g.2.2 (le_max_left ..)⟩
  exact (Nat.add_le_add_left a 1).trans b

/-- The recursion and the choice of split cannot omit a solution. If
fuel runs out, the exact slice still covers the whole remaining box. -/
theorem walk_false {k B C p : ℕ}
    (floor : ∀ j, 0<j → j≤B → 1+k*(j-1)/j≤p) (upper : p≤3*(k+1))
    (noEasy : ∀ t, Fits t (k+1) B C p → Good t → easy t=false)
    (noExact : ∀ t, Fits t (k+1) B C p → exact t=false) :
    ∀ fuel t, Fits t (k+1) B C p → Good t → check fuel t=false := by
  intro fuel
  induction fuel with
  | zero =>
    intro raw fit g
    obtain ⟨ft,gt⟩ := trim_fits fit g floor upper
    simp [check,noEasy _ ft gt,noExact _ ft]
  | succ fuel ih =>
    intro raw fit g
    obtain ⟨ft,gt⟩ := trim_fits fit g floor upper
    simp only [check,noEasy _ ft gt,Bool.false_eq_true,ite_false]
    split
    · exact noExact _ ft
    · obtain ⟨fl,gl⟩ | ⟨fr,gr⟩ := split_covers ft gt
      · simp [ih _ fl gl]
      · simp [ih _ fr gr]

#print axioms walk_false

open ArithmeticFunction
open scoped ArithmeticFunction.sigma

/-- An actual solution survives the three arithmetic tests needed by the
closed-cell certificates, regardless of a cell's ancestry. -/
theorem solution_facts {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime)
    (op : 13≤p) (pq : p+2≤q) (dk : 5≤k) (ea : 5≤a) (ed : 4≤d) (upper : p≤3*(k+1))
    (generic : ∀ s, Fits s (k+1) (a+1) (d+2) p →
      OeisA245212.a (2^k*p^a*q^(d+1))=(σ 1 (2^k*p^a*q^(d+1)):ℤ) →
      OMA.OddBox245212.veto s.kl s.kh s.bl s.bh s.cl s.ch s.pl s.ph=false)
    (eqn : OeisA245212.a (2^k*p^a*q^(d+1))=(σ 1 (2^k*p^a*q^(d+1)):ℤ)) :
    (∀ j, 0<j → j≤a+1 → 1+k*(j-1)/j≤p) ∧
    (∀ s, Fits s (k+1) (a+1) (d+2) p → Good s → easy s=false) ∧
    (∀ s, Fits s (k+1) (a+1) (d+2) p → exact s=false) := by
  have po : 3≤p := by omega
  have qo : 3≤q := by omega
  have plq : p<q := by omega
  have pos : (p:ℤ)-1<(k:ℤ)*(d+1) := by
    have ub : (p:ℤ)≤3*(k+1) := by exact_mod_cast upper
    nlinarith only [ub,mul_nonneg (by positivity : (0:ℤ)≤k) (by omega : (0:ℤ)≤d-4),
      (show (5:ℤ)≤k by exact_mod_cast dk)]
  have small : (p:ℤ)-1≤((d:ℤ)+2)*k := by nlinarith only [pos,Int.natCast_nonneg k]
  have sep := OMA.OddBox245212.separations hp hq po plq (by omega : 1≤a)
    (by omega : 1≤d+1) (by omega : 2≤k) (by exact_mod_cast pos) eqn
  have bd := OMA.SimultaneousBound245212.of_separations hp hq po qo plq.ne eqn sep.1 sep.2
  have floor (j : ℕ) (j0 : 0<j) (jb : j≤a+1) : 1+k*(j-1)/j≤p := by
    have f := OMA.TwoOddParameters245212.floor hp hq po qo plq.ne (by omega : 1≤a) j0 jb eqn
    exact (le_max_right _ _).trans (by simpa [OMA.TwoOddEffectiveTable245212.floorPrime] using f)
  have noEasy (s : Cell) (fs : Fits s (k+1) (a+1) (d+2) p) (gs : Good s) : easy s=false := by
    have order : ¬s.ph<s.pl := by obtain ⟨_,_,_,_,_,_,l,r⟩:=fs;omega
    have v := veto_false hp hq po pq (by omega : 2≤a) gs.1 gs.2.2 fs small eqn bd.1 bd.2
    simp [easy,order,generic s fs eqn,v]
  have noExact (s : Cell) (fs : Fits s (k+1) (a+1) (d+2) p) : exact s=false := by
    obtain ⟨k₀,k₁,b₀,b₁,c₀,c₁,p₀,p₁⟩ := fs
    by_contra! bad
    have checked := Bool.eq_true_of_not_eq_false bad
    exact OMA.RankTwoReplay245212.of_slice hp (by omega) hq plq (by omega : 0<d+1) p₀ p₁
      (by omega : s.kl-1 ≤ k) (by omega : k ≤ s.kh-1) (by omega : s.bl-1 ≤ a)
      (by omega : a ≤ s.bh-1) (by omega : s.cl-1 ≤ d+1) (by omega : d+1 ≤ s.ch-1) checked eqn
  exact ⟨floor,noEasy,noExact⟩

/-- Point, range and recursion soundness composed at the original OEIS
statement. The shared generic exterior veto can be supplied independently
of the sharper interior pole calculation and the final digit checks. -/
theorem original_of_check {t : Cell} {p q a d k fuel : ℕ}
    (hp : p.Prime) (hq : q.Prime) (op : 13≤p) (pq : p+2≤q)
    (dk : 5≤k) (ea : 5≤a) (ed : 4≤d) (upper : p≤3*(k+1))
    (fit : Fits t (k+1) (a+1) (d+2) p) (good : Good t)
    (generic : ∀ s, Fits s (k+1) (a+1) (d+2) p →
      OeisA245212.a (2^k*p^a*q^(d+1))=(σ 1 (2^k*p^a*q^(d+1)):ℤ) →
      OMA.OddBox245212.veto s.kl s.kh s.bl s.bh s.cl s.ch s.pl s.ph=false)
    (ok : check fuel t=true) :
    OeisA245212.a (2^k*p^a*q^(d+1))≠(σ 1 (2^k*p^a*q^(d+1)):ℤ) := by
  intro eqn
  obtain ⟨floor,noEasy,noExact⟩ := solution_facts hp hq op pq dk ea ed upper generic eqn
  have nope := walk_false floor upper noEasy noExact fuel t fit good
  simp [ok] at nope

#print axioms original_of_check

end OMA.RankTwoInteriorWalk245212
