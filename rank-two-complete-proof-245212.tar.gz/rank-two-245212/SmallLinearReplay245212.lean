import SmallLinear245212
import RankTwoReplay245212

/-! Check both choices of the smaller prime. No bound on the other base is
used: its value is recovered by leading-digit division. -/
namespace OMA.SmallLinearReplay245212
open OMA.Large245212 OMA.RankTwoReplay245212
open scoped ArithmeticFunction.sigma

def row (r k : ℕ) : Bool :=
  let K:=k+1
  let w:=wt 2 k
  let s:=sig 2 k
  let t:=OMA.Large245212.tax 2 k
  let oneA:=w*wt r 1
  let oneS:=s*sig r 1
  let oneT:=t*OMA.Large245212.tax r 1
  let top:=min 59 (Nat.log r (OMA.SmallLinear245212.limit K)/4)
  (List.range (top+1)).all fun j =>
    let a:=4*j+2
    excluded r a oneA oneS oneT &&
      excluded r 1 (w*wt r a) (s*sig r a) (t*OMA.Large245212.tax r a)

def stripe (lo hi : ℕ) := (List.range' lo (hi+1-lo)).all fun r =>
  !decide r.Prime || (List.range' ((r+4)/5-1) (min 159 (2*r)+1-(r+4)/5)).all (row r)

theorem use_stripe {p q a k lo hi : ℕ} (hp : p.Prime) (hq : q.Prime)
    (op : 3 ≤ p) (oq : 3 ≤ q) (pq : p≠q) (lower : lo ≤ min p q) (upper : min p q≤hi)
    (ok : stripe lo hi=true) :
    OeisA245212.a (2^k*p^a*q)≠(σ 1 (2^k*p^a*q):ℤ) := by
  intro eqn
  obtain ⟨K,res,power,endA,small⟩:=OMA.SmallLinear245212.box hp hq op oq pq eqn
  have ha : 1≤a := by omega
  have eq' : OeisA245212.a (2^k*p^a*q^1)=(σ 1 (2^k*p^a*q^1):ℤ) := by simpa
  have flip : OeisA245212.a (2^k*q^1*p^a)=(σ 1 (2^k*q^1*p^a):ℤ) := by rwa [mul_right_comm]
  let r:=min p q
  have r3 : 3≤r := le_min op oq
  have pr : r.Prime := by rcases le_total p q with l|l <;> simp_all [r]
  have Kbound : k<2*r := by
    have pBound := OMA.TwoOddParameters245212.reciprocal hp hq op oq pq ha eq'
    have qBound := OMA.TwoOddParameters245212.reciprocal hq hp oq op pq.symm (by decide : 1≤1) flip
    have pk : k<2*p := by
      by_contra! fail
      nlinarith only [pBound,Nat.mul_le_mul_right a fail,Nat.mul_le_mul_left p ha]
    dsimp [r];omega
  have rpass:=List.all_eq_true.mp ok r (List.mem_range'_1.mpr ⟨lower,by omega⟩)
  simp only [pr,decide_true,Bool.not_true,Bool.false_or] at rpass
  have step:=List.all_eq_true.mp rpass k (List.mem_range'_1.mpr ⟨by dsimp [r] at *;omega,by dsimp [r] at *;omega⟩)
  have rg : r^(a-1)≤OMA.SmallLinear245212.limit (k+1) :=
    (Nat.pow_le_pow_left (min_le_left p q) _).trans power
  have alog := Nat.le_log_of_pow_le (by omega : 1<r) rg
  let j:=a/4
  have ja : 4*j+2=a := by dsimp [j];omega
  have part:=List.all_eq_true.mp step j (List.mem_range.mpr (by dsimp [j];omega))
  simp only [ja,Bool.and_eq_true] at part
  rcases lt_or_gt_of_ne pq with less|more
  · have ln : r=p := min_eq_left less.le
    rw [ln] at part
    exact leaf hp (by omega) hq less (by decide : 0<1) part.2 eq'
  · have ln : r=q := min_eq_right more.le
    rw [ln] at part
    exact leaf hq (by omega) hp more ha part.1 flip

end OMA.SmallLinearReplay245212
