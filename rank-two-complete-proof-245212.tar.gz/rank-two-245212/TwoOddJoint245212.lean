import ComplementaryPole245212

/-! A shared-error version of the k-pole rounding bound, exactly matching
the finite scalar table. The bound R may be any positive lower bound on P. -/
namespace OMA.TwoOddJoint245212
open ArithmeticFunction OMA.Smooth245212 OMA.ComplementaryPole245212 OMA.ComplementaryLocal245212
open scoped ArithmeticFunction.sigma

private theorem round {k : ℕ} {p b h P W S : ℤ} (hp : 3≤p) (hb : 3≤b) (hh : 2≤h) (hP : 0<P)
    (w : (p-1)^2*W=p*(b*(p-1)-1)*P+1) (s : (p-1)*S=p*P-1)
    (plus : 0<den k b h P W S) (small : p-1≤h*(k:ℤ))
    (joint : 2*(((k:ℤ)+1)*h*b*p*P+G k*h*(k+1))≤G k*P) :
    G k*P≤2*(p-1)^2*den k b h P W S := by
  let u:=p-1
  let L:=h*b*u^2+(k:ℤ)*h*(p-b*u)-p*u
  let D:=den k b h P W S
  change G k*P≤2*u^2*D
  have up : 0<u := by dsimp [u];omega
  have kp : (0:ℤ)<k+1 := by positivity
  have bp : 0<b*u-p := by
    dsimp [u];nlinarith only [hp,hb,mul_nonneg (show 0≤b-3 by omega) (show 0≤p-1 by omega)]
  have gp := (dyad k).1
  have fg : F k=(k:ℤ)*G k+(k+1) := by dsimp [F,G];ring
  have iden : u^2*D=P*G k*L-P*(k+1)*h*(b*u-p)-(h*F k-G k*u) := by
    dsimp [L,D,den,u];rw [fg]
    linear_combination -h*((k:ℤ)*G k+(k+1))*w-G k*(p-1)*s
  have ef : 0≤h*F k-G k*u := by
    rw [fg];nlinarith only [mul_nonneg gp.le (sub_nonneg.mpr small),mul_nonneg (by omega : 0≤h) kp.le]
  have pl : 0<(P*G k)*L := by
    nlinarith only [iden,ef,mul_pos (sq_pos_of_pos up) plus,
      mul_nonneg (mul_nonneg (mul_nonneg hP.le kp.le) (by omega : 0≤h)) bp.le]
  have lp := pos_of_mul_pos_right pl (mul_nonneg hP.le gp.le)
  have gain := mul_nonneg (mul_nonneg hP.le gp.le) (show 0≤L-1 by omega)
  have fcap := mul_le_mul_of_nonneg_left (dyad k).2.2.1 (by omega : 0≤h)
  have bu : b*u-p≤b*p := by dsimp [u];nlinarith only [hp,hb]
  have sf := mul_le_mul_of_nonneg_left bu (show (0:ℤ)≤P*(k+1)*h by positivity)
  nlinarith only [iden,gain,joint,fcap,sf,mul_nonneg gp.le up.le]

private theorem enlarge {A B G R P : ℕ} (r0 : 0<R) (rP : R≤P) (box : 2*(A*R+B)≤G*R) :
    2*(A*P+B)≤G*P := by
  have ca : 2*A≤G := (mul_le_mul_iff_left₀ r0).mp (by nlinarith only [box,Nat.zero_le B])
  obtain ⟨n,rfl⟩:=Nat.exists_eq_add_of_le rP
  nlinarith only [box,Nat.mul_le_mul_right n ca]

theorem near {p q a d k R : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 3≤p) (oq : 3≤q) (pq : p≠q)
    (ha : 2≤a) (hd : 1≤d)
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ))
    (small : p-1≤(d+1)*k) (r0 : 0<R) (rP : R≤p^a)
    (box : 2*((k+1)*(d+1)*(a+1)*p*R+(2^(k+1)-1)*(d+1)*(k+1))≤(2^(k+1)-1)*R) :
    q≤6*(d+1)*(k+1)*(a+1)*p^2 := by
  obtain ⟨e,rfl⟩:=Nat.exists_eq_succ_of_ne_zero (by omega : d≠0)
  let D:=den k (a+1) (e+2) ((p:ℤ)^a) (W (p^a)) (σ 1 (p^a))
  obtain ⟨plus,tail'⟩ := tail hp hq op oq pq a e k eqn
  change 0<D at plus
  have jc:=enlarge r0 rP box
  have gz : 1≤2^(k+1) := Nat.one_le_pow _ _ (by decide : 0<2)
  zify [Nat.cast_sub gz] at jc
  have joint : 2*(((k:ℤ)+1)*(e+2)*(a+1)*p*p^a+G k*(e+2)*(k+1))≤G k*(p:ℤ)^a := by
    dsimp [G,z];nlinarith only [jc]
  have sm : (p:ℤ)-1≤((e:ℤ)+2)*k := by
    zify [Nat.cast_sub hp.pos] at small;linarith only [small]
  have m:=moments hp a
  have rr:=round (show (3:ℤ)≤p by omega) (show (3:ℤ)≤a+1 by omega) (show (2:ℤ)≤e+2 by omega)
    (pow_pos (show (0:ℤ)<p by omega) a) m.2 m.1 plus sm joint
  change (q:ℤ)*D≤3*(e+2)*(k+1)*(a+1)*G k*(p:ℤ)^a at tail'
  have qk : (q:ℤ)*(G k*(p:ℤ)^a)≤(6*(e+2)*(k+1)*(a+1)*((p:ℤ)-1)^2)*(G k*(p:ℤ)^a) := by
    nlinarith only [mul_le_mul_of_nonneg_left rr (show (0:ℤ)≤q by positivity),
      mul_le_mul_of_nonneg_left tail' (mul_nonneg (show (0:ℤ)≤2 by decide) (sq_nonneg ((p:ℤ)-1)))]
  have cap := (mul_le_mul_iff_left₀ (mul_pos (dyad k).1 (pow_pos (show (0:ℤ)<p by omega) a))).mp qk
  have sq : ((p:ℤ)-1)^2≤(p:ℤ)^2 := by nlinarith only [show (3:ℤ)≤p by omega]
  exact_mod_cast cap.trans (mul_le_mul_of_nonneg_left sq (by positivity))

end OMA.TwoOddJoint245212
