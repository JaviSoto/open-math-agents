import TwoOddJoint245212

/-! A pointwise lower bound on the last-prime deficit, retaining the
actual integral pole instead of replacing a positive integer by one. -/
namespace OMA.RankTwoPoleInterior245212
open ArithmeticFunction OMA.Smooth245212 OMA.ComplementaryPole245212 OMA.ComplementaryLocal245212
open scoped ArithmeticFunction.sigma

def L (k p b c : ℤ) := c*b*(p-1)*((p-1)-k)+(c*k-(p-1))*p

theorem point {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 3≤p) (oq : 3≤q)
    (pq : p≠q) (ha : 2≤a) (small : (p:ℤ)-1≤((d:ℤ)+2)*k)
    (eqn : OeisA245212.a (2^k*p^a*q^(d+1))=(σ 1 (2^k*p^a*q^(d+1)):ℤ)) :
    let b : ℤ := a+1; let c : ℤ := d+2; let u : ℤ := p-1; let K : ℤ := k+1
    0<L k p b c ∧ ∀ x y : ℤ, K*c*b*u≤x*G k → c*K≤y*(p:ℤ)^a →
      (q:ℤ)*(L k p b c-(x+y))≤3*c*K*b*u^2 := by
  dsimp only
  let b : ℤ := a+1
  let c : ℤ := d+2
  let u : ℤ := p-1
  let K : ℤ := k+1
  let P : ℤ := (p:ℤ)^a
  let D := den k b c P (W (p^a)) (σ 1 (p^a))
  have gp := (dyad k).1
  have pp : 0<P := pow_pos (by omega) _
  have up : 0<u := by dsimp [u];omega
  have cb : 0<c := by dsimp [c];positivity
  have bp : 0<b := by dsimp [b];positivity
  have kp : 0<K := by dsimp [K];positivity
  have ppos : (0:ℤ)<p := by omega
  have qpos : (0:ℤ)<q := by omega
  have bu : 0<b*u-p := by
    dsimp [b,u]
    nlinarith only [mul_nonneg (by omega : (0:ℤ)≤a-2) (by omega : (0:ℤ)≤p-1),op]
  have fg : F k=(k:ℤ)*G k+K := by dsimp [F,G,K];ring
  have cf : 0≤c*F k-G k*u := by
    change u≤c*k at small
    rw [fg]; nlinarith only [mul_nonneg gp.le (sub_nonneg.mpr small),mul_pos cb kp]
  have m := moments hp a
  have id : u^2*D=P*G k*(L k p b c)-P*K*c*(b*u-p)-(c*F k-G k*u) := by
    dsimp [D,den,L,u,b,c,P,K] at *
    rw [fg]
    linear_combination -((d:ℤ)+2)*((k:ℤ)*G k+(k+1))*m.2-G k*(p-1)*m.1
  obtain ⟨plus,tail⟩ := tail hp hq op oq pq a d k eqn
  change 0<D at plus
  change (q:ℤ)*D≤3*c*K*b*G k*P at tail
  have pl : 0<(P*G k)*(L k p b c) := by
    nlinarith only [id,cf,mul_pos (sq_pos_of_pos up) plus,
      mul_nonneg (mul_nonneg (mul_nonneg pp.le kp.le) cb.le) bu.le]
  refine ⟨pos_of_mul_pos_right pl (mul_nonneg pp.le gp.le),?_⟩
  intro x y hx hy
  have fcap := mul_le_mul_of_nonneg_left (dyad k).2.2.1 cb.le
  have room : (P*G k)*(L k p b c-(x+y))≤u^2*D := by
    nlinarith only [id,mul_le_mul_of_nonneg_left hx pp.le,mul_le_mul_of_nonneg_left hy gp.le,
      fcap,mul_nonneg gp.le up.le,mul_nonneg (mul_nonneg (mul_nonneg pp.le kp.le) cb.le) ppos.le]
  apply le_of_mul_le_mul_right (a:=P*G k) _ (mul_pos pp gp)
  nlinarith only [mul_le_mul_of_nonneg_left room qpos.le,
    mul_le_mul_of_nonneg_left tail (sq_nonneg u)]

#print axioms point

def underSlope (l h s : ℤ) := if s<0 then h*s else l*s
def overSlope (l h s : ℤ) := if s<0 then l*s else h*s

private theorem bracket {l h x s t w : ℤ} (lo : l≤x) (hi : x≤h)
    (xp : 0≤x) (sl : s≤t) (sw : t≤w) :
    underSlope l h s≤x*t ∧ x*t≤overSlope l h w := by
  have low := mul_le_mul_of_nonneg_left sl xp
  have high := mul_le_mul_of_nonneg_left sw xp
  constructor
  · unfold underSlope; split
    · exact (mul_le_mul_of_nonpos_right hi (by omega)).trans low
    · exact (mul_le_mul_of_nonneg_right lo (by omega)).trans low
  · unfold overSlope; split
    · exact high.trans (mul_le_mul_of_nonpos_right lo (by omega))
    · exact high.trans (mul_le_mul_of_nonneg_right hi (by omega))

/-- k endpoints are the ordinary exponent (not K); p,r bound the
smaller prime, while the larger prime is not yet bounded. -/
def lowPole (kl kh bl bh cl ch p r : ℤ) :=
  underSlope (cl*bl*(p-1)) (ch*bh*(r-1)) (p-1-kh)+max 0 (cl*kl-(r-1))*p

def highPole (kl kh bl bh cl ch p r : ℤ) :=
  overSlope (cl*bl*(p-1)) (ch*bh*(r-1)) (r-1-kl)+(ch*kh-(p-1))*r

theorem pole_interval {kl kh bl bh cl ch pl ph k p b c : ℤ}
    (k0 : 0≤kl) (b0 : 0≤bl) (c0 : 0≤cl) (p0 : 1≤pl)
    (kl' : kl≤k) (kh' : k≤kh) (bl' : bl≤b) (bh' : b≤bh)
    (cl' : cl≤c) (ch' : c≤ch) (pl' : pl≤p) (ph' : p≤ph)
    (small : p-1≤c*k) :
    lowPole kl kh bl bh cl ch pl ph≤L k p b c ∧ L k p b c≤highPole kl kh bl bh cl ch pl ph := by
  have pp : 0≤p := by omega
  have up : 0≤p-1 := by omega
  have bp : 0≤b := by omega
  have cp : 0≤c := by omega
  have bh0 : 0≤bh := by omega
  have ch0 : 0≤ch := by omega
  have kk : 0≤k := by omega
  have blim : cl*bl*(pl-1)≤c*b*(p-1) := by gcongr
  have bhim : c*b*(p-1)≤ch*bh*(ph-1) := by gcongr
  have first := bracket blim bhim (by positivity : 0≤c*b*(p-1))
    (show pl-1-kh≤p-1-k by omega) (show p-1-k≤ph-1-kl by omega)
  have a : cl*kl≤c*k := by gcongr
  have z : c*k≤ch*kh := by gcongr
  have e : max 0 (cl*kl-(ph-1))≤c*k-(p-1) := max_le (by omega) (by omega)
  have f : c*k-(p-1)≤ch*kh-(pl-1) := by omega
  have lower := mul_le_mul e pl' (by omega : 0≤pl) (by omega : 0≤c*k-(p-1))
  have upper := mul_le_mul f ph' pp (by omega : 0≤ch*kh-(pl-1))
  exact ⟨add_le_add first.1 lower,add_le_add first.2 upper⟩

#print axioms pole_interval
end OMA.RankTwoPoleInterior245212
