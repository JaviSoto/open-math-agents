import TwoOddEffectiveTable245212

/-! Scalar domination by powers of two and propagation of the table tail. -/
namespace OMA.TwoOddGrowth245212

private theorem step {t c j n : ℕ} (ht : 0<t) (s : (t+1)^j≤c*t^j) (h : t≤n) :
    (n+1)^j≤c*n^j := by
  have spread : (n+1)*t≤(t+1)*n := by nlinarith only [h]
  have w := Nat.pow_le_pow_left spread j
  rw [mul_pow,mul_pow] at w
  exact (mul_le_mul_iff_left₀ (pow_pos ht j)).mp
    (by nlinarith only [w,Nat.mul_le_mul_right (n^j) s])

private theorem exponential {t c j : ℕ} (ht : 0<t) (s : (t+1)^j≤2*t^j)
    (base : c*t^j≤2^t) (n : ℕ) (hn : t≤n) : c*n^j≤2^n := by
  induction n,hn using Nat.le_induction with
  | base => exact base
  | succ n hn ih =>
    have hp := Nat.mul_le_mul_left c (step ht s hn)
    rw [pow_succ]
    nlinarith only [hp,ih]

theorem at256 {n : ℕ} (hn : 256≤n) :
    n^20≤2^n ∧ n^16≤2^n ∧ 2^65*n^21≤2^n := by
  refine ⟨?_,?_,exponential (by decide : 0<256) (by decide) (by decide) n hn⟩
  · simpa using exponential (c:=1) (j:=20) (by decide : 0<256) (by decide) (by decide) n hn
  · simpa using exponential (c:=1) (j:=16) (by decide : 0<256) (by decide) (by decide) n hn

theorem table_tail {K p m : ℕ} (klo : 3≤K) (khi : K≤255) (ml : 119 ≤ m)
    (least : OMA.TwoOddEffectiveTable245212.floorPrime K 119≤p) (p3 : 3≤p) :
    2^(37+3*K)*K^10*m^8<p^(m-1) := by
  have tail := (OMA.TwoOddEffectiveTable245212.ranges (m:=33) klo khi (by decide) (by decide)).1
  change decide (_ < _) = true at tail
  have t := of_decide_eq_true tail
  have ini := t.trans_le (Nat.pow_le_pow_left least 118)
  induction m,ml using Nat.le_induction with
  | base => exact ini
  | succ n hn ih =>
    have sf := step (j:=8) (c:=3) (by decide : 0<119) (by decide) hn
    calc
      _ ≤ 2^(37+3*K)*K^10*(3*n^8) := Nat.mul_le_mul_left _ sf
      _ = (2^(37+3*K)*K^10*n^8)*3 := by ring
      _ < p^(n-1)*p := Nat.mul_lt_mul_of_lt_of_le ih p3 (by omega)
      _ = p^((n+1)-1) := by rw [←pow_succ];congr 1;omega

theorem m_large {K m p : ℕ} (big : 256≤K) (pp : 3≤p)
    (input : p^(m-1)≤2^(37+3*K)*K^10*m^8) : m≤5*K := by
  by_cases sm : m<256
  · omega
  have mm := (at256 (by omega : 256 ≤ m)).2.1
  have kk := (at256 big).1
  have power := Nat.pow_le_pow_left input 2
  simp only [mul_pow,←pow_mul] at power
  have bound : (p^(m-1))^2≤2^(74+7*K+m) := calc
    _ ≤ (2^((37+3*K)*2))*K^20*m^16 := by rw [←pow_mul];exact power
    _ ≤ (2^((37+3*K)*2))*2^K*2^m := by gcongr
    _ = _ := by rw [←pow_add,←pow_add];congr 1;ring
  have nine : 8≤p^2 := (show 8≤(3:ℕ)^2 by decide).trans (Nat.pow_le_pow_left pp 2)
  have lo : 2^(3*(m-1)) ≤ (p^(m-1))^2 := by
    rw [pow_mul 2 3 (m-1),←pow_mul p (m-1) 2,mul_comm (m-1) 2,pow_mul p 2 (m-1)]
    exact Nat.pow_le_pow_left nine _
  have cut := (pow_le_pow_iff_right₀ (a:=(2:ℕ)) (by decide)).mp (lo.trans bound)
  omega

end OMA.TwoOddGrowth245212
