import SmallCaps245212

/-! A bound depending only on the smaller prime and the dyadic exponent
for the number of powers which the finite replay needs to examine. -/
namespace OMA.SmallExponent245212
open scoped ArithmeticFunction.sigma

def cap (d K r : ℕ) (rev : Bool) : ℕ :=
  let h:=d+1
  let z:=2^K
  let b:=64*h^2*K
  let factor:=3*z*K*h
  if rev then factor*r^d else
  let R:=6*h*K*b*r^2
  if 4*K*h*b*r<z then max (4*h*K) (factor*R^d)
  else max (2*z*h*K) (factor*(z*R)^d)

theorem power {p q a d k : ℕ} (hp : p.Prime) (hq : q.Prime)
    (op : 3≤p) (oq : 3≤q) (pq : p≠q) (hd : 2≤d) (order : d≤a)
    (eqn : OeisA245212.a (2^k*p^a*q^d)=(σ 1 (2^k*p^a*q^d):ℤ)) :
    (min p q)^(a-1)≤cap d (k+1) (min p q) (decide (q<p)) := by
  let K:=k+1
  let h:=d+1
  let z:ℕ:=2^K
  let b:=64*h^2*K
  let R:=6*h*K*b*p^2
  have rle := Nat.pow_le_pow_left (min_le_left p q) (a-1)
  have flip : OeisA245212.a (2^k*q^d*p^a)=(σ 1 (2^k*q^d*p^a):ℤ) := by rwa [mul_right_comm]
  have cp := OMA.TwoOddParameters245212.cofactor hq hp oq op pq.symm (by omega) flip
  change p^(a-1)≤3*z*K*h*q^d at cp
  have ab : a+1≤b := OMA.ComplementaryExp245212.exponent hp hq op oq pq (by omega) eqn
  by_cases rev : q<p
  · simpa [cap,rev,min_eq_right rev.le,h,K,z] using rle.trans cp
  · have le : p≤q := by omega
    simp only [min_eq_left le,cap,decide_eq_true_eq,if_neg rev]
    change p^(a-1) ≤ if 4*K*h*b*p<z then max (4*h*K) (3*z*K*h*R^d) else
        max (2*z*h*K) (3*z*K*h*(z*R)^d)
    split
    · rename_i cut
      by_cases small : p^a<4*h*K
      · exact le_max_of_le_left ((Nat.pow_le_pow_right hp.pos (Nat.sub_le _ _)).trans small.le)
      · have gc : 4*K*h*(a+1)*p<z := lt_of_le_of_lt (by gcongr) cut
        have pc : 4*h*K≤p^a := le_of_not_gt small
        have ub := OMA.ComplementaryFar245212.far hp hq op oq pq (by omega) (by omega) eqn gc pc
        have qr : q≤R := ub.trans (by dsimp [R,K,h];gcongr)
        exact le_max_of_le_right (cp.trans (by gcongr))
    · obtain ⟨e,de⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : d≠0)
      have alt := OMA.ComplementaryPole245212.alternative hp hq op oq pq a e k (by omega) (by simpa [de] using eqn)
      have eh : e+2=h := by dsimp [h];omega
      rw [eh] at alt
      rcases alt with direct|upper
      · exact le_max_of_le_left ((Nat.pow_le_pow_right hp.pos (Nat.sub_le _ _)).trans direct)
      · have qr : q≤z*R := by
          apply upper.trans
          calc
            _ ≤ 6*h*K*b*z*p^2 := by dsimp [K,z];gcongr
            _ = _ := by dsimp [R];ring
        exact le_max_of_le_right (cp.trans (by gcongr))

end OMA.SmallExponent245212
