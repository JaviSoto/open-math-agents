import OddBoxLogs245212

/-! Algebra of the scaled binary logarithm on positive naturals. -/
namespace OMA.OddBox245212

noncomputable abbrev L (n : ℕ) := logSize (n:ℝ)

theorem lmono {a b : ℕ} (ha : 0<a) (hab : a≤b) : L a≤L b :=
  mono (by exact_mod_cast ha) (by exact_mod_cast hab)
theorem lreflect {a b : ℕ} (ha : 0<a) (hb : 0<b) : L a≤L b ↔ a≤b := by
  simpa [L] using reflect (x:=(a:ℝ)) (y:=(b:ℝ)) (by exact_mod_cast ha) (by exact_mod_cast hb)
theorem lmul {a b : ℕ} (ha : 0<a) (hb : 0<b) : L (a*b)=L a+L b := by
  push_cast [L];exact mul (by exact_mod_cast ha) (by exact_mod_cast hb)
theorem lpow (a n : ℕ) : L (a^n)=n*L a := by simp only [L,Nat.cast_pow,pow]
@[simp] theorem ltwo : L 2=16 := by norm_num [L]
@[simp] theorem lone : L 1=0 := by norm_num [L]
@[simp] theorem lfour : L 4=32 := by rw [show (4:ℕ)=2*2 by decide,lmul (by decide) (by decide),ltwo];norm_num

theorem le_up {a b : ℕ} (ha : 0<a) (h : a≤b) : L a≤up b := (lmono ha h).trans (enclosed b (ha.trans_le h)).2
theorem down_le {a b : ℕ} (ha : 0<a) (h : a≤b) : (down a:ℝ)≤L b := (enclosed a ha).1.trans (lmono ha h)
theorem lmax {a b : ℕ} (ha : 0<a) (hb : 0<b) : L (max a b)=max (L a) (L b) := by
  rcases le_total a b with h|h
  · rw [max_eq_right h,max_eq_right (lmono ha h)]
  · rw [max_eq_left h,max_eq_left (lmono hb h)]

theorem sum_three {x a b c : ℕ} (hx : 0<x) (ha : 0<a) (hb : 0<b) (hc : 0<c)
    (ub : x≤a+b+c) : L x≤L 3+max (L a) (max (L b) (L c)) := by
  have h : x≤3*(max a (max b c)) := by omega
  have z := lmono hx h
  rwa [lmul (by decide) (by omega),lmax ha (by omega),lmax hb hc] at z

theorem sum_four {x a b c d : ℕ} (hx : 0<x) (ha : 0<a) (hb : 0<b) (hc : 0<c) (hd : 0<d)
    (ub : x≤a+b+c+d) : L x≤32+max (max (L a) (max (L b) (L c))) (L d) := by
  have h : x≤4*(max (max a (max b c)) d) := by omega
  have z := lmono hx h
  rwa [lmul (by decide) (by omega),lmax (by omega) hd,lmax ha (by omega),lmax hb hc,lfour] at z

/-- The numerator may grow linearly with the prime. Dividing by a
positive power of the prime makes the resulting ratio decreasing. -/
theorem increasing_gap {e lo q a b : ℕ} (he : 1≤e) (hl : 0<lo) (lq : lo≤q)
    (positive : 0<a+b*lo) : L (a+b*q)-e*L q≤L (a+b*lo)-e*L lo := by
  have h : (a+b*q)*lo≤(a+b*lo)*q := by nlinarith only [Nat.mul_le_mul_left a lq]
  have posq : 0<a+b*q := positive.trans_le (by gcongr)
  have h' := lmono (Nat.mul_pos posq hl) h
  rw [lmul posq hl,lmul positive (by omega)] at h'
  have := mul_nonneg (sub_nonneg.mpr (show (1:ℝ)≤e by exact_mod_cast he))
    (sub_nonneg.mpr (lmono hl lq))
  nlinarith only [h',this]

end OMA.OddBox245212
