import PairSweep245212

/-! No A245212 equality with least odd prime 11 and exactly two odd primes. -/
namespace OMA.Least11Pair245212
open Nat Finset ArithmeticFunction OMA.PairSweep245212
open scoped ArithmeticFunction.sigma

set_option maxHeartbeats 50000000 in
private theorem at_0 {q e f : ℕ} (hq : q.Prime) (pq : 11<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^0*11^e*q^f)≠(σ 1 (2^0*11^e*q^f):ℤ) := by
  by_cases big : 12≤q
  · exact OMA.DyadicEuler245212.pair_small (by decide) hq (by decide) pq ep (u:=11) (v:=12)
      (by decide) (by decide) le_rfl big (by decide +kernel)
  interval_cases q <;> norm_num at *

set_option maxHeartbeats 50000000 in
private theorem at_1 {q e f : ℕ} (hq : q.Prime) (pq : 11<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^1*11^e*q^f)≠(σ 1 (2^1*11^e*q^f):ℤ) := by
  by_cases big : 12≤q
  · exact OMA.DyadicEuler245212.pair_small (by decide) hq (by decide) pq ep (u:=11) (v:=12)
      (by decide) (by decide) le_rfl big (by decide +kernel)
  interval_cases q <;> norm_num at *

set_option maxHeartbeats 50000000 in
private theorem at_2 {q e f : ℕ} (hq : q.Prime) (pq : 11<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^2*11^e*q^f)≠(σ 1 (2^2*11^e*q^f):ℤ) := by
  by_cases big : 12≤q
  · exact OMA.DyadicEuler245212.pair_small (by decide) hq (by decide) pq ep (u:=11) (v:=12)
      (by decide) (by decide) le_rfl big (by decide +kernel)
  interval_cases q <;> norm_num at *

set_option maxHeartbeats 50000000 in
private theorem at_3 {q e f : ℕ} (hq : q.Prime) (pq : 11<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^3*11^e*q^f)≠(σ 1 (2^3*11^e*q^f):ℤ) := by
  by_cases big : 12≤q
  · exact OMA.DyadicEuler245212.pair_small (by decide) hq (by decide) pq ep (u:=11) (v:=12)
      (by decide) (by decide) le_rfl big (by decide +kernel)
  interval_cases q <;> norm_num at *

set_option maxHeartbeats 50000000 in
private theorem at_4 {q e f : ℕ} (hq : q.Prime) (pq : 11<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^4*11^e*q^f)≠(σ 1 (2^4*11^e*q^f):ℤ) := by
  by_cases big : 12≤q
  · exact OMA.DyadicEuler245212.pair_small (by decide) hq (by decide) pq ep (u:=11) (v:=12)
      (by decide) (by decide) le_rfl big (by decide +kernel)
  interval_cases q <;> norm_num at *

set_option maxHeartbeats 50000000 in
private theorem at_5 {q e f : ℕ} (hq : q.Prime) (pq : 11<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^5*11^e*q^f)≠(σ 1 (2^5*11^e*q^f):ℤ) := by
  by_cases big : 13≤q
  · exact OMA.DyadicEuler245212.pair_small (by decide) hq (by decide) pq ep (u:=11) (v:=13)
      (by decide) (by decide) le_rfl big (by decide +kernel)
  interval_cases q <;> norm_num at *

set_option maxHeartbeats 50000000 in
private theorem at_6 {q e f : ℕ} (hq : q.Prime) (pq : 11<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^6*11^e*q^f)≠(σ 1 (2^6*11^e*q^f):ℤ) := by
  by_cases big : 18≤q
  · exact OMA.DyadicEuler245212.pair_small (by decide) hq (by decide) pq ep (u:=11) (v:=18)
      (by decide) (by decide) le_rfl big (by decide +kernel)
  have cases : q=13 ∨ q=17 := by
    interval_cases q <;> norm_num at *
  rcases cases with rfl|rfl
  · apply known_case (B:=7) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=51) (by decide) hq (by decide) pq ep fp <;> decide +kernel

set_option maxHeartbeats 50000000 in
private theorem at_7 {q e f : ℕ} (hq : q.Prime) (pq : 11<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^7*11^e*q^f)≠(σ 1 (2^7*11^e*q^f):ℤ) := by
  by_cases big : 28≤q
  · exact OMA.DyadicEuler245212.pair_small (by decide) hq (by decide) pq ep (u:=11) (v:=28)
      (by decide) (by decide) le_rfl big (by decide +kernel)
  have cases : q=13 ∨ q=17 ∨ q=19 ∨ q=23 := by
    interval_cases q <;> norm_num at *
  rcases cases with rfl|rfl|rfl|rfl
  · apply known_case (B:=3) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=6) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=8) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=20) (by decide) hq (by decide) pq ep fp <;> decide +kernel

set_option maxHeartbeats 50000000 in
private theorem at_8 {q e f : ℕ} (hq : q.Prime) (pq : 11<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^8*11^e*q^f)≠(σ 1 (2^8*11^e*q^f):ℤ) := by
  by_cases big : 46≤q
  · exact OMA.DyadicEuler245212.pair_small (by decide) hq (by decide) pq ep (u:=11) (v:=46)
      (by decide) (by decide) le_rfl big (by decide +kernel)
  have cases : q=13 ∨ q=17 ∨ q=19 ∨ q=23 ∨ q=29 ∨ q=31 ∨ q=37 ∨ q=41 ∨ q=43 := by
    interval_cases q <;> norm_num at *
  rcases cases with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · apply known_case (B:=2) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=3) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=3) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=5) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=9) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=11) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=23) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=49) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=94) (by decide) hq (by decide) pq ep fp <;> decide +kernel

set_option maxHeartbeats 50000000 in
private theorem at_9 {q e f : ℕ} (hq : q.Prime) (pq : 11<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^9*11^e*q^f)≠(σ 1 (2^9*11^e*q^f):ℤ) := by
  by_cases big : 102≤q
  · exact OMA.DyadicEuler245212.pair_small (by decide) hq (by decide) pq ep (u:=11) (v:=102)
      (by decide) (by decide) le_rfl big (by decide +kernel)
  have cases : q=13 ∨ q=17 ∨ q=19 ∨ q=23 ∨ q=29 ∨ q=31 ∨ q=37 ∨ q=41 ∨ q=43 ∨ q=47 ∨ q=53 ∨ q=59 ∨ q=61 ∨ q=67 ∨ q=71 ∨ q=73 ∨ q=79 ∨ q=83 ∨ q=89 ∨ q=97 ∨ q=101 := by
    interval_cases q <;> norm_num at *
  rcases cases with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · apply known_case (B:=1) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=2) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=2) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=3) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=4) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=4) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=6) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=7) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=8) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=9) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=12) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=15) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=16) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=21) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=25) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=28) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=39) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=50) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=81) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=261) (by decide) hq (by decide) pq ep fp <;> decide +kernel
  · apply known_case (B:=12946) (by decide) hq (by decide) pq ep fp <;> decide +kernel

set_option maxHeartbeats 50000000 in
private theorem at_10 {q e f : ℕ} (hq : q.Prime) (pq : 11<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^10*11^e*q^f)≠(σ 1 (2^10*11^e*q^f):ℤ) := by
  apply free_case (B:=2047) (by decide) hq (by decide) pq ep fp <;> decide +kernel

set_option maxHeartbeats 50000000 in
private theorem at_11 {q e f : ℕ} (hq : q.Prime) (pq : 11<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^11*11^e*q^f)≠(σ 1 (2^11*11^e*q^f):ℤ) := by
  apply free_case (B:=11) (by decide) hq (by decide) pq ep fp <;> decide +kernel

set_option maxHeartbeats 50000000 in
private theorem at_12 {q e f : ℕ} (hq : q.Prime) (pq : 11<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^12*11^e*q^f)≠(σ 1 (2^12*11^e*q^f):ℤ) := by
  apply free_case (B:=5) (by decide) hq (by decide) pq ep fp <;> decide +kernel

set_option maxHeartbeats 50000000 in
private theorem at_13 {q e f : ℕ} (hq : q.Prime) (pq : 11<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^13*11^e*q^f)≠(σ 1 (2^13*11^e*q^f):ℤ) := by
  apply free_case (B:=3) (by decide) hq (by decide) pq ep fp <;> decide +kernel

set_option maxHeartbeats 50000000 in
private theorem at_14 {q e f : ℕ} (hq : q.Prime) (pq : 11<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^14*11^e*q^f)≠(σ 1 (2^14*11^e*q^f):ℤ) := by
  apply free_case (B:=2) (by decide) hq (by decide) pq ep fp <;> decide +kernel

set_option maxHeartbeats 50000000 in
private theorem at_15 {q e f : ℕ} (hq : q.Prime) (pq : 11<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^15*11^e*q^f)≠(σ 1 (2^15*11^e*q^f):ℤ) := by
  apply free_case (B:=2) (by decide) hq (by decide) pq ep fp <;> decide +kernel

set_option maxHeartbeats 50000000 in
private theorem at_16 {q e f : ℕ} (hq : q.Prime) (pq : 11<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^16*11^e*q^f)≠(σ 1 (2^16*11^e*q^f):ℤ) := by
  apply free_case (B:=1) (by decide) hq (by decide) pq ep fp <;> decide +kernel

set_option maxHeartbeats 50000000 in
private theorem at_17 {q e f : ℕ} (hq : q.Prime) (pq : 11<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^17*11^e*q^f)≠(σ 1 (2^17*11^e*q^f):ℤ) := by
  apply free_case (B:=1) (by decide) hq (by decide) pq ep fp <;> decide +kernel

set_option maxHeartbeats 50000000 in
private theorem at_18 {q e f : ℕ} (hq : q.Prime) (pq : 11<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^18*11^e*q^f)≠(σ 1 (2^18*11^e*q^f):ℤ) := by
  apply free_case (B:=1) (by decide) hq (by decide) pq ep fp <;> decide +kernel

set_option maxHeartbeats 50000000 in
private theorem at_19 {q e f : ℕ} (hq : q.Prime) (pq : 11<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^19*11^e*q^f)≠(σ 1 (2^19*11^e*q^f):ℤ) := by
  apply free_case (B:=1) (by decide) hq (by decide) pq ep fp <;> decide +kernel

set_option maxHeartbeats 50000000 in
private theorem at_20 {q e f : ℕ} (hq : q.Prime) (pq : 11<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^20*11^e*q^f)≠(σ 1 (2^20*11^e*q^f):ℤ) := by
  apply free_case (B:=1) (by decide) hq (by decide) pq ep fp <;> decide +kernel

set_option maxHeartbeats 50000000 in
private theorem at_21 {q e f : ℕ} (hq : q.Prime) (pq : 11<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^21*11^e*q^f)≠(σ 1 (2^21*11^e*q^f):ℤ) := by
  apply free_case (B:=1) (by decide) hq (by decide) pq ep fp <;> decide +kernel

theorem no_pair {k q e f : ℕ} (hq : q.Prime) (pq : 11<q) (ep : 0<e) (fp : 0<f) :
    OeisA245212.a (2^k*11^e*q^f)≠(σ 1 (2^k*11^e*q^f):ℤ) := by
  intro eq
  have oq := hq.odd_of_ne_two (by omega)
  have odd : Odd (11^e*q^f) := ((by decide : Odd 11).pow).mul oq.pow
  have mem : 11∈(11^e*q^f).primeFactors := Nat.mem_primeFactors.mpr
    ⟨by decide,dvd_mul_of_dvd_left (dvd_pow_self 11 ep.ne') _,by have := hq.pos; positivity⟩
  have hi : k<22 := OMA.DyadicLeast245212.exponent_lt_twice_prime odd mem (by simpa [mul_assoc] using eq)
  interval_cases k
  · exact at_0 hq pq ep fp eq
  · exact at_1 hq pq ep fp eq
  · exact at_2 hq pq ep fp eq
  · exact at_3 hq pq ep fp eq
  · exact at_4 hq pq ep fp eq
  · exact at_5 hq pq ep fp eq
  · exact at_6 hq pq ep fp eq
  · exact at_7 hq pq ep fp eq
  · exact at_8 hq pq ep fp eq
  · exact at_9 hq pq ep fp eq
  · exact at_10 hq pq ep fp eq
  · exact at_11 hq pq ep fp eq
  · exact at_12 hq pq ep fp eq
  · exact at_13 hq pq ep fp eq
  · exact at_14 hq pq ep fp eq
  · exact at_15 hq pq ep fp eq
  · exact at_16 hq pq ep fp eq
  · exact at_17 hq pq ep fp eq
  · exact at_18 hq pq ep fp eq
  · exact at_19 hq pq ep fp eq
  · exact at_20 hq pq ep fp eq
  · exact at_21 hq pq ep fp eq

#print axioms no_pair
end OMA.Least11Pair245212
