import SmallFastDegree245212

/-! Exclude the original divisor equation for complementary exponent 4. -/
namespace OMA.SmallFourthBlocks245212
open OMA.SmallFastReplay245212 OMA.SmallFastDegree245212
open scoped ArithmeticFunction.sigma

set_option maxRecDepth 8192
set_option maxHeartbeats 16000000

private theorem s00_0 : stripe 4 false false 3 34=true := by decide +kernel

private theorem s00_1 : stripe 4 false false 35 66=true := by decide +kernel

private theorem s00_2 : stripe 4 false false 67 98=true := by decide +kernel

private theorem s00_3 : stripe 4 false false 99 130=true := by decide +kernel

private theorem s00_4 : stripe 4 false false 131 162=true := by decide +kernel

private theorem s00_5 : stripe 4 false false 163 194=true := by decide +kernel

private theorem s00_6 : stripe 4 false false 195 226=true := by decide +kernel

private theorem s00_7 : stripe 4 false false 227 258=true := by decide +kernel

private theorem s00_8 : stripe 4 false false 259 290=true := by decide +kernel

private theorem s00_9 : stripe 4 false false 291 322=true := by decide +kernel

private theorem s00_10 : stripe 4 false false 323 354=true := by decide +kernel

private theorem s00_11 : stripe 4 false false 355 386=true := by decide +kernel

private theorem s00_12 : stripe 4 false false 387 418=true := by decide +kernel

private theorem s00_13 : stripe 4 false false 419 450=true := by decide +kernel

private theorem s00_14 : stripe 4 false false 451 482=true := by decide +kernel

private theorem s00_15 : stripe 4 false false 483 514=true := by decide +kernel

private theorem s00_16 : stripe 4 false false 515 546=true := by decide +kernel

private theorem s00_17 : stripe 4 false false 547 578=true := by decide +kernel

private theorem s00_18 : stripe 4 false false 579 610=true := by decide +kernel

private theorem s00_19 : stripe 4 false false 611 642=true := by decide +kernel

private theorem s00_20 : stripe 4 false false 643 674=true := by decide +kernel

private theorem s00_21 : stripe 4 false false 675 706=true := by decide +kernel

private theorem s00_22 : stripe 4 false false 707 738=true := by decide +kernel

private theorem s00_23 : stripe 4 false false 739 770=true := by decide +kernel

private theorem s00_24 : stripe 4 false false 771 802=true := by decide +kernel

private theorem s00_25 : stripe 4 false false 803 834=true := by decide +kernel

private theorem s00_26 : stripe 4 false false 835 866=true := by decide +kernel

private theorem s00_27 : stripe 4 false false 867 898=true := by decide +kernel

private theorem part00 : Checked 4 false false := by
  intro j h
  change j≤27 at h
  interval_cases j
  · exact s00_0
  · exact s00_1
  · exact s00_2
  · exact s00_3
  · exact s00_4
  · exact s00_5
  · exact s00_6
  · exact s00_7
  · exact s00_8
  · exact s00_9
  · exact s00_10
  · exact s00_11
  · exact s00_12
  · exact s00_13
  · exact s00_14
  · exact s00_15
  · exact s00_16
  · exact s00_17
  · exact s00_18
  · exact s00_19
  · exact s00_20
  · exact s00_21
  · exact s00_22
  · exact s00_23
  · exact s00_24
  · exact s00_25
  · exact s00_26
  · exact s00_27

private theorem s01_0 : stripe 4 false true 3 34=true := by decide +kernel

private theorem s01_1 : stripe 4 false true 35 66=true := by decide +kernel

private theorem s01_2 : stripe 4 false true 67 98=true := by decide +kernel

private theorem s01_3 : stripe 4 false true 99 130=true := by decide +kernel

private theorem s01_4 : stripe 4 false true 131 162=true := by decide +kernel

private theorem s01_5 : stripe 4 false true 163 194=true := by decide +kernel

private theorem s01_6 : stripe 4 false true 195 226=true := by decide +kernel

private theorem s01_7 : stripe 4 false true 227 258=true := by decide +kernel

private theorem s01_8 : stripe 4 false true 259 290=true := by decide +kernel

private theorem s01_9 : stripe 4 false true 291 322=true := by decide +kernel

private theorem s01_10 : stripe 4 false true 323 354=true := by decide +kernel

private theorem s01_11 : stripe 4 false true 355 386=true := by decide +kernel

private theorem s01_12 : stripe 4 false true 387 418=true := by decide +kernel

private theorem part01 : Checked 4 false true := by
  intro j h
  change j≤12 at h
  interval_cases j
  · exact s01_0
  · exact s01_1
  · exact s01_2
  · exact s01_3
  · exact s01_4
  · exact s01_5
  · exact s01_6
  · exact s01_7
  · exact s01_8
  · exact s01_9
  · exact s01_10
  · exact s01_11
  · exact s01_12

private theorem s10_0 : stripe 4 true false 3 34=true := by decide +kernel

private theorem s10_1 : stripe 4 true false 35 66=true := by decide +kernel

private theorem s10_2 : stripe 4 true false 67 98=true := by decide +kernel

private theorem s10_3 : stripe 4 true false 99 130=true := by decide +kernel

private theorem s10_4 : stripe 4 true false 131 162=true := by decide +kernel

private theorem s10_5 : stripe 4 true false 163 194=true := by decide +kernel

private theorem s10_6 : stripe 4 true false 195 226=true := by decide +kernel

private theorem s10_7 : stripe 4 true false 227 258=true := by decide +kernel

private theorem s10_8 : stripe 4 true false 259 290=true := by decide +kernel

private theorem s10_9 : stripe 4 true false 291 322=true := by decide +kernel

private theorem s10_10 : stripe 4 true false 323 354=true := by decide +kernel

private theorem s10_11 : stripe 4 true false 355 386=true := by decide +kernel

private theorem s10_12 : stripe 4 true false 387 418=true := by decide +kernel

private theorem s10_13 : stripe 4 true false 419 450=true := by decide +kernel

private theorem s10_14 : stripe 4 true false 451 482=true := by decide +kernel

private theorem s10_15 : stripe 4 true false 483 514=true := by decide +kernel

private theorem part10 : Checked 4 true false := by
  intro j h
  change j≤15 at h
  interval_cases j
  · exact s10_0
  · exact s10_1
  · exact s10_2
  · exact s10_3
  · exact s10_4
  · exact s10_5
  · exact s10_6
  · exact s10_7
  · exact s10_8
  · exact s10_9
  · exact s10_10
  · exact s10_11
  · exact s10_12
  · exact s10_13
  · exact s10_14
  · exact s10_15

private theorem s11_0 : stripe 4 true true 3 34=true := by decide +kernel

private theorem s11_1 : stripe 4 true true 35 66=true := by decide +kernel

private theorem s11_2 : stripe 4 true true 67 98=true := by decide +kernel

private theorem s11_3 : stripe 4 true true 99 130=true := by decide +kernel

private theorem s11_4 : stripe 4 true true 131 162=true := by decide +kernel

private theorem s11_5 : stripe 4 true true 163 194=true := by decide +kernel

private theorem s11_6 : stripe 4 true true 195 226=true := by decide +kernel

private theorem s11_7 : stripe 4 true true 227 258=true := by decide +kernel

private theorem s11_8 : stripe 4 true true 259 290=true := by decide +kernel

private theorem s11_9 : stripe 4 true true 291 322=true := by decide +kernel

private theorem s11_10 : stripe 4 true true 323 354=true := by decide +kernel

private theorem s11_11 : stripe 4 true true 355 386=true := by decide +kernel

private theorem s11_12 : stripe 4 true true 387 418=true := by decide +kernel

private theorem s11_13 : stripe 4 true true 419 450=true := by decide +kernel

private theorem s11_14 : stripe 4 true true 451 482=true := by decide +kernel

private theorem s11_15 : stripe 4 true true 483 514=true := by decide +kernel

private theorem s11_16 : stripe 4 true true 515 546=true := by decide +kernel

private theorem s11_17 : stripe 4 true true 547 578=true := by decide +kernel

private theorem s11_18 : stripe 4 true true 579 610=true := by decide +kernel

private theorem s11_19 : stripe 4 true true 611 642=true := by decide +kernel

private theorem s11_20 : stripe 4 true true 643 674=true := by decide +kernel

private theorem s11_21 : stripe 4 true true 675 706=true := by decide +kernel

private theorem s11_22 : stripe 4 true true 707 738=true := by decide +kernel

private theorem s11_23 : stripe 4 true true 739 770=true := by decide +kernel

private theorem s11_24 : stripe 4 true true 771 802=true := by decide +kernel

private theorem s11_25 : stripe 4 true true 803 834=true := by decide +kernel

private theorem s11_26 : stripe 4 true true 835 866=true := by decide +kernel

private theorem s11_27 : stripe 4 true true 867 898=true := by decide +kernel

private theorem s11_28 : stripe 4 true true 899 930=true := by decide +kernel

private theorem s11_29 : stripe 4 true true 931 962=true := by decide +kernel

private theorem s11_30 : stripe 4 true true 963 994=true := by decide +kernel

private theorem s11_31 : stripe 4 true true 995 1026=true := by decide +kernel

private theorem s11_32 : stripe 4 true true 1027 1058=true := by decide +kernel

private theorem s11_33 : stripe 4 true true 1059 1090=true := by decide +kernel

private theorem s11_34 : stripe 4 true true 1091 1122=true := by decide +kernel

private theorem s11_35 : stripe 4 true true 1123 1154=true := by decide +kernel

private theorem s11_36 : stripe 4 true true 1155 1186=true := by decide +kernel

private theorem s11_37 : stripe 4 true true 1187 1218=true := by decide +kernel

private theorem s11_38 : stripe 4 true true 1219 1250=true := by decide +kernel

private theorem s11_39 : stripe 4 true true 1251 1282=true := by decide +kernel

private theorem s11_40 : stripe 4 true true 1283 1314=true := by decide +kernel

private theorem s11_41 : stripe 4 true true 1315 1346=true := by decide +kernel

private theorem s11_42 : stripe 4 true true 1347 1378=true := by decide +kernel

private theorem s11_43 : stripe 4 true true 1379 1410=true := by decide +kernel

private theorem s11_44 : stripe 4 true true 1411 1442=true := by decide +kernel

private theorem s11_45 : stripe 4 true true 1443 1474=true := by decide +kernel

private theorem part11 : Checked 4 true true := by
  intro j h
  change j≤45 at h
  interval_cases j
  · exact s11_0
  · exact s11_1
  · exact s11_2
  · exact s11_3
  · exact s11_4
  · exact s11_5
  · exact s11_6
  · exact s11_7
  · exact s11_8
  · exact s11_9
  · exact s11_10
  · exact s11_11
  · exact s11_12
  · exact s11_13
  · exact s11_14
  · exact s11_15
  · exact s11_16
  · exact s11_17
  · exact s11_18
  · exact s11_19
  · exact s11_20
  · exact s11_21
  · exact s11_22
  · exact s11_23
  · exact s11_24
  · exact s11_25
  · exact s11_26
  · exact s11_27
  · exact s11_28
  · exact s11_29
  · exact s11_30
  · exact s11_31
  · exact s11_32
  · exact s11_33
  · exact s11_34
  · exact s11_35
  · exact s11_36
  · exact s11_37
  · exact s11_38
  · exact s11_39
  · exact s11_40
  · exact s11_41
  · exact s11_42
  · exact s11_43
  · exact s11_44
  · exact s11_45

theorem closed {p q a k : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 3≤p)
    (oq : 3≤q) (pq : p≠q) (ha : 4≤a) :
    OeisA245212.a (2^k*p^a*q^4)≠(σ 1 (2^k*p^a*q^4):ℤ) := by
  apply of_tables hp hq op oq pq (by decide) (by decide) ha
  intro f v
  cases f <;> cases v
  · exact part00
  · exact part01
  · exact part10
  · exact part11

#print axioms closed
end OMA.SmallFourthBlocks245212
