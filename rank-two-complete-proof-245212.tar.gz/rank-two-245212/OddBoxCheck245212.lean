import OddBoxLogs245212

/-! Integer exterior tests. Every logarithmic endpoint is measured in
sixteenths of a binary logarithm. The final two endpoints allow either the
entire least-prime interval or any user-supplied subinterval. -/
namespace OMA.OddBox245212

def lowPrime (kl bl pl : ℕ) :=
  let l := max 13 (max pl (1+(kl-1)*(bl-1)/bl))
  l+(1-l%2)

def highPrime (kh ph : ℕ) := min ph (1+9*kh/4)

def compVeto (kl kh bl bh ch : ℕ) (x y : ℤ) : Bool :=
  let fst := up (2*ch*bh*kh)+2*x+(ch-1:ℕ)*y
  let snd := up (6*ch^2*bh)+16+max (up kh) x+2*(ch-1:ℕ)*y
  decide (2*ch+3≤bl ∧ max 0 (max fst snd)+up 3<16*(kl:ℤ))

structure Frame where
  kl : ℕ
  kh : ℕ
  bl : ℕ
  bh : ℕ
  cl : ℕ
  ch : ℕ
  lo : ℕ
  hi : ℕ

namespace Frame

def qlo (f : Frame) := f.lo+2
def xp (f : Frame) := (f.bl-1:ℕ)*down f.lo
def yq (f : Frame) := (f.cl-1:ℕ)*down f.qlo
def dz (f : Frame) : ℤ := 16*f.kh
def dg (f : Frame) : ℤ := 16*(f.kl-1:ℕ)
def cap (f : Frame) := f.dz+up (3*f.kh*f.bh)
def capY (f : Frame) := f.cap+(f.bh-1:ℕ)*up f.hi
def residue (f : Frame) := up (6*f.ch*f.bh*f.kh*f.hi^2)

def y (f : Frame) : ℤ :=
  let upper := roundedQuot f.capY (f.cl-2)
  let near := if f.dz+up (2*f.ch*f.kh)≤f.xp then min upper (f.dz+f.residue) else upper
  if max (up (f.ch*f.kh*f.bh*f.hi)-f.dg) (up (f.ch*f.kh)-f.xp)≤ -32 then
    min near f.residue else near

def normalized (f : Frame) := min (roundedQuot (2*f.cap-(f.cl-4:ℕ)*f.xp) (f.cl-2)) (2*f.y-f.xp)

def e1 (f : Frame) := up (f.kh*f.ch+f.hi)+f.normalized
def e2 (f : Frame) := 2*up f.hi+up (f.kh*f.bh+f.qlo)-f.yq
def e3 (f : Frame) := up (f.kh+f.hi*f.qlo)-f.xp-f.yq
def largest (f : Frame) := max f.e1 (max f.e2 f.e3)
def drift (f : Frame) := up (3*f.kh*f.bh*f.ch)+2*up f.hi+2*f.y-f.dg

def reject (f : Frame) : Bool :=
  decide (f.hi<f.lo ∨ f.capY<(f.cl-2:ℕ)*down f.qlo ∨
    f.cap<((f.cl:ℤ)-f.bh-1)*down f.qlo ∨ f.y<down f.qlo ∨
    f.dz+up (3*f.kh*f.ch)+(f.ch-1:ℕ)*f.y<(f.bl-2:ℕ)*down f.lo ∨
    up (3*f.bh*f.ch)+(f.bh-1:ℕ)*up f.hi+(f.ch-1:ℕ)*f.y<16*(f.kl:ℤ) ∨
    f.largest+up 3+f.dz<0 ∨ max f.largest f.drift+32<0) ||
    compVeto f.kl f.kh f.bl f.bh f.ch (up f.hi) f.y ||
    compVeto f.kl f.kh f.cl f.ch f.bh f.y (up f.hi)

end Frame

def veto (kl kh bl bh cl ch pl ph : ℕ) : Bool :=
  if 6≤kl ∧ 6≤bl ∧ 6≤cl then
    Frame.reject ⟨kl,kh,bl,bh,cl,ch,lowPrime kl bl pl,highPrime kh ph⟩
  else false

end OMA.OddBox245212
