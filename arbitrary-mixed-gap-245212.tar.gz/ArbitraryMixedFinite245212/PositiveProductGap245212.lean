import Mathlib

/-! A uniform one-sided integer gap for any number of factors of the form
g*z+1. The multiplier depends on the coefficients and the number of factors,
but not on the positive variables z or the numerator U. -/
namespace OMA.PositiveProductGap245212
open Finset
variable {ι : Type*} [DecidableEq ι]

def cost : ℕ → ℕ → ℕ
  | 0,_ => 1
  | n+1,A => 2*(A+1)*cost n (2*(A+1)^2)

private theorem cost_pos (n A : ℕ) : 0<cost n A := by
  induction n generalizing A with
  | zero => simp [cost]
  | succ n ih => exact Nat.mul_pos (by positivity) (ih _)

private theorem error {s : Finset ι} (g z : ι→ℕ) (m : ℕ)
    (lower : ∀i∈s, m≤z i) (positive : ∀i∈s, 0<z i) :
    let P:=∏i∈s,z i
    let Q:=∏i∈s,(g i*z i+1)
    let c:=∏i∈s,g i
    let A:=∏i∈s,(g i+1)
    c*P ≤ Q ∧ Q ≤ A*P ∧ m*Q ≤ m*(c*P)+A*P := by
  induction s using Finset.induction_on with
  | empty => simp
  | @insert i s hi ih =>
    have lo:=lower i (mem_insert_self ..)
    have po:=positive i (mem_insert_self ..)
    obtain ⟨lb,ub,err⟩:=ih (fun j hj=>lower j (mem_insert_of_mem hj))
      (fun j hj=>positive j (mem_insert_of_mem hj))
    simp only [prod_insert hi]
    refine ⟨?_,?_,?_⟩
    · have h:=Nat.mul_le_mul (Nat.le_succ (g i*z i)) lb
      simpa only [mul_comm,mul_assoc,mul_left_comm] using h
    · have h:=Nat.mul_le_mul (show g i*z i+1≤(g i+1)*z i by nlinarith only [po]) ub
      simpa only [mul_comm,mul_assoc,mul_left_comm] using h
    · have h:=Nat.mul_le_mul_left (g i*z i) err
      have small:=Nat.mul_le_mul lo ub
      nlinarith only [h,small]

theorem gap (n A : ℕ) (s : Finset ι) (g z : ι→ℕ) {U V R : ℕ}
    (count : s.card=n) (pos : ∀i∈s,0<z i) (rp : 0<R)
    (budget : V*(∏i∈s,(g i+1))≤A)
    (eqn : U*(∏i∈s,z i)=R+V*(∏i∈s,(g i*z i+1))) :
    (∏i∈s,z i)≤cost n A*R := by
  induction n generalizing A s U V with
  | zero =>
    have empty:=Finset.card_eq_zero.mp count
    simpa [empty,cost] using (show 1≤R from rp)
  | succ n ih =>
    by_cases small : ∃i∈s,z i≤2*(A+1)
    · obtain ⟨i,mem,lim⟩:=small
      let t:=s.erase i
      have mult (x : ι→ℕ) : x i*(∏j∈t,x j)=∏j∈s,x j := by
        rw [mul_comm];exact prod_erase_mul _ _ mem
      have zp:=pos i mem
      have cb : (V*(g i*z i+1))*(∏j∈t,(g j+1))≤2*(A+1)^2 := calc
        _ ≤ z i*(V*(∏j∈s,(g j+1))) := by
          rw [←mult (fun j=>g j+1)]
          have h:=Nat.mul_le_mul_left (V*(∏j∈t,(g j+1)))
            (show g i*z i+1≤z i*(g i+1) by nlinarith only [zp])
          simpa only [mul_comm,mul_assoc,mul_left_comm] using h
        _ ≤ 2*(A+1)*(A+1) := Nat.mul_le_mul lim (budget.trans (Nat.le_succ _))
        _ = _ := by ring
      have eq : (U*z i)*(∏j∈t,z j)=R+(V*(g i*z i+1))*(∏j∈t,(g j*z j+1)) := by
        rw [Nat.mul_assoc,Nat.mul_assoc,mult z,mult (fun j=>g j*z j+1)]
        exact eqn
      have smaller:=ih (2*(A+1)^2) t (by dsimp [t];rw [card_erase_of_mem mem,count];omega)
        (fun j hj=>pos j (mem_of_mem_erase hj)) cb eq
      rw [←mult z]
      exact (Nat.mul_le_mul lim smaller).trans_eq (by simp only [cost,Nat.mul_assoc])
    · have lo i (mem:i∈s) : 2*(A+1)≤z i:=by
        have no : ¬z i≤2*(A+1):=fun h=>small ⟨i,mem,h⟩
        omega
      obtain ⟨lb,_,err⟩:=error g z (2*(A+1)) lo pos
      let P:=∏i∈s,z i
      let Q:=∏i∈s,(g i*z i+1)
      let c:=∏i∈s,g i
      let B:=∏i∈s,(g i+1)
      change c*P≤Q at lb
      change 2*(A+1)*Q≤2*(A+1)*(c*P)+B*P at err
      change U*P=R+V*Q at eqn
      have uc : V*c<U := by
        by_contra! rev
        have h:=Nat.mul_le_mul_right P rev
        have l:=Nat.mul_le_mul_left V lb
        nlinarith only [h,l,eqn,rp]
      have h:=Nat.mul_le_mul_right P (Nat.succ_le_of_lt uc)
      have extra:=Nat.mul_le_mul_left V err
      have cap:=Nat.mul_le_mul_right P budget
      change V*B*P≤A*P at cap
      have joined:=Nat.mul_le_mul_left (2*(A+1)) h
      have id:=congrArg (2*(A+1)*·) eqn
      have pr : P≤2*R := by
        by_contra! bad
        have worse:=Nat.mul_lt_mul_of_pos_left bad (Nat.succ_pos A)
        nlinarith only [extra,cap,joined,id,worse,Nat.zero_le P]
      change P≤cost (n+1) A*R
      have big : 2≤cost (n+1) A:=
        calc
          2 ≤ 2*(A+1) := by omega
          _ ≤ _ := Nat.le_mul_of_pos_right _ (cost_pos n _)
      exact pr.trans (Nat.mul_le_mul_right R big)

#print axioms gap
end OMA.PositiveProductGap245212
