import PositiveProductGap245212
import ComplementaryLocal245212
import PrimePowerDiv245212

/-! Quantitative separation below rational targets for products of normalized
weighted divisor sums. The bound does not contain any prime power. -/
namespace OMA.WeightedUpperGap245212
open Nat Finset ArithmeticFunction OMA.Smooth245212
open scoped ArithmeticFunction.sigma
variable {ι : Type*} [DecidableEq ι]

def mass (p e : ℕ) := (e+1)*p^e
def coeff (p e : ℕ) := p*((e+1)*(p-1)-1)
def boundedCost (r V T B : ℕ) :=
  (T^r*(B^2)^r)*OMA.PositiveProductGap245212.cost r (V*(B*(T*B)+1)^r)

theorem local_moment {p : ℕ} (pr : p.Prime) (e : ℕ) :
    (p-1)^2*W (p^e)=coeff p e*p^e+1 := by
  have base : 1≤(e+1)*(p-1):=Nat.mul_pos (Nat.succ_pos _) (Nat.sub_pos_of_lt pr.one_lt)
  unfold coeff
  zify [Nat.cast_sub pr.pos,Nat.cast_sub base]
  exact (OMA.ComplementaryLocal245212.moments pr e).2

theorem bounded {s : Finset ι} (p e : ι→ℕ) (V U R T B : ℕ)
    (pr : ∀i∈s,(p i).Prime) (base : ∀i∈s,p i≤B) (len : ∀i∈s,e i+1≤T) (rp : 0<R)
    (eqn : U*(∏i∈s,mass (p i) (e i))=R+V*(∏i∈s,W ((p i)^(e i)))) :
    (∏i∈s,mass (p i) (e i))≤boundedCost s.card V T B*R := by
  let z i:=p i^e i
  let g i:=coeff (p i) (e i)
  let L:=∏i∈s,(p i-1)^2
  let M:=∏i∈s,(e i+1)
  let P:=∏i∈s,z i
  let Wp:=∏i∈s,W (p i^e i)
  have mass_eq : (∏i∈s,mass (p i) (e i))=M*P:=by simp only [mass,prod_mul_distrib,M,P,z]
  have weights : L*Wp=∏i∈s,(g i*z i+1):=by
    dsimp only [L,Wp]
    rw [←prod_mul_distrib]; exact prod_congr rfl (fun i hi=>local_moment (pr i hi) _)
  have lpos : 0<L:=prod_pos fun i hi=>pow_pos (Nat.sub_pos_of_lt (pr i hi).one_lt) _
  have gb : V*(∏i∈s,(g i+1))≤V*(B*(T*B)+1)^s.card:=by
    apply Nat.mul_le_mul_left
    calc
      _ ≤ ∏_i∈s,(B*(T*B)+1) := by
        apply prod_le_prod'
        intro i hi
        exact Nat.succ_le_succ (Nat.mul_le_mul (base i hi) ((Nat.sub_le _ _).trans
          (Nat.mul_le_mul (len i hi) ((Nat.sub_le _ _).trans (base i hi)))))
      _ = _ := by simp
  have gap : (U*L*M)*P=L*R+V*(∏i∈s,(g i*z i+1)):=by
    rw [←weights]
    rw [mass_eq] at eqn
    change U*(M*P)=R+V*Wp at eqn
    nlinarith only [congrArg (L*·) eqn]
  have res:=OMA.PositiveProductGap245212.gap _ _ s g z rfl
    (fun i hi=>pow_pos (pr i hi).pos _) (Nat.mul_pos lpos rp) gb gap
  have lcap : L≤(B^2)^s.card:=calc
    L ≤ ∏_i∈s,B^2 := prod_le_prod' fun i hi=>Nat.pow_le_pow_left ((Nat.sub_le _ _).trans (base i hi)) _
    _ = _ := by simp
  have mcap : M≤T^s.card:=calc
    M ≤ ∏_i∈s,T := prod_le_prod' len
    _ = _ := by simp
  rw [mass_eq]
  have out:=Nat.mul_le_mul mcap res
  let C:=OMA.PositiveProductGap245212.cost s.card (V*(B*(T*B)+1)^s.card)
  change M*P≤T^s.card*(C*(L*R)) at out
  exact out.trans (by
    have h:=Nat.mul_le_mul_left (T^s.card*C*R) lcap
    simpa only [boundedCost,C,mul_assoc,mul_comm,mul_left_comm] using h)

theorem local_range {p : ℕ} (pr : p.Prime) (e : ℕ) :
    mass p e≤W (p^e) ∧ (p-1)*W (p^e)≤p*mass p e ∧ W (p^e)≤2*mass p e := by
  have identity:=OMA.PrimePowerDiv245212.weighted pr e
  have lower : mass p e≤W (p^e):=by
    rw [w_pow pr];unfold mass
    simpa only [mul_comm] using single_le_sum (f:=fun i=>p^i*(i+1)) (fun i _=>Nat.zero_le _)
      (mem_range.mpr (Nat.lt_succ_self e))
  have upper : (p-1)*W (p^e)≤p*mass p e:=by dsimp [mass];omega
  have nz : 0<p-1:=Nat.sub_pos_of_lt pr.one_lt
  have p2 : p≤(p-1)*2:=by omega
  have h:=upper.trans (Nat.mul_le_mul_right (mass p e) p2)
  exact ⟨lower,upper,Nat.le_of_mul_le_mul_left (by simpa only [mul_assoc] using h) nz⟩

-- The rank-r target gap survives adding one sufficiently large prime.
theorem large_step {U V A T x y p K E R : ℕ}
    (left : U*T=E+V*A) (coarse : A≤T*(2^p))
    (old : T≤K*E) {prime : ℕ} (strong : 2*K*V*2^p≤prime-1)
    (massbound : (prime-1)*y≤prime*x) (pr : 2≤prime)
    (full : U*(T*x)=R+V*(A*y)) : T*x≤(2*K)*R := by
  have den : 0<prime-1:=by omega
  have add:=Nat.sub_add_cancel (show 1≤prime by omega)
  have localDiff : (prime-1)*y≤(prime-1)*x+x:=by nlinarith only [massbound,congrArg (·*x) add]
  have rem:=Nat.mul_le_mul_left (V*A) localDiff
  have e:=congrArg (·*((prime-1)*x)) left
  have f:=congrArg ((prime-1)*·) full
  have gap : (prime-1)*E*x ≤ (prime-1)*R + V*A*x:=by nlinarith only [rem,e,f]
  have h:=Nat.mul_le_mul_left ((prime-1)*x) old
  have b:=Nat.mul_le_mul_left K gap
  have err:=Nat.mul_le_mul_left (2*K*V*x) coarse
  have top:=Nat.mul_le_mul_right (T*x) strong
  have goal : (prime-1)*(T*x)≤(prime-1)*((2*K)*R) := by
    nlinarith only [h,b,err,top]
  exact Nat.le_of_mul_le_mul_left goal den

#print axioms bounded
end OMA.WeightedUpperGap245212
