import WeightedUpperGap245212

/-! A rational strictly above the normalized weighted moment is separated
from it independently of all the prime bases and prime powers. -/
namespace OMA.WeightedUniformGap245212
open Nat Finset ArithmeticFunction OMA.Smooth245212 OMA.WeightedUpperGap245212
open scoped ArithmeticFunction.sigma
variable {ι : Type*} [DecidableEq ι]

def cutoff (r x K : ℕ) := 2*K*x*2^r+2
def constant : ℕ→ℕ→ℕ
  | 0,_ => 1
  | r+1,x => let K:=constant r x; 2*K+boundedCost (r+1) x x (cutoff r x K)

theorem cost_mono (n : ℕ) : Monotone (OMA.PositiveProductGap245212.cost n) := by
  induction n with
  | zero => intro _ _ _;rfl
  | succ n ih =>
    intro a b le
    dsimp only [OMA.PositiveProductGap245212.cost]
    exact Nat.mul_le_mul (Nat.mul_le_mul_left 2 (Nat.succ_le_succ le))
      (ih (Nat.mul_le_mul_left 2 (Nat.pow_le_pow_left (Nat.succ_le_succ le) 2)))

theorem bound (n x : ℕ) (s : Finset ι) (p e : ι→ℕ) {U V R : ℕ}
    (count : s.card=n) (pr : ∀i∈s,(p i).Prime) (len : ∀i∈s,e i+1≤x)
    (vx : V≤x) (rp : 0<R)
    (eqn : U*(∏i∈s,mass (p i) (e i))=R+V*(∏i∈s,W ((p i)^(e i)))) :
    (∏i∈s,mass (p i) (e i))≤constant n x*R := by
  induction n generalizing s R with
  | zero =>
    have empty:=card_eq_zero.mp count
    simpa [empty,constant] using (show 1≤R from rp)
  | succ n ih =>
    let K:=constant n x
    let B:=cutoff n x K
    by_cases low : ∀i∈s,p i≤B
    · have h:=bounded p e V U R x B pr low len rp eqn
      rw [count] at h
      have c : boundedCost (n+1) V x B ≤ boundedCost (n+1) x x B := by
        unfold boundedCost
        exact Nat.mul_le_mul_left _ (cost_mono _ (Nat.mul_le_mul_right _ vx))
      exact h.trans (Nat.mul_le_mul_right R (c.trans (Nat.le_add_left _ _)))
    push Not at low
    obtain ⟨i,mem,high⟩:=low
    let t:=s.erase i
    have card : t.card=n:=by dsimp [t];rw [card_erase_of_mem mem,count];omega
    let M j:=mass (p j) (e j)
    let A j:=W ((p j)^(e j))
    let P:=∏j∈t,M j
    let Q:=∏j∈t,A j
    have combine (f : ι→ℕ) : (∏j∈t,f j)*f i=∏j∈s,f j := prod_erase_mul _ _ mem
    change U*(∏j∈s,M j)=R+V*(∏j∈s,A j) at eqn
    rw [←combine M,←combine A] at eqn
    change U*(P*M i)=R+V*(Q*A i) at eqn
    have loc:=local_range (pr i mem) (e i)
    change M i≤A i ∧ (p i-1)*A i≤p i*M i ∧ _ at loc
    have pv : V*Q<U*P:=by
      by_contra! bad
      have h:=Nat.mul_le_mul bad loc.1
      nlinarith only [h,eqn,rp]
    let E:=U*P-V*Q
    have ep : 0<E:=Nat.sub_pos_of_lt pv
    have prev : U*P=E+V*Q:=(Nat.sub_add_cancel pv.le).symm
    have old : P≤K*E:=ih t card (fun j mj=>pr j (mem_of_mem_erase mj))
      (fun j mj=>len j (mem_of_mem_erase mj)) ep prev
    have coarse : Q≤P*2^n:=calc
      Q ≤ ∏j∈t,(2*M j) := prod_le_prod' fun j hj=>(local_range (pr j (mem_of_mem_erase hj)) (e j)).2.2
      _ = _ := by simp [prod_mul_distrib,card,P,mul_comm]
    have strong : 2*K*V*2^n≤p i-1:=by
      change 2*K*x*2^n+2<p i at high
      have h:=Nat.mul_le_mul_right (2^n) (Nat.mul_le_mul_left (2*K) vx)
      omega
    have lift:=large_step prev coarse old strong loc.2.1 (pr i mem).two_le eqn
    change (∏j∈s,M j)≤_
    rw [←combine M]
    exact lift.trans (Nat.mul_le_mul_right R (Nat.le_add_right _ _))

#print axioms bound
end OMA.WeightedUniformGap245212
