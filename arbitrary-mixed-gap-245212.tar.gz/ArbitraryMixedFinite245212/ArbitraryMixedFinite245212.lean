import ArbitraryMixedGap245212
import ComplementarySize245212

/-! Absolute length bound for an exact physical rounding with one retained
prime, any number of exact primes, and any number of discarded primes. -/
namespace OMA.ArbitraryMixedFinite245212
noncomputable section
open Nat ArithmeticFunction OMA.ArbitraryMixedGap245212 OMA.WeightedGapPolynomial245212
open OMA.Smooth245212 (W)
open scoped ArithmeticFunction.sigma

def cutoff (r D : ℕ) :=
  let F:=poly r
  let a:=F.eval 1+1
  let d:=F.natDegree
  a*(16*(d*D+1)^2+2*(a*D)+6)^d

theorem bounded {h q B C r D : ℕ} (pos : 0<h) (rank : h.primeFactors.card≤r)
    (qg : 2≤q) (bp : 0<B) (cp : 0<C) (small : h≤(B+1)^D)
    (side : C*W h<(q-1)*σ 1 h)
    (hit : (2*h*σ 0 h)*B*C*(q-1)^2=q*(W h*C*(B*(q-1)-1)+σ 1 h*(q-1))) :
    B≤cutoff r D := by
  let l:=Nat.log 2 h
  let F:=poly r
  let d:=F.natDegree
  let a:=F.eval 1+1
  let y:=l+3
  have base : B≤F.eval 1*y^d:=(mixed pos rank qg bp cp side hit).trans (eval_height _ _)
  have plus : B+1≤a*y^d:=by
    have one:=Nat.one_le_pow d y (by dsimp [y];omega)
    dsimp only [a];nlinarith only [base,one]
  have pot : 2^l≤2^(a*D)*y^(d*D):=calc
    _ ≤ h := Nat.pow_log_le_self 2 pos.ne'
    _ ≤ (B+1)^D := small
    _ ≤ (a*y^d)^D := Nat.pow_le_pow_left plus _
    _ = a^D*y^(d*D) := by rw [mul_pow,pow_mul]
    _ ≤ _ := by
      rw [pow_mul (2:ℕ) a D]
      exact Nat.mul_le_mul_right _ (Nat.pow_le_pow_left (Nat.lt_pow_self (by decide : 1<(2:ℕ))).le _)
  have bound : y≤16*(d*D+1)^2+2*(a*D)+6:=by
    by_cases big : 16*(d*D+1)^2≤y
    · have absorb:=OMA.ComplementarySize245212.absorb big
      have square:=Nat.pow_le_pow_left pot 2
      have hsq : (2^(a*D)*y^(d*D))^2=2^(2*(a*D))*y^(2*(d*D)):=by
        rw [mul_pow,←pow_mul,←pow_mul,Nat.mul_comm (a*D) 2,Nat.mul_comm (d*D) 2]
      have joined : 2^(2*l)≤2^(2*(a*D)+y):=by
        rw [pow_add]
        rw [hsq,←pow_mul,Nat.mul_comm l 2] at square
        exact square.trans (Nat.mul_le_mul_left _ absorb)
      have exp:=(pow_le_pow_iff_right₀ (a:=(2:ℕ)) (by decide)).mp joined
      dsimp only [y] at exp ⊢;omega
    · omega
  exact (Nat.le_succ B).trans (plus.trans (Nat.mul_le_mul_left a (Nat.pow_le_pow_left bound d)))

#print axioms bounded
end
end OMA.ArbitraryMixedFinite245212
