import WeightedGapPolynomial245212
import CofactorCrossOriginal245212

/-! Removal of all cofactor prime bases from the pole bound of a retained
prime. The remaining exponent is polynomially bounded in log of the cofactor. -/
namespace OMA.ArbitraryMixedGap245212
noncomputable section
open Nat Finset ArithmeticFunction Polynomial OMA.WeightedGapPolynomial245212
open OMA.Smooth245212 (W)
open scoped ArithmeticFunction.sigma
open private OMA.CofactorCrossOriginal245212.sigma_bound from CofactorCrossOriginal245212

def poly (r : ℕ) : Polynomial ℕ :=
  let K:=2*envelope r
  2*K+2*K*(2*(envelope r).comp (X+2*K))

private theorem equations {H A S B C q u : ℕ} (qv : q=u+1) (up : 0<u)
    (bp : 0<B) (cp : 0<C) (ss : S≤H) (side : C*A<u*S)
    (hit : H*B*C*u^2=q*(A*C*(B*u-1)+S*u)) :
    ∃ E Δ : ℕ, 0<E ∧ 0<Δ ∧ E+q*A=u*H ∧ Δ+A=H ∧ B*E≤q*H ∧ q*Δ=E+H := by
  have qp : 0<q:=by omega
  have bu:=Nat.sub_add_cancel (show 1≤B*u from Nat.mul_pos bp up)
  have raw : B*u*C*(H*u)+q*(A*C)=B*u*C*(A*q)+q*(u*S):=by
    nlinarith only [hit,congrArg (fun z : ℕ=>q*(A*C)*z) bu]
  have strict : A*q<H*u:=by
    by_contra! no
    have low:=Nat.mul_le_mul_left (B*u*C) no
    have sign:=Nat.mul_lt_mul_of_pos_left side qp
    nlinarith only [raw,low,sign]
  have ah : A<H:=by
    by_contra! no
    have bad:=Nat.mul_le_mul_right u no
    rw [qv,Nat.mul_add,Nat.mul_one] at strict
    omega
  let E:=H*u-A*q
  let Δ:=H-A
  have ee : E+q*A=u*H:=by
    dsimp only [E];rw [Nat.mul_comm q A,Nat.mul_comm u H,Nat.sub_add_cancel strict.le]
  have de : Δ+A=H:=Nat.sub_add_cancel ah.le
  have prod : B*u*C*E+q*(A*C)=q*(u*S):=by
    nlinarith only [raw,congrArg (fun z : ℕ=>B*u*C*z) ee]
  have main : (B*E*C)*u≤(q*S)*u:=by nlinarith only [prod,Nat.zero_le (q*(A*C))]
  have bare:=Nat.le_of_mul_le_mul_right main up
  refine ⟨E,Δ,Nat.sub_pos_of_lt strict,Nat.sub_pos_of_lt ah,ee,de,
    (Nat.le_mul_of_pos_right _ cp).trans (bare.trans (Nat.mul_le_mul_left q ss)),?_⟩
  nlinarith only [ee,congrArg (q*·) de,congrArg (·*H) qv]

theorem mixed {h q B C r : ℕ} (pos : 0<h) (rank : h.primeFactors.card≤r)
    (qg : 2≤q) (bp : 0<B) (cp : 0<C)
    (side : C*W h<(q-1)*σ 1 h)
    (hit : (2*h*σ 0 h)*B*C*(q-1)^2=q*(W h*C*(B*(q-1)-1)+σ 1 h*(q-1))) :
    B≤(poly r).eval (Nat.log 2 h+2) := by
  let x:=Nat.log 2 h+2
  let H:=2*(h*σ 0 h)
  let K:=2*(envelope r).eval x
  have lengths (p) (mem:p∈h.primeFactors) : h.factorization p+1≤x:=by
    have pow : 2^h.factorization p≤h:=(Nat.pow_le_pow_left (prime_of_mem_primeFactors mem).two_le _).trans
      (Nat.le_of_dvd pos (Nat.ordProj_dvd h p))
    have log:=Nat.le_log_of_pow_le (by decide : 1<(2:ℕ)) pow
    dsimp [x];omega
  have ss : σ 1 h≤H:=(OMA.CofactorCrossOriginal245212.sigma_bound pos).trans (by dsimp [H];omega)
  obtain ⟨E,Δ,ep,dp,ee,de,sb,id⟩:=equations (H:=H) (u:=q-1) (q:=q) (by omega) (by omega)
    bp cp ss side (by simpa only [H,mul_assoc] using hit)
  have rel (v t y z : ℕ) (yp : 0<y) (vz : v≤z) (xz : x≤z) (eqn : y+v*W h=t*H) :
      H≤(2*(envelope r).eval z)*y:=by
    have e : (t*2)*(h*σ 0 h)=y+v*W h:=by
      simpa only [H,mul_assoc] using eqn.symm
    have g:=OMA.WeightedGapPolynomial245212.original pos rank (fun p m=>(lengths p m).trans xz) vz yp e
    simpa only [H,mul_assoc] using Nat.mul_le_mul_left 2 g
  have first : H≤K*Δ:=rel 1 1 Δ x dp (by dsimp [x];omega) le_rfl (by simpa using de)
  change B≤(poly r).eval x
  simp only [poly,eval_add,eval_mul,eval_ofNat,eval_comp,eval_X]
  change B≤2*K+2*K*(2*(envelope r).eval (x+2*K))
  by_cases large : 2*K≤q
  · have high:=Nat.mul_le_mul_right Δ large
    have bound : q*Δ≤2*E:=by nlinarith only [high,id,first]
    have hq:=Nat.mul_le_mul_left q first
    have b:=Nat.mul_le_mul_left K bound
    have fin : B*E≤(2*K)*E:=by nlinarith only [sb,hq,b]
    exact (Nat.le_of_mul_le_mul_right fin ep).trans (Nat.le_add_right _ _)
  · have qz : q≤x+2*K:=by omega
    have close:=rel q (q-1) E (x+2*K) ep qz (Nat.le_add_right _ _) ee
    have hq:=Nat.mul_le_mul_left q close
    have fin : B*E≤(q*(2*(envelope r).eval (x+2*K)))*E:=by
      simpa only [mul_assoc] using sb.trans hq
    exact (Nat.le_of_mul_le_mul_right fin ep).trans
      ((Nat.mul_le_mul_right _ (by omega : q≤2*K)).trans (Nat.le_add_left _ _))

#print axioms mixed
end
end OMA.ArbitraryMixedGap245212
