import WeightedUniformGap245212

/-! A single polynomial controls every cofactor of bounded rank, without
fixing its bases, exponents, or numerator of the rational target. -/
namespace OMA.WeightedGapPolynomial245212
noncomputable section
open Nat Finset ArithmeticFunction Polynomial OMA.WeightedUpperGap245212
open OMA.Smooth245212 (W w_mult)
open scoped ArithmeticFunction.sigma Function

def localCost : ℕ→Polynomial ℕ→Polynomial ℕ
  | 0,_ => 1
  | n+1,A => 2*(A+1)*localCost n (2*(A+1)^2)

def fixed : ℕ→Polynomial ℕ
  | 0 => 1
  | r+1 => let K:=fixed r; let B:=2*K*X*2^r+2
           2*K+(X^(r+1)*(B^2)^(r+1))*localCost (r+1) (X*(B*(X*B)+1)^(r+1))

def envelope (r : ℕ) : Polynomial ℕ := ∑j∈range (r+1),fixed j

theorem evaluate_local (n x : ℕ) (A : Polynomial ℕ) :
    (localCost n A).eval x=OMA.PositiveProductGap245212.cost n (A.eval x) := by
  induction n generalizing A with
  | zero => simp [localCost,OMA.PositiveProductGap245212.cost]
  | succ n ih => simp [localCost,OMA.PositiveProductGap245212.cost,ih]

theorem evaluate_fixed (r x : ℕ) : (fixed r).eval x=OMA.WeightedUniformGap245212.constant r x := by
  induction r with
  | zero => simp [fixed,OMA.WeightedUniformGap245212.constant]
  | succ r ih => simp [fixed,evaluate_local,ih,OMA.WeightedUniformGap245212.constant,
      OMA.WeightedUniformGap245212.cutoff,boundedCost]

theorem monotone_eval (P : Polynomial ℕ) : Monotone P.eval := by
  intro a b le
  simp only [eval_eq_sum,Polynomial.sum]
  exact sum_le_sum (fun i _=>Nat.mul_le_mul_left _ (Nat.pow_le_pow_left le i))

theorem eval_height (P : Polynomial ℕ) (x : ℕ) :
    P.eval x≤P.eval 1*(x+1)^P.natDegree := by
  rw [eval_eq_sum,eval_eq_sum]
  simp only [Polynomial.sum,one_pow,mul_one,sum_mul]
  refine sum_le_sum fun i hi=>Nat.mul_le_mul_left _ ?_
  exact (Nat.pow_le_pow_left (Nat.le_succ _) i).trans
    (Nat.pow_le_pow_right (Nat.succ_pos _) (P.le_natDegree_of_mem_supp i hi))

theorem original {h U V R r x : ℕ} (hp : 0<h) (rank : h.primeFactors.card≤r)
    (len : ∀p∈h.primeFactors,h.factorization p+1≤x) (vx : V≤x) (rp : 0<R)
    (eqn : U*(h*σ 0 h)=R+V*W h) : h*σ 0 h≤(envelope r).eval x*R := by
  let s:=h.primeFactors
  let z (p:ℕ):=p^h.factorization p
  have repr : h=∏p∈s,z p:=Nat.prod_primeFactors_pow_factorization hp.ne'
  have pr (p) (mp:p∈s) := prime_of_mem_primeFactors mp
  have pair : (s:Set ℕ).Pairwise (Coprime on z):=by
    intro p mp q mq ne
    exact (((coprime_primes (pr p mp) (pr q mq)).mpr ne).pow_left _).pow_right _
  have weight:=IsMultiplicative.map_prod z w_mult s pair
  have tau:=IsMultiplicative.map_prod z (isMultiplicative_sigma (k:=0)) s pair
  rw [←repr] at weight tau
  have lengths : (∏p∈s,(h.factorization p+1))=σ 0 h := by
    rw [tau]
    exact prod_congr rfl (fun p mp=>(sigma_zero_apply_prime_pow (pr p mp)).symm)
  have mass_eq : (∏p∈s,mass p (h.factorization p))=h*σ 0 h := by
    simp only [mass,prod_mul_distrib]
    change (∏p∈s,(h.factorization p+1))*(∏p∈s,z p)=_
    rw [lengths,←repr,mul_comm]
  have ineq:=OMA.WeightedUniformGap245212.bound s.card x s id (fun p=>h.factorization p)
    (U:=U) rfl pr len vx rp (by
      change U*(∏i∈s,mass i (h.factorization i))=R+V*(∏i∈s,W (z i))
      rwa [mass_eq,←weight])
  change (∏p∈s,mass p (h.factorization p))≤_ at ineq
  rw [mass_eq] at ineq
  have inc : (fixed s.card).eval x≤(envelope r).eval x:=by
    simp only [envelope,eval_finsetSum]
    exact single_le_sum (f:=fun j=>(fixed j).eval x) (fun _ _=>Nat.zero_le _)
      (mem_range.mpr (Nat.lt_succ_of_le rank))
  rw [evaluate_fixed] at inc
  exact ineq.trans (Nat.mul_le_mul_right R inc)

#print axioms original
end
end OMA.WeightedGapPolynomial245212
