import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S63409
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b63409 : Box := ![⟨127,152⟩,⟨36,41⟩,⟨12,14⟩,⟨1,53⟩,⟨959,999999999999999999⟩]
private def b63410 : Box := ![⟨127,152⟩,⟨36,41⟩,⟨12,14⟩,⟨1,46⟩,⟨959,1918⟩]
private def b63421 : Box := ![⟨127,152⟩,⟨36,41⟩,⟨12,14⟩,⟨1,46⟩,⟨1919,999999999999999999⟩]
private theorem e63410 : Deny 5 13 b63410 := by
    apply closeAction rule_sound _ _ 64 [0x20e31f80f89c38c78c80c3e278c88c99e3]
    decide +kernel
private theorem e63421 : Deny 5 13 b63421 := by
    apply closeAction rule_sound _ _ 64 [0xc38c70e70f88c78c80f89e3088e23263]
    decide +kernel
private theorem e63409 : Deny 5 13 b63409 :=
    branchAction rule_sound _ _ 2
      0x2e3 b63409 b63410 b63421 (by decide +kernel) e63410 e63421
theorem deny5_13 : Deny 5 13 ![⟨127,152⟩,⟨36,41⟩,⟨12,14⟩,⟨1,53⟩,⟨959,999999999999999999⟩] := by
  exact e63409
end OMA.Blocks5_13_245212.S63409
