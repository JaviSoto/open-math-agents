import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S61254
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b61254 : Box := ![⟨54,62⟩,⟨63,126⟩,⟨21,30⟩,⟨1,65⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨54,62⟩,⟨63,126⟩,⟨21,30⟩,⟨1,65⟩,⟨479,999999999999999999⟩] := by
  have e61254 : Deny 5 13 b61254 := by
    apply closeAction rule_sound _ _ 64 [0xdc38c88c98c88cb0c31c30f88c88c88df7d728a5ca8cb8c98c78c88c25f8dd7e375f70c38c88c88d7dcb8c98c78c88cb,0xe020f88c7e030e3223223097e370c78c88cb8c90820f81f88c9e030e32030e32232637df5ca2972a32e3223097e370f8,0x2082083e232380f80e32078c2083e232381e32f88c8e232788c7e020820f88c9e231f88c8]
    decide +kernel
  exact e61254
end OMA.Blocks5_13_245212.S61254
