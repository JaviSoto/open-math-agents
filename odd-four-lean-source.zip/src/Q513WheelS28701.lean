import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S28701
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b28701 : Box := ![⟨31,37⟩,⟨127,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨1,1466112759643916922660⟩,⟨239,478⟩]
theorem deny5_13 : Deny 5 13 ![⟨31,37⟩,⟨127,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨1,1466112759643916922660⟩,⟨239,478⟩] := by
  have e28701 : Deny 5 13 b28701 := by
    apply closeAction rule_sound _ _ 64 [0x2421f8da12a32236ab8c47ab8c4238ade59e59f0f884784984a58a8497c21f8ae126a84a8c810b8c75aa84a5aa84a8c9,0x58a8c88c9e1e7a22b858a8c88c7e162962827ab8c4238ae37a32388df84ae1aadeae322b7967c2107e2125f087e37da1,0x209e58a8c98c42388d6e378c2ade]
    decide +kernel
  exact e28701
end OMA.Blocks5_13_245212.S28701
