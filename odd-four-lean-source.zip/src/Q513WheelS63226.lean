import FastReplay245212
import SparseDigit245212
import WheelRule245212

import Q513MicroS63229
import Q513MicroS63254
import Q513MicroS63279
import Q513MicroS63298
import Q513MicroS63327
import Q513MicroS63347
import Q513MicroS63372
import Q513MicroS63381
import Q513MicroS63409
import Q513MicroS63432

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S63226
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b63226 : Box := ![⟨127,190⟩,⟨31,41⟩,⟨10,14⟩,⟨1,59⟩,⟨479,999999999999999999⟩]
private def b63227 : Box := ![⟨127,190⟩,⟨31,41⟩,⟨10,14⟩,⟨1,59⟩,⟨479,958⟩]
private def b63228 : Box := ![⟨127,190⟩,⟨31,41⟩,⟨10,11⟩,⟨4,53⟩,⟨479,958⟩]
private def b63229 : Box := ![⟨127,190⟩,⟨31,35⟩,⟨10,11⟩,⟨5,52⟩,⟨479,958⟩]
private def b63254 : Box := ![⟨127,190⟩,⟨36,41⟩,⟨10,11⟩,⟨5,52⟩,⟨479,958⟩]
private def b63277 : Box := ![⟨127,190⟩,⟨31,41⟩,⟨12,14⟩,⟨4,53⟩,⟨479,958⟩]
private def b63278 : Box := ![⟨127,190⟩,⟨31,35⟩,⟨12,14⟩,⟨4,53⟩,⟨479,958⟩]
private def b63279 : Box := ![⟨127,152⟩,⟨31,35⟩,⟨12,14⟩,⟨5,51⟩,⟨479,958⟩]
private def b63298 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨12,14⟩,⟨5,51⟩,⟨479,958⟩]
private def b63327 : Box := ![⟨127,190⟩,⟨36,41⟩,⟨12,14⟩,⟨4,53⟩,⟨479,958⟩]
private def b63346 : Box := ![⟨127,190⟩,⟨31,41⟩,⟨10,14⟩,⟨1,59⟩,⟨959,999999999999999999⟩]
private def b63347 : Box := ![⟨127,190⟩,⟨31,41⟩,⟨10,11⟩,⟨1,53⟩,⟨959,999999999999999999⟩]
private def b63370 : Box := ![⟨127,190⟩,⟨31,41⟩,⟨12,14⟩,⟨1,53⟩,⟨959,999999999999999999⟩]
private def b63371 : Box := ![⟨127,190⟩,⟨31,35⟩,⟨12,14⟩,⟨1,53⟩,⟨959,999999999999999999⟩]
private def b63372 : Box := ![⟨127,152⟩,⟨31,35⟩,⟨12,14⟩,⟨1,51⟩,⟨959,999999999999999999⟩]
private def b63381 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨12,14⟩,⟨1,51⟩,⟨959,999999999999999999⟩]
private def b63408 : Box := ![⟨127,190⟩,⟨36,41⟩,⟨12,14⟩,⟨1,53⟩,⟨959,999999999999999999⟩]
private def b63409 : Box := ![⟨127,152⟩,⟨36,41⟩,⟨12,14⟩,⟨1,53⟩,⟨959,999999999999999999⟩]
private def b63432 : Box := ![⟨153,190⟩,⟨36,41⟩,⟨12,14⟩,⟨1,53⟩,⟨959,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨127,190⟩,⟨31,41⟩,⟨10,14⟩,⟨1,59⟩,⟨479,999999999999999999⟩] := by
  have e63229 : Deny 5 13 b63229 := OMA.Blocks5_13_245212.S63229.deny5_13
  have e63254 : Deny 5 13 b63254 := OMA.Blocks5_13_245212.S63254.deny5_13
  have e63228 : Deny 5 13 b63228 :=
    branchAction rule_sound _ _ 3
      0x89e3 b63228 b63229 b63254 (by decide +kernel) e63229 e63254
  have e63279 : Deny 5 13 b63279 := OMA.Blocks5_13_245212.S63279.deny5_13
  have e63298 : Deny 5 13 b63298 := OMA.Blocks5_13_245212.S63298.deny5_13
  have e63278 : Deny 5 13 b63278 :=
    branchAction rule_sound _ _ 3
      0x79e3 b63278 b63279 b63298 (by decide +kernel) e63279 e63298
  have e63327 : Deny 5 13 b63327 := OMA.Blocks5_13_245212.S63327.deny5_13
  have e63277 : Deny 5 13 b63277 :=
    branchAction rule_sound _ _ 1
      0x8 b63277 b63278 b63327 (by decide +kernel) e63278 e63327
  have e63227 : Deny 5 13 b63227 :=
    branchAction rule_sound _ _ 3
      0x99e3 b63227 b63228 b63277 (by decide +kernel) e63228 e63277
  have e63347 : Deny 5 13 b63347 := OMA.Blocks5_13_245212.S63347.deny5_13
  have e63372 : Deny 5 13 b63372 := OMA.Blocks5_13_245212.S63372.deny5_13
  have e63381 : Deny 5 13 b63381 := OMA.Blocks5_13_245212.S63381.deny5_13
  have e63371 : Deny 5 13 b63371 :=
    branchAction rule_sound _ _ 2
      0x1e3 b63371 b63372 b63381 (by decide +kernel) e63372 e63381
  have e63409 : Deny 5 13 b63409 := OMA.Blocks5_13_245212.S63409.deny5_13
  have e63432 : Deny 5 13 b63432 := OMA.Blocks5_13_245212.S63432.deny5_13
  have e63408 : Deny 5 13 b63408 :=
    branchAction rule_sound _ _ 1
      0x7 b63408 b63409 b63432 (by decide +kernel) e63409 e63432
  have e63370 : Deny 5 13 b63370 :=
    branchAction rule_sound _ _ 1
      0x8 b63370 b63371 b63408 (by decide +kernel) e63371 e63408
  have e63346 : Deny 5 13 b63346 :=
    branchAction rule_sound _ _ 2
      0x263 b63346 b63347 b63370 (by decide +kernel) e63347 e63370
  have e63226 : Deny 5 13 b63226 :=
    branchAction rule_sound _ _ 1
      0xb b63226 b63227 b63346 (by decide +kernel) e63227 e63346
  exact e63226
end OMA.Blocks5_13_245212.S63226
