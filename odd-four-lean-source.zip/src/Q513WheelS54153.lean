import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S54153
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b54153 : Box := ![⟨63,94⟩,⟨31,62⟩,⟨10,14⟩,⟨1,53⟩,⟨479,999999999999999999⟩]
private def b54154 : Box := ![⟨63,94⟩,⟨31,41⟩,⟨10,14⟩,⟨1,47⟩,⟨479,999999999999999999⟩]
private def b54155 : Box := ![⟨63,75⟩,⟨31,41⟩,⟨12,14⟩,⟨2,41⟩,⟨479,743⟩]
private def b54156 : Box := ![⟨76,94⟩,⟨31,41⟩,⟨12,14⟩,⟨2,41⟩,⟨479,743⟩]
private def b54167 : Box := ![⟨63,94⟩,⟨42,62⟩,⟨10,14⟩,⟨1,47⟩,⟨479,999999999999999999⟩]
private def b54168 : Box := ![⟨63,75⟩,⟨42,62⟩,⟨10,14⟩,⟨1,47⟩,⟨479,999999999999999999⟩]
private def b54169 : Box := ![⟨63,75⟩,⟨42,62⟩,⟨11,14⟩,⟨1,2⟩,⟨479,1520⟩]
private def b54170 : Box := ![⟨63,75⟩,⟨42,62⟩,⟨11,14⟩,⟨3,43⟩,⟨479,1520⟩]
private def b54171 : Box := ![⟨63,75⟩,⟨42,50⟩,⟨11,14⟩,⟨3,38⟩,⟨479,1516⟩]
private def b54178 : Box := ![⟨63,75⟩,⟨51,62⟩,⟨11,14⟩,⟨3,38⟩,⟨479,1516⟩]
private def b54179 : Box := ![⟨63,75⟩,⟨51,62⟩,⟨11,14⟩,⟨3,38⟩,⟨479,728⟩]
private def b54180 : Box := ![⟨63,75⟩,⟨51,62⟩,⟨11,12⟩,⟨3,38⟩,⟨479,728⟩]
private def b54185 : Box := ![⟨63,75⟩,⟨51,62⟩,⟨13,14⟩,⟨3,38⟩,⟨479,728⟩]
private def b54192 : Box := ![⟨63,75⟩,⟨51,62⟩,⟨11,14⟩,⟨3,38⟩,⟨729,1515⟩]
private def b54199 : Box := ![⟨76,94⟩,⟨42,62⟩,⟨10,14⟩,⟨1,47⟩,⟨479,999999999999999999⟩]
private def b54200 : Box := ![⟨76,94⟩,⟨42,62⟩,⟨10,14⟩,⟨1,47⟩,⟨479,958⟩]
private def b54201 : Box := ![⟨76,94⟩,⟨42,62⟩,⟨10,14⟩,⟨1,2⟩,⟨479,958⟩]
private def b54202 : Box := ![⟨76,94⟩,⟨42,62⟩,⟨10,14⟩,⟨3,41⟩,⟨479,958⟩]
private def b54203 : Box := ![⟨76,94⟩,⟨42,62⟩,⟨10,11⟩,⟨3,41⟩,⟨479,958⟩]
private def b54204 : Box := ![⟨76,94⟩,⟨42,50⟩,⟨10,11⟩,⟨3,40⟩,⟨479,958⟩]
private def b54209 : Box := ![⟨76,94⟩,⟨51,62⟩,⟨10,11⟩,⟨3,40⟩,⟨479,958⟩]
private def b54220 : Box := ![⟨76,94⟩,⟨42,62⟩,⟨12,14⟩,⟨3,41⟩,⟨479,958⟩]
private def b54221 : Box := ![⟨76,94⟩,⟨42,50⟩,⟨12,14⟩,⟨3,41⟩,⟨479,958⟩]
private def b54232 : Box := ![⟨76,94⟩,⟨51,62⟩,⟨12,14⟩,⟨3,41⟩,⟨479,958⟩]
private def b54233 : Box := ![⟨76,84⟩,⟨51,62⟩,⟨12,14⟩,⟨3,41⟩,⟨479,958⟩]
private def b54234 : Box := ![⟨76,84⟩,⟨51,62⟩,⟨12,14⟩,⟨3,39⟩,⟨479,638⟩]
private def b54243 : Box := ![⟨76,84⟩,⟨51,62⟩,⟨12,14⟩,⟨3,39⟩,⟨639,958⟩]
private def b54252 : Box := ![⟨85,94⟩,⟨51,62⟩,⟨12,14⟩,⟨3,41⟩,⟨479,958⟩]
private def b54253 : Box := ![⟨85,94⟩,⟨51,62⟩,⟨12,14⟩,⟨3,41⟩,⟨479,638⟩]
private def b54258 : Box := ![⟨85,94⟩,⟨51,62⟩,⟨12,14⟩,⟨3,41⟩,⟨639,958⟩]
private def b54265 : Box := ![⟨76,94⟩,⟨42,62⟩,⟨10,14⟩,⟨1,47⟩,⟨959,999999999999999999⟩]
private def b54266 : Box := ![⟨76,94⟩,⟨42,62⟩,⟨10,11⟩,⟨1,42⟩,⟨959,999999999999999999⟩]
private def b54273 : Box := ![⟨76,94⟩,⟨42,62⟩,⟨12,14⟩,⟨1,42⟩,⟨959,999999999999999999⟩]
private def b54274 : Box := ![⟨76,94⟩,⟨42,50⟩,⟨12,14⟩,⟨1,42⟩,⟨959,999999999999999999⟩]
private def b54285 : Box := ![⟨76,94⟩,⟨51,62⟩,⟨12,14⟩,⟨1,42⟩,⟨959,999999999999999999⟩]
private def b54286 : Box := ![⟨76,84⟩,⟨51,62⟩,⟨12,14⟩,⟨1,42⟩,⟨959,999999999999999999⟩]
private def b54287 : Box := ![⟨76,84⟩,⟨51,62⟩,⟨12,14⟩,⟨1,40⟩,⟨959,1918⟩]
private def b54298 : Box := ![⟨76,84⟩,⟨51,62⟩,⟨12,14⟩,⟨1,40⟩,⟨1919,999999999999999999⟩]
private def b54305 : Box := ![⟨85,94⟩,⟨51,62⟩,⟨12,14⟩,⟨1,42⟩,⟨959,999999999999999999⟩]
private def b54306 : Box := ![⟨85,94⟩,⟨51,62⟩,⟨12,14⟩,⟨1,42⟩,⟨959,1918⟩]
private def b54317 : Box := ![⟨85,94⟩,⟨51,62⟩,⟨12,14⟩,⟨1,42⟩,⟨1919,999999999999999999⟩]
private theorem e54155 : Deny 5 13 b54155 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e54156 : Deny 5 13 b54156 := by
    apply closeAction rule_sound _ _ 64 [0x30f8de321f089e378c7089088e23]
    decide +kernel
private theorem e54154 : Deny 5 13 b54154 :=
    branchAction rule_sound _ _ 5
      0x7e37da3 b54154 b54155 b54156 (by decide +kernel) e54155 e54156
private theorem e54169 : Deny 5 13 b54169 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
private theorem e54171 : Deny 5 13 b54171 := by
    apply closeAction rule_sound _ _ 64 [0x3089088087e37da3]
    decide +kernel
private theorem e54180 : Deny 5 13 b54180 := by
    apply closeAction rule_sound _ _ 64 [0x3089087e23]
    decide +kernel
private theorem e54185 : Deny 5 13 b54185 := by
    apply closeAction rule_sound _ _ 64 [0xc38c80c3e378c88c7]
    decide +kernel
private theorem e54179 : Deny 5 13 b54179 :=
    branchAction rule_sound _ _ 1
      0x9 b54179 b54180 b54185 (by decide +kernel) e54180 e54185
private theorem e54192 : Deny 5 13 b54192 := by
    apply closeAction rule_sound _ _ 64 [0x30f8de320225be37da31f8da3]
    decide +kernel
private theorem e54178 : Deny 5 13 b54178 :=
    branchAction rule_sound _ _ 2
      0x2f8 b54178 b54179 b54192 (by decide +kernel) e54179 e54192
private theorem e54170 : Deny 5 13 b54170 :=
    branchAction rule_sound _ _ 3
      0x8e23 b54170 b54171 b54178 (by decide +kernel) e54171 e54178
private theorem e54168 : Deny 5 13 b54168 :=
    branchAction rule_sound _ _ 4
      0x2b8da3 b54168 b54169 b54170 (by decide +kernel) e54169 e54170
private theorem e54201 : Deny 5 13 b54201 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
private theorem e54204 : Deny 5 13 b54204 := by
    apply closeAction rule_sound _ _ 64 [0x30881021f8de3]
    decide +kernel
private theorem e54209 : Deny 5 13 b54209 := by
    apply closeAction rule_sound _ _ 64 [0x30f8243e232030f8de321be372788c7]
    decide +kernel
private theorem e54203 : Deny 5 13 b54203 :=
    branchAction rule_sound _ _ 2
      0x223 b54203 b54204 b54209 (by decide +kernel) e54204 e54209
private theorem e54221 : Deny 5 13 b54221 := by
    apply closeAction rule_sound _ _ 64 [0x30e3203e232430f88c80f8de32631e3]
    decide +kernel
private theorem e54234 : Deny 5 13 b54234 := by
    apply closeAction rule_sound _ _ 64 [0x20f7107e370e32030e3209]
    decide +kernel
private theorem e54243 : Deny 5 13 b54243 := by
    apply closeAction rule_sound _ _ 64 [0x3e038c70e32030f8de3223263]
    decide +kernel
private theorem e54233 : Deny 5 13 b54233 :=
    branchAction rule_sound _ _ 2
      0x2e3 b54233 b54234 b54243 (by decide +kernel) e54234 e54243
private theorem e54253 : Deny 5 13 b54253 := by
    apply closeAction rule_sound _ _ 64 [0x20838c88c9]
    decide +kernel
private theorem e54258 : Deny 5 13 b54258 := by
    apply closeAction rule_sound _ _ 64 [0x838c8e03e038c8263]
    decide +kernel
private theorem e54252 : Deny 5 13 b54252 :=
    branchAction rule_sound _ _ 1
      0xb b54252 b54253 b54258 (by decide +kernel) e54253 e54258
private theorem e54232 : Deny 5 13 b54232 :=
    branchAction rule_sound _ _ 1
      0x7 b54232 b54233 b54252 (by decide +kernel) e54233 e54252
private theorem e54220 : Deny 5 13 b54220 :=
    branchAction rule_sound _ _ 1
      0x8 b54220 b54221 b54232 (by decide +kernel) e54221 e54232
private theorem e54202 : Deny 5 13 b54202 :=
    branchAction rule_sound _ _ 1
      0x9 b54202 b54203 b54220 (by decide +kernel) e54203 e54220
private theorem e54200 : Deny 5 13 b54200 :=
    branchAction rule_sound _ _ 2
      0x2a3 b54200 b54201 b54202 (by decide +kernel) e54201 e54202
private theorem e54266 : Deny 5 13 b54266 := by
    apply closeAction rule_sound _ _ 64 [0x3088087e23088e37d63]
    decide +kernel
private theorem e54274 : Deny 5 13 b54274 := by
    apply closeAction rule_sound _ _ 64 [0xc3e378c8e1f089e378c74cae23089e23]
    decide +kernel
private theorem e54287 : Deny 5 13 b54287 := by
    apply closeAction rule_sound _ _ 64 [0x30e31c38c80c2238de32532a3]
    decide +kernel
private theorem e54298 : Deny 5 13 b54298 := by
    apply closeAction rule_sound _ _ 64 [0xc3e378c70f8de3202263]
    decide +kernel
private theorem e54286 : Deny 5 13 b54286 :=
    branchAction rule_sound _ _ 2
      0x2e3 b54286 b54287 b54298 (by decide +kernel) e54287 e54298
private theorem e54306 : Deny 5 13 b54306 := by
    apply closeAction rule_sound _ _ 64 [0x838c7e038c80c3e232232532a3]
    decide +kernel
private theorem e54317 : Deny 5 13 b54317 := by
    apply closeAction rule_sound _ _ 64 [0xc38c70e3203e23088e23263]
    decide +kernel
private theorem e54305 : Deny 5 13 b54305 :=
    branchAction rule_sound _ _ 1
      0xb b54305 b54306 b54317 (by decide +kernel) e54306 e54317
private theorem e54285 : Deny 5 13 b54285 :=
    branchAction rule_sound _ _ 1
      0x7 b54285 b54286 b54305 (by decide +kernel) e54286 e54305
private theorem e54273 : Deny 5 13 b54273 :=
    branchAction rule_sound _ _ 1
      0x8 b54273 b54274 b54285 (by decide +kernel) e54274 e54285
private theorem e54265 : Deny 5 13 b54265 :=
    branchAction rule_sound _ _ 2
      0x263 b54265 b54266 b54273 (by decide +kernel) e54266 e54273
private theorem e54199 : Deny 5 13 b54199 :=
    branchAction rule_sound _ _ 1
      0xb b54199 b54200 b54265 (by decide +kernel) e54200 e54265
private theorem e54167 : Deny 5 13 b54167 :=
    branchAction rule_sound _ _ 1
      0x7 b54167 b54168 b54199 (by decide +kernel) e54168 e54199
private theorem e54153 : Deny 5 13 b54153 :=
    branchAction rule_sound _ _ 2
      0x223 b54153 b54154 b54167 (by decide +kernel) e54154 e54167
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨31,62⟩,⟨10,14⟩,⟨1,53⟩,⟨479,999999999999999999⟩] := by
  exact e54153
end OMA.Blocks5_13_245212.S54153
