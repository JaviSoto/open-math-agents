import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S54707
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b54707 : Box := ![⟨54,57⟩,⟨85,126⟩,⟨12,14⟩,⟨4,51⟩,⟨479,638⟩]
private def b54708 : Box := ![⟨54,57⟩,⟨85,101⟩,⟨12,14⟩,⟨4,51⟩,⟨479,638⟩]
private def b54709 : Box := ![⟨54,57⟩,⟨85,101⟩,⟨12,12⟩,⟨4,45⟩,⟨479,638⟩]
private def b54710 : Box := ![⟨54,57⟩,⟨85,101⟩,⟨13,14⟩,⟨4,45⟩,⟨479,638⟩]
private def b54711 : Box := ![⟨54,55⟩,⟨85,101⟩,⟨13,14⟩,⟨4,45⟩,⟨479,638⟩]
private def b54712 : Box := ![⟨56,57⟩,⟨85,101⟩,⟨13,14⟩,⟨4,45⟩,⟨479,638⟩]
private def b54713 : Box := ![⟨54,57⟩,⟨102,126⟩,⟨12,14⟩,⟨4,51⟩,⟨479,638⟩]
private def b54714 : Box := ![⟨54,57⟩,⟨102,126⟩,⟨12,12⟩,⟨9,51⟩,⟨479,638⟩]
private def b54715 : Box := ![⟨54,57⟩,⟨102,126⟩,⟨13,14⟩,⟨9,51⟩,⟨479,638⟩]
private def b54716 : Box := ![⟨54,57⟩,⟨102,126⟩,⟨13,13⟩,⟨9,51⟩,⟨479,638⟩]
private def b54717 : Box := ![⟨54,57⟩,⟨102,126⟩,⟨14,14⟩,⟨9,51⟩,⟨479,638⟩]
private theorem e54709 : Deny 5 13 b54709 := by
    apply closeAction rule_sound _ _ 64 [0x1ae37ae3]
    decide +kernel
private theorem e54711 : Deny 5 13 b54711 := by
    apply closeAction rule_sound _ _ 64 [0x3ae3]
    decide +kernel
private theorem e54712 : Deny 5 13 b54712 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e54710 : Deny 5 13 b54710 :=
    branchAction rule_sound _ _ 1
      0x7 b54710 b54711 b54712 (by decide +kernel) e54711 e54712
private theorem e54708 : Deny 5 13 b54708 :=
    branchAction rule_sound _ _ 2
      0x263 b54708 b54709 b54710 (by decide +kernel) e54709 e54710
private theorem e54714 : Deny 5 13 b54714 := by
    apply closeAction rule_sound _ _ 64 [0xf8]
    decide +kernel
private theorem e54716 : Deny 5 13 b54716 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e54717 : Deny 5 13 b54717 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e54715 : Deny 5 13 b54715 :=
    branchAction rule_sound _ _ 1
      0x9 b54715 b54716 b54717 (by decide +kernel) e54716 e54717
private theorem e54713 : Deny 5 13 b54713 :=
    branchAction rule_sound _ _ 2
      0x26b b54713 b54714 b54715 (by decide +kernel) e54714 e54715
private theorem e54707 : Deny 5 13 b54707 :=
    branchAction rule_sound _ _ 1
      0x8 b54707 b54708 b54713 (by decide +kernel) e54708 e54713
theorem deny5_13 : Deny 5 13 ![⟨54,57⟩,⟨85,126⟩,⟨12,14⟩,⟨4,51⟩,⟨479,638⟩] := by
  exact e54707
end OMA.Blocks5_13_245212.S54707
