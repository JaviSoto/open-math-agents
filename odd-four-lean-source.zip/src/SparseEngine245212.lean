import Engine245212
import SingletonCaps245212

/-! Six-bit replay for four-prime search certificates. The trace can
    request just one proven exponent contraction. Digit and leaf rules
    can be exchanged for equivalent, cheaper kernel computations. -/
namespace OMA.SparseEngine245212
open OMA.Box245212

abbrev Cut := ℕ→ℕ→Box→Option Box
abbrev Test := ℕ→ℕ→Box→ℕ→Bool
abbrev Advance := ℕ→ℕ→ℕ→Stack→Option Stack
def CutSound (cut : Cut) := ∀ p q b v,Fits b v → Candidate p q v →
  ∃ out,cut p q b=some out ∧ Fits out v
def TestSound (test : Test) := ∀ p q b op,test p q b op=true → Deny p q b
def AdvanceSound (step : Advance) := ∀ p q op s t,step p q op s=some t → solved p q t → solved p q s

/-- 32+i contracts exponent i above; 36+4*i+j contracts j below
    using the height requirement at i. The old complete pass is op 5. -/
def single (p q op : ℕ) (b : Box) : Box :=
  if ∀ i,1<(baseBox p q b i).lo then
    if op<36 then upperClip p q b (Fin.ofNat 4 (op-32))
    else lowerClip p q b (Fin.ofNat 4 ((op-36)/4)) (Fin.ofNat 4 ((op-36)%4))
  else b

theorem single_sound {p q op : ℕ} {b : Box} {v : Values} (fit : Fits b v) (c : Candidate p q v) :
    Fits (single p q op b) v := by
  unfold single
  split_ifs with start h
  · exact upper_sound fit c start _
  · exact lower_sound fit c start _ _
  · exact fit

def step (digit : Cut) (leaf : Test) (p q op : ℕ) (s : Stack) : Option Stack :=
  if op=0 ∨ op=4 ∨ op=5 ∨ 7≤op ∧ op<12 then advance singletonCaps p q op s
  else match s with
  | [] => none
  | b::rest =>
    if op=6 then some (put (digit p q b) rest)
    else if 32≤op ∧ op<52 then some (single p q op b::rest)
    else if leaf p q b op then some rest else none

theorem step_sound {digit : Cut} {leaf : Test} (ds : CutSound digit) (ls : TestSound leaf) :
    AdvanceSound (step digit leaf) := by
  intro p q op s t check yes
  unfold step at check
  by_cases old : op=0 ∨ op=4 ∨ op=5 ∨ 7≤op ∧ op<12
  · rw [if_pos old] at check
    exact advance_sound singletonCaps (fun _ _ _ _ f c=>singletonCaps_sound f c) check yes
  rw [if_neg old] at check
  cases s with
  | nil => cases check
  | cons b rest =>
    dsimp only at check
    split_ifs at check with digitOp shrink passed
    · cases Option.some.inj check
      intro x hx
      rcases List.mem_cons.mp hx with rfl|other
      · intro v hv c
        obtain ⟨out,h,ho⟩ := ds p q _ _ hv c
        rw [h] at yes
        exact yes out List.mem_cons_self v ho c
      · cases h : digit p q b with
        | none => rw [h] at yes; exact yes x other
        | some out => rw [h] at yes; exact yes x (List.mem_cons_of_mem _ other)
    · cases Option.some.inj check
      intro x hx
      rcases List.mem_cons.mp hx with rfl|other
      · exact fun v f c=>yes _ List.mem_cons_self v (single_sound f c) c
      · exact yes _ (List.mem_cons_of_mem _ other)
    · cases Option.some.inj check
      intro x hx
      rcases List.mem_cons.mp hx with rfl|other
      · exact ls p q _ op passed
      · exact yes _ other

def word (advance : Advance) (p q : ℕ) : ℕ→ℕ→Stack→Option Stack
  | 0,_,s => some s
  | n+1,w,s => (advance p q (w%64) s).bind (word advance p q n (w/64) ·)

theorem word_sound {action : Advance} (good : AdvanceSound action) (p q n w : ℕ) (s t : Stack)
    (check : word action p q n w s=some t) (yes : solved p q t) : solved p q s := by
  induction n generalizing w s with
  | zero => cases Option.some.inj check;exact yes
  | succ n ih =>
    cases h : action p q (w%64) s with
    | none => simp [word,h] at check
    | some u => exact good p q _ s u h (ih (w/64) u (by simpa only [word,h,Option.bind_some] using check))

def run (advance : Advance) (p q fuel : ℕ) : List ℕ→Stack→Option Stack
  | [],s => some s
  | w::ws,s => (word advance p q fuel w s).bind (run advance p q fuel ws ·)

/-- Chunked traces can use this form with an already verified tail. -/
theorem run_sound {action : Advance} (good : AdvanceSound action)
    (p q fuel : ℕ) (ws : List ℕ) {s t : Stack}
    (check : run action p q fuel ws s=some t) (yes : solved p q t) : solved p q s := by
  induction ws generalizing s with
  | nil => cases Option.some.inj check;exact yes
  | cons w ws ih =>
    cases h : word action p q fuel w s with
    | none => simp [run,h] at check
    | some u => exact word_sound good p q _ w s u h (ih (by simpa only [run,h,Option.bind_some] using check))

theorem certify {digit : Cut} {leaf : Test} (ds : CutSound digit) (ls : TestSound leaf)
    (p q fuel : ℕ) (ws : List ℕ) (b : Box)
    (check : run (step digit leaf) p q fuel ws [b]=some []) : Deny p q b :=
  run_sound (step_sound ds ls) p q fuel ws check (by simp [solved]) b List.mem_cons_self

theorem standard (p q fuel : ℕ) (ws : List ℕ) (b : Box)
    (check : run (step digitTrim banned) p q fuel ws [b]=some []) : Deny p q b :=
  certify (fun _ _ _ _ f c=>digitTrim_sound f c) (fun _ _ _ _=>banned_sound) p q fuel ws b check

/-- A subtree can begin with an arbitrary word of verified cuts and
    one split, followed by two independent proofs on explicit boxes. -/
theorem branchAction {action : Advance} (ok : AdvanceSound action)
    (p q fuel code : ℕ) (b l r : Box)
    (check : word action p q fuel code [b]=some [l,r])
    (left : Deny p q l) (right : Deny p q r) : Deny p q b := by
  apply word_sound ok p q fuel code [b] [l,r] check _ b List.mem_cons_self
  intro x hx
  rcases List.mem_cons.mp hx with rfl|hx
  · exact left
  · exact (List.mem_singleton.mp hx) ▸ right

theorem branch {digit : Cut} {leaf : Test} (ds : CutSound digit) (ls : TestSound leaf)
    (p q fuel code : ℕ) (b l r : Box)
    (check : word (step digit leaf) p q fuel code [b]=some [l,r])
    (left : Deny p q l) (right : Deny p q r) : Deny p q b :=
  branchAction (step_sound ds ls) p q fuel code b l r check left right

theorem closeAction {action : Advance} (ok : AdvanceSound action) (p q fuel : ℕ)
    (ws : List ℕ) (b : Box) (check : run action p q fuel ws [b]=some []) : Deny p q b :=
  run_sound ok p q fuel ws check (by simp [solved]) b List.mem_cons_self

end OMA.SparseEngine245212
