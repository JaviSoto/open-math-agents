import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S12570
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b12570 : Box := ![⟨23,46⟩,⟨15,30⟩,⟨7,14⟩,⟨3,1328583941605839423973⟩,⟨41,53⟩]
theorem deny5_13 : Deny 5 13 ![⟨23,46⟩,⟨15,30⟩,⟨7,14⟩,⟨3,1328583941605839423973⟩,⟨41,53⟩] := by
  have e12570 : Deny 5 13 b12570 := by
    apply closeAction rule_sound _ _ 64 [0xdc70f72092842c30f8df68c80f8df6d631f7da30c38c70e32430f8df6d631e32430f8df6203e37db51f62842e32231e3,0xc31e31c30c70c40f7db5107e371ca0c3e378c80f8df68c7de32630832370c38c78c70c38c70e32232430c70c31c70c3,0xc7108e370f8dc38c88c90832370e31c30e32232631c20c7dc3dc31c80c32090f70c80c70c3df62091ca10b8c80c38c7,0xdc31c32091c42ca0f78c40e3107e030e31e32030c70c31c82830f78c88c90c3de3203de31c30f8df68c8de32631e3082,0xc8247dc42c20832441f8dc3e370c72030c70c9257e370c90c70c31c80c31c32091c2083e370c7209dc20f8dc31c8dc3,0x820c4238dc38c98c97c3e370e32232430e31c38c88c98c78c2082]
    decide +kernel
  exact e12570
end OMA.Blocks5_13_245212.S12570
