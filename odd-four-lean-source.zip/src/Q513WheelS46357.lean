import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S46357
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b46357 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨63,1920000000000000011376⟩,⟨3,799016681299385430601⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨127,190⟩,⟨18,20⟩,⟨63,1920000000000000011376⟩,⟨3,799016681299385430601⟩,⟨479,999999999999999999⟩] := by
  have e46357 : Deny 5 13 b46357 := by
    apply closeAction rule_sound _ _ 64 [0xe23088e232637552952a32dd7552b888a54ae23778df68c8e231dce37da322326372f778747be325d75528a8c954a8cb,0xe37578dc3e03e232631f88c98cbe1d54a54a778de32788dce37da31f8d887555781f82952b88c22388c775d54ae0a54a,0x1f8df68c853888a8c70820f88c7e232780f80e31c30f88c78c98dd54ae152a32e31c3e038c90f88c3e232788c78c98d5,0x26370bbdcbe326f8c7bddbe32421e372f8cbbddbe326372f8cb0888dcbe32ef76f8ddbe31f88c98dcbddbe326f8cb742,0x8c9be32ddbe376f8c9e2320208272f8c9e2f8dcbe3278be372f8c9e2f8dcbe3278bdcbe326f087da370b0878c7bdcbe3,0x8ddbe32e376f8cbda376f8cbda376f8cbda31c222376f8cb8ddbe32e376f8cb8ddbe32e376f8cb8c98dcbdde1dbe31ef,0x8cb8dcbe32e372f8cb8dcbe32ef0820820e31e32631e325d76f0ef0890872552d52d52d52d42d42d42c21e22a376f8cb,0x8208209ce361ef72f8c98dc2e31f8bdcbe3247bdcbe32631ef76f8c9778da31c8bddbe326372f]
    decide +kernel
  exact e46357
end OMA.Blocks5_13_245212.S46357
