import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S23031
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b23031 : Box := ![⟨31,46⟩,⟨31,62⟩,⟨7,14⟩,⟨1,648707482993197282786⟩,⟨119,1312⟩]
theorem deny5_13 : Deny 5 13 ![⟨31,46⟩,⟨31,62⟩,⟨7,14⟩,⟨1,648707482993197282786⟩,⟨119,1312⟩] := by
  have e23031 : Deny 5 13 b23031 := by
    apply closeAction rule_sound _ _ 64 [0x2830f8de31c3e378c90f8df68c80c2238df6d631f78c910b7c3e37d63244087e37da32368c47c2278df6d63107e37da3,0xdf58c97f8df6d631f7da3103e038c90c70c31e32037f8de3203e378c98c70c3e090f81c31021f8203102238df6d475ca,0x1f0dfe371c2238283e37d63243102238]
    decide +kernel
  exact e23031
end OMA.Blocks5_13_245212.S23031
