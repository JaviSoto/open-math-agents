import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S17120
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b17120 : Box := ![⟨23,30⟩,⟨21,30⟩,⟨15,1920000000000000011376⟩,⟨2,4⟩,⟨59,73⟩]
theorem deny5_13 : Deny 5 13 ![⟨23,30⟩,⟨21,30⟩,⟨15,1920000000000000011376⟩,⟨2,4⟩,⟨59,73⟩] := by
  have e17120 : Deny 5 13 b17120 := by
    apply closeAction rule_sound _ _ 64 [0x8880f8df61f6103e370e22032430c90f7da22221c30f8df61c9d842c3da21021f8df68885ca0c21e2102238df6d621e2,0x30f8dc90f8df6]
    decide +kernel
  exact e17120
end OMA.Blocks5_13_245212.S17120
