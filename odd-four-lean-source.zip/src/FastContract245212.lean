import FastDigit245212
import FastFactor245212

/-! Glue the integer top-digit cuts to any local factor bounds with a
fixed denominator. Four cofactors use three factors and denominator M³. -/
namespace OMA.FastDigit245212
open OMA.Box245212 Finset
open OMA.Smooth245212 (X Y)

def Correct (M : ℕ) (F : Range→Range→Span) :=
  ∀ (bp be : Range) (p e : ℕ),1<bp.lo → bp.has p → be.has e →
    ((F bp be).xl:ℚ) ≤ M*X p (some e) ∧ M*X p (some e) ≤ (F bp be).xu ∧
    ((F bp be).yl:ℚ) ≤ M*Y p (some e) ∧ M*Y p (some e) ≤ (F bp be).yu

def cofactor (F : Range→Range→Span) (p q : ℕ) (b : Box) (i : Fin 4) : Span :=
  let f (j : Fin 4) := F (baseBox p q b j) (b j.castSucc)
  ⟨∏ j∈univ.erase i,(f j).xl, ∏ j∈univ.erase i,(f j).yl,
   ∏ j∈univ.erase i,(f j).xu, ∏ j∈univ.erase i,(f j).yu⟩

open private OMA.Large245212.y_both from LargeWindow245212
theorem obey_box {M : ℕ} (positive : 0<M) {F : Range→Range→Span} (valid : Correct M F)
    {p q : ℕ} {b : Box} {v : Values} (c : Candidate p q v) (fit : Fits b v)
    (start : ∀i,1<(baseBox p q b i).lo) (i : Fin 4) (l h : ℕ) (lp : 1≤l)
    (lr : l≤bases p q v i) (rh : bases p q v i≤h) :
    obey (M^3) (cofactor F p q b i) (exponents v i) l h := by
  let xv (j : Fin 4) := X (bases p q v j) (some (exponents v j))
  let yv (j : Fin 4) := Y (bases p q v j) (some (exponents v j))
  let f (j : Fin 4) := F (baseBox p q b j) (b j.castSucc)
  let s := (univ : Finset (Fin 4)).erase i
  have local_ (j : Fin 4) := valid _ _ _ _ (start j) (inside_primes fit j) (fit j.castSucc)
  have xx (j : Fin 4) : 0≤xv j := (moments fit start j).1.trans (moments fit start j).2.1
  have yy (j : Fin 4) : 0<yv j := (show (0:ℚ)<1/((exponents v j:ℚ)+1) by positivity).trans_le
    (OMA.Large245212.y_both (c.prime j).one_lt).1
  have triple (g : Fin 4→ℚ) : ∏ j∈s,(M:ℚ)*g j=(M:ℚ)^3*(∏ j∈s,g j) := by
    rw [prod_mul_distrib,prod_const];simp [s]
  have xl : (∏ j∈s,((f j).xl:ℚ)) ≤ ∏ j∈s,(M:ℚ)*xv j :=
    prod_le_prod (fun j _=>Nat.cast_nonneg _) (fun j _=>(local_ j).1)
  have yl : (∏ j∈s,((f j).yl:ℚ)) ≤ ∏ j∈s,(M:ℚ)*yv j :=
    prod_le_prod (fun j _=>Nat.cast_nonneg _) (fun j _=>(local_ j).2.2.1)
  have xu : (∏ j∈s,(M:ℚ)*xv j) ≤ ∏ j∈s,((f j).xu:ℚ) :=
    prod_le_prod (fun j _=>mul_nonneg (Nat.cast_nonneg _) (xx j)) (fun j _=>(local_ j).2.1)
  have yu : (∏ j∈s,(M:ℚ)*yv j) ≤ ∏ j∈s,((f j).yu:ℚ) :=
    prod_le_prod (fun j _=>mul_nonneg (Nat.cast_nonneg _) (yy j).le) (fun j _=>(local_ j).2.2.2)
  rw [triple] at xl yl xu yu
  refine obey_of_score (x:=∏ j∈s,xv j) (y:=∏j∈s,yv j) (pow_pos positive _) (c.prime i) (c.pos i) (prod_nonneg fun j _=>xx j)
    (prod_pos fun j _=>yy j) lp lr rh ?_ ?_ ?_ ?_ ?_
  · change (∏j∈univ.erase i,xv j)*xv i+(∏j∈univ.erase i,yv j)*yv i=2
    rw [prod_erase_mul _ _ (mem_univ i),prod_erase_mul _ _ (mem_univ i)]
    exact c.score
  · simpa only [cofactor,Nat.cast_prod,Nat.cast_pow] using xl
  · simpa only [cofactor,Nat.cast_prod,Nat.cast_pow] using yl
  · simpa only [cofactor,Nat.cast_prod,Nat.cast_pow] using xu
  · simpa only [cofactor,Nat.cast_prod,Nat.cast_pow] using yu

/-- In a single pass compute the four digit cuts, then bound the last
prime using the tightened exponent and the original cofactor. -/
def contract (M : ℕ) (F : Range→Range→Span) (p q : ℕ) (b : Box) : Option Box :=
  if ∀i,1<(baseBox p q b i).lo then
    let C := cofactor F p q b
    let digit (i : Fin 4) := digitAt (M^3) (C i) (b i.castSucc) (baseBox p q b i)
    let D := digit 3
    let R := lowPrime (M^3) (C 3).xl (C 3).yl D (b 4)
    let R := highPrime (M^3) (C 3).xu (C 3).yu D R
    let out : Box := Fin.lastCases R digit
    if ∀i,(out i).lo≤(out i).hi then some out else none
  else some b

theorem contract_sound {M : ℕ} {F : Range→Range→Span} (mz : 0<M) (valid : Correct M F)
    {p q : ℕ} {v : Values} {b : Box} (fit : Fits b v) (c : Candidate p q v) :
    ∃ out,contract M F p q b=some out ∧ Fits out v := by
  unfold contract
  split_ifs with start
  · let C := cofactor F p q b
    let D (i : Fin 4) := digitAt (M^3) (C i) (b i.castSucc) (baseBox p q b i)
    have f (i : Fin 4) : (D i).has (exponents v i) :=
      digitAt_ok (fit i.castSucc) (obey_box mz valid c fit start i _ _ (start i).le
        (inside_primes fit i).1 (inside_primes fit i).2)
    have good := obey_box mz valid c fit start 3 (v 4) (v 4) (c.prime 3).pos (by rfl) (by rfl)
    let rl := lowPrime (M^3) (C 3).xl (C 3).yl (D 3) (b 4)
    have fl : rl.has (v 4) := lowPrime_ok (f 3) (fit 4) good.1 good.2.1
    let rr := highPrime (M^3) (C 3).xu (C 3).yu (D 3) rl
    have fr : rr.has (v 4) := highPrime_ok (f 3) fl good.2.2
    let out : Box := Fin.lastCases rr D
    have ff : Fits out v := by
      intro i
      refine Fin.lastCases ?_ (fun j=>?_) i
      · exact fr
      · simpa [out,exponents] using f j
    exact ⟨out,if_pos (fun i=>(ff i).1.trans (ff i).2),ff⟩
  · exact ⟨_,rfl,fit⟩

def hull (base exp : Range) : Span :=
  ⟨FastFactor245212.lowX base exp,FastFactor245212.lowY base exp,
    FastFactor245212.highX base exp,FastFactor245212.highY base exp⟩

def fastDigit := contract FastFactor245212.scale hull

theorem fastDigit_sound {p q : ℕ} {v : Values} {b : Box} (fit : Fits b v) (c : Candidate p q v) :
    ∃ out,fastDigit p q b=some out ∧ Fits out v :=
  contract_sound FastFactor245212.scale_pos
    (fun _ _ _ _ start pi ei=>FastFactor245212.bounds start pi ei) fit c

def fastInterval (p q : ℕ) (b : Box) : Bool :=
  let f (i : Fin 4) := hull (baseBox p q b i) (b i.castSucc)
  decide ((∀i,1<(baseBox p q b i).lo) ∧
    ((∏i,(f i).xu)+(∏i,(f i).yu)<2*FastFactor245212.scale^4 ∨
    2*FastFactor245212.scale^4<(∏i,(f i).xl)+(∏i,(f i).yl)))

theorem fastInterval_sound {p q : ℕ} {b : Box} (yes : fastInterval p q b=true) : Deny p q b := by
  obtain ⟨start,why⟩ := of_decide_eq_true yes
  intro v fit c
  let f (i : Fin 4) := hull (baseBox p q b i) (b i.castSucc)
  let M := FastFactor245212.scale
  let x (i : Fin 4) := X (bases p q v i) (some (exponents v i))
  let y (i : Fin 4) := Y (bases p q v i) (some (exponents v i))
  have within (i : Fin 4) : ((f i).xl:ℚ)≤M*x i ∧ M*x i≤(f i).xu ∧
      ((f i).yl:ℚ)≤M*y i ∧ M*y i≤(f i).yu :=
    FastFactor245212.bounds (start i) (inside_primes fit i) (fit i.castSucc)
  have l := add_le_add (prod_le_prod (s:=univ) (fun i _=>Nat.cast_nonneg _) (fun i _=>(within i).1))
    (prod_le_prod (s:=univ) (fun i _=>Nat.cast_nonneg _) (fun i _=>(within i).2.2.1))
  have h := add_le_add (prod_le_prod (s:=univ) (fun i _=>(Nat.cast_nonneg _).trans (within i).1) (fun i _=>(within i).2.1))
    (prod_le_prod (s:=univ) (fun i _=>(Nat.cast_nonneg _).trans (within i).2.2.1) (fun i _=>(within i).2.2.2))
  have eq : (∏i,x i)+(∏i,y i)=2 := c.score
  have mid : (∏i,(M:ℚ)*x i)+(∏i,(M:ℚ)*y i)=2*(M:ℚ)^4 := by
    simp only [prod_mul_distrib,prod_const,card_univ,Fintype.card_fin,←mul_add,eq,mul_comm]
  rw [mid] at l h
  rcases why with upper|lower
  · exact upper.not_ge (by exact_mod_cast h)
  · exact lower.not_ge (by exact_mod_cast l)

end OMA.FastDigit245212
