import Engine245212
import SparseEngine245212

/-! Fixed-arity arithmetic for the four-prime rounding leaves. A 256-entry
    bit-length table is checked from the defining integer logarithm. -/
namespace OMA.FastRound245212
open OMA.Box245212 Finset

private def page : ℕ → ℕ
  | 0 => 0x7d1e7765ca6e9a96558059d4a4a5003288000000
  | 1 => 0x9ea749b6679825994a4a90e3a8ca2987e1582e00
  | 2 => 0xb1ac3afabaadab2ab6a9a929fa6a95a428ba1680
  | 3 => 0xbf6fabdef4bc2edbaae7b92e0b76d9b5ad2b3aca
  | 4 => 0xc9b24c8b1fc771ac6315c4f10c370bc2305c0b00
  | 5 => 0xd2346d1743d033ecf33ace336cd332cc32dcaf29
  | 6 => 0xd9764d8b60d7b5dd6f59d5f56d5352d434ed334a
  | 7 => 0xdfb7ddef7ade377dd774dcb70dbf6ddb36ada367
  | 8 => 0xe5393e4790e3f8de338be2788e1f85e1382e0780
  | 9 => 0xea3a6e97a4e8fa2e839fe7b9de739ae6798e5f95
  | 10 => 0xee7b8edfb6ed7b4ecfb2ec7b0ebbadeb3abeaba9
  | 11 => 0xf27c8f1fc6f1bc5f13c3f0bc0effbeef7bceefba
  | 12 => 0xf63d7f5bd6f57d4f4fd2f47d0f3fcef37ccf2fca
  | 13 => 0xf9be5f93e4f8fe2f87e0f7fdef7bddf73dbf6bd9
  | 14 => 0xfcff2fc7f0fc3effbbedfb7ecfafeafa7e8fa3e7
  | 15 => 0xffffeff7fdff3fbfebfafe7f8fdff7fdbf5fd3f4
  | _ => 0

private def lookup (n : ℕ) := ((page (n/16)) >>> (10*(n%16))) &&& 1023

private theorem table_ok : ∀ i : Fin 256, lookup i.val = sizeLo i.val := by decide +kernel

def low (n : ℕ) := if n<256 then lookup n else sizeLo n
def high (n : ℕ) := low n+1

theorem low_eq (n : ℕ) : low n = sizeLo n := by
  unfold low
  split_ifs with h
  · exact table_ok ⟨_,h⟩
  · rfl

private theorem high_eq (n : ℕ) : high n=sizeHi n := by simp [high,sizeHi,low_eq]

def all4 (f : Fin 4→Bool) := f 0 && f 1 && f 2 && f 3

private theorem all4_iff {f : Fin 4→Bool} : all4 f=true ↔ ∀ i,f i=true := by
  simp only [all4,Bool.and_eq_true_iff]
  constructor
  · rintro ⟨⟨⟨h0,h1⟩,h2⟩,h3⟩ i
    fin_cases i <;> assumption
  · exact fun h=>⟨⟨⟨h 0,h 1⟩,h 2⟩,h 3⟩

def skipSum (f : Fin 4→ℕ) (i : Fin 4) := f 0+f 1+f 2+f 3-f i

private theorem skipSum_eq (f : Fin 4→ℕ) (i : Fin 4) :
    skipSum f i=∑ j∈univ.erase i,f j := by
  have h := sum_erase_add _ f (mem_univ i)
  rw [Fin.sum_univ_four] at h
  unfold skipSum
  omega

def skipProd (f : Fin 4→ℕ) (i : Fin 4) :=
  if i.val<2 then (if i.val=0 then f 1 else f 0)*f 2*f 3
  else f 0*f 1*(if i.val=2 then f 3 else f 2)

private theorem skipProd_eq (f : Fin 4→ℕ) (i : Fin 4) :
    skipProd f i=∏ j∈univ.erase i,f j := by
  have h0 : univ.erase (0:Fin 4)={1,2,3} := by decide
  have h1 : univ.erase (1:Fin 4)={0,2,3} := by decide
  have h2 : univ.erase (2:Fin 4)={0,1,3} := by decide
  have h3 : univ.erase (3:Fin 4)={0,1,2} := by decide
  fin_cases i <;> simp_all [skipProd,Finset.prod_insert,mul_assoc]

private def allOn (mask : ℕ) (test : Fin 4→Bool) :=
  all4 fun i=>if mask.testBit i.val then test i else true

private theorem on_of_true {mask : ℕ} {test : Fin 4→Bool} (h : allOn mask test=true)
    {i : Fin 4} (inside : i∈selected mask) : test i=true := by
  have flag : mask.testBit i.val=true := (mem_filter.mp inside).2
  simpa only [flag,if_true] using (all4_iff.mp h i)

private def denominator (p q mask : ℕ) (b : Box) (i : Fin 4) :=
  high ((b i.castSucc).hi+1) +
    (if mask.testBit i.val then 2 else (b i.castSucc).hi)*high (baseBox p q b i).hi

private def smaller (p q mask : ℕ) (b : Box) (i : Fin 4) :=
  decide (high (4*(8+((baseBox p q b i).hi-1))) + skipSum (denominator p q mask b) i <
    (b i.castSucc).lo*low (baseBox p q b i).lo)

private def strictly (p q : ℕ) (b : Box) (i : Fin 4) :=
  decide (((baseBox p q b i).hi-1)*skipProd (fun j=>(baseBox p q b j).lo) i <
    skipProd (fun j=>((baseBox p q b j).lo-1)*((b j.castSucc).lo+1)) i)

private def noExponent (b : Box) (t : Range) :=
  all4 fun j => decide ((b j.castSucc).hi+1<t.lo ∨
    t.lo=t.hi ∧ (b j.castSucc).hi+1<((b j.castSucc).lo/t.lo+1)*t.lo)

def accept (p q : ℕ) (b : Box) (mask : ℕ) : Bool :=
  let t := selectedTop mask
  all4 (fun i=>decide (1<(baseBox p q b i).lo)) &&
    mask.testBit t.val && allOn mask (fun i=>decide (i≤t)) &&
    allOn mask (smaller p q mask b) &&
    (allOn mask (fun i=>decide (i=t)) || noExponent b (baseBox p q b t) ||
      allOn mask (strictly p q b))

theorem sound {p q mask : ℕ} {b : Box} (yes : accept p q b mask=true) : Deny p q b := by
  apply round_sound (s:=selected mask) (t:=selectedTop mask)
  apply decide_eq_true
  simp only [accept,Bool.and_eq_true_iff,Bool.or_eq_true_iff] at yes
  obtain ⟨⟨⟨⟨start,chosen⟩,top⟩,cmp⟩,why⟩ := yes
  have mem : selectedTop mask∈selected mask := mem_filter.mpr ⟨mem_univ _,chosen⟩
  refine ⟨fun i=>of_decide_eq_true (all4_iff.mp start i),mem,
    fun i hi=>of_decide_eq_true (on_of_true top hi),?_,?_⟩
  · intro i hi
    have raw := of_decide_eq_true (on_of_true cmp hi)
    simpa only [skipSum_eq,denominator,high_eq,low_eq,comparison,powBits,denBits,selected,
      mem_filter,mem_univ,true_and] using raw
  · rcases why with (one|never)|strict
    · left
      ext i
      constructor
      · intro hi
        exact mem_singleton.mpr (of_decide_eq_true (on_of_true one hi))
      · intro hi
        exact (mem_singleton.mp hi) ▸ mem
    · right; left
      exact decide_eq_true fun i=>of_decide_eq_true (all4_iff.mp never i)
    · right;right
      intro i hi
      have raw := of_decide_eq_true (on_of_true strict hi)
      simpa only [skipProd_eq,strictBits] using raw

/-- Replace just the 16 selected-mask leaf instructions. -/
def dispatch (fallback : OMA.SparseEngine245212.Test) (p q : ℕ) (b : Box) (op : ℕ) :=
  if 16≤op ∧ op<32 then accept p q b (op-16) else fallback p q b op

theorem dispatch_sound {fallback : OMA.SparseEngine245212.Test}
    (ok : OMA.SparseEngine245212.TestSound fallback) :
    OMA.SparseEngine245212.TestSound (dispatch fallback) := by
  intro p q b op checked
  unfold dispatch at checked
  split_ifs at checked
  · exact sound checked
  · exact ok p q b op checked

private def pad (p q : ℕ) (b : Box) (i : Fin 4) :=
  high (8+((baseBox p q b i).hi-1)) + skipSum (fun j=>high ((b j.castSucc).hi+1)) i

private def term (p q : ℕ) (b : Box) (j : Fin 4) :=
  (b j.castSucc).hi*high (baseBox p q b j).hi

private def upper (p q : ℕ) (b : Box) (i : Fin 4) :=
  let ceiling := (pad p q b i+skipSum (term p q b) i)/low (baseBox p q b i).lo
  clip b i.castSucc ⟨(b i.castSucc).lo,min (b i.castSucc).hi ceiling⟩

private def lower (p q : ℕ) (b : Box) (i j : Fin 4) :=
  if i=j then b else
  let rest := pad p q b i+(skipSum (term p q b) i-term p q b j)
  let floor := upDiv ((b i.castSucc).lo*low (baseBox p q b i).lo-rest) (high (baseBox p q b j).hi)
  clip b j.castSucc ⟨max (b j.castSucc).lo floor,(b j.castSucc).hi⟩

private theorem upper_eq (p q : ℕ) (b : Box) (i : Fin 4) : upper p q b i=upperClip p q b i := by
  simp only [upper,upperClip,pad,term,skipSum_eq,coefficientHi,high_eq,low_eq]

private theorem lower_eq (p q : ℕ) (b : Box) (i j : Fin 4) : lower p q b i j=lowerClip p q b i j := by
  by_cases same : i=j
  · simp [same,lower,lowerClip]
  have mem : j∈(univ.erase i) := mem_erase.mpr ⟨Ne.symm same,mem_univ _⟩
  have hs := sum_erase_add (univ.erase i) (term p q b) mem
  have eq : skipSum (term p q b) i-term p q b j =
      ∑ k∈(univ.erase i).erase j,term p q b k := by rw [skipSum_eq]; omega
  simp only [lower,lowerClip,if_neg same]
  rw [eq]
  simp only [pad,coefficientHi,term,skipSum_eq,high_eq,low_eq]

private def single (p q op : ℕ) (b : Box) :=
  if all4 (fun i=>decide (1<(baseBox p q b i).lo)) then
    if op<36 then upper p q b (Fin.ofNat 4 (op-32))
    else lower p q b (Fin.ofNat 4 ((op-36)/4)) (Fin.ofNat 4 ((op-36)%4))
  else b

private theorem single_eq (p q op : ℕ) (b : Box) : single p q op b=OMA.SparseEngine245212.single p q op b := by
  simp only [single,OMA.SparseEngine245212.single,all4_iff,decide_eq_true_eq,upper_eq,lower_eq]

open OMA.SparseEngine245212
/-- Replace the height instructions of any independently sound replay engine. -/
def withSingles (fallback : Advance) (p q op : ℕ) (s : Stack) :=
  if 32≤op ∧ op<52 then match s with
  | [] => none
  | b::rest => some (single p q op b::rest)
  else fallback p q op s

theorem withSingles_sound {fallback : Advance} (ok : AdvanceSound fallback) :
    AdvanceSound (withSingles fallback) := by
  intro p q op s t check yes
  unfold withSingles at check
  by_cases special : 32≤op ∧ op<52
  · rw [if_pos special] at check
    cases s with
    | nil => cases check
    | cons b rest =>
      cases Option.some.inj check
      intro x hx
      rcases List.mem_cons.mp hx with rfl|hx
      · intro v fit c
        exact yes _ List.mem_cons_self v ((single_eq p q op _) ▸ single_sound fit c) c
      · exact yes _ (List.mem_cons_of_mem _ hx)
  · rw [if_neg special] at check
    exact ok p q op s t check yes

def withRounds (fallback : Advance) (p q op : ℕ) (s : Stack) :=
  if 16≤op ∧ op<32 then match s with
  | [] => none
  | b::rest => if accept p q b (op-16) then some rest else none
  else fallback p q op s

theorem withRounds_sound {fallback : Advance} (ok : AdvanceSound fallback) :
    AdvanceSound (withRounds fallback) := by
  intro p q op s t check yes
  unfold withRounds at check
  by_cases special : 16≤op ∧ op<32
  · rw [if_pos special] at check
    cases s with
    | nil => cases check
    | cons b rest =>
      dsimp only at check
      split_ifs at check with done
      cases Option.some.inj check
      intro x hx
      exact (List.mem_cons.mp hx).elim (fun e=>e ▸ sound done) (yes x)
  · rw [if_neg special] at check
    exact ok p q op s t check yes

end OMA.FastRound245212
