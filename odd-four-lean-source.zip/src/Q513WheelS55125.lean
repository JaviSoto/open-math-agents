import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S55125
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b55125 : Box := ![⟨54,62⟩,⟨255,1920000000000000011376⟩,⟨12,14⟩,⟨2,451586424625098660952⟩,⟨959,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨54,62⟩,⟨255,1920000000000000011376⟩,⟨12,14⟩,⟨2,451586424625098660952⟩,⟨959,999999999999999999⟩] := by
  have e55125 : Deny 5 13 b55125 := by
    apply closeAction rule_sound _ _ 64 [0x8c88daae32e36ab8cb8daae32e36ab8cb8daae32c226b8c81e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32eb,0x8cb8daae32e36ab8cb8c9ae32020826ab8c8ac21f51eb8c9adaae322b6ab69a6ab68308984a2122d22d22e12922d22ca,0x209aada69aac32122d22d22e12922ca8daae32c21e32236ab8cb8daae32e36ab]
    decide +kernel
  exact e55125
end OMA.Blocks5_13_245212.S55125
