import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S61073
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b61073 : Box := ![⟨47,53⟩,⟨63,126⟩,⟨21,30⟩,⟨1,65⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,53⟩,⟨63,126⟩,⟨21,30⟩,⟨1,65⟩,⟨479,999999999999999999⟩] := by
  have e61073 : Deny 5 13 b61073 := by
    apply closeAction rule_sound _ _ 64 [0x1f85f82382b82b88d72b88c97df0f8087e17e09e365cbe17e36238d8ae362b88d72b88c78c88df7df2d72a12972a32e3,0x84ae378c88dfadf5c21f884a8c8ae32e32631c3e038c90c3e232470c3e23243e37d878c88df7d728a5ca8cb7df0f85f8,0x203e368c78df7c30c80c3e0825728a2972a32e32237df5c30c88475cb84a84a5ca8cb0c3e378c90878dfae32df0f8df6,0xe232078c88dfadf7d728a5ca8c88cb8c9083e231f80e32030c7ac38c88dfae32c98dfac3e03ae326322b8cb0c38c90e3,0x2083e23238083e232780e32078c2083e232078cbe23238083e232380f80e32470c38c80c3]
    decide +kernel
  exact e61073
end OMA.Blocks5_13_245212.S61073
