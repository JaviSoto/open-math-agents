import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S57982
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b57982 : Box := ![⟨47,62⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨1,900178041543026711613⟩,⟨239,478⟩]
private def b57983 : Box := ![⟨47,62⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨1,2⟩,⟨239,478⟩]
private def b57984 : Box := ![⟨47,62⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨3,900178041543026711607⟩,⟨239,478⟩]
private def b57985 : Box := ![⟨47,62⟩,⟨31,41⟩,⟨31,1920000000000000011376⟩,⟨3,900178041543026711607⟩,⟨239,478⟩]
private def b57986 : Box := ![⟨47,62⟩,⟨31,41⟩,⟨31,62⟩,⟨3,900178041543026711601⟩,⟨239,478⟩]
private def b57987 : Box := ![⟨47,62⟩,⟨31,41⟩,⟨31,62⟩,⟨3,6⟩,⟨239,478⟩]
private def b57988 : Box := ![⟨47,62⟩,⟨31,41⟩,⟨31,62⟩,⟨3,4⟩,⟨239,478⟩]
private def b57989 : Box := ![⟨47,62⟩,⟨31,41⟩,⟨31,62⟩,⟨5,6⟩,⟨239,478⟩]
private def b57990 : Box := ![⟨47,62⟩,⟨31,41⟩,⟨31,62⟩,⟨5,5⟩,⟨239,478⟩]
private def b57991 : Box := ![⟨47,53⟩,⟨31,41⟩,⟨31,62⟩,⟨5,5⟩,⟨239,478⟩]
private def b57992 : Box := ![⟨47,53⟩,⟨31,41⟩,⟨31,62⟩,⟨5,5⟩,⟨239,318⟩]
private def b57997 : Box := ![⟨47,53⟩,⟨31,41⟩,⟨31,62⟩,⟨5,5⟩,⟨319,478⟩]
private def b58008 : Box := ![⟨54,62⟩,⟨31,41⟩,⟨31,62⟩,⟨5,5⟩,⟨239,478⟩]
private def b58009 : Box := ![⟨54,62⟩,⟨31,35⟩,⟨31,62⟩,⟨5,5⟩,⟨239,478⟩]
private def b58010 : Box := ![⟨54,62⟩,⟨31,32⟩,⟨31,62⟩,⟨5,5⟩,⟨239,478⟩]
private def b58011 : Box := ![⟨54,62⟩,⟨31,32⟩,⟨31,62⟩,⟨5,5⟩,⟨239,318⟩]
private def b58012 : Box := ![⟨54,62⟩,⟨31,32⟩,⟨31,41⟩,⟨5,5⟩,⟨239,317⟩]
private def b58013 : Box := ![⟨54,62⟩,⟨31,32⟩,⟨42,62⟩,⟨5,5⟩,⟨239,317⟩]
private def b58024 : Box := ![⟨54,62⟩,⟨31,32⟩,⟨31,62⟩,⟨5,5⟩,⟨319,478⟩]
private def b58025 : Box := ![⟨54,62⟩,⟨31,32⟩,⟨31,41⟩,⟨5,5⟩,⟨319,478⟩]
private def b58028 : Box := ![⟨54,62⟩,⟨31,32⟩,⟨42,62⟩,⟨5,5⟩,⟨319,478⟩]
private def b58037 : Box := ![⟨54,62⟩,⟨33,35⟩,⟨31,62⟩,⟨5,5⟩,⟨239,478⟩]
private def b58038 : Box := ![⟨54,62⟩,⟨36,41⟩,⟨31,62⟩,⟨5,5⟩,⟨239,478⟩]
private def b58039 : Box := ![⟨47,62⟩,⟨31,41⟩,⟨31,62⟩,⟨6,6⟩,⟨239,478⟩]
private def b58040 : Box := ![⟨47,62⟩,⟨31,41⟩,⟨31,62⟩,⟨7,56⟩,⟨239,478⟩]
private def b58041 : Box := ![⟨47,62⟩,⟨31,41⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711601⟩,⟨239,478⟩]
private def b58042 : Box := ![⟨47,53⟩,⟨31,41⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711601⟩,⟨239,478⟩]
private def b58043 : Box := ![⟨47,53⟩,⟨31,41⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711599⟩,⟨239,318⟩]
private def b58044 : Box := ![⟨47,53⟩,⟨31,35⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711599⟩,⟨239,317⟩]
private def b58049 : Box := ![⟨47,53⟩,⟨36,41⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711599⟩,⟨239,317⟩]
private def b58056 : Box := ![⟨47,53⟩,⟨31,41⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711599⟩,⟨319,478⟩]
private def b58057 : Box := ![⟨47,53⟩,⟨31,35⟩,⟨63,1920000000000000011376⟩,⟨3,855338345864661659235⟩,⟨319,478⟩]
private def b58062 : Box := ![⟨47,53⟩,⟨36,41⟩,⟨63,1920000000000000011376⟩,⟨3,855338345864661659235⟩,⟨319,478⟩]
private def b58073 : Box := ![⟨54,62⟩,⟨31,41⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711601⟩,⟨239,478⟩]
private def b58074 : Box := ![⟨54,62⟩,⟨31,35⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711601⟩,⟨270,478⟩]
private def b58075 : Box := ![⟨54,62⟩,⟨31,35⟩,⟨63,1920000000000000011376⟩,⟨3,881006776379477255979⟩,⟨270,345⟩]
private def b58078 : Box := ![⟨54,62⟩,⟨31,35⟩,⟨63,1920000000000000011376⟩,⟨3,881006776379477255979⟩,⟨346,478⟩]
private def b58079 : Box := ![⟨54,62⟩,⟨31,35⟩,⟨63,126⟩,⟨3,843447636700648753871⟩,⟨346,478⟩]
private def b58088 : Box := ![⟨54,62⟩,⟨31,35⟩,⟨127,1920000000000000011376⟩,⟨3,843447636700648753871⟩,⟨346,478⟩]
private def b58091 : Box := ![⟨54,62⟩,⟨36,41⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711601⟩,⟨270,478⟩]
private def b58094 : Box := ![⟨47,62⟩,⟨42,62⟩,⟨31,1920000000000000011376⟩,⟨3,900178041543026711607⟩,⟨239,478⟩]
private def b58095 : Box := ![⟨47,62⟩,⟨42,62⟩,⟨31,62⟩,⟨3,900178041543026711607⟩,⟨239,478⟩]
private def b58096 : Box := ![⟨47,62⟩,⟨42,62⟩,⟨31,62⟩,⟨3,6⟩,⟨239,478⟩]
private def b58097 : Box := ![⟨47,62⟩,⟨42,62⟩,⟨31,62⟩,⟨3,4⟩,⟨239,478⟩]
private def b58098 : Box := ![⟨47,62⟩,⟨42,62⟩,⟨31,62⟩,⟨5,6⟩,⟨239,478⟩]
private def b58099 : Box := ![⟨47,62⟩,⟨42,62⟩,⟨31,62⟩,⟨5,5⟩,⟨245,478⟩]
private def b58100 : Box := ![⟨47,53⟩,⟨42,62⟩,⟨31,62⟩,⟨5,5⟩,⟨245,478⟩]
private def b58101 : Box := ![⟨47,53⟩,⟨42,62⟩,⟨31,62⟩,⟨5,5⟩,⟨245,324⟩]
private def b58102 : Box := ![⟨47,53⟩,⟨42,62⟩,⟨31,62⟩,⟨5,5⟩,⟨325,478⟩]
private def b58103 : Box := ![⟨47,49⟩,⟨42,62⟩,⟨31,62⟩,⟨5,5⟩,⟨325,478⟩]
private def b58104 : Box := ![⟨47,49⟩,⟨42,50⟩,⟨31,62⟩,⟨5,5⟩,⟨325,478⟩]
private def b58105 : Box := ![⟨47,49⟩,⟨42,50⟩,⟨31,41⟩,⟨5,5⟩,⟨325,478⟩]
private def b58108 : Box := ![⟨47,49⟩,⟨42,50⟩,⟨42,62⟩,⟨5,5⟩,⟨325,478⟩]
private def b58109 : Box := ![⟨47,49⟩,⟨42,50⟩,⟨42,62⟩,⟨5,5⟩,⟨325,386⟩]
private def b58118 : Box := ![⟨47,49⟩,⟨42,50⟩,⟨42,62⟩,⟨5,5⟩,⟨387,478⟩]
private def b58127 : Box := ![⟨47,49⟩,⟨51,62⟩,⟨31,62⟩,⟨5,5⟩,⟨325,478⟩]
private def b58134 : Box := ![⟨50,53⟩,⟨42,62⟩,⟨31,62⟩,⟨5,5⟩,⟨325,478⟩]
private def b58135 : Box := ![⟨54,62⟩,⟨42,62⟩,⟨31,62⟩,⟨5,5⟩,⟨245,478⟩]
private def b58136 : Box := ![⟨47,62⟩,⟨42,62⟩,⟨31,62⟩,⟨6,6⟩,⟨245,478⟩]
private def b58137 : Box := ![⟨47,62⟩,⟨42,62⟩,⟨31,62⟩,⟨7,63⟩,⟨239,478⟩]
private def b58138 : Box := ![⟨47,62⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711607⟩,⟨239,478⟩]
private def b58139 : Box := ![⟨47,53⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711607⟩,⟨357,478⟩]
private def b58140 : Box := ![⟨47,53⟩,⟨42,50⟩,⟨63,1920000000000000011376⟩,⟨3,55⟩,⟨359,467⟩]
private def b58151 : Box := ![⟨47,53⟩,⟨51,62⟩,⟨63,1920000000000000011376⟩,⟨3,55⟩,⟨359,467⟩]
private def b58152 : Box := ![⟨54,62⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711607⟩,⟨357,478⟩]
private theorem e57983 : Deny 5 13 b57983 := by
    apply closeAction rule_sound _ _ 64 [0x5e2]
    decide +kernel
private theorem e57988 : Deny 5 13 b57988 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e57992 : Deny 5 13 b57992 := by
    apply closeAction rule_sound _ _ 64 [0x5d75f8da2222204]
    decide +kernel
private theorem e57997 : Deny 5 13 b57997 := by
    apply closeAction rule_sound _ _ 64 [0x5d75f8d87e361d7088d84087e36888]
    decide +kernel
private theorem e57991 : Deny 5 13 b57991 :=
    branchAction rule_sound _ _ 1
      0xb b57991 b57992 b57997 (by decide +kernel) e57992 e57997
private theorem e58012 : Deny 5 13 b58012 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e58013 : Deny 5 13 b58013 := by
    apply closeAction rule_sound _ _ 64 [0x5c20c90f68872045cb1172f8]
    decide +kernel
private theorem e58011 : Deny 5 13 b58011 :=
    branchAction rule_sound _ _ 2
      0x244 b58011 b58012 b58013 (by decide +kernel) e58012 e58013
private theorem e58025 : Deny 5 13 b58025 := by
    apply closeAction rule_sound _ _ 64 [0x170f8d84238]
    decide +kernel
private theorem e58028 : Deny 5 13 b58028 := by
    apply closeAction rule_sound _ _ 64 [0xf80f81f80c95c3e36884238887]
    decide +kernel
private theorem e58024 : Deny 5 13 b58024 :=
    branchAction rule_sound _ _ 1
      0x9 b58024 b58025 b58028 (by decide +kernel) e58025 e58028
private theorem e58010 : Deny 5 13 b58010 :=
    branchAction rule_sound _ _ 1
      0xb b58010 b58011 b58024 (by decide +kernel) e58011 e58024
private theorem e58037 : Deny 5 13 b58037 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e58009 : Deny 5 13 b58009 :=
    branchAction rule_sound _ _ 1
      0x8 b58009 b58010 b58037 (by decide +kernel) e58010 e58037
private theorem e58038 : Deny 5 13 b58038 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e58008 : Deny 5 13 b58008 :=
    branchAction rule_sound _ _ 1
      0x8 b58008 b58009 b58038 (by decide +kernel) e58009 e58038
private theorem e57990 : Deny 5 13 b57990 :=
    branchAction rule_sound _ _ 1
      0x7 b57990 b57991 b58008 (by decide +kernel) e57991 e58008
private theorem e58039 : Deny 5 13 b58039 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e57989 : Deny 5 13 b57989 :=
    branchAction rule_sound _ _ 1
      0xa b57989 b57990 b58039 (by decide +kernel) e57990 e58039
private theorem e57987 : Deny 5 13 b57987 :=
    branchAction rule_sound _ _ 1
      0xa b57987 b57988 b57989 (by decide +kernel) e57988 e57989
private theorem e58040 : Deny 5 13 b58040 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e57986 : Deny 5 13 b57986 :=
    branchAction rule_sound _ _ 2
      0x2a3 b57986 b57987 b58040 (by decide +kernel) e57987 e58040
private theorem e58044 : Deny 5 13 b58044 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe311c278bdfbe3263]
    decide +kernel
private theorem e58049 : Deny 5 13 b58049 := by
    apply closeAction rule_sound _ _ 64 [0x50209fbe2108e2f8841f8be2109e37]
    decide +kernel
private theorem e58043 : Deny 5 13 b58043 :=
    branchAction rule_sound _ _ 2
      0x204 b58043 b58044 b58049 (by decide +kernel) e58044 e58049
private theorem e58057 : Deny 5 13 b58057 := by
    apply closeAction rule_sound _ _ 64 [0x72f709bdfbe3263]
    decide +kernel
private theorem e58062 : Deny 5 13 b58062 := by
    apply closeAction rule_sound _ _ 64 [0xaf8c472f8c4278bdfbdf7c3e2db222a22a326f8c9]
    decide +kernel
private theorem e58056 : Deny 5 13 b58056 :=
    branchAction rule_sound _ _ 2
      0x223 b58056 b58057 b58062 (by decide +kernel) e58057 e58062
private theorem e58042 : Deny 5 13 b58042 :=
    branchAction rule_sound _ _ 2
      0x2e3 b58042 b58043 b58056 (by decide +kernel) e58043 e58056
private theorem e58075 : Deny 5 13 b58075 := by
    apply closeAction rule_sound _ _ 64 [0x1f882bedb222b78c4]
    decide +kernel
private theorem e58079 : Deny 5 13 b58079 := by
    apply closeAction rule_sound _ _ 64 [0x1fbdf7d70afb2222c88a88a8c9be3]
    decide +kernel
private theorem e58088 : Deny 5 13 b58088 := by
    apply closeAction rule_sound _ _ 64 [0x9cbe3109e2f]
    decide +kernel
private theorem e58078 : Deny 5 13 b58078 :=
    branchAction rule_sound _ _ 2
      0x263 b58078 b58079 b58088 (by decide +kernel) e58079 e58088
private theorem e58074 : Deny 5 13 b58074 :=
    branchAction rule_sound _ _ 2
      0x2e3 b58074 b58075 b58078 (by decide +kernel) e58075 e58078
private theorem e58091 : Deny 5 13 b58091 := by
    apply closeAction rule_sound _ _ 64 [0x97278de3]
    decide +kernel
private theorem e58073 : Deny 5 13 b58073 :=
    branchAction rule_sound _ _ 2
      0x238 b58073 b58074 b58091 (by decide +kernel) e58074 e58091
private theorem e58041 : Deny 5 13 b58041 :=
    branchAction rule_sound _ _ 1
      0x7 b58041 b58042 b58073 (by decide +kernel) e58042 e58073
private theorem e57985 : Deny 5 13 b57985 :=
    branchAction rule_sound _ _ 2
      0x263 b57985 b57986 b58041 (by decide +kernel) e57986 e58041
private theorem e58097 : Deny 5 13 b58097 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e58101 : Deny 5 13 b58101 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e58105 : Deny 5 13 b58105 := by
    apply closeAction rule_sound _ _ 64 [0x1f5cb]
    decide +kernel
private theorem e58109 : Deny 5 13 b58109 := by
    apply closeAction rule_sound _ _ 64 [0x17083109e032045cb1c4]
    decide +kernel
private theorem e58118 : Deny 5 13 b58118 := by
    apply closeAction rule_sound _ _ 64 [0x1f0970c721f2442c4]
    decide +kernel
private theorem e58108 : Deny 5 13 b58108 :=
    branchAction rule_sound _ _ 1
      0xb b58108 b58109 b58118 (by decide +kernel) e58109 e58118
private theorem e58104 : Deny 5 13 b58104 :=
    branchAction rule_sound _ _ 1
      0x9 b58104 b58105 b58108 (by decide +kernel) e58105 e58108
private theorem e58127 : Deny 5 13 b58127 := by
    apply closeAction rule_sound _ _ 64 [0x27f85c31c8278]
    decide +kernel
private theorem e58103 : Deny 5 13 b58103 :=
    branchAction rule_sound _ _ 1
      0x8 b58103 b58104 b58127 (by decide +kernel) e58104 e58127
private theorem e58134 : Deny 5 13 b58134 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e58102 : Deny 5 13 b58102 :=
    branchAction rule_sound _ _ 1
      0x7 b58102 b58103 b58134 (by decide +kernel) e58103 e58134
private theorem e58100 : Deny 5 13 b58100 :=
    branchAction rule_sound _ _ 1
      0xb b58100 b58101 b58102 (by decide +kernel) e58101 e58102
private theorem e58135 : Deny 5 13 b58135 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e58099 : Deny 5 13 b58099 :=
    branchAction rule_sound _ _ 1
      0x7 b58099 b58100 b58135 (by decide +kernel) e58100 e58135
private theorem e58136 : Deny 5 13 b58136 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e58098 : Deny 5 13 b58098 :=
    branchAction rule_sound _ _ 2
      0x2b8 b58098 b58099 b58136 (by decide +kernel) e58099 e58136
private theorem e58096 : Deny 5 13 b58096 :=
    branchAction rule_sound _ _ 1
      0xa b58096 b58097 b58098 (by decide +kernel) e58097 e58098
private theorem e58137 : Deny 5 13 b58137 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e58095 : Deny 5 13 b58095 :=
    branchAction rule_sound _ _ 2
      0x2a3 b58095 b58096 b58137 (by decide +kernel) e58096 e58137
private theorem e58140 : Deny 5 13 b58140 := by
    apply closeAction rule_sound _ _ 64 [0x20827df0e22a2284278be22221e2]
    decide +kernel
private theorem e58151 : Deny 5 13 b58151 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e58139 : Deny 5 13 b58139 :=
    branchAction rule_sound _ _ 4
      0x2378c4 b58139 b58140 b58151 (by decide +kernel) e58140 e58151
private theorem e58152 : Deny 5 13 b58152 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e58138 : Deny 5 13 b58138 :=
    branchAction rule_sound _ _ 2
      0x1f8 b58138 b58139 b58152 (by decide +kernel) e58139 e58152
private theorem e58094 : Deny 5 13 b58094 :=
    branchAction rule_sound _ _ 1
      0x9 b58094 b58095 b58138 (by decide +kernel) e58095 e58138
private theorem e57984 : Deny 5 13 b57984 :=
    branchAction rule_sound _ _ 1
      0x8 b57984 b57985 b58094 (by decide +kernel) e57985 e58094
private theorem e57982 : Deny 5 13 b57982 :=
    branchAction rule_sound _ _ 2
      0x2a3 b57982 b57983 b57984 (by decide +kernel) e57983 e57984
theorem deny5_13 : Deny 5 13 ![⟨47,62⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨1,900178041543026711613⟩,⟨239,478⟩] := by
  exact e57982
end OMA.Blocks5_13_245212.S57982
