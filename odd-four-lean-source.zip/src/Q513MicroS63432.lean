import FastReplay245212
import SparseDigit245212
import WheelRule245212

import Q513Under63432S63435
import Q513Under63432S63438
import Q513Under63432S63444
import Q513Under63432S63447
import Q513Under63432S63451

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S63432
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b63432 : Box := ![⟨153,190⟩,⟨36,41⟩,⟨12,14⟩,⟨1,53⟩,⟨959,999999999999999999⟩]
private def b63433 : Box := ![⟨153,190⟩,⟨36,41⟩,⟨12,14⟩,⟨2,53⟩,⟨959,1918⟩]
private def b63434 : Box := ![⟨153,190⟩,⟨36,38⟩,⟨12,14⟩,⟨7,48⟩,⟨959,1918⟩]
private def b63435 : Box := ![⟨153,190⟩,⟨36,38⟩,⟨12,12⟩,⟨8,47⟩,⟨959,1918⟩]
private def b63438 : Box := ![⟨153,190⟩,⟨36,38⟩,⟨13,14⟩,⟨8,47⟩,⟨959,1918⟩]
private def b63441 : Box := ![⟨153,190⟩,⟨39,41⟩,⟨12,14⟩,⟨7,48⟩,⟨959,1918⟩]
private def b63442 : Box := ![⟨153,190⟩,⟨36,41⟩,⟨12,14⟩,⟨2,53⟩,⟨1919,999999999999999999⟩]
private def b63443 : Box := ![⟨153,190⟩,⟨36,41⟩,⟨12,12⟩,⟨2,48⟩,⟨1919,999999999999999999⟩]
private def b63444 : Box := ![⟨153,190⟩,⟨36,38⟩,⟨12,12⟩,⟨2,47⟩,⟨1919,999999999999999999⟩]
private def b63447 : Box := ![⟨153,190⟩,⟨39,41⟩,⟨12,12⟩,⟨2,47⟩,⟨1919,999999999999999999⟩]
private def b63450 : Box := ![⟨153,190⟩,⟨36,41⟩,⟨13,14⟩,⟨2,48⟩,⟨1919,999999999999999999⟩]
private def b63451 : Box := ![⟨153,190⟩,⟨36,38⟩,⟨13,14⟩,⟨2,48⟩,⟨1919,999999999999999999⟩]
private def b63456 : Box := ![⟨153,190⟩,⟨39,41⟩,⟨13,14⟩,⟨2,48⟩,⟨1919,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨153,190⟩,⟨36,41⟩,⟨12,14⟩,⟨1,53⟩,⟨959,999999999999999999⟩] := by
  have e63435 : Deny 5 13 b63435 := OMA.Blocks5_13_245212.S63435.deny5_13
  have e63438 : Deny 5 13 b63438 := OMA.Blocks5_13_245212.S63438.deny5_13
  have e63434 : Deny 5 13 b63434 :=
    branchAction rule_sound _ _ 3
      0x99e3 b63434 b63435 b63438 (by decide +kernel) e63435 e63438
  have e63441 : Deny 5 13 b63441 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e63433 : Deny 5 13 b63433 :=
    branchAction rule_sound _ _ 3
      0x89e3 b63433 b63434 b63441 (by decide +kernel) e63434 e63441
  have e63444 : Deny 5 13 b63444 := OMA.Blocks5_13_245212.S63444.deny5_13
  have e63447 : Deny 5 13 b63447 := OMA.Blocks5_13_245212.S63447.deny5_13
  have e63443 : Deny 5 13 b63443 :=
    branchAction rule_sound _ _ 2
      0x223 b63443 b63444 b63447 (by decide +kernel) e63444 e63447
  have e63451 : Deny 5 13 b63451 := OMA.Blocks5_13_245212.S63451.deny5_13
  have e63456 : Deny 5 13 b63456 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e63450 : Deny 5 13 b63450 :=
    branchAction rule_sound _ _ 1
      0x8 b63450 b63451 b63456 (by decide +kernel) e63451 e63456
  have e63442 : Deny 5 13 b63442 :=
    branchAction rule_sound _ _ 2
      0x263 b63442 b63443 b63450 (by decide +kernel) e63443 e63450
  have e63432 : Deny 5 13 b63432 :=
    branchAction rule_sound _ _ 2
      0x2e7 b63432 b63433 b63442 (by decide +kernel) e63433 e63442
  exact e63432
end OMA.Blocks5_13_245212.S63432
