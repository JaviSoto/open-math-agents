import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S63327
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b63327 : Box := ![⟨127,190⟩,⟨36,41⟩,⟨12,14⟩,⟨4,53⟩,⟨479,958⟩]
private def b63328 : Box := ![⟨127,152⟩,⟨36,41⟩,⟨12,14⟩,⟨4,53⟩,⟨494,958⟩]
private def b63329 : Box := ![⟨127,152⟩,⟨36,41⟩,⟨12,14⟩,⟨4,46⟩,⟨494,651⟩]
private def b63334 : Box := ![⟨127,152⟩,⟨36,41⟩,⟨12,14⟩,⟨4,46⟩,⟨652,958⟩]
private def b63343 : Box := ![⟨153,190⟩,⟨36,41⟩,⟨12,14⟩,⟨4,53⟩,⟨494,958⟩]
private theorem e63329 : Deny 5 13 b63329 := by
    apply closeAction rule_sound _ _ 64 [0x2083e278c8e278c9]
    decide +kernel
private theorem e63334 : Deny 5 13 b63334 := by
    apply closeAction rule_sound _ _ 64 [0x820e31f89e32380f80e78c89e3263]
    decide +kernel
private theorem e63328 : Deny 5 13 b63328 :=
    branchAction rule_sound _ _ 2
      0x2e3 b63328 b63329 b63334 (by decide +kernel) e63329 e63334
private theorem e63343 : Deny 5 13 b63343 := by
    apply closeAction rule_sound _ _ 64 [0x20f8de7804278de7]
    decide +kernel
private theorem e63327 : Deny 5 13 b63327 :=
    branchAction rule_sound _ _ 2
      0x1f8 b63327 b63328 b63343 (by decide +kernel) e63328 e63343
theorem deny5_13 : Deny 5 13 ![⟨127,190⟩,⟨36,41⟩,⟨12,14⟩,⟨4,53⟩,⟨479,958⟩] := by
  exact e63327
end OMA.Blocks5_13_245212.S63327
