import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S50297
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b50297 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨63,1920000000000000011376⟩,⟨1,718295185477505923790⟩,⟨959,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,126⟩,⟨21,22⟩,⟨63,1920000000000000011376⟩,⟨1,718295185477505923790⟩,⟨959,999999999999999999⟩] := by
  have e50297 : Deny 5 13 b50297 := by
    apply closeAction rule_sound _ _ 64 [0x555e36887e1de37da21f6555578da21f888788b54ae22578da2238882884087e36887e222b82b88d5e222b88c957888a,0x8cb8ddbe32e376f8cb8ddbe32c21e376f8cb8ddbe32c222376f8cb8ddbe32ef8c98dcbdd26f8cb72f8ddbe32788c775d,0x74b8dd2e374b8dd2e376f8cb8ddbe32e376f8cb8ddbe32e376f8cb8ddbe32e376f8cb8ddbe32e376f8cb8ddbe32e376f,0x2dd2dd2dd2c3bc21f688774b74b74b74b74b74b74b74b74b88a8dd2e374b74b8dd2e374b8dd2e374b8dd2e374b8dd2e3,0x878c9da374b087be32422368c78dcbe32e372f8cb8dcbe32e372f8cb8dcbe32e372f8cb8dcbe32ef71c0c21e229d2dd,0x8272f8c9e2f72f8c9d87bdcbe3247bdcbe326f72f8c9bc21f620208272f8c9bdcbe32761ef72f8c9d87bdcbc3bc38c9,0x82]
    decide +kernel
  exact e50297
end OMA.Blocks5_13_245212.S50297
