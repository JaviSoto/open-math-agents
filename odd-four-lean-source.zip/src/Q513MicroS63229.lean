import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S63229
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b63229 : Box := ![⟨127,190⟩,⟨31,35⟩,⟨10,11⟩,⟨5,52⟩,⟨479,958⟩]
private def b63230 : Box := ![⟨127,152⟩,⟨31,35⟩,⟨10,11⟩,⟨7,50⟩,⟨479,930⟩]
private def b63235 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨10,11⟩,⟨7,50⟩,⟨479,930⟩]
private def b63236 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨10,11⟩,⟨11,18⟩,⟨479,930⟩]
private def b63237 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨10,11⟩,⟨11,18⟩,⟨479,625⟩]
private def b63246 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨10,11⟩,⟨11,18⟩,⟨626,899⟩]
private def b63253 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨10,11⟩,⟨19,50⟩,⟨479,930⟩]
private theorem e63230 : Deny 5 13 b63230 := by
    apply closeAction rule_sound _ _ 64 [0xc2244088e23]
    decide +kernel
private theorem e63237 : Deny 5 13 b63237 := by
    apply closeAction rule_sound _ _ 64 [0x3e03e090c80e7804089e20227]
    decide +kernel
private theorem e63246 : Deny 5 13 b63246 := by
    apply closeAction rule_sound _ _ 64 [0x39c3e07089088]
    decide +kernel
private theorem e63236 : Deny 5 13 b63236 :=
    branchAction rule_sound _ _ 2
      0x2f8 b63236 b63237 b63246 (by decide +kernel) e63237 e63246
private theorem e63253 : Deny 5 13 b63253 := by
    apply closeAction rule_sound _ _ 64 [0x19]
    decide +kernel
private theorem e63235 : Deny 5 13 b63235 :=
    branchAction rule_sound _ _ 2
      0x2a7 b63235 b63236 b63253 (by decide +kernel) e63236 e63253
private theorem e63229 : Deny 5 13 b63229 :=
    branchAction rule_sound _ _ 4
      0x1f89e3 b63229 b63230 b63235 (by decide +kernel) e63230 e63235
theorem deny5_13 : Deny 5 13 ![⟨127,190⟩,⟨31,35⟩,⟨10,11⟩,⟨5,52⟩,⟨479,958⟩] := by
  exact e63229
end OMA.Blocks5_13_245212.S63229
