import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S23624
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b23624 : Box := ![⟨23,30⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨1,1657986577181208063543⟩,⟨127,211⟩]
theorem deny5_13 : Deny 5 13 ![⟨23,30⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨1,1657986577181208063543⟩,⟨127,211⟩] := by
  have e23624 : Deny 5 13 b23624 := by
    apply closeAction rule_sound _ _ 64 [0x26b102238de325a088e37db58c80a1284087e37d63109e2321aada21a8c87b8db584a0abaa128448ae36d631c2aa12a3,0x79f0c47b8df6108e072830f8de322324b0c3e371c3e372440f8df6108e3629ee37da31f78c82c40eb0f88c80f88c90c2,0x11e0c3e3784908784a0c21eb6b8df68c8de324b8c70dfe37d87844087e2baa12830f8de325ee37da31dee37da32368c4,0xe37d872212830c7ac3087de322326311e7c30e12611e1283e370c7ac30f71e322324b0c21dae37ae325ae37da3237da3,0x11e79e0dfe362021e12a128a7c21f8de1283087ac4088e37ae32442c21dee37db58c8df58c479fe370e11c3ae126b7c3,0x1021f8dab8497b8df6847da111e683e03e211e12ab8496ab849ae110be2110ae2b8c8ae322b0c21dae378c90a3237da3,0x6ab6ab69e783e2b844278ae1243ae1]
    decide +kernel
  exact e23624
end OMA.Blocks5_13_245212.S23624
