import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S63447
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b63447 : Box := ![⟨153,190⟩,⟨39,41⟩,⟨12,12⟩,⟨2,47⟩,⟨1919,999999999999999999⟩]
private def b63448 : Box := ![⟨153,169⟩,⟨39,41⟩,⟨12,12⟩,⟨2,47⟩,⟨1919,999999999999999999⟩]
private def b63449 : Box := ![⟨170,190⟩,⟨39,41⟩,⟨12,12⟩,⟨2,47⟩,⟨1919,999999999999999999⟩]
private theorem e63448 : Deny 5 13 b63448 := by
    apply closeAction rule_sound _ _ 64 [0xe3]
    decide +kernel
private theorem e63449 : Deny 5 13 b63449 := by
    apply closeAction rule_sound _ _ 64 [0xf8]
    decide +kernel
private theorem e63447 : Deny 5 13 b63447 :=
    branchAction rule_sound _ _ 1
      0x7 b63447 b63448 b63449 (by decide +kernel) e63448 e63449
theorem deny5_13 : Deny 5 13 ![⟨153,190⟩,⟨39,41⟩,⟨12,12⟩,⟨2,47⟩,⟨1919,999999999999999999⟩] := by
  exact e63447
end OMA.Blocks5_13_245212.S63447
