import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S35487
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b35487 : Box := ![⟨47,94⟩,⟨15,30⟩,⟨7,14⟩,⟨1,2⟩,⟨59,113⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,94⟩,⟨15,30⟩,⟨7,14⟩,⟨1,2⟩,⟨59,113⟩] := by
  have e35487 : Deny 5 13 b35487 := by
    apply closeAction rule_sound _ _ 64 [0xde02202575c30f82092430f82132431021f8d88257d8a1d70c4089e20243804088e368085c2238d87d8280ada022010b,0x257df6d445c30f8d88087dc95f8df62042f8d875c2238df6d748081175c3e250c78098095ca0c38080c74e0243102278,0x170c3e20217089e070881170e50c78098042e02572830f88080f81c2260102238de0]
    decide +kernel
  exact e35487
end OMA.Blocks5_13_245212.S35487
