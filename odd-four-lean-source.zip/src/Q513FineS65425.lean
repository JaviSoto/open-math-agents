import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S65425
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b65425 : Box := ![⟨191,1920000000000000011376⟩,⟨63,1920000000000000011376⟩,⟨7,14⟩,⟨1,951454005934718106560⟩,⟨239,999999999999999999⟩]
private def b65426 : Box := ![⟨191,1920000000000000011376⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨1,951454005934718106560⟩,⟨336,999999999999999999⟩]
private def b65427 : Box := ![⟨191,1920000000000000011376⟩,⟨63,126⟩,⟨7,9⟩,⟨1,895642458100558664552⟩,⟨336,999999999999999999⟩]
private def b65428 : Box := ![⟨191,1920000000000000011376⟩,⟨63,126⟩,⟨7,9⟩,⟨1,362905027932960896060⟩,⟨336,672⟩]
private def b65435 : Box := ![⟨191,1920000000000000011376⟩,⟨63,126⟩,⟨7,9⟩,⟨1,362905027932960896060⟩,⟨673,999999999999999999⟩]
private def b65436 : Box := ![⟨191,382⟩,⟨63,126⟩,⟨7,9⟩,⟨1,324259567387687189990⟩,⟨673,999999999999999999⟩]
private def b65663 : Box := ![⟨383,1920000000000000011376⟩,⟨63,126⟩,⟨7,9⟩,⟨1,324259567387687189990⟩,⟨673,999999999999999999⟩]
private def b65726 : Box := ![⟨191,1920000000000000011376⟩,⟨127,1920000000000000011376⟩,⟨7,9⟩,⟨1,895642458100558664552⟩,⟨336,999999999999999999⟩]
private def b65727 : Box := ![⟨191,1920000000000000011376⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨1,951454005934718106560⟩,⟨336,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨191,1920000000000000011376⟩,⟨63,1920000000000000011376⟩,⟨7,14⟩,⟨1,951454005934718106560⟩,⟨239,999999999999999999⟩] := by
  have e65428 : Deny 5 13 b65428 := by
    apply closeAction rule_sound _ _ 64 [0x20826f89e32232631e3]
    decide +kernel
  have e65436 : Deny 5 13 b65436 := by
    apply closeAction rule_sound _ _ 64 [0x8cb0888db9e32e36e78cb6e78c22388c78db9db4ca6e78c88c79e32db9e36e78c7e232231e36db9e02a78cb9e3223263,0x6e78cb8db9e32e36e78cb8db9e32e36e78cb8db9e32e36e78cb8db9e32e36e78cb8db9e32e70c32270878db9e32e36e7,0x6cb8db2e36cb8db2db2e36cb8db2e36cb8db2e36cb8db9e32e36e78cb8db9e32e36e78cb8db9e32e36e78cb8db9e32e3,0x8cbe232384cae231f809b6d96ca9c82231d99c30e31c22231e70879e321b2db2e36cb6cb8db2db2e36cb6cb8db2e36cb,0x2388c7e230820f80f88c8e231f88c8e020f88c8e230f80f88c8e231f80c3e2321b4cae231e36d32a78cb8c88c78db4ca,0x6e78cb8db9e32e36e78cb8db9e32e36e78cb8db9e32e36e78cbe231f88c9e278c8e231f88c8e020820820f82388c7e23,0x820820838c70c38c78c86e78cb8db9e32e36e78cb8db9e32e36e78cb8db9e32e36e78cb8db9e32e36e78cb8db9e32e3,0x2]
    decide +kernel
  have e65663 : Deny 5 13 b65663 := by
    apply closeAction rule_sound _ _ 64 [0x2d12d12d12d12d12d12d12ca8db2e36cb8db2e36cb8db2e36cb8db2e36cb8db2f88c8e231f88c8e278c7e278c88c9e27,0x820820826599d964380a44b44b44b80a1d12d1]
    decide +kernel
  have e65435 : Deny 5 13 b65435 :=
    branchAction rule_sound _ _ 2
      0x1e3 b65435 b65436 b65663 (by decide +kernel) e65436 e65663
  have e65427 : Deny 5 13 b65427 :=
    branchAction rule_sound _ _ 2
      0x2e3 b65427 b65428 b65435 (by decide +kernel) e65428 e65435
  have e65726 : Deny 5 13 b65726 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e65426 : Deny 5 13 b65426 :=
    branchAction rule_sound _ _ 2
      0x223 b65426 b65427 b65726 (by decide +kernel) e65427 e65726
  have e65727 : Deny 5 13 b65727 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e65425 : Deny 5 13 b65425 :=
    branchAction rule_sound _ _ 2
      0x278 b65425 b65426 b65727 (by decide +kernel) e65426 e65727
  exact e65425
end OMA.Blocks5_13_245212.S65425
