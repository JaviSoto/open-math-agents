import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S31718
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b31718 : Box := ![⟨38,41⟩,⟨85,126⟩,⟨63,126⟩,⟨1,718295185477505923801⟩,⟨959,999999999999999999⟩]
private def b31719 : Box := ![⟨38,41⟩,⟨85,126⟩,⟨63,126⟩,⟨1,91⟩,⟨959,1918⟩]
private def b31724 : Box := ![⟨38,41⟩,⟨85,126⟩,⟨63,126⟩,⟨1,91⟩,⟨1919,999999999999999999⟩]
private def b31725 : Box := ![⟨38,41⟩,⟨85,101⟩,⟨63,126⟩,⟨1,82⟩,⟨1919,999999999999999999⟩]
private def b31726 : Box := ![⟨38,39⟩,⟨85,101⟩,⟨63,126⟩,⟨1,77⟩,⟨1919,999999999999999999⟩]
private def b31737 : Box := ![⟨40,41⟩,⟨85,101⟩,⟨63,126⟩,⟨1,77⟩,⟨1919,999999999999999999⟩]
private def b31738 : Box := ![⟨40,41⟩,⟨85,101⟩,⟨63,84⟩,⟨1,77⟩,⟨1919,999999999999999999⟩]
private def b31739 : Box := ![⟨40,41⟩,⟨85,101⟩,⟨63,84⟩,⟨1,63⟩,⟨1919,3838⟩]
private def b31744 : Box := ![⟨40,41⟩,⟨85,101⟩,⟨63,84⟩,⟨1,63⟩,⟨3839,999999999999999999⟩]
private def b31745 : Box := ![⟨40,41⟩,⟨85,92⟩,⟨63,84⟩,⟨1,57⟩,⟨3839,999999999999999999⟩]
private def b31748 : Box := ![⟨40,41⟩,⟨93,101⟩,⟨63,84⟩,⟨1,57⟩,⟨3839,999999999999999999⟩]
private def b31757 : Box := ![⟨40,41⟩,⟨85,101⟩,⟨85,126⟩,⟨1,77⟩,⟨1919,999999999999999999⟩]
private def b31758 : Box := ![⟨40,41⟩,⟨85,101⟩,⟨85,126⟩,⟨1,77⟩,⟨1919,3838⟩]
private def b31765 : Box := ![⟨40,41⟩,⟨85,101⟩,⟨85,126⟩,⟨1,77⟩,⟨3839,999999999999999999⟩]
private def b31766 : Box := ![⟨40,41⟩,⟨85,92⟩,⟨85,126⟩,⟨1,71⟩,⟨3839,999999999999999999⟩]
private def b31767 : Box := ![⟨40,41⟩,⟨85,92⟩,⟨85,101⟩,⟨1,69⟩,⟨3839,999999999999999999⟩]
private def b31772 : Box := ![⟨40,41⟩,⟨85,92⟩,⟨102,126⟩,⟨1,69⟩,⟨3839,999999999999999999⟩]
private def b31779 : Box := ![⟨40,41⟩,⟨93,101⟩,⟨85,126⟩,⟨1,71⟩,⟨3839,999999999999999999⟩]
private def b31780 : Box := ![⟨40,41⟩,⟨93,101⟩,⟨85,126⟩,⟨1,2⟩,⟨3839,999999999999999999⟩]
private def b31781 : Box := ![⟨40,41⟩,⟨93,101⟩,⟨85,126⟩,⟨3,71⟩,⟨3839,999999999999999999⟩]
private def b31782 : Box := ![⟨40,41⟩,⟨93,101⟩,⟨85,101⟩,⟨3,71⟩,⟨3839,999999999999999999⟩]
private def b31789 : Box := ![⟨40,41⟩,⟨93,101⟩,⟨102,126⟩,⟨3,71⟩,⟨3839,999999999999999999⟩]
private def b31798 : Box := ![⟨38,41⟩,⟨102,126⟩,⟨63,126⟩,⟨1,82⟩,⟨1919,999999999999999999⟩]
private def b31799 : Box := ![⟨38,41⟩,⟨102,126⟩,⟨63,126⟩,⟨1,2⟩,⟨1919,999999999999999999⟩]
private def b31800 : Box := ![⟨38,41⟩,⟨102,126⟩,⟨63,126⟩,⟨3,82⟩,⟨1919,999999999999999999⟩]
private def b31801 : Box := ![⟨38,39⟩,⟨102,126⟩,⟨63,126⟩,⟨3,82⟩,⟨1919,999999999999999999⟩]
private def b31802 : Box := ![⟨38,39⟩,⟨102,126⟩,⟨63,84⟩,⟨3,82⟩,⟨1919,999999999999999999⟩]
private def b31803 : Box := ![⟨38,39⟩,⟨102,126⟩,⟨63,84⟩,⟨3,6⟩,⟨1919,38116⟩]
private def b31804 : Box := ![⟨38,39⟩,⟨102,126⟩,⟨63,84⟩,⟨7,68⟩,⟨1919,38116⟩]
private def b31815 : Box := ![⟨38,39⟩,⟨102,126⟩,⟨85,126⟩,⟨3,82⟩,⟨1919,999999999999999999⟩]
private def b31816 : Box := ![⟨38,39⟩,⟨102,126⟩,⟨85,126⟩,⟨3,82⟩,⟨1919,3838⟩]
private def b31821 : Box := ![⟨38,39⟩,⟨102,126⟩,⟨85,126⟩,⟨3,82⟩,⟨3839,999999999999999999⟩]
private def b31822 : Box := ![⟨38,39⟩,⟨102,112⟩,⟨85,126⟩,⟨3,75⟩,⟨3839,999999999999999999⟩]
private def b31823 : Box := ![⟨38,38⟩,⟨102,112⟩,⟨85,126⟩,⟨3,72⟩,⟨3839,999999999999999999⟩]
private def b31824 : Box := ![⟨39,39⟩,⟨102,112⟩,⟨85,126⟩,⟨3,72⟩,⟨3839,999999999999999999⟩]
private def b31825 : Box := ![⟨39,39⟩,⟨102,112⟩,⟨85,101⟩,⟨3,72⟩,⟨3839,999999999999999999⟩]
private def b31828 : Box := ![⟨39,39⟩,⟨102,112⟩,⟨102,126⟩,⟨3,72⟩,⟨3839,999999999999999999⟩]
private def b31839 : Box := ![⟨38,39⟩,⟨113,126⟩,⟨85,126⟩,⟨3,75⟩,⟨3839,999999999999999999⟩]
private def b31840 : Box := ![⟨38,38⟩,⟨113,126⟩,⟨85,126⟩,⟨3,75⟩,⟨3839,999999999999999999⟩]
private def b31847 : Box := ![⟨39,39⟩,⟨113,126⟩,⟨85,126⟩,⟨3,75⟩,⟨3839,999999999999999999⟩]
private def b31848 : Box := ![⟨39,39⟩,⟨113,126⟩,⟨85,101⟩,⟨3,75⟩,⟨3839,999999999999999999⟩]
private def b31849 : Box := ![⟨39,39⟩,⟨113,126⟩,⟨85,101⟩,⟨3,67⟩,⟨3839,7678⟩]
private def b31854 : Box := ![⟨39,39⟩,⟨113,126⟩,⟨85,101⟩,⟨3,67⟩,⟨7679,999999999999999999⟩]
private def b31861 : Box := ![⟨39,39⟩,⟨113,126⟩,⟨102,126⟩,⟨3,75⟩,⟨3839,999999999999999999⟩]
private def b31866 : Box := ![⟨40,41⟩,⟨102,126⟩,⟨63,126⟩,⟨3,82⟩,⟨1919,999999999999999999⟩]
private def b31867 : Box := ![⟨40,41⟩,⟨102,126⟩,⟨63,84⟩,⟨3,82⟩,⟨1919,999999999999999999⟩]
private def b31868 : Box := ![⟨40,41⟩,⟨102,126⟩,⟨63,84⟩,⟨3,68⟩,⟨1919,3838⟩]
private def b31871 : Box := ![⟨40,41⟩,⟨102,126⟩,⟨63,84⟩,⟨3,68⟩,⟨3839,999999999999999999⟩]
private def b31872 : Box := ![⟨40,41⟩,⟨102,112⟩,⟨63,84⟩,⟨3,62⟩,⟨3839,999999999999999999⟩]
private def b31873 : Box := ![⟨40,41⟩,⟨102,112⟩,⟨63,72⟩,⟨3,60⟩,⟨3839,999999999999999999⟩]
private def b31878 : Box := ![⟨40,41⟩,⟨102,112⟩,⟨73,84⟩,⟨3,60⟩,⟨3839,999999999999999999⟩]
private def b31885 : Box := ![⟨40,41⟩,⟨113,126⟩,⟨63,84⟩,⟨3,62⟩,⟨3839,999999999999999999⟩]
private def b31894 : Box := ![⟨40,41⟩,⟨102,126⟩,⟨85,126⟩,⟨3,82⟩,⟨1919,999999999999999999⟩]
private def b31895 : Box := ![⟨40,41⟩,⟨102,112⟩,⟨85,126⟩,⟨3,82⟩,⟨4542,999999999999999999⟩]
private def b31906 : Box := ![⟨40,41⟩,⟨113,126⟩,⟨85,126⟩,⟨3,82⟩,⟨4542,999999999999999999⟩]
private theorem e31719 : Deny 5 13 b31719 := by
    apply closeAction rule_sound _ _ 64 [0x7d62962a3]
    decide +kernel
private theorem e31726 : Deny 5 13 b31726 := by
    apply closeAction rule_sound _ _ 64 [0x1e7ca58ad9629ce37d87e237f8df68c8e36]
    decide +kernel
private theorem e31739 : Deny 5 13 b31739 := by
    apply closeAction rule_sound _ _ 64 [0x7d62962a3]
    decide +kernel
private theorem e31745 : Deny 5 13 b31745 := by
    apply closeAction rule_sound _ _ 64 [0x1f58ae37da3]
    decide +kernel
private theorem e31748 : Deny 5 13 b31748 := by
    apply closeAction rule_sound _ _ 64 [0x3e03e23203e23243e37d8758a]
    decide +kernel
private theorem e31744 : Deny 5 13 b31744 :=
    branchAction rule_sound _ _ 2
      0x223 b31744 b31745 b31748 (by decide +kernel) e31745 e31748
private theorem e31738 : Deny 5 13 b31738 :=
    branchAction rule_sound _ _ 2
      0x2e3 b31738 b31739 b31744 (by decide +kernel) e31739 e31744
private theorem e31758 : Deny 5 13 b31758 := by
    apply closeAction rule_sound _ _ 64 [0x7ef7d62962a3263]
    decide +kernel
private theorem e31767 : Deny 5 13 b31767 := by
    apply closeAction rule_sound _ _ 64 [0xc3e232021e3]
    decide +kernel
private theorem e31772 : Deny 5 13 b31772 := by
    apply closeAction rule_sound _ _ 64 [0x3e0321fe37d878dfbe32ef]
    decide +kernel
private theorem e31766 : Deny 5 13 b31766 :=
    branchAction rule_sound _ _ 2
      0x263 b31766 b31767 b31772 (by decide +kernel) e31767 e31772
private theorem e31780 : Deny 5 13 b31780 := by
    apply closeAction rule_sound _ _ 64 [0x16]
    decide +kernel
private theorem e31782 : Deny 5 13 b31782 := by
    apply closeAction rule_sound _ _ 64 [0x83e232380f88c3e232381e3]
    decide +kernel
private theorem e31789 : Deny 5 13 b31789 := by
    apply closeAction rule_sound _ _ 64 [0x20f80e3243e232237ef8cb8c7]
    decide +kernel
private theorem e31781 : Deny 5 13 b31781 :=
    branchAction rule_sound _ _ 1
      0x9 b31781 b31782 b31789 (by decide +kernel) e31782 e31789
private theorem e31779 : Deny 5 13 b31779 :=
    branchAction rule_sound _ _ 1
      0xa b31779 b31780 b31781 (by decide +kernel) e31780 e31781
private theorem e31765 : Deny 5 13 b31765 :=
    branchAction rule_sound _ _ 2
      0x223 b31765 b31766 b31779 (by decide +kernel) e31766 e31779
private theorem e31757 : Deny 5 13 b31757 :=
    branchAction rule_sound _ _ 1
      0xb b31757 b31758 b31765 (by decide +kernel) e31758 e31765
private theorem e31737 : Deny 5 13 b31737 :=
    branchAction rule_sound _ _ 1
      0x9 b31737 b31738 b31757 (by decide +kernel) e31738 e31757
private theorem e31725 : Deny 5 13 b31725 :=
    branchAction rule_sound _ _ 2
      0x1e3 b31725 b31726 b31737 (by decide +kernel) e31726 e31737
private theorem e31799 : Deny 5 13 b31799 := by
    apply closeAction rule_sound _ _ 64 [0x16]
    decide +kernel
private theorem e31803 : Deny 5 13 b31803 := by
    apply closeAction rule_sound _ _ 64 [0x16]
    decide +kernel
private theorem e31804 : Deny 5 13 b31804 := by
    apply closeAction rule_sound _ _ 64 [0x3e03e232387f88c9e022388df2f87f8d87e23]
    decide +kernel
private theorem e31802 : Deny 5 13 b31802 :=
    branchAction rule_sound _ _ 3
      0xae23 b31802 b31803 b31804 (by decide +kernel) e31803 e31804
private theorem e31816 : Deny 5 13 b31816 := by
    apply closeAction rule_sound _ _ 64 [0x79f2962a3]
    decide +kernel
private theorem e31823 : Deny 5 13 b31823 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e31825 : Deny 5 13 b31825 := by
    apply closeAction rule_sound _ _ 64 [0x3e230f88c9e23]
    decide +kernel
private theorem e31828 : Deny 5 13 b31828 := by
    apply closeAction rule_sound _ _ 64 [0xc3e23243e368c88de7ca58a8cb]
    decide +kernel
private theorem e31824 : Deny 5 13 b31824 :=
    branchAction rule_sound _ _ 1
      0x9 b31824 b31825 b31828 (by decide +kernel) e31825 e31828
private theorem e31822 : Deny 5 13 b31822 :=
    branchAction rule_sound _ _ 2
      0x1e3 b31822 b31823 b31824 (by decide +kernel) e31823 e31824
private theorem e31840 : Deny 5 13 b31840 := by
    apply closeAction rule_sound _ _ 64 [0x1e7962b8d8ae2358ae36]
    decide +kernel
private theorem e31849 : Deny 5 13 b31849 := by
    apply closeAction rule_sound _ _ 64 [0x16e370f80e3263223]
    decide +kernel
private theorem e31854 : Deny 5 13 b31854 := by
    apply closeAction rule_sound _ _ 64 [0x3e038c90c3e23263223]
    decide +kernel
private theorem e31848 : Deny 5 13 b31848 :=
    branchAction rule_sound _ _ 2
      0x2e3 b31848 b31849 b31854 (by decide +kernel) e31849 e31854
private theorem e31861 : Deny 5 13 b31861 := by
    apply closeAction rule_sound _ _ 64 [0x20f80f88c9e23238]
    decide +kernel
private theorem e31847 : Deny 5 13 b31847 :=
    branchAction rule_sound _ _ 1
      0x9 b31847 b31848 b31861 (by decide +kernel) e31848 e31861
private theorem e31839 : Deny 5 13 b31839 :=
    branchAction rule_sound _ _ 1
      0x7 b31839 b31840 b31847 (by decide +kernel) e31840 e31847
private theorem e31821 : Deny 5 13 b31821 :=
    branchAction rule_sound _ _ 2
      0x223 b31821 b31822 b31839 (by decide +kernel) e31822 e31839
private theorem e31815 : Deny 5 13 b31815 :=
    branchAction rule_sound _ _ 1
      0xb b31815 b31816 b31821 (by decide +kernel) e31816 e31821
private theorem e31801 : Deny 5 13 b31801 :=
    branchAction rule_sound _ _ 1
      0x9 b31801 b31802 b31815 (by decide +kernel) e31802 e31815
private theorem e31868 : Deny 5 13 b31868 := by
    apply closeAction rule_sound _ _ 64 [0x7d62a3]
    decide +kernel
private theorem e31873 : Deny 5 13 b31873 := by
    apply closeAction rule_sound _ _ 64 [0x3e03e070e3223]
    decide +kernel
private theorem e31878 : Deny 5 13 b31878 := by
    apply closeAction rule_sound _ _ 64 [0x20f88c8e030f88c88c7]
    decide +kernel
private theorem e31872 : Deny 5 13 b31872 :=
    branchAction rule_sound _ _ 2
      0x263 b31872 b31873 b31878 (by decide +kernel) e31873 e31878
private theorem e31885 : Deny 5 13 b31885 := by
    apply closeAction rule_sound _ _ 64 [0x2083e232380f80e3223247]
    decide +kernel
private theorem e31871 : Deny 5 13 b31871 :=
    branchAction rule_sound _ _ 2
      0x223 b31871 b31872 b31885 (by decide +kernel) e31872 e31885
private theorem e31867 : Deny 5 13 b31867 :=
    branchAction rule_sound _ _ 2
      0x2e3 b31867 b31868 b31871 (by decide +kernel) e31868 e31871
private theorem e31895 : Deny 5 13 b31895 := by
    apply closeAction rule_sound _ _ 64 [0x82083e232788c8e03e03e232788c9e07e23]
    decide +kernel
private theorem e31906 : Deny 5 13 b31906 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e31894 : Deny 5 13 b31894 :=
    branchAction rule_sound _ _ 2
      0x238 b31894 b31895 b31906 (by decide +kernel) e31895 e31906
private theorem e31866 : Deny 5 13 b31866 :=
    branchAction rule_sound _ _ 1
      0x9 b31866 b31867 b31894 (by decide +kernel) e31867 e31894
private theorem e31800 : Deny 5 13 b31800 :=
    branchAction rule_sound _ _ 1
      0x7 b31800 b31801 b31866 (by decide +kernel) e31801 e31866
private theorem e31798 : Deny 5 13 b31798 :=
    branchAction rule_sound _ _ 1
      0xa b31798 b31799 b31800 (by decide +kernel) e31799 e31800
private theorem e31724 : Deny 5 13 b31724 :=
    branchAction rule_sound _ _ 2
      0x223 b31724 b31725 b31798 (by decide +kernel) e31725 e31798
private theorem e31718 : Deny 5 13 b31718 :=
    branchAction rule_sound _ _ 2
      0x2e3 b31718 b31719 b31724 (by decide +kernel) e31719 e31724
theorem deny5_13 : Deny 5 13 ![⟨38,41⟩,⟨85,126⟩,⟨63,126⟩,⟨1,718295185477505923801⟩,⟨959,999999999999999999⟩] := by
  exact e31718
end OMA.Blocks5_13_245212.S31718
