import OddThreeSolution245212
import FourRoot245212
import LargeResult245212
import LargeSeven245212
import LargeEleven245212
import LargeThirteen245212

/-! Connect the unbounded prime-support estimates to the ten finite certificates. -/
namespace OMA.OddSupportClass245212
open Finset OMA.Smooth245212 OMA.Large245212 OMA.Box245212
open private OMA.Large245212.four from LargeResult245212
open scoped ArithmeticFunction.sigma
theorem prime_bounds : ∀ k p q r e f g : ℕ, 2≤k → p.Prime → q.Prime → r.Prime →
  5≤p → p<q → q<r → 0<e → 0<f → 0<g →
  let n := 3^k*p^e*q^f*r^g
  OeisA245212.a n=(σ 1 n : ℤ) → p∈({5,7}:Finset ℕ) ∧ q≤31 ∧ r<1000000000000000000 := by
  intro k p q r e f g hk hp hq hr hp5 pq qr he hf hg n eq
  let P : Fin 4 → ℕ := ![3,p,q,r]
  let E : Fin 4 → ℕ := ![k,e,f,g]
  have pp (i : Fin 4) : Nat.Prime (P i) := by fin_cases i <;> simp [P,hp,hq,hr,Nat.prime_three]
  have pm : StrictMono P := by
    apply Fin.strictMono_iff_lt_succ.mpr
    intro i; fin_cases i <;> simp [P] <;> omega
  have repr : total P E=n := by simp [total,P,E,n,Fin.prod_univ_four]
  have norm := normalized_of_eq P pp pm.injective E (by rw [repr]; exact eq)
  have cap := OMA.OddFaces245212.cap_needed P E (fun i => (pp i).one_lt) 0 (by simpa [E] using (by omega : 0<k)) norm
  have drop (u : Fin 4 → ℕ) (hu : ∀ i,1<u i) (ge : ∀ i,u i≤P i)
      (cut : (∏ i,OMA.OddFaces245212.limitX (u i))<2) : False := by
    have b := prod_le_prod (s:=univ) (f:=fun i => OMA.OddFaces245212.limitX (P i))
      (fun i _ => x_nonneg ((hu i).trans_le (ge i)) none) (fun i _ => OMA.OddFaces245212.cap_anti (hu i) (ge i))
    exact (cap.trans b).not_gt cut
  have smallP : p≤7 := by
    by_contra! h
    have pm : 11≤p := by by_contra! z; interval_cases p <;> norm_num at *
    apply drop ![3,11,12,13] (by decide) _ (by decide +kernel)
    intro i; fin_cases i <;> simp [P] <;> omega
  have p57 : p∈({5,7}:Finset ℕ) := by interval_cases p <;> norm_num at *
  have smallQ : q≤31 := by
    by_contra! h
    apply drop ![3,5,32,33] (by decide) _ (by decide +kernel)
    intro i; fin_cases i <;> simp [P] <;> omega
  have cert : Certs := by
    intro s h
    rcases h with rfl|rfl|rfl
    · exact p7x0
    · exact p11x0
    · exact p13x0
  have pos (i : Fin 4) : 0 < E i := by fin_cases i <;> simp [E] <;> omega
  exact ⟨p57,smallQ,OMA.Large245212.four cert pp pm (by change 3 ≤ 3; exact le_rfl) pos (by rw [repr]; exact eq)⟩

theorem odd_four_of_roots
    (proofs : ∀ pq∈families, OMA.Box245212.Deny pq.1 pq.2 (rootBox pq.1 pq.2))
    {n : ℕ} (odd : Odd n) (few : n.primeFactors.card≤4)
    (eq : OeisA245212.a n=(σ 1 n:ℤ)) : n=1 := by
  apply classify three_excluded n odd few _ eq
  intro _ k p q r e f g hk hp hq hr hp5 pq qr he hf hg eqn
  obtain ⟨ps,qs,rs⟩ := prime_bounds k p q r e f g hk hp hq hr hp5 pq qr he hf hg eqn
  exact exclude_bounded proofs p ps q (mem_Icc.mpr ⟨pq,qs⟩) r (mem_Icc.mpr ⟨qr,by omega⟩)
    hq hr k e f g hk he hf hg eqn

end OMA.OddSupportClass245212
