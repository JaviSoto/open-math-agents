import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S63451
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b63451 : Box := ![⟨153,190⟩,⟨36,38⟩,⟨13,14⟩,⟨2,48⟩,⟨1919,999999999999999999⟩]
private def b63452 : Box := ![⟨153,190⟩,⟨36,36⟩,⟨13,14⟩,⟨2,47⟩,⟨1919,999999999999999999⟩]
private def b63453 : Box := ![⟨153,190⟩,⟨37,38⟩,⟨13,14⟩,⟨2,47⟩,⟨1919,999999999999999999⟩]
private def b63454 : Box := ![⟨153,169⟩,⟨37,38⟩,⟨13,14⟩,⟨2,47⟩,⟨2112,999999999999999999⟩]
private def b63455 : Box := ![⟨170,190⟩,⟨37,38⟩,⟨13,14⟩,⟨2,47⟩,⟨2112,999999999999999999⟩]
private theorem e63452 : Deny 5 13 b63452 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e63454 : Deny 5 13 b63454 := by
    apply closeAction rule_sound _ _ 64 [0x3e23]
    decide +kernel
private theorem e63455 : Deny 5 13 b63455 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e63453 : Deny 5 13 b63453 :=
    branchAction rule_sound _ _ 2
      0x1f8 b63453 b63454 b63455 (by decide +kernel) e63454 e63455
private theorem e63451 : Deny 5 13 b63451 :=
    branchAction rule_sound _ _ 2
      0x223 b63451 b63452 b63453 (by decide +kernel) e63452 e63453
theorem deny5_13 : Deny 5 13 ![⟨153,190⟩,⟨36,38⟩,⟨13,14⟩,⟨2,48⟩,⟨1919,999999999999999999⟩] := by
  exact e63451
end OMA.Blocks5_13_245212.S63451
