import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S29624
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b29624 : Box := ![⟨36,37⟩,⟨170,254⟩,⟨63,126⟩,⟨3,109⟩,⟨1919,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨36,37⟩,⟨170,254⟩,⟨63,126⟩,⟨3,109⟩,⟨1919,999999999999999999⟩] := by
  have e29624 : Deny 5 13 b29624 := by
    apply closeAction rule_sound _ _ 64 [0xf80f88c80f8ae30f8ae32388c90f88c22788c88de58a58a8cb79e58ae0ae2358ae232421e322379e58a84a58a8cb8c9,0x7ab8cb8deae32e37ab8cb8deae32e37ab8cb8deae32e37ab8cb8deae32e37ab8cb8deae32e325e58ae2b8deae3278d87,0xabaa12c2aea84b0abaa12d62d62d62d62d22e129eae12deae12c2ae12c2ae12c2aea84b0abaa12c2aea84b58b58b2a3,0x8c88de58a58a8cb7962962b88c22388c91e322309e58a58a1e32c2083e232380f80f88c8e232788c8e1e79eac3088d88,0x2232635b8dd6e370e32388c98cbe232388c9e030f88c90f88c22788c88de58a58a8cb0f88dee37da32388c97962b8df6,0x79eacbae32e325e58ae2358ae232237962962a32e3247082083e232388c9e232388c2083e232388c9e03e038c80c3e23,0xe230f88c9e23223263096e370f80f88c9e232388c98cbe23238083e232788c3e03e232788c8e030f88c90888deae32e3,0x2082083e232788c8e232788c20f80f88c9e232380f80e3243]
    decide +kernel
  exact e29624
end OMA.Blocks5_13_245212.S29624
