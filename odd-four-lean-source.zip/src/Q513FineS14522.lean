import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S14522
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b14522 : Box := ![⟨23,46⟩,⟨7,14⟩,⟨4,1920000000000000011376⟩,⟨1,1728510638297872350707⟩,⟨59,768⟩]
theorem deny5_13 : Deny 5 13 ![⟨23,46⟩,⟨7,14⟩,⟨4,1920000000000000011376⟩,⟨1,1728510638297872350707⟩,⟨59,768⟩] := by
  have e14522 : Deny 5 13 b14522 := by
    apply closeAction rule_sound _ _ 64 [0xd8a0881021f8da324288a102238de31c30f7da31c3de32422371021f8df68c9d9cbc472f8c4278df68c88c21f8df6d63,0x2032622842c30f8de3203e378c98c775ce37d871021f8df68c88c90c22021c4088e3788a10b72f72f11c1f8be325c0f8,0x88ad82237da311cbdc72f0f80ef1c3e2f20988abe32542af0c3df61dcdf62378c409de370e31c80f8dc38c88c90f70e2,0x1cbdcbc3e2325c1dcbc8707e2f8c90dce37d870881021f8da3242]
    decide +kernel
  exact e14522
end OMA.Blocks5_13_245212.S14522
