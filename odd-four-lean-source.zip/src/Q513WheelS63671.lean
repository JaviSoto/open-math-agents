import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S63671
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b63671 : Box := ![⟨127,190⟩,⟨42,62⟩,⟨10,14⟩,⟨1,64⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨127,190⟩,⟨42,62⟩,⟨10,14⟩,⟨1,64⟩,⟨479,999999999999999999⟩] := by
  have e63671 : Deny 5 13 b63671 := by
    apply closeAction rule_sound _ _ 64 [0x4f8dd3e3709b9e32789c20f8de70e31c96c20e78099c31ca9e32234f8ddb093dc41f8dc39e020a9c92e31e78c88c98cb,0xe1b9e32278cb9c30f8dc90c22631c3e022789e3087e232230838c99c3e03e098c76c30a02602a78c89e32e31e3223263,0x1e32234f8dc20f8de70e31e32678c88cb8c7083e231f80f80c80e31e3243e038c76e78db9e32f88c98c88c20838c78c9,0x1f80c38c78c98c88c20820f88c7e278c9e278c8e278cb8c78c8082083e231f82788c8e020f80e31e32420c90f80f8263,0x820820f88c7e232789e32380820f88c7e23278083e23]
    decide +kernel
  exact e63671
end OMA.Blocks5_13_245212.S63671
