import WheelRule245212

/-! Replace the repeated three- and four-factor finite products in the
digit cuts and the interval leaf by fixed-arity natural multiplication. -/
namespace OMA.RawDigit245212
open OMA.Box245212 OMA.FastDigit245212 OMA.SparseEngine245212
open Finset

private def start (p q : ℕ) (b : Box) : Bool := 1<p && 1<q && 1<(b 4).lo

private theorem start_iff (p q : ℕ) (b : Box) :
    start p q b=true ↔ ∀ i,1<(baseBox p q b i).lo := by
  simp only [start,Bool.and_eq_true_iff,decide_eq_true_eq]
  constructor
  · rintro ⟨⟨hp,hq⟩,hr⟩ i
    fin_cases i <;> first | exact hp | exact hq | exact hr | exact (show 1<3 by decide)
  · exact fun h=>⟨⟨h 1,h 2⟩,h 3⟩

private def span (P E : Range) : Span :=
  let l:=FastFactor245212.lowY P E
  let u:=FastFactor245212.highY P E
  let M:=FastFactor245212.scale
  ⟨M+(M-u)/(P.hi-1),l,M+(M-l)/(P.lo-1)+1,u⟩

private theorem span_eq (P E : Range) : span P E=hull P E := rfl

private def co (p q : ℕ) (b : Box) (i : Fin 4) : Span :=
  let f (j : Fin 4) := span (baseBox p q b j) (b j.castSucc)
  let raw (v : Span→ℕ) := FastRound245212.skipProd (fun j=>v (f j)) i
  ⟨raw Span.xl,raw Span.yl,raw Span.xu,raw Span.yu⟩

private theorem triple (f : Fin 4→ℕ) (i : Fin 4) :
    FastRound245212.skipProd f i=∏ j∈univ.erase i,f j := by
  have h0 : univ.erase (0:Fin 4)={1,2,3} := by decide
  have h1 : univ.erase (1:Fin 4)={0,2,3} := by decide
  have h2 : univ.erase (2:Fin 4)={0,1,3} := by decide
  have h3 : univ.erase (3:Fin 4)={0,1,2} := by decide
  fin_cases i <;> simp_all [FastRound245212.skipProd,prod_insert,mul_assoc]

private theorem co_eq (p q : ℕ) (b : Box) (i : Fin 4) : co p q b i=cofactor hull p q b i := by
  simp only [co,triple,span_eq,cofactor]

private def individual (ax : ℕ) (p q : ℕ) (b : Box) : Option Box :=
  if start p q b then
    let Z:=FastFactor245212.scale^3
    let i:=Fin.ofNat 4 (ax-52)
    let j : Fin 5 := if ax=56 then 4 else i.castSucc
    let r:=if ax=56 then
      let V:=co p q b 3
      highPrime Z V.xu V.yu (b 3) (lowPrime Z V.xl V.yl (b 3) (b 4))
    else digitAt Z (co p q b i) (b i.castSucc) (baseBox p q b i)
    if r.lo≤r.hi then some (clip b j r) else none
  else some b

private theorem individual_eq (ax p q : ℕ) (b : Box) :
    individual ax p q b=SparseDigit245212.individual ax p q b := by
  simp only [individual,SparseDigit245212.individual,start_iff,co_eq]

private def interval (p q : ℕ) (b : Box) : Bool :=
  let f (j : Fin 4) := span (baseBox p q b j) (b j.castSucc)
  let prod (v : Span→ℕ) := v (f 0)*v (f 1)*v (f 2)*v (f 3)
  let z:=2*FastFactor245212.scale^4
  start p q b && (prod Span.xu + prod Span.yu < z || z < prod Span.xl + prod Span.yl)

private theorem interval_sound {p q : ℕ} {b : Box} (yes : interval p q b=true) : Deny p q b := by
  apply fastInterval_sound
  simpa only [interval,fastInterval,Bool.and_eq_true_iff,Bool.or_eq_true_iff,
    decide_eq_true_eq,start_iff,Fin.prod_univ_four,span_eq,mul_assoc] using yes

def rule (p q op : ℕ) (s : Stack) :=
  if 52≤op ∧ op≤56 then step (individual op) FastReplay245212.leaf p q 6 s
  else if op=2 then
    match s with
    | [] => none
    | b::rest => if interval p q b then some rest else none
  else WheelRule245212.rule p q op s

theorem sound : AdvanceSound rule := by
  intro p q op s t checked solved
  unfold rule at checked
  split_ifs at checked with digit inter
  · apply step_sound (digit:=individual op) _ FastReplay245212.leaf_sound p q 6 s t checked solved
    intro p q b v fits candidate
    simpa only [individual_eq] using SparseDigit245212.individual_sound op p q b v fits candidate
  · cases s with
    | nil => cases checked
    | cons b rest =>
      dsimp only at checked
      split_ifs at checked with yes
      · cases Option.some.inj checked
        exact fun x hx=>(List.mem_cons.mp hx).elim (fun e=>e ▸ interval_sound yes) (solved x)
  · exact WheelRule245212.sound p q op s t checked solved

end OMA.RawDigit245212
