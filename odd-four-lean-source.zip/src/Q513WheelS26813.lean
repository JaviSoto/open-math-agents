import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S26813
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b26813 : Box := ![⟨42,46⟩,⟨42,62⟩,⟨31,62⟩,⟨3,6⟩,⟨239,478⟩]
private def b26814 : Box := ![⟨42,46⟩,⟨42,62⟩,⟨31,62⟩,⟨3,6⟩,⟨239,318⟩]
private def b26815 : Box := ![⟨42,46⟩,⟨42,62⟩,⟨31,62⟩,⟨3,4⟩,⟨239,317⟩]
private def b26816 : Box := ![⟨42,46⟩,⟨42,62⟩,⟨31,62⟩,⟨5,6⟩,⟨239,317⟩]
private def b26817 : Box := ![⟨42,46⟩,⟨42,62⟩,⟨31,62⟩,⟨5,5⟩,⟨239,317⟩]
private def b26818 : Box := ![⟨42,46⟩,⟨42,50⟩,⟨31,62⟩,⟨5,5⟩,⟨239,317⟩]
private def b26819 : Box := ![⟨42,46⟩,⟨42,50⟩,⟨31,41⟩,⟨5,5⟩,⟨239,317⟩]
private def b26820 : Box := ![⟨42,46⟩,⟨42,50⟩,⟨31,41⟩,⟨5,5⟩,⟨239,272⟩]
private def b26829 : Box := ![⟨42,46⟩,⟨42,50⟩,⟨31,41⟩,⟨5,5⟩,⟨273,317⟩]
private def b26838 : Box := ![⟨42,46⟩,⟨42,50⟩,⟨42,62⟩,⟨5,5⟩,⟨239,317⟩]
private def b26839 : Box := ![⟨42,46⟩,⟨42,50⟩,⟨42,62⟩,⟨5,5⟩,⟨239,272⟩]
private def b26840 : Box := ![⟨42,43⟩,⟨42,50⟩,⟨42,62⟩,⟨5,5⟩,⟨239,271⟩]
private def b26849 : Box := ![⟨44,46⟩,⟨42,50⟩,⟨42,62⟩,⟨5,5⟩,⟨239,271⟩]
private def b26856 : Box := ![⟨42,46⟩,⟨42,50⟩,⟨42,62⟩,⟨5,5⟩,⟨273,317⟩]
private def b26857 : Box := ![⟨42,43⟩,⟨42,50⟩,⟨42,62⟩,⟨5,5⟩,⟨277,317⟩]
private def b26866 : Box := ![⟨44,46⟩,⟨42,50⟩,⟨42,62⟩,⟨5,5⟩,⟨277,317⟩]
private def b26877 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨31,62⟩,⟨5,5⟩,⟨239,317⟩]
private def b26878 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨31,41⟩,⟨5,5⟩,⟨239,317⟩]
private def b26879 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨31,41⟩,⟨5,5⟩,⟨239,272⟩]
private def b26880 : Box := ![⟨42,43⟩,⟨51,62⟩,⟨31,41⟩,⟨5,5⟩,⟨239,271⟩]
private def b26887 : Box := ![⟨44,46⟩,⟨51,62⟩,⟨31,41⟩,⟨5,5⟩,⟨239,271⟩]
private def b26892 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨31,41⟩,⟨5,5⟩,⟨273,317⟩]
private def b26893 : Box := ![⟨42,43⟩,⟨51,62⟩,⟨31,41⟩,⟨5,5⟩,⟨277,317⟩]
private def b26900 : Box := ![⟨44,46⟩,⟨51,62⟩,⟨31,41⟩,⟨5,5⟩,⟨277,317⟩]
private def b26907 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨42,62⟩,⟨5,5⟩,⟨239,317⟩]
private def b26914 : Box := ![⟨42,46⟩,⟨42,62⟩,⟨31,62⟩,⟨6,6⟩,⟨239,317⟩]
private def b26915 : Box := ![⟨42,46⟩,⟨42,62⟩,⟨31,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b26916 : Box := ![⟨42,46⟩,⟨42,50⟩,⟨31,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b26917 : Box := ![⟨42,46⟩,⟨42,50⟩,⟨31,41⟩,⟨3,6⟩,⟨319,478⟩]
private def b26924 : Box := ![⟨42,46⟩,⟨42,50⟩,⟨42,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b26925 : Box := ![⟨42,46⟩,⟨42,50⟩,⟨42,62⟩,⟨3,6⟩,⟨319,382⟩]
private def b26926 : Box := ![⟨42,46⟩,⟨42,50⟩,⟨42,62⟩,⟨3,4⟩,⟨331,379⟩]
private def b26927 : Box := ![⟨42,46⟩,⟨42,50⟩,⟨42,62⟩,⟨5,6⟩,⟨331,379⟩]
private def b26928 : Box := ![⟨42,46⟩,⟨42,50⟩,⟨42,62⟩,⟨5,5⟩,⟨331,379⟩]
private def b26929 : Box := ![⟨42,43⟩,⟨42,50⟩,⟨42,62⟩,⟨5,5⟩,⟨331,379⟩]
private def b26934 : Box := ![⟨44,46⟩,⟨42,50⟩,⟨42,62⟩,⟨5,5⟩,⟨331,379⟩]
private def b26935 : Box := ![⟨44,46⟩,⟨42,45⟩,⟨42,62⟩,⟨5,5⟩,⟨331,379⟩]
private def b26940 : Box := ![⟨44,46⟩,⟨46,50⟩,⟨42,62⟩,⟨5,5⟩,⟨331,379⟩]
private def b26949 : Box := ![⟨42,46⟩,⟨42,50⟩,⟨42,62⟩,⟨6,6⟩,⟨331,379⟩]
private def b26950 : Box := ![⟨42,46⟩,⟨42,50⟩,⟨42,62⟩,⟨3,6⟩,⟨383,478⟩]
private def b26951 : Box := ![⟨42,43⟩,⟨42,50⟩,⟨42,62⟩,⟨3,6⟩,⟨383,467⟩]
private def b26954 : Box := ![⟨44,46⟩,⟨42,50⟩,⟨42,62⟩,⟨3,6⟩,⟨383,467⟩]
private def b26955 : Box := ![⟨44,46⟩,⟨42,50⟩,⟨42,62⟩,⟨3,4⟩,⟨383,467⟩]
private def b26956 : Box := ![⟨44,46⟩,⟨42,50⟩,⟨42,62⟩,⟨5,6⟩,⟨383,467⟩]
private def b26957 : Box := ![⟨44,46⟩,⟨42,50⟩,⟨42,62⟩,⟨5,6⟩,⟨383,420⟩]
private def b26958 : Box := ![⟨44,46⟩,⟨42,50⟩,⟨42,62⟩,⟨5,6⟩,⟨383,400⟩]
private def b26959 : Box := ![⟨44,46⟩,⟨42,50⟩,⟨42,50⟩,⟨5,6⟩,⟨383,397⟩]
private def b26960 : Box := ![⟨44,46⟩,⟨42,50⟩,⟨51,62⟩,⟨5,6⟩,⟨383,397⟩]
private def b26971 : Box := ![⟨44,46⟩,⟨42,50⟩,⟨42,62⟩,⟨5,6⟩,⟨401,419⟩]
private def b26972 : Box := ![⟨44,46⟩,⟨42,50⟩,⟨42,62⟩,⟨5,6⟩,⟨421,467⟩]
private def b26973 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨31,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b26974 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨31,41⟩,⟨3,6⟩,⟨319,478⟩]
private def b26975 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨31,41⟩,⟨3,6⟩,⟨319,382⟩]
private def b26976 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨31,41⟩,⟨3,4⟩,⟨331,379⟩]
private def b26977 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨31,41⟩,⟨5,6⟩,⟨331,379⟩]
private def b26978 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨31,41⟩,⟨5,5⟩,⟨331,379⟩]
private def b26979 : Box := ![⟨42,43⟩,⟨51,62⟩,⟨31,41⟩,⟨5,5⟩,⟨331,379⟩]
private def b26984 : Box := ![⟨44,46⟩,⟨51,62⟩,⟨31,41⟩,⟨5,5⟩,⟨331,379⟩]
private def b26993 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨31,41⟩,⟨6,6⟩,⟨331,379⟩]
private def b26994 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨31,41⟩,⟨3,6⟩,⟨383,478⟩]
private def b26995 : Box := ![⟨42,43⟩,⟨51,62⟩,⟨31,41⟩,⟨3,6⟩,⟨383,467⟩]
private def b27000 : Box := ![⟨44,46⟩,⟨51,62⟩,⟨31,41⟩,⟨3,6⟩,⟨383,467⟩]
private def b27009 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨42,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b27010 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨42,62⟩,⟨3,6⟩,⟨319,382⟩]
private def b27011 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨42,62⟩,⟨3,4⟩,⟨331,379⟩]
private def b27012 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨42,62⟩,⟨5,6⟩,⟨331,379⟩]
private def b27013 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨42,62⟩,⟨5,5⟩,⟨331,379⟩]
private def b27014 : Box := ![⟨42,43⟩,⟨51,62⟩,⟨42,62⟩,⟨5,5⟩,⟨331,379⟩]
private def b27025 : Box := ![⟨44,46⟩,⟨51,62⟩,⟨42,62⟩,⟨5,5⟩,⟨331,379⟩]
private def b27032 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨42,62⟩,⟨6,6⟩,⟨331,379⟩]
private def b27033 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨42,62⟩,⟨3,6⟩,⟨383,478⟩]
private def b27034 : Box := ![⟨42,43⟩,⟨51,62⟩,⟨42,62⟩,⟨3,6⟩,⟨383,467⟩]
private def b27035 : Box := ![⟨42,43⟩,⟨51,55⟩,⟨42,62⟩,⟨3,6⟩,⟨383,467⟩]
private def b27040 : Box := ![⟨42,43⟩,⟨56,62⟩,⟨42,62⟩,⟨3,6⟩,⟨383,467⟩]
private def b27047 : Box := ![⟨44,46⟩,⟨51,62⟩,⟨42,62⟩,⟨3,6⟩,⟨383,467⟩]
private def b27048 : Box := ![⟨44,46⟩,⟨51,62⟩,⟨42,62⟩,⟨3,4⟩,⟨383,467⟩]
private def b27049 : Box := ![⟨44,46⟩,⟨51,62⟩,⟨42,62⟩,⟨5,6⟩,⟨383,467⟩]
private def b27050 : Box := ![⟨44,46⟩,⟨51,62⟩,⟨42,62⟩,⟨5,5⟩,⟨383,467⟩]
private def b27051 : Box := ![⟨44,46⟩,⟨51,55⟩,⟨42,62⟩,⟨5,5⟩,⟨383,467⟩]
private def b27060 : Box := ![⟨44,46⟩,⟨56,62⟩,⟨42,62⟩,⟨5,5⟩,⟨383,467⟩]
private def b27063 : Box := ![⟨44,46⟩,⟨51,62⟩,⟨42,62⟩,⟨6,6⟩,⟨383,467⟩]
private theorem e26815 : Deny 5 13 b26815 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e26820 : Deny 5 13 b26820 := by
    apply closeAction rule_sound _ _ 64 [0x5c31c31c30f8d871c4]
    decide +kernel
private theorem e26829 : Deny 5 13 b26829 := by
    apply closeAction rule_sound _ _ 64 [0x30c70c70c4088e361c4]
    decide +kernel
private theorem e26819 : Deny 5 13 b26819 :=
    branchAction rule_sound _ _ 1
      0xb b26819 b26820 b26829 (by decide +kernel) e26820 e26829
private theorem e26840 : Deny 5 13 b26840 := by
    apply closeAction rule_sound _ _ 64 [0x83108e032780c3248]
    decide +kernel
private theorem e26849 : Deny 5 13 b26849 := by
    apply closeAction rule_sound _ _ 64 [0x2083109e031c4238]
    decide +kernel
private theorem e26839 : Deny 5 13 b26839 :=
    branchAction rule_sound _ _ 2
      0x1c4 b26839 b26840 b26849 (by decide +kernel) e26840 e26849
private theorem e26857 : Deny 5 13 b26857 := by
    apply closeAction rule_sound _ _ 64 [0x3e03203243103e04278d88]
    decide +kernel
private theorem e26866 : Deny 5 13 b26866 := by
    apply closeAction rule_sound _ _ 64 [0x83e031c9e03e032431c8]
    decide +kernel
private theorem e26856 : Deny 5 13 b26856 :=
    branchAction rule_sound _ _ 2
      0x1c4 b26856 b26857 b26866 (by decide +kernel) e26857 e26866
private theorem e26838 : Deny 5 13 b26838 :=
    branchAction rule_sound _ _ 1
      0xb b26838 b26839 b26856 (by decide +kernel) e26839 e26856
private theorem e26818 : Deny 5 13 b26818 :=
    branchAction rule_sound _ _ 1
      0x9 b26818 b26819 b26838 (by decide +kernel) e26819 e26838
private theorem e26880 : Deny 5 13 b26880 := by
    apply closeAction rule_sound _ _ 64 [0x83109e03e03248]
    decide +kernel
private theorem e26887 : Deny 5 13 b26887 := by
    apply closeAction rule_sound _ _ 64 [0x820c9238]
    decide +kernel
private theorem e26879 : Deny 5 13 b26879 :=
    branchAction rule_sound _ _ 2
      0x1c4 b26879 b26880 b26887 (by decide +kernel) e26880 e26887
private theorem e26893 : Deny 5 13 b26893 := by
    apply closeAction rule_sound _ _ 64 [0x3e032430f8248]
    decide +kernel
private theorem e26900 : Deny 5 13 b26900 := by
    apply closeAction rule_sound _ _ 64 [0x83107e03e03248]
    decide +kernel
private theorem e26892 : Deny 5 13 b26892 :=
    branchAction rule_sound _ _ 2
      0x1c4 b26892 b26893 b26900 (by decide +kernel) e26893 e26900
private theorem e26878 : Deny 5 13 b26878 :=
    branchAction rule_sound _ _ 1
      0xb b26878 b26879 b26892 (by decide +kernel) e26879 e26892
private theorem e26907 : Deny 5 13 b26907 := by
    apply closeAction rule_sound _ _ 64 [0x820832481f8]
    decide +kernel
private theorem e26877 : Deny 5 13 b26877 :=
    branchAction rule_sound _ _ 1
      0x9 b26877 b26878 b26907 (by decide +kernel) e26878 e26907
private theorem e26817 : Deny 5 13 b26817 :=
    branchAction rule_sound _ _ 1
      0x8 b26817 b26818 b26877 (by decide +kernel) e26818 e26877
private theorem e26914 : Deny 5 13 b26914 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e26816 : Deny 5 13 b26816 :=
    branchAction rule_sound _ _ 1
      0xa b26816 b26817 b26914 (by decide +kernel) e26817 e26914
private theorem e26814 : Deny 5 13 b26814 :=
    branchAction rule_sound _ _ 2
      0x284 b26814 b26815 b26816 (by decide +kernel) e26815 e26816
private theorem e26917 : Deny 5 13 b26917 := by
    apply closeAction rule_sound _ _ 64 [0x30f8dc90881021f8]
    decide +kernel
private theorem e26926 : Deny 5 13 b26926 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e26929 : Deny 5 13 b26929 := by
    apply closeAction rule_sound _ _ 64 [0x30f8242236]
    decide +kernel
private theorem e26935 : Deny 5 13 b26935 := by
    apply closeAction rule_sound _ _ 64 [0xc3e090f8d87]
    decide +kernel
private theorem e26940 : Deny 5 13 b26940 := by
    apply closeAction rule_sound _ _ 64 [0x20c8e031c30f81c9]
    decide +kernel
private theorem e26934 : Deny 5 13 b26934 :=
    branchAction rule_sound _ _ 1
      0x8 b26934 b26935 b26940 (by decide +kernel) e26935 e26940
private theorem e26928 : Deny 5 13 b26928 :=
    branchAction rule_sound _ _ 1
      0x7 b26928 b26929 b26934 (by decide +kernel) e26929 e26934
private theorem e26949 : Deny 5 13 b26949 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e26927 : Deny 5 13 b26927 :=
    branchAction rule_sound _ _ 1
      0xa b26927 b26928 b26949 (by decide +kernel) e26928 e26949
private theorem e26925 : Deny 5 13 b26925 :=
    branchAction rule_sound _ _ 2
      0x284 b26925 b26926 b26927 (by decide +kernel) e26926 e26927
private theorem e26951 : Deny 5 13 b26951 := by
    apply closeAction rule_sound _ _ 64 [0xc2238df6]
    decide +kernel
private theorem e26955 : Deny 5 13 b26955 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e26959 : Deny 5 13 b26959 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e26960 : Deny 5 13 b26960 := by
    apply closeAction rule_sound _ _ 64 [0x7c3e032031c308720a]
    decide +kernel
private theorem e26958 : Deny 5 13 b26958 :=
    branchAction rule_sound _ _ 2
      0x244 b26958 b26959 b26960 (by decide +kernel) e26959 e26960
private theorem e26971 : Deny 5 13 b26971 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e26957 : Deny 5 13 b26957 :=
    branchAction rule_sound _ _ 2
      0x2c4 b26957 b26958 b26971 (by decide +kernel) e26958 e26971
private theorem e26972 : Deny 5 13 b26972 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e26956 : Deny 5 13 b26956 :=
    branchAction rule_sound _ _ 1
      0xb b26956 b26957 b26972 (by decide +kernel) e26957 e26972
private theorem e26954 : Deny 5 13 b26954 :=
    branchAction rule_sound _ _ 1
      0xa b26954 b26955 b26956 (by decide +kernel) e26955 e26956
private theorem e26950 : Deny 5 13 b26950 :=
    branchAction rule_sound _ _ 2
      0x1c4 b26950 b26951 b26954 (by decide +kernel) e26951 e26954
private theorem e26924 : Deny 5 13 b26924 :=
    branchAction rule_sound _ _ 1
      0xb b26924 b26925 b26950 (by decide +kernel) e26925 e26950
private theorem e26916 : Deny 5 13 b26916 :=
    branchAction rule_sound _ _ 1
      0x9 b26916 b26917 b26924 (by decide +kernel) e26917 e26924
private theorem e26976 : Deny 5 13 b26976 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e26979 : Deny 5 13 b26979 := by
    apply closeAction rule_sound _ _ 64 [0xc3e090f8d88]
    decide +kernel
private theorem e26984 : Deny 5 13 b26984 := by
    apply closeAction rule_sound _ _ 64 [0x20c42780c70c3248]
    decide +kernel
private theorem e26978 : Deny 5 13 b26978 :=
    branchAction rule_sound _ _ 1
      0x7 b26978 b26979 b26984 (by decide +kernel) e26979 e26984
private theorem e26993 : Deny 5 13 b26993 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e26977 : Deny 5 13 b26977 :=
    branchAction rule_sound _ _ 1
      0xa b26977 b26978 b26993 (by decide +kernel) e26978 e26993
private theorem e26975 : Deny 5 13 b26975 :=
    branchAction rule_sound _ _ 2
      0x284 b26975 b26976 b26977 (by decide +kernel) e26976 e26977
private theorem e26995 : Deny 5 13 b26995 := by
    apply closeAction rule_sound _ _ 64 [0xdfe37244088e36]
    decide +kernel
private theorem e27000 : Deny 5 13 b27000 := by
    apply closeAction rule_sound _ _ 64 [0x7df7cb10b7c95ca]
    decide +kernel
private theorem e26994 : Deny 5 13 b26994 :=
    branchAction rule_sound _ _ 2
      0x1c4 b26994 b26995 b27000 (by decide +kernel) e26995 e27000
private theorem e26974 : Deny 5 13 b26974 :=
    branchAction rule_sound _ _ 1
      0xb b26974 b26975 b26994 (by decide +kernel) e26975 e26994
private theorem e27011 : Deny 5 13 b27011 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e27014 : Deny 5 13 b27014 := by
    apply closeAction rule_sound _ _ 64 [0x20f80c8243e03203248]
    decide +kernel
private theorem e27025 : Deny 5 13 b27025 := by
    apply closeAction rule_sound _ _ 64 [0x20820c7244238]
    decide +kernel
private theorem e27013 : Deny 5 13 b27013 :=
    branchAction rule_sound _ _ 1
      0x7 b27013 b27014 b27025 (by decide +kernel) e27014 e27025
private theorem e27032 : Deny 5 13 b27032 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e27012 : Deny 5 13 b27012 :=
    branchAction rule_sound _ _ 1
      0xa b27012 b27013 b27032 (by decide +kernel) e27013 e27032
private theorem e27010 : Deny 5 13 b27010 :=
    branchAction rule_sound _ _ 2
      0x284 b27010 b27011 b27012 (by decide +kernel) e27011 e27012
private theorem e27035 : Deny 5 13 b27035 := by
    apply closeAction rule_sound _ _ 64 [0x30f8dc80f8dc9]
    decide +kernel
private theorem e27040 : Deny 5 13 b27040 := by
    apply closeAction rule_sound _ _ 64 [0x30c80c3209]
    decide +kernel
private theorem e27034 : Deny 5 13 b27034 :=
    branchAction rule_sound _ _ 1
      0x8 b27034 b27035 b27040 (by decide +kernel) e27035 e27040
private theorem e27048 : Deny 5 13 b27048 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e27051 : Deny 5 13 b27051 := by
    apply closeAction rule_sound _ _ 64 [0x1f09f2780df24910b]
    decide +kernel
private theorem e27060 : Deny 5 13 b27060 := by
    apply closeAction rule_sound _ _ 64 [0x9f278]
    decide +kernel
private theorem e27050 : Deny 5 13 b27050 :=
    branchAction rule_sound _ _ 1
      0x8 b27050 b27051 b27060 (by decide +kernel) e27051 e27060
private theorem e27063 : Deny 5 13 b27063 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e27049 : Deny 5 13 b27049 :=
    branchAction rule_sound _ _ 1
      0xa b27049 b27050 b27063 (by decide +kernel) e27050 e27063
private theorem e27047 : Deny 5 13 b27047 :=
    branchAction rule_sound _ _ 1
      0xa b27047 b27048 b27049 (by decide +kernel) e27048 e27049
private theorem e27033 : Deny 5 13 b27033 :=
    branchAction rule_sound _ _ 2
      0x1c4 b27033 b27034 b27047 (by decide +kernel) e27034 e27047
private theorem e27009 : Deny 5 13 b27009 :=
    branchAction rule_sound _ _ 1
      0xb b27009 b27010 b27033 (by decide +kernel) e27010 e27033
private theorem e26973 : Deny 5 13 b26973 :=
    branchAction rule_sound _ _ 1
      0x9 b26973 b26974 b27009 (by decide +kernel) e26974 e27009
private theorem e26915 : Deny 5 13 b26915 :=
    branchAction rule_sound _ _ 1
      0x8 b26915 b26916 b26973 (by decide +kernel) e26916 e26973
private theorem e26813 : Deny 5 13 b26813 :=
    branchAction rule_sound _ _ 1
      0xb b26813 b26814 b26915 (by decide +kernel) e26814 e26915
theorem deny5_13 : Deny 5 13 ![⟨42,46⟩,⟨42,62⟩,⟨31,62⟩,⟨3,6⟩,⟨239,478⟩] := by
  exact e26813
end OMA.Blocks5_13_245212.S26813
