import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S27677
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b27677 : Box := ![⟨38,46⟩,⟨63,109⟩,⟨21,30⟩,⟨3,6⟩,⟨239,478⟩]
private def b27678 : Box := ![⟨38,41⟩,⟨63,109⟩,⟨21,30⟩,⟨3,6⟩,⟨239,478⟩]
private def b27679 : Box := ![⟨38,41⟩,⟨63,106⟩,⟨21,30⟩,⟨3,6⟩,⟨239,318⟩]
private def b27680 : Box := ![⟨38,41⟩,⟨63,78⟩,⟨21,30⟩,⟨3,6⟩,⟨239,317⟩]
private def b27681 : Box := ![⟨38,41⟩,⟨63,78⟩,⟨21,24⟩,⟨3,6⟩,⟨239,317⟩]
private def b27686 : Box := ![⟨38,41⟩,⟨63,78⟩,⟨25,30⟩,⟨3,6⟩,⟨239,317⟩]
private def b27687 : Box := ![⟨38,41⟩,⟨63,78⟩,⟨25,30⟩,⟨3,6⟩,⟨239,272⟩]
private def b27694 : Box := ![⟨38,41⟩,⟨63,78⟩,⟨25,30⟩,⟨3,6⟩,⟨273,317⟩]
private def b27701 : Box := ![⟨38,41⟩,⟨79,104⟩,⟨21,30⟩,⟨3,6⟩,⟨239,317⟩]
private def b27702 : Box := ![⟨38,41⟩,⟨79,104⟩,⟨21,24⟩,⟨3,6⟩,⟨239,317⟩]
private def b27703 : Box := ![⟨38,41⟩,⟨79,94⟩,⟨21,24⟩,⟨3,6⟩,⟨239,272⟩]
private def b27710 : Box := ![⟨38,41⟩,⟨79,94⟩,⟨21,24⟩,⟨3,6⟩,⟨273,317⟩]
private def b27715 : Box := ![⟨38,41⟩,⟨79,104⟩,⟨25,30⟩,⟨3,6⟩,⟨239,317⟩]
private def b27716 : Box := ![⟨38,41⟩,⟨79,104⟩,⟨25,30⟩,⟨3,6⟩,⟨239,272⟩]
private def b27717 : Box := ![⟨38,39⟩,⟨79,104⟩,⟨25,30⟩,⟨3,6⟩,⟨239,271⟩]
private def b27724 : Box := ![⟨40,41⟩,⟨79,104⟩,⟨25,30⟩,⟨3,6⟩,⟨239,271⟩]
private def b27729 : Box := ![⟨38,41⟩,⟨79,104⟩,⟨25,30⟩,⟨3,6⟩,⟨273,317⟩]
private def b27730 : Box := ![⟨38,39⟩,⟨79,104⟩,⟨25,30⟩,⟨3,6⟩,⟨277,317⟩]
private def b27737 : Box := ![⟨40,41⟩,⟨79,104⟩,⟨25,30⟩,⟨3,6⟩,⟨277,317⟩]
private def b27744 : Box := ![⟨38,41⟩,⟨63,106⟩,⟨21,30⟩,⟨3,6⟩,⟨319,478⟩]
private def b27745 : Box := ![⟨38,41⟩,⟨63,79⟩,⟨21,30⟩,⟨3,6⟩,⟨319,478⟩]
private def b27752 : Box := ![⟨38,41⟩,⟨80,106⟩,⟨21,30⟩,⟨3,6⟩,⟨319,478⟩]
private def b27753 : Box := ![⟨38,41⟩,⟨80,106⟩,⟨21,24⟩,⟨3,6⟩,⟨319,478⟩]
private def b27758 : Box := ![⟨38,41⟩,⟨80,106⟩,⟨25,30⟩,⟨3,6⟩,⟨319,478⟩]
private def b27759 : Box := ![⟨38,41⟩,⟨80,106⟩,⟨25,30⟩,⟨3,6⟩,⟨319,382⟩]
private def b27760 : Box := ![⟨38,39⟩,⟨80,105⟩,⟨25,30⟩,⟨3,6⟩,⟨331,379⟩]
private def b27765 : Box := ![⟨40,41⟩,⟨80,105⟩,⟨25,30⟩,⟨3,6⟩,⟨331,379⟩]
private def b27772 : Box := ![⟨38,41⟩,⟨80,106⟩,⟨25,30⟩,⟨3,6⟩,⟨383,478⟩]
private def b27783 : Box := ![⟨42,46⟩,⟨63,109⟩,⟨21,30⟩,⟨3,6⟩,⟨239,478⟩]
private def b27784 : Box := ![⟨42,46⟩,⟨63,109⟩,⟨21,30⟩,⟨3,6⟩,⟨239,318⟩]
private def b27785 : Box := ![⟨42,46⟩,⟨63,108⟩,⟨21,30⟩,⟨3,4⟩,⟨239,317⟩]
private def b27786 : Box := ![⟨42,46⟩,⟨63,108⟩,⟨21,30⟩,⟨5,6⟩,⟨239,317⟩]
private def b27787 : Box := ![⟨42,46⟩,⟨63,108⟩,⟨21,30⟩,⟨5,5⟩,⟨239,317⟩]
private def b27788 : Box := ![⟨42,46⟩,⟨63,78⟩,⟨21,30⟩,⟨5,5⟩,⟨239,317⟩]
private def b27789 : Box := ![⟨42,46⟩,⟨63,78⟩,⟨21,24⟩,⟨5,5⟩,⟨239,317⟩]
private def b27790 : Box := ![⟨42,46⟩,⟨63,78⟩,⟨21,24⟩,⟨5,5⟩,⟨239,272⟩]
private def b27797 : Box := ![⟨42,46⟩,⟨63,78⟩,⟨21,24⟩,⟨5,5⟩,⟨273,317⟩]
private def b27804 : Box := ![⟨42,46⟩,⟨63,78⟩,⟨25,30⟩,⟨5,5⟩,⟨239,317⟩]
private def b27811 : Box := ![⟨42,46⟩,⟨79,104⟩,⟨21,30⟩,⟨5,5⟩,⟨239,317⟩]
private def b27818 : Box := ![⟨42,46⟩,⟨63,108⟩,⟨21,30⟩,⟨6,6⟩,⟨239,317⟩]
private def b27819 : Box := ![⟨42,46⟩,⟨63,109⟩,⟨21,30⟩,⟨3,6⟩,⟨319,478⟩]
private def b27820 : Box := ![⟨42,46⟩,⟨63,79⟩,⟨21,30⟩,⟨3,6⟩,⟨319,478⟩]
private def b27821 : Box := ![⟨42,46⟩,⟨63,79⟩,⟨21,24⟩,⟨3,6⟩,⟨319,478⟩]
private def b27822 : Box := ![⟨42,46⟩,⟨63,79⟩,⟨21,24⟩,⟨3,6⟩,⟨319,382⟩]
private def b27823 : Box := ![⟨42,46⟩,⟨63,79⟩,⟨21,24⟩,⟨3,4⟩,⟨331,379⟩]
private def b27824 : Box := ![⟨42,46⟩,⟨63,79⟩,⟨21,24⟩,⟨5,6⟩,⟨331,379⟩]
private def b27835 : Box := ![⟨42,46⟩,⟨63,79⟩,⟨21,24⟩,⟨3,6⟩,⟨383,478⟩]
private def b27838 : Box := ![⟨42,46⟩,⟨63,79⟩,⟨25,30⟩,⟨3,6⟩,⟨319,478⟩]
private def b27839 : Box := ![⟨42,46⟩,⟨63,79⟩,⟨25,30⟩,⟨3,6⟩,⟨319,382⟩]
private def b27840 : Box := ![⟨42,46⟩,⟨63,79⟩,⟨25,30⟩,⟨3,4⟩,⟨331,379⟩]
private def b27841 : Box := ![⟨42,46⟩,⟨63,79⟩,⟨25,30⟩,⟨5,6⟩,⟨331,379⟩]
private def b27842 : Box := ![⟨42,46⟩,⟨63,79⟩,⟨25,30⟩,⟨5,5⟩,⟨331,379⟩]
private def b27843 : Box := ![⟨42,43⟩,⟨63,79⟩,⟨25,30⟩,⟨5,5⟩,⟨331,379⟩]
private def b27848 : Box := ![⟨44,46⟩,⟨63,79⟩,⟨25,30⟩,⟨5,5⟩,⟨331,379⟩]
private def b27855 : Box := ![⟨42,46⟩,⟨63,79⟩,⟨25,30⟩,⟨6,6⟩,⟨331,379⟩]
private def b27856 : Box := ![⟨42,46⟩,⟨63,79⟩,⟨25,30⟩,⟨3,6⟩,⟨383,478⟩]
private def b27867 : Box := ![⟨42,46⟩,⟨80,109⟩,⟨21,30⟩,⟨3,6⟩,⟨319,478⟩]
private def b27868 : Box := ![⟨42,46⟩,⟨80,109⟩,⟨21,24⟩,⟨3,6⟩,⟨319,478⟩]
private def b27869 : Box := ![⟨42,46⟩,⟨80,99⟩,⟨21,24⟩,⟨3,6⟩,⟨319,382⟩]
private def b27880 : Box := ![⟨42,46⟩,⟨80,99⟩,⟨21,24⟩,⟨3,6⟩,⟨383,478⟩]
private def b27889 : Box := ![⟨42,46⟩,⟨80,109⟩,⟨25,30⟩,⟨3,6⟩,⟨319,478⟩]
private def b27890 : Box := ![⟨42,46⟩,⟨80,109⟩,⟨25,30⟩,⟨3,6⟩,⟨319,382⟩]
private def b27897 : Box := ![⟨42,46⟩,⟨80,109⟩,⟨25,30⟩,⟨3,6⟩,⟨383,478⟩]
private theorem e27681 : Deny 5 13 b27681 := by
    apply closeAction rule_sound _ _ 64 [0x30f8dc811fe37d841f8]
    decide +kernel
private theorem e27687 : Deny 5 13 b27687 := by
    apply closeAction rule_sound _ _ 64 [0xc32430f8dc91c4]
    decide +kernel
private theorem e27694 : Deny 5 13 b27694 := by
    apply closeAction rule_sound _ _ 64 [0xc3243102238df61c4]
    decide +kernel
private theorem e27686 : Deny 5 13 b27686 :=
    branchAction rule_sound _ _ 1
      0xb b27686 b27687 b27694 (by decide +kernel) e27687 e27694
private theorem e27680 : Deny 5 13 b27680 :=
    branchAction rule_sound _ _ 1
      0x9 b27680 b27681 b27686 (by decide +kernel) e27681 e27686
private theorem e27703 : Deny 5 13 b27703 := by
    apply closeAction rule_sound _ _ 64 [0x3ac32030f8de12611c4]
    decide +kernel
private theorem e27710 : Deny 5 13 b27710 := by
    apply closeAction rule_sound _ _ 64 [0x3ac3e3721fe37da11c4]
    decide +kernel
private theorem e27702 : Deny 5 13 b27702 :=
    branchAction rule_sound _ _ 2
      0x2e1 b27702 b27703 b27710 (by decide +kernel) e27703 e27710
private theorem e27717 : Deny 5 13 b27717 := by
    apply closeAction rule_sound _ _ 64 [0xf8dc3ae12430c9221]
    decide +kernel
private theorem e27724 : Deny 5 13 b27724 := by
    apply closeAction rule_sound _ _ 64 [0x97e370c9108e37]
    decide +kernel
private theorem e27716 : Deny 5 13 b27716 :=
    branchAction rule_sound _ _ 2
      0x1c4 b27716 b27717 b27724 (by decide +kernel) e27717 e27724
private theorem e27730 : Deny 5 13 b27730 := by
    apply closeAction rule_sound _ _ 64 [0xc3ae12430f8dc9221]
    decide +kernel
private theorem e27737 : Deny 5 13 b27737 := by
    apply closeAction rule_sound _ _ 64 [0x5f8dc3e2b8490c3248]
    decide +kernel
private theorem e27729 : Deny 5 13 b27729 :=
    branchAction rule_sound _ _ 2
      0x1c4 b27729 b27730 b27737 (by decide +kernel) e27730 e27737
private theorem e27715 : Deny 5 13 b27715 :=
    branchAction rule_sound _ _ 1
      0xb b27715 b27716 b27729 (by decide +kernel) e27716 e27729
private theorem e27701 : Deny 5 13 b27701 :=
    branchAction rule_sound _ _ 1
      0x9 b27701 b27702 b27715 (by decide +kernel) e27702 e27715
private theorem e27679 : Deny 5 13 b27679 :=
    branchAction rule_sound _ _ 3
      0x8844 b27679 b27680 b27701 (by decide +kernel) e27680 e27701
private theorem e27745 : Deny 5 13 b27745 := by
    apply closeAction rule_sound _ _ 64 [0xdfe37242237d84087e36]
    decide +kernel
private theorem e27753 : Deny 5 13 b27753 := by
    apply closeAction rule_sound _ _ 64 [0xc4088e211021f8de1]
    decide +kernel
private theorem e27760 : Deny 5 13 b27760 := by
    apply closeAction rule_sound _ _ 64 [0x30f8dc87f8de1261]
    decide +kernel
private theorem e27765 : Deny 5 13 b27765 := by
    apply closeAction rule_sound _ _ 64 [0x30eb8490c3248]
    decide +kernel
private theorem e27759 : Deny 5 13 b27759 :=
    branchAction rule_sound _ _ 3
      0x7844 b27759 b27760 b27765 (by decide +kernel) e27760 e27765
private theorem e27772 : Deny 5 13 b27772 := by
    apply closeAction rule_sound _ _ 64 [0xc3e2b8490c47f8dc427821f7cbe37da11c4]
    decide +kernel
private theorem e27758 : Deny 5 13 b27758 :=
    branchAction rule_sound _ _ 1
      0xb b27758 b27759 b27772 (by decide +kernel) e27759 e27772
private theorem e27752 : Deny 5 13 b27752 :=
    branchAction rule_sound _ _ 1
      0x9 b27752 b27753 b27758 (by decide +kernel) e27753 e27758
private theorem e27744 : Deny 5 13 b27744 :=
    branchAction rule_sound _ _ 1
      0x8 b27744 b27745 b27752 (by decide +kernel) e27745 e27752
private theorem e27678 : Deny 5 13 b27678 :=
    branchAction rule_sound _ _ 2
      0x2e1 b27678 b27679 b27744 (by decide +kernel) e27679 e27744
private theorem e27785 : Deny 5 13 b27785 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e27790 : Deny 5 13 b27790 := by
    apply closeAction rule_sound _ _ 64 [0x83108e030c81c4]
    decide +kernel
private theorem e27797 : Deny 5 13 b27797 := by
    apply closeAction rule_sound _ _ 64 [0x30c90c3e081c4]
    decide +kernel
private theorem e27789 : Deny 5 13 b27789 :=
    branchAction rule_sound _ _ 1
      0xb b27789 b27790 b27797 (by decide +kernel) e27790 e27797
private theorem e27804 : Deny 5 13 b27804 := by
    apply closeAction rule_sound _ _ 64 [0x20c41f8103e032441f8]
    decide +kernel
private theorem e27788 : Deny 5 13 b27788 :=
    branchAction rule_sound _ _ 1
      0x9 b27788 b27789 b27804 (by decide +kernel) e27789 e27804
private theorem e27811 : Deny 5 13 b27811 := by
    apply closeAction rule_sound _ _ 64 [0x2083e03849847844278]
    decide +kernel
private theorem e27787 : Deny 5 13 b27787 :=
    branchAction rule_sound _ _ 2
      0x221 b27787 b27788 b27811 (by decide +kernel) e27788 e27811
private theorem e27818 : Deny 5 13 b27818 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e27786 : Deny 5 13 b27786 :=
    branchAction rule_sound _ _ 1
      0xa b27786 b27787 b27818 (by decide +kernel) e27787 e27818
private theorem e27784 : Deny 5 13 b27784 :=
    branchAction rule_sound _ _ 3
      0xa844 b27784 b27785 b27786 (by decide +kernel) e27785 e27786
private theorem e27823 : Deny 5 13 b27823 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e27824 : Deny 5 13 b27824 := by
    apply closeAction rule_sound _ _ 64 [0x1f0c31c3203088e361ca]
    decide +kernel
private theorem e27822 : Deny 5 13 b27822 :=
    branchAction rule_sound _ _ 2
      0x284 b27822 b27823 b27824 (by decide +kernel) e27823 e27824
private theorem e27835 : Deny 5 13 b27835 := by
    apply closeAction rule_sound _ _ 64 [0x7d7284]
    decide +kernel
private theorem e27821 : Deny 5 13 b27821 :=
    branchAction rule_sound _ _ 1
      0xb b27821 b27822 b27835 (by decide +kernel) e27822 e27835
private theorem e27840 : Deny 5 13 b27840 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e27843 : Deny 5 13 b27843 := by
    apply closeAction rule_sound _ _ 64 [0x30c90c8]
    decide +kernel
private theorem e27848 : Deny 5 13 b27848 := by
    apply closeAction rule_sound _ _ 64 [0x83109e03e03248]
    decide +kernel
private theorem e27842 : Deny 5 13 b27842 :=
    branchAction rule_sound _ _ 1
      0x7 b27842 b27843 b27848 (by decide +kernel) e27843 e27848
private theorem e27855 : Deny 5 13 b27855 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e27841 : Deny 5 13 b27841 :=
    branchAction rule_sound _ _ 1
      0xa b27841 b27842 b27855 (by decide +kernel) e27842 e27855
private theorem e27839 : Deny 5 13 b27839 :=
    branchAction rule_sound _ _ 2
      0x284 b27839 b27840 b27841 (by decide +kernel) e27840 e27841
private theorem e27856 : Deny 5 13 b27856 := by
    apply closeAction rule_sound _ _ 64 [0x1f7cb5ca7d75f8df6107e0a1c4]
    decide +kernel
private theorem e27838 : Deny 5 13 b27838 :=
    branchAction rule_sound _ _ 1
      0xb b27838 b27839 b27856 (by decide +kernel) e27839 e27856
private theorem e27820 : Deny 5 13 b27820 :=
    branchAction rule_sound _ _ 1
      0x9 b27820 b27821 b27838 (by decide +kernel) e27821 e27838
private theorem e27869 : Deny 5 13 b27869 := by
    apply closeAction rule_sound _ _ 64 [0x7dfe038490c3e212611e1297284]
    decide +kernel
private theorem e27880 : Deny 5 13 b27880 := by
    apply closeAction rule_sound _ _ 64 [0x1f7cb5ca7d7e37da12a11c4]
    decide +kernel
private theorem e27868 : Deny 5 13 b27868 :=
    branchAction rule_sound _ _ 2
      0x2e1 b27868 b27869 b27880 (by decide +kernel) e27869 e27880
private theorem e27890 : Deny 5 13 b27890 := by
    apply closeAction rule_sound _ _ 64 [0x97e375f8dc3248847844]
    decide +kernel
private theorem e27897 : Deny 5 13 b27897 := by
    apply closeAction rule_sound _ _ 64 [0x7f85ca0f8dc3ae12430c92211c4]
    decide +kernel
private theorem e27889 : Deny 5 13 b27889 :=
    branchAction rule_sound _ _ 1
      0xb b27889 b27890 b27897 (by decide +kernel) e27890 e27897
private theorem e27867 : Deny 5 13 b27867 :=
    branchAction rule_sound _ _ 1
      0x9 b27867 b27868 b27889 (by decide +kernel) e27868 e27889
private theorem e27819 : Deny 5 13 b27819 :=
    branchAction rule_sound _ _ 1
      0x8 b27819 b27820 b27867 (by decide +kernel) e27820 e27867
private theorem e27783 : Deny 5 13 b27783 :=
    branchAction rule_sound _ _ 1
      0xb b27783 b27784 b27819 (by decide +kernel) e27784 e27819
private theorem e27677 : Deny 5 13 b27677 :=
    branchAction rule_sound _ _ 1
      0x7 b27677 b27678 b27783 (by decide +kernel) e27678 e27783
theorem deny5_13 : Deny 5 13 ![⟨38,46⟩,⟨63,109⟩,⟨21,30⟩,⟨3,6⟩,⟨239,478⟩] := by
  exact e27677
end OMA.Blocks5_13_245212.S27677
