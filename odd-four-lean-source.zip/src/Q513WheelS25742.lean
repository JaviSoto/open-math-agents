import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S25742
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b25742 : Box := ![⟨31,37⟩,⟨63,126⟩,⟨15,30⟩,⟨3,69⟩,⟨127,164⟩]
theorem deny5_13 : Deny 5 13 ![⟨31,37⟩,⟨63,126⟩,⟨15,30⟩,⟨3,69⟩,⟨127,164⟩] := by
  have e25742 : Deny 5 13 b25742 := by
    apply closeAction rule_sound _ _ 64 [0xe11c38490c3e378478498442e12a321f0f8adf8c811fe2b8c42781eb7f7da311f7c3e37da12b62842f8de32231e3244,0xdc87c28442b8df52421c40f70c90c70c32480c3dc80f8dc72442ca8c88c77eb7c30f8de11c3de125f0a110ae37849103,0xc824722110b84a7da78ae04689e2311f2b87ca1c3e03e2b8490f8aa11ea84a7c38c77e321f26311f2c30f72431021f8,0x2775f8dc3e370c81c38498475f8dc32370c32090c32030f8dc8247204097dea8441f8dc25f8dc3204278dd7e370c8dc3,0x7c20e1]
    decide +kernel
  exact e25742
end OMA.Blocks5_13_245212.S25742
