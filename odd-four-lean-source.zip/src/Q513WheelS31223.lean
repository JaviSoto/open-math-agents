import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S31223
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b31223 : Box := ![⟨42,46⟩,⟨85,126⟩,⟨31,62⟩,⟨1,68⟩,⟨959,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨42,46⟩,⟨85,126⟩,⟨31,62⟩,⟨1,68⟩,⟨959,999999999999999999⟩] := by
  have e31223 : Deny 5 13 b31223 := by
    apply closeAction rule_sound _ _ 64 [0x83e2a0c8e21278583e031c90f80c80f81c92160f80c88490f8843e212788490c3e090f8d882211d72a128a5ca8cb8c9,0x2632030f88c90f88c22788c88df7d60e126128a58a8cb0dfae3278ae37f8df6ae32388c90c22788c2238df68c81e37df,0x2438475ca5ca84aae32e32430e32438c80f88c22388c78df7c20c9e032160f82475ca28a58a8cb0c3e2321fe37da31e3,0x2632078df7d628a58a8cb0820f88c9e232380f80e32231e30820e32231e32c3e038c80e32437f8df68c88c78df0f80e1,0xe078c88df7d628a58a8cb8c90f80c70e32437f8df61e32237d62962a32c3e021f87b8df68c8e237df58a28be2358ae23,0xe232388c7e020f88c9e03e038c98c80c38c81e37df58a2962a32e3263202083e03e232781f88c8e020c70f80c78c90c3,0x82083e232381f88c9e02083]
    decide +kernel
  exact e31223
end OMA.Blocks5_13_245212.S31223
