import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S4994
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b4994 : Box := ![⟨18,22⟩,⟨15,20⟩,⟨11,1920000000000000011376⟩,⟨3,1366486486486486494619⟩,⟨37,47⟩]
theorem deny5_13 : Deny 5 13 ![⟨18,22⟩,⟨15,20⟩,⟨11,1920000000000000011376⟩,⟨3,1366486486486486494619⟩,⟨37,47⟩] := by
  have e4994 : Deny 5 13 b4994 := by
    apply closeAction rule_sound _ _ 64 [0xbe3243102238da324288a8c88c72c30f8df68870f8df6888087e3788a0c3e378c90f8df68c88c40f8df68c41f8de3263,0xdc38c90e31e325cbdc0f80f8887be22a32542830e3203e371e326321cbdc0e22a32542830f8de326325cbdc0ef8842b8,0x70388a72f8c81021f8be32430881021f8df68c9d8288ada321cbdcdf68c9d84088e37da31e31020e210ae2f8942b70f8,0x72f7030f81e22af8c90c3e378c90f8df68c78c972f]
    decide +kernel
  exact e4994
end OMA.Blocks5_13_245212.S4994
