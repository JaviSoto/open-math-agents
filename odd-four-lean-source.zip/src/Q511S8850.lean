import FastReplay245212
import SparseDigit245212
import FastRound245212
import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S8850
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b8850 : Box := ![⟨15,22⟩,⟨15,30⟩,⟨7,1920000000000000011376⟩,⟨1,1664000000000000009895⟩,⟨103,999999999999999999⟩]
private def b8851 : Box := ![⟨15,22⟩,⟨15,30⟩,⟨8,16⟩,⟨1,994807017543859655053⟩,⟨103,999999999999999999⟩]
private def b8862 : Box := ![⟨15,22⟩,⟨15,30⟩,⟨17,1920000000000000011376⟩,⟨1,994807017543859655053⟩,⟨103,999999999999999999⟩]
private def b8863 : Box := ![⟨15,17⟩,⟨15,30⟩,⟨17,1920000000000000011376⟩,⟨1,994807017543859655053⟩,⟨103,999999999999999999⟩]
private def b8864 : Box := ![⟨15,17⟩,⟨16,30⟩,⟨20,1920000000000000011376⟩,⟨2,4⟩,⟨103,182⟩]
private def b8865 : Box := ![⟨15,17⟩,⟨16,30⟩,⟨20,1920000000000000011376⟩,⟨5,994807017543859655052⟩,⟨103,182⟩]
private def b8866 : Box := ![⟨15,17⟩,⟨16,20⟩,⟨21,1920000000000000011376⟩,⟨5,994807017543859655044⟩,⟨103,181⟩]
private def b8869 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨21,1920000000000000011376⟩,⟨5,994807017543859655044⟩,⟨103,181⟩]
private def b8870 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨21,42⟩,⟨5,994807017543859655044⟩,⟨103,181⟩]
private def b8879 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨43,1920000000000000011376⟩,⟨5,994807017543859655044⟩,⟨103,181⟩]
private def b8880 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨43,1920000000000000011376⟩,⟨5,994807017543859655044⟩,⟨103,131⟩]
private def b8881 : Box := ![⟨15,15⟩,⟨21,30⟩,⟨43,1920000000000000011376⟩,⟨5,994807017543859655044⟩,⟨103,131⟩]
private def b8884 : Box := ![⟨16,17⟩,⟨21,30⟩,⟨43,1920000000000000011376⟩,⟨5,994807017543859655044⟩,⟨103,131⟩]
private def b8885 : Box := ![⟨16,17⟩,⟨21,24⟩,⟨43,1920000000000000011376⟩,⟨5,994807017543859655044⟩,⟨103,131⟩]
private def b8896 : Box := ![⟨16,17⟩,⟨25,30⟩,⟨43,1920000000000000011376⟩,⟨5,994807017543859655044⟩,⟨103,131⟩]
private def b8897 : Box := ![⟨16,17⟩,⟨25,30⟩,⟨43,86⟩,⟨5,994807017543859655044⟩,⟨103,131⟩]
private def b8898 : Box := ![⟨16,17⟩,⟨25,30⟩,⟨43,86⟩,⟨5,62⟩,⟨103,115⟩]
private def b8911 : Box := ![⟨16,17⟩,⟨25,30⟩,⟨43,86⟩,⟨5,62⟩,⟨116,131⟩]
private def b8918 : Box := ![⟨16,17⟩,⟨25,30⟩,⟨87,1920000000000000011376⟩,⟨5,994807017543859655044⟩,⟨103,131⟩]
private def b8921 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨43,1920000000000000011376⟩,⟨5,994807017543859655044⟩,⟨132,181⟩]
private def b8936 : Box := ![⟨18,22⟩,⟨15,30⟩,⟨17,1920000000000000011376⟩,⟨1,994807017543859655053⟩,⟨103,999999999999999999⟩]
private def b8937 : Box := ![⟨18,22⟩,⟨15,30⟩,⟨17,1920000000000000011376⟩,⟨1,994807017543859655053⟩,⟨103,206⟩]
private def b8938 : Box := ![⟨18,22⟩,⟨15,20⟩,⟨17,1920000000000000011376⟩,⟨1,994807017543859655045⟩,⟨103,199⟩]
private def b8939 : Box := ![⟨18,22⟩,⟨15,20⟩,⟨17,34⟩,⟨1,994807017543859655042⟩,⟨103,199⟩]
private def b8948 : Box := ![⟨18,22⟩,⟨15,20⟩,⟨35,1920000000000000011376⟩,⟨1,994807017543859655042⟩,⟨103,199⟩]
private def b8949 : Box := ![⟨18,22⟩,⟨15,20⟩,⟨35,1920000000000000011376⟩,⟨1,2⟩,⟨103,199⟩]
private def b8950 : Box := ![⟨18,22⟩,⟨15,20⟩,⟨35,1920000000000000011376⟩,⟨3,994807017543859655042⟩,⟨103,199⟩]
private def b8951 : Box := ![⟨18,22⟩,⟨15,20⟩,⟨35,1920000000000000011376⟩,⟨3,994807017543859655042⟩,⟨103,135⟩]
private def b8952 : Box := ![⟨18,19⟩,⟨15,20⟩,⟨35,1920000000000000011376⟩,⟨3,994807017543859655042⟩,⟨103,131⟩]
private def b8967 : Box := ![⟨20,22⟩,⟨15,20⟩,⟨35,1920000000000000011376⟩,⟨3,994807017543859655042⟩,⟨103,131⟩]
private def b8968 : Box := ![⟨20,22⟩,⟨15,17⟩,⟨35,1920000000000000011376⟩,⟨3,994807017543859655042⟩,⟨103,131⟩]
private def b8981 : Box := ![⟨20,22⟩,⟨18,20⟩,⟨35,1920000000000000011376⟩,⟨3,994807017543859655042⟩,⟨103,131⟩]
private def b8996 : Box := ![⟨18,22⟩,⟨15,20⟩,⟨35,1920000000000000011376⟩,⟨3,994807017543859655042⟩,⟨136,199⟩]
private def b8997 : Box := ![⟨18,19⟩,⟨15,20⟩,⟨35,1920000000000000011376⟩,⟨3,936740088105726877820⟩,⟨137,199⟩]
private def b9000 : Box := ![⟨20,22⟩,⟨15,20⟩,⟨35,1920000000000000011376⟩,⟨3,936740088105726877820⟩,⟨137,199⟩]
private def b9001 : Box := ![⟨20,22⟩,⟨15,17⟩,⟨35,1920000000000000011376⟩,⟨3,936740088105726877820⟩,⟨137,199⟩]
private def b9012 : Box := ![⟨20,22⟩,⟨18,20⟩,⟨35,1920000000000000011376⟩,⟨3,936740088105726877820⟩,⟨137,199⟩]
private def b9025 : Box := ![⟨18,22⟩,⟨21,30⟩,⟨17,1920000000000000011376⟩,⟨1,994807017543859655045⟩,⟨103,199⟩]
private def b9026 : Box := ![⟨18,22⟩,⟨21,30⟩,⟨17,34⟩,⟨1,994807017543859655045⟩,⟨103,199⟩]
private def b9027 : Box := ![⟨18,22⟩,⟨21,30⟩,⟨17,34⟩,⟨1,36⟩,⟨103,135⟩]
private def b9028 : Box := ![⟨18,22⟩,⟨21,30⟩,⟨17,34⟩,⟨1,2⟩,⟨103,131⟩]
private def b9029 : Box := ![⟨18,19⟩,⟨21,30⟩,⟨17,34⟩,⟨1,2⟩,⟨103,131⟩]
private def b9034 : Box := ![⟨20,22⟩,⟨21,30⟩,⟨17,34⟩,⟨1,2⟩,⟨103,131⟩]
private def b9049 : Box := ![⟨18,22⟩,⟨21,30⟩,⟨17,34⟩,⟨3,36⟩,⟨103,131⟩]
private def b9050 : Box := ![⟨18,19⟩,⟨21,30⟩,⟨17,34⟩,⟨3,36⟩,⟨103,131⟩]
private def b9059 : Box := ![⟨20,22⟩,⟨21,30⟩,⟨17,34⟩,⟨3,36⟩,⟨103,131⟩]
private def b9074 : Box := ![⟨18,22⟩,⟨21,30⟩,⟨17,34⟩,⟨1,36⟩,⟨136,199⟩]
private def b9075 : Box := ![⟨18,19⟩,⟨21,30⟩,⟨17,34⟩,⟨1,34⟩,⟨137,199⟩]
private def b9080 : Box := ![⟨20,22⟩,⟨21,30⟩,⟨17,34⟩,⟨1,34⟩,⟨137,199⟩]
private def b9081 : Box := ![⟨20,22⟩,⟨21,30⟩,⟨17,34⟩,⟨1,2⟩,⟨137,199⟩]
private def b9090 : Box := ![⟨20,22⟩,⟨21,30⟩,⟨17,34⟩,⟨3,34⟩,⟨137,199⟩]
private def b9105 : Box := ![⟨18,22⟩,⟨21,30⟩,⟨35,1920000000000000011376⟩,⟨1,994807017543859655045⟩,⟨103,199⟩]
private def b9106 : Box := ![⟨18,22⟩,⟨21,30⟩,⟨35,1920000000000000011376⟩,⟨1,2⟩,⟨103,199⟩]
private def b9109 : Box := ![⟨18,22⟩,⟨21,30⟩,⟨35,1920000000000000011376⟩,⟨3,994807017543859655045⟩,⟨103,199⟩]
private def b9110 : Box := ![⟨18,22⟩,⟨21,30⟩,⟨35,1920000000000000011376⟩,⟨3,994807017543859655045⟩,⟨103,135⟩]
private def b9111 : Box := ![⟨18,19⟩,⟨21,30⟩,⟨35,1920000000000000011376⟩,⟨3,994807017543859655045⟩,⟨103,131⟩]
private def b9112 : Box := ![⟨18,19⟩,⟨21,24⟩,⟨35,1920000000000000011376⟩,⟨3,994807017543859655045⟩,⟨103,131⟩]
private def b9123 : Box := ![⟨18,19⟩,⟨25,30⟩,⟨35,1920000000000000011376⟩,⟨3,994807017543859655045⟩,⟨103,131⟩]
private def b9124 : Box := ![⟨18,19⟩,⟨25,30⟩,⟨35,70⟩,⟨3,994807017543859655045⟩,⟨103,131⟩]
private def b9125 : Box := ![⟨18,19⟩,⟨25,30⟩,⟨35,70⟩,⟨3,6⟩,⟨103,131⟩]
private def b9128 : Box := ![⟨18,19⟩,⟨25,30⟩,⟨35,70⟩,⟨7,54⟩,⟨103,131⟩]
private def b9143 : Box := ![⟨18,19⟩,⟨25,30⟩,⟨71,1920000000000000011376⟩,⟨3,994807017543859655045⟩,⟨103,131⟩]
private def b9144 : Box := ![⟨20,22⟩,⟨21,30⟩,⟨35,1920000000000000011376⟩,⟨3,994807017543859655045⟩,⟨103,131⟩]
private def b9159 : Box := ![⟨18,22⟩,⟨21,30⟩,⟨35,1920000000000000011376⟩,⟨3,994807017543859655045⟩,⟨136,199⟩]
private def b9160 : Box := ![⟨18,19⟩,⟨21,30⟩,⟨35,1920000000000000011376⟩,⟨3,936740088105726877824⟩,⟨137,199⟩]
private def b9161 : Box := ![⟨18,19⟩,⟨21,24⟩,⟨35,1920000000000000011376⟩,⟨3,936740088105726877823⟩,⟨137,199⟩]
private def b9172 : Box := ![⟨18,19⟩,⟨25,30⟩,⟨35,1920000000000000011376⟩,⟨3,936740088105726877823⟩,⟨137,199⟩]
private def b9173 : Box := ![⟨18,19⟩,⟨25,30⟩,⟨35,70⟩,⟨3,936740088105726877823⟩,⟨137,199⟩]
private def b9174 : Box := ![⟨18,19⟩,⟨25,30⟩,⟨35,70⟩,⟨3,51⟩,⟨137,162⟩]
private def b9189 : Box := ![⟨18,19⟩,⟨25,30⟩,⟨35,70⟩,⟨3,51⟩,⟨163,199⟩]
private def b9202 : Box := ![⟨18,19⟩,⟨25,30⟩,⟨71,1920000000000000011376⟩,⟨3,936740088105726877823⟩,⟨137,199⟩]
private def b9211 : Box := ![⟨20,22⟩,⟨21,30⟩,⟨35,1920000000000000011376⟩,⟨3,936740088105726877824⟩,⟨137,199⟩]
private def b9212 : Box := ![⟨20,22⟩,⟨21,24⟩,⟨35,1920000000000000011376⟩,⟨3,936740088105726877824⟩,⟨137,199⟩]
private def b9213 : Box := ![⟨20,22⟩,⟨21,24⟩,⟨35,70⟩,⟨3,936740088105726877822⟩,⟨137,199⟩]
private def b9214 : Box := ![⟨20,22⟩,⟨21,24⟩,⟨35,70⟩,⟨3,50⟩,⟨137,162⟩]
private def b9225 : Box := ![⟨20,22⟩,⟨21,24⟩,⟨35,70⟩,⟨3,50⟩,⟨163,199⟩]
private def b9236 : Box := ![⟨20,22⟩,⟨21,24⟩,⟨71,1920000000000000011376⟩,⟨3,936740088105726877822⟩,⟨137,199⟩]
private def b9239 : Box := ![⟨20,22⟩,⟨25,30⟩,⟨35,1920000000000000011376⟩,⟨3,936740088105726877824⟩,⟨137,199⟩]
private def b9240 : Box := ![⟨20,22⟩,⟨25,30⟩,⟨35,70⟩,⟨3,936740088105726877824⟩,⟨137,199⟩]
private def b9241 : Box := ![⟨20,22⟩,⟨25,30⟩,⟨35,70⟩,⟨3,52⟩,⟨137,162⟩]
private def b9246 : Box := ![⟨20,22⟩,⟨25,30⟩,⟨35,70⟩,⟨3,52⟩,⟨163,199⟩]
private def b9259 : Box := ![⟨20,22⟩,⟨25,30⟩,⟨71,1920000000000000011376⟩,⟨3,936740088105726877824⟩,⟨137,199⟩]
private def b9260 : Box := ![⟨18,22⟩,⟨15,30⟩,⟨17,1920000000000000011376⟩,⟨1,994807017543859655053⟩,⟨207,999999999999999999⟩]
private def b9261 : Box := ![⟨18,22⟩,⟨15,20⟩,⟨17,1920000000000000011376⟩,⟨1,864390243902439029543⟩,⟨207,999999999999999999⟩]
private def b9272 : Box := ![⟨18,22⟩,⟨21,30⟩,⟨17,1920000000000000011376⟩,⟨1,864390243902439029543⟩,⟨207,999999999999999999⟩]
private def b9273 : Box := ![⟨18,22⟩,⟨21,30⟩,⟨17,34⟩,⟨1,864390243902439029543⟩,⟨207,999999999999999999⟩]
private def b9284 : Box := ![⟨18,22⟩,⟨21,30⟩,⟨35,1920000000000000011376⟩,⟨1,864390243902439029543⟩,⟨207,999999999999999999⟩]
private def b9285 : Box := ![⟨18,22⟩,⟨21,30⟩,⟨35,1920000000000000011376⟩,⟨1,864390243902439029543⟩,⟨207,414⟩]
private def b9286 : Box := ![⟨18,19⟩,⟨21,30⟩,⟨35,1920000000000000011376⟩,⟨1,864390243902439029536⟩,⟨207,414⟩]
private def b9287 : Box := ![⟨18,19⟩,⟨21,30⟩,⟨40,1920000000000000011376⟩,⟨2,4⟩,⟨207,378⟩]
private def b9288 : Box := ![⟨18,19⟩,⟨21,30⟩,⟨40,1920000000000000011376⟩,⟨5,864390243902439029536⟩,⟨207,378⟩]
private def b9289 : Box := ![⟨18,19⟩,⟨21,24⟩,⟨41,1920000000000000011376⟩,⟨5,864390243902439029536⟩,⟨207,378⟩]
private def b9292 : Box := ![⟨18,19⟩,⟨25,30⟩,⟨41,1920000000000000011376⟩,⟨5,864390243902439029536⟩,⟨207,378⟩]
private def b9305 : Box := ![⟨20,22⟩,⟨21,30⟩,⟨35,1920000000000000011376⟩,⟨1,864390243902439029536⟩,⟨207,414⟩]
private def b9306 : Box := ![⟨20,22⟩,⟨21,24⟩,⟨35,1920000000000000011376⟩,⟨1,864390243902439029536⟩,⟨207,414⟩]
private def b9321 : Box := ![⟨20,22⟩,⟨25,30⟩,⟨35,1920000000000000011376⟩,⟨1,864390243902439029536⟩,⟨207,414⟩]
private def b9322 : Box := ![⟨20,22⟩,⟨25,30⟩,⟨35,1920000000000000011376⟩,⟨1,2⟩,⟨207,414⟩]
private def b9323 : Box := ![⟨20,22⟩,⟨25,30⟩,⟨35,1920000000000000011376⟩,⟨3,864390243902439029536⟩,⟨207,414⟩]
private def b9324 : Box := ![⟨20,22⟩,⟨25,30⟩,⟨35,70⟩,⟨3,864390243902439029536⟩,⟨207,414⟩]
private def b9325 : Box := ![⟨20,22⟩,⟨25,30⟩,⟨35,70⟩,⟨3,48⟩,⟨207,276⟩]
private def b9340 : Box := ![⟨20,22⟩,⟨25,30⟩,⟨35,70⟩,⟨3,48⟩,⟨277,414⟩]
private def b9355 : Box := ![⟨20,22⟩,⟨25,30⟩,⟨71,1920000000000000011376⟩,⟨3,864390243902439029536⟩,⟨207,414⟩]
private def b9364 : Box := ![⟨18,22⟩,⟨21,30⟩,⟨35,1920000000000000011376⟩,⟨1,864390243902439029543⟩,⟨415,999999999999999999⟩]
private def b9365 : Box := ![⟨18,19⟩,⟨21,30⟩,⟨35,1920000000000000011376⟩,⟨1,764204851752021567898⟩,⟨415,999999999999999999⟩]
private def b9366 : Box := ![⟨20,22⟩,⟨21,30⟩,⟨35,1920000000000000011376⟩,⟨1,764204851752021567898⟩,⟨415,999999999999999999⟩]
private def b9367 : Box := ![⟨20,22⟩,⟨21,24⟩,⟨35,1920000000000000011376⟩,⟨1,764204851752021567898⟩,⟨415,999999999999999999⟩]
private def b9370 : Box := ![⟨20,22⟩,⟨25,30⟩,⟨35,1920000000000000011376⟩,⟨1,764204851752021567898⟩,⟨415,999999999999999999⟩]
private def b9371 : Box := ![⟨20,22⟩,⟨25,30⟩,⟨35,70⟩,⟨1,764204851752021567898⟩,⟨415,999999999999999999⟩]
private def b9372 : Box := ![⟨20,20⟩,⟨25,30⟩,⟨35,70⟩,⟨1,48⟩,⟨415,1374⟩]
private def b9373 : Box := ![⟨21,22⟩,⟨25,30⟩,⟨35,70⟩,⟨1,48⟩,⟨415,1374⟩]
private def b9374 : Box := ![⟨21,22⟩,⟨25,30⟩,⟨35,70⟩,⟨1,2⟩,⟨415,1370⟩]
private def b9375 : Box := ![⟨21,22⟩,⟨25,30⟩,⟨35,70⟩,⟨3,42⟩,⟨415,1370⟩]
private def b9390 : Box := ![⟨20,22⟩,⟨25,30⟩,⟨71,1920000000000000011376⟩,⟨1,764204851752021567898⟩,⟨415,999999999999999999⟩]
private def b9391 : Box := ![⟨20,22⟩,⟨25,30⟩,⟨71,1920000000000000011376⟩,⟨1,2⟩,⟨415,999999999999999999⟩]
private def b9392 : Box := ![⟨20,22⟩,⟨25,30⟩,⟨71,1920000000000000011376⟩,⟨3,764204851752021567898⟩,⟨415,999999999999999999⟩]
private def b9393 : Box := ![⟨20,22⟩,⟨25,30⟩,⟨71,1920000000000000011376⟩,⟨3,6⟩,⟨415,999999999999999999⟩]
private def b9394 : Box := ![⟨20,22⟩,⟨25,30⟩,⟨71,1920000000000000011376⟩,⟨7,764204851752021567898⟩,⟨415,999999999999999999⟩]
private def b9395 : Box := ![⟨20,22⟩,⟨25,30⟩,⟨71,1920000000000000011376⟩,⟨7,764204851752021567898⟩,⟨415,830⟩]
private def b9406 : Box := ![⟨20,22⟩,⟨25,30⟩,⟨71,1920000000000000011376⟩,⟨7,764204851752021567898⟩,⟨831,999999999999999999⟩]
private def b9407 : Box := ![⟨20,20⟩,⟨25,30⟩,⟨71,1920000000000000011376⟩,⟨7,685382755842062856624⟩,⟨831,999999999999999999⟩]
private def b9408 : Box := ![⟨21,22⟩,⟨25,30⟩,⟨71,1920000000000000011376⟩,⟨7,685382755842062856624⟩,⟨831,999999999999999999⟩]
private def b9409 : Box := ![⟨21,22⟩,⟨25,27⟩,⟨71,1920000000000000011376⟩,⟨7,685382755842062856624⟩,⟨831,999999999999999999⟩]
private def b9412 : Box := ![⟨21,22⟩,⟨28,30⟩,⟨71,1920000000000000011376⟩,⟨7,685382755842062856624⟩,⟨831,999999999999999999⟩]
private def b9413 : Box := ![⟨21,22⟩,⟨28,30⟩,⟨71,142⟩,⟨7,685382755842062856624⟩,⟨831,999999999999999999⟩]
private def b9426 : Box := ![⟨21,22⟩,⟨28,30⟩,⟨143,1920000000000000011376⟩,⟨7,685382755842062856624⟩,⟨831,999999999999999999⟩]
private def b9427 : Box := ![⟨21,22⟩,⟨28,30⟩,⟨143,1920000000000000011376⟩,⟨7,685382755842062856624⟩,⟨831,1662⟩]
private def b9428 : Box := ![⟨21,22⟩,⟨28,30⟩,⟨143,1920000000000000011376⟩,⟨7,685382755842062856624⟩,⟨1663,999999999999999999⟩]
private def b9429 : Box := ![⟨21,22⟩,⟨28,30⟩,⟨143,1920000000000000011376⟩,⟨7,621300219138056979598⟩,⟨1663,3326⟩]
private def b9430 : Box := ![⟨21,22⟩,⟨28,30⟩,⟨143,1920000000000000011376⟩,⟨7,621300219138056979598⟩,⟨3327,999999999999999999⟩]
private def b9431 : Box := ![⟨21,21⟩,⟨28,30⟩,⟨143,1920000000000000011376⟩,⟨7,568176352705410825030⟩,⟨3327,999999999999999999⟩]
private def b9432 : Box := ![⟨22,22⟩,⟨28,30⟩,⟨143,1920000000000000011376⟩,⟨7,568176352705410825030⟩,⟨3327,999999999999999999⟩]
private def b9433 : Box := ![⟨22,22⟩,⟨28,30⟩,⟨143,1920000000000000011376⟩,⟨7,568176352705410825030⟩,⟨3327,6654⟩]
private def b9434 : Box := ![⟨22,22⟩,⟨28,30⟩,⟨143,1920000000000000011376⟩,⟨7,568176352705410825030⟩,⟨6655,999999999999999999⟩]
theorem deny5_11 : Deny 5 11 ![⟨15,22⟩,⟨15,30⟩,⟨7,1920000000000000011376⟩,⟨1,1664000000000000009895⟩,⟨103,999999999999999999⟩] := by
  have e8851 : Deny 5 11 b8851 := by
    apply closeAction rule_sound _ _ 64 [0x30f88c90f8df6d631c3e37db58c90f8df68c8d631021f8de3]
    decide +kernel
  have e8864 : Deny 5 11 b8864 := by
    apply closeAction rule_sound _ _ 64 [0x2884]
    decide +kernel
  have e8866 : Deny 5 11 b8866 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3087e37da3]
    decide +kernel
  have e8870 : Deny 5 11 b8870 := by
    apply closeAction rule_sound _ _ 64 [0x30f8de325ce37d870881021f8da3]
    decide +kernel
  have e8881 : Deny 5 11 b8881 := by
    apply closeAction rule_sound _ _ 64 [0x1cbc4088e37db5]
    decide +kernel
  have e8885 : Deny 5 11 b8885 := by
    apply closeAction rule_sound _ _ 64 [0x72f709bdc0f8da2284087e23242be22a3]
    decide +kernel
  have e8898 : Deny 5 11 b8898 := by
    apply closeAction rule_sound _ _ 64 [0x83be3108e2f0e3243bc3e378c90f8df68c81c3be2284]
    decide +kernel
  have e8911 : Deny 5 11 b8911 := by
    apply closeAction rule_sound _ _ 64 [0xef0f78c9737da32021f78c4]
    decide +kernel
  have e8897 : Deny 5 11 b8897 :=
    branchAction rule_sound _ _ 2
      0x2e3 b8897 b8898 b8911 (by decide +kernel) e8898 e8911
  have e8918 : Deny 5 11 b8918 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdcbe326f]
    decide +kernel
  have e8896 : Deny 5 11 b8896 :=
    branchAction rule_sound _ _ 1
      0x9 b8896 b8897 b8918 (by decide +kernel) e8897 e8918
  have e8884 : Deny 5 11 b8884 :=
    branchAction rule_sound _ _ 1
      0x8 b8884 b8885 b8896 (by decide +kernel) e8885 e8896
  have e8880 : Deny 5 11 b8880 :=
    branchAction rule_sound _ _ 1
      0x7 b8880 b8881 b8884 (by decide +kernel) e8881 e8884
  have e8921 : Deny 5 11 b8921 := by
    apply closeAction rule_sound _ _ 64 [0x72f709bdc0f8df688ae368c90af88a738df61c22021f68c4]
    decide +kernel
  have e8879 : Deny 5 11 b8879 :=
    branchAction rule_sound _ _ 1
      0xb b8879 b8880 b8921 (by decide +kernel) e8880 e8921
  have e8869 : Deny 5 11 b8869 :=
    branchAction rule_sound _ _ 1
      0x9 b8869 b8870 b8879 (by decide +kernel) e8870 e8879
  have e8865 : Deny 5 11 b8865 :=
    branchAction rule_sound _ _ 4
      0x2368c4 b8865 b8866 b8869 (by decide +kernel) e8866 e8869
  have e8863 : Deny 5 11 b8863 :=
    branchAction rule_sound _ _ 6
      0x2b8df6d63 b8863 b8864 b8865 (by decide +kernel) e8864 e8865
  have e8939 : Deny 5 11 b8939 := by
    apply closeAction rule_sound _ _ 64 [0xc3e378c90f8df68c80f8df68c7103e37db58c41f8de3]
    decide +kernel
  have e8949 : Deny 5 11 b8949 := by
    apply closeAction rule_sound _ _ 64 [0x14]
    decide +kernel
  have e8952 : Deny 5 11 b8952 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdcbe326f0ef0f78c911ce37da3107e2325cbc472f8c4278da3202be22a3]
    decide +kernel
  have e8968 : Deny 5 11 b8968 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdcbe326f0ef0e3243e23203e37d878c90f8be22a3]
    decide +kernel
  have e8981 : Deny 5 11 b8981 := by
    apply closeAction rule_sound _ _ 64 [0xaf8c472f8c4278bc20ef8c4238bc40e3109e03e2f0e32478c90ef88a]
    decide +kernel
  have e8967 : Deny 5 11 b8967 :=
    branchAction rule_sound _ _ 1
      0x8 b8967 b8968 b8981 (by decide +kernel) e8968 e8981
  have e8951 : Deny 5 11 b8951 :=
    branchAction rule_sound _ _ 2
      0x1c4 b8951 b8952 b8967 (by decide +kernel) e8952 e8967
  have e8997 : Deny 5 11 b8997 := by
    apply closeAction rule_sound _ _ 64 [0x1cbc4088e37da3]
    decide +kernel
  have e9001 : Deny 5 11 b9001 := by
    apply closeAction rule_sound _ _ 64 [0x72f709bdc8c90af88a50a738df61f8da3]
    decide +kernel
  have e9012 : Deny 5 11 b9012 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdcbe326f703e222af0f88c90f8df61e3243e2f88a]
    decide +kernel
  have e9000 : Deny 5 11 b9000 :=
    branchAction rule_sound _ _ 1
      0x8 b9000 b9001 b9012 (by decide +kernel) e9001 e9012
  have e8996 : Deny 5 11 b8996 :=
    branchAction rule_sound _ _ 3
      0x78c4 b8996 b8997 b9000 (by decide +kernel) e8997 e9000
  have e8950 : Deny 5 11 b8950 :=
    branchAction rule_sound _ _ 1
      0xb b8950 b8951 b8996 (by decide +kernel) e8951 e8996
  have e8948 : Deny 5 11 b8948 :=
    branchAction rule_sound _ _ 1
      0xa b8948 b8949 b8950 (by decide +kernel) e8949 e8950
  have e8938 : Deny 5 11 b8938 :=
    branchAction rule_sound _ _ 2
      0x263 b8938 b8939 b8948 (by decide +kernel) e8939 e8948
  have e9029 : Deny 5 11 b9029 := by
    apply closeAction rule_sound _ _ 64 [0x3087102238df6]
    decide +kernel
  have e9034 : Deny 5 11 b9034 := by
    apply closeAction rule_sound _ _ 64 [0xf70c80c70c3e371c90c3e37da21c3e37248]
    decide +kernel
  have e9028 : Deny 5 11 b9028 :=
    branchAction rule_sound _ _ 1
      0x7 b9028 b9029 b9034 (by decide +kernel) e9029 e9034
  have e9050 : Deny 5 11 b9050 := by
    apply closeAction rule_sound _ _ 64 [0x30e32038c90c40f8de3109e37da3223]
    decide +kernel
  have e9059 : Deny 5 11 b9059 := by
    apply closeAction rule_sound _ _ 64 [0x20c4238dc40c41f8dc30e31e32430e31c38c98c8]
    decide +kernel
  have e9049 : Deny 5 11 b9049 :=
    branchAction rule_sound _ _ 1
      0x7 b9049 b9050 b9059 (by decide +kernel) e9050 e9059
  have e9027 : Deny 5 11 b9027 :=
    branchAction rule_sound _ _ 2
      0x284 b9027 b9028 b9049 (by decide +kernel) e9028 e9049
  have e9075 : Deny 5 11 b9075 := by
    apply closeAction rule_sound _ _ 64 [0xc3e37da3204088e37da3]
    decide +kernel
  have e9081 : Deny 5 11 b9081 := by
    apply closeAction rule_sound _ _ 64 [0x30c80f8243e37d880f8df6d47]
    decide +kernel
  have e9090 : Deny 5 11 b9090 := by
    apply closeAction rule_sound _ _ 64 [0x3e038c80c70c3e371e32430f8df61c3e378c98c8]
    decide +kernel
  have e9080 : Deny 5 11 b9080 :=
    branchAction rule_sound _ _ 1
      0xa b9080 b9081 b9090 (by decide +kernel) e9081 e9090
  have e9074 : Deny 5 11 b9074 :=
    branchAction rule_sound _ _ 3
      0x78c4 b9074 b9075 b9080 (by decide +kernel) e9075 e9080
  have e9026 : Deny 5 11 b9026 :=
    branchAction rule_sound _ _ 2
      0x2e3 b9026 b9027 b9074 (by decide +kernel) e9027 e9074
  have e9106 : Deny 5 11 b9106 := by
    apply closeAction rule_sound _ _ 64 [0xc3bec888b62]
    decide +kernel
  have e9112 : Deny 5 11 b9112 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe311cbe3109e2f0f80e322f0e3263243e222a3]
    decide +kernel
  have e9125 : Deny 5 11 b9125 := by
    apply closeAction rule_sound _ _ 64 [0x30e2222]
    decide +kernel
  have e9128 : Deny 5 11 b9128 := by
    apply closeAction rule_sound _ _ 64 [0x832770838c7bc38c98c88c40820c7888dc42f8]
    decide +kernel
  have e9124 : Deny 5 11 b9124 :=
    branchAction rule_sound _ _ 2
      0x2a3 b9124 b9125 b9128 (by decide +kernel) e9125 e9128
  have e9143 : Deny 5 11 b9143 := by
    apply closeAction rule_sound _ _ 64 [0x538def]
    decide +kernel
  have e9123 : Deny 5 11 b9123 :=
    branchAction rule_sound _ _ 1
      0x9 b9123 b9124 b9143 (by decide +kernel) e9124 e9143
  have e9111 : Deny 5 11 b9111 :=
    branchAction rule_sound _ _ 1
      0x8 b9111 b9112 b9123 (by decide +kernel) e9112 e9123
  have e9144 : Deny 5 11 b9144 := by
    apply closeAction rule_sound _ _ 64 [0xaf8820e2107e370820e3223107e03e370e21e22a3223277]
    decide +kernel
  have e9110 : Deny 5 11 b9110 :=
    branchAction rule_sound _ _ 2
      0x1c4 b9110 b9111 b9144 (by decide +kernel) e9111 e9144
  have e9161 : Deny 5 11 b9161 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdcbe326f0c21dce37da32388c90a22a3]
    decide +kernel
  have e9174 : Deny 5 11 b9174 := by
    apply closeAction rule_sound _ _ 64 [0x831c38c90f80f8bc70e32632030f8de2222284]
    decide +kernel
  have e9189 : Deny 5 11 b9189 := by
    apply closeAction rule_sound _ _ 64 [0xf80f8dc70e3243e3788a0ef0f8de32421f7da3223]
    decide +kernel
  have e9173 : Deny 5 11 b9173 :=
    branchAction rule_sound _ _ 2
      0x2e3 b9173 b9174 b9189 (by decide +kernel) e9174 e9189
  have e9202 : Deny 5 11 b9202 := by
    apply closeAction rule_sound _ _ 64 [0x1cbc272f0f88c98c41f872f8c8be326f]
    decide +kernel
  have e9172 : Deny 5 11 b9172 :=
    branchAction rule_sound _ _ 1
      0x9 b9172 b9173 b9202 (by decide +kernel) e9173 e9202
  have e9160 : Deny 5 11 b9160 :=
    branchAction rule_sound _ _ 2
      0x223 b9160 b9161 b9172 (by decide +kernel) e9161 e9172
  have e9214 : Deny 5 11 b9214 := by
    apply closeAction rule_sound _ _ 64 [0x820c78c80e22830f72231c4]
    decide +kernel
  have e9225 : Deny 5 11 b9225 := by
    apply closeAction rule_sound _ _ 64 [0x3e370ef8c80e324388a0c3e37da32371e3]
    decide +kernel
  have e9213 : Deny 5 11 b9213 :=
    branchAction rule_sound _ _ 2
      0x2e3 b9213 b9214 b9225 (by decide +kernel) e9214 e9225
  have e9236 : Deny 5 11 b9236 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe311cbe3109e2f]
    decide +kernel
  have e9212 : Deny 5 11 b9212 :=
    branchAction rule_sound _ _ 2
      0x263 b9212 b9213 b9236 (by decide +kernel) e9213 e9236
  have e9241 : Deny 5 11 b9241 := by
    apply closeAction rule_sound _ _ 64 [0x2083888887dc4]
    decide +kernel
  have e9246 : Deny 5 11 b9246 := by
    apply closeAction rule_sound _ _ 64 [0x82bc32622370838c8e038c90e22a31e3]
    decide +kernel
  have e9240 : Deny 5 11 b9240 :=
    branchAction rule_sound _ _ 2
      0x2e3 b9240 b9241 b9246 (by decide +kernel) e9241 e9246
  have e9259 : Deny 5 11 b9259 := by
    apply closeAction rule_sound _ _ 64 [0xaf]
    decide +kernel
  have e9239 : Deny 5 11 b9239 :=
    branchAction rule_sound _ _ 1
      0x9 b9239 b9240 b9259 (by decide +kernel) e9240 e9259
  have e9211 : Deny 5 11 b9211 :=
    branchAction rule_sound _ _ 1
      0x8 b9211 b9212 b9239 (by decide +kernel) e9212 e9239
  have e9159 : Deny 5 11 b9159 :=
    branchAction rule_sound _ _ 3
      0x78c4 b9159 b9160 b9211 (by decide +kernel) e9160 e9211
  have e9109 : Deny 5 11 b9109 :=
    branchAction rule_sound _ _ 1
      0xb b9109 b9110 b9159 (by decide +kernel) e9110 e9159
  have e9105 : Deny 5 11 b9105 :=
    branchAction rule_sound _ _ 1
      0xa b9105 b9106 b9109 (by decide +kernel) e9106 e9109
  have e9025 : Deny 5 11 b9025 :=
    branchAction rule_sound _ _ 1
      0x9 b9025 b9026 b9105 (by decide +kernel) e9026 e9105
  have e8937 : Deny 5 11 b8937 :=
    branchAction rule_sound _ _ 3
      0x88c4 b8937 b8938 b9025 (by decide +kernel) e8938 e9025
  have e9261 : Deny 5 11 b9261 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdcbc4738df6be3109e36be32421ef088daf8c4087e37da3]
    decide +kernel
  have e9273 : Deny 5 11 b9273 := by
    apply closeAction rule_sound _ _ 64 [0xc3e37203e378c90f8df68c80f8df6d47e23087e23]
    decide +kernel
  have e9287 : Deny 5 11 b9287 := by
    apply closeAction rule_sound _ _ 64 [0xafb62]
    decide +kernel
  have e9289 : Deny 5 11 b9289 := by
    apply closeAction rule_sound _ _ 64 [0x72f8c4088e37da3]
    decide +kernel
  have e9292 : Deny 5 11 b9292 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdcbe326f703e3688a087da3102108e368c90f8df688a]
    decide +kernel
  have e9288 : Deny 5 11 b9288 :=
    branchAction rule_sound _ _ 2
      0x236 b9288 b9289 b9292 (by decide +kernel) e9289 e9292
  have e9286 : Deny 5 11 b9286 :=
    branchAction rule_sound _ _ 4
      0x2b8df6 b9286 b9287 b9288 (by decide +kernel) e9287 e9288
  have e9306 : Deny 5 11 b9306 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdc72f10bbe326f0c3e2322f0f88c9087e23242bedb222a3]
    decide +kernel
  have e9322 : Deny 5 11 b9322 := by
    apply closeAction rule_sound _ _ 64 [0x3e22]
    decide +kernel
  have e9325 : Deny 5 11 b9325 := by
    apply closeAction rule_sound _ _ 64 [0x2bc38c90838c41f8bc38c98c80ef0e3243e37da32231c4]
    decide +kernel
  have e9340 : Deny 5 11 b9340 := by
    apply closeAction rule_sound _ _ 64 [0x831f8bc38c90f80f81ef0e3263203102238df61e3]
    decide +kernel
  have e9324 : Deny 5 11 b9324 :=
    branchAction rule_sound _ _ 2
      0x2e3 b9324 b9325 b9340 (by decide +kernel) e9325 e9340
  have e9355 : Deny 5 11 b9355 := by
    apply closeAction rule_sound _ _ 64 [0x72f72f72f0f80f8be3223263278be326f]
    decide +kernel
  have e9323 : Deny 5 11 b9323 :=
    branchAction rule_sound _ _ 1
      0x9 b9323 b9324 b9355 (by decide +kernel) e9324 e9355
  have e9321 : Deny 5 11 b9321 :=
    branchAction rule_sound _ _ 1
      0xa b9321 b9322 b9323 (by decide +kernel) e9322 e9323
  have e9305 : Deny 5 11 b9305 :=
    branchAction rule_sound _ _ 1
      0x8 b9305 b9306 b9321 (by decide +kernel) e9306 e9321
  have e9285 : Deny 5 11 b9285 :=
    branchAction rule_sound _ _ 2
      0x1e3 b9285 b9286 b9305 (by decide +kernel) e9286 e9305
  have e9365 : Deny 5 11 b9365 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e9367 : Deny 5 11 b9367 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe372f8c9e37da3]
    decide +kernel
  have e9372 : Deny 5 11 b9372 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e9374 : Deny 5 11 b9374 := by
    apply closeAction rule_sound _ _ 64 [0xa2]
    decide +kernel
  have e9375 : Deny 5 11 b9375 := by
    apply closeAction rule_sound _ _ 64 [0xc21f8088e368c3e03e07bc38c90c21f8da320b]
    decide +kernel
  have e9373 : Deny 5 11 b9373 :=
    branchAction rule_sound _ _ 3
      0xae23 b9373 b9374 b9375 (by decide +kernel) e9374 e9375
  have e9371 : Deny 5 11 b9371 :=
    branchAction rule_sound _ _ 3
      0x7e23 b9371 b9372 b9373 (by decide +kernel) e9372 e9373
  have e9391 : Deny 5 11 b9391 := by
    apply closeAction rule_sound _ _ 64 [0x14]
    decide +kernel
  have e9393 : Deny 5 11 b9393 := by
    apply closeAction rule_sound _ _ 64 [0x14e22]
    decide +kernel
  have e9395 : Deny 5 11 b9395 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdcbdcbc30f8bc88c90878c9be3263]
    decide +kernel
  have e9407 : Deny 5 11 b9407 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e9409 : Deny 5 11 b9409 := by
    apply closeAction rule_sound _ _ 64 [0x72f8dcbe3278da3]
    decide +kernel
  have e9413 : Deny 5 11 b9413 := by
    apply closeAction rule_sound _ _ 64 [0x702be20af88be3688ae021e372f0c21e326f8cbe23]
    decide +kernel
  have e9427 : Deny 5 11 b9427 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e9429 : Deny 5 11 b9429 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e9431 : Deny 5 11 b9431 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e9433 : Deny 5 11 b9433 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e9434 : Deny 5 11 b9434 := by
    apply closeAction rule_sound _ _ 64 [0x209cbe32768c8bc20f620222326372f8cb8dcbe32e3]
    decide +kernel
  have e9432 : Deny 5 11 b9432 :=
    branchAction rule_sound _ _ 1
      0xb b9432 b9433 b9434 (by decide +kernel) e9433 e9434
  have e9430 : Deny 5 11 b9430 :=
    branchAction rule_sound _ _ 2
      0x1e3 b9430 b9431 b9432 (by decide +kernel) e9431 e9432
  have e9428 : Deny 5 11 b9428 :=
    branchAction rule_sound _ _ 2
      0x2e3 b9428 b9429 b9430 (by decide +kernel) e9429 e9430
  have e9426 : Deny 5 11 b9426 :=
    branchAction rule_sound _ _ 1
      0xb b9426 b9427 b9428 (by decide +kernel) e9427 e9428
  have e9412 : Deny 5 11 b9412 :=
    branchAction rule_sound _ _ 1
      0x9 b9412 b9413 b9426 (by decide +kernel) e9413 e9426
  have e9408 : Deny 5 11 b9408 :=
    branchAction rule_sound _ _ 1
      0x8 b9408 b9409 b9412 (by decide +kernel) e9409 e9412
  have e9406 : Deny 5 11 b9406 :=
    branchAction rule_sound _ _ 2
      0x1e3 b9406 b9407 b9408 (by decide +kernel) e9407 e9408
  have e9394 : Deny 5 11 b9394 :=
    branchAction rule_sound _ _ 1
      0xb b9394 b9395 b9406 (by decide +kernel) e9395 e9406
  have e9392 : Deny 5 11 b9392 :=
    branchAction rule_sound _ _ 1
      0xa b9392 b9393 b9394 (by decide +kernel) e9393 e9394
  have e9390 : Deny 5 11 b9390 :=
    branchAction rule_sound _ _ 1
      0xa b9390 b9391 b9392 (by decide +kernel) e9391 e9392
  have e9370 : Deny 5 11 b9370 :=
    branchAction rule_sound _ _ 1
      0x9 b9370 b9371 b9390 (by decide +kernel) e9371 e9390
  have e9366 : Deny 5 11 b9366 :=
    branchAction rule_sound _ _ 1
      0x8 b9366 b9367 b9370 (by decide +kernel) e9367 e9370
  have e9364 : Deny 5 11 b9364 :=
    branchAction rule_sound _ _ 2
      0x1e3 b9364 b9365 b9366 (by decide +kernel) e9365 e9366
  have e9284 : Deny 5 11 b9284 :=
    branchAction rule_sound _ _ 1
      0xb b9284 b9285 b9364 (by decide +kernel) e9285 e9364
  have e9272 : Deny 5 11 b9272 :=
    branchAction rule_sound _ _ 1
      0x9 b9272 b9273 b9284 (by decide +kernel) e9273 e9284
  have e9260 : Deny 5 11 b9260 :=
    branchAction rule_sound _ _ 2
      0x223 b9260 b9261 b9272 (by decide +kernel) e9261 e9272
  have e8936 : Deny 5 11 b8936 :=
    branchAction rule_sound _ _ 1
      0xb b8936 b8937 b9260 (by decide +kernel) e8937 e9260
  have e8862 : Deny 5 11 b8862 :=
    branchAction rule_sound _ _ 1
      0x7 b8862 b8863 b8936 (by decide +kernel) e8863 e8936
  have e8850 : Deny 5 11 b8850 :=
    branchAction rule_sound _ _ 3
      0x9da3 b8850 b8851 b8862 (by decide +kernel) e8851 e8862
  exact e8850
end OMA.Blocks5_11_245212.S8850
