import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S50096
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b50096 : Box := ![⟨127,152⟩,⟨23,24⟩,⟨31,41⟩,⟨1,53⟩,⟨1919,999999999999999999⟩]
private def b50097 : Box := ![⟨127,138⟩,⟨23,24⟩,⟨31,41⟩,⟨1,48⟩,⟨1919,999999999999999999⟩]
private def b50098 : Box := ![⟨127,138⟩,⟨23,23⟩,⟨32,41⟩,⟨1,46⟩,⟨1919,7216⟩]
private def b50099 : Box := ![⟨127,138⟩,⟨24,24⟩,⟨32,41⟩,⟨1,46⟩,⟨1919,7216⟩]
private def b50100 : Box := ![⟨127,138⟩,⟨24,24⟩,⟨32,35⟩,⟨1,41⟩,⟨1919,7198⟩]
private def b50101 : Box := ![⟨127,138⟩,⟨24,24⟩,⟨36,41⟩,⟨1,41⟩,⟨1919,7198⟩]
private def b50102 : Box := ![⟨139,152⟩,⟨23,24⟩,⟨31,41⟩,⟨1,48⟩,⟨1919,999999999999999999⟩]
private def b50103 : Box := ![⟨139,152⟩,⟨23,24⟩,⟨31,35⟩,⟨1,48⟩,⟨1919,999999999999999999⟩]
private def b50104 : Box := ![⟨139,152⟩,⟨23,23⟩,⟨31,35⟩,⟨1,46⟩,⟨1919,7156⟩]
private def b50105 : Box := ![⟨139,152⟩,⟨24,24⟩,⟨31,35⟩,⟨1,46⟩,⟨1919,7156⟩]
private def b50106 : Box := ![⟨139,152⟩,⟨23,24⟩,⟨36,41⟩,⟨1,48⟩,⟨1919,999999999999999999⟩]
private def b50107 : Box := ![⟨139,152⟩,⟨23,23⟩,⟨36,41⟩,⟨1,48⟩,⟨1919,999999999999999999⟩]
private def b50108 : Box := ![⟨139,152⟩,⟨24,24⟩,⟨36,41⟩,⟨1,48⟩,⟨1919,999999999999999999⟩]
private theorem e50098 : Deny 5 13 b50098 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e50100 : Deny 5 13 b50100 := by
    apply closeAction rule_sound _ _ 64 [0x778de3]
    decide +kernel
private theorem e50101 : Deny 5 13 b50101 := by
    apply closeAction rule_sound _ _ 64 [0xf8]
    decide +kernel
private theorem e50099 : Deny 5 13 b50099 :=
    branchAction rule_sound _ _ 3
      0x9e23 b50099 b50100 b50101 (by decide +kernel) e50100 e50101
private theorem e50097 : Deny 5 13 b50097 :=
    branchAction rule_sound _ _ 4
      0x238da3 b50097 b50098 b50099 (by decide +kernel) e50098 e50099
private theorem e50104 : Deny 5 13 b50104 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e50105 : Deny 5 13 b50105 := by
    apply closeAction rule_sound _ _ 64 [0xf89e3]
    decide +kernel
private theorem e50103 : Deny 5 13 b50103 :=
    branchAction rule_sound _ _ 3
      0x8e23 b50103 b50104 b50105 (by decide +kernel) e50104 e50105
private theorem e50107 : Deny 5 13 b50107 := by
    apply closeAction rule_sound _ _ 64 [0xf8]
    decide +kernel
private theorem e50108 : Deny 5 13 b50108 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e50106 : Deny 5 13 b50106 :=
    branchAction rule_sound _ _ 1
      0x8 b50106 b50107 b50108 (by decide +kernel) e50107 e50108
private theorem e50102 : Deny 5 13 b50102 :=
    branchAction rule_sound _ _ 1
      0x9 b50102 b50103 b50106 (by decide +kernel) e50103 e50106
private theorem e50096 : Deny 5 13 b50096 :=
    branchAction rule_sound _ _ 2
      0x1e3 b50096 b50097 b50102 (by decide +kernel) e50097 e50102
theorem deny5_13 : Deny 5 13 ![⟨127,152⟩,⟨23,24⟩,⟨31,41⟩,⟨1,53⟩,⟨1919,999999999999999999⟩] := by
  exact e50096
end OMA.Blocks5_13_245212.S50096
