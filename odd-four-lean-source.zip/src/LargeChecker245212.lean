import LargeExact245212

/-! A prefix-code tree for excluding large fourth primes. The split
locations are recomputed from the box, so just two bits describe each node. -/
namespace OMA.Large245212
open OMA.Smooth245212 OMA.Moving245212 Finset
open scoped ArithmeticFunction.sigma

def Deny (R q : ℕ) (b : B) := ∀ (e : Fin 3 → ℕ), (∀ i,(b i).Contains (e i)) →
  ∀ r d : ℕ, Nat.Prime r → 0<d → R≤r → (prev q e).Coprime r →
  prefProd X q e*X r (some d)+prefProd Y q e*Y r (some d)=2 →
  OeisA245212.a (prev q e*r^d)≠(σ 1 (prev q e*r^d):ℤ)

def leaf (R q : ℕ) (b : B) :=
  let L:=lows xl q b; let U:=lows xu q b; let G:=lows yl q b; let V:=lows yu q b;
  let c:=scale R; let lo:=lowerD L G; let hi:=upperD c U V; let e:=fun i => (b i).lo
  decide (2≤L ∨ (U+V/2)*c<2 ∨ 0<2-U*c ∧ (hi<lo ∨
    (∀ i,(b i).hi=some (b i).lo) ∧ ∀ t∈Icc lo hi,test R (full wt q e) (full sig q e) (full tax q e) t=true))

theorem leaf_sound {R q : ℕ} (R1 : 1<R) (hq : q=7 ∨ q=11 ∨ q=13) {b : B}
    (cert : leaf R q b=true) : Deny R q b := by
  intro e inside r d hp hd big cop score eq
  have hq1 : 1<q := by rcases hq with rfl|rfl|rfl <;> decide
  have w := window R1 big hq1 hd b e inside score
  rcases of_decide_eq_true cert with gt|lt|⟨pos,range|⟨single,all⟩⟩
  · exact w.xl.not_ge gt
  · exact w.coarse.not_gt lt
  · exact (w.low.trans (w.high pos)).not_gt range
  · have same : (fun i => (b i).lo)=e := funext fun i =>
      le_antisymm (inside i).1 ((inside i).2 _ (single i))
    have checked := all (d+1) (mem_Icc.mpr ⟨w.low,w.high pos⟩)
    rw [same,valid_exact hq e hp hd R big cop eq] at checked
    contradiction

def cutAt (a : Band) := match a.hi with
  | none => 2*a.lo+1
  | some h => max a.lo (min (h-1) (2*(a.lo+1)*(h+1)/(a.lo+h+2)-1))
def leftB (b : B) (i : Fin 3) : B := Function.update b i ⟨(b i).lo,some (cutAt (b i))⟩
def rightB (b : B) (i : Fin 3) : B := Function.update b i ⟨cutAt (b i)+1,(b i).hi⟩

theorem split {R q : ℕ} (b : B) (i : Fin 3) (l : Deny R q (leftB b i)) (r : Deny R q (rightB b i)) :
    Deny R q b := by
  intro e inside
  by_cases low : e i≤cutAt (b i)
  · apply l
    intro j; by_cases ji : j=i
    · subst j; simpa [leftB,Band.Contains] using And.intro (inside i).1 low
    · simpa [leftB,ji] using inside j
  · apply r
    intro j; by_cases ji : j=i
    · subst j; simpa [rightB,Band.Contains] using And.intro (by omega : cutAt (b i)+1≤e i) (inside i).2
    · simpa [rightB,ji] using inside j

def axis (word : ℕ) : Fin 3 := Fin.ofNat 3 (word%4-1)
def run (R q : ℕ) : ℕ → ℕ → B → Option ℕ
| 0,_,_ => none
| f+1,w,b =>
  if w%4=0 then if leaf R q b then some (w/4) else none
  else (run R q f (w/4) (leftB b (axis w))).bind (fun rest => run R q f rest (rightB b (axis w)))

theorem sound {R q : ℕ} (hR : 1<R) (hq : q=7 ∨ q=11 ∨ q=13) (f w : ℕ) {tail : ℕ} {b : B}
    (cert : run R q f w b=some tail) : Deny R q b := by
  induction f generalizing w tail b with
  | zero => simp [run] at cert
  | succ f ih =>
    by_cases tip : w%4=0
    · by_cases yes : leaf R q b=true
      · exact leaf_sound hR hq yes
      · simp [run,tip,yes] at cert
    · cases l : run R q f (w/4) (leftB b (axis w)) with
      | none => simp [run,tip,l] at cert
      | some rest =>
        exact split b (axis w) (ih _ l) (ih rest (by simpa [run,tip,l] using cert))

def start : B := fun _ => ⟨1,none⟩
end OMA.Large245212
