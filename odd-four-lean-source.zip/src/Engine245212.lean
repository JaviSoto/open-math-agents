import RoundedBox245212
import BoxPrefix245212
import PrimeWindow245212

/-! A trace of local exclusions and coordinate bisections. At every instruction,
a putative solution in the old stack must remain somewhere in the new one.
Five-bit instructions describe all split coordinates and rounding subsets.
The zero instruction pads the last word of a finite trace. -/
namespace OMA.Box245212
open Finset

def primeTrim (b : Box) : Option Box :=
  let R := b 4
  let live := (Icc R.lo R.hi).filter Nat.Prime
  if h : live.Nonempty then some (clip b 4 ⟨live.min' h,live.max' h⟩) else none

theorem primeTrim_sound {b : Box} {v : Values} {p q : ℕ} (fit : Fits b v) (c : Candidate p q v) :
    ∃ out,primeTrim b=some out ∧ Fits out v := by
  let live := (Icc (b 4).lo (b 4).hi).filter Nat.Prime
  have mem : v 4∈live := mem_filter.mpr ⟨mem_Icc.mpr (fit 4),c.prime 3⟩
  have ne : live.Nonempty := ⟨_,mem⟩
  exact ⟨_,dif_pos ne,clip_fits fit ⟨min'_le _ _ mem,le_max' _ _ mem⟩⟩

def digitTrim (p q : ℕ) (b : Box) : Option Box :=
  if ∀ i,1<(baseBox p q b i).lo then do
    let d ← DigitBox245212.digit p q b
    DigitBox245212.primeWindow p q b d
  else some b

theorem digitTrim_sound {b : Box} {v : Values} {p q : ℕ} (fit : Fits b v) (c : Candidate p q v) :
    ∃ out,digitTrim p q b=some out ∧ Fits out v := by
  unfold digitTrim
  split_ifs with start
  · obtain ⟨d,hd,hf⟩ := DigitBox245212.digit_sound c fit start
    obtain ⟨e,he,ef⟩ := DigitBox245212.primeWindow_sound c fit hf start
    exact ⟨e,by simpa [hd] using he,ef⟩
  · exact ⟨_,rfl,fit⟩

def cutPoint (r : Range) := max r.lo (min (r.hi-1) (2*(r.lo+1)*(r.hi+1)/(r.lo+r.hi+2)-1))
def leftBox (b : Box) (i : Fin 5) := clip b i ⟨(b i).lo,cutPoint (b i)⟩
def rightBox (b : Box) (i : Fin 5) := clip b i ⟨cutPoint (b i)+1,(b i).hi⟩
def selected (mask : ℕ) := (univ : Finset (Fin 4)).filter fun i=>mask.testBit i.val
def selectedTop (mask : ℕ) : Fin 4 := ⟨min 3 mask.log2,by omega⟩
def banned (p q : ℕ) (b : Box) (op : ℕ) : Bool :=
  if op=1 then decide (∃ i,(b i).hi<(b i).lo)
  else if op=2 then interval p q b
  else if op=3 then exactBlock p q b
  else roundLeaf p q b (selected (op-16)) (selectedTop (op-16))

theorem banned_sound {p q op : ℕ} {b : Box} (good : banned p q b op=true) : Deny p q b := by
  unfold banned at good
  split_ifs at good
  · obtain ⟨i,hi⟩ := of_decide_eq_true good
    exact fun v fit _ => (hi.not_ge ((fit i).1.trans (fit i).2))
  · exact interval_sound good
  · exact prefix_sound good
  · exact round_sound good

abbrev Stack := List Box
def solved (p q : ℕ) (s : Stack) := ∀ b∈s,Deny p q b
def put (out : Option Box) (rest : Stack) : Stack := match out with
  | none => rest
  | some b => b::rest

private theorem put_sound {p q : ℕ} {b : Box} {rest : Stack} {out : Option Box}
    (act : ∀ v,Fits b v → Candidate p q v → ∃ w,out=some w ∧ Fits w v)
    (yes : solved p q (put out rest)) : solved p q (b::rest) := by
  intro w hw
  rcases List.mem_cons.mp hw with rfl|hr
  · intro v fit c
    obtain ⟨w,hw,hf⟩ := act v fit c
    rw [hw] at yes
    exact yes w List.mem_cons_self v hf c
  · cases out with
    | none => exact yes _ hr
    | some d => exact yes _ (List.mem_cons_of_mem _ hr)

/-- `none` records an invalid trace. A successful pruning operation whose
box is empty pops that box and preserves the rest of the stack. -/
def advance (shrink : ℕ→ℕ→Box→Box) (p q op : ℕ) (s : Stack) : Option Stack :=
  if op=0 then some s else match s with
  | [] => none
  | b::rest =>
    if op=4 then some (put (primeTrim b) rest)
    else if op=5 then some (shrink p q b::rest)
    else if op=6 then some (put (digitTrim p q b) rest)
    else if h : 7≤op ∧ op<12 then
      let i : Fin 5 := ⟨op-7,by omega⟩
      some (leftBox b i::rightBox b i::rest)
    else if banned p q b op then some rest else none

theorem advance_sound (shrink : ℕ→ℕ→Box→Box)
    (valid : ∀ p q b v,Fits b v → Candidate p q v → Fits (shrink p q b) v)
    {p q op : ℕ} {s t : Stack} (check : advance shrink p q op s=some t)
    (yes : solved p q t) : solved p q s := by
  by_cases z : op=0
  · exact (Option.some.inj (by simpa [advance,z] using check)) ▸ yes
  cases s with
  | nil => simp [advance,z] at check
  | cons b rest =>
    simp only [advance,if_neg z] at check
    split_ifs at check with h4 h5 h6 hi ok
    · cases Option.some.inj check
      exact put_sound (fun _ f c=>primeTrim_sound f c) yes
    · cases Option.some.inj check
      exact put_sound (out:=some (shrink p q b)) (fun v f c=>⟨_,rfl,valid _ _ _ v f c⟩) yes
    · cases Option.some.inj check
      exact put_sound (fun _ f c=>digitTrim_sound f c) yes
    · cases Option.some.inj check
      intro w hw
      rcases List.mem_cons.mp hw with rfl|hr
      · exact split p q _ _ _ (yes _ List.mem_cons_self) (yes _ (List.mem_cons_of_mem _ List.mem_cons_self))
      · exact yes _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ hr))
    · cases Option.some.inj check
      exact fun w hw=> (List.mem_cons.mp hw).elim (fun h=>h ▸ banned_sound ok) (yes w)

/-- A word holds a fixed number of five-bit instructions, low bits first. -/
def runWord (shrink : ℕ→ℕ→Box→Box) (p q : ℕ) : ℕ→ℕ→Stack→Option Stack
  | 0,_,s => some s
  | fuel+1,w,s => (advance shrink p q (w%32) s).bind (runWord shrink p q fuel (w/32) ·)

theorem runWord_sound (shrink : ℕ→ℕ→Box→Box)
    (valid : ∀ p q b v,Fits b v → Candidate p q v → Fits (shrink p q b) v)
    (p q fuel w : ℕ) (s t : Stack) (check : runWord shrink p q fuel w s=some t)
    (yes : solved p q t) : solved p q s := by
  induction fuel generalizing w s with
  | zero => cases Option.some.inj check; exact yes
  | succ f ih =>
    cases h : advance shrink p q (w%32) s with
    | none => simp [runWord,h] at check
    | some y => exact advance_sound shrink valid h (ih (w/32) y (by simpa [runWord,h] using check))

def runTrace (shrink : ℕ→ℕ→Box→Box) (p q : ℕ) : List ℕ→Stack→Option Stack
  | [],s => some s
  | w::ws,s => (runWord shrink p q 64 w s).bind (runTrace shrink p q ws ·)

theorem trace_sound (shrink : ℕ→ℕ→Box→Box)
    (valid : ∀ p q b v,Fits b v → Candidate p q v → Fits (shrink p q b) v)
    (p q : ℕ) (ws : List ℕ) (b : Box) (check : runTrace shrink p q ws [b]=some []) : Deny p q b := by
  have backward (words : List ℕ) (s t : Stack) (h : runTrace shrink p q words s=some t) (yes : solved p q t) : solved p q s := by
    induction words generalizing s with
    | nil => cases Option.some.inj h; exact yes
    | cons w ws ih =>
      cases one : runWord shrink p q 64 w s with
      | none => simp [runTrace,one] at h
      | some y => exact runWord_sound shrink valid p q _ w s y one (ih y (by simpa [runTrace,one] using h))
  exact backward ws [b] [] check (by simp [solved]) b List.mem_cons_self

end OMA.Box245212
