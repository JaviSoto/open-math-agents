import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S50501
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b50501 : Box := ![⟨95,126⟩,⟨23,24⟩,⟨63,126⟩,⟨1,718295185477505923790⟩,⟨959,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,126⟩,⟨23,24⟩,⟨63,126⟩,⟨1,718295185477505923790⟩,⟨959,999999999999999999⟩] := by
  have e50501 : Deny 5 13 b50501 := by
    apply closeAction rule_sound _ _ 64 [0x8c22388c7bc3e03e232780f8df68c754ae23088e2326375f743e03e221dfe0954a7f8da21e22a22222952952a32e31e3,0x2b854a2152a32c3e031ef0c3e231e325dbe376f8cbe37d888ddbdd0f80f8203be21ca8c9be32ddbdd0f8be22b88c9e2f,0x54a2232c30e3243e37d888dd578dc32780c3e0920a54a54a8cb8c78c98d5e3775d55de03e03e0727854ae152a21e22a2,0xf81c3e2f8c3e37daf8c7e23254e222888c276f0f80ef1e3248be32e31c20f88c9e030f81c3e2326322309d75528a54a,0x82083e232788c7e2f0f80c78c98dd54ae2f8cbe232380820f88c7e232780f8]
    decide +kernel
  exact e50501
end OMA.Blocks5_13_245212.S50501
