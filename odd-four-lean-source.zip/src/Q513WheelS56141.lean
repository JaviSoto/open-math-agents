import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S56141
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b56141 : Box := ![⟨76,94⟩,⟨63,126⟩,⟨10,14⟩,⟨1,64⟩,⟨479,999999999999999999⟩]
private def b56142 : Box := ![⟨76,94⟩,⟨63,126⟩,⟨10,14⟩,⟨1,64⟩,⟨479,958⟩]
private def b56143 : Box := ![⟨76,94⟩,⟨63,126⟩,⟨10,14⟩,⟨1,2⟩,⟨479,958⟩]
private def b56144 : Box := ![⟨76,94⟩,⟨63,126⟩,⟨10,14⟩,⟨3,58⟩,⟨479,958⟩]
private def b56145 : Box := ![⟨76,94⟩,⟨63,126⟩,⟨10,11⟩,⟨3,58⟩,⟨479,958⟩]
private def b56146 : Box := ![⟨76,94⟩,⟨63,84⟩,⟨10,11⟩,⟨3,57⟩,⟨479,958⟩]
private def b56147 : Box := ![⟨76,84⟩,⟨63,84⟩,⟨10,11⟩,⟨3,46⟩,⟨479,958⟩]
private def b56148 : Box := ![⟨76,84⟩,⟨63,84⟩,⟨10,11⟩,⟨3,44⟩,⟨479,638⟩]
private def b56149 : Box := ![⟨76,84⟩,⟨63,84⟩,⟨10,11⟩,⟨3,6⟩,⟨479,638⟩]
private def b56150 : Box := ![⟨76,84⟩,⟨63,84⟩,⟨10,11⟩,⟨7,44⟩,⟨479,638⟩]
private def b56151 : Box := ![⟨76,84⟩,⟨63,84⟩,⟨10,11⟩,⟨7,12⟩,⟨479,638⟩]
private def b56162 : Box := ![⟨76,84⟩,⟨63,84⟩,⟨10,11⟩,⟨13,44⟩,⟨479,638⟩]
private def b56163 : Box := ![⟨76,84⟩,⟨63,84⟩,⟨10,11⟩,⟨3,44⟩,⟨639,958⟩]
private def b56172 : Box := ![⟨85,94⟩,⟨63,84⟩,⟨10,11⟩,⟨3,46⟩,⟨479,958⟩]
private def b56173 : Box := ![⟨85,94⟩,⟨63,84⟩,⟨10,11⟩,⟨3,6⟩,⟨479,958⟩]
private def b56174 : Box := ![⟨85,94⟩,⟨63,84⟩,⟨10,11⟩,⟨7,46⟩,⟨479,958⟩]
private def b56175 : Box := ![⟨85,94⟩,⟨63,84⟩,⟨10,11⟩,⟨7,12⟩,⟨479,958⟩]
private def b56176 : Box := ![⟨85,94⟩,⟨63,84⟩,⟨10,11⟩,⟨7,8⟩,⟨479,958⟩]
private def b56177 : Box := ![⟨85,94⟩,⟨63,84⟩,⟨10,11⟩,⟨7,7⟩,⟨479,958⟩]
private def b56178 : Box := ![⟨85,94⟩,⟨63,84⟩,⟨10,11⟩,⟨8,8⟩,⟨479,958⟩]
private def b56189 : Box := ![⟨85,94⟩,⟨63,84⟩,⟨10,11⟩,⟨9,12⟩,⟨479,958⟩]
private def b56190 : Box := ![⟨85,94⟩,⟨63,84⟩,⟨10,11⟩,⟨13,46⟩,⟨479,958⟩]
private def b56191 : Box := ![⟨76,94⟩,⟨85,126⟩,⟨10,11⟩,⟨3,57⟩,⟨479,958⟩]
private def b56192 : Box := ![⟨76,84⟩,⟨85,126⟩,⟨10,11⟩,⟨3,57⟩,⟨492,958⟩]
private def b56193 : Box := ![⟨76,84⟩,⟨85,126⟩,⟨10,10⟩,⟨3,55⟩,⟨492,958⟩]
private def b56194 : Box := ![⟨76,84⟩,⟨85,126⟩,⟨10,10⟩,⟨3,6⟩,⟨492,958⟩]
private def b56195 : Box := ![⟨76,84⟩,⟨85,126⟩,⟨10,10⟩,⟨7,54⟩,⟨492,958⟩]
private def b56206 : Box := ![⟨76,84⟩,⟨85,126⟩,⟨11,11⟩,⟨3,55⟩,⟨492,958⟩]
private def b56207 : Box := ![⟨85,94⟩,⟨85,126⟩,⟨10,11⟩,⟨3,57⟩,⟨492,958⟩]
private def b56208 : Box := ![⟨76,94⟩,⟨63,126⟩,⟨12,14⟩,⟨3,58⟩,⟨479,958⟩]
private def b56219 : Box := ![⟨76,94⟩,⟨63,126⟩,⟨10,14⟩,⟨1,64⟩,⟨959,999999999999999999⟩]
private def b56220 : Box := ![⟨76,94⟩,⟨63,126⟩,⟨10,11⟩,⟨1,57⟩,⟨959,999999999999999999⟩]
private def b56221 : Box := ![⟨76,94⟩,⟨63,84⟩,⟨10,11⟩,⟨1,56⟩,⟨959,999999999999999999⟩]
private def b56222 : Box := ![⟨76,84⟩,⟨63,84⟩,⟨10,11⟩,⟨1,46⟩,⟨959,999999999999999999⟩]
private def b56231 : Box := ![⟨85,94⟩,⟨63,84⟩,⟨10,11⟩,⟨1,46⟩,⟨959,999999999999999999⟩]
private def b56232 : Box := ![⟨85,94⟩,⟨63,84⟩,⟨10,11⟩,⟨1,46⟩,⟨959,1918⟩]
private def b56233 : Box := ![⟨85,94⟩,⟨63,84⟩,⟨10,11⟩,⟨1,2⟩,⟨959,1918⟩]
private def b56234 : Box := ![⟨85,94⟩,⟨63,84⟩,⟨10,11⟩,⟨3,41⟩,⟨959,1918⟩]
private def b56235 : Box := ![⟨85,94⟩,⟨63,84⟩,⟨10,11⟩,⟨3,6⟩,⟨959,1918⟩]
private def b56236 : Box := ![⟨85,94⟩,⟨63,84⟩,⟨10,11⟩,⟨7,41⟩,⟨959,1918⟩]
private def b56237 : Box := ![⟨85,94⟩,⟨63,84⟩,⟨10,11⟩,⟨7,12⟩,⟨959,1918⟩]
private def b56248 : Box := ![⟨85,94⟩,⟨63,84⟩,⟨10,11⟩,⟨13,41⟩,⟨959,1918⟩]
private def b56249 : Box := ![⟨85,94⟩,⟨63,84⟩,⟨10,11⟩,⟨1,46⟩,⟨1919,999999999999999999⟩]
private def b56260 : Box := ![⟨76,94⟩,⟨85,126⟩,⟨10,11⟩,⟨1,56⟩,⟨959,999999999999999999⟩]
private def b56261 : Box := ![⟨76,84⟩,⟨85,126⟩,⟨10,11⟩,⟨1,56⟩,⟨959,999999999999999999⟩]
private def b56262 : Box := ![⟨76,84⟩,⟨85,126⟩,⟨10,11⟩,⟨1,54⟩,⟨959,1918⟩]
private def b56263 : Box := ![⟨76,84⟩,⟨85,126⟩,⟨10,11⟩,⟨1,2⟩,⟨959,1918⟩]
private def b56264 : Box := ![⟨76,84⟩,⟨85,126⟩,⟨10,11⟩,⟨3,50⟩,⟨959,1918⟩]
private def b56265 : Box := ![⟨76,84⟩,⟨85,101⟩,⟨10,11⟩,⟨3,50⟩,⟨959,1918⟩]
private def b56272 : Box := ![⟨76,84⟩,⟨102,126⟩,⟨10,11⟩,⟨3,50⟩,⟨959,1918⟩]
private def b56279 : Box := ![⟨76,84⟩,⟨85,126⟩,⟨10,11⟩,⟨1,54⟩,⟨1919,999999999999999999⟩]
private def b56280 : Box := ![⟨76,84⟩,⟨85,101⟩,⟨10,11⟩,⟨1,49⟩,⟨1919,999999999999999999⟩]
private def b56285 : Box := ![⟨76,84⟩,⟨102,126⟩,⟨10,11⟩,⟨1,49⟩,⟨1919,999999999999999999⟩]
private def b56296 : Box := ![⟨85,94⟩,⟨85,126⟩,⟨10,11⟩,⟨1,56⟩,⟨959,999999999999999999⟩]
private def b56297 : Box := ![⟨85,94⟩,⟨85,126⟩,⟨10,11⟩,⟨1,56⟩,⟨959,1918⟩]
private def b56304 : Box := ![⟨85,94⟩,⟨85,126⟩,⟨10,11⟩,⟨1,56⟩,⟨1919,999999999999999999⟩]
private def b56305 : Box := ![⟨85,94⟩,⟨85,101⟩,⟨10,11⟩,⟨1,51⟩,⟨1919,999999999999999999⟩]
private def b56312 : Box := ![⟨85,94⟩,⟨102,126⟩,⟨10,11⟩,⟨1,51⟩,⟨1919,999999999999999999⟩]
private def b56321 : Box := ![⟨76,94⟩,⟨63,126⟩,⟨12,14⟩,⟨1,57⟩,⟨959,999999999999999999⟩]
private def b56322 : Box := ![⟨76,94⟩,⟨63,84⟩,⟨12,14⟩,⟨1,57⟩,⟨959,999999999999999999⟩]
private def b56323 : Box := ![⟨76,84⟩,⟨63,84⟩,⟨12,14⟩,⟨1,47⟩,⟨959,999999999999999999⟩]
private def b56324 : Box := ![⟨76,84⟩,⟨63,84⟩,⟨12,14⟩,⟨1,46⟩,⟨959,1918⟩]
private def b56325 : Box := ![⟨76,84⟩,⟨63,84⟩,⟨12,14⟩,⟨1,2⟩,⟨959,1918⟩]
private def b56326 : Box := ![⟨76,84⟩,⟨63,84⟩,⟨12,14⟩,⟨3,41⟩,⟨959,1918⟩]
private def b56337 : Box := ![⟨76,84⟩,⟨63,84⟩,⟨12,14⟩,⟨1,46⟩,⟨1919,999999999999999999⟩]
private def b56338 : Box := ![⟨76,84⟩,⟨63,72⟩,⟨12,14⟩,⟨1,41⟩,⟨1919,999999999999999999⟩]
private def b56343 : Box := ![⟨76,84⟩,⟨73,84⟩,⟨12,14⟩,⟨1,41⟩,⟨1919,999999999999999999⟩]
private def b56352 : Box := ![⟨85,94⟩,⟨63,84⟩,⟨12,14⟩,⟨1,47⟩,⟨959,999999999999999999⟩]
private def b56353 : Box := ![⟨85,94⟩,⟨63,84⟩,⟨12,14⟩,⟨1,47⟩,⟨959,1918⟩]
private def b56358 : Box := ![⟨85,94⟩,⟨63,84⟩,⟨12,14⟩,⟨1,47⟩,⟨1919,999999999999999999⟩]
private def b56369 : Box := ![⟨76,94⟩,⟨85,126⟩,⟨12,14⟩,⟨1,57⟩,⟨959,999999999999999999⟩]
private theorem e56143 : Deny 5 13 b56143 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
private theorem e56149 : Deny 5 13 b56149 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
private theorem e56151 : Deny 5 13 b56151 := by
    apply closeAction rule_sound _ _ 64 [0x1b083e031c90c3e0920a]
    decide +kernel
private theorem e56162 : Deny 5 13 b56162 := by
    apply closeAction rule_sound _ _ 64 [0x1b]
    decide +kernel
private theorem e56150 : Deny 5 13 b56150 :=
    branchAction rule_sound _ _ 1
      0xa b56150 b56151 b56162 (by decide +kernel) e56151 e56162
private theorem e56148 : Deny 5 13 b56148 :=
    branchAction rule_sound _ _ 1
      0xa b56148 b56149 b56150 (by decide +kernel) e56149 e56150
private theorem e56163 : Deny 5 13 b56163 := by
    apply closeAction rule_sound _ _ 64 [0x3e032438c70dbe37263223]
    decide +kernel
private theorem e56147 : Deny 5 13 b56147 :=
    branchAction rule_sound _ _ 2
      0x2e3 b56147 b56148 b56163 (by decide +kernel) e56148 e56163
private theorem e56173 : Deny 5 13 b56173 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
private theorem e56177 : Deny 5 13 b56177 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
private theorem e56178 : Deny 5 13 b56178 := by
    apply closeAction rule_sound _ _ 64 [0x20c8e1b2420832482f8]
    decide +kernel
private theorem e56176 : Deny 5 13 b56176 :=
    branchAction rule_sound _ _ 1
      0xa b56176 b56177 b56178 (by decide +kernel) e56177 e56178
private theorem e56189 : Deny 5 13 b56189 := by
    apply closeAction rule_sound _ _ 64 [0x1b]
    decide +kernel
private theorem e56175 : Deny 5 13 b56175 :=
    branchAction rule_sound _ _ 1
      0xa b56175 b56176 b56189 (by decide +kernel) e56176 e56189
private theorem e56190 : Deny 5 13 b56190 := by
    apply closeAction rule_sound _ _ 64 [0x1b]
    decide +kernel
private theorem e56174 : Deny 5 13 b56174 :=
    branchAction rule_sound _ _ 1
      0xa b56174 b56175 b56190 (by decide +kernel) e56175 e56190
private theorem e56172 : Deny 5 13 b56172 :=
    branchAction rule_sound _ _ 1
      0xa b56172 b56173 b56174 (by decide +kernel) e56173 e56174
private theorem e56146 : Deny 5 13 b56146 :=
    branchAction rule_sound _ _ 2
      0x1e3 b56146 b56147 b56172 (by decide +kernel) e56147 e56172
private theorem e56194 : Deny 5 13 b56194 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
private theorem e56195 : Deny 5 13 b56195 := by
    apply closeAction rule_sound _ _ 64 [0x6db083847e03e031c884a2b8]
    decide +kernel
private theorem e56193 : Deny 5 13 b56193 :=
    branchAction rule_sound _ _ 2
      0x2a3 b56193 b56194 b56195 (by decide +kernel) e56194 e56195
private theorem e56206 : Deny 5 13 b56206 := by
    apply closeAction rule_sound _ _ 64 [0x13e37]
    decide +kernel
private theorem e56192 : Deny 5 13 b56192 :=
    branchAction rule_sound _ _ 2
      0x263 b56192 b56193 b56206 (by decide +kernel) e56193 e56206
private theorem e56207 : Deny 5 13 b56207 := by
    apply closeAction rule_sound _ _ 64 [0x13e37]
    decide +kernel
private theorem e56191 : Deny 5 13 b56191 :=
    branchAction rule_sound _ _ 2
      0x1f8 b56191 b56192 b56207 (by decide +kernel) e56192 e56207
private theorem e56145 : Deny 5 13 b56145 :=
    branchAction rule_sound _ _ 2
      0x223 b56145 b56146 b56191 (by decide +kernel) e56146 e56191
private theorem e56208 : Deny 5 13 b56208 := by
    apply closeAction rule_sound _ _ 64 [0x824f8dc20c41f8dc38c9e232231e3238]
    decide +kernel
private theorem e56144 : Deny 5 13 b56144 :=
    branchAction rule_sound _ _ 1
      0x9 b56144 b56145 b56208 (by decide +kernel) e56145 e56208
private theorem e56142 : Deny 5 13 b56142 :=
    branchAction rule_sound _ _ 2
      0x2a3 b56142 b56143 b56144 (by decide +kernel) e56143 e56144
private theorem e56222 : Deny 5 13 b56222 := by
    apply closeAction rule_sound _ _ 64 [0xc3e231c3e378c84cae236f8df58c9e23]
    decide +kernel
private theorem e56233 : Deny 5 13 b56233 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
private theorem e56235 : Deny 5 13 b56235 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
private theorem e56237 : Deny 5 13 b56237 := by
    apply closeAction rule_sound _ _ 64 [0x6db4c3e03e084f824728a]
    decide +kernel
private theorem e56248 : Deny 5 13 b56248 := by
    apply closeAction rule_sound _ _ 64 [0x1b]
    decide +kernel
private theorem e56236 : Deny 5 13 b56236 :=
    branchAction rule_sound _ _ 1
      0xa b56236 b56237 b56248 (by decide +kernel) e56237 e56248
private theorem e56234 : Deny 5 13 b56234 :=
    branchAction rule_sound _ _ 1
      0xa b56234 b56235 b56236 (by decide +kernel) e56235 e56236
private theorem e56232 : Deny 5 13 b56232 :=
    branchAction rule_sound _ _ 2
      0x2a3 b56232 b56233 b56234 (by decide +kernel) e56233 e56234
private theorem e56249 : Deny 5 13 b56249 := by
    apply closeAction rule_sound _ _ 64 [0x30e31c3e23087e37243e23089e23223]
    decide +kernel
private theorem e56231 : Deny 5 13 b56231 :=
    branchAction rule_sound _ _ 1
      0xb b56231 b56232 b56249 (by decide +kernel) e56232 e56249
private theorem e56221 : Deny 5 13 b56221 :=
    branchAction rule_sound _ _ 2
      0x1e3 b56221 b56222 b56231 (by decide +kernel) e56222 e56231
private theorem e56263 : Deny 5 13 b56263 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
private theorem e56265 : Deny 5 13 b56265 := by
    apply closeAction rule_sound _ _ 64 [0xf80e31c30f8de31e3263]
    decide +kernel
private theorem e56272 : Deny 5 13 b56272 := by
    apply closeAction rule_sound _ _ 64 [0x26c3e2b0c884aae326b]
    decide +kernel
private theorem e56264 : Deny 5 13 b56264 :=
    branchAction rule_sound _ _ 1
      0x8 b56264 b56265 b56272 (by decide +kernel) e56265 e56272
private theorem e56262 : Deny 5 13 b56262 :=
    branchAction rule_sound _ _ 2
      0x2a3 b56262 b56263 b56264 (by decide +kernel) e56263 e56264
private theorem e56280 : Deny 5 13 b56280 := by
    apply closeAction rule_sound _ _ 64 [0xc3e231dbe37263]
    decide +kernel
private theorem e56285 : Deny 5 13 b56285 := by
    apply closeAction rule_sound _ _ 64 [0x83e232380c70eb0f88c80f8de31c9]
    decide +kernel
private theorem e56279 : Deny 5 13 b56279 :=
    branchAction rule_sound _ _ 2
      0x223 b56279 b56280 b56285 (by decide +kernel) e56280 e56285
private theorem e56261 : Deny 5 13 b56261 :=
    branchAction rule_sound _ _ 2
      0x2e3 b56261 b56262 b56279 (by decide +kernel) e56262 e56279
private theorem e56297 : Deny 5 13 b56297 := by
    apply closeAction rule_sound _ _ 64 [0xab083e038c7263223]
    decide +kernel
private theorem e56305 : Deny 5 13 b56305 := by
    apply closeAction rule_sound _ _ 64 [0x83e231f80c3e231e3263]
    decide +kernel
private theorem e56312 : Deny 5 13 b56312 := by
    apply closeAction rule_sound _ _ 64 [0x820f88c8e03e2b0e32231c9]
    decide +kernel
private theorem e56304 : Deny 5 13 b56304 :=
    branchAction rule_sound _ _ 2
      0x223 b56304 b56305 b56312 (by decide +kernel) e56305 e56312
private theorem e56296 : Deny 5 13 b56296 :=
    branchAction rule_sound _ _ 1
      0xb b56296 b56297 b56304 (by decide +kernel) e56297 e56304
private theorem e56260 : Deny 5 13 b56260 :=
    branchAction rule_sound _ _ 1
      0x7 b56260 b56261 b56296 (by decide +kernel) e56261 e56296
private theorem e56220 : Deny 5 13 b56220 :=
    branchAction rule_sound _ _ 2
      0x223 b56220 b56221 b56260 (by decide +kernel) e56221 e56260
private theorem e56325 : Deny 5 13 b56325 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
private theorem e56326 : Deny 5 13 b56326 := by
    apply closeAction rule_sound _ _ 64 [0x20f8dc38c78c90f80e31c38c98c8]
    decide +kernel
private theorem e56324 : Deny 5 13 b56324 :=
    branchAction rule_sound _ _ 2
      0x2a3 b56324 b56325 b56326 (by decide +kernel) e56325 e56326
private theorem e56338 : Deny 5 13 b56338 := by
    apply closeAction rule_sound _ _ 64 [0x30e31c3e23263]
    decide +kernel
private theorem e56343 : Deny 5 13 b56343 := by
    apply closeAction rule_sound _ _ 64 [0x20f80e31c90c3e231c9]
    decide +kernel
private theorem e56337 : Deny 5 13 b56337 :=
    branchAction rule_sound _ _ 2
      0x223 b56337 b56338 b56343 (by decide +kernel) e56338 e56343
private theorem e56323 : Deny 5 13 b56323 :=
    branchAction rule_sound _ _ 2
      0x2e3 b56323 b56324 b56337 (by decide +kernel) e56324 e56337
private theorem e56353 : Deny 5 13 b56353 := by
    apply closeAction rule_sound _ _ 64 [0x820e3263223]
    decide +kernel
private theorem e56358 : Deny 5 13 b56358 := by
    apply closeAction rule_sound _ _ 64 [0x2083e231f88c9e020f88c7e03263223]
    decide +kernel
private theorem e56352 : Deny 5 13 b56352 :=
    branchAction rule_sound _ _ 1
      0xb b56352 b56353 b56358 (by decide +kernel) e56353 e56358
private theorem e56322 : Deny 5 13 b56322 :=
    branchAction rule_sound _ _ 2
      0x1e3 b56322 b56323 b56352 (by decide +kernel) e56323 e56352
private theorem e56369 : Deny 5 13 b56369 := by
    apply closeAction rule_sound _ _ 64 [0x20820f80f88c7e232788c8e231f8]
    decide +kernel
private theorem e56321 : Deny 5 13 b56321 :=
    branchAction rule_sound _ _ 1
      0x8 b56321 b56322 b56369 (by decide +kernel) e56322 e56369
private theorem e56219 : Deny 5 13 b56219 :=
    branchAction rule_sound _ _ 2
      0x263 b56219 b56220 b56321 (by decide +kernel) e56220 e56321
private theorem e56141 : Deny 5 13 b56141 :=
    branchAction rule_sound _ _ 1
      0xb b56141 b56142 b56219 (by decide +kernel) e56142 e56219
theorem deny5_13 : Deny 5 13 ![⟨76,94⟩,⟨63,126⟩,⟨10,14⟩,⟨1,64⟩,⟨479,999999999999999999⟩] := by
  exact e56141
end OMA.Blocks5_13_245212.S56141
