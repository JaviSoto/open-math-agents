import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S52607
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b52607 : Box := ![⟨47,62⟩,⟨31,62⟩,⟨7,14⟩,⟨1,52⟩,⟨127,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,62⟩,⟨31,62⟩,⟨7,14⟩,⟨1,52⟩,⟨127,233⟩] := by
  have e52607 : Deny 5 13 b52607 := by
    apply closeAction rule_sound _ _ 64 [0x8c7de311b0f80c90c70c3e07203102238df524a4ca0c3e378c86f8df52422778c710b1030891021f8df68c4238de3263,0xc40f8df5109e3724a0c3e378c80f8de31c3102238de32778c710bde32030f8de31c3e378c86f8df58c9dc225be37db5,0x1c42d74d3087e37d47e092830f8de3243e378c90c4089e378c97c2278df68c78c40c38c90e32430f82632430c90c95ca,0x107e370c9108e370f8dc40c4238dc38c70c38c78c88c90f8dc31f8dc38c90c38c80e31e32030e31c30f8de31e3223263,0x8c88c90c38c70f88c90c3e378c80f8de31f88c80c3e378c71031021f8de3108e378c98c78c40820c9107e37103e37103,0xf8dc40c4238dc38c90c38c98c78c4083109e370f8dc3247dc42c30e31c38c98c80c38c80e31c3103e378c41f8]
    decide +kernel
  exact e52607
end OMA.Blocks5_13_245212.S52607
