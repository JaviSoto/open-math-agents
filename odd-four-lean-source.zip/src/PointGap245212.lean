import HeightGap245212

/-! A local, pointwise denominator test sufficient to force the mixed rounded
score of a four-prime solution to equal two exactly. -/
namespace OMA.Height245212
open Finset OMA.Smooth245212
noncomputable section

theorem point_gap (p e : Fin 4 → ℕ) (prime : ∀ i,(p i).Prime) (pos : ∀ i,0<e i)
    (s : Finset (Fin 4)) (sol : normalized p e=2)
    (small : ∀ i∈s,4*(8+(p i-1))*(∏ j∈univ.erase i,localDen p e s j)<p i^e i) :
    scoreM p e s=2 := by
  apply gap_eq p e prime pos s sol
  by_cases empty : s=∅
  · simp [empty]
  have one (i) (hi : i∈s) : err (p i) (e i)*(8+((p i:ℚ)-1))*commonDen p e s<1/4 := by
    have hd : (0:ℚ)<den (p i) (e i) := by exact_mod_cast den_pos (prime i).one_lt _
    have pp : (0:ℚ)<(p i:ℚ)^e i := by exact_mod_cast pow_pos (prime i).pos (e i)
    have h : (4:ℚ)*(8+((p i:ℚ)-1))*(∏ j∈univ.erase i,(localDen p e s j:ℚ))<(p i:ℚ)^e i := by
      have t : (4:ℚ)*(8+((p i-1:ℕ):ℚ))*(∏ j∈univ.erase i,(localDen p e s j:ℚ))<(p i:ℚ)^e i := by
        exact_mod_cast small i hi
      simpa only [Nat.cast_sub (prime i).pos,Nat.cast_one] using t
    have common : (commonDen p e s:ℚ)=
        (∏ j∈univ.erase i,(localDen p e s j:ℚ))*den (p i) (e i) := by
      unfold commonDen
      rw [Nat.cast_prod,←prod_erase_mul ((univ):Finset (Fin 4)) (fun j => (localDen p e s j:ℚ)) (mem_univ i)]
      simp [localDen,hi]
    rw [common,err]
    field_simp [hd.ne',pp.ne']
    nlinarith only [mul_pos hd (sub_pos.mpr h)]
  rw [sum_mul]
  have sum := sum_lt_sum_of_nonempty (Finset.nonempty_iff_ne_empty.mpr empty) one
  have card : s.card≤4 := (card_le_univ s).trans_eq (by simp)
  have cq : (s.card:ℚ)≤4 := by exact_mod_cast card
  simp only [sum_const,nsmul_eq_mul] at sum
  linarith

end
end OMA.Height245212
