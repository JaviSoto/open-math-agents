import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S42182
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b42182 : Box := ![⟨63,75⟩,⟨25,30⟩,⟨31,62⟩,⟨1,59⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,75⟩,⟨25,30⟩,⟨31,62⟩,⟨1,59⟩,⟨479,999999999999999999⟩] := by
  have e42182 : Deny 5 13 b42182 := by
    apply closeAction rule_sound _ _ 64 [0x2420c41f80c85c320910b5d7e362022381d75f8d88088087e095ca28be030f8dc97f8df61c22021f8d88e0ae235cae23,0x7df0c3e361f80f8d875cae362b87f8df62021f8d9f5c3203e085c3e08088]
    decide +kernel
  exact e42182
end OMA.Blocks5_13_245212.S42182
