import BoxPrefix245212

/-! Short prime or exponent windows do not need a logarithm of the
full cofactor moments. Check the few integers in the window directly. -/
namespace OMA.QuickPrefix245212
open OMA.Box245212 OMA.PrefixLeaf245212 OMA.Large245212

private theorem trim_subset {B : ℕ×ℕ} {v w : ℤ} {d : ℕ}
    (lo : (trim B v w).1≤d) (hi : d≤(trim B v w).2) : B.1≤d ∧ d≤B.2 := by
  unfold trim at lo hi
  split_ifs at lo hi <;> omega

private theorem bounds_subset {A S T rl rh gl gh d : ℕ}
    (lo : (bounds A S T rl rh gl gh).1≤d) (hi : d≤(bounds A S T rl rh gl gh).2) :
    gl≤d ∧ d≤gh := by
  unfold bounds at lo hi
  obtain ⟨a,b⟩ := trim_subset lo hi
  obtain ⟨u,v⟩ := trim_subset a b
  exact ⟨u,v.trans (min_le_left ..)⟩

def noPrime (A S rl rh : ℕ) : Bool :=
  rh-rl<8 && (List.range' rl (rh+1-rl)).all (fun r=>(A+S)%r != 0)

def quick (A S T rl rh gl gh : ℕ) : Bool :=
  noPrime A S rl rh || (if gh-gl<6 then (List.range' gl (gh+1-gl)).all (rejects A S T rl rh)
    else exact A S T rl rh gl gh)

private theorem from_noPrime {A S T rl rh : ℕ} (h : noPrime A S rl rh=true) (d : ℕ) :
    rejects A S T rl rh d=true := by
  obtain ⟨_,no⟩ := Bool.and_eq_true_iff.mp h
  let r := candidate A S T d
  by_cases l : r<rl
  · simp [rejects,show candidate A S T d<rl from l]
  by_cases u : rh<r
  · simp [rejects,show rh<candidate A S T d from u]
  have mem : r∈List.range' rl (rh+1-rl) := List.mem_range'_1.mpr ⟨by omega,by omega⟩
  have neq := List.all_eq_true.mp no r mem
  simp [rejects,show ((A+S)%(candidate A S T d)!=0)=true from neq]

theorem quick_ok {A S T rl rh gl gh : ℕ} (h : quick A S T rl rh gl gh=true) :
    exact A S T rl rh gl gh=true := by
  rcases Bool.or_eq_true_iff.mp h with no|rest
  · exact List.all_eq_true.mpr fun d _=>from_noPrime no d
  by_cases short : gh-gl<6
  · rw [if_pos short] at rest
    apply List.all_eq_true.mpr
    intro d hd
    have lo := (List.mem_range'_1.mp hd).1
    have hi := (List.mem_range'_1.mp hd).2
    have dh : d≤(bounds A S T rl rh gl gh).2 := by omega
    obtain ⟨gl,gh⟩ := bounds_subset lo dh
    exact List.all_eq_true.mp rest d (List.mem_range'_1.mpr ⟨gl,by omega⟩)
  · simpa only [if_neg short] using rest

def quickBlock (p q : ℕ) (b : Box) : Bool :=
  decide (1<(b 4).lo) &&
  (b 0).entries.all (fun k =>
    let a0 := wt 3 k; let s0 := sig 3 k; let t0 := tax 3 k
    (b 1).entries.all (fun e =>
      let a1 := a0*wt p e; let s1 := s0*sig p e; let t1 := t0*tax p e
      (b 2).entries.all (fun f => quick (a1*wt q f) (s1*sig q f) (t1*tax q f)
        (b 4).lo (b 4).hi (b 3).lo (b 3).hi)))

theorem prefix_ok {p q : ℕ} {b : Box} (yes : quickBlock p q b=true) : Deny p q b := by
  apply prefix_sound
  obtain ⟨base,all⟩ := Bool.and_eq_true_iff.mp yes
  apply Bool.and_eq_true_iff.mpr
  refine ⟨base,List.all_eq_true.mpr fun k hk=>List.all_eq_true.mpr fun e he=>List.all_eq_true.mpr fun f hf=>?_⟩
  exact quick_ok (List.all_eq_true.mp (List.all_eq_true.mp (List.all_eq_true.mp all k hk) e he) f hf)

theorem atPrefix {p q : ℕ} {b : Box} {v : Values} (fit : Fits b v) (c : Candidate p q v)
    (base : decide (1<(b 4).lo)=true)
    (last : quick (wt 3 (v 0)*wt p (v 1)*wt q (v 2))
      (sig 3 (v 0)*sig p (v 1)*sig q (v 2)) (tax 3 (v 0)*tax p (v 1)*tax q (v 2))
      (b 4).lo (b 4).hi (b 3).lo (b 3).hi=true) : False := by
  let bb : Box := ![⟨v 0,v 0⟩,⟨v 1,v 1⟩,⟨v 2,v 2⟩,b 3,b 4]
  have inside : Fits bb v := by
    intro i; fin_cases i <;> first | exact ⟨le_rfl,le_rfl⟩ | apply fit
  apply prefix_sound (b:=bb) _ v inside c
  simp [exactBlock,bb,Range.entries]
  exact ⟨base,quick_ok last⟩

end OMA.QuickPrefix245212
