import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S55447
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b55447 : Box := ![⟨76,94⟩,⟨127,1920000000000000011376⟩,⟨7,9⟩,⟨1,502335381913959616708⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨76,94⟩,⟨127,1920000000000000011376⟩,⟨7,9⟩,⟨1,502335381913959616708⟩,⟨479,999999999999999999⟩] := by
  have e55447 : Deny 5 13 b55447 := by
    apply closeAction rule_sound _ _ 64 [0x8cb8dbae32e36eb8cb6f8df58c98dbae32e36eb8cb8dbae32e36eb8cbae32236ab6eb8c8ae32daada22b8dbae32388c9,0x2e36eb8cb8dbae32e36eb8cb8dbae32e36eb8cb8dbae32e36eb8cb8dbae32e36eb8cb8dbae32e36eb8cb8dbae32e36eb,0x8dbae32dbacb8dbae32e36eb8cb8c88dbae32da683ac322129aae12c2ae884b48b48b48b48b2ab088ac21f58c78dbae3,0x8cb8daae32e36ab8cbac20830e3223207ac20c7ac38c86eb2e36eb8cb6eb2e36eb8cb0c21eb0881dbacb8dbae32dbacb,0x2d22d22d22d22e128848b48b48b48b48b84a8db2e36cb8db2e36cb8db2c226b8c88c78daae32e36ab8cb8daae32e36ab,0x8db2e36cb8db2eb8c824208209aae3238adaae32358c7adaae3207adaae322b6ab8c8ac21f526b69aada683a212922d2,0x209aae322b69aada68308784a48b48b48b0a12a12821c21c848b48b48b48b48b48b84a8db2e36cb]
    decide +kernel
  exact e55447
end OMA.Blocks5_13_245212.S55447
