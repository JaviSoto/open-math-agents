import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S41991
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b41991 : Box := ![⟨63,94⟩,⟨25,30⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711604⟩,⟨239,478⟩]
private def b41992 : Box := ![⟨63,75⟩,⟨25,30⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711604⟩,⟨239,478⟩]
private def b41993 : Box := ![⟨63,75⟩,⟨25,30⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711600⟩,⟨239,318⟩]
private def b42002 : Box := ![⟨63,75⟩,⟨25,30⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711600⟩,⟨319,478⟩]
private def b42003 : Box := ![⟨63,75⟩,⟨25,27⟩,⟨63,1920000000000000011376⟩,⟨3,855338345864661659236⟩,⟨319,478⟩]
private def b42014 : Box := ![⟨63,75⟩,⟨28,30⟩,⟨63,1920000000000000011376⟩,⟨3,855338345864661659236⟩,⟨319,478⟩]
private def b42025 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711604⟩,⟨239,478⟩]
private theorem e41993 : Deny 5 13 b41993 := by
    apply closeAction rule_sound _ _ 64 [0x20af7df0b8dec88a8842b8be3263204]
    decide +kernel
private theorem e42003 : Deny 5 13 b42003 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe311cbe3109e2f7ef7df0ec88a88a8c9be3263]
    decide +kernel
private theorem e42014 : Deny 5 13 b42014 := by
    apply closeAction rule_sound _ _ 64 [0xaf8d7e377ef8df7f8103884238be22a3278be31e3278]
    decide +kernel
private theorem e42002 : Deny 5 13 b42002 :=
    branchAction rule_sound _ _ 2
      0x223 b42002 b42003 b42014 (by decide +kernel) e42003 e42014
private theorem e41992 : Deny 5 13 b41992 :=
    branchAction rule_sound _ _ 2
      0x2e3 b41992 b41993 b42002 (by decide +kernel) e41993 e42002
private theorem e42025 : Deny 5 13 b42025 := by
    apply closeAction rule_sound _ _ 64 [0x2095e37578dc3e2f887888887de2108e37]
    decide +kernel
private theorem e41991 : Deny 5 13 b41991 :=
    branchAction rule_sound _ _ 1
      0x7 b41991 b41992 b42025 (by decide +kernel) e41992 e42025
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨25,30⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711604⟩,⟨239,478⟩] := by
  exact e41991
end OMA.Blocks5_13_245212.S41991
