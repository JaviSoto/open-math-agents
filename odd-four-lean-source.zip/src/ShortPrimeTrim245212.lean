import RawDigit245212

/-! Trim a prime interval from its ends. Once a prime is reached there is
no need to compute primality for any of the interior integers. -/
namespace OMA.ShortPrimeTrim245212
open OMA.Box245212 OMA.SparseEngine245212
open private OMA.Box245212.put_sound from Engine245212

def lo : ℕ → ℕ → ℕ
  | 0,a => a
  | n+1,a => if a.Prime then a else lo n (a+1)

def hi : ℕ → ℕ → ℕ
  | 0,a => a
  | n+1,a => if a.Prime then a else hi n (a-1)

private theorem lo_le {v : ℕ} (pv : v.Prime) (n a : ℕ) (h : a≤v) : lo n a≤v := by
  induction n generalizing a with
  | zero => exact h
  | succ n ih =>
    rw [lo]; split_ifs with prime
    · exact h
    · apply ih; have z : a≠v := fun same=>prime (same ▸ pv); omega

private theorem le_hi {v : ℕ} (pv : v.Prime) (n a : ℕ) (h : v≤a) : v≤hi n a := by
  induction n generalizing a with
  | zero => exact h
  | succ n ih =>
    rw [hi]; split_ifs with prime
    · exact h
    · apply ih; have z : a≠v := fun same=>prime (same ▸ pv); omega

def trim (b : Box) : Option Box :=
  let r := b 4
  let n := r.hi-r.lo+1
  let l := lo n r.lo
  let u := hi n r.hi
  if l≤u then some (clip b 4 ⟨l,u⟩) else none

private theorem trim_sound {p q : ℕ} {b : Box} {v : Values} (f : Fits b v) (c : Candidate p q v) :
    ∃ out,trim b=some out ∧ Fits out v := by
  have a := lo_le (v:=v 4) (c.prime 3) ((b 4).hi-(b 4).lo+1) _ (f 4).1
  have z := le_hi (v:=v 4) (c.prime 3) ((b 4).hi-(b 4).lo+1) _ (f 4).2
  exact ⟨_,if_pos (a.trans z),clip_fits f ⟨a,z⟩⟩

private def rest := OMA.PrefixRule245212.withPrefix (OMA.WheelPrefix245212.test 640) OMA.RawDigit245212.rule
private theorem rest_ok : AdvanceSound rest :=
  OMA.PrefixRule245212.prefix_sound OMA.WheelPrefix245212.test_ok OMA.RawDigit245212.sound

def rule (p q op : ℕ) (s : Stack) : Option Stack := if op=4 then
  match s with
  | [] => none
  | b::tail => some (put (trim b) tail)
  else rest p q op s

theorem sound : AdvanceSound rule := by
  intro p q op s t ck yes
  unfold rule at ck
  split_ifs at ck with prime
  · cases s with
    | nil => cases ck
    | cons b tail =>
      cases Option.some.inj ck
      exact OMA.Box245212.put_sound (fun _ f c=>trim_sound f c) yes
  · exact rest_ok p q op s t ck yes
end OMA.ShortPrimeTrim245212
