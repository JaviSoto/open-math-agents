import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S19580
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b19580 : Box := ![⟨23,30⟩,⟨31,1920000000000000011376⟩,⟨15,1920000000000000011376⟩,⟨1,2⟩,⟨59,113⟩]
theorem deny5_13 : Deny 5 13 ![⟨23,30⟩,⟨31,1920000000000000011376⟩,⟨15,1920000000000000011376⟩,⟨1,2⟩,⟨59,113⟩] := by
  have e19580 : Deny 5 13 b19580 := by
    apply closeAction rule_sound _ _ 64 [0xe36888116a96597256aa11ea849aa22165c95e2216df6d445960c95b8d88256088da2216db51c22a210bda21e22042e2,0x16a96597e37aa12788495b8daa887aa22175b8df6d621c4087]
    decide +kernel
  exact e19580
end OMA.Blocks5_13_245212.S19580
