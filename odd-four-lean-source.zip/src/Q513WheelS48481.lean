import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S48481
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b48481 : Box := ![⟨95,190⟩,⟨21,24⟩,⟨15,30⟩,⟨3,64⟩,⟨239,478⟩]
private def b48482 : Box := ![⟨95,126⟩,⟨21,24⟩,⟨15,30⟩,⟨3,62⟩,⟨239,478⟩]
private def b48483 : Box := ![⟨95,126⟩,⟨21,24⟩,⟨15,20⟩,⟨3,49⟩,⟨239,478⟩]
private def b48484 : Box := ![⟨95,126⟩,⟨21,24⟩,⟨15,20⟩,⟨3,44⟩,⟨239,298⟩]
private def b48485 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨15,20⟩,⟨3,44⟩,⟨239,293⟩]
private def b48490 : Box := ![⟨95,126⟩,⟨23,24⟩,⟨15,20⟩,⟨3,44⟩,⟨239,293⟩]
private def b48497 : Box := ![⟨95,126⟩,⟨21,24⟩,⟨15,20⟩,⟨3,44⟩,⟨299,396⟩]
private def b48504 : Box := ![⟨95,126⟩,⟨21,24⟩,⟨21,30⟩,⟨3,49⟩,⟨239,478⟩]
private def b48505 : Box := ![⟨95,126⟩,⟨21,24⟩,⟨21,30⟩,⟨3,49⟩,⟨239,318⟩]
private def b48506 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨21,30⟩,⟨3,49⟩,⟨239,317⟩]
private def b48507 : Box := ![⟨95,108⟩,⟨21,22⟩,⟨21,30⟩,⟨3,48⟩,⟨239,317⟩]
private def b48514 : Box := ![⟨109,126⟩,⟨21,22⟩,⟨21,30⟩,⟨3,48⟩,⟨239,317⟩]
private def b48523 : Box := ![⟨95,126⟩,⟨23,24⟩,⟨21,30⟩,⟨3,49⟩,⟨239,317⟩]
private def b48524 : Box := ![⟨95,126⟩,⟨23,24⟩,⟨21,30⟩,⟨3,6⟩,⟨239,317⟩]
private def b48525 : Box := ![⟨95,108⟩,⟨23,24⟩,⟨21,30⟩,⟨3,6⟩,⟨239,317⟩]
private def b48532 : Box := ![⟨109,126⟩,⟨23,24⟩,⟨21,30⟩,⟨3,6⟩,⟨239,317⟩]
private def b48541 : Box := ![⟨95,126⟩,⟨23,24⟩,⟨21,30⟩,⟨7,49⟩,⟨239,317⟩]
private def b48542 : Box := ![⟨95,126⟩,⟨21,24⟩,⟨21,30⟩,⟨3,49⟩,⟨319,478⟩]
private def b48543 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨21,30⟩,⟨3,47⟩,⟨319,478⟩]
private def b48544 : Box := ![⟨95,108⟩,⟨21,22⟩,⟨21,30⟩,⟨3,46⟩,⟨319,475⟩]
private def b48547 : Box := ![⟨109,126⟩,⟨21,22⟩,⟨21,30⟩,⟨3,46⟩,⟨319,475⟩]
private def b48556 : Box := ![⟨95,126⟩,⟨23,24⟩,⟨21,30⟩,⟨3,47⟩,⟨319,478⟩]
private def b48557 : Box := ![⟨95,126⟩,⟨23,24⟩,⟨21,30⟩,⟨3,6⟩,⟨319,478⟩]
private def b48558 : Box := ![⟨95,108⟩,⟨23,24⟩,⟨21,30⟩,⟨3,6⟩,⟨319,478⟩]
private def b48563 : Box := ![⟨109,126⟩,⟨23,24⟩,⟨21,30⟩,⟨3,6⟩,⟨319,478⟩]
private def b48572 : Box := ![⟨95,126⟩,⟨23,24⟩,⟨21,30⟩,⟨7,47⟩,⟨319,478⟩]
private def b48573 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨15,30⟩,⟨3,62⟩,⟨239,478⟩]
private def b48574 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨15,20⟩,⟨3,62⟩,⟨239,478⟩]
private def b48575 : Box := ![⟨127,190⟩,⟨21,22⟩,⟨15,20⟩,⟨6,57⟩,⟨239,478⟩]
private def b48576 : Box := ![⟨127,190⟩,⟨21,22⟩,⟨15,20⟩,⟨7,57⟩,⟨239,318⟩]
private def b48577 : Box := ![⟨127,190⟩,⟨21,21⟩,⟨15,20⟩,⟨7,57⟩,⟨239,317⟩]
private def b48578 : Box := ![⟨127,190⟩,⟨21,21⟩,⟨15,20⟩,⟨8,14⟩,⟨239,317⟩]
private def b48579 : Box := ![⟨127,190⟩,⟨21,21⟩,⟨15,20⟩,⟨15,56⟩,⟨239,317⟩]
private def b48580 : Box := ![⟨127,190⟩,⟨21,21⟩,⟨15,20⟩,⟨15,23⟩,⟨239,317⟩]
private def b48591 : Box := ![⟨127,190⟩,⟨21,21⟩,⟨15,20⟩,⟨24,56⟩,⟨239,317⟩]
private def b48592 : Box := ![⟨127,190⟩,⟨22,22⟩,⟨15,20⟩,⟨7,57⟩,⟨239,317⟩]
private def b48593 : Box := ![⟨127,190⟩,⟨21,22⟩,⟨15,20⟩,⟨7,57⟩,⟨319,478⟩]
private def b48604 : Box := ![⟨127,190⟩,⟨23,24⟩,⟨15,20⟩,⟨6,57⟩,⟨239,478⟩]
private def b48605 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨21,30⟩,⟨3,62⟩,⟨239,478⟩]
private def b48606 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨21,30⟩,⟨3,62⟩,⟨239,318⟩]
private def b48607 : Box := ![⟨127,190⟩,⟨21,22⟩,⟨21,30⟩,⟨3,62⟩,⟨239,317⟩]
private def b48608 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨21,30⟩,⟨3,61⟩,⟨239,317⟩]
private def b48609 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨21,24⟩,⟨3,54⟩,⟨239,317⟩]
private def b48616 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨25,30⟩,⟨3,54⟩,⟨239,317⟩]
private def b48617 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨25,30⟩,⟨3,30⟩,⟨246,277⟩]
private def b48620 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨25,30⟩,⟨3,30⟩,⟨278,317⟩]
private def b48629 : Box := ![⟨153,190⟩,⟨21,22⟩,⟨21,30⟩,⟨3,61⟩,⟨239,317⟩]
private def b48636 : Box := ![⟨127,190⟩,⟨23,24⟩,⟨21,30⟩,⟨3,62⟩,⟨239,317⟩]
private def b48639 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨21,30⟩,⟨3,62⟩,⟨319,478⟩]
private def b48640 : Box := ![⟨127,190⟩,⟨21,22⟩,⟨21,30⟩,⟨3,59⟩,⟨319,478⟩]
private def b48641 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨21,30⟩,⟨3,58⟩,⟨319,478⟩]
private def b48642 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨21,24⟩,⟨3,51⟩,⟨319,478⟩]
private def b48647 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨25,30⟩,⟨3,51⟩,⟨319,478⟩]
private def b48648 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨25,30⟩,⟨3,51⟩,⟨319,382⟩]
private def b48659 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨25,30⟩,⟨3,51⟩,⟨383,478⟩]
private def b48666 : Box := ![⟨153,190⟩,⟨21,22⟩,⟨21,30⟩,⟨3,58⟩,⟨319,478⟩]
private def b48667 : Box := ![⟨153,190⟩,⟨21,22⟩,⟨21,24⟩,⟨7,58⟩,⟨319,478⟩]
private def b48668 : Box := ![⟨153,190⟩,⟨21,22⟩,⟨21,24⟩,⟨10,56⟩,⟨319,382⟩]
private def b48673 : Box := ![⟨153,190⟩,⟨21,22⟩,⟨21,24⟩,⟨10,56⟩,⟨383,478⟩]
private def b48680 : Box := ![⟨153,190⟩,⟨21,22⟩,⟨25,30⟩,⟨7,58⟩,⟨319,478⟩]
private def b48689 : Box := ![⟨127,190⟩,⟨23,24⟩,⟨21,30⟩,⟨3,59⟩,⟨319,478⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨21,24⟩,⟨15,30⟩,⟨3,64⟩,⟨239,478⟩] := by
  have e48485 : Deny 5 13 b48485 := by
    apply closeAction rule_sound _ _ 64 [0x39c3e37da31c47f8df68c41f8df6]
    decide +kernel
  have e48490 : Deny 5 13 b48490 := by
    apply closeAction rule_sound _ _ 64 [0x1f0e70f8dc77f8df680980a]
    decide +kernel
  have e48484 : Deny 5 13 b48484 :=
    branchAction rule_sound _ _ 2
      0x204 b48484 b48485 b48490 (by decide +kernel) e48485 e48490
  have e48497 : Deny 5 13 b48497 := by
    apply closeAction rule_sound _ _ 64 [0xe77f8df68c77f8df68c7088df68c4]
    decide +kernel
  have e48483 : Deny 5 13 b48483 :=
    branchAction rule_sound _ _ 3
      0xbe23 b48483 b48484 b48497 (by decide +kernel) e48484 e48497
  have e48507 : Deny 5 13 b48507 := by
    apply closeAction rule_sound _ _ 64 [0x30e31c3103e378c41f8de3263]
    decide +kernel
  have e48514 : Deny 5 13 b48514 := by
    apply closeAction rule_sound _ _ 64 [0xf8dc38c90e31c39c38c78c9]
    decide +kernel
  have e48506 : Deny 5 13 b48506 :=
    branchAction rule_sound _ _ 2
      0x1e3 b48506 b48507 b48514 (by decide +kernel) e48507 e48514
  have e48525 : Deny 5 13 b48525 := by
    apply closeAction rule_sound _ _ 64 [0x3e031c30f81c9]
    decide +kernel
  have e48532 : Deny 5 13 b48532 := by
    apply closeAction rule_sound _ _ 64 [0x83e370c7108e03e031c9]
    decide +kernel
  have e48524 : Deny 5 13 b48524 :=
    branchAction rule_sound _ _ 1
      0x7 b48524 b48525 b48532 (by decide +kernel) e48525 e48532
  have e48541 : Deny 5 13 b48541 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
  have e48523 : Deny 5 13 b48523 :=
    branchAction rule_sound _ _ 1
      0xa b48523 b48524 b48541 (by decide +kernel) e48524 e48541
  have e48505 : Deny 5 13 b48505 :=
    branchAction rule_sound _ _ 2
      0x204 b48505 b48506 b48523 (by decide +kernel) e48506 e48523
  have e48544 : Deny 5 13 b48544 := by
    apply closeAction rule_sound _ _ 64 [0x1f088e37da3]
    decide +kernel
  have e48547 : Deny 5 13 b48547 := by
    apply closeAction rule_sound _ _ 64 [0x30f88c90f8de31df088e378c9]
    decide +kernel
  have e48543 : Deny 5 13 b48543 :=
    branchAction rule_sound _ _ 3
      0x7e23 b48543 b48544 b48547 (by decide +kernel) e48544 e48547
  have e48558 : Deny 5 13 b48558 := by
    apply closeAction rule_sound _ _ 64 [0xc3e37243e36238]
    decide +kernel
  have e48563 : Deny 5 13 b48563 := by
    apply closeAction rule_sound _ _ 64 [0xf80c90c70c3e07e09]
    decide +kernel
  have e48557 : Deny 5 13 b48557 :=
    branchAction rule_sound _ _ 1
      0x7 b48557 b48558 b48563 (by decide +kernel) e48558 e48563
  have e48572 : Deny 5 13 b48572 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
  have e48556 : Deny 5 13 b48556 :=
    branchAction rule_sound _ _ 1
      0xa b48556 b48557 b48572 (by decide +kernel) e48557 e48572
  have e48542 : Deny 5 13 b48542 :=
    branchAction rule_sound _ _ 2
      0x223 b48542 b48543 b48556 (by decide +kernel) e48543 e48556
  have e48504 : Deny 5 13 b48504 :=
    branchAction rule_sound _ _ 1
      0xb b48504 b48505 b48542 (by decide +kernel) e48505 e48542
  have e48482 : Deny 5 13 b48482 :=
    branchAction rule_sound _ _ 2
      0x263 b48482 b48483 b48504 (by decide +kernel) e48483 e48504
  have e48578 : Deny 5 13 b48578 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
  have e48580 : Deny 5 13 b48580 := by
    apply closeAction rule_sound _ _ 64 [0x19e0380ae197cae090c47c9e07]
    decide +kernel
  have e48591 : Deny 5 13 b48591 := by
    apply closeAction rule_sound _ _ 64 [0x19]
    decide +kernel
  have e48579 : Deny 5 13 b48579 :=
    branchAction rule_sound _ _ 1
      0xa b48579 b48580 b48591 (by decide +kernel) e48580 e48591
  have e48577 : Deny 5 13 b48577 :=
    branchAction rule_sound _ _ 3
      0xa9e3 b48577 b48578 b48579 (by decide +kernel) e48578 e48579
  have e48592 : Deny 5 13 b48592 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
  have e48576 : Deny 5 13 b48576 :=
    branchAction rule_sound _ _ 2
      0x204 b48576 b48577 b48592 (by decide +kernel) e48577 e48592
  have e48593 : Deny 5 13 b48593 := by
    apply closeAction rule_sound _ _ 64 [0x197c30891021f8d88e0a7f8da02a3]
    decide +kernel
  have e48575 : Deny 5 13 b48575 :=
    branchAction rule_sound _ _ 2
      0x2e7 b48575 b48576 b48593 (by decide +kernel) e48576 e48593
  have e48604 : Deny 5 13 b48604 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
  have e48574 : Deny 5 13 b48574 :=
    branchAction rule_sound _ _ 3
      0x89e3 b48574 b48575 b48604 (by decide +kernel) e48575 e48604
  have e48609 : Deny 5 13 b48609 := by
    apply closeAction rule_sound _ _ 64 [0x7c3e038c78c42387ca9e3]
    decide +kernel
  have e48617 : Deny 5 13 b48617 := by
    apply closeAction rule_sound _ _ 64 [0x15e378029e6809dc4]
    decide +kernel
  have e48620 : Deny 5 13 b48620 := by
    apply closeAction rule_sound _ _ 64 [0x20832441f80a79831e0284]
    decide +kernel
  have e48616 : Deny 5 13 b48616 :=
    branchAction rule_sound _ _ 3
      0xbe37 b48616 b48617 b48620 (by decide +kernel) e48617 e48620
  have e48608 : Deny 5 13 b48608 :=
    branchAction rule_sound _ _ 2
      0x263 b48608 b48609 b48616 (by decide +kernel) e48609 e48616
  have e48629 : Deny 5 13 b48629 := by
    apply closeAction rule_sound _ _ 64 [0x20820c8107e27804278de7]
    decide +kernel
  have e48607 : Deny 5 13 b48607 :=
    branchAction rule_sound _ _ 2
      0x1e3 b48607 b48608 b48629 (by decide +kernel) e48608 e48629
  have e48636 : Deny 5 13 b48636 := by
    apply closeAction rule_sound _ _ 64 [0x20a6807e37]
    decide +kernel
  have e48606 : Deny 5 13 b48606 :=
    branchAction rule_sound _ _ 2
      0x204 b48606 b48607 b48636 (by decide +kernel) e48607 e48636
  have e48642 : Deny 5 13 b48642 := by
    apply closeAction rule_sound _ _ 64 [0xc3e272270f88c79e3]
    decide +kernel
  have e48648 : Deny 5 13 b48648 := by
    apply closeAction rule_sound _ _ 64 [0x7f8dc30e31e3203e370e02039e0260284]
    decide +kernel
  have e48659 : Deny 5 13 b48659 := by
    apply closeAction rule_sound _ _ 64 [0x30e78c99c30e78c98c78c4]
    decide +kernel
  have e48647 : Deny 5 13 b48647 :=
    branchAction rule_sound _ _ 1
      0xb b48647 b48648 b48659 (by decide +kernel) e48648 e48659
  have e48641 : Deny 5 13 b48641 :=
    branchAction rule_sound _ _ 2
      0x263 b48641 b48642 b48647 (by decide +kernel) e48642 e48647
  have e48668 : Deny 5 13 b48668 := by
    apply closeAction rule_sound _ _ 64 [0x7f8dc3e270e31c88c4]
    decide +kernel
  have e48673 : Deny 5 13 b48673 := by
    apply closeAction rule_sound _ _ 64 [0x3e032270c3e088c78c4]
    decide +kernel
  have e48667 : Deny 5 13 b48667 :=
    branchAction rule_sound _ _ 3
      0xb9e3 b48667 b48668 b48673 (by decide +kernel) e48668 e48673
  have e48680 : Deny 5 13 b48680 := by
    apply closeAction rule_sound _ _ 64 [0x1fe378c40839c4278de70f8dc3e278c98c7e278c4238]
    decide +kernel
  have e48666 : Deny 5 13 b48666 :=
    branchAction rule_sound _ _ 2
      0x267 b48666 b48667 b48680 (by decide +kernel) e48667 e48680
  have e48640 : Deny 5 13 b48640 :=
    branchAction rule_sound _ _ 2
      0x1e3 b48640 b48641 b48666 (by decide +kernel) e48641 e48666
  have e48689 : Deny 5 13 b48689 := by
    apply closeAction rule_sound _ _ 64 [0x7e77c29e60f89831c780a8c7]
    decide +kernel
  have e48639 : Deny 5 13 b48639 :=
    branchAction rule_sound _ _ 2
      0x223 b48639 b48640 b48689 (by decide +kernel) e48640 e48689
  have e48605 : Deny 5 13 b48605 :=
    branchAction rule_sound _ _ 1
      0xb b48605 b48606 b48639 (by decide +kernel) e48606 e48639
  have e48573 : Deny 5 13 b48573 :=
    branchAction rule_sound _ _ 1
      0x9 b48573 b48574 b48605 (by decide +kernel) e48574 e48605
  have e48481 : Deny 5 13 b48481 :=
    branchAction rule_sound _ _ 2
      0x1e3 b48481 b48482 b48573 (by decide +kernel) e48482 e48573
  exact e48481
end OMA.Blocks5_13_245212.S48481
