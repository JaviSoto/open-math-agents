import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S51426
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b51426 : Box := ![⟨95,190⟩,⟨25,30⟩,⟨63,1920000000000000011376⟩,⟨1,799016681299385430604⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨25,30⟩,⟨63,1920000000000000011376⟩,⟨1,799016681299385430604⟩,⟨479,999999999999999999⟩] := by
  have e51426 : Deny 5 13 b51426 := by
    apply closeAction rule_sound _ _ 64 [0x26375f2b8bdf54ae370f80e32631e32552a32e32231e3263082082bc20af0e32631e32635772c88c7e232632e32231f8,0x82083e03e23248e231f88c9e020f80c7bc30f81e326376f0f80ef8c78c9be32e31ef0f80e3243e2f8c3e378c9e231e3,0x20820820820820f88c9e07e232788c7e2f8c98c88c7e2f0820820f88c9e231f88c9e23238]
    decide +kernel
  exact e51426
end OMA.Blocks5_13_245212.S51426
