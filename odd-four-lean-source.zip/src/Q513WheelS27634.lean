import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S27634
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b27634 : Box := ![⟨38,46⟩,⟨63,109⟩,⟨15,20⟩,⟨3,6⟩,⟨239,478⟩]
theorem deny5_13 : Deny 5 13 ![⟨38,46⟩,⟨63,109⟩,⟨15,20⟩,⟨3,6⟩,⟨239,478⟩] := by
  have e27634 : Deny 5 13 b27634 := by
    apply closeAction rule_sound _ _ 64 [0xd6125f0f8103108e03e211c30f81c884a5ca0c3e37ae1243e3721fe37db58478498442c31021f8da1102238df6847e21,0x1f7c30f8203e0884a7f8df6d611e110b5ca7f8df6]
    decide +kernel
  exact e27634
end OMA.Blocks5_13_245212.S27634
