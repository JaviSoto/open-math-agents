import PrefixRule245212
import WheelPrefix245212

/-! Prime-wheel replacement for prefix instruction 3. All other box
instructions, and the fallback for an inconclusive wheel, stay unchanged. -/
namespace OMA.WheelRule245212
open OMA.SparseEngine245212
def rule := PrefixRule245212.withPrefix (WheelPrefix245212.test 128) PrefixRule245212.base
theorem sound : AdvanceSound rule :=
  PrefixRule245212.prefix_sound WheelPrefix245212.test_ok PrefixRule245212.base_sound
end OMA.WheelRule245212
