import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S47906
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b47906 : Box := ![⟨255,382⟩,⟨18,20⟩,⟨63,126⟩,⟨3,121⟩,⟨959,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨255,382⟩,⟨18,20⟩,⟨63,126⟩,⟨3,121⟩,⟨959,999999999999999999⟩] := by
  have e47906 : Deny 5 13 b47906 := by
    apply closeAction rule_sound _ _ 64 [0xe2354ae232631e3578dd5e377552b89e32631e32f87678dd9e32f88c9755578278d8ae2354ae368c78dd54a54a8cb8c8,0x820f88c9e231f80f80e31e3243e038c90c3e232631e37552a32dd54ae232631e3578dd5e370f80e31e32631e32dd54a,0x7552d52ca54b54b54a54b54b2a37678cb8dd9e32e37678cb8dd9e32e37678cb8dd9e32e37678cb8dd9e32e37678cb8c9,0x7678cb8dd9e32e37678cb75d54ae0ae2354ae231e326309d54ae278c98cbe231c8e23278082083e232788c9e231f875d,0xc21c92952d52d52d52d52d52d52ca54b54b54b54b54b54b2a37678cb8dd9e32e37678cb8dd9e32e37678cb8dd9e32e3,0x820820820f88c7e232788c9e231f80820f88c9e03e03e232631e30820f89e32788c78cbe231f875d755]
    decide +kernel
  exact e47906
end OMA.Blocks5_13_245212.S47906
