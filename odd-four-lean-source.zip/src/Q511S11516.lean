import FastReplay245212
import SparseDigit245212
import FastRound245212
import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S11516
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b11516 : Box := ![⟨18,22⟩,⟨31,1920000000000000011376⟩,⟨15,1920000000000000011376⟩,⟨1,1664000000000000009895⟩,⟨103,206⟩]
private def b11517 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨15,1920000000000000011376⟩,⟨1,1664000000000000009887⟩,⟨103,199⟩]
private def b11518 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨15,30⟩,⟨1,994807017543859655057⟩,⟨103,199⟩]
private def b11519 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨15,30⟩,⟨1,2⟩,⟨103,199⟩]
private def b11520 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨15,30⟩,⟨1,2⟩,⟨103,135⟩]
private def b11521 : Box := ![⟨18,19⟩,⟨31,62⟩,⟨15,30⟩,⟨1,2⟩,⟨103,131⟩]
private def b11530 : Box := ![⟨20,22⟩,⟨31,62⟩,⟨15,30⟩,⟨1,2⟩,⟨103,131⟩]
private def b11545 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨15,30⟩,⟨1,2⟩,⟨136,199⟩]
private def b11546 : Box := ![⟨18,19⟩,⟨31,62⟩,⟨15,30⟩,⟨1,2⟩,⟨137,199⟩]
private def b11553 : Box := ![⟨20,22⟩,⟨31,62⟩,⟨15,30⟩,⟨1,2⟩,⟨137,199⟩]
private def b11554 : Box := ![⟨20,22⟩,⟨31,41⟩,⟨15,30⟩,⟨1,2⟩,⟨137,199⟩]
private def b11567 : Box := ![⟨20,22⟩,⟨42,62⟩,⟨15,30⟩,⟨1,2⟩,⟨137,199⟩]
private def b11576 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨15,30⟩,⟨3,45⟩,⟨103,199⟩]
private def b11577 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨15,30⟩,⟨3,45⟩,⟨103,135⟩]
private def b11578 : Box := ![⟨18,19⟩,⟨31,62⟩,⟨15,30⟩,⟨3,45⟩,⟨103,131⟩]
private def b11579 : Box := ![⟨18,19⟩,⟨31,41⟩,⟨15,30⟩,⟨3,45⟩,⟨103,131⟩]
private def b11588 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨15,30⟩,⟨3,45⟩,⟨103,131⟩]
private def b11589 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨15,20⟩,⟨3,45⟩,⟨103,131⟩]
private def b11590 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨15,20⟩,⟨3,6⟩,⟨103,131⟩]
private def b11603 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨15,20⟩,⟨7,39⟩,⟨103,131⟩]
private def b11608 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨21,30⟩,⟨3,45⟩,⟨103,131⟩]
private def b11613 : Box := ![⟨20,22⟩,⟨31,62⟩,⟨15,30⟩,⟨3,45⟩,⟨103,131⟩]
private def b11620 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨15,30⟩,⟨3,45⟩,⟨136,199⟩]
private def b11621 : Box := ![⟨18,19⟩,⟨31,62⟩,⟨15,30⟩,⟨3,43⟩,⟨137,199⟩]
private def b11622 : Box := ![⟨18,19⟩,⟨31,41⟩,⟨15,30⟩,⟨3,42⟩,⟨137,199⟩]
private def b11631 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨15,30⟩,⟨3,42⟩,⟨137,199⟩]
private def b11632 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨15,20⟩,⟨3,42⟩,⟨137,199⟩]
private def b11647 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨21,30⟩,⟨3,42⟩,⟨137,199⟩]
private def b11648 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨21,30⟩,⟨3,42⟩,⟨137,162⟩]
private def b11655 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨21,30⟩,⟨3,42⟩,⟨163,199⟩]
private def b11664 : Box := ![⟨20,22⟩,⟨31,62⟩,⟨15,30⟩,⟨3,43⟩,⟨137,199⟩]
private def b11665 : Box := ![⟨20,22⟩,⟨31,41⟩,⟨15,30⟩,⟨3,43⟩,⟨137,199⟩]
private def b11666 : Box := ![⟨20,22⟩,⟨31,41⟩,⟨15,20⟩,⟨3,36⟩,⟨137,199⟩]
private def b11669 : Box := ![⟨20,22⟩,⟨31,41⟩,⟨21,30⟩,⟨3,36⟩,⟨137,199⟩]
private def b11682 : Box := ![⟨20,22⟩,⟨42,62⟩,⟨15,30⟩,⟨3,43⟩,⟨137,199⟩]
private def b11683 : Box := ![⟨20,22⟩,⟨42,62⟩,⟨15,20⟩,⟨3,43⟩,⟨138,199⟩]
private def b11698 : Box := ![⟨20,22⟩,⟨42,62⟩,⟨21,30⟩,⟨3,43⟩,⟨138,199⟩]
private def b11699 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨1,994807017543859655057⟩,⟨103,199⟩]
private def b11700 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨1,2⟩,⟨103,199⟩]
private def b11705 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655057⟩,⟨103,199⟩]
private def b11706 : Box := ![⟨18,19⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655057⟩,⟨109,199⟩]
private def b11707 : Box := ![⟨18,19⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨3,982170900692840652509⟩,⟨109,140⟩]
private def b11718 : Box := ![⟨18,19⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨3,982170900692840652509⟩,⟨141,199⟩]
private def b11719 : Box := ![⟨18,19⟩,⟨31,41⟩,⟨31,1920000000000000011376⟩,⟨3,920519480519480524971⟩,⟨149,199⟩]
private def b11720 : Box := ![⟨18,19⟩,⟨31,41⟩,⟨31,62⟩,⟨3,920519480519480524964⟩,⟨149,199⟩]
private def b11721 : Box := ![⟨18,19⟩,⟨31,35⟩,⟨31,62⟩,⟨3,50⟩,⟨149,199⟩]
private def b11722 : Box := ![⟨18,19⟩,⟨31,35⟩,⟨31,62⟩,⟨3,48⟩,⟨149,170⟩]
private def b11735 : Box := ![⟨18,19⟩,⟨31,35⟩,⟨31,62⟩,⟨3,48⟩,⟨171,199⟩]
private def b11746 : Box := ![⟨18,19⟩,⟨36,41⟩,⟨31,62⟩,⟨3,50⟩,⟨149,199⟩]
private def b11761 : Box := ![⟨18,19⟩,⟨31,41⟩,⟨63,1920000000000000011376⟩,⟨3,920519480519480524964⟩,⟨149,199⟩]
private def b11772 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨31,1920000000000000011376⟩,⟨3,920519480519480524971⟩,⟨149,199⟩]
private def b11781 : Box := ![⟨20,22⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655057⟩,⟨109,199⟩]
private def b11788 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨15,1920000000000000011376⟩,⟨1,1664000000000000009887⟩,⟨103,199⟩]
private def b11789 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨1,1664000000000000009887⟩,⟨103,199⟩]
private def b11790 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨1,2⟩,⟨103,199⟩]
private def b11791 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨3,669192982456140354876⟩,⟨103,199⟩]
private def b11792 : Box := ![⟨18,19⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨3,669192982456140354876⟩,⟨123,199⟩]
private def b11793 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨15,30⟩,⟨3,640000000000000003823⟩,⟨127,199⟩]
private def b11794 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨15,20⟩,⟨3,64⟩,⟨127,199⟩]
private def b11795 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨15,20⟩,⟨4,59⟩,⟨132,158⟩]
private def b11802 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨15,20⟩,⟨4,59⟩,⟨159,199⟩]
private def b11817 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨21,30⟩,⟨3,64⟩,⟨127,199⟩]
private def b11824 : Box := ![⟨18,19⟩,⟨127,1920000000000000011376⟩,⟨15,30⟩,⟨3,640000000000000003823⟩,⟨127,199⟩]
private def b11825 : Box := ![⟨20,22⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨3,669192982456140354876⟩,⟨123,199⟩]
private def b11826 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨1,1664000000000000009887⟩,⟨103,199⟩]
theorem deny5_11 : Deny 5 11 ![⟨18,22⟩,⟨31,1920000000000000011376⟩,⟨15,1920000000000000011376⟩,⟨1,1664000000000000009895⟩,⟨103,206⟩] := by
  have e11521 : Deny 5 11 b11521 := by
    apply closeAction rule_sound _ _ 64 [0x160c3de12431021f8dc8849]
    decide +kernel
  have e11530 : Deny 5 11 b11530 := by
    apply closeAction rule_sound _ _ 64 [0x820c4238dc38478495b8dd61c30c9248]
    decide +kernel
  have e11520 : Deny 5 11 b11520 :=
    branchAction rule_sound _ _ 2
      0x1c4 b11520 b11521 b11530 (by decide +kernel) e11521 e11530
  have e11546 : Deny 5 11 b11546 := by
    apply closeAction rule_sound _ _ 64 [0x5831021f8de1256e37d88]
    decide +kernel
  have e11554 : Deny 5 11 b11554 := by
    apply closeAction rule_sound _ _ 64 [0x2587e040c423858a5870c3249]
    decide +kernel
  have e11567 : Deny 5 11 b11567 := by
    apply closeAction rule_sound _ _ 64 [0x5b8dd61c3e370e1243847849]
    decide +kernel
  have e11553 : Deny 5 11 b11553 :=
    branchAction rule_sound _ _ 1
      0x8 b11553 b11554 b11567 (by decide +kernel) e11554 e11567
  have e11545 : Deny 5 11 b11545 :=
    branchAction rule_sound _ _ 2
      0x1c4 b11545 b11546 b11553 (by decide +kernel) e11546 e11553
  have e11519 : Deny 5 11 b11519 :=
    branchAction rule_sound _ _ 1
      0xb b11519 b11520 b11545 (by decide +kernel) e11520 e11545
  have e11579 : Deny 5 11 b11579 := by
    apply closeAction rule_sound _ _ 64 [0x3e37103107e370e32030e3223263]
    decide +kernel
  have e11590 : Deny 5 11 b11590 := by
    apply closeAction rule_sound _ _ 64 [0x20c70c32481020f8dc320710b]
    decide +kernel
  have e11603 : Deny 5 11 b11603 := by
    apply closeAction rule_sound _ _ 64 [0x20f8dc38c88c41f8]
    decide +kernel
  have e11589 : Deny 5 11 b11589 :=
    branchAction rule_sound _ _ 2
      0x2a3 b11589 b11590 b11603 (by decide +kernel) e11590 e11603
  have e11608 : Deny 5 11 b11608 := by
    apply closeAction rule_sound _ _ 64 [0x820c7108e37]
    decide +kernel
  have e11588 : Deny 5 11 b11588 :=
    branchAction rule_sound _ _ 1
      0x9 b11588 b11589 b11608 (by decide +kernel) e11589 e11608
  have e11578 : Deny 5 11 b11578 :=
    branchAction rule_sound _ _ 1
      0x8 b11578 b11579 b11588 (by decide +kernel) e11579 e11588
  have e11613 : Deny 5 11 b11613 := by
    apply closeAction rule_sound _ _ 64 [0x2083e370e3263263237]
    decide +kernel
  have e11577 : Deny 5 11 b11577 :=
    branchAction rule_sound _ _ 2
      0x1c4 b11577 b11578 b11613 (by decide +kernel) e11578 e11613
  have e11622 : Deny 5 11 b11622 := by
    apply closeAction rule_sound _ _ 64 [0xc3e070e3203103e37da3108e23263]
    decide +kernel
  have e11632 : Deny 5 11 b11632 := by
    apply closeAction rule_sound _ _ 64 [0x30e32430f8de32632230f70e32430e32632042e3]
    decide +kernel
  have e11648 : Deny 5 11 b11648 := by
    apply closeAction rule_sound _ _ 64 [0x83109e370f8dc31e3204]
    decide +kernel
  have e11655 : Deny 5 11 b11655 := by
    apply closeAction rule_sound _ _ 64 [0x83107e370e32430e31e3223]
    decide +kernel
  have e11647 : Deny 5 11 b11647 :=
    branchAction rule_sound _ _ 1
      0xb b11647 b11648 b11655 (by decide +kernel) e11648 e11655
  have e11631 : Deny 5 11 b11631 :=
    branchAction rule_sound _ _ 1
      0x9 b11631 b11632 b11647 (by decide +kernel) e11632 e11647
  have e11621 : Deny 5 11 b11621 :=
    branchAction rule_sound _ _ 2
      0x223 b11621 b11622 b11631 (by decide +kernel) e11622 e11631
  have e11666 : Deny 5 11 b11666 := by
    apply closeAction rule_sound _ _ 64 [0x30e3263]
    decide +kernel
  have e11669 : Deny 5 11 b11669 := by
    apply closeAction rule_sound _ _ 64 [0x20c8dc3dc38c81e30820c81f710b]
    decide +kernel
  have e11665 : Deny 5 11 b11665 :=
    branchAction rule_sound _ _ 2
      0x263 b11665 b11666 b11669 (by decide +kernel) e11666 e11669
  have e11683 : Deny 5 11 b11683 := by
    apply closeAction rule_sound _ _ 64 [0x820c9108e370f8dc38c81e3102083207dcb8c4]
    decide +kernel
  have e11698 : Deny 5 11 b11698 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e11682 : Deny 5 11 b11682 :=
    branchAction rule_sound _ _ 2
      0x278 b11682 b11683 b11698 (by decide +kernel) e11683 e11698
  have e11664 : Deny 5 11 b11664 :=
    branchAction rule_sound _ _ 1
      0x8 b11664 b11665 b11682 (by decide +kernel) e11665 e11682
  have e11620 : Deny 5 11 b11620 :=
    branchAction rule_sound _ _ 3
      0x78c4 b11620 b11621 b11664 (by decide +kernel) e11621 e11664
  have e11576 : Deny 5 11 b11576 :=
    branchAction rule_sound _ _ 1
      0xb b11576 b11577 b11620 (by decide +kernel) e11577 e11620
  have e11518 : Deny 5 11 b11518 :=
    branchAction rule_sound _ _ 2
      0x2a3 b11518 b11519 b11576 (by decide +kernel) e11519 e11576
  have e11700 : Deny 5 11 b11700 := by
    apply closeAction rule_sound _ _ 64 [0x5b8dc4587e161e2]
    decide +kernel
  have e11707 : Deny 5 11 b11707 := by
    apply closeAction rule_sound _ _ 64 [0x82508e375b8dc3e370c7209888dc4]
    decide +kernel
  have e11722 : Deny 5 11 b11722 := by
    apply closeAction rule_sound _ _ 64 [0x83e370e32070f8dc38c78c90c31e2284]
    decide +kernel
  have e11735 : Deny 5 11 b11735 := by
    apply closeAction rule_sound _ _ 64 [0x20e31c38c80e22837b8df68c78c98c4]
    decide +kernel
  have e11721 : Deny 5 11 b11721 :=
    branchAction rule_sound _ _ 2
      0x2e3 b11721 b11722 b11735 (by decide +kernel) e11722 e11735
  have e11746 : Deny 5 11 b11746 := by
    apply closeAction rule_sound _ _ 64 [0x20f70e32070f70e31e32631020f70c81f710b]
    decide +kernel
  have e11720 : Deny 5 11 b11720 :=
    branchAction rule_sound _ _ 2
      0x223 b11720 b11721 b11746 (by decide +kernel) e11721 e11746
  have e11761 : Deny 5 11 b11761 := by
    apply closeAction rule_sound _ _ 64 [0x14e370af8c409c7a22a3107e2f8c427850a8c8]
    decide +kernel
  have e11719 : Deny 5 11 b11719 :=
    branchAction rule_sound _ _ 2
      0x263 b11719 b11720 b11761 (by decide +kernel) e11720 e11761
  have e11772 : Deny 5 11 b11772 := by
    apply closeAction rule_sound _ _ 64 [0x96e375b8dc20c7248109e37]
    decide +kernel
  have e11718 : Deny 5 11 b11718 :=
    branchAction rule_sound _ _ 3
      0x88c4 b11718 b11719 b11772 (by decide +kernel) e11719 e11772
  have e11706 : Deny 5 11 b11706 :=
    branchAction rule_sound _ _ 2
      0x2e3 b11706 b11707 b11718 (by decide +kernel) e11707 e11718
  have e11781 : Deny 5 11 b11781 := by
    apply closeAction rule_sound _ _ 64 [0x20820e22221f7884238de3]
    decide +kernel
  have e11705 : Deny 5 11 b11705 :=
    branchAction rule_sound _ _ 2
      0x1f8 b11705 b11706 b11781 (by decide +kernel) e11706 e11781
  have e11699 : Deny 5 11 b11699 :=
    branchAction rule_sound _ _ 1
      0xa b11699 b11700 b11705 (by decide +kernel) e11700 e11705
  have e11517 : Deny 5 11 b11517 :=
    branchAction rule_sound _ _ 2
      0x263 b11517 b11518 b11699 (by decide +kernel) e11518 e11699
  have e11790 : Deny 5 11 b11790 := by
    apply closeAction rule_sound _ _ 64 [0x16aa1]
    decide +kernel
  have e11795 : Deny 5 11 b11795 := by
    apply closeAction rule_sound _ _ 64 [0x82083107e2b26b2378c4]
    decide +kernel
  have e11802 : Deny 5 11 b11802 := by
    apply closeAction rule_sound _ _ 64 [0x20820e322b8c41f8ae3278ac20f8ac70f8dc31eb8c98c88c4]
    decide +kernel
  have e11794 : Deny 5 11 b11794 :=
    branchAction rule_sound _ _ 4
      0x2f8ae3 b11794 b11795 b11802 (by decide +kernel) e11795 e11802
  have e11817 : Deny 5 11 b11817 := by
    apply closeAction rule_sound _ _ 64 [0x82083849847108e37]
    decide +kernel
  have e11793 : Deny 5 11 b11793 :=
    branchAction rule_sound _ _ 2
      0x263 b11793 b11794 b11817 (by decide +kernel) e11794 e11817
  have e11824 : Deny 5 11 b11824 := by
    apply closeAction rule_sound _ _ 64 [0xab]
    decide +kernel
  have e11792 : Deny 5 11 b11792 :=
    branchAction rule_sound _ _ 3
      0x88c4 b11792 b11793 b11824 (by decide +kernel) e11793 e11824
  have e11825 : Deny 5 11 b11825 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e11791 : Deny 5 11 b11791 :=
    branchAction rule_sound _ _ 2
      0x1f8 b11791 b11792 b11825 (by decide +kernel) e11792 e11825
  have e11789 : Deny 5 11 b11789 :=
    branchAction rule_sound _ _ 2
      0x2a3 b11789 b11790 b11791 (by decide +kernel) e11790 e11791
  have e11826 : Deny 5 11 b11826 := by
    apply closeAction rule_sound _ _ 64 [0x2588e37]
    decide +kernel
  have e11788 : Deny 5 11 b11788 :=
    branchAction rule_sound _ _ 1
      0x9 b11788 b11789 b11826 (by decide +kernel) e11789 e11826
  have e11516 : Deny 5 11 b11516 :=
    branchAction rule_sound _ _ 3
      0x88c4 b11516 b11517 b11788 (by decide +kernel) e11517 e11788
  exact e11516
end OMA.Blocks5_11_245212.S11516
