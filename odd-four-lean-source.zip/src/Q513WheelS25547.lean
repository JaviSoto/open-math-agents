import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S25547
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b25547 : Box := ![⟨38,46⟩,⟨42,62⟩,⟨31,1920000000000000011376⟩,⟨3,1017986577181208059766⟩,⟨127,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨38,46⟩,⟨42,62⟩,⟨31,1920000000000000011376⟩,⟨3,1017986577181208059766⟩,⟨127,233⟩] := by
  have e25547 : Deny 5 13 b25547 := by
    apply closeAction rule_sound _ _ 64 [0xc92070c31c30c71c910b2072a3263097e375b8ddf0820832622041f8083108e030c71d7dc42c9e1728a2072778c42f8,0x108e040c42780c3e098882972830c80c90c3e37278dc81c30c70c4088e37d872445f8dd7e370c9216e370e2238dc3243,0x2f80f8dc32032481df083109e03e032482b85ca0c32430f8dc92072445f8dc2587e37583109e370f80c92091c42df083,0x8c78c97df0820820c9207109e02083e03248107e170c70c31c710208320710b24810ae172825c8e375b7583209116dc4,0xaf5f8ddf0afb440961f8dc3e37103e2fb62107e2f888109e2d88a]
    decide +kernel
  exact e25547
end OMA.Blocks5_13_245212.S25547
