import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S30696
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b30696 : Box := ![⟨38,46⟩,⟨63,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨1,1466112759643916922668⟩,⟨239,478⟩]
private def b30697 : Box := ![⟨38,46⟩,⟨63,126⟩,⟨31,1920000000000000011376⟩,⟨1,1466112759643916922662⟩,⟨239,478⟩]
private def b30698 : Box := ![⟨38,46⟩,⟨63,126⟩,⟨31,1920000000000000011376⟩,⟨1,2⟩,⟨239,478⟩]
private def b30699 : Box := ![⟨38,46⟩,⟨63,126⟩,⟨31,1920000000000000011376⟩,⟨3,900178041543026711623⟩,⟨239,478⟩]
private def b30700 : Box := ![⟨38,46⟩,⟨63,126⟩,⟨31,62⟩,⟨3,900178041543026711623⟩,⟨239,478⟩]
private def b30701 : Box := ![⟨38,46⟩,⟨63,126⟩,⟨31,62⟩,⟨3,6⟩,⟨239,478⟩]
private def b30702 : Box := ![⟨38,41⟩,⟨63,126⟩,⟨31,62⟩,⟨3,6⟩,⟨239,478⟩]
private def b30703 : Box := ![⟨38,41⟩,⟨63,126⟩,⟨31,41⟩,⟨3,6⟩,⟨239,478⟩]
private def b30704 : Box := ![⟨38,41⟩,⟨63,123⟩,⟨31,41⟩,⟨3,6⟩,⟨239,318⟩]
private def b30705 : Box := ![⟨38,41⟩,⟨63,83⟩,⟨31,41⟩,⟨3,6⟩,⟨239,317⟩]
private def b30706 : Box := ![⟨38,41⟩,⟨63,83⟩,⟨31,41⟩,⟨3,6⟩,⟨239,272⟩]
private def b30707 : Box := ![⟨38,41⟩,⟨63,71⟩,⟨31,41⟩,⟨3,6⟩,⟨239,271⟩]
private def b30714 : Box := ![⟨38,41⟩,⟨72,83⟩,⟨31,41⟩,⟨3,6⟩,⟨239,271⟩]
private def b30721 : Box := ![⟨38,41⟩,⟨63,83⟩,⟨31,41⟩,⟨3,6⟩,⟨273,317⟩]
private def b30722 : Box := ![⟨38,41⟩,⟨63,71⟩,⟨31,41⟩,⟨3,6⟩,⟨277,317⟩]
private def b30729 : Box := ![⟨38,41⟩,⟨72,83⟩,⟨31,41⟩,⟨3,6⟩,⟨277,317⟩]
private def b30730 : Box := ![⟨38,39⟩,⟨72,83⟩,⟨31,41⟩,⟨3,6⟩,⟨277,317⟩]
private def b30737 : Box := ![⟨40,41⟩,⟨72,83⟩,⟨31,41⟩,⟨3,6⟩,⟨277,317⟩]
private def b30742 : Box := ![⟨38,41⟩,⟨84,122⟩,⟨31,41⟩,⟨3,6⟩,⟨239,317⟩]
private def b30751 : Box := ![⟨38,41⟩,⟨63,123⟩,⟨31,41⟩,⟨3,6⟩,⟨319,478⟩]
private def b30752 : Box := ![⟨38,41⟩,⟨63,83⟩,⟨31,41⟩,⟨3,6⟩,⟨319,478⟩]
private def b30753 : Box := ![⟨38,41⟩,⟨63,83⟩,⟨31,41⟩,⟨3,6⟩,⟨319,382⟩]
private def b30754 : Box := ![⟨38,41⟩,⟨63,71⟩,⟨31,41⟩,⟨3,6⟩,⟨331,379⟩]
private def b30759 : Box := ![⟨38,41⟩,⟨72,83⟩,⟨31,41⟩,⟨3,6⟩,⟨331,379⟩]
private def b30760 : Box := ![⟨38,39⟩,⟨72,83⟩,⟨31,41⟩,⟨3,6⟩,⟨331,379⟩]
private def b30765 : Box := ![⟨40,41⟩,⟨72,83⟩,⟨31,41⟩,⟨3,6⟩,⟨331,379⟩]
private def b30772 : Box := ![⟨38,41⟩,⟨63,83⟩,⟨31,41⟩,⟨3,6⟩,⟨383,478⟩]
private def b30773 : Box := ![⟨38,41⟩,⟨63,71⟩,⟨31,41⟩,⟨3,6⟩,⟨383,467⟩]
private def b30778 : Box := ![⟨38,41⟩,⟨72,83⟩,⟨31,41⟩,⟨3,6⟩,⟨383,467⟩]
private def b30789 : Box := ![⟨38,41⟩,⟨84,123⟩,⟨31,41⟩,⟨3,6⟩,⟨319,478⟩]
private def b30790 : Box := ![⟨38,41⟩,⟨84,123⟩,⟨31,41⟩,⟨3,6⟩,⟨319,382⟩]
private def b30791 : Box := ![⟨38,41⟩,⟨84,99⟩,⟨31,41⟩,⟨3,6⟩,⟨331,379⟩]
private def b30792 : Box := ![⟨38,39⟩,⟨84,99⟩,⟨31,41⟩,⟨3,6⟩,⟨331,379⟩]
private def b30799 : Box := ![⟨40,41⟩,⟨84,99⟩,⟨31,41⟩,⟨3,6⟩,⟨331,379⟩]
private def b30804 : Box := ![⟨38,41⟩,⟨100,123⟩,⟨31,41⟩,⟨3,6⟩,⟨331,379⟩]
private def b30811 : Box := ![⟨38,41⟩,⟨84,123⟩,⟨31,41⟩,⟨3,6⟩,⟨383,478⟩]
private def b30812 : Box := ![⟨38,41⟩,⟨84,99⟩,⟨31,41⟩,⟨3,6⟩,⟨383,467⟩]
private def b30813 : Box := ![⟨38,39⟩,⟨84,99⟩,⟨31,41⟩,⟨3,6⟩,⟨383,467⟩]
private def b30820 : Box := ![⟨40,41⟩,⟨84,99⟩,⟨31,41⟩,⟨3,6⟩,⟨383,467⟩]
private def b30827 : Box := ![⟨38,41⟩,⟨100,123⟩,⟨31,41⟩,⟨3,6⟩,⟨383,467⟩]
private def b30828 : Box := ![⟨38,39⟩,⟨100,123⟩,⟨31,41⟩,⟨3,6⟩,⟨383,467⟩]
private def b30837 : Box := ![⟨40,41⟩,⟨100,123⟩,⟨31,41⟩,⟨3,6⟩,⟨383,467⟩]
private def b30842 : Box := ![⟨38,41⟩,⟨63,126⟩,⟨42,62⟩,⟨3,6⟩,⟨239,478⟩]
private def b30843 : Box := ![⟨42,46⟩,⟨63,126⟩,⟨31,62⟩,⟨3,6⟩,⟨239,478⟩]
private def b30844 : Box := ![⟨42,46⟩,⟨63,84⟩,⟨31,62⟩,⟨3,6⟩,⟨277,478⟩]
private def b30845 : Box := ![⟨42,46⟩,⟨63,84⟩,⟨31,62⟩,⟨3,6⟩,⟨277,350⟩]
private def b30854 : Box := ![⟨42,46⟩,⟨63,84⟩,⟨31,62⟩,⟨3,6⟩,⟨351,478⟩]
private def b30855 : Box := ![⟨42,46⟩,⟨63,84⟩,⟨31,41⟩,⟨3,6⟩,⟨353,467⟩]
private def b30856 : Box := ![⟨42,43⟩,⟨63,84⟩,⟨31,41⟩,⟨3,6⟩,⟨353,467⟩]
private def b30857 : Box := ![⟨42,43⟩,⟨63,72⟩,⟨31,41⟩,⟨3,6⟩,⟨353,467⟩]
private def b30862 : Box := ![⟨42,43⟩,⟨73,84⟩,⟨31,41⟩,⟨3,6⟩,⟨353,467⟩]
private def b30863 : Box := ![⟨42,43⟩,⟨73,84⟩,⟨31,41⟩,⟨3,6⟩,⟨353,402⟩]
private def b30868 : Box := ![⟨42,43⟩,⟨73,84⟩,⟨31,41⟩,⟨3,6⟩,⟨403,467⟩]
private def b30875 : Box := ![⟨44,46⟩,⟨63,84⟩,⟨31,41⟩,⟨3,6⟩,⟨353,467⟩]
private def b30884 : Box := ![⟨42,46⟩,⟨63,84⟩,⟨42,62⟩,⟨3,6⟩,⟨353,467⟩]
private def b30893 : Box := ![⟨42,46⟩,⟨85,126⟩,⟨31,62⟩,⟨3,6⟩,⟨277,478⟩]
private def b30896 : Box := ![⟨38,46⟩,⟨63,126⟩,⟨31,62⟩,⟨7,78⟩,⟨239,478⟩]
private def b30897 : Box := ![⟨38,46⟩,⟨63,126⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711623⟩,⟨239,478⟩]
private def b30906 : Box := ![⟨38,46⟩,⟨127,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨1,1466112759643916922662⟩,⟨239,478⟩]
private theorem e30698 : Deny 5 13 b30698 := by
    apply closeAction rule_sound _ _ 64 [0x5e2]
    decide +kernel
private theorem e30707 : Deny 5 13 b30707 := by
    apply closeAction rule_sound _ _ 64 [0x16e370c90c31c7]
    decide +kernel
private theorem e30714 : Deny 5 13 b30714 := by
    apply closeAction rule_sound _ _ 64 [0x16e375b8dc30c8247]
    decide +kernel
private theorem e30706 : Deny 5 13 b30706 :=
    branchAction rule_sound _ _ 2
      0x204 b30706 b30707 b30714 (by decide +kernel) e30707 e30714
private theorem e30722 : Deny 5 13 b30722 := by
    apply closeAction rule_sound _ _ 64 [0xc31c30f8df61c7]
    decide +kernel
private theorem e30730 : Deny 5 13 b30730 := by
    apply closeAction rule_sound _ _ 64 [0x160c90c3209]
    decide +kernel
private theorem e30737 : Deny 5 13 b30737 := by
    apply closeAction rule_sound _ _ 64 [0x16e370f8dc3209]
    decide +kernel
private theorem e30729 : Deny 5 13 b30729 :=
    branchAction rule_sound _ _ 1
      0x7 b30729 b30730 b30737 (by decide +kernel) e30730 e30737
private theorem e30721 : Deny 5 13 b30721 :=
    branchAction rule_sound _ _ 2
      0x204 b30721 b30722 b30729 (by decide +kernel) e30722 e30729
private theorem e30705 : Deny 5 13 b30705 :=
    branchAction rule_sound _ _ 1
      0xb b30705 b30706 b30721 (by decide +kernel) e30706 e30721
private theorem e30742 : Deny 5 13 b30742 := by
    apply closeAction rule_sound _ _ 64 [0x25b8dd6e370f80c82488441f8]
    decide +kernel
private theorem e30704 : Deny 5 13 b30704 :=
    branchAction rule_sound _ _ 3
      0x8844 b30704 b30705 b30742 (by decide +kernel) e30705 e30742
private theorem e30754 : Deny 5 13 b30754 := by
    apply closeAction rule_sound _ _ 64 [0x30f61dfe37d87]
    decide +kernel
private theorem e30760 : Deny 5 13 b30760 := by
    apply closeAction rule_sound _ _ 64 [0xc3e37243e37d87]
    decide +kernel
private theorem e30765 : Deny 5 13 b30765 := by
    apply closeAction rule_sound _ _ 64 [0x160c90c3209]
    decide +kernel
private theorem e30759 : Deny 5 13 b30759 :=
    branchAction rule_sound _ _ 1
      0x7 b30759 b30760 b30765 (by decide +kernel) e30760 e30765
private theorem e30753 : Deny 5 13 b30753 :=
    branchAction rule_sound _ _ 2
      0x204 b30753 b30754 b30759 (by decide +kernel) e30754 e30759
private theorem e30773 : Deny 5 13 b30773 := by
    apply closeAction rule_sound _ _ 64 [0x37f8dc9087e36]
    decide +kernel
private theorem e30778 : Deny 5 13 b30778 := by
    apply closeAction rule_sound _ _ 64 [0x5832430f8dc8256089e37d87]
    decide +kernel
private theorem e30772 : Deny 5 13 b30772 :=
    branchAction rule_sound _ _ 2
      0x204 b30772 b30773 b30778 (by decide +kernel) e30773 e30778
private theorem e30752 : Deny 5 13 b30752 :=
    branchAction rule_sound _ _ 1
      0xb b30752 b30753 b30772 (by decide +kernel) e30753 e30772
private theorem e30792 : Deny 5 13 b30792 := by
    apply closeAction rule_sound _ _ 64 [0x160c90c3209]
    decide +kernel
private theorem e30799 : Deny 5 13 b30799 := by
    apply closeAction rule_sound _ _ 64 [0x25f8dc3209]
    decide +kernel
private theorem e30791 : Deny 5 13 b30791 :=
    branchAction rule_sound _ _ 1
      0x7 b30791 b30792 b30799 (by decide +kernel) e30792 e30799
private theorem e30804 : Deny 5 13 b30804 := by
    apply closeAction rule_sound _ _ 64 [0x25b8dc3e370c7849847]
    decide +kernel
private theorem e30790 : Deny 5 13 b30790 :=
    branchAction rule_sound _ _ 2
      0x204 b30790 b30791 b30804 (by decide +kernel) e30791 e30804
private theorem e30813 : Deny 5 13 b30813 := by
    apply closeAction rule_sound _ _ 64 [0x583243103e37108e09]
    decide +kernel
private theorem e30820 : Deny 5 13 b30820 := by
    apply closeAction rule_sound _ _ 64 [0x7f858a0c3209]
    decide +kernel
private theorem e30812 : Deny 5 13 b30812 :=
    branchAction rule_sound _ _ 1
      0x7 b30812 b30813 b30820 (by decide +kernel) e30813 e30820
private theorem e30828 : Deny 5 13 b30828 := by
    apply closeAction rule_sound _ _ 64 [0x5b8dd60e12611c30f81e1261]
    decide +kernel
private theorem e30837 : Deny 5 13 b30837 := by
    apply closeAction rule_sound _ _ 64 [0x2083847844278]
    decide +kernel
private theorem e30827 : Deny 5 13 b30827 :=
    branchAction rule_sound _ _ 1
      0x7 b30827 b30828 b30837 (by decide +kernel) e30828 e30837
private theorem e30811 : Deny 5 13 b30811 :=
    branchAction rule_sound _ _ 2
      0x204 b30811 b30812 b30827 (by decide +kernel) e30812 e30827
private theorem e30789 : Deny 5 13 b30789 :=
    branchAction rule_sound _ _ 1
      0xb b30789 b30790 b30811 (by decide +kernel) e30790 e30811
private theorem e30751 : Deny 5 13 b30751 :=
    branchAction rule_sound _ _ 1
      0x8 b30751 b30752 b30789 (by decide +kernel) e30752 e30789
private theorem e30703 : Deny 5 13 b30703 :=
    branchAction rule_sound _ _ 2
      0x2e1 b30703 b30704 b30751 (by decide +kernel) e30704 e30751
private theorem e30842 : Deny 5 13 b30842 := by
    apply closeAction rule_sound _ _ 64 [0x16]
    decide +kernel
private theorem e30702 : Deny 5 13 b30702 :=
    branchAction rule_sound _ _ 1
      0x9 b30702 b30703 b30842 (by decide +kernel) e30703 e30842
private theorem e30845 : Deny 5 13 b30845 := by
    apply closeAction rule_sound _ _ 64 [0x97e375f8dd6e370c9207244]
    decide +kernel
private theorem e30857 : Deny 5 13 b30857 := by
    apply closeAction rule_sound _ _ 64 [0xf80c80c9]
    decide +kernel
private theorem e30863 : Deny 5 13 b30863 := by
    apply closeAction rule_sound _ _ 64 [0x97e370c8244]
    decide +kernel
private theorem e30868 : Deny 5 13 b30868 := by
    apply closeAction rule_sound _ _ 64 [0x20c4238dc30c8244]
    decide +kernel
private theorem e30862 : Deny 5 13 b30862 :=
    branchAction rule_sound _ _ 1
      0xb b30862 b30863 b30868 (by decide +kernel) e30863 e30868
private theorem e30856 : Deny 5 13 b30856 :=
    branchAction rule_sound _ _ 1
      0x8 b30856 b30857 b30862 (by decide +kernel) e30857 e30862
private theorem e30875 : Deny 5 13 b30875 := by
    apply closeAction rule_sound _ _ 64 [0x5f8ddfe047f80c8109e17288]
    decide +kernel
private theorem e30855 : Deny 5 13 b30855 :=
    branchAction rule_sound _ _ 1
      0x7 b30855 b30856 b30875 (by decide +kernel) e30856 e30875
private theorem e30884 : Deny 5 13 b30884 := by
    apply closeAction rule_sound _ _ 64 [0x825b8dd60c82481f8]
    decide +kernel
private theorem e30854 : Deny 5 13 b30854 :=
    branchAction rule_sound _ _ 2
      0x244 b30854 b30855 b30884 (by decide +kernel) e30855 e30884
private theorem e30844 : Deny 5 13 b30844 :=
    branchAction rule_sound _ _ 1
      0xb b30844 b30845 b30854 (by decide +kernel) e30845 e30854
private theorem e30893 : Deny 5 13 b30893 := by
    apply closeAction rule_sound _ _ 64 [0x97de1109e37]
    decide +kernel
private theorem e30843 : Deny 5 13 b30843 :=
    branchAction rule_sound _ _ 2
      0x238 b30843 b30844 b30893 (by decide +kernel) e30844 e30893
private theorem e30701 : Deny 5 13 b30701 :=
    branchAction rule_sound _ _ 1
      0x7 b30701 b30702 b30843 (by decide +kernel) e30702 e30843
private theorem e30896 : Deny 5 13 b30896 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e30700 : Deny 5 13 b30700 :=
    branchAction rule_sound _ _ 2
      0x2a3 b30700 b30701 b30896 (by decide +kernel) e30701 e30896
private theorem e30897 : Deny 5 13 b30897 := by
    apply closeAction rule_sound _ _ 64 [0x25b8dd4e37bdf5a22a32632231f8]
    decide +kernel
private theorem e30699 : Deny 5 13 b30699 :=
    branchAction rule_sound _ _ 1
      0x9 b30699 b30700 b30897 (by decide +kernel) e30700 e30897
private theorem e30697 : Deny 5 13 b30697 :=
    branchAction rule_sound _ _ 2
      0x2a3 b30697 b30698 b30699 (by decide +kernel) e30698 e30699
private theorem e30906 : Deny 5 13 b30906 := by
    apply closeAction rule_sound _ _ 64 [0x96e377eb849849e37]
    decide +kernel
private theorem e30696 : Deny 5 13 b30696 :=
    branchAction rule_sound _ _ 2
      0x223 b30696 b30697 b30906 (by decide +kernel) e30697 e30906
theorem deny5_13 : Deny 5 13 ![⟨38,46⟩,⟨63,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨1,1466112759643916922668⟩,⟨239,478⟩] := by
  exact e30696
end OMA.Blocks5_13_245212.S30696
