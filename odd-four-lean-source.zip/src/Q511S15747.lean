import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S15747
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b15747 : Box := ![⟨23,30⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨1,994807017543859655053⟩,⟨103,999999999999999999⟩]
theorem deny5_11 : Deny 5 11 ![⟨23,30⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨1,994807017543859655053⟩,⟨103,999999999999999999⟩] := by
  have e15747 : Deny 5 11 b15747 := by
    apply closeAction rule_sound _ _ 64 [0xbc3738df68c71022388c972f1021f8df68c71028842b88c80efb6c88a0c3e378c90f8df68c70f8df62022378c98cbe23,0x8c88c92dcbdcbe326f0c22021c4088e368c98c472f72f8c9bc30f8be31ef0e3243e37da322324b0f888a8c772f72f8c9,0xda372f72f8c9bc3e038c70e324388a0f6087e37da3223263102be311cbe3109e2f083bc41f8dc40e3109e0388a0c3dc7,0x72f709bdce1c21c1e3243e2f88a72f1021f8d888c42d4283738df68c7d84088e368c972f8c472f8c4278df61c288a088,0x1cbdc26f723242be2282223]
    decide +kernel
  exact e15747
end OMA.Blocks5_11_245212.S15747
