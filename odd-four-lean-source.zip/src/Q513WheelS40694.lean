import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S40694
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b40694 : Box := ![⟨63,94⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨3,1017986577181208059767⟩,⟨127,164⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨3,1017986577181208059767⟩,⟨127,164⟩] := by
  have e40694 : Deny 5 13 b40694 := by
    apply closeAction rule_sound _ _ 64 [0xde37c9e17e37578dc3dc3247255dc3dc38870c98870c32430c91c92045f8dd5e37578dc3dc324724810b2a31e3263204,0x2e370941f8dd5e377f8]
    decide +kernel
  exact e40694
end OMA.Blocks5_13_245212.S40694
