import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S22390
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b22390 : Box := ![⟨31,46⟩,⟨31,62⟩,⟨15,30⟩,⟨3,1129131513647642686639⟩,⟨79,113⟩]
theorem deny5_13 : Deny 5 13 ![⟨31,46⟩,⟨31,62⟩,⟨15,30⟩,⟨3,1129131513647642686639⟩,⟨79,113⟩] := by
  have e22390 : Deny 5 13 b22390 := by
    apply closeAction rule_sound _ _ 64 [0xdf6204088e371c30f8dc97f8df6204087e09117e370c9dc30c72030c80c3dc92070c32430c92030f8dc91c910b2072a3,0x820c7109e375f8dc40c4278dc31c81d7e375f8dc3e370c91c80f8dc32431c30c92072442c30c70c90c3e37d872030f8,0x10b0c3203e371c81c3dc31c30f71c9117e370c7dc3dc31c910b0c32432080c3e37243e37d870c4087e37d881c9117e37,0xdd7e370c91d7dc42f8dc3dc32030c81c45f70f70c81c42c80f70c80c70c3dc72440831f8dc3e031c90972831c30c724a,0x2780c820a1c427811f5cae020c42780f80c72077d70f80c82430c90c3e092072891020820f80c92072442c42385ca5f8,0x7c209f0820c7109e020c4]
    decide +kernel
  exact e22390
end OMA.Blocks5_13_245212.S22390
