import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S56911
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b56911 : Box := ![⟨63,94⟩,⟨31,62⟩,⟨15,30⟩,⟨3,6⟩,⟨127,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨31,62⟩,⟨15,30⟩,⟨3,6⟩,⟨127,233⟩] := by
  have e56911 : Deny 5 13 b56911 := by
    apply closeAction rule_sound _ _ 64 [0xe37103107e032497d70c92972830c80c72445f8dc31c3dc32031c910b2091c4082097e37083108e370c724824710b238,0x17e370825f8dd7e370f8dc3207248109e025f8dd7e375f8dc32091c42385f8dd7]
    decide +kernel
  exact e56911
end OMA.Blocks5_13_245212.S56911
