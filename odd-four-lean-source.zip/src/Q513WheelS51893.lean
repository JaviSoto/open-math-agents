import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S51893
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b51893 : Box := ![⟨383,1920000000000000011376⟩,⟨21,24⟩,⟨15,30⟩,⟨3,342194907813871819445⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨383,1920000000000000011376⟩,⟨21,24⟩,⟨15,30⟩,⟨3,342194907813871819445⟩,⟨479,999999999999999999⟩] := by
  have e51893 : Deny 5 13 b51893 := by
    apply closeAction rule_sound _ _ 64 [0x2276678c79d99e31e76670879e31e7089db42278c98d99e32e36678cb8d99e32e36678cb8d99e32e36678cb8d99e32e7,0x6678c79d99d966708324220224744b2a36678cb8d99e32e36678cbda31e36678cb8d99e32f69e31c20998c7e02242267,0x2d12d12d12e02912d12e02a36678cb8d99e32e36678cb8d99e32e36678cb9e31e78c80820999e31c22489d99e31e3267,0x20820820820c98c72098c79e32678c70826678c79d99e31e32676590999d90e02822761e02192512d1]
    decide +kernel
  exact e51893
end OMA.Blocks5_13_245212.S51893
