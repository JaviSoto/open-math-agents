import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S16900
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b16900 : Box := ![⟨23,46⟩,⟨15,30⟩,⟨7,14⟩,⟨1,1210212765957446815720⟩,⟨59,113⟩]
theorem deny5_13 : Deny 5 13 ![⟨23,46⟩,⟨15,30⟩,⟨7,14⟩,⟨1,1210212765957446815720⟩,⟨59,113⟩] := by
  have e16900 : Deny 5 13 b16900 := by
    apply closeAction rule_sound _ _ 64 [0xe23243103e37da3107e368c80c3e37d87088e36283102238df68c7df68c810b1030f8df68c9088087e37db58c41f8de3,0xd8a1020c90c32475c3257d872842c30f8dc72030f8df51c4089e372430f8243e37d870f8df620408ae361ca0c3e231c3,0xdc42c30e31e32030e31c3e232632430e32438c70c3e378c78c80c3e37da31c40f8df68c42388c98c70c32430f8dc91d7,0x1021f8df620a10b0c2242238de325f0f8df58c4278df68c77c2238df68c8df6d63103e370e32430e32631e3102083247,0xc21c22378c47df0e32632430f8df61c3]
    decide +kernel
  exact e16900
end OMA.Blocks5_13_245212.S16900
