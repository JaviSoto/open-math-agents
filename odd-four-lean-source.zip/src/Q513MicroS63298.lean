import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S63298
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b63298 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨12,14⟩,⟨5,51⟩,⟨479,958⟩]
private def b63299 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨12,14⟩,⟨10,51⟩,⟨479,638⟩]
private def b63300 : Box := ![⟨153,190⟩,⟨31,32⟩,⟨12,14⟩,⟨10,51⟩,⟨479,638⟩]
private def b63307 : Box := ![⟨153,190⟩,⟨33,35⟩,⟨12,14⟩,⟨10,51⟩,⟨479,638⟩]
private def b63312 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨12,14⟩,⟨10,51⟩,⟨639,958⟩]
private def b63313 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨12,14⟩,⟨10,17⟩,⟨639,958⟩]
private def b63314 : Box := ![⟨153,190⟩,⟨31,32⟩,⟨12,14⟩,⟨10,17⟩,⟨639,958⟩]
private def b63319 : Box := ![⟨153,190⟩,⟨33,35⟩,⟨12,14⟩,⟨10,17⟩,⟨639,958⟩]
private def b63326 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨12,14⟩,⟨18,49⟩,⟨639,958⟩]
private theorem e63300 : Deny 5 13 b63300 := by
    apply closeAction rule_sound _ _ 64 [0x6420c41f80e724a9e3]
    decide +kernel
private theorem e63307 : Deny 5 13 b63307 := by
    apply closeAction rule_sound _ _ 64 [0x820e3107e278c4278]
    decide +kernel
private theorem e63299 : Deny 5 13 b63299 :=
    branchAction rule_sound _ _ 1
      0x8 b63299 b63300 b63307 (by decide +kernel) e63300 e63307
private theorem e63314 : Deny 5 13 b63314 := by
    apply closeAction rule_sound _ _ 64 [0x7c39c90f89c9]
    decide +kernel
private theorem e63319 : Deny 5 13 b63319 := by
    apply closeAction rule_sound _ _ 64 [0x20c8e03e270c79c9]
    decide +kernel
private theorem e63313 : Deny 5 13 b63313 :=
    branchAction rule_sound _ _ 1
      0x8 b63313 b63314 b63319 (by decide +kernel) e63314 e63319
private theorem e63326 : Deny 5 13 b63326 := by
    apply closeAction rule_sound _ _ 64 [0x19]
    decide +kernel
private theorem e63312 : Deny 5 13 b63312 :=
    branchAction rule_sound _ _ 2
      0x2a3 b63312 b63313 b63326 (by decide +kernel) e63313 e63326
private theorem e63298 : Deny 5 13 b63298 :=
    branchAction rule_sound _ _ 2
      0x2e7 b63298 b63299 b63312 (by decide +kernel) e63299 e63312
theorem deny5_13 : Deny 5 13 ![⟨153,190⟩,⟨31,35⟩,⟨12,14⟩,⟨5,51⟩,⟨479,958⟩] := by
  exact e63298
end OMA.Blocks5_13_245212.S63298
