import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S7268
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b7268 : Box := ![⟨11,14⟩,⟨15,1920000000000000011376⟩,⟨7,1920000000000000011376⟩,⟨1,1920000000000000011376⟩,⟨89,320⟩]
private def b7269 : Box := ![⟨11,14⟩,⟨23,46⟩,⟨10,1920000000000000011376⟩,⟨1,1718260869565217401512⟩,⟨89,320⟩]
private def b7290 : Box := ![⟨11,14⟩,⟨47,1920000000000000011376⟩,⟨10,1920000000000000011376⟩,⟨1,1718260869565217401512⟩,⟨89,320⟩]
private def b7291 : Box := ![⟨11,12⟩,⟨47,1920000000000000011376⟩,⟨11,1920000000000000011376⟩,⟨1,1718260869565217401512⟩,⟨89,320⟩]
private def b7312 : Box := ![⟨13,14⟩,⟨47,1920000000000000011376⟩,⟨11,1920000000000000011376⟩,⟨1,1718260869565217401512⟩,⟨89,320⟩]
private def b7313 : Box := ![⟨13,14⟩,⟨47,1920000000000000011376⟩,⟨11,22⟩,⟨1,1718260869565217401512⟩,⟨89,320⟩]
private def b7328 : Box := ![⟨13,14⟩,⟨47,1920000000000000011376⟩,⟨23,1920000000000000011376⟩,⟨1,1718260869565217401512⟩,⟨89,320⟩]
private def b7329 : Box := ![⟨13,14⟩,⟨47,1920000000000000011376⟩,⟨23,1920000000000000011376⟩,⟨1,1718260869565217401512⟩,⟨89,139⟩]
private def b7484 : Box := ![⟨13,14⟩,⟨47,1920000000000000011376⟩,⟨23,1920000000000000011376⟩,⟨1,1718260869565217401512⟩,⟨140,320⟩]
theorem deny5_11 : Deny 5 11 ![⟨11,14⟩,⟨15,1920000000000000011376⟩,⟨7,1920000000000000011376⟩,⟨1,1920000000000000011376⟩,⟨89,320⟩] := by
  have e7269 : Deny 5 11 b7269 := by
    apply closeAction rule_sound _ _ 64 [0x71cbc42ef7af8c9783e3629ee37da3202204087e37da324288a738df68c81021f8df6d63]
    decide +kernel
  have e7291 : Deny 5 11 b7291 := by
    apply closeAction rule_sound _ _ 64 [0x1e5aa7a222229629aac47ab8c4238df58c97af78911ce37da3108e37da3216e36d622b51021f8df6d63]
    decide +kernel
  have e7313 : Deny 5 11 b7313 := by
    apply closeAction rule_sound _ _ 64 [0x1aade689ac4689e36ae321e6b8df58c4278db58c80a12b5102aa110ae37d63]
    decide +kernel
  have e7329 : Deny 5 11 b7329 := by
    apply closeAction rule_sound _ _ 64 [0x2761160c3e3784984910b583e09116e37d84238d8828a596e37db5849e0a11ee37db5107e232632165aa849a9688888a,0x2477895a2282be311ebe3109e2f79e58a88a8c972f7af8c9bc47b8df68c4278da31e32042d688a79e596089102238d61,0x8c909c238be311e2785afb6229e58a8c972f709bc4789e37d8772f7af8c97a325ee37da22821e322309cbe311c278bde,0x6ab6ab8c8adeade796aa110ae2110ae2321eae325ae37db51e32236ab6ab8c8ade796aa12a129eae32632042d6aea84a,0x27962b86b8ade2232475aa88a79e88a58a8c88c2082aea849e3779e8842b858a8c81e310b58a]
    decide +kernel
  have e7484 : Deny 5 11 b7484 := by
    apply closeAction rule_sound _ _ 64 [0x2821e322310b58a6ab7ab8c8df6d631021f8d6325cbde26f7b8df68c9738df68c8df6d631021f8df68c85b8db588ad63,0x788e358c95aa88a7af11ee37db58c4278da32021f58c4096e377898c8e1aade22325e5b8db588ae361d6aa229e7a2296,0x796aa211623888a6ab]
    decide +kernel
  have e7328 : Deny 5 11 b7328 :=
    branchAction rule_sound _ _ 1
      0xb b7328 b7329 b7484 (by decide +kernel) e7329 e7484
  have e7312 : Deny 5 11 b7312 :=
    branchAction rule_sound _ _ 1
      0x9 b7312 b7313 b7328 (by decide +kernel) e7313 e7328
  have e7290 : Deny 5 11 b7290 :=
    branchAction rule_sound _ _ 2
      0x1f6 b7290 b7291 b7312 (by decide +kernel) e7291 e7312
  have e7268 : Deny 5 11 b7268 :=
    branchAction rule_sound _ _ 4
      0x236d63 b7268 b7269 b7290 (by decide +kernel) e7269 e7290
  exact e7268
end OMA.Blocks5_11_245212.S7268
