import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S63254
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b63254 : Box := ![⟨127,190⟩,⟨36,41⟩,⟨10,11⟩,⟨5,52⟩,⟨479,958⟩]
private def b63255 : Box := ![⟨127,152⟩,⟨36,41⟩,⟨10,11⟩,⟨5,52⟩,⟨479,958⟩]
private def b63256 : Box := ![⟨127,152⟩,⟨36,41⟩,⟨10,11⟩,⟨5,45⟩,⟨479,638⟩]
private def b63263 : Box := ![⟨127,152⟩,⟨36,41⟩,⟨10,11⟩,⟨5,45⟩,⟨639,958⟩]
private def b63270 : Box := ![⟨153,190⟩,⟨36,41⟩,⟨10,11⟩,⟨5,52⟩,⟨479,958⟩]
private theorem e63256 : Deny 5 13 b63256 := by
    apply closeAction rule_sound _ _ 64 [0x39c38c70e70e31e78c8]
    decide +kernel
private theorem e63263 : Deny 5 13 b63263 := by
    apply closeAction rule_sound _ _ 64 [0xe70f88c70c22789e3223]
    decide +kernel
private theorem e63255 : Deny 5 13 b63255 :=
    branchAction rule_sound _ _ 2
      0x2e3 b63255 b63256 b63263 (by decide +kernel) e63256 e63263
private theorem e63270 : Deny 5 13 b63270 := by
    apply closeAction rule_sound _ _ 64 [0x1b0f89e30e31f86c99e3227]
    decide +kernel
private theorem e63254 : Deny 5 13 b63254 :=
    branchAction rule_sound _ _ 1
      0x7 b63254 b63255 b63270 (by decide +kernel) e63255 e63270
theorem deny5_13 : Deny 5 13 ![⟨127,190⟩,⟨36,41⟩,⟨10,11⟩,⟨5,52⟩,⟨479,958⟩] := by
  exact e63254
end OMA.Blocks5_13_245212.S63254
