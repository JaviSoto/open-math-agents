import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S55695
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b55695 : Box := ![⟨63,94⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨1,565934718100890211111⟩,⟨239,478⟩]
private def b55696 : Box := ![⟨63,94⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨1,2⟩,⟨239,478⟩]
private def b55697 : Box := ![⟨63,94⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨3,565934718100890211105⟩,⟨239,478⟩]
private def b55698 : Box := ![⟨63,94⟩,⟨63,126⟩,⟨10,14⟩,⟨3,565934718100890211105⟩,⟨239,478⟩]
private def b55699 : Box := ![⟨63,75⟩,⟨63,126⟩,⟨10,14⟩,⟨3,65⟩,⟨239,478⟩]
private def b55700 : Box := ![⟨63,75⟩,⟨63,126⟩,⟨10,14⟩,⟨3,62⟩,⟨239,318⟩]
private def b55701 : Box := ![⟨63,75⟩,⟨63,126⟩,⟨10,11⟩,⟨3,61⟩,⟨239,317⟩]
private def b55702 : Box := ![⟨63,75⟩,⟨63,84⟩,⟨10,11⟩,⟨3,60⟩,⟨239,317⟩]
private def b55703 : Box := ![⟨63,68⟩,⟨63,84⟩,⟨10,11⟩,⟨3,48⟩,⟨239,317⟩]
private def b55704 : Box := ![⟨63,68⟩,⟨63,84⟩,⟨10,11⟩,⟨3,46⟩,⟨239,272⟩]
private def b55711 : Box := ![⟨63,68⟩,⟨63,84⟩,⟨10,11⟩,⟨3,46⟩,⟨273,317⟩]
private def b55718 : Box := ![⟨69,75⟩,⟨63,84⟩,⟨10,11⟩,⟨3,48⟩,⟨239,317⟩]
private def b55723 : Box := ![⟨63,75⟩,⟨85,126⟩,⟨10,11⟩,⟨3,60⟩,⟨239,317⟩]
private def b55730 : Box := ![⟨63,75⟩,⟨63,126⟩,⟨12,14⟩,⟨3,61⟩,⟨239,317⟩]
private def b55739 : Box := ![⟨63,75⟩,⟨63,126⟩,⟨10,14⟩,⟨3,62⟩,⟨319,478⟩]
private def b55740 : Box := ![⟨63,75⟩,⟨63,126⟩,⟨10,11⟩,⟨3,58⟩,⟨319,478⟩]
private def b55741 : Box := ![⟨63,75⟩,⟨63,84⟩,⟨10,11⟩,⟨3,57⟩,⟨319,478⟩]
private def b55742 : Box := ![⟨63,68⟩,⟨63,84⟩,⟨10,11⟩,⟨3,45⟩,⟨319,478⟩]
private def b55743 : Box := ![⟨63,68⟩,⟨63,84⟩,⟨10,11⟩,⟨3,44⟩,⟨319,382⟩]
private def b55750 : Box := ![⟨63,68⟩,⟨63,84⟩,⟨10,11⟩,⟨3,44⟩,⟨383,478⟩]
private def b55757 : Box := ![⟨69,75⟩,⟨63,84⟩,⟨10,11⟩,⟨3,45⟩,⟨319,478⟩]
private def b55758 : Box := ![⟨69,75⟩,⟨63,84⟩,⟨10,11⟩,⟨3,45⟩,⟨319,382⟩]
private def b55765 : Box := ![⟨69,75⟩,⟨63,84⟩,⟨10,11⟩,⟨3,45⟩,⟨383,478⟩]
private def b55772 : Box := ![⟨63,75⟩,⟨85,126⟩,⟨10,11⟩,⟨3,57⟩,⟨319,478⟩]
private def b55773 : Box := ![⟨63,68⟩,⟨85,126⟩,⟨10,11⟩,⟨3,57⟩,⟨319,478⟩]
private def b55774 : Box := ![⟨63,68⟩,⟨85,126⟩,⟨10,11⟩,⟨4,56⟩,⟨319,382⟩]
private def b55781 : Box := ![⟨63,68⟩,⟨85,126⟩,⟨10,11⟩,⟨4,56⟩,⟨383,478⟩]
private def b55788 : Box := ![⟨69,75⟩,⟨85,126⟩,⟨10,11⟩,⟨3,57⟩,⟨319,478⟩]
private def b55795 : Box := ![⟨63,75⟩,⟨63,126⟩,⟨12,14⟩,⟨3,58⟩,⟨319,478⟩]
private def b55796 : Box := ![⟨63,75⟩,⟨63,84⟩,⟨12,14⟩,⟨3,58⟩,⟨319,478⟩]
private def b55797 : Box := ![⟨63,68⟩,⟨63,84⟩,⟨12,14⟩,⟨3,47⟩,⟨319,478⟩]
private def b55798 : Box := ![⟨63,68⟩,⟨63,84⟩,⟨12,14⟩,⟨3,45⟩,⟨319,382⟩]
private def b55805 : Box := ![⟨63,68⟩,⟨63,84⟩,⟨12,14⟩,⟨3,45⟩,⟨383,478⟩]
private def b55814 : Box := ![⟨69,75⟩,⟨63,84⟩,⟨12,14⟩,⟨3,47⟩,⟨319,478⟩]
private def b55819 : Box := ![⟨63,75⟩,⟨85,126⟩,⟨12,14⟩,⟨3,58⟩,⟨319,478⟩]
private def b55822 : Box := ![⟨76,94⟩,⟨63,126⟩,⟨10,14⟩,⟨3,65⟩,⟨239,478⟩]
private def b55823 : Box := ![⟨76,94⟩,⟨63,126⟩,⟨10,11⟩,⟨3,65⟩,⟨297,478⟩]
private def b55824 : Box := ![⟨76,94⟩,⟨63,84⟩,⟨10,11⟩,⟨3,62⟩,⟨297,478⟩]
private def b55825 : Box := ![⟨76,84⟩,⟨63,84⟩,⟨10,11⟩,⟨3,50⟩,⟨297,478⟩]
private def b55826 : Box := ![⟨76,84⟩,⟨63,84⟩,⟨10,11⟩,⟨3,6⟩,⟨297,478⟩]
private def b55827 : Box := ![⟨76,84⟩,⟨63,84⟩,⟨10,11⟩,⟨7,48⟩,⟨297,478⟩]
private def b55838 : Box := ![⟨85,94⟩,⟨63,84⟩,⟨10,11⟩,⟨3,50⟩,⟨297,478⟩]
private def b55839 : Box := ![⟨76,94⟩,⟨85,126⟩,⟨10,11⟩,⟨3,62⟩,⟨297,478⟩]
private def b55840 : Box := ![⟨76,94⟩,⟨63,126⟩,⟨12,14⟩,⟨3,65⟩,⟨297,478⟩]
private def b55841 : Box := ![⟨63,94⟩,⟨127,1920000000000000011376⟩,⟨10,14⟩,⟨3,565934718100890211105⟩,⟨239,478⟩]
private theorem e55696 : Deny 5 13 b55696 := by
    apply closeAction rule_sound _ _ 64 [0x4e1]
    decide +kernel
private theorem e55704 : Deny 5 13 b55704 := by
    apply closeAction rule_sound _ _ 64 [0x832770f70e3263204]
    decide +kernel
private theorem e55711 : Deny 5 13 b55711 := by
    apply closeAction rule_sound _ _ 64 [0xf8dc38c90c3dc98c88c4]
    decide +kernel
private theorem e55703 : Deny 5 13 b55703 :=
    branchAction rule_sound _ _ 2
      0x2e3 b55703 b55704 b55711 (by decide +kernel) e55704 e55711
private theorem e55718 : Deny 5 13 b55718 := by
    apply closeAction rule_sound _ _ 64 [0x4f8dd3e370c98c8]
    decide +kernel
private theorem e55702 : Deny 5 13 b55702 :=
    branchAction rule_sound _ _ 2
      0x1e3 b55702 b55703 b55718 (by decide +kernel) e55703 e55718
private theorem e55723 : Deny 5 13 b55723 := by
    apply closeAction rule_sound _ _ 64 [0x20820e1107e2b849e2b847e37]
    decide +kernel
private theorem e55701 : Deny 5 13 b55701 :=
    branchAction rule_sound _ _ 2
      0x223 b55701 b55702 b55723 (by decide +kernel) e55702 e55723
private theorem e55730 : Deny 5 13 b55730 := by
    apply closeAction rule_sound _ _ 64 [0x820820c9207108e37]
    decide +kernel
private theorem e55700 : Deny 5 13 b55700 :=
    branchAction rule_sound _ _ 3
      0x98c4 b55700 b55701 b55730 (by decide +kernel) e55701 e55730
private theorem e55743 : Deny 5 13 b55743 := by
    apply closeAction rule_sound _ _ 64 [0x30f78c90dbe37263204]
    decide +kernel
private theorem e55750 : Deny 5 13 b55750 := by
    apply closeAction rule_sound _ _ 64 [0xc3e378c90c4089e378c88c4]
    decide +kernel
private theorem e55742 : Deny 5 13 b55742 :=
    branchAction rule_sound _ _ 2
      0x2e3 b55742 b55743 b55750 (by decide +kernel) e55743 e55750
private theorem e55758 : Deny 5 13 b55758 := by
    apply closeAction rule_sound _ _ 64 [0x4f8dc38c90f70e3263204]
    decide +kernel
private theorem e55765 : Deny 5 13 b55765 := by
    apply closeAction rule_sound _ _ 64 [0x3dc38c90c3e378c98c88c4]
    decide +kernel
private theorem e55757 : Deny 5 13 b55757 :=
    branchAction rule_sound _ _ 1
      0xb b55757 b55758 b55765 (by decide +kernel) e55758 e55765
private theorem e55741 : Deny 5 13 b55741 :=
    branchAction rule_sound _ _ 2
      0x1e3 b55741 b55742 b55757 (by decide +kernel) e55742 e55757
private theorem e55774 : Deny 5 13 b55774 := by
    apply closeAction rule_sound _ _ 64 [0x2ac20f8ac9ac38c88c88c4]
    decide +kernel
private theorem e55781 : Deny 5 13 b55781 := by
    apply closeAction rule_sound _ _ 64 [0x6c3e370eb8470eb84984a8c4]
    decide +kernel
private theorem e55773 : Deny 5 13 b55773 :=
    branchAction rule_sound _ _ 3
      0xbae3 b55773 b55774 b55781 (by decide +kernel) e55774 e55781
private theorem e55788 : Deny 5 13 b55788 := by
    apply closeAction rule_sound _ _ 64 [0x2ae3083e370f8ae31c9e23238]
    decide +kernel
private theorem e55772 : Deny 5 13 b55772 :=
    branchAction rule_sound _ _ 1
      0x7 b55772 b55773 b55788 (by decide +kernel) e55773 e55788
private theorem e55740 : Deny 5 13 b55740 :=
    branchAction rule_sound _ _ 2
      0x223 b55740 b55741 b55772 (by decide +kernel) e55741 e55772
private theorem e55798 : Deny 5 13 b55798 := by
    apply closeAction rule_sound _ _ 64 [0x20c9e370f70e31e3204]
    decide +kernel
private theorem e55805 : Deny 5 13 b55805 := by
    apply closeAction rule_sound _ _ 64 [0x93278dc38c90c38c78c88c4]
    decide +kernel
private theorem e55797 : Deny 5 13 b55797 :=
    branchAction rule_sound _ _ 2
      0x2e3 b55797 b55798 b55805 (by decide +kernel) e55798 e55805
private theorem e55814 : Deny 5 13 b55814 := by
    apply closeAction rule_sound _ _ 64 [0x2083277108e37]
    decide +kernel
private theorem e55796 : Deny 5 13 b55796 :=
    branchAction rule_sound _ _ 2
      0x1e3 b55796 b55797 b55814 (by decide +kernel) e55797 e55814
private theorem e55819 : Deny 5 13 b55819 := by
    apply closeAction rule_sound _ _ 64 [0x82a21109e37]
    decide +kernel
private theorem e55795 : Deny 5 13 b55795 :=
    branchAction rule_sound _ _ 1
      0x8 b55795 b55796 b55819 (by decide +kernel) e55796 e55819
private theorem e55739 : Deny 5 13 b55739 :=
    branchAction rule_sound _ _ 2
      0x263 b55739 b55740 b55795 (by decide +kernel) e55740 e55795
private theorem e55699 : Deny 5 13 b55699 :=
    branchAction rule_sound _ _ 2
      0x2e3 b55699 b55700 b55739 (by decide +kernel) e55700 e55739
private theorem e55826 : Deny 5 13 b55826 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
private theorem e55827 : Deny 5 13 b55827 := by
    apply closeAction rule_sound _ _ 64 [0x6dbe020c41f80f80c920a2b8]
    decide +kernel
private theorem e55825 : Deny 5 13 b55825 :=
    branchAction rule_sound _ _ 2
      0x2a3 b55825 b55826 b55827 (by decide +kernel) e55826 e55827
private theorem e55838 : Deny 5 13 b55838 := by
    apply closeAction rule_sound _ _ 64 [0x13e37]
    decide +kernel
private theorem e55824 : Deny 5 13 b55824 :=
    branchAction rule_sound _ _ 2
      0x1e3 b55824 b55825 b55838 (by decide +kernel) e55825 e55838
private theorem e55839 : Deny 5 13 b55839 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e55823 : Deny 5 13 b55823 :=
    branchAction rule_sound _ _ 2
      0x223 b55823 b55824 b55839 (by decide +kernel) e55824 e55839
private theorem e55840 : Deny 5 13 b55840 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e55822 : Deny 5 13 b55822 :=
    branchAction rule_sound _ _ 2
      0x278 b55822 b55823 b55840 (by decide +kernel) e55823 e55840
private theorem e55698 : Deny 5 13 b55698 :=
    branchAction rule_sound _ _ 2
      0x1e3 b55698 b55699 b55822 (by decide +kernel) e55699 e55822
private theorem e55841 : Deny 5 13 b55841 := by
    apply closeAction rule_sound _ _ 64 [0x2487e37]
    decide +kernel
private theorem e55697 : Deny 5 13 b55697 :=
    branchAction rule_sound _ _ 1
      0x8 b55697 b55698 b55841 (by decide +kernel) e55698 e55841
private theorem e55695 : Deny 5 13 b55695 :=
    branchAction rule_sound _ _ 2
      0x2a3 b55695 b55696 b55697 (by decide +kernel) e55696 e55697
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨1,565934718100890211111⟩,⟨239,478⟩] := by
  exact e55695
end OMA.Blocks5_13_245212.S55695
