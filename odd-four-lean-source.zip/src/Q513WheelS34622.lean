import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S34622
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b34622 : Box := ![⟨95,1920000000000000011376⟩,⟨33,1920000000000000011376⟩,⟨3,4⟩,⟨1,1090612244897959190168⟩,⟨119,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,1920000000000000011376⟩,⟨33,1920000000000000011376⟩,⟨3,4⟩,⟨1,1090612244897959190168⟩,⟨119,999999999999999999⟩] := by
  have e34622 : Deny 5 13 b34622 := by
    apply closeAction rule_sound _ _ 64 [0x2844f8d6110ae358c96daae3107e2b6c86c84e12822631d32a310b4ca8d99db9e31e78c46f8df6d748c41f8df48c8e23,0x11b238d631d3e35d212822634f8de3113e376f86c78c88c41f86678c46c7e276c74e580a8c86d34e11e1102804238d61,0x6d32b88db2386f88c74ca6676c79e311b1f8d2321aae3]
    decide +kernel
  exact e34622
end OMA.Blocks5_13_245212.S34622
