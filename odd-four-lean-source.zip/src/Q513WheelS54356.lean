import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S54356
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b54356 : Box := ![⟨47,53⟩,⟨63,126⟩,⟨10,14⟩,⟨1,59⟩,⟨239,478⟩]
private def b54357 : Box := ![⟨47,53⟩,⟨63,126⟩,⟨10,14⟩,⟨1,2⟩,⟨239,478⟩]
private def b54358 : Box := ![⟨47,53⟩,⟨63,126⟩,⟨10,14⟩,⟨3,57⟩,⟨239,478⟩]
private def b54359 : Box := ![⟨47,53⟩,⟨63,126⟩,⟨10,14⟩,⟨3,57⟩,⟨239,318⟩]
private def b54360 : Box := ![⟨47,53⟩,⟨63,126⟩,⟨10,11⟩,⟨3,57⟩,⟨239,317⟩]
private def b54361 : Box := ![⟨47,53⟩,⟨63,126⟩,⟨10,11⟩,⟨3,6⟩,⟨239,317⟩]
private def b54362 : Box := ![⟨47,53⟩,⟨63,126⟩,⟨10,11⟩,⟨7,56⟩,⟨239,317⟩]
private def b54363 : Box := ![⟨47,53⟩,⟨63,84⟩,⟨10,11⟩,⟨7,56⟩,⟨239,317⟩]
private def b54368 : Box := ![⟨47,53⟩,⟨85,126⟩,⟨10,11⟩,⟨7,56⟩,⟨239,317⟩]
private def b54369 : Box := ![⟨47,49⟩,⟨85,126⟩,⟨10,11⟩,⟨7,56⟩,⟨239,317⟩]
private def b54374 : Box := ![⟨50,53⟩,⟨85,126⟩,⟨10,11⟩,⟨7,56⟩,⟨239,317⟩]
private def b54375 : Box := ![⟨50,53⟩,⟨85,126⟩,⟨10,11⟩,⟨7,56⟩,⟨239,272⟩]
private def b54382 : Box := ![⟨50,53⟩,⟨85,126⟩,⟨10,11⟩,⟨7,56⟩,⟨273,317⟩]
private def b54389 : Box := ![⟨47,53⟩,⟨63,126⟩,⟨12,14⟩,⟨3,57⟩,⟨239,317⟩]
private def b54390 : Box := ![⟨47,53⟩,⟨63,84⟩,⟨12,14⟩,⟨3,57⟩,⟨239,317⟩]
private def b54401 : Box := ![⟨47,53⟩,⟨85,126⟩,⟨12,14⟩,⟨3,57⟩,⟨239,317⟩]
private def b54402 : Box := ![⟨47,49⟩,⟨85,126⟩,⟨12,14⟩,⟨6,57⟩,⟨239,317⟩]
private def b54403 : Box := ![⟨47,49⟩,⟨85,126⟩,⟨12,14⟩,⟨6,56⟩,⟨239,272⟩]
private def b54410 : Box := ![⟨47,49⟩,⟨85,126⟩,⟨12,14⟩,⟨6,56⟩,⟨273,317⟩]
private def b54419 : Box := ![⟨50,53⟩,⟨85,126⟩,⟨12,14⟩,⟨6,57⟩,⟨239,317⟩]
private def b54420 : Box := ![⟨50,53⟩,⟨85,126⟩,⟨12,14⟩,⟨6,57⟩,⟨239,272⟩]
private def b54425 : Box := ![⟨50,53⟩,⟨85,126⟩,⟨12,14⟩,⟨6,57⟩,⟨273,317⟩]
private def b54434 : Box := ![⟨47,53⟩,⟨63,126⟩,⟨10,14⟩,⟨3,57⟩,⟨319,478⟩]
private def b54435 : Box := ![⟨47,53⟩,⟨63,126⟩,⟨10,11⟩,⟨3,54⟩,⟨319,478⟩]
private def b54442 : Box := ![⟨47,53⟩,⟨63,126⟩,⟨12,14⟩,⟨3,54⟩,⟨319,478⟩]
private def b54443 : Box := ![⟨47,53⟩,⟨63,84⟩,⟨12,14⟩,⟨3,54⟩,⟨319,478⟩]
private def b54450 : Box := ![⟨47,53⟩,⟨85,126⟩,⟨12,14⟩,⟨3,54⟩,⟨319,478⟩]
private def b54451 : Box := ![⟨47,49⟩,⟨85,126⟩,⟨12,14⟩,⟨5,54⟩,⟨319,478⟩]
private def b54458 : Box := ![⟨50,53⟩,⟨85,126⟩,⟨12,14⟩,⟨5,54⟩,⟨319,478⟩]
private def b54459 : Box := ![⟨50,53⟩,⟨85,126⟩,⟨12,14⟩,⟨5,54⟩,⟨319,382⟩]
private def b54470 : Box := ![⟨50,53⟩,⟨85,126⟩,⟨12,14⟩,⟨5,54⟩,⟨383,478⟩]
private theorem e54357 : Deny 5 13 b54357 := by
    apply closeAction rule_sound _ _ 64 [0x2e37da1]
    decide +kernel
private theorem e54361 : Deny 5 13 b54361 := by
    apply closeAction rule_sound _ _ 64 [0xa1]
    decide +kernel
private theorem e54363 : Deny 5 13 b54363 := by
    apply closeAction rule_sound _ _ 64 [0xc22021f8de3]
    decide +kernel
private theorem e54369 : Deny 5 13 b54369 := by
    apply closeAction rule_sound _ _ 64 [0x3ac3e378c8102278ae3]
    decide +kernel
private theorem e54375 : Deny 5 13 b54375 := by
    apply closeAction rule_sound _ _ 64 [0x3e038c9ac36f8deb263204]
    decide +kernel
private theorem e54382 : Deny 5 13 b54382 := by
    apply closeAction rule_sound _ _ 64 [0xc3e3726b0c4089e378c88c4]
    decide +kernel
private theorem e54374 : Deny 5 13 b54374 :=
    branchAction rule_sound _ _ 1
      0xb b54374 b54375 b54382 (by decide +kernel) e54375 e54382
private theorem e54368 : Deny 5 13 b54368 :=
    branchAction rule_sound _ _ 1
      0x7 b54368 b54369 b54374 (by decide +kernel) e54369 e54374
private theorem e54362 : Deny 5 13 b54362 :=
    branchAction rule_sound _ _ 1
      0x8 b54362 b54363 b54368 (by decide +kernel) e54363 e54368
private theorem e54360 : Deny 5 13 b54360 :=
    branchAction rule_sound _ _ 2
      0x2a3 b54360 b54361 b54362 (by decide +kernel) e54361 e54362
private theorem e54390 : Deny 5 13 b54390 := by
    apply closeAction rule_sound _ _ 64 [0xc38c80f8de32430f8deb8c90f8de32231e3]
    decide +kernel
private theorem e54403 : Deny 5 13 b54403 := by
    apply closeAction rule_sound _ _ 64 [0x20eb8c4278ac3ac38c88c8ac4]
    decide +kernel
private theorem e54410 : Deny 5 13 b54410 := by
    apply closeAction rule_sound _ _ 64 [0x1f0eb8c90eb8c9ac3ac38c88c88c4]
    decide +kernel
private theorem e54402 : Deny 5 13 b54402 :=
    branchAction rule_sound _ _ 2
      0x2e3 b54402 b54403 b54410 (by decide +kernel) e54403 e54410
private theorem e54420 : Deny 5 13 b54420 := by
    apply closeAction rule_sound _ _ 64 [0xab7f8dc3ae3263204]
    decide +kernel
private theorem e54425 : Deny 5 13 b54425 := by
    apply closeAction rule_sound _ _ 64 [0x20f8ae3278adf0c90eb8c98c88c4]
    decide +kernel
private theorem e54419 : Deny 5 13 b54419 :=
    branchAction rule_sound _ _ 1
      0xb b54419 b54420 b54425 (by decide +kernel) e54420 e54425
private theorem e54401 : Deny 5 13 b54401 :=
    branchAction rule_sound _ _ 2
      0x1eb b54401 b54402 b54419 (by decide +kernel) e54402 e54419
private theorem e54389 : Deny 5 13 b54389 :=
    branchAction rule_sound _ _ 1
      0x8 b54389 b54390 b54401 (by decide +kernel) e54390 e54401
private theorem e54359 : Deny 5 13 b54359 :=
    branchAction rule_sound _ _ 2
      0x244 b54359 b54360 b54389 (by decide +kernel) e54360 e54389
private theorem e54435 : Deny 5 13 b54435 := by
    apply closeAction rule_sound _ _ 64 [0xc226b102238df58c4087e37d63]
    decide +kernel
private theorem e54443 : Deny 5 13 b54443 := by
    apply closeAction rule_sound _ _ 64 [0xc3e378c8087dc4089e23]
    decide +kernel
private theorem e54451 : Deny 5 13 b54451 := by
    apply closeAction rule_sound _ _ 64 [0x7c3ac40ab8c4238243e37d6b278ae3]
    decide +kernel
private theorem e54459 : Deny 5 13 b54459 := by
    apply closeAction rule_sound _ _ 64 [0x20e31c3ae326b0c3ae31c3e37ae3263204]
    decide +kernel
private theorem e54470 : Deny 5 13 b54470 := by
    apply closeAction rule_sound _ _ 64 [0x7c38c90f8ae326b7c3e2b8c90898c88c4]
    decide +kernel
private theorem e54458 : Deny 5 13 b54458 :=
    branchAction rule_sound _ _ 1
      0xb b54458 b54459 b54470 (by decide +kernel) e54459 e54470
private theorem e54450 : Deny 5 13 b54450 :=
    branchAction rule_sound _ _ 2
      0x1eb b54450 b54451 b54458 (by decide +kernel) e54451 e54458
private theorem e54442 : Deny 5 13 b54442 :=
    branchAction rule_sound _ _ 1
      0x8 b54442 b54443 b54450 (by decide +kernel) e54443 e54450
private theorem e54434 : Deny 5 13 b54434 :=
    branchAction rule_sound _ _ 2
      0x263 b54434 b54435 b54442 (by decide +kernel) e54435 e54442
private theorem e54358 : Deny 5 13 b54358 :=
    branchAction rule_sound _ _ 1
      0xb b54358 b54359 b54434 (by decide +kernel) e54359 e54434
private theorem e54356 : Deny 5 13 b54356 :=
    branchAction rule_sound _ _ 2
      0x2a3 b54356 b54357 b54358 (by decide +kernel) e54357 e54358
theorem deny5_13 : Deny 5 13 ![⟨47,53⟩,⟨63,126⟩,⟨10,14⟩,⟨1,59⟩,⟨239,478⟩] := by
  exact e54356
end OMA.Blocks5_13_245212.S54356
