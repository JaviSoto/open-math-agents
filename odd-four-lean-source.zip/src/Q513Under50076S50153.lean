import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S50153
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b50153 : Box := ![⟨139,152⟩,⟨23,24⟩,⟨42,62⟩,⟨1,55⟩,⟨1919,999999999999999999⟩]
private def b50154 : Box := ![⟨139,152⟩,⟨23,24⟩,⟨42,50⟩,⟨1,55⟩,⟨1919,999999999999999999⟩]
private def b50155 : Box := ![⟨139,152⟩,⟨23,24⟩,⟨42,50⟩,⟨1,51⟩,⟨1919,3838⟩]
private def b50156 : Box := ![⟨139,152⟩,⟨23,23⟩,⟨42,50⟩,⟨1,46⟩,⟨1919,3838⟩]
private def b50157 : Box := ![⟨139,152⟩,⟨23,23⟩,⟨42,45⟩,⟨1,46⟩,⟨1919,3838⟩]
private def b50158 : Box := ![⟨139,152⟩,⟨23,23⟩,⟨46,50⟩,⟨1,46⟩,⟨1919,3838⟩]
private def b50159 : Box := ![⟨139,152⟩,⟨24,24⟩,⟨42,50⟩,⟨1,46⟩,⟨1919,3838⟩]
private def b50160 : Box := ![⟨139,152⟩,⟨23,24⟩,⟨42,50⟩,⟨1,51⟩,⟨3839,999999999999999999⟩]
private def b50161 : Box := ![⟨139,152⟩,⟨23,23⟩,⟨42,50⟩,⟨1,46⟩,⟨3839,999999999999999999⟩]
private def b50162 : Box := ![⟨139,152⟩,⟨23,23⟩,⟨42,45⟩,⟨1,46⟩,⟨3839,999999999999999999⟩]
private def b50163 : Box := ![⟨139,152⟩,⟨23,23⟩,⟨46,50⟩,⟨1,46⟩,⟨3839,999999999999999999⟩]
private def b50164 : Box := ![⟨139,152⟩,⟨24,24⟩,⟨42,50⟩,⟨1,46⟩,⟨3839,999999999999999999⟩]
private def b50165 : Box := ![⟨139,152⟩,⟨24,24⟩,⟨42,45⟩,⟨1,46⟩,⟨8166,999999999999999999⟩]
private def b50166 : Box := ![⟨139,152⟩,⟨24,24⟩,⟨46,50⟩,⟨1,46⟩,⟨8166,999999999999999999⟩]
private def b50167 : Box := ![⟨139,152⟩,⟨23,24⟩,⟨51,62⟩,⟨1,55⟩,⟨1919,999999999999999999⟩]
private def b50168 : Box := ![⟨139,152⟩,⟨23,23⟩,⟨51,62⟩,⟨1,55⟩,⟨3409,999999999999999999⟩]
private def b50169 : Box := ![⟨139,145⟩,⟨23,23⟩,⟨51,62⟩,⟨1,51⟩,⟨3411,999999999999999999⟩]
private def b50170 : Box := ![⟨146,152⟩,⟨23,23⟩,⟨51,62⟩,⟨1,51⟩,⟨3411,999999999999999999⟩]
private def b50171 : Box := ![⟨139,152⟩,⟨24,24⟩,⟨51,62⟩,⟨1,55⟩,⟨3409,999999999999999999⟩]
private theorem e50157 : Deny 5 13 b50157 := by
    apply closeAction rule_sound _ _ 64 [0xe3]
    decide +kernel
private theorem e50158 : Deny 5 13 b50158 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e50156 : Deny 5 13 b50156 :=
    branchAction rule_sound _ _ 1
      0x9 b50156 b50157 b50158 (by decide +kernel) e50157 e50158
private theorem e50159 : Deny 5 13 b50159 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e50155 : Deny 5 13 b50155 :=
    branchAction rule_sound _ _ 2
      0x223 b50155 b50156 b50159 (by decide +kernel) e50156 e50159
private theorem e50162 : Deny 5 13 b50162 := by
    apply closeAction rule_sound _ _ 64 [0x3e23]
    decide +kernel
private theorem e50163 : Deny 5 13 b50163 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e50161 : Deny 5 13 b50161 :=
    branchAction rule_sound _ _ 1
      0x9 b50161 b50162 b50163 (by decide +kernel) e50162 e50163
private theorem e50165 : Deny 5 13 b50165 := by
    apply closeAction rule_sound _ _ 64 [0x3e23]
    decide +kernel
private theorem e50166 : Deny 5 13 b50166 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e50164 : Deny 5 13 b50164 :=
    branchAction rule_sound _ _ 2
      0x278 b50164 b50165 b50166 (by decide +kernel) e50165 e50166
private theorem e50160 : Deny 5 13 b50160 :=
    branchAction rule_sound _ _ 2
      0x223 b50160 b50161 b50164 (by decide +kernel) e50161 e50164
private theorem e50154 : Deny 5 13 b50154 :=
    branchAction rule_sound _ _ 2
      0x2e3 b50154 b50155 b50160 (by decide +kernel) e50155 e50160
private theorem e50169 : Deny 5 13 b50169 := by
    apply closeAction rule_sound _ _ 64 [0x3e23]
    decide +kernel
private theorem e50170 : Deny 5 13 b50170 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e50168 : Deny 5 13 b50168 :=
    branchAction rule_sound _ _ 3
      0x7e23 b50168 b50169 b50170 (by decide +kernel) e50169 e50170
private theorem e50171 : Deny 5 13 b50171 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e50167 : Deny 5 13 b50167 :=
    branchAction rule_sound _ _ 2
      0x238 b50167 b50168 b50171 (by decide +kernel) e50168 e50171
private theorem e50153 : Deny 5 13 b50153 :=
    branchAction rule_sound _ _ 1
      0x9 b50153 b50154 b50167 (by decide +kernel) e50154 e50167
theorem deny5_13 : Deny 5 13 ![⟨139,152⟩,⟨23,24⟩,⟨42,62⟩,⟨1,55⟩,⟨1919,999999999999999999⟩] := by
  exact e50153
end OMA.Blocks5_13_245212.S50153
