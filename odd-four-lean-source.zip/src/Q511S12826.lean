import FastReplay245212
import SparseDigit245212
import FastRound245212
import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S12826
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b12826 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨1,1445853658536585374451⟩,⟨207,999999999999999999⟩]
private def b12827 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨1,581463414634146344944⟩,⟨207,414⟩]
private def b12828 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨1,2⟩,⟨207,414⟩]
private def b12829 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨3,581463414634146344938⟩,⟨207,414⟩]
private def b12830 : Box := ![⟨18,19⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨3,581463414634146344938⟩,⟨207,414⟩]
private def b12831 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨15,30⟩,⟨3,581463414634146344937⟩,⟨207,414⟩]
private def b12832 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨15,20⟩,⟨3,58⟩,⟨207,414⟩]
private def b12833 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨15,20⟩,⟨4,54⟩,⟨207,276⟩]
private def b12834 : Box := ![⟨18,19⟩,⟨63,84⟩,⟨15,20⟩,⟨4,53⟩,⟨211,271⟩]
private def b12841 : Box := ![⟨18,19⟩,⟨85,126⟩,⟨15,20⟩,⟨4,53⟩,⟨211,271⟩]
private def b12850 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨15,20⟩,⟨4,54⟩,⟨277,414⟩]
private def b12865 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨21,30⟩,⟨3,58⟩,⟨207,414⟩]
private def b12866 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨21,30⟩,⟨3,58⟩,⟨207,276⟩]
private def b12879 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨21,30⟩,⟨3,58⟩,⟨277,414⟩]
private def b12880 : Box := ![⟨18,19⟩,⟨63,84⟩,⟨21,30⟩,⟨3,55⟩,⟨277,414⟩]
private def b12891 : Box := ![⟨18,19⟩,⟨85,126⟩,⟨21,30⟩,⟨3,55⟩,⟨277,414⟩]
private def b12902 : Box := ![⟨18,19⟩,⟨127,1920000000000000011376⟩,⟨15,30⟩,⟨3,581463414634146344937⟩,⟨207,414⟩]
private def b12909 : Box := ![⟨20,22⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨3,581463414634146344938⟩,⟨207,414⟩]
private def b12910 : Box := ![⟨20,22⟩,⟨63,126⟩,⟨15,30⟩,⟨3,581463414634146344938⟩,⟨214,414⟩]
private def b12911 : Box := ![⟨20,22⟩,⟨63,126⟩,⟨15,20⟩,⟨3,59⟩,⟨214,414⟩]
private def b12912 : Box := ![⟨20,22⟩,⟨63,126⟩,⟨15,20⟩,⟨3,54⟩,⟨214,282⟩]
private def b12919 : Box := ![⟨20,22⟩,⟨63,126⟩,⟨15,20⟩,⟨3,54⟩,⟨283,414⟩]
private def b12920 : Box := ![⟨20,20⟩,⟨63,126⟩,⟨15,20⟩,⟨3,51⟩,⟨283,414⟩]
private def b12929 : Box := ![⟨21,22⟩,⟨63,126⟩,⟨15,20⟩,⟨3,51⟩,⟨283,414⟩]
private def b12936 : Box := ![⟨20,22⟩,⟨63,126⟩,⟨21,30⟩,⟨3,59⟩,⟨214,414⟩]
private def b12937 : Box := ![⟨20,22⟩,⟨127,1920000000000000011376⟩,⟨15,30⟩,⟨3,581463414634146344938⟩,⟨214,414⟩]
private def b12938 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨1,581463414634146344944⟩,⟨415,999999999999999999⟩]
private def b12939 : Box := ![⟨18,19⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨1,514070080862533695800⟩,⟨415,999999999999999999⟩]
private def b12940 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨15,30⟩,⟨1,514070080862533695799⟩,⟨415,999999999999999999⟩]
private def b12941 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨15,20⟩,⟨1,57⟩,⟨415,999999999999999999⟩]
private def b12952 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨21,30⟩,⟨1,57⟩,⟨415,999999999999999999⟩]
private def b12953 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨21,30⟩,⟨1,57⟩,⟨415,830⟩]
private def b12954 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨21,30⟩,⟨1,2⟩,⟨415,830⟩]
private def b12955 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨21,30⟩,⟨3,52⟩,⟨415,830⟩]
private def b12956 : Box := ![⟨18,19⟩,⟨63,84⟩,⟨21,30⟩,⟨3,52⟩,⟨415,830⟩]
private def b12965 : Box := ![⟨18,19⟩,⟨85,126⟩,⟨21,30⟩,⟨3,52⟩,⟨415,830⟩]
private def b12966 : Box := ![⟨18,18⟩,⟨85,126⟩,⟨21,30⟩,⟨5,52⟩,⟨415,830⟩]
private def b12975 : Box := ![⟨19,19⟩,⟨85,126⟩,⟨21,30⟩,⟨5,52⟩,⟨415,830⟩]
private def b12984 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨21,30⟩,⟨1,57⟩,⟨831,999999999999999999⟩]
private def b12985 : Box := ![⟨18,18⟩,⟨63,126⟩,⟨21,30⟩,⟨1,51⟩,⟨831,999999999999999999⟩]
private def b12986 : Box := ![⟨19,19⟩,⟨63,126⟩,⟨21,30⟩,⟨1,51⟩,⟨831,999999999999999999⟩]
private def b12987 : Box := ![⟨19,19⟩,⟨63,84⟩,⟨21,30⟩,⟨1,51⟩,⟨831,999999999999999999⟩]
private def b12990 : Box := ![⟨19,19⟩,⟨85,126⟩,⟨21,30⟩,⟨1,51⟩,⟨831,999999999999999999⟩]
private def b12991 : Box := ![⟨19,19⟩,⟨85,126⟩,⟨21,24⟩,⟨1,51⟩,⟨831,999999999999999999⟩]
private def b12994 : Box := ![⟨19,19⟩,⟨85,126⟩,⟨25,30⟩,⟨1,51⟩,⟨831,999999999999999999⟩]
private def b13007 : Box := ![⟨18,19⟩,⟨127,1920000000000000011376⟩,⟨15,30⟩,⟨1,514070080862533695799⟩,⟨415,999999999999999999⟩]
private def b13008 : Box := ![⟨18,19⟩,⟨127,1920000000000000011376⟩,⟨15,20⟩,⟨2,514070080862533695799⟩,⟨415,999999999999999999⟩]
private def b13009 : Box := ![⟨18,19⟩,⟨127,1920000000000000011376⟩,⟨15,20⟩,⟨2,4⟩,⟨415,999999999999999999⟩]
private def b13010 : Box := ![⟨18,19⟩,⟨127,1920000000000000011376⟩,⟨15,20⟩,⟨5,514070080862533695795⟩,⟨415,999999999999999999⟩]
private def b13011 : Box := ![⟨18,19⟩,⟨127,1920000000000000011376⟩,⟨15,20⟩,⟨5,10⟩,⟨415,999999999999999999⟩]
private def b13012 : Box := ![⟨18,19⟩,⟨127,1920000000000000011376⟩,⟨15,20⟩,⟨11,514070080862533695795⟩,⟨415,999999999999999999⟩]
private def b13013 : Box := ![⟨18,19⟩,⟨127,1920000000000000011376⟩,⟨15,20⟩,⟨11,514070080862533695795⟩,⟨415,830⟩]
private def b13016 : Box := ![⟨18,19⟩,⟨127,1920000000000000011376⟩,⟨15,20⟩,⟨11,514070080862533695795⟩,⟨831,999999999999999999⟩]
private def b13017 : Box := ![⟨18,19⟩,⟨127,254⟩,⟨15,20⟩,⟨11,461047542304593072861⟩,⟨831,999999999999999999⟩]
private def b13020 : Box := ![⟨18,19⟩,⟨255,1920000000000000011376⟩,⟨15,20⟩,⟨11,461047542304593072861⟩,⟨831,999999999999999999⟩]
private def b13021 : Box := ![⟨18,19⟩,⟨255,1920000000000000011376⟩,⟨15,20⟩,⟨11,461047542304593072861⟩,⟨831,1662⟩]
private def b13022 : Box := ![⟨18,19⟩,⟨255,1920000000000000011376⟩,⟨15,20⟩,⟨11,461047542304593072861⟩,⟨1663,999999999999999999⟩]
private def b13023 : Box := ![⟨18,18⟩,⟨255,1920000000000000011376⟩,⟨15,20⟩,⟨11,417940102264426591249⟩,⟨1663,999999999999999999⟩]
private def b13024 : Box := ![⟨19,19⟩,⟨255,1920000000000000011376⟩,⟨15,20⟩,⟨11,417940102264426591249⟩,⟨1663,999999999999999999⟩]
private def b13025 : Box := ![⟨19,19⟩,⟨255,1920000000000000011376⟩,⟨15,20⟩,⟨11,417940102264426591249⟩,⟨1663,3326⟩]
private def b13026 : Box := ![⟨19,19⟩,⟨255,1920000000000000011376⟩,⟨15,20⟩,⟨11,417940102264426591249⟩,⟨3327,999999999999999999⟩]
private def b13027 : Box := ![⟨19,19⟩,⟨255,1920000000000000011376⟩,⟨15,20⟩,⟨11,382204408817635272826⟩,⟨3327,6654⟩]
private def b13028 : Box := ![⟨19,19⟩,⟨255,1920000000000000011376⟩,⟨15,20⟩,⟨11,382204408817635272826⟩,⟨6655,999999999999999999⟩]
private def b13029 : Box := ![⟨19,19⟩,⟨255,1920000000000000011376⟩,⟨16,20⟩,⟨11,352098461538461540566⟩,⟨6655,13310⟩]
private def b13030 : Box := ![⟨19,19⟩,⟨255,1920000000000000011376⟩,⟨16,20⟩,⟨11,352098461538461540566⟩,⟨13311,999999999999999999⟩]
private def b13031 : Box := ![⟨19,19⟩,⟨264,1920000000000000011376⟩,⟨16,17⟩,⟨11,326389047347404451466⟩,⟨13311,999999999999999999⟩]
private def b13032 : Box := ![⟨19,19⟩,⟨264,1920000000000000011376⟩,⟨18,20⟩,⟨11,326389047347404451466⟩,⟨13311,999999999999999999⟩]
private def b13047 : Box := ![⟨18,19⟩,⟨127,1920000000000000011376⟩,⟨21,30⟩,⟨2,514070080862533695799⟩,⟨415,999999999999999999⟩]
private def b13048 : Box := ![⟨18,19⟩,⟨127,1920000000000000011376⟩,⟨21,30⟩,⟨2,514070080862533695799⟩,⟨415,830⟩]
private def b13053 : Box := ![⟨18,19⟩,⟨127,1920000000000000011376⟩,⟨21,30⟩,⟨2,514070080862533695799⟩,⟨831,999999999999999999⟩]
private def b13054 : Box := ![⟨18,19⟩,⟨127,254⟩,⟨21,30⟩,⟨2,461047542304593072864⟩,⟨831,999999999999999999⟩]
private def b13055 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨21,30⟩,⟨3,82⟩,⟨831,999999999999999999⟩]
private def b13058 : Box := ![⟨19,19⟩,⟨127,254⟩,⟨21,30⟩,⟨3,82⟩,⟨831,999999999999999999⟩]
private def b13059 : Box := ![⟨19,19⟩,⟨127,254⟩,⟨21,24⟩,⟨3,82⟩,⟨831,999999999999999999⟩]
private def b13060 : Box := ![⟨19,19⟩,⟨127,254⟩,⟨21,24⟩,⟨3,80⟩,⟨831,1662⟩]
private def b13061 : Box := ![⟨19,19⟩,⟨127,254⟩,⟨21,24⟩,⟨3,80⟩,⟨1663,999999999999999999⟩]
private def b13062 : Box := ![⟨19,19⟩,⟨127,254⟩,⟨21,24⟩,⟨3,73⟩,⟨1663,3326⟩]
private def b13063 : Box := ![⟨19,19⟩,⟨127,254⟩,⟨21,24⟩,⟨3,73⟩,⟨3327,999999999999999999⟩]
private def b13064 : Box := ![⟨19,19⟩,⟨127,254⟩,⟨21,24⟩,⟨3,66⟩,⟨3327,6654⟩]
private def b13065 : Box := ![⟨19,19⟩,⟨127,254⟩,⟨21,24⟩,⟨3,66⟩,⟨6655,999999999999999999⟩]
private def b13066 : Box := ![⟨19,19⟩,⟨127,254⟩,⟨21,24⟩,⟨3,61⟩,⟨6655,13310⟩]
private def b13067 : Box := ![⟨19,19⟩,⟨127,254⟩,⟨21,24⟩,⟨3,61⟩,⟨13311,999999999999999999⟩]
private def b13068 : Box := ![⟨19,19⟩,⟨131,254⟩,⟨21,24⟩,⟨3,57⟩,⟨13311,26622⟩]
private def b13069 : Box := ![⟨19,19⟩,⟨131,254⟩,⟨21,24⟩,⟨3,57⟩,⟨26623,999999999999999999⟩]
private def b13070 : Box := ![⟨19,19⟩,⟨134,254⟩,⟨21,24⟩,⟨3,53⟩,⟨26623,53246⟩]
private def b13071 : Box := ![⟨19,19⟩,⟨134,254⟩,⟨21,24⟩,⟨3,53⟩,⟨53247,999999999999999999⟩]
private def b13072 : Box := ![⟨19,19⟩,⟨136,254⟩,⟨21,24⟩,⟨4,49⟩,⟨53247,106494⟩]
private def b13073 : Box := ![⟨19,19⟩,⟨136,254⟩,⟨21,24⟩,⟨4,49⟩,⟨106495,999999999999999999⟩]
private def b13074 : Box := ![⟨19,19⟩,⟨137,254⟩,⟨21,24⟩,⟨4,46⟩,⟨106495,212990⟩]
private def b13075 : Box := ![⟨19,19⟩,⟨137,254⟩,⟨21,24⟩,⟨4,46⟩,⟨212991,999999999999999999⟩]
private def b13076 : Box := ![⟨19,19⟩,⟨137,254⟩,⟨21,24⟩,⟨4,44⟩,⟨212991,425982⟩]
private def b13077 : Box := ![⟨19,19⟩,⟨137,254⟩,⟨21,24⟩,⟨4,44⟩,⟨425983,999999999999999999⟩]
private def b13078 : Box := ![⟨19,19⟩,⟨137,254⟩,⟨21,24⟩,⟨4,41⟩,⟨425983,851966⟩]
private def b13079 : Box := ![⟨19,19⟩,⟨137,254⟩,⟨21,24⟩,⟨4,41⟩,⟨851967,999999999999999999⟩]
private def b13080 : Box := ![⟨19,19⟩,⟨137,254⟩,⟨21,24⟩,⟨4,39⟩,⟨851967,1703934⟩]
private def b13081 : Box := ![⟨19,19⟩,⟨137,254⟩,⟨21,24⟩,⟨4,39⟩,⟨1703935,999999999999999999⟩]
private def b13082 : Box := ![⟨19,19⟩,⟨138,254⟩,⟨21,24⟩,⟨4,37⟩,⟨1703935,3407870⟩]
private def b13083 : Box := ![⟨19,19⟩,⟨138,254⟩,⟨21,24⟩,⟨4,37⟩,⟨3407871,999999999999999999⟩]
private def b13084 : Box := ![⟨19,19⟩,⟨138,254⟩,⟨21,24⟩,⟨4,36⟩,⟨3407871,6815742⟩]
private def b13085 : Box := ![⟨19,19⟩,⟨138,254⟩,⟨21,24⟩,⟨4,36⟩,⟨6815743,999999999999999999⟩]
private def b13086 : Box := ![⟨19,19⟩,⟨138,254⟩,⟨21,24⟩,⟨4,34⟩,⟨6815743,13631486⟩]
private def b13087 : Box := ![⟨19,19⟩,⟨138,254⟩,⟨21,24⟩,⟨4,34⟩,⟨13631487,999999999999999999⟩]
private def b13088 : Box := ![⟨19,19⟩,⟨138,254⟩,⟨21,24⟩,⟨4,32⟩,⟨13631487,27262974⟩]
private def b13089 : Box := ![⟨19,19⟩,⟨138,254⟩,⟨21,24⟩,⟨4,32⟩,⟨27262975,999999999999999999⟩]
private def b13090 : Box := ![⟨19,19⟩,⟨138,254⟩,⟨21,24⟩,⟨4,7⟩,⟨27262975,999999999999999999⟩]
private def b13091 : Box := ![⟨19,19⟩,⟨138,235⟩,⟨21,24⟩,⟨4,7⟩,⟨27262975,54525950⟩]
private def b13092 : Box := ![⟨19,19⟩,⟨138,235⟩,⟨21,24⟩,⟨4,7⟩,⟨54525951,999999999999999999⟩]
private def b13093 : Box := ![⟨19,19⟩,⟨138,235⟩,⟨21,24⟩,⟨4,7⟩,⟨54525951,109051902⟩]
private def b13094 : Box := ![⟨19,19⟩,⟨138,235⟩,⟨21,24⟩,⟨4,7⟩,⟨109051903,999999999999999999⟩]
private def b13095 : Box := ![⟨19,19⟩,⟨138,235⟩,⟨21,24⟩,⟨4,7⟩,⟨109051903,218103806⟩]
private def b13096 : Box := ![⟨19,19⟩,⟨138,235⟩,⟨21,24⟩,⟨4,7⟩,⟨218103807,999999999999999999⟩]
private def b13097 : Box := ![⟨19,19⟩,⟨138,235⟩,⟨21,24⟩,⟨4,7⟩,⟨218103807,436207614⟩]
private def b13098 : Box := ![⟨19,19⟩,⟨138,235⟩,⟨21,24⟩,⟨4,7⟩,⟨436207615,999999999999999999⟩]
private def b13113 : Box := ![⟨19,19⟩,⟨138,254⟩,⟨21,24⟩,⟨8,31⟩,⟨27262975,999999999999999999⟩]
private def b13114 : Box := ![⟨19,19⟩,⟨127,254⟩,⟨25,30⟩,⟨3,82⟩,⟨831,999999999999999999⟩]
private def b13121 : Box := ![⟨18,19⟩,⟨255,1920000000000000011376⟩,⟨21,30⟩,⟨2,461047542304593072864⟩,⟨831,999999999999999999⟩]
private def b13122 : Box := ![⟨18,19⟩,⟨255,1920000000000000011376⟩,⟨21,30⟩,⟨7,461047542304593072864⟩,⟨831,1662⟩]
private def b13123 : Box := ![⟨18,19⟩,⟨255,1920000000000000011376⟩,⟨21,30⟩,⟨7,461047542304593072864⟩,⟨1663,999999999999999999⟩]
private def b13124 : Box := ![⟨18,19⟩,⟨255,1920000000000000011376⟩,⟨21,30⟩,⟨7,417940102264426591252⟩,⟨1663,3326⟩]
private def b13125 : Box := ![⟨18,19⟩,⟨255,1920000000000000011376⟩,⟨21,30⟩,⟨7,417940102264426591252⟩,⟨3327,999999999999999999⟩]
private def b13126 : Box := ![⟨18,19⟩,⟨255,1920000000000000011376⟩,⟨21,30⟩,⟨7,382204408817635272829⟩,⟨3327,6654⟩]
private def b13127 : Box := ![⟨18,19⟩,⟨255,1920000000000000011376⟩,⟨21,30⟩,⟨7,382204408817635272829⟩,⟨6655,999999999999999999⟩]
private def b13128 : Box := ![⟨18,19⟩,⟨255,1920000000000000011376⟩,⟨21,30⟩,⟨7,352098461538461540569⟩,⟨6655,13310⟩]
private def b13129 : Box := ![⟨18,19⟩,⟨255,1920000000000000011376⟩,⟨21,30⟩,⟨7,352098461538461540569⟩,⟨13311,999999999999999999⟩]
private def b13130 : Box := ![⟨18,19⟩,⟨255,1920000000000000011376⟩,⟨21,30⟩,⟨7,326389047347404451468⟩,⟨13311,26622⟩]
private def b13131 : Box := ![⟨18,19⟩,⟨255,1920000000000000011376⟩,⟨21,30⟩,⟨7,326389047347404451468⟩,⟨26623,999999999999999999⟩]
private def b13132 : Box := ![⟨18,18⟩,⟨255,1920000000000000011376⟩,⟨21,30⟩,⟨7,304178628389154706765⟩,⟨26623,999999999999999999⟩]
private def b13133 : Box := ![⟨18,18⟩,⟨255,1920000000000000011376⟩,⟨21,24⟩,⟨7,304178628389154706764⟩,⟨26623,999999999999999999⟩]
private def b13140 : Box := ![⟨18,18⟩,⟨255,1920000000000000011376⟩,⟨25,30⟩,⟨7,304178628389154706764⟩,⟨26623,999999999999999999⟩]
private def b13141 : Box := ![⟨18,18⟩,⟨255,1920000000000000011376⟩,⟨25,30⟩,⟨7,304178628389154706764⟩,⟨26623,53246⟩]
private def b13142 : Box := ![⟨18,18⟩,⟨255,1920000000000000011376⟩,⟨25,30⟩,⟨7,304178628389154706764⟩,⟨53247,999999999999999999⟩]
private def b13143 : Box := ![⟨18,18⟩,⟨255,510⟩,⟨25,30⟩,⟨7,284798407167745148543⟩,⟨53247,999999999999999999⟩]
private def b13144 : Box := ![⟨18,18⟩,⟨255,510⟩,⟨25,30⟩,⟨8,89⟩,⟨53247,106494⟩]
private def b13145 : Box := ![⟨18,18⟩,⟨255,510⟩,⟨25,30⟩,⟨8,89⟩,⟨106495,999999999999999999⟩]
private def b13160 : Box := ![⟨18,18⟩,⟨511,1920000000000000011376⟩,⟨25,30⟩,⟨7,284798407167745148543⟩,⟨53247,999999999999999999⟩]
private def b13163 : Box := ![⟨19,19⟩,⟨255,1920000000000000011376⟩,⟨21,30⟩,⟨7,304178628389154706765⟩,⟨26623,999999999999999999⟩]
private def b13174 : Box := ![⟨20,22⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨1,514070080862533695800⟩,⟨415,999999999999999999⟩]
private def b13175 : Box := ![⟨20,22⟩,⟨63,126⟩,⟨15,30⟩,⟨1,514070080862533695800⟩,⟨415,999999999999999999⟩]
private def b13176 : Box := ![⟨20,22⟩,⟨63,126⟩,⟨15,20⟩,⟨1,58⟩,⟨415,999999999999999999⟩]
private def b13177 : Box := ![⟨20,22⟩,⟨63,126⟩,⟨15,20⟩,⟨1,54⟩,⟨415,830⟩]
private def b13178 : Box := ![⟨20,20⟩,⟨63,126⟩,⟨15,20⟩,⟨3,48⟩,⟨415,830⟩]
private def b13189 : Box := ![⟨21,22⟩,⟨63,126⟩,⟨15,20⟩,⟨3,48⟩,⟨415,830⟩]
private def b13202 : Box := ![⟨20,22⟩,⟨63,126⟩,⟨15,20⟩,⟨1,54⟩,⟨831,999999999999999999⟩]
private def b13203 : Box := ![⟨20,20⟩,⟨63,126⟩,⟨15,20⟩,⟨1,48⟩,⟨831,999999999999999999⟩]
private def b13212 : Box := ![⟨21,22⟩,⟨63,126⟩,⟨15,20⟩,⟨1,48⟩,⟨831,999999999999999999⟩]
private def b13213 : Box := ![⟨21,22⟩,⟨63,84⟩,⟨15,20⟩,⟨1,48⟩,⟨831,999999999999999999⟩]
private def b13220 : Box := ![⟨21,22⟩,⟨85,126⟩,⟨15,20⟩,⟨1,48⟩,⟨831,999999999999999999⟩]
private def b13231 : Box := ![⟨20,22⟩,⟨63,126⟩,⟨21,30⟩,⟨1,58⟩,⟨415,999999999999999999⟩]
private def b13232 : Box := ![⟨20,22⟩,⟨63,126⟩,⟨21,30⟩,⟨1,58⟩,⟨415,830⟩]
private def b13243 : Box := ![⟨20,22⟩,⟨63,126⟩,⟨21,30⟩,⟨1,58⟩,⟨831,999999999999999999⟩]
private def b13244 : Box := ![⟨20,20⟩,⟨63,126⟩,⟨21,30⟩,⟨1,52⟩,⟨831,999999999999999999⟩]
private def b13259 : Box := ![⟨21,22⟩,⟨63,126⟩,⟨21,30⟩,⟨1,52⟩,⟨831,999999999999999999⟩]
private def b13266 : Box := ![⟨20,22⟩,⟨127,1920000000000000011376⟩,⟨15,30⟩,⟨1,514070080862533695800⟩,⟨415,999999999999999999⟩]
private def b13267 : Box := ![⟨20,22⟩,⟨127,1920000000000000011376⟩,⟨15,20⟩,⟨2,514070080862533695800⟩,⟨430,999999999999999999⟩]
private def b13268 : Box := ![⟨20,22⟩,⟨127,1920000000000000011376⟩,⟨15,20⟩,⟨2,511313672922252013781⟩,⟨430,860⟩]
private def b13271 : Box := ![⟨20,22⟩,⟨127,1920000000000000011376⟩,⟨15,20⟩,⟨2,511313672922252013781⟩,⟨861,999999999999999999⟩]
private def b13272 : Box := ![⟨20,20⟩,⟨127,1920000000000000011376⟩,⟨15,20⟩,⟨2,458829190056134726079⟩,⟨861,999999999999999999⟩]
private def b13273 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨2,458829190056134726079⟩,⟨861,999999999999999999⟩]
private def b13274 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,78⟩,⟨861,1722⟩]
private def b13275 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,78⟩,⟨1723,999999999999999999⟩]
private def b13276 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,71⟩,⟨1723,3446⟩]
private def b13277 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,71⟩,⟨3447,999999999999999999⟩]
private def b13278 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,65⟩,⟨3447,6894⟩]
private def b13279 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,65⟩,⟨6895,999999999999999999⟩]
private def b13280 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,60⟩,⟨6895,13790⟩]
private def b13281 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,60⟩,⟨13791,999999999999999999⟩]
private def b13282 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,55⟩,⟨13791,27582⟩]
private def b13283 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,55⟩,⟨27583,999999999999999999⟩]
private def b13284 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,52⟩,⟨27583,55166⟩]
private def b13285 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,52⟩,⟨55167,999999999999999999⟩]
private def b13286 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,48⟩,⟨55167,110334⟩]
private def b13287 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,48⟩,⟨110335,999999999999999999⟩]
private def b13288 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,45⟩,⟨110335,220670⟩]
private def b13289 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,45⟩,⟨220671,999999999999999999⟩]
private def b13290 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,43⟩,⟨220671,441342⟩]
private def b13291 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,43⟩,⟨441343,999999999999999999⟩]
private def b13292 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,41⟩,⟨441343,882686⟩]
private def b13293 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,41⟩,⟨882687,999999999999999999⟩]
private def b13294 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,38⟩,⟨882687,1765374⟩]
private def b13295 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,38⟩,⟨1765375,999999999999999999⟩]
private def b13296 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,37⟩,⟨1765375,3530750⟩]
private def b13297 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,37⟩,⟨3530751,999999999999999999⟩]
private def b13298 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,35⟩,⟨3530751,7061502⟩]
private def b13299 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,35⟩,⟨7061503,999999999999999999⟩]
private def b13300 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,33⟩,⟨7061503,14123006⟩]
private def b13301 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,33⟩,⟨14123007,999999999999999999⟩]
private def b13302 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,32⟩,⟨14123007,28246014⟩]
private def b13303 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,32⟩,⟨28246015,999999999999999999⟩]
private def b13304 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,31⟩,⟨28246015,56492030⟩]
private def b13305 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,31⟩,⟨56492031,999999999999999999⟩]
private def b13306 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,29⟩,⟨56492031,112984062⟩]
private def b13307 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,29⟩,⟨112984063,999999999999999999⟩]
private def b13308 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨3,6⟩,⟨112984063,999999999999999999⟩]
private def b13309 : Box := ![⟨20,20⟩,⟨127,204⟩,⟨16,17⟩,⟨3,6⟩,⟨112984063,999999999999999999⟩]
private def b13310 : Box := ![⟨20,20⟩,⟨127,204⟩,⟨18,20⟩,⟨3,6⟩,⟨112984063,999999999999999999⟩]
private def b13311 : Box := ![⟨20,20⟩,⟨127,204⟩,⟨18,20⟩,⟨3,6⟩,⟨112984063,225968126⟩]
private def b13312 : Box := ![⟨20,20⟩,⟨127,204⟩,⟨18,20⟩,⟨3,6⟩,⟨225968127,999999999999999999⟩]
private def b13313 : Box := ![⟨20,20⟩,⟨127,204⟩,⟨18,20⟩,⟨3,6⟩,⟨225968127,451936254⟩]
private def b13314 : Box := ![⟨20,20⟩,⟨127,204⟩,⟨18,20⟩,⟨3,6⟩,⟨451936255,999999999999999999⟩]
private def b13315 : Box := ![⟨20,20⟩,⟨127,204⟩,⟨18,20⟩,⟨3,6⟩,⟨451936255,903872510⟩]
private def b13316 : Box := ![⟨20,20⟩,⟨127,204⟩,⟨18,20⟩,⟨3,6⟩,⟨903872511,999999999999999999⟩]
private def b13317 : Box := ![⟨20,20⟩,⟨127,204⟩,⟨18,20⟩,⟨3,6⟩,⟨903872511,1807745021⟩]
private def b13318 : Box := ![⟨20,20⟩,⟨127,204⟩,⟨18,20⟩,⟨3,6⟩,⟨1807745022,999999999999999999⟩]
private def b13319 : Box := ![⟨20,20⟩,⟨127,204⟩,⟨18,20⟩,⟨3,6⟩,⟨1807745022,3615490038⟩]
private def b13320 : Box := ![⟨20,20⟩,⟨127,204⟩,⟨18,20⟩,⟨3,6⟩,⟨3615490039,999999999999999999⟩]
private def b13335 : Box := ![⟨20,20⟩,⟨127,254⟩,⟨15,20⟩,⟨7,28⟩,⟨112984063,999999999999999999⟩]
private def b13336 : Box := ![⟨20,20⟩,⟨255,1920000000000000011376⟩,⟨15,20⟩,⟨2,458829190056134726079⟩,⟨861,999999999999999999⟩]
private def b13337 : Box := ![⟨20,20⟩,⟨255,1920000000000000011376⟩,⟨15,17⟩,⟨7,458829190056134726079⟩,⟨1528,999999999999999999⟩]
private def b13338 : Box := ![⟨20,20⟩,⟨255,1920000000000000011376⟩,⟨15,17⟩,⟨8,422882483370288250864⟩,⟨1553,3106⟩]
private def b13339 : Box := ![⟨20,20⟩,⟨255,1920000000000000011376⟩,⟨15,17⟩,⟨8,422882483370288250864⟩,⟨3107,999999999999999999⟩]
private def b13340 : Box := ![⟨20,20⟩,⟨255,1920000000000000011376⟩,⟨15,17⟩,⟨8,385552560646900271845⟩,⟨3107,6214⟩]
private def b13341 : Box := ![⟨20,20⟩,⟨255,1920000000000000011376⟩,⟨15,17⟩,⟨8,385552560646900271845⟩,⟨6215,999999999999999999⟩]
private def b13356 : Box := ![⟨20,20⟩,⟨255,1920000000000000011376⟩,⟨18,20⟩,⟨7,458829190056134726079⟩,⟨1528,999999999999999999⟩]
private def b13357 : Box := ![⟨21,22⟩,⟨127,1920000000000000011376⟩,⟨15,20⟩,⟨2,458829190056134726079⟩,⟨861,999999999999999999⟩]
private def b13368 : Box := ![⟨20,22⟩,⟨127,1920000000000000011376⟩,⟨21,30⟩,⟨2,514070080862533695800⟩,⟨430,999999999999999999⟩]
theorem deny5_11 : Deny 5 11 ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨1,1445853658536585374451⟩,⟨207,999999999999999999⟩] := by
  have e12828 : Deny 5 11 b12828 := by
    apply closeAction rule_sound _ _ 64 [0x16aa1]
    decide +kernel
  have e12834 : Deny 5 11 b12834 := by
    apply closeAction rule_sound _ _ 64 [0x3e03e070c3e37ac7ae3263]
    decide +kernel
  have e12841 : Deny 5 11 b12841 := by
    apply closeAction rule_sound _ _ 64 [0x6820e1107e03e03e211eb849ae12ab]
    decide +kernel
  have e12833 : Deny 5 11 b12833 :=
    branchAction rule_sound _ _ 3
      0x88c4 b12833 b12834 b12841 (by decide +kernel) e12834 e12841
  have e12850 : Deny 5 11 b12850 := by
    apply closeAction rule_sound _ _ 64 [0x1a0f80f88470e11021f8ae12612ab0c3e37ae32421e3223]
    decide +kernel
  have e12832 : Deny 5 11 b12832 :=
    branchAction rule_sound _ _ 3
      0xbae3 b12832 b12833 b12850 (by decide +kernel) e12833 e12850
  have e12866 : Deny 5 11 b12866 := by
    apply closeAction rule_sound _ _ 64 [0x27ab844278deb083844278dc3e370e32038c91e3204]
    decide +kernel
  have e12880 : Deny 5 11 b12880 := by
    apply closeAction rule_sound _ _ 64 [0x83dc4238dc38c90c3e23203e378c91e3]
    decide +kernel
  have e12891 : Deny 5 11 b12891 := by
    apply closeAction rule_sound _ _ 64 [0x20ab8c40f8dc3ae3263108e03e2b0e322b8c91eb]
    decide +kernel
  have e12879 : Deny 5 11 b12879 :=
    branchAction rule_sound _ _ 2
      0x223 b12879 b12880 b12891 (by decide +kernel) e12880 e12891
  have e12865 : Deny 5 11 b12865 :=
    branchAction rule_sound _ _ 1
      0xb b12865 b12866 b12879 (by decide +kernel) e12866 e12879
  have e12831 : Deny 5 11 b12831 :=
    branchAction rule_sound _ _ 2
      0x263 b12831 b12832 b12865 (by decide +kernel) e12832 e12865
  have e12902 : Deny 5 11 b12902 := by
    apply closeAction rule_sound _ _ 64 [0x6ab8c2689e23689e2b8c8e2b]
    decide +kernel
  have e12830 : Deny 5 11 b12830 :=
    branchAction rule_sound _ _ 2
      0x223 b12830 b12831 b12902 (by decide +kernel) e12831 e12902
  have e12912 : Deny 5 11 b12912 := by
    apply closeAction rule_sound _ _ 64 [0x82083e2b8c98c4238ae31c4]
    decide +kernel
  have e12920 : Deny 5 11 b12920 := by
    apply closeAction rule_sound _ _ 64 [0x820e3108e2b8c4278ac3e03ae326322b]
    decide +kernel
  have e12929 : Deny 5 11 b12929 := by
    apply closeAction rule_sound _ _ 64 [0x20820e3107e2b8c98c4238]
    decide +kernel
  have e12919 : Deny 5 11 b12919 :=
    branchAction rule_sound _ _ 2
      0x1e3 b12919 b12920 b12929 (by decide +kernel) e12920 e12929
  have e12911 : Deny 5 11 b12911 :=
    branchAction rule_sound _ _ 2
      0x2e3 b12911 b12912 b12919 (by decide +kernel) e12912 e12919
  have e12936 : Deny 5 11 b12936 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e12910 : Deny 5 11 b12910 :=
    branchAction rule_sound _ _ 2
      0x263 b12910 b12911 b12936 (by decide +kernel) e12911 e12936
  have e12937 : Deny 5 11 b12937 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e12909 : Deny 5 11 b12909 :=
    branchAction rule_sound _ _ 2
      0x238 b12909 b12910 b12937 (by decide +kernel) e12910 e12937
  have e12829 : Deny 5 11 b12829 :=
    branchAction rule_sound _ _ 1
      0x7 b12829 b12830 b12909 (by decide +kernel) e12830 e12909
  have e12827 : Deny 5 11 b12827 :=
    branchAction rule_sound _ _ 2
      0x2a3 b12827 b12828 b12829 (by decide +kernel) e12828 e12829
  have e12941 : Deny 5 11 b12941 := by
    apply closeAction rule_sound _ _ 64 [0x1a0c2278842238db584a0a12b8ae3087e37d63]
    decide +kernel
  have e12954 : Deny 5 11 b12954 := by
    apply closeAction rule_sound _ _ 64 [0x16aa1]
    decide +kernel
  have e12956 : Deny 5 11 b12956 := by
    apply closeAction rule_sound _ _ 64 [0xf80f88c80f88c90f6102238df61e3]
    decide +kernel
  have e12966 : Deny 5 11 b12966 := by
    apply closeAction rule_sound _ _ 64 [0x7ab783e2b84ae23203ac4084238ae3263]
    decide +kernel
  have e12975 : Deny 5 11 b12975 := by
    apply closeAction rule_sound _ _ 64 [0x820f8ae32632380f8ac38c8e2b8c9]
    decide +kernel
  have e12965 : Deny 5 11 b12965 :=
    branchAction rule_sound _ _ 2
      0x1eb b12965 b12966 b12975 (by decide +kernel) e12966 e12975
  have e12955 : Deny 5 11 b12955 :=
    branchAction rule_sound _ _ 1
      0x8 b12955 b12956 b12965 (by decide +kernel) e12956 e12965
  have e12953 : Deny 5 11 b12953 :=
    branchAction rule_sound _ _ 2
      0x2a3 b12953 b12954 b12955 (by decide +kernel) e12954 e12955
  have e12985 : Deny 5 11 b12985 := by
    apply closeAction rule_sound _ _ 64 [0x1ee37db5]
    decide +kernel
  have e12987 : Deny 5 11 b12987 := by
    apply closeAction rule_sound _ _ 64 [0x3e23088e37da3]
    decide +kernel
  have e12991 : Deny 5 11 b12991 := by
    apply closeAction rule_sound _ _ 64 [0xf8ae30f8ae3238ae3]
    decide +kernel
  have e12994 : Deny 5 11 b12994 := by
    apply closeAction rule_sound _ _ 64 [0x30f88c9ac3e2b8dae37ae32788c88deac3e03ae326322b8cb]
    decide +kernel
  have e12990 : Deny 5 11 b12990 :=
    branchAction rule_sound _ _ 1
      0x9 b12990 b12991 b12994 (by decide +kernel) e12991 e12994
  have e12986 : Deny 5 11 b12986 :=
    branchAction rule_sound _ _ 1
      0x8 b12986 b12987 b12990 (by decide +kernel) e12987 e12990
  have e12984 : Deny 5 11 b12984 :=
    branchAction rule_sound _ _ 2
      0x1e3 b12984 b12985 b12986 (by decide +kernel) e12985 e12986
  have e12952 : Deny 5 11 b12952 :=
    branchAction rule_sound _ _ 1
      0xb b12952 b12953 b12984 (by decide +kernel) e12953 e12984
  have e12940 : Deny 5 11 b12940 :=
    branchAction rule_sound _ _ 2
      0x263 b12940 b12941 b12952 (by decide +kernel) e12941 e12952
  have e13009 : Deny 5 11 b13009 := by
    apply closeAction rule_sound _ _ 64 [0x4b8ae1]
    decide +kernel
  have e13011 : Deny 5 11 b13011 := by
    apply closeAction rule_sound _ _ 64 [0x12e21]
    decide +kernel
  have e13013 : Deny 5 11 b13013 := by
    apply closeAction rule_sound _ _ 64 [0x6ab6ab8c8ae3]
    decide +kernel
  have e13017 : Deny 5 11 b13017 := by
    apply closeAction rule_sound _ _ 64 [0x6ab8c21f8da3]
    decide +kernel
  have e13021 : Deny 5 11 b13021 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13023 : Deny 5 11 b13023 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e13025 : Deny 5 11 b13025 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13027 : Deny 5 11 b13027 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13029 : Deny 5 11 b13029 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13031 : Deny 5 11 b13031 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e13032 : Deny 5 11 b13032 := by
    apply closeAction rule_sound _ _ 64 [0x9aae322b6ab8c8adaac30898c80898c8d636ab8cb]
    decide +kernel
  have e13030 : Deny 5 11 b13030 :=
    branchAction rule_sound _ _ 3
      0x9d63 b13030 b13031 b13032 (by decide +kernel) e13031 e13032
  have e13028 : Deny 5 11 b13028 :=
    branchAction rule_sound _ _ 3
      0xbda3 b13028 b13029 b13030 (by decide +kernel) e13029 e13030
  have e13026 : Deny 5 11 b13026 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13026 b13027 b13028 (by decide +kernel) e13027 e13028
  have e13024 : Deny 5 11 b13024 :=
    branchAction rule_sound _ _ 1
      0xb b13024 b13025 b13026 (by decide +kernel) e13025 e13026
  have e13022 : Deny 5 11 b13022 :=
    branchAction rule_sound _ _ 2
      0x1e3 b13022 b13023 b13024 (by decide +kernel) e13023 e13024
  have e13020 : Deny 5 11 b13020 :=
    branchAction rule_sound _ _ 1
      0xb b13020 b13021 b13022 (by decide +kernel) e13021 e13022
  have e13016 : Deny 5 11 b13016 :=
    branchAction rule_sound _ _ 2
      0x223 b13016 b13017 b13020 (by decide +kernel) e13017 e13020
  have e13012 : Deny 5 11 b13012 :=
    branchAction rule_sound _ _ 1
      0xb b13012 b13013 b13016 (by decide +kernel) e13013 e13016
  have e13010 : Deny 5 11 b13010 :=
    branchAction rule_sound _ _ 1
      0xa b13010 b13011 b13012 (by decide +kernel) e13011 e13012
  have e13008 : Deny 5 11 b13008 :=
    branchAction rule_sound _ _ 2
      0x2a3 b13008 b13009 b13010 (by decide +kernel) e13009 e13010
  have e13048 : Deny 5 11 b13048 := by
    apply closeAction rule_sound _ _ 64 [0x6ab79aae326b8c8ae3]
    decide +kernel
  have e13055 : Deny 5 11 b13055 := by
    apply closeAction rule_sound _ _ 64 [0x6ab8dee36ae3238]
    decide +kernel
  have e13060 : Deny 5 11 b13060 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13062 : Deny 5 11 b13062 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13064 : Deny 5 11 b13064 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13066 : Deny 5 11 b13066 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13068 : Deny 5 11 b13068 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13070 : Deny 5 11 b13070 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13072 : Deny 5 11 b13072 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13074 : Deny 5 11 b13074 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13076 : Deny 5 11 b13076 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13078 : Deny 5 11 b13078 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13080 : Deny 5 11 b13080 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13082 : Deny 5 11 b13082 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13084 : Deny 5 11 b13084 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13086 : Deny 5 11 b13086 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13088 : Deny 5 11 b13088 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13091 : Deny 5 11 b13091 := by
    apply closeAction rule_sound _ _ 64 [0x12]
    decide +kernel
  have e13093 : Deny 5 11 b13093 := by
    apply closeAction rule_sound _ _ 64 [0x12]
    decide +kernel
  have e13095 : Deny 5 11 b13095 := by
    apply closeAction rule_sound _ _ 64 [0xabaa1]
    decide +kernel
  have e13097 : Deny 5 11 b13097 := by
    apply closeAction rule_sound _ _ 64 [0xabaa1]
    decide +kernel
  have e13098 : Deny 5 11 b13098 := by
    apply closeAction rule_sound _ _ 64 [0x1a0c223684a0ab84b0ab84b0ab84b0ab84b0ab84b]
    decide +kernel
  have e13096 : Deny 5 11 b13096 :=
    branchAction rule_sound _ _ 1
      0xb b13096 b13097 b13098 (by decide +kernel) e13097 e13098
  have e13094 : Deny 5 11 b13094 :=
    branchAction rule_sound _ _ 1
      0xb b13094 b13095 b13096 (by decide +kernel) e13095 e13096
  have e13092 : Deny 5 11 b13092 :=
    branchAction rule_sound _ _ 1
      0xb b13092 b13093 b13094 (by decide +kernel) e13093 e13094
  have e13090 : Deny 5 11 b13090 :=
    branchAction rule_sound _ _ 2
      0x2e1 b13090 b13091 b13092 (by decide +kernel) e13091 e13092
  have e13113 : Deny 5 11 b13113 := by
    apply closeAction rule_sound _ _ 64 [0x1a]
    decide +kernel
  have e13089 : Deny 5 11 b13089 :=
    branchAction rule_sound _ _ 2
      0x2a3 b13089 b13090 b13113 (by decide +kernel) e13090 e13113
  have e13087 : Deny 5 11 b13087 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13087 b13088 b13089 (by decide +kernel) e13088 e13089
  have e13085 : Deny 5 11 b13085 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13085 b13086 b13087 (by decide +kernel) e13086 e13087
  have e13083 : Deny 5 11 b13083 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13083 b13084 b13085 (by decide +kernel) e13084 e13085
  have e13081 : Deny 5 11 b13081 :=
    branchAction rule_sound _ _ 3
      0xbd63 b13081 b13082 b13083 (by decide +kernel) e13082 e13083
  have e13079 : Deny 5 11 b13079 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13079 b13080 b13081 (by decide +kernel) e13080 e13081
  have e13077 : Deny 5 11 b13077 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13077 b13078 b13079 (by decide +kernel) e13078 e13079
  have e13075 : Deny 5 11 b13075 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13075 b13076 b13077 (by decide +kernel) e13076 e13077
  have e13073 : Deny 5 11 b13073 :=
    branchAction rule_sound _ _ 3
      0xbd63 b13073 b13074 b13075 (by decide +kernel) e13074 e13075
  have e13071 : Deny 5 11 b13071 :=
    branchAction rule_sound _ _ 4
      0x2f5ae3 b13071 b13072 b13073 (by decide +kernel) e13072 e13073
  have e13069 : Deny 5 11 b13069 :=
    branchAction rule_sound _ _ 3
      0xbd63 b13069 b13070 b13071 (by decide +kernel) e13070 e13071
  have e13067 : Deny 5 11 b13067 :=
    branchAction rule_sound _ _ 3
      0xbd63 b13067 b13068 b13069 (by decide +kernel) e13068 e13069
  have e13065 : Deny 5 11 b13065 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13065 b13066 b13067 (by decide +kernel) e13066 e13067
  have e13063 : Deny 5 11 b13063 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13063 b13064 b13065 (by decide +kernel) e13064 e13065
  have e13061 : Deny 5 11 b13061 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13061 b13062 b13063 (by decide +kernel) e13062 e13063
  have e13059 : Deny 5 11 b13059 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13059 b13060 b13061 (by decide +kernel) e13060 e13061
  have e13114 : Deny 5 11 b13114 := by
    apply closeAction rule_sound _ _ 64 [0x820f8ac3e232388c9e23238]
    decide +kernel
  have e13058 : Deny 5 11 b13058 :=
    branchAction rule_sound _ _ 1
      0x9 b13058 b13059 b13114 (by decide +kernel) e13059 e13114
  have e13054 : Deny 5 11 b13054 :=
    branchAction rule_sound _ _ 3
      0x7ae3 b13054 b13055 b13058 (by decide +kernel) e13055 e13058
  have e13122 : Deny 5 11 b13122 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13124 : Deny 5 11 b13124 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13126 : Deny 5 11 b13126 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13128 : Deny 5 11 b13128 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13130 : Deny 5 11 b13130 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13133 : Deny 5 11 b13133 := by
    apply closeAction rule_sound _ _ 64 [0x26ab8c8089d6b089d63]
    decide +kernel
  have e13141 : Deny 5 11 b13141 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13144 : Deny 5 11 b13144 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13145 : Deny 5 11 b13145 := by
    apply closeAction rule_sound _ _ 64 [0x1aac3ac38c8089da32236ab8cb8daae32e36ab8cb8daae32e3]
    decide +kernel
  have e13143 : Deny 5 11 b13143 :=
    branchAction rule_sound _ _ 3
      0xbae3 b13143 b13144 b13145 (by decide +kernel) e13144 e13145
  have e13160 : Deny 5 11 b13160 := by
    apply closeAction rule_sound _ _ 64 [0x9aae322b]
    decide +kernel
  have e13142 : Deny 5 11 b13142 :=
    branchAction rule_sound _ _ 2
      0x223 b13142 b13143 b13160 (by decide +kernel) e13143 e13160
  have e13140 : Deny 5 11 b13140 :=
    branchAction rule_sound _ _ 1
      0xb b13140 b13141 b13142 (by decide +kernel) e13141 e13142
  have e13132 : Deny 5 11 b13132 :=
    branchAction rule_sound _ _ 2
      0x263 b13132 b13133 b13140 (by decide +kernel) e13133 e13140
  have e13163 : Deny 5 11 b13163 := by
    apply closeAction rule_sound _ _ 64 [0x820820838c88c826b8c88c9]
    decide +kernel
  have e13131 : Deny 5 11 b13131 :=
    branchAction rule_sound _ _ 2
      0x1e3 b13131 b13132 b13163 (by decide +kernel) e13132 e13163
  have e13129 : Deny 5 11 b13129 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13129 b13130 b13131 (by decide +kernel) e13130 e13131
  have e13127 : Deny 5 11 b13127 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13127 b13128 b13129 (by decide +kernel) e13128 e13129
  have e13125 : Deny 5 11 b13125 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13125 b13126 b13127 (by decide +kernel) e13126 e13127
  have e13123 : Deny 5 11 b13123 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13123 b13124 b13125 (by decide +kernel) e13124 e13125
  have e13121 : Deny 5 11 b13121 :=
    branchAction rule_sound _ _ 2
      0x2eb b13121 b13122 b13123 (by decide +kernel) e13122 e13123
  have e13053 : Deny 5 11 b13053 :=
    branchAction rule_sound _ _ 2
      0x223 b13053 b13054 b13121 (by decide +kernel) e13054 e13121
  have e13047 : Deny 5 11 b13047 :=
    branchAction rule_sound _ _ 1
      0xb b13047 b13048 b13053 (by decide +kernel) e13048 e13053
  have e13007 : Deny 5 11 b13007 :=
    branchAction rule_sound _ _ 2
      0x26b b13007 b13008 b13047 (by decide +kernel) e13008 e13047
  have e12939 : Deny 5 11 b12939 :=
    branchAction rule_sound _ _ 2
      0x223 b12939 b12940 b13007 (by decide +kernel) e12940 e13007
  have e13178 : Deny 5 11 b13178 := by
    apply closeAction rule_sound _ _ 64 [0x683e03e2b84984aac30f88c98c80f8dab84a]
    decide +kernel
  have e13189 : Deny 5 11 b13189 := by
    apply closeAction rule_sound _ _ 64 [0x820f8ae3278ae3278ac20e31f80f80e31eb8c98c8]
    decide +kernel
  have e13177 : Deny 5 11 b13177 :=
    branchAction rule_sound _ _ 3
      0x7ae3 b13177 b13178 b13189 (by decide +kernel) e13178 e13189
  have e13203 : Deny 5 11 b13203 := by
    apply closeAction rule_sound _ _ 64 [0x3e03e2b8c9e2b0f8da3238ac3e37db58c8e2348ae35]
    decide +kernel
  have e13213 : Deny 5 11 b13213 := by
    apply closeAction rule_sound _ _ 64 [0xf80c70c3e371e3263]
    decide +kernel
  have e13220 : Deny 5 11 b13220 := by
    apply closeAction rule_sound _ _ 64 [0x820f88c8e231f80f80c70e326326b]
    decide +kernel
  have e13212 : Deny 5 11 b13212 :=
    branchAction rule_sound _ _ 1
      0x8 b13212 b13213 b13220 (by decide +kernel) e13213 e13220
  have e13202 : Deny 5 11 b13202 :=
    branchAction rule_sound _ _ 2
      0x1e3 b13202 b13203 b13212 (by decide +kernel) e13203 e13212
  have e13176 : Deny 5 11 b13176 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13176 b13177 b13202 (by decide +kernel) e13177 e13202
  have e13232 : Deny 5 11 b13232 := by
    apply closeAction rule_sound _ _ 64 [0x5b8dc2ac20f8238de30e32785aa84a8c81e3]
    decide +kernel
  have e13244 : Deny 5 11 b13244 := by
    apply closeAction rule_sound _ _ 64 [0x2083e232788c8e03e03e23238ae3243e038c80f88c98c8]
    decide +kernel
  have e13259 : Deny 5 11 b13259 := by
    apply closeAction rule_sound _ _ 64 [0x820838c78c98c8]
    decide +kernel
  have e13243 : Deny 5 11 b13243 :=
    branchAction rule_sound _ _ 2
      0x1e3 b13243 b13244 b13259 (by decide +kernel) e13244 e13259
  have e13231 : Deny 5 11 b13231 :=
    branchAction rule_sound _ _ 1
      0xb b13231 b13232 b13243 (by decide +kernel) e13232 e13243
  have e13175 : Deny 5 11 b13175 :=
    branchAction rule_sound _ _ 2
      0x263 b13175 b13176 b13231 (by decide +kernel) e13176 e13231
  have e13268 : Deny 5 11 b13268 := by
    apply closeAction rule_sound _ _ 64 [0x9aae3238ae3]
    decide +kernel
  have e13274 : Deny 5 11 b13274 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13276 : Deny 5 11 b13276 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13278 : Deny 5 11 b13278 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13280 : Deny 5 11 b13280 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13282 : Deny 5 11 b13282 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13284 : Deny 5 11 b13284 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13286 : Deny 5 11 b13286 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13288 : Deny 5 11 b13288 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13290 : Deny 5 11 b13290 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13292 : Deny 5 11 b13292 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13294 : Deny 5 11 b13294 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13296 : Deny 5 11 b13296 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13298 : Deny 5 11 b13298 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13300 : Deny 5 11 b13300 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13302 : Deny 5 11 b13302 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13304 : Deny 5 11 b13304 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13306 : Deny 5 11 b13306 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13309 : Deny 5 11 b13309 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e13311 : Deny 5 11 b13311 := by
    apply closeAction rule_sound _ _ 64 [0x12]
    decide +kernel
  have e13313 : Deny 5 11 b13313 := by
    apply closeAction rule_sound _ _ 64 [0x12]
    decide +kernel
  have e13315 : Deny 5 11 b13315 := by
    apply closeAction rule_sound _ _ 64 [0xabaa1]
    decide +kernel
  have e13317 : Deny 5 11 b13317 := by
    apply closeAction rule_sound _ _ 64 [0xabaa1]
    decide +kernel
  have e13319 : Deny 5 11 b13319 := by
    apply closeAction rule_sound _ _ 64 [0x1aae1]
    decide +kernel
  have e13320 : Deny 5 11 b13320 := by
    apply closeAction rule_sound _ _ 64 [0x6ab0c86ab84b6ab84b6ab84b6ab84b6ab84b6ab84b]
    decide +kernel
  have e13318 : Deny 5 11 b13318 :=
    branchAction rule_sound _ _ 1
      0xb b13318 b13319 b13320 (by decide +kernel) e13319 e13320
  have e13316 : Deny 5 11 b13316 :=
    branchAction rule_sound _ _ 1
      0xb b13316 b13317 b13318 (by decide +kernel) e13317 e13318
  have e13314 : Deny 5 11 b13314 :=
    branchAction rule_sound _ _ 1
      0xb b13314 b13315 b13316 (by decide +kernel) e13315 e13316
  have e13312 : Deny 5 11 b13312 :=
    branchAction rule_sound _ _ 1
      0xb b13312 b13313 b13314 (by decide +kernel) e13313 e13314
  have e13310 : Deny 5 11 b13310 :=
    branchAction rule_sound _ _ 1
      0xb b13310 b13311 b13312 (by decide +kernel) e13311 e13312
  have e13308 : Deny 5 11 b13308 :=
    branchAction rule_sound _ _ 3
      0x9da1 b13308 b13309 b13310 (by decide +kernel) e13309 e13310
  have e13335 : Deny 5 11 b13335 := by
    apply closeAction rule_sound _ _ 64 [0x1a]
    decide +kernel
  have e13307 : Deny 5 11 b13307 :=
    branchAction rule_sound _ _ 2
      0x2a3 b13307 b13308 b13335 (by decide +kernel) e13308 e13335
  have e13305 : Deny 5 11 b13305 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13305 b13306 b13307 (by decide +kernel) e13306 e13307
  have e13303 : Deny 5 11 b13303 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13303 b13304 b13305 (by decide +kernel) e13304 e13305
  have e13301 : Deny 5 11 b13301 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13301 b13302 b13303 (by decide +kernel) e13302 e13303
  have e13299 : Deny 5 11 b13299 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13299 b13300 b13301 (by decide +kernel) e13300 e13301
  have e13297 : Deny 5 11 b13297 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13297 b13298 b13299 (by decide +kernel) e13298 e13299
  have e13295 : Deny 5 11 b13295 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13295 b13296 b13297 (by decide +kernel) e13296 e13297
  have e13293 : Deny 5 11 b13293 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13293 b13294 b13295 (by decide +kernel) e13294 e13295
  have e13291 : Deny 5 11 b13291 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13291 b13292 b13293 (by decide +kernel) e13292 e13293
  have e13289 : Deny 5 11 b13289 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13289 b13290 b13291 (by decide +kernel) e13290 e13291
  have e13287 : Deny 5 11 b13287 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13287 b13288 b13289 (by decide +kernel) e13288 e13289
  have e13285 : Deny 5 11 b13285 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13285 b13286 b13287 (by decide +kernel) e13286 e13287
  have e13283 : Deny 5 11 b13283 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13283 b13284 b13285 (by decide +kernel) e13284 e13285
  have e13281 : Deny 5 11 b13281 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13281 b13282 b13283 (by decide +kernel) e13282 e13283
  have e13279 : Deny 5 11 b13279 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13279 b13280 b13281 (by decide +kernel) e13280 e13281
  have e13277 : Deny 5 11 b13277 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13277 b13278 b13279 (by decide +kernel) e13278 e13279
  have e13275 : Deny 5 11 b13275 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13275 b13276 b13277 (by decide +kernel) e13276 e13277
  have e13273 : Deny 5 11 b13273 :=
    branchAction rule_sound _ _ 3
      0xbae3 b13273 b13274 b13275 (by decide +kernel) e13274 e13275
  have e13338 : Deny 5 11 b13338 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13340 : Deny 5 11 b13340 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13341 : Deny 5 11 b13341 := by
    apply closeAction rule_sound _ _ 64 [0x9aae322b0820c98c8089ae32236ab8cb8daae32e3]
    decide +kernel
  have e13339 : Deny 5 11 b13339 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13339 b13340 b13341 (by decide +kernel) e13340 e13341
  have e13337 : Deny 5 11 b13337 :=
    branchAction rule_sound _ _ 4
      0x2f8ae3 b13337 b13338 b13339 (by decide +kernel) e13338 e13339
  have e13356 : Deny 5 11 b13356 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e13336 : Deny 5 11 b13336 :=
    branchAction rule_sound _ _ 3
      0x9e2b b13336 b13337 b13356 (by decide +kernel) e13337 e13356
  have e13272 : Deny 5 11 b13272 :=
    branchAction rule_sound _ _ 1
      0x8 b13272 b13273 b13336 (by decide +kernel) e13273 e13336
  have e13357 : Deny 5 11 b13357 := by
    apply closeAction rule_sound _ _ 64 [0x820820f80f82788c81f8ae3278ae3238]
    decide +kernel
  have e13271 : Deny 5 11 b13271 :=
    branchAction rule_sound _ _ 2
      0x1e3 b13271 b13272 b13357 (by decide +kernel) e13272 e13357
  have e13267 : Deny 5 11 b13267 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13267 b13268 b13271 (by decide +kernel) e13268 e13271
  have e13368 : Deny 5 11 b13368 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e13266 : Deny 5 11 b13266 :=
    branchAction rule_sound _ _ 3
      0x9e2b b13266 b13267 b13368 (by decide +kernel) e13267 e13368
  have e13174 : Deny 5 11 b13174 :=
    branchAction rule_sound _ _ 1
      0x8 b13174 b13175 b13266 (by decide +kernel) e13175 e13266
  have e12938 : Deny 5 11 b12938 :=
    branchAction rule_sound _ _ 2
      0x1e3 b12938 b12939 b13174 (by decide +kernel) e12939 e13174
  have e12826 : Deny 5 11 b12826 :=
    branchAction rule_sound _ _ 2
      0x2e3 b12826 b12827 b12938 (by decide +kernel) e12827 e12938
  exact e12826
end OMA.Blocks5_11_245212.S12826
