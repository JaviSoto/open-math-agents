import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S36922
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b36922 : Box := ![⟨47,62⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨3,1129131513647642686627⟩,⟨79,93⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,62⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨3,1129131513647642686627⟩,⟨79,93⟩] := by
  have e36922 : Deny 5 13 b36922 := by
    apply closeAction rule_sound _ _ 64 [0xf7da21e2284083109e030c98875430c988788a2c30c90f8da21c456210ae378880c3e37243e37da21c22221e22a3204,0x2631020832041f8dc30e31e32420c80f8dc38888870c31c988a2c30f8de31c3e378c98c88c78c90838880c90c32621d5,0x832070f70c82440820c72772c3e37103109e038870c920a09d203dc3df68c88c70f70f78880c223788788a0c3de31e3,0xe21e22020c9dc38870c3df688788888a2e21e2289ddcbdd702083be2222107e1d0f8be21e22222a31e325dbec88a742,0xe377f8dc3209107e15e378820c4278dc3888887dc20c9dc30c98870c324388788a0c3df6887de22040838841f8dc3e37,0x2be20820e2108]
    decide +kernel
  exact e36922
end OMA.Blocks5_13_245212.S36922
