import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S15411
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b15411 : Box := ![⟨47,94⟩,⟨10,14⟩,⟨19,1920000000000000011376⟩,⟨3,1210212765957446815727⟩,⟨77,109⟩]
private def b15412 : Box := ![⟨47,94⟩,⟨10,11⟩,⟨19,1920000000000000011376⟩,⟨3,1129131513647642686633⟩,⟨79,109⟩]
private def b15419 : Box := ![⟨47,94⟩,⟨12,14⟩,⟨19,1920000000000000011376⟩,⟨3,1129131513647642686633⟩,⟨79,109⟩]
private def b15420 : Box := ![⟨47,62⟩,⟨12,14⟩,⟨19,1920000000000000011376⟩,⟨3,1129131513647642686633⟩,⟨79,109⟩]
private def b15471 : Box := ![⟨63,94⟩,⟨12,14⟩,⟨19,1920000000000000011376⟩,⟨3,1129131513647642686633⟩,⟨79,109⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,94⟩,⟨10,14⟩,⟨19,1920000000000000011376⟩,⟨3,1210212765957446815727⟩,⟨77,109⟩] := by
  have e15412 : Deny 5 13 b15412 := by
    apply closeAction rule_sound _ _ 64 [0x72f76f8c9bdde37da3244087e37da3]
    decide +kernel
  have e15420 : Deny 5 13 b15420 := by
    apply closeAction rule_sound _ _ 64 [0x88a0a22a31dcbc472f8c4278df68c80ec088e37dac88a10b11d0c21c220a778df68c9738df68c7102238df68c4278da3,0x72f76f8c9087088df68c472f72f8c9bdd0c3e37887884778df688423888a8c972f70972325d]
    decide +kernel
  have e15471 : Deny 5 13 b15471 := by
    apply closeAction rule_sound _ _ 64 [0xf8df62030881cb283103de3107e232631c3778de31dde378c91021f8df68c85430f8df61c2204087e3724220a10b8c9,0xc90881c4083e370c92020c80c91cb283777d88777da31e311d0e325d2030c80dde37d881ca8cb8c9743088087df6103,0x8c976325de37da22a31e32042d588a7430f8243e37d8754a10223829de378c9778df68c7088df68c47420c9dc3df6203,0x887777d881020f70e21c3262203e370e21c30f8dc98888872e22a32631c2bddbe325d75d7552a228b54a88a8c972f76f,0xdf68c9087df6223102be2755e3775575554388788788a8878842b854a2222a32770af76f8c9bdd083887dc32430f7276,0x27888a08888788a54a2a325cbddbe326f743778df688711de37109e37da229ce37da321de37da31e32631dcbdc26f778,0x1cbddbe325d7557550f8887103e04]
    decide +kernel
  have e15419 : Deny 5 13 b15419 :=
    branchAction rule_sound _ _ 1
      0x7 b15419 b15420 b15471 (by decide +kernel) e15420 e15471
  have e15411 : Deny 5 13 b15411 :=
    branchAction rule_sound _ _ 3
      0x88c4 b15411 b15412 b15419 (by decide +kernel) e15412 e15419
  exact e15411
end OMA.Blocks5_13_245212.S15411
