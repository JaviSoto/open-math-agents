import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S55996
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b55996 : Box := ![⟨63,75⟩,⟨63,126⟩,⟨10,14⟩,⟨1,60⟩,⟨959,999999999999999999⟩]
private def b55997 : Box := ![⟨63,75⟩,⟨63,126⟩,⟨10,11⟩,⟨1,54⟩,⟨959,999999999999999999⟩]
private def b55998 : Box := ![⟨63,75⟩,⟨67,126⟩,⟨10,11⟩,⟨1,2⟩,⟨959,27869⟩]
private def b55999 : Box := ![⟨63,75⟩,⟨67,126⟩,⟨10,11⟩,⟨3,53⟩,⟨959,27869⟩]
private def b56000 : Box := ![⟨63,75⟩,⟨67,87⟩,⟨10,11⟩,⟨3,48⟩,⟨959,27847⟩]
private def b56003 : Box := ![⟨63,75⟩,⟨88,126⟩,⟨10,11⟩,⟨3,48⟩,⟨959,27847⟩]
private def b56004 : Box := ![⟨63,68⟩,⟨88,126⟩,⟨10,11⟩,⟨3,48⟩,⟨959,27766⟩]
private def b56007 : Box := ![⟨69,75⟩,⟨88,126⟩,⟨10,11⟩,⟨3,48⟩,⟨959,27766⟩]
private def b56008 : Box := ![⟨69,75⟩,⟨88,126⟩,⟨10,11⟩,⟨3,48⟩,⟨959,1854⟩]
private def b56019 : Box := ![⟨69,75⟩,⟨88,126⟩,⟨10,11⟩,⟨3,48⟩,⟨1855,27744⟩]
private def b56026 : Box := ![⟨63,75⟩,⟨63,126⟩,⟨12,14⟩,⟨1,54⟩,⟨959,999999999999999999⟩]
private def b56027 : Box := ![⟨63,75⟩,⟨63,84⟩,⟨12,14⟩,⟨1,54⟩,⟨959,999999999999999999⟩]
private def b56028 : Box := ![⟨63,68⟩,⟨63,84⟩,⟨12,14⟩,⟨1,44⟩,⟨959,999999999999999999⟩]
private def b56039 : Box := ![⟨69,75⟩,⟨63,84⟩,⟨12,14⟩,⟨1,44⟩,⟨959,999999999999999999⟩]
private def b56040 : Box := ![⟨69,75⟩,⟨63,84⟩,⟨12,14⟩,⟨1,44⟩,⟨959,1918⟩]
private def b56041 : Box := ![⟨69,75⟩,⟨63,84⟩,⟨12,14⟩,⟨1,2⟩,⟨959,1918⟩]
private def b56042 : Box := ![⟨69,75⟩,⟨63,84⟩,⟨12,14⟩,⟨3,39⟩,⟨959,1918⟩]
private def b56053 : Box := ![⟨69,75⟩,⟨63,84⟩,⟨12,14⟩,⟨1,44⟩,⟨1919,999999999999999999⟩]
private def b56062 : Box := ![⟨63,75⟩,⟨85,126⟩,⟨12,14⟩,⟨1,54⟩,⟨959,999999999999999999⟩]
private def b56063 : Box := ![⟨63,68⟩,⟨85,126⟩,⟨12,14⟩,⟨1,54⟩,⟨959,999999999999999999⟩]
private def b56064 : Box := ![⟨63,68⟩,⟨85,126⟩,⟨12,14⟩,⟨1,53⟩,⟨959,1918⟩]
private def b56065 : Box := ![⟨63,68⟩,⟨85,101⟩,⟨12,14⟩,⟨2,48⟩,⟨959,1918⟩]
private def b56074 : Box := ![⟨63,68⟩,⟨102,126⟩,⟨12,14⟩,⟨2,48⟩,⟨959,1918⟩]
private def b56083 : Box := ![⟨63,68⟩,⟨85,126⟩,⟨12,14⟩,⟨1,53⟩,⟨1919,999999999999999999⟩]
private def b56084 : Box := ![⟨63,68⟩,⟨85,101⟩,⟨12,14⟩,⟨1,48⟩,⟨1919,999999999999999999⟩]
private def b56091 : Box := ![⟨63,68⟩,⟨102,126⟩,⟨12,14⟩,⟨1,48⟩,⟨1919,999999999999999999⟩]
private def b56102 : Box := ![⟨69,75⟩,⟨85,126⟩,⟨12,14⟩,⟨1,54⟩,⟨959,999999999999999999⟩]
private def b56103 : Box := ![⟨69,75⟩,⟨85,126⟩,⟨12,14⟩,⟨1,54⟩,⟨959,1918⟩]
private def b56104 : Box := ![⟨69,75⟩,⟨85,126⟩,⟨12,14⟩,⟨1,2⟩,⟨959,1918⟩]
private def b56105 : Box := ![⟨69,75⟩,⟨85,126⟩,⟨12,14⟩,⟨3,49⟩,⟨959,1918⟩]
private def b56106 : Box := ![⟨69,75⟩,⟨85,101⟩,⟨12,14⟩,⟨3,49⟩,⟨959,1918⟩]
private def b56115 : Box := ![⟨69,75⟩,⟨102,126⟩,⟨12,14⟩,⟨3,49⟩,⟨959,1918⟩]
private def b56120 : Box := ![⟨69,75⟩,⟨85,126⟩,⟨12,14⟩,⟨1,54⟩,⟨1919,999999999999999999⟩]
private def b56121 : Box := ![⟨69,75⟩,⟨85,101⟩,⟨12,14⟩,⟨1,49⟩,⟨1919,999999999999999999⟩]
private def b56132 : Box := ![⟨69,75⟩,⟨102,126⟩,⟨12,14⟩,⟨1,49⟩,⟨1919,999999999999999999⟩]
private theorem e55998 : Deny 5 13 b55998 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
private theorem e56000 : Deny 5 13 b56000 := by
    apply closeAction rule_sound _ _ 64 [0x6f71021f8de3]
    decide +kernel
private theorem e56004 : Deny 5 13 b56004 := by
    apply closeAction rule_sound _ _ 64 [0x6eb088e23]
    decide +kernel
private theorem e56008 : Deny 5 13 b56008 := by
    apply closeAction rule_sound _ _ 64 [0x6eb0c3e2b26322b0c3e378c70898c8]
    decide +kernel
private theorem e56019 : Deny 5 13 b56019 := by
    apply closeAction rule_sound _ _ 64 [0xf8ac3e378c8e03e351f8089e23]
    decide +kernel
private theorem e56007 : Deny 5 13 b56007 :=
    branchAction rule_sound _ _ 2
      0x2f8 b56007 b56008 b56019 (by decide +kernel) e56008 e56019
private theorem e56003 : Deny 5 13 b56003 :=
    branchAction rule_sound _ _ 2
      0x1f8 b56003 b56004 b56007 (by decide +kernel) e56004 e56007
private theorem e55999 : Deny 5 13 b55999 :=
    branchAction rule_sound _ _ 3
      0x8e23 b55999 b56000 b56003 (by decide +kernel) e56000 e56003
private theorem e55997 : Deny 5 13 b55997 :=
    branchAction rule_sound _ _ 4
      0x2b8d63 b55997 b55998 b55999 (by decide +kernel) e55998 e55999
private theorem e56028 : Deny 5 13 b56028 := by
    apply closeAction rule_sound _ _ 64 [0x30f81f80c21f88c84cae23089e23]
    decide +kernel
private theorem e56041 : Deny 5 13 b56041 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
private theorem e56042 : Deny 5 13 b56042 := by
    apply closeAction rule_sound _ _ 64 [0x3e031c32430c76f8dc98c8]
    decide +kernel
private theorem e56040 : Deny 5 13 b56040 :=
    branchAction rule_sound _ _ 2
      0x2a3 b56040 b56041 b56042 (by decide +kernel) e56041 e56042
private theorem e56053 : Deny 5 13 b56053 := by
    apply closeAction rule_sound _ _ 64 [0x30c70f88dbe378c7e2321be37d63263]
    decide +kernel
private theorem e56039 : Deny 5 13 b56039 :=
    branchAction rule_sound _ _ 1
      0xb b56039 b56040 b56053 (by decide +kernel) e56040 e56053
private theorem e56027 : Deny 5 13 b56027 :=
    branchAction rule_sound _ _ 2
      0x1e3 b56027 b56028 b56039 (by decide +kernel) e56028 e56039
private theorem e56065 : Deny 5 13 b56065 := by
    apply closeAction rule_sound _ _ 64 [0xf80c7ac38c80dbe371f8ae3263]
    decide +kernel
private theorem e56074 : Deny 5 13 b56074 := by
    apply closeAction rule_sound _ _ 64 [0x2083e2b2631f80f80eb1e326b]
    decide +kernel
private theorem e56064 : Deny 5 13 b56064 :=
    branchAction rule_sound _ _ 3
      0x8ae3 b56064 b56065 b56074 (by decide +kernel) e56065 e56074
private theorem e56084 : Deny 5 13 b56084 := by
    apply closeAction rule_sound _ _ 64 [0xc3e231c3e23202263]
    decide +kernel
private theorem e56091 : Deny 5 13 b56091 := by
    apply closeAction rule_sound _ _ 64 [0x83ac90c38c8ac70f8ae36b8deb8c7e2b8c9]
    decide +kernel
private theorem e56083 : Deny 5 13 b56083 :=
    branchAction rule_sound _ _ 2
      0x223 b56083 b56084 b56091 (by decide +kernel) e56084 e56091
private theorem e56063 : Deny 5 13 b56063 :=
    branchAction rule_sound _ _ 2
      0x2e3 b56063 b56064 b56083 (by decide +kernel) e56064 e56083
private theorem e56104 : Deny 5 13 b56104 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
private theorem e56106 : Deny 5 13 b56106 := by
    apply closeAction rule_sound _ _ 64 [0x820f88c88c7e03e038c7263]
    decide +kernel
private theorem e56115 : Deny 5 13 b56115 := by
    apply closeAction rule_sound _ _ 64 [0x2083e2b8c78c9e2b]
    decide +kernel
private theorem e56105 : Deny 5 13 b56105 :=
    branchAction rule_sound _ _ 1
      0x8 b56105 b56106 b56115 (by decide +kernel) e56106 e56115
private theorem e56103 : Deny 5 13 b56103 :=
    branchAction rule_sound _ _ 2
      0x2a3 b56103 b56104 b56105 (by decide +kernel) e56104 e56105
private theorem e56121 : Deny 5 13 b56121 := by
    apply closeAction rule_sound _ _ 64 [0x20f88c9e030e32231c30f8de31e3263]
    decide +kernel
private theorem e56132 : Deny 5 13 b56132 := by
    apply closeAction rule_sound _ _ 64 [0x2083e232388c7e03e03ac78c9]
    decide +kernel
private theorem e56120 : Deny 5 13 b56120 :=
    branchAction rule_sound _ _ 2
      0x223 b56120 b56121 b56132 (by decide +kernel) e56121 e56132
private theorem e56102 : Deny 5 13 b56102 :=
    branchAction rule_sound _ _ 1
      0xb b56102 b56103 b56120 (by decide +kernel) e56103 e56120
private theorem e56062 : Deny 5 13 b56062 :=
    branchAction rule_sound _ _ 1
      0x7 b56062 b56063 b56102 (by decide +kernel) e56063 e56102
private theorem e56026 : Deny 5 13 b56026 :=
    branchAction rule_sound _ _ 1
      0x8 b56026 b56027 b56062 (by decide +kernel) e56027 e56062
private theorem e55996 : Deny 5 13 b55996 :=
    branchAction rule_sound _ _ 2
      0x263 b55996 b55997 b56026 (by decide +kernel) e55997 e56026
theorem deny5_13 : Deny 5 13 ![⟨63,75⟩,⟨63,126⟩,⟨10,14⟩,⟨1,60⟩,⟨959,999999999999999999⟩] := by
  exact e55996
end OMA.Blocks5_13_245212.S55996
