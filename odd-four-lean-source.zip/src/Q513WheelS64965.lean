import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S64965
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b64965 : Box := ![⟨95,126⟩,⟨127,1920000000000000011376⟩,⟨7,7⟩,⟨1,502335381913959616714⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,126⟩,⟨127,1920000000000000011376⟩,⟨7,7⟩,⟨1,502335381913959616714⟩,⟨479,999999999999999999⟩] := by
  have e64965 : Deny 5 13 b64965 := by
    apply closeAction rule_sound _ _ 64 [0xd631e36eb8cb6eb8c22388c88db4caae32dbae36eb8c8e358c78c88c26ab8c7e2b6f86eb8c78c84eba212a32d2e212a3,0x2e36ab8cb8daae32f8adbe2b8c8ae31eb0c31eb0888dbae32e36eb8cb8dbae32dbe378c78dbae32eb0888dbae32dbe37,0x6ab8cbe2b8c8e020826ab8c8ac21f51eb6ab8c80878c7adaae322b6ab8c88daae32e36ab8cb8daae32e36ab8cb8daae3,0x8209a68be2b8c7e2b8c88c7e2b8db6da6caac22351f5ae31e36cb8db2e36cb8db2e36cb8db2e36cb8db2e3]
    decide +kernel
  exact e64965
end OMA.Blocks5_13_245212.S64965
