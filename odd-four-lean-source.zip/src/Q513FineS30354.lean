import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S30354
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b30354 : Box := ![⟨34,37⟩,⟨255,1920000000000000011376⟩,⟨63,1920000000000000011376⟩,⟨1,1169881610102604584701⟩,⟨959,999999999999999999⟩]
private def b30355 : Box := ![⟨34,37⟩,⟨255,1920000000000000011376⟩,⟨63,1920000000000000011376⟩,⟨1,2⟩,⟨959,999999999999999999⟩]
private def b30356 : Box := ![⟨34,37⟩,⟨255,1920000000000000011376⟩,⟨63,1920000000000000011376⟩,⟨3,1169881610102604584701⟩,⟨959,999999999999999999⟩]
private def b30357 : Box := ![⟨34,37⟩,⟨255,1920000000000000011376⟩,⟨63,126⟩,⟨3,1169881610102604584701⟩,⟨959,999999999999999999⟩]
private def b30358 : Box := ![⟨34,35⟩,⟨255,1920000000000000011376⟩,⟨63,126⟩,⟨3,451586424625098660990⟩,⟨959,999999999999999999⟩]
private def b30551 : Box := ![⟨36,37⟩,⟨255,1920000000000000011376⟩,⟨63,126⟩,⟨3,451586424625098660990⟩,⟨959,999999999999999999⟩]
private def b30622 : Box := ![⟨34,37⟩,⟨255,1920000000000000011376⟩,⟨127,1920000000000000011376⟩,⟨3,1169881610102604584701⟩,⟨959,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨34,37⟩,⟨255,1920000000000000011376⟩,⟨63,1920000000000000011376⟩,⟨1,1169881610102604584701⟩,⟨959,999999999999999999⟩] := by
  have e30355 : Deny 5 13 b30355 := by
    apply closeAction rule_sound _ _ 64 [0x16aa2]
    decide +kernel
  have e30358 : Deny 5 13 b30358 := by
    apply closeAction rule_sound _ _ 64 [0x58a8c87ab8c98c8ae32de78badee2321ee358c9adee37dab8c8db58deae32c21e37ab8cbae32632237ab7962ab8c88cb,0x8c87ab8deae32f88c97b8df68c88de58aae32deae3088e232632237962ab8cb7ab8deae32388c90878c88deadeade58a,0x8498492962d62d62962d62ca8deae32e37ab8cb8deae32e37ab8cb8deae32e37ab8cb8deae32e37ab8cb8deae32c30f8,0x8c88deae32e37ab8cb8deae32e37ab8cb8deae32e37ab8cb8deae32dee37db51e37ab8cb8deae32e37ab8cbade796582,0xadaae322368b6b8ae3247adeae32236ab8cbadeae32236ab8cbae326b7ab79e0820e1242849ae126a84a48b2a37ab8cb,0x2e37ab8cb8deae32e31f808208209aae3238adaae3223278ae36ab8c8e1ae358c9adaae322368b8c9adaae322368b8c9,0x209eae322b7ab8c88deae3]
    decide +kernel
  have e30551 : Deny 5 13 b30551 := by
    apply closeAction rule_sound _ _ 64 [0x2237ab8cb8deae32e37ab8cb8deae32e37ab8cb8deae32e37ab8cb8deae32e37ab8cb8deae32e37ab8cbe2b8c9e23238,0xe03e2b8c9e232388c9e232388c9e07e232387ab79e09e0aa84a1deae12522d22d22d22d22e1296aea84b48b48b48b2a3,0x82082082083]
    decide +kernel
  have e30357 : Deny 5 13 b30357 :=
    branchAction rule_sound _ _ 2
      0x1e3 b30357 b30358 b30551 (by decide +kernel) e30358 e30551
  have e30622 : Deny 5 13 b30622 := by
    apply closeAction rule_sound _ _ 64 [0x2d62d62d62d62d62d62d62d62d62e22b88c91e32388de7962d62d62d62d62d62d62d62d62d62d62ca8c9e162a32231f8,0x820820827ab8c9e2b8c9e07e2322327808209ebe3278bde796]
    decide +kernel
  have e30356 : Deny 5 13 b30356 :=
    branchAction rule_sound _ _ 1
      0x9 b30356 b30357 b30622 (by decide +kernel) e30357 e30622
  have e30354 : Deny 5 13 b30354 :=
    branchAction rule_sound _ _ 1
      0xa b30354 b30355 b30356 (by decide +kernel) e30355 e30356
  exact e30354
end OMA.Blocks5_13_245212.S30354
