import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S61886
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b61886 : Box := ![⟨63,94⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨1,565934718100890211119⟩,⟨239,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨1,565934718100890211119⟩,⟨239,999999999999999999⟩] := by
  have e61886 : Deny 5 13 b61886 := by
    apply closeAction rule_sound _ _ 64 [0xe032780c31c81c928a5ca8cb8c88c98c78c2082093e37097e370e32788c8e172a31e32635f710b8c88c98c78cbe23238,0x8c9e03e031e32231c20f88c9e03e031c3263203e031c38c90c3e078c88c78c98df7c20820c7e081f80820f8248e020c7,0x82083e232381f88c8e232788c7e232380820820f88c8e03e031e32630820f88c7e2b8c98cbe232388c7e232780820f8,0x82082082083e232788c8e231f88c9e232388c9e02082]
    decide +kernel
  exact e61886
end OMA.Blocks5_13_245212.S61886
