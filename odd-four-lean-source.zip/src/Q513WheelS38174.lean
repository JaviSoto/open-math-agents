import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S38174
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b38174 : Box := ![⟨47,94⟩,⟨31,1920000000000000011376⟩,⟨7,14⟩,⟨3,760851063829787238599⟩,⟨59,77⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,94⟩,⟨31,1920000000000000011376⟩,⟨7,14⟩,⟨3,760851063829787238599⟩,⟨59,77⟩] := by
  have e38174 : Deny 5 13 b38174 := by
    apply closeAction rule_sound _ _ 64 [0x820832091c4238dc209b083108e370c92a31c4238093278dd3e370f8dc32480f8dc32032471024c9dc42c82891c8dc4,0x20824c9278dc2]
    decide +kernel
  exact e38174
end OMA.Blocks5_13_245212.S38174
