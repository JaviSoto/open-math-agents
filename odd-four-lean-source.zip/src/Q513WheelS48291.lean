import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S48291
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b48291 : Box := ![⟨255,382⟩,⟨18,20⟩,⟨127,1920000000000000011376⟩,⟨3,718295185477505923831⟩,⟨959,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨255,382⟩,⟨18,20⟩,⟨127,1920000000000000011376⟩,⟨3,718295185477505923831⟩,⟨959,999999999999999999⟩] := by
  have e48291 : Deny 5 13 b48291 := by
    apply closeAction rule_sound _ _ 64 [0xbe32e31dd7552d52d52d52d52d52d52cae1529d54ae2354ae231e32630af578ddd54ae152a31e32632f88c7e23263238,0xe231f88c9e1d7552952952e22a376f8cb8ddbe32e376f8cb8ddbe32e376f8cb8ddbe32e376f8cb8ddbe32e376f8cb8dd,0x8c7e07e232788c7e23278be31f8be3278be31f8bc2082082083e231f88c9e231f88c9e231f88c9e02082083e231f88c9,0x820820820827780f8]
    decide +kernel
  exact e48291
end OMA.Blocks5_13_245212.S48291
