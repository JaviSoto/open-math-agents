import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S24591
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b24591 : Box := ![⟨31,37⟩,⟨31,62⟩,⟨15,30⟩,⟨3,50⟩,⟨127,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨31,37⟩,⟨31,62⟩,⟨15,30⟩,⟨3,50⟩,⟨127,233⟩] := by
  have e24591 : Deny 5 13 b24591 := by
    apply closeAction rule_sound _ _ 64 [0xf8dc9087102238df61c30f8dc90f8df61dfe37d88087e092842c40dfe378c77f8de325fe37da3204087e37da3108e23,0xd631f68c47c30c80c90c3e37277d87117e370c8dc32430c80c91c42c3088087df61030c80dfe37277d8710b2030f8dc8,0x7c30f8dc80f8dc911fe37d841f829fe378c87f8df58c97b8df6]
    decide +kernel
  exact e24591
end OMA.Blocks5_13_245212.S24591
