import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S31032
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b31032 : Box := ![⟨42,46⟩,⟨63,126⟩,⟨31,62⟩,⟨1,75⟩,⟨479,958⟩]
theorem deny5_13 : Deny 5 13 ![⟨42,46⟩,⟨63,126⟩,⟨31,62⟩,⟨1,75⟩,⟨479,958⟩] := by
  have e31032 : Deny 5 13 b31032 := by
    apply closeAction rule_sound _ _ 64 [0x1cb25f7f87c72d629f583e031c95c3e072570f8d872160f8242238d875ca29f5d60c3e080f8d885ca24728b2482972a3,0x1f0961f87c20820c42380c7248e02a83e031c85832430f82092211d72a1297e375f8ddf583e03209288]
    decide +kernel
  exact e31032
end OMA.Blocks5_13_245212.S31032
