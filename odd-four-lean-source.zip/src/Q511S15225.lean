import FastReplay245212
import SparseDigit245212
import FastRound245212
import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S15225
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b15225 : Box := ![⟨23,46⟩,⟨10,14⟩,⟨7,1920000000000000011376⟩,⟨1,1160381991814461125599⟩,⟨53,101⟩]
private def b15226 : Box := ![⟨23,46⟩,⟨10,14⟩,⟨7,14⟩,⟨1,1160381991814461125599⟩,⟨53,101⟩]
private def b15227 : Box := ![⟨23,30⟩,⟨10,14⟩,⟨7,14⟩,⟨1,30⟩,⟨53,101⟩]
private def b15228 : Box := ![⟨23,30⟩,⟨10,14⟩,⟨7,14⟩,⟨1,2⟩,⟨53,101⟩]
private def b15233 : Box := ![⟨23,30⟩,⟨10,14⟩,⟨7,14⟩,⟨3,25⟩,⟨53,101⟩]
private def b15246 : Box := ![⟨31,46⟩,⟨10,14⟩,⟨7,14⟩,⟨1,30⟩,⟨53,101⟩]
private def b15247 : Box := ![⟨31,46⟩,⟨10,14⟩,⟨7,14⟩,⟨1,2⟩,⟨53,101⟩]
private def b15248 : Box := ![⟨31,46⟩,⟨10,14⟩,⟨7,14⟩,⟨1,2⟩,⟨53,69⟩]
private def b15263 : Box := ![⟨31,46⟩,⟨10,14⟩,⟨7,14⟩,⟨1,2⟩,⟨70,101⟩]
private def b15276 : Box := ![⟨31,46⟩,⟨10,14⟩,⟨7,14⟩,⟨3,30⟩,⟨53,101⟩]
private def b15277 : Box := ![⟨31,46⟩,⟨10,14⟩,⟨7,14⟩,⟨3,30⟩,⟨53,69⟩]
private def b15292 : Box := ![⟨31,46⟩,⟨10,14⟩,⟨7,14⟩,⟨3,30⟩,⟨70,101⟩]
private def b15307 : Box := ![⟨23,46⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨1,1160381991814461125599⟩,⟨53,101⟩]
private def b15308 : Box := ![⟨23,30⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨1,1160381991814461125599⟩,⟨53,101⟩]
private def b15309 : Box := ![⟨23,30⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨1,2⟩,⟨53,101⟩]
private def b15310 : Box := ![⟨23,30⟩,⟨10,14⟩,⟨15,31⟩,⟨1,2⟩,⟨53,69⟩]
private def b15323 : Box := ![⟨23,30⟩,⟨10,14⟩,⟨15,31⟩,⟨1,2⟩,⟨70,101⟩]
private def b15332 : Box := ![⟨23,30⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨3,1160381991814461125594⟩,⟨53,101⟩]
private def b15333 : Box := ![⟨23,30⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨3,1160381991814461125594⟩,⟨53,69⟩]
private def b15334 : Box := ![⟨23,30⟩,⟨10,14⟩,⟨15,30⟩,⟨3,1160381991814461125594⟩,⟨53,67⟩]
private def b15347 : Box := ![⟨23,30⟩,⟨10,14⟩,⟨31,1920000000000000011376⟩,⟨3,1160381991814461125594⟩,⟨53,67⟩]
private def b15348 : Box := ![⟨23,30⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,1160381991814461125594⟩,⟨53,67⟩]
private def b15349 : Box := ![⟨23,30⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,6⟩,⟨53,67⟩]
private def b15350 : Box := ![⟨23,30⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨7,1160381991814461125593⟩,⟨53,67⟩]
private def b15351 : Box := ![⟨23,26⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨7,1160381991814461125593⟩,⟨53,67⟩]
private def b15366 : Box := ![⟨27,30⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨7,1160381991814461125593⟩,⟨53,67⟩]
private def b15369 : Box := ![⟨23,30⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨3,1160381991814461125594⟩,⟨53,67⟩]
private def b15372 : Box := ![⟨23,30⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨3,1160381991814461125594⟩,⟨70,101⟩]
private def b15373 : Box := ![⟨23,30⟩,⟨10,14⟩,⟨15,30⟩,⟨3,1080762388818297338069⟩,⟨71,101⟩]
private def b15386 : Box := ![⟨23,30⟩,⟨10,14⟩,⟨31,1920000000000000011376⟩,⟨3,1080762388818297338069⟩,⟨71,101⟩]
private def b15387 : Box := ![⟨23,30⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,1080762388818297338069⟩,⟨71,101⟩]
private def b15388 : Box := ![⟨23,26⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,1080762388818297338068⟩,⟨71,101⟩]
private def b15389 : Box := ![⟨23,26⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,6⟩,⟨71,101⟩]
private def b15390 : Box := ![⟨23,26⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨7,1080762388818297338067⟩,⟨71,101⟩]
private def b15391 : Box := ![⟨23,26⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨7,1080762388818297338067⟩,⟨71,83⟩]
private def b15400 : Box := ![⟨23,26⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨7,1080762388818297338067⟩,⟨84,101⟩]
private def b15411 : Box := ![⟨27,30⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,1080762388818297338068⟩,⟨71,101⟩]
private def b15412 : Box := ![⟨27,30⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,6⟩,⟨71,101⟩]
private def b15413 : Box := ![⟨27,30⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨7,1080762388818297338068⟩,⟨71,101⟩]
private def b15414 : Box := ![⟨27,30⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨7,1080762388818297338068⟩,⟨71,83⟩]
private def b15423 : Box := ![⟨27,30⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨7,1080762388818297338068⟩,⟨84,101⟩]
private def b15432 : Box := ![⟨23,30⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨3,1080762388818297338069⟩,⟨71,101⟩]
private def b15433 : Box := ![⟨23,26⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨3,1080762388818297338069⟩,⟨71,101⟩]
private def b15434 : Box := ![⟨23,26⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨3,6⟩,⟨71,101⟩]
private def b15435 : Box := ![⟨23,26⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨7,1080762388818297338068⟩,⟨71,101⟩]
private def b15436 : Box := ![⟨23,26⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨7,1080762388818297338068⟩,⟨71,83⟩]
private def b15445 : Box := ![⟨23,26⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨7,1080762388818297338068⟩,⟨84,101⟩]
private def b15458 : Box := ![⟨27,30⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨3,1080762388818297338069⟩,⟨71,101⟩]
private def b15469 : Box := ![⟨31,46⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨1,1160381991814461125599⟩,⟨53,101⟩]
private def b15470 : Box := ![⟨31,46⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨1,2⟩,⟨53,101⟩]
private def b15471 : Box := ![⟨31,46⟩,⟨10,14⟩,⟨15,38⟩,⟨1,2⟩,⟨53,69⟩]
private def b15472 : Box := ![⟨31,46⟩,⟨10,11⟩,⟨15,38⟩,⟨1,2⟩,⟨53,67⟩]
private def b15483 : Box := ![⟨31,46⟩,⟨12,14⟩,⟨15,38⟩,⟨1,2⟩,⟨53,67⟩]
private def b15484 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨15,38⟩,⟨1,2⟩,⟨53,67⟩]
private def b15485 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨15,34⟩,⟨1,2⟩,⟨53,59⟩]
private def b15492 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨15,34⟩,⟨1,2⟩,⟨60,67⟩]
private def b15501 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨15,38⟩,⟨1,2⟩,⟨53,67⟩]
private def b15506 : Box := ![⟨31,46⟩,⟨10,14⟩,⟨15,38⟩,⟨1,2⟩,⟨70,101⟩]
private def b15507 : Box := ![⟨31,46⟩,⟨10,11⟩,⟨15,38⟩,⟨1,2⟩,⟨71,101⟩]
private def b15508 : Box := ![⟨31,37⟩,⟨10,11⟩,⟨15,36⟩,⟨1,2⟩,⟨71,101⟩]
private def b15513 : Box := ![⟨38,46⟩,⟨10,11⟩,⟨15,36⟩,⟨1,2⟩,⟨71,101⟩]
private def b15514 : Box := ![⟨38,46⟩,⟨10,11⟩,⟨15,36⟩,⟨1,1⟩,⟨71,101⟩]
private def b15515 : Box := ![⟨38,46⟩,⟨10,11⟩,⟨15,36⟩,⟨2,2⟩,⟨71,101⟩]
private def b15530 : Box := ![⟨31,46⟩,⟨12,14⟩,⟨15,38⟩,⟨1,2⟩,⟨71,101⟩]
private def b15531 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨15,38⟩,⟨1,2⟩,⟨71,101⟩]
private def b15532 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨15,34⟩,⟨1,2⟩,⟨71,83⟩]
private def b15541 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨15,34⟩,⟨1,2⟩,⟨84,101⟩]
private def b15550 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨15,38⟩,⟨1,2⟩,⟨71,101⟩]
private def b15551 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨15,38⟩,⟨1,2⟩,⟨71,83⟩]
private def b15558 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨15,38⟩,⟨1,2⟩,⟨84,101⟩]
private def b15567 : Box := ![⟨31,46⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨3,1160381991814461125599⟩,⟨53,101⟩]
private def b15568 : Box := ![⟨31,46⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨3,1160381991814461125599⟩,⟨53,69⟩]
private def b15583 : Box := ![⟨31,46⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨3,1160381991814461125599⟩,⟨70,101⟩]
private def b15584 : Box := ![⟨31,46⟩,⟨10,14⟩,⟨15,30⟩,⟨3,1080762388818297338073⟩,⟨71,101⟩]
private def b15585 : Box := ![⟨31,46⟩,⟨10,11⟩,⟨15,30⟩,⟨3,37⟩,⟨71,101⟩]
private def b15586 : Box := ![⟨31,37⟩,⟨10,11⟩,⟨15,30⟩,⟨3,36⟩,⟨71,101⟩]
private def b15591 : Box := ![⟨38,46⟩,⟨10,11⟩,⟨15,30⟩,⟨3,36⟩,⟨71,101⟩]
private def b15606 : Box := ![⟨31,46⟩,⟨12,14⟩,⟨15,30⟩,⟨3,37⟩,⟨71,101⟩]
private def b15607 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨15,30⟩,⟨3,37⟩,⟨71,101⟩]
private def b15622 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨15,30⟩,⟨3,37⟩,⟨71,101⟩]
private def b15627 : Box := ![⟨31,46⟩,⟨10,14⟩,⟨31,1920000000000000011376⟩,⟨3,1080762388818297338073⟩,⟨71,101⟩]
private def b15628 : Box := ![⟨31,46⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,1080762388818297338073⟩,⟨71,101⟩]
private def b15629 : Box := ![⟨31,37⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,1080762388818297338072⟩,⟨71,101⟩]
private def b15630 : Box := ![⟨31,37⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,1080762388818297338070⟩,⟨71,83⟩]
private def b15639 : Box := ![⟨31,37⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,1080762388818297338070⟩,⟨84,101⟩]
private def b15640 : Box := ![⟨31,37⟩,⟨10,11⟩,⟨31,62⟩,⟨3,1027246376811594209011⟩,⟨89,101⟩]
private def b15653 : Box := ![⟨31,37⟩,⟨10,11⟩,⟨63,1920000000000000011376⟩,⟨3,1027246376811594209011⟩,⟨89,101⟩]
private def b15656 : Box := ![⟨38,46⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,1080762388818297338072⟩,⟨71,101⟩]
private def b15659 : Box := ![⟨31,46⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨3,1080762388818297338073⟩,⟨71,101⟩]
theorem deny5_11 : Deny 5 11 ![⟨23,46⟩,⟨10,14⟩,⟨7,1920000000000000011376⟩,⟨1,1160381991814461125599⟩,⟨53,101⟩] := by
  have e15228 : Deny 5 11 b15228 := by
    apply closeAction rule_sound _ _ 64 [0x30f8df61c4088e36]
    decide +kernel
  have e15233 : Deny 5 11 b15233 := by
    apply closeAction rule_sound _ _ 64 [0xc3e37da31f60f8df68c88c40c38c70c3e378c98c810b]
    decide +kernel
  have e15227 : Deny 5 11 b15227 :=
    branchAction rule_sound _ _ 2
      0x2a3 b15227 b15228 b15233 (by decide +kernel) e15228 e15233
  have e15248 : Deny 5 11 b15248 := by
    apply closeAction rule_sound _ _ 64 [0xf8dc31c32030c72430f8dc70f8dc9204]
    decide +kernel
  have e15263 : Deny 5 11 b15263 := by
    apply closeAction rule_sound _ _ 64 [0xc31c3203103e37d841f82431021f8df6204]
    decide +kernel
  have e15247 : Deny 5 11 b15247 :=
    branchAction rule_sound _ _ 1
      0xb b15247 b15248 b15263 (by decide +kernel) e15248 e15263
  have e15277 : Deny 5 11 b15277 := by
    apply closeAction rule_sound _ _ 64 [0x83e370c8107e370f70e31e3243dc38c70e3263204]
    decide +kernel
  have e15292 : Deny 5 11 b15292 := by
    apply closeAction rule_sound _ _ 64 [0x3e370e31c38c80c38c78c90c3e231c3e378c98c88c4]
    decide +kernel
  have e15276 : Deny 5 11 b15276 :=
    branchAction rule_sound _ _ 1
      0xb b15276 b15277 b15292 (by decide +kernel) e15277 e15292
  have e15246 : Deny 5 11 b15246 :=
    branchAction rule_sound _ _ 1
      0xa b15246 b15247 b15276 (by decide +kernel) e15247 e15276
  have e15226 : Deny 5 11 b15226 :=
    branchAction rule_sound _ _ 2
      0x1e3 b15226 b15227 b15246 (by decide +kernel) e15227 e15246
  have e15310 : Deny 5 11 b15310 := by
    apply closeAction rule_sound _ _ 64 [0xc31c30f78878870c3e090b8da21f7888884]
    decide +kernel
  have e15323 : Deny 5 11 b15323 := by
    apply closeAction rule_sound _ _ 64 [0x30f8243e37da21c3e37da2202204]
    decide +kernel
  have e15309 : Deny 5 11 b15309 :=
    branchAction rule_sound _ _ 2
      0x2e2 b15309 b15310 b15323 (by decide +kernel) e15310 e15323
  have e15334 : Deny 5 11 b15334 := by
    apply closeAction rule_sound _ _ 64 [0x20c4278dc3dc38c78c70c38c70e3263223]
    decide +kernel
  have e15349 : Deny 5 11 b15349 := by
    apply closeAction rule_sound _ _ 64 [0x3be2]
    decide +kernel
  have e15351 : Deny 5 11 b15351 := by
    apply closeAction rule_sound _ _ 64 [0x2be311cbe3109e2f0f8dc3bc7bc38c98c98c4082bc32772772e3]
    decide +kernel
  have e15366 : Deny 5 11 b15366 := by
    apply closeAction rule_sound _ _ 64 [0x20e2109e37]
    decide +kernel
  have e15350 : Deny 5 11 b15350 :=
    branchAction rule_sound _ _ 1
      0x7 b15350 b15351 b15366 (by decide +kernel) e15351 e15366
  have e15348 : Deny 5 11 b15348 :=
    branchAction rule_sound _ _ 2
      0x2a3 b15348 b15349 b15350 (by decide +kernel) e15349 e15350
  have e15369 : Deny 5 11 b15369 := by
    apply closeAction rule_sound _ _ 64 [0x83887e37]
    decide +kernel
  have e15347 : Deny 5 11 b15347 :=
    branchAction rule_sound _ _ 1
      0x8 b15347 b15348 b15369 (by decide +kernel) e15348 e15369
  have e15333 : Deny 5 11 b15333 :=
    branchAction rule_sound _ _ 2
      0x244 b15333 b15334 b15347 (by decide +kernel) e15334 e15347
  have e15373 : Deny 5 11 b15373 := by
    apply closeAction rule_sound _ _ 64 [0x30e31c30e31e31c30f8de31c40f8de3109e23223]
    decide +kernel
  have e15389 : Deny 5 11 b15389 := by
    apply closeAction rule_sound _ _ 64 [0x3e37be2]
    decide +kernel
  have e15391 : Deny 5 11 b15391 := by
    apply closeAction rule_sound _ _ 64 [0x72f72f8c9bc30f88c7bc38c98c9]
    decide +kernel
  have e15400 : Deny 5 11 b15400 := by
    apply closeAction rule_sound _ _ 64 [0x72f709bdc7042b8da32760af88a738df62368c4]
    decide +kernel
  have e15390 : Deny 5 11 b15390 :=
    branchAction rule_sound _ _ 1
      0xb b15390 b15391 b15400 (by decide +kernel) e15391 e15400
  have e15388 : Deny 5 11 b15388 :=
    branchAction rule_sound _ _ 2
      0x2a3 b15388 b15389 b15390 (by decide +kernel) e15389 e15390
  have e15412 : Deny 5 11 b15412 := by
    apply closeAction rule_sound _ _ 64 [0x3e22]
    decide +kernel
  have e15414 : Deny 5 11 b15414 := by
    apply closeAction rule_sound _ _ 64 [0x272f884238def0838c4238bc38c98c9]
    decide +kernel
  have e15423 : Deny 5 11 b15423 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdcbe326f0c3e08bc38c98c98c4]
    decide +kernel
  have e15413 : Deny 5 11 b15413 :=
    branchAction rule_sound _ _ 1
      0xb b15413 b15414 b15423 (by decide +kernel) e15414 e15423
  have e15411 : Deny 5 11 b15411 :=
    branchAction rule_sound _ _ 1
      0xa b15411 b15412 b15413 (by decide +kernel) e15412 e15413
  have e15387 : Deny 5 11 b15387 :=
    branchAction rule_sound _ _ 2
      0x1e3 b15387 b15388 b15411 (by decide +kernel) e15388 e15411
  have e15434 : Deny 5 11 b15434 := by
    apply closeAction rule_sound _ _ 64 [0xe2]
    decide +kernel
  have e15436 : Deny 5 11 b15436 := by
    apply closeAction rule_sound _ _ 64 [0x14e37bc2bc40c4278dc3e370c78c88c9]
    decide +kernel
  have e15445 : Deny 5 11 b15445 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdcbe326f0f8dc3bc7bc38c90c3e37da31c88c98c4]
    decide +kernel
  have e15435 : Deny 5 11 b15435 :=
    branchAction rule_sound _ _ 1
      0xb b15435 b15436 b15445 (by decide +kernel) e15436 e15445
  have e15433 : Deny 5 11 b15433 :=
    branchAction rule_sound _ _ 2
      0x2a3 b15433 b15434 b15435 (by decide +kernel) e15434 e15435
  have e15458 : Deny 5 11 b15458 := by
    apply closeAction rule_sound _ _ 64 [0x2be21020838c78c8e03e370e22222a3109e37]
    decide +kernel
  have e15432 : Deny 5 11 b15432 :=
    branchAction rule_sound _ _ 1
      0x7 b15432 b15433 b15458 (by decide +kernel) e15433 e15458
  have e15386 : Deny 5 11 b15386 :=
    branchAction rule_sound _ _ 1
      0x8 b15386 b15387 b15432 (by decide +kernel) e15387 e15432
  have e15372 : Deny 5 11 b15372 :=
    branchAction rule_sound _ _ 3
      0x98c4 b15372 b15373 b15386 (by decide +kernel) e15373 e15386
  have e15332 : Deny 5 11 b15332 :=
    branchAction rule_sound _ _ 1
      0xb b15332 b15333 b15372 (by decide +kernel) e15333 e15372
  have e15308 : Deny 5 11 b15308 :=
    branchAction rule_sound _ _ 2
      0x2a3 b15308 b15309 b15332 (by decide +kernel) e15309 e15332
  have e15472 : Deny 5 11 b15472 := by
    apply closeAction rule_sound _ _ 64 [0x15dd50c92430e21c32621e2]
    decide +kernel
  have e15485 : Deny 5 11 b15485 := by
    apply closeAction rule_sound _ _ 64 [0x20e2108e220f80c8277]
    decide +kernel
  have e15492 : Deny 5 11 b15492 := by
    apply closeAction rule_sound _ _ 64 [0x83887e220e22370f70c8244]
    decide +kernel
  have e15484 : Deny 5 11 b15484 :=
    branchAction rule_sound _ _ 2
      0x2e2 b15484 b15485 b15492 (by decide +kernel) e15485 e15492
  have e15501 : Deny 5 11 b15501 := by
    apply closeAction rule_sound _ _ 64 [0x820c8109e37]
    decide +kernel
  have e15483 : Deny 5 11 b15483 :=
    branchAction rule_sound _ _ 1
      0x7 b15483 b15484 b15501 (by decide +kernel) e15484 e15501
  have e15471 : Deny 5 11 b15471 :=
    branchAction rule_sound _ _ 2
      0x204 b15471 b15472 b15483 (by decide +kernel) e15472 e15483
  have e15508 : Deny 5 11 b15508 := by
    apply closeAction rule_sound _ _ 64 [0x30f8de21c3e37262]
    decide +kernel
  have e15514 : Deny 5 11 b15514 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
  have e15515 : Deny 5 11 b15515 := by
    apply closeAction rule_sound _ _ 64 [0x838870c95762040952030c724b]
    decide +kernel
  have e15513 : Deny 5 11 b15513 :=
    branchAction rule_sound _ _ 1
      0xa b15513 b15514 b15515 (by decide +kernel) e15514 e15515
  have e15507 : Deny 5 11 b15507 :=
    branchAction rule_sound _ _ 2
      0x1e2 b15507 b15508 b15513 (by decide +kernel) e15508 e15513
  have e15532 : Deny 5 11 b15532 := by
    apply closeAction rule_sound _ _ 64 [0xf8883887dc38880c3209]
    decide +kernel
  have e15541 : Deny 5 11 b15541 := by
    apply closeAction rule_sound _ _ 64 [0x3dc38880e22030f7d88244]
    decide +kernel
  have e15531 : Deny 5 11 b15531 :=
    branchAction rule_sound _ _ 2
      0x2e2 b15531 b15532 b15541 (by decide +kernel) e15532 e15541
  have e15551 : Deny 5 11 b15551 := by
    apply closeAction rule_sound _ _ 64 [0x20831f80c8277]
    decide +kernel
  have e15558 : Deny 5 11 b15558 := by
    apply closeAction rule_sound _ _ 64 [0x2548dc3e031f70c8244]
    decide +kernel
  have e15550 : Deny 5 11 b15550 :=
    branchAction rule_sound _ _ 1
      0xb b15550 b15551 b15558 (by decide +kernel) e15551 e15558
  have e15530 : Deny 5 11 b15530 :=
    branchAction rule_sound _ _ 1
      0x7 b15530 b15531 b15550 (by decide +kernel) e15531 e15550
  have e15506 : Deny 5 11 b15506 :=
    branchAction rule_sound _ _ 2
      0x204 b15506 b15507 b15530 (by decide +kernel) e15507 e15530
  have e15470 : Deny 5 11 b15470 :=
    branchAction rule_sound _ _ 2
      0x2e2 b15470 b15471 b15506 (by decide +kernel) e15471 e15506
  have e15568 : Deny 5 11 b15568 := by
    apply closeAction rule_sound _ _ 64 [0x20820831c4278dc20c41f8dc3247209dc4]
    decide +kernel
  have e15586 : Deny 5 11 b15586 := by
    apply closeAction rule_sound _ _ 64 [0xc38c70e3263]
    decide +kernel
  have e15591 : Deny 5 11 b15591 := by
    apply closeAction rule_sound _ _ 64 [0x3dc38c70c38c78c98c4083107e370f8dc31c9dcb]
    decide +kernel
  have e15585 : Deny 5 11 b15585 :=
    branchAction rule_sound _ _ 2
      0x1e3 b15585 b15586 b15591 (by decide +kernel) e15586 e15591
  have e15607 : Deny 5 11 b15607 := by
    apply closeAction rule_sound _ _ 64 [0x20c41f8dc32370f70c88c98c4083e370c82772e3]
    decide +kernel
  have e15622 : Deny 5 11 b15622 := by
    apply closeAction rule_sound _ _ 64 [0x820c8109e37]
    decide +kernel
  have e15606 : Deny 5 11 b15606 :=
    branchAction rule_sound _ _ 1
      0x7 b15606 b15607 b15622 (by decide +kernel) e15607 e15622
  have e15584 : Deny 5 11 b15584 :=
    branchAction rule_sound _ _ 2
      0x223 b15584 b15585 b15606 (by decide +kernel) e15585 e15606
  have e15630 : Deny 5 11 b15630 := by
    apply closeAction rule_sound _ _ 64 [0x14083884238dc3e370e22221e2277]
    decide +kernel
  have e15640 : Deny 5 11 b15640 := by
    apply closeAction rule_sound _ _ 64 [0x20f8dc38c98c42380f8dc32231c30e21e22a3]
    decide +kernel
  have e15653 : Deny 5 11 b15653 := by
    apply closeAction rule_sound _ _ 64 [0x272f8841f8def]
    decide +kernel
  have e15639 : Deny 5 11 b15639 :=
    branchAction rule_sound _ _ 3
      0x98c4 b15639 b15640 b15653 (by decide +kernel) e15640 e15653
  have e15629 : Deny 5 11 b15629 :=
    branchAction rule_sound _ _ 2
      0x2e3 b15629 b15630 b15639 (by decide +kernel) e15630 e15639
  have e15656 : Deny 5 11 b15656 := by
    apply closeAction rule_sound _ _ 64 [0x20e2107e37]
    decide +kernel
  have e15628 : Deny 5 11 b15628 :=
    branchAction rule_sound _ _ 2
      0x1e3 b15628 b15629 b15656 (by decide +kernel) e15629 e15656
  have e15659 : Deny 5 11 b15659 := by
    apply closeAction rule_sound _ _ 64 [0x820e2222107e37]
    decide +kernel
  have e15627 : Deny 5 11 b15627 :=
    branchAction rule_sound _ _ 1
      0x8 b15627 b15628 b15659 (by decide +kernel) e15628 e15659
  have e15583 : Deny 5 11 b15583 :=
    branchAction rule_sound _ _ 3
      0x98c4 b15583 b15584 b15627 (by decide +kernel) e15584 e15627
  have e15567 : Deny 5 11 b15567 :=
    branchAction rule_sound _ _ 1
      0xb b15567 b15568 b15583 (by decide +kernel) e15568 e15583
  have e15469 : Deny 5 11 b15469 :=
    branchAction rule_sound _ _ 1
      0xa b15469 b15470 b15567 (by decide +kernel) e15470 e15567
  have e15307 : Deny 5 11 b15307 :=
    branchAction rule_sound _ _ 1
      0x7 b15307 b15308 b15469 (by decide +kernel) e15308 e15469
  have e15225 : Deny 5 11 b15225 :=
    branchAction rule_sound _ _ 1
      0x9 b15225 b15226 b15307 (by decide +kernel) e15226 e15307
  exact e15225
end OMA.Blocks5_11_245212.S15225
