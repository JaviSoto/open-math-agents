import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S66077
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b66077 : Box := ![⟨95,190⟩,⟨42,62⟩,⟨15,30⟩,⟨1,74⟩,⟨361,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨42,62⟩,⟨15,30⟩,⟨1,74⟩,⟨361,999999999999999999⟩] := by
  have e66077 : Deny 5 13 b66077 := by
    apply closeAction rule_sound _ _ 64 [0x820820820f88c7e23238083e232780c38c78c88c78c2093e370e32788c88c78cbe232632388c9e231f8]
    decide +kernel
  exact e66077
end OMA.Blocks5_13_245212.S66077
