import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S65826
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b65826 : Box := ![⟨95,190⟩,⟨31,41⟩,⟨15,30⟩,⟨1,68⟩,⟨723,999999999999999999⟩]
private def b65827 : Box := ![⟨95,126⟩,⟨31,41⟩,⟨15,30⟩,⟨1,61⟩,⟨723,999999999999999999⟩]
private def b65828 : Box := ![⟨95,126⟩,⟨31,41⟩,⟨15,20⟩,⟨1,50⟩,⟨723,999999999999999999⟩]
private def b65829 : Box := ![⟨95,126⟩,⟨31,35⟩,⟨15,20⟩,⟨1,46⟩,⟨723,999999999999999999⟩]
private def b65830 : Box := ![⟨95,126⟩,⟨31,35⟩,⟨15,20⟩,⟨1,45⟩,⟨723,1446⟩]
private def b65831 : Box := ![⟨95,126⟩,⟨31,35⟩,⟨15,20⟩,⟨1,2⟩,⟨723,1446⟩]
private def b65832 : Box := ![⟨95,126⟩,⟨31,35⟩,⟨15,20⟩,⟨3,40⟩,⟨723,1446⟩]
private def b65833 : Box := ![⟨95,126⟩,⟨31,35⟩,⟨15,20⟩,⟨3,6⟩,⟨723,1446⟩]
private def b65834 : Box := ![⟨95,126⟩,⟨31,35⟩,⟨15,20⟩,⟨3,4⟩,⟨723,1446⟩]
private def b65835 : Box := ![⟨95,108⟩,⟨31,35⟩,⟨15,20⟩,⟨3,4⟩,⟨723,1446⟩]
private def b65836 : Box := ![⟨95,108⟩,⟨31,35⟩,⟨15,17⟩,⟨3,4⟩,⟨723,1446⟩]
private def b65841 : Box := ![⟨95,108⟩,⟨31,35⟩,⟨18,20⟩,⟨3,4⟩,⟨723,1446⟩]
private def b65848 : Box := ![⟨109,126⟩,⟨31,35⟩,⟨15,20⟩,⟨3,4⟩,⟨723,1446⟩]
private def b65849 : Box := ![⟨109,126⟩,⟨31,35⟩,⟨15,17⟩,⟨3,4⟩,⟨723,1446⟩]
private def b65854 : Box := ![⟨109,126⟩,⟨31,35⟩,⟨18,20⟩,⟨3,4⟩,⟨723,1446⟩]
private def b65861 : Box := ![⟨95,126⟩,⟨31,35⟩,⟨15,20⟩,⟨5,6⟩,⟨723,1446⟩]
private def b65862 : Box := ![⟨95,126⟩,⟨31,35⟩,⟨15,20⟩,⟨7,40⟩,⟨723,1446⟩]
private def b65863 : Box := ![⟨95,126⟩,⟨31,35⟩,⟨15,20⟩,⟨1,45⟩,⟨1447,999999999999999999⟩]
private def b65864 : Box := ![⟨95,108⟩,⟨31,35⟩,⟨15,20⟩,⟨1,41⟩,⟨1447,999999999999999999⟩]
private def b65875 : Box := ![⟨109,126⟩,⟨31,35⟩,⟨15,20⟩,⟨1,41⟩,⟨1447,999999999999999999⟩]
private def b65886 : Box := ![⟨95,126⟩,⟨36,41⟩,⟨15,20⟩,⟨1,46⟩,⟨723,999999999999999999⟩]
private def b65887 : Box := ![⟨95,126⟩,⟨36,41⟩,⟨15,20⟩,⟨1,46⟩,⟨723,1446⟩]
private def b65888 : Box := ![⟨95,126⟩,⟨36,41⟩,⟨15,20⟩,⟨1,2⟩,⟨723,1446⟩]
private def b65889 : Box := ![⟨95,126⟩,⟨36,41⟩,⟨15,20⟩,⟨3,41⟩,⟨723,1446⟩]
private def b65890 : Box := ![⟨95,126⟩,⟨36,41⟩,⟨15,20⟩,⟨3,6⟩,⟨723,1446⟩]
private def b65891 : Box := ![⟨95,126⟩,⟨36,41⟩,⟨15,20⟩,⟨3,4⟩,⟨723,1446⟩]
private def b65892 : Box := ![⟨95,108⟩,⟨36,41⟩,⟨15,20⟩,⟨3,4⟩,⟨723,1446⟩]
private def b65903 : Box := ![⟨109,126⟩,⟨36,41⟩,⟨15,20⟩,⟨3,4⟩,⟨723,1446⟩]
private def b65912 : Box := ![⟨95,126⟩,⟨36,41⟩,⟨15,20⟩,⟨5,6⟩,⟨723,1446⟩]
private def b65913 : Box := ![⟨95,126⟩,⟨36,41⟩,⟨15,20⟩,⟨7,41⟩,⟨723,1446⟩]
private def b65914 : Box := ![⟨95,126⟩,⟨36,41⟩,⟨15,20⟩,⟨1,46⟩,⟨1447,999999999999999999⟩]
private def b65915 : Box := ![⟨95,108⟩,⟨36,41⟩,⟨15,20⟩,⟨1,42⟩,⟨1447,999999999999999999⟩]
private def b65926 : Box := ![⟨109,126⟩,⟨36,41⟩,⟨15,20⟩,⟨1,42⟩,⟨1447,999999999999999999⟩]
private def b65927 : Box := ![⟨109,126⟩,⟨36,41⟩,⟨15,17⟩,⟨1,42⟩,⟨1447,999999999999999999⟩]
private def b65934 : Box := ![⟨109,126⟩,⟨36,41⟩,⟨18,20⟩,⟨1,42⟩,⟨1447,999999999999999999⟩]
private def b65939 : Box := ![⟨95,126⟩,⟨31,41⟩,⟨21,30⟩,⟨1,50⟩,⟨723,999999999999999999⟩]
private def b65940 : Box := ![⟨95,126⟩,⟨31,35⟩,⟨21,30⟩,⟨1,50⟩,⟨723,999999999999999999⟩]
private def b65941 : Box := ![⟨95,126⟩,⟨31,35⟩,⟨21,30⟩,⟨1,49⟩,⟨723,1446⟩]
private def b65942 : Box := ![⟨95,126⟩,⟨31,35⟩,⟨21,30⟩,⟨1,2⟩,⟨723,1446⟩]
private def b65943 : Box := ![⟨95,126⟩,⟨31,35⟩,⟨21,30⟩,⟨3,44⟩,⟨723,1446⟩]
private def b65944 : Box := ![⟨95,126⟩,⟨31,35⟩,⟨21,30⟩,⟨3,6⟩,⟨723,1446⟩]
private def b65945 : Box := ![⟨95,126⟩,⟨31,35⟩,⟨21,30⟩,⟨3,4⟩,⟨723,1446⟩]
private def b65946 : Box := ![⟨95,126⟩,⟨31,32⟩,⟨21,30⟩,⟨3,4⟩,⟨723,1446⟩]
private def b65947 : Box := ![⟨95,126⟩,⟨31,32⟩,⟨21,30⟩,⟨3,4⟩,⟨723,964⟩]
private def b65948 : Box := ![⟨95,126⟩,⟨31,32⟩,⟨21,30⟩,⟨3,4⟩,⟨965,1446⟩]
private def b65949 : Box := ![⟨95,126⟩,⟨31,32⟩,⟨21,30⟩,⟨3,4⟩,⟨965,1157⟩]
private def b65950 : Box := ![⟨95,126⟩,⟨31,32⟩,⟨21,30⟩,⟨3,4⟩,⟨1158,1446⟩]
private def b65951 : Box := ![⟨95,126⟩,⟨31,31⟩,⟨21,30⟩,⟨3,4⟩,⟨1158,1446⟩]
private def b65962 : Box := ![⟨95,126⟩,⟨32,32⟩,⟨21,30⟩,⟨3,4⟩,⟨1158,1446⟩]
private def b65963 : Box := ![⟨95,126⟩,⟨33,35⟩,⟨21,30⟩,⟨3,4⟩,⟨723,1446⟩]
private def b65964 : Box := ![⟨95,126⟩,⟨31,35⟩,⟨21,30⟩,⟨5,6⟩,⟨723,1446⟩]
private def b65965 : Box := ![⟨95,126⟩,⟨31,35⟩,⟨21,30⟩,⟨7,44⟩,⟨723,1446⟩]
private def b65966 : Box := ![⟨95,126⟩,⟨31,35⟩,⟨21,30⟩,⟨1,49⟩,⟨1447,999999999999999999⟩]
private def b65967 : Box := ![⟨95,108⟩,⟨31,35⟩,⟨21,30⟩,⟨1,44⟩,⟨1447,999999999999999999⟩]
private def b65968 : Box := ![⟨95,108⟩,⟨31,35⟩,⟨21,24⟩,⟨1,41⟩,⟨1447,999999999999999999⟩]
private def b65975 : Box := ![⟨95,108⟩,⟨31,35⟩,⟨25,30⟩,⟨1,41⟩,⟨1447,999999999999999999⟩]
private def b65984 : Box := ![⟨109,126⟩,⟨31,35⟩,⟨21,30⟩,⟨1,44⟩,⟨1447,999999999999999999⟩]
private def b65985 : Box := ![⟨109,126⟩,⟨31,35⟩,⟨21,24⟩,⟨1,44⟩,⟨1447,999999999999999999⟩]
private def b65992 : Box := ![⟨109,126⟩,⟨31,35⟩,⟨25,30⟩,⟨1,44⟩,⟨1447,999999999999999999⟩]
private def b65997 : Box := ![⟨95,126⟩,⟨36,41⟩,⟨21,30⟩,⟨1,50⟩,⟨723,999999999999999999⟩]
private def b66006 : Box := ![⟨127,190⟩,⟨31,41⟩,⟨15,30⟩,⟨1,61⟩,⟨723,999999999999999999⟩]
private def b66007 : Box := ![⟨127,190⟩,⟨31,41⟩,⟨15,20⟩,⟨1,61⟩,⟨723,999999999999999999⟩]
private def b66008 : Box := ![⟨127,190⟩,⟨31,35⟩,⟨15,20⟩,⟨1,57⟩,⟨723,999999999999999999⟩]
private def b66009 : Box := ![⟨127,190⟩,⟨31,35⟩,⟨15,20⟩,⟨1,56⟩,⟨723,1446⟩]
private def b66020 : Box := ![⟨127,190⟩,⟨31,35⟩,⟨15,20⟩,⟨1,56⟩,⟨1447,999999999999999999⟩]
private def b66021 : Box := ![⟨127,152⟩,⟨31,35⟩,⟨15,20⟩,⟨1,50⟩,⟨1447,999999999999999999⟩]
private def b66022 : Box := ![⟨127,152⟩,⟨31,35⟩,⟨15,17⟩,⟨1,45⟩,⟨1447,999999999999999999⟩]
private def b66031 : Box := ![⟨127,152⟩,⟨31,35⟩,⟨18,20⟩,⟨1,45⟩,⟨1447,999999999999999999⟩]
private def b66038 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨15,20⟩,⟨1,50⟩,⟨1447,999999999999999999⟩]
private def b66039 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨15,17⟩,⟨2,50⟩,⟨1447,999999999999999999⟩]
private def b66040 : Box := ![⟨153,190⟩,⟨31,32⟩,⟨15,17⟩,⟨2,49⟩,⟨1447,999999999999999999⟩]
private def b66047 : Box := ![⟨153,190⟩,⟨33,35⟩,⟨15,17⟩,⟨2,49⟩,⟨1447,999999999999999999⟩]
private def b66054 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨18,20⟩,⟨2,50⟩,⟨1447,999999999999999999⟩]
private def b66055 : Box := ![⟨127,190⟩,⟨36,41⟩,⟨15,20⟩,⟨1,57⟩,⟨723,999999999999999999⟩]
private def b66066 : Box := ![⟨127,190⟩,⟨31,41⟩,⟨21,30⟩,⟨1,61⟩,⟨723,999999999999999999⟩]
private theorem e65831 : Deny 5 13 b65831 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e65836 : Deny 5 13 b65836 := by
    apply closeAction rule_sound _ _ 64 [0x3089e02238]
    decide +kernel
private theorem e65841 : Deny 5 13 b65841 := by
    apply closeAction rule_sound _ _ 64 [0xc31c3e085ca]
    decide +kernel
private theorem e65835 : Deny 5 13 b65835 :=
    branchAction rule_sound _ _ 1
      0x9 b65835 b65836 b65841 (by decide +kernel) e65836 e65841
private theorem e65849 : Deny 5 13 b65849 := by
    apply closeAction rule_sound _ _ 64 [0x30c70f8808]
    decide +kernel
private theorem e65854 : Deny 5 13 b65854 := by
    apply closeAction rule_sound _ _ 64 [0x5c32780c95ca]
    decide +kernel
private theorem e65848 : Deny 5 13 b65848 :=
    branchAction rule_sound _ _ 1
      0x9 b65848 b65849 b65854 (by decide +kernel) e65849 e65854
private theorem e65834 : Deny 5 13 b65834 :=
    branchAction rule_sound _ _ 1
      0x7 b65834 b65835 b65848 (by decide +kernel) e65835 e65848
private theorem e65861 : Deny 5 13 b65861 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e65833 : Deny 5 13 b65833 :=
    branchAction rule_sound _ _ 1
      0xa b65833 b65834 b65861 (by decide +kernel) e65834 e65861
private theorem e65862 : Deny 5 13 b65862 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e65832 : Deny 5 13 b65832 :=
    branchAction rule_sound _ _ 1
      0xa b65832 b65833 b65862 (by decide +kernel) e65833 e65862
private theorem e65830 : Deny 5 13 b65830 :=
    branchAction rule_sound _ _ 2
      0x2a3 b65830 b65831 b65832 (by decide +kernel) e65831 e65832
private theorem e65864 : Deny 5 13 b65864 := by
    apply closeAction rule_sound _ _ 64 [0x7c3e03e07e022382972b88c2278da3]
    decide +kernel
private theorem e65875 : Deny 5 13 b65875 := by
    apply closeAction rule_sound _ _ 64 [0xc38c70e3243e270f8de31f88c22388c9]
    decide +kernel
private theorem e65863 : Deny 5 13 b65863 :=
    branchAction rule_sound _ _ 2
      0x1e3 b65863 b65864 b65875 (by decide +kernel) e65864 e65875
private theorem e65829 : Deny 5 13 b65829 :=
    branchAction rule_sound _ _ 2
      0x2e3 b65829 b65830 b65863 (by decide +kernel) e65830 e65863
private theorem e65888 : Deny 5 13 b65888 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e65892 : Deny 5 13 b65892 := by
    apply closeAction rule_sound _ _ 64 [0x97e370c7e08e03e03203249]
    decide +kernel
private theorem e65903 : Deny 5 13 b65903 := by
    apply closeAction rule_sound _ _ 64 [0x2083107e370f80c7209]
    decide +kernel
private theorem e65891 : Deny 5 13 b65891 :=
    branchAction rule_sound _ _ 1
      0x7 b65891 b65892 b65903 (by decide +kernel) e65892 e65903
private theorem e65912 : Deny 5 13 b65912 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e65890 : Deny 5 13 b65890 :=
    branchAction rule_sound _ _ 1
      0xa b65890 b65891 b65912 (by decide +kernel) e65891 e65912
private theorem e65913 : Deny 5 13 b65913 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e65889 : Deny 5 13 b65889 :=
    branchAction rule_sound _ _ 1
      0xa b65889 b65890 b65913 (by decide +kernel) e65890 e65913
private theorem e65887 : Deny 5 13 b65887 :=
    branchAction rule_sound _ _ 2
      0x2a3 b65887 b65888 b65889 (by decide +kernel) e65888 e65889
private theorem e65915 : Deny 5 13 b65915 := by
    apply closeAction rule_sound _ _ 64 [0x3e032032430f8203e23263263]
    decide +kernel
private theorem e65927 : Deny 5 13 b65927 := by
    apply closeAction rule_sound _ _ 64 [0xf80e31c30e31e3223]
    decide +kernel
private theorem e65934 : Deny 5 13 b65934 := by
    apply closeAction rule_sound _ _ 64 [0x820f88c7e23238]
    decide +kernel
private theorem e65926 : Deny 5 13 b65926 :=
    branchAction rule_sound _ _ 1
      0x9 b65926 b65927 b65934 (by decide +kernel) e65927 e65934
private theorem e65914 : Deny 5 13 b65914 :=
    branchAction rule_sound _ _ 2
      0x1e3 b65914 b65915 b65926 (by decide +kernel) e65915 e65926
private theorem e65886 : Deny 5 13 b65886 :=
    branchAction rule_sound _ _ 1
      0xb b65886 b65887 b65914 (by decide +kernel) e65887 e65914
private theorem e65828 : Deny 5 13 b65828 :=
    branchAction rule_sound _ _ 2
      0x223 b65828 b65829 b65886 (by decide +kernel) e65829 e65886
private theorem e65942 : Deny 5 13 b65942 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e65947 : Deny 5 13 b65947 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e65949 : Deny 5 13 b65949 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e65951 : Deny 5 13 b65951 := by
    apply closeAction rule_sound _ _ 64 [0x20c90d72475ca5cb]
    decide +kernel
private theorem e65962 : Deny 5 13 b65962 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e65950 : Deny 5 13 b65950 :=
    branchAction rule_sound _ _ 1
      0x8 b65950 b65951 b65962 (by decide +kernel) e65951 e65962
private theorem e65948 : Deny 5 13 b65948 :=
    branchAction rule_sound _ _ 1
      0xb b65948 b65949 b65950 (by decide +kernel) e65949 e65950
private theorem e65946 : Deny 5 13 b65946 :=
    branchAction rule_sound _ _ 1
      0xb b65946 b65947 b65948 (by decide +kernel) e65947 e65948
private theorem e65963 : Deny 5 13 b65963 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e65945 : Deny 5 13 b65945 :=
    branchAction rule_sound _ _ 1
      0x8 b65945 b65946 b65963 (by decide +kernel) e65946 e65963
private theorem e65964 : Deny 5 13 b65964 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e65944 : Deny 5 13 b65944 :=
    branchAction rule_sound _ _ 1
      0xa b65944 b65945 b65964 (by decide +kernel) e65945 e65964
private theorem e65965 : Deny 5 13 b65965 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e65943 : Deny 5 13 b65943 :=
    branchAction rule_sound _ _ 1
      0xa b65943 b65944 b65965 (by decide +kernel) e65944 e65965
private theorem e65941 : Deny 5 13 b65941 :=
    branchAction rule_sound _ _ 2
      0x2a3 b65941 b65942 b65943 (by decide +kernel) e65942 e65943
private theorem e65968 : Deny 5 13 b65968 := by
    apply closeAction rule_sound _ _ 64 [0x30e31c3e230f8de31f8223]
    decide +kernel
private theorem e65975 : Deny 5 13 b65975 := by
    apply closeAction rule_sound _ _ 64 [0x2083e232788c7e030e31c8]
    decide +kernel
private theorem e65967 : Deny 5 13 b65967 :=
    branchAction rule_sound _ _ 2
      0x263 b65967 b65968 b65975 (by decide +kernel) e65968 e65975
private theorem e65985 : Deny 5 13 b65985 := by
    apply closeAction rule_sound _ _ 64 [0x20f88c7e030e31e3223]
    decide +kernel
private theorem e65992 : Deny 5 13 b65992 := by
    apply closeAction rule_sound _ _ 64 [0x820f88c7e23238]
    decide +kernel
private theorem e65984 : Deny 5 13 b65984 :=
    branchAction rule_sound _ _ 1
      0x9 b65984 b65985 b65992 (by decide +kernel) e65985 e65992
private theorem e65966 : Deny 5 13 b65966 :=
    branchAction rule_sound _ _ 2
      0x1e3 b65966 b65967 b65984 (by decide +kernel) e65967 e65984
private theorem e65940 : Deny 5 13 b65940 :=
    branchAction rule_sound _ _ 2
      0x2e3 b65940 b65941 b65966 (by decide +kernel) e65941 e65966
private theorem e65997 : Deny 5 13 b65997 := by
    apply closeAction rule_sound _ _ 64 [0x820820f88c7e232388c9e231f8]
    decide +kernel
private theorem e65939 : Deny 5 13 b65939 :=
    branchAction rule_sound _ _ 1
      0x8 b65939 b65940 b65997 (by decide +kernel) e65940 e65997
private theorem e65827 : Deny 5 13 b65827 :=
    branchAction rule_sound _ _ 2
      0x263 b65827 b65828 b65939 (by decide +kernel) e65828 e65939
private theorem e66009 : Deny 5 13 b66009 := by
    apply closeAction rule_sound _ _ 64 [0x1f9df9df7c20a79a02389a028a8c78c79e3]
    decide +kernel
private theorem e66022 : Deny 5 13 b66022 := by
    apply closeAction rule_sound _ _ 64 [0xc38c70e3243e278c3e278c7e23223]
    decide +kernel
private theorem e66031 : Deny 5 13 b66031 := by
    apply closeAction rule_sound _ _ 64 [0x20f88c9e03e038c78c8]
    decide +kernel
private theorem e66021 : Deny 5 13 b66021 :=
    branchAction rule_sound _ _ 2
      0x263 b66021 b66022 b66031 (by decide +kernel) e66022 e66031
private theorem e66040 : Deny 5 13 b66040 := by
    apply closeAction rule_sound _ _ 64 [0xf80e31c32637e78cb]
    decide +kernel
private theorem e66047 : Deny 5 13 b66047 := by
    apply closeAction rule_sound _ _ 64 [0x20f88c9e230f80f88c7e231f8]
    decide +kernel
private theorem e66039 : Deny 5 13 b66039 :=
    branchAction rule_sound _ _ 2
      0x223 b66039 b66040 b66047 (by decide +kernel) e66040 e66047
private theorem e66054 : Deny 5 13 b66054 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e66038 : Deny 5 13 b66038 :=
    branchAction rule_sound _ _ 2
      0x267 b66038 b66039 b66054 (by decide +kernel) e66039 e66054
private theorem e66020 : Deny 5 13 b66020 :=
    branchAction rule_sound _ _ 2
      0x1e3 b66020 b66021 b66038 (by decide +kernel) e66021 e66038
private theorem e66008 : Deny 5 13 b66008 :=
    branchAction rule_sound _ _ 2
      0x2e3 b66008 b66009 b66020 (by decide +kernel) e66009 e66020
private theorem e66055 : Deny 5 13 b66055 := by
    apply closeAction rule_sound _ _ 64 [0x2082083e231f80f88c9e232388c9e231f8]
    decide +kernel
private theorem e66007 : Deny 5 13 b66007 :=
    branchAction rule_sound _ _ 2
      0x223 b66007 b66008 b66055 (by decide +kernel) e66008 e66055
private theorem e66066 : Deny 5 13 b66066 := by
    apply closeAction rule_sound _ _ 64 [0x82082083e231f88c8e232788c7e23238]
    decide +kernel
private theorem e66006 : Deny 5 13 b66006 :=
    branchAction rule_sound _ _ 1
      0x9 b66006 b66007 b66066 (by decide +kernel) e66007 e66066
private theorem e65826 : Deny 5 13 b65826 :=
    branchAction rule_sound _ _ 2
      0x1e3 b65826 b65827 b66006 (by decide +kernel) e65827 e66006
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨31,41⟩,⟨15,30⟩,⟨1,68⟩,⟨723,999999999999999999⟩] := by
  exact e65826
end OMA.Blocks5_13_245212.S65826
