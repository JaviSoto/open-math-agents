import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S6244
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b6244 : Box := ![⟨11,22⟩,⟨7,14⟩,⟨3,1920000000000000011376⟩,⟨1,1920000000000000011376⟩,⟨51,999999999999999999⟩]
private def b6245 : Box := ![⟨11,14⟩,⟨7,14⟩,⟨7,1920000000000000011376⟩,⟨1,1171570247933884304498⟩,⟨51,125⟩]
private def b6246 : Box := ![⟨15,22⟩,⟨7,14⟩,⟨7,1920000000000000011376⟩,⟨1,1171570247933884304498⟩,⟨51,125⟩]
private def b6247 : Box := ![⟨15,22⟩,⟨7,9⟩,⟨7,1920000000000000011376⟩,⟨1,1160381991814461125592⟩,⟨53,113⟩]
private def b6260 : Box := ![⟨15,22⟩,⟨10,14⟩,⟨7,1920000000000000011376⟩,⟨1,1160381991814461125592⟩,⟨53,113⟩]
private def b6261 : Box := ![⟨15,22⟩,⟨10,14⟩,⟨8,16⟩,⟨1,1160381991814461125592⟩,⟨53,113⟩]
private def b6268 : Box := ![⟨15,22⟩,⟨10,14⟩,⟨17,1920000000000000011376⟩,⟨1,1160381991814461125592⟩,⟨53,113⟩]
theorem deny5_11 : Deny 5 11 ![⟨11,22⟩,⟨7,14⟩,⟨3,1920000000000000011376⟩,⟨1,1920000000000000011376⟩,⟨51,999999999999999999⟩] := by
  have e6245 : Deny 5 11 b6245 := by
    apply closeAction rule_sound _ _ 64 [0x84]
    decide +kernel
  have e6247 : Deny 5 11 b6247 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdc26f738df6be32422021c2236087e37da3]
    decide +kernel
  have e6261 : Deny 5 11 b6261 := by
    apply closeAction rule_sound _ _ 64 [0xc3e378c90f8df68c81021f8de3]
    decide +kernel
  have e6268 : Deny 5 11 b6268 := by
    apply closeAction rule_sound _ _ 64 [0x72f0e326325cbc472f8c4278d872c3e2f88a0f61021f8df68c90a2284738df68c4238da31c3087884087e37db588a10b,0x88888a8c90ef88a72f709bdc8c90af88a1e310b50a0c40f8df6108e378c98c871c8c9738df688a088087da311cbdc26f,0x2a31c42c188a0c38c80f88c70e326325cbdc26f70370870710b8c90f8be229cbc4088e37da31e372f8c4709e2f703e03,0x1038c41f80c3e2f1e322325cbdc26f0c38c97088c90f888a1e3083de2109e3709cbe2108e37bdc0f80e21e22a3243be2,0x738df688a0af88a088da31c42c30f8de32422021f88c972f11cbe3109e37da320288a087de30af8dcbe3278bc20c9de3,0x72f72f8c9bdc0f888a0871022388c90af88a0878dcbdcbe326f7030f88870f8da22222a3243be229cbdc25c8c9]
    decide +kernel
  have e6260 : Deny 5 11 b6260 :=
    branchAction rule_sound _ _ 2
      0x276 b6260 b6261 b6268 (by decide +kernel) e6261 e6268
  have e6246 : Deny 5 11 b6246 :=
    branchAction rule_sound _ _ 3
      0x88c4 b6246 b6247 b6260 (by decide +kernel) e6247 e6260
  have e6244 : Deny 5 11 b6244 :=
    branchAction rule_sound _ _ 4
      0x1f8da3 b6244 b6245 b6246 (by decide +kernel) e6245 e6246
  exact e6244
end OMA.Blocks5_11_245212.S6244
