import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S63458
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b63458 : Box := ![⟨95,126⟩,⟨42,62⟩,⟨10,14⟩,⟨1,64⟩,⟨479,999999999999999999⟩]
private def b63459 : Box := ![⟨95,126⟩,⟨42,62⟩,⟨10,14⟩,⟨1,53⟩,⟨479,958⟩]
private def b63460 : Box := ![⟨95,126⟩,⟨42,62⟩,⟨10,14⟩,⟨1,2⟩,⟨479,958⟩]
private def b63461 : Box := ![⟨95,126⟩,⟨42,62⟩,⟨10,14⟩,⟨3,47⟩,⟨479,958⟩]
private def b63462 : Box := ![⟨95,126⟩,⟨42,62⟩,⟨10,11⟩,⟨3,47⟩,⟨479,958⟩]
private def b63463 : Box := ![⟨95,126⟩,⟨42,50⟩,⟨10,11⟩,⟨3,46⟩,⟨479,958⟩]
private def b63464 : Box := ![⟨95,108⟩,⟨42,50⟩,⟨10,11⟩,⟨3,43⟩,⟨479,958⟩]
private def b63465 : Box := ![⟨95,108⟩,⟨42,50⟩,⟨10,11⟩,⟨3,39⟩,⟨479,638⟩]
private def b63472 : Box := ![⟨95,108⟩,⟨42,50⟩,⟨10,11⟩,⟨3,39⟩,⟨639,958⟩]
private def b63477 : Box := ![⟨109,126⟩,⟨42,50⟩,⟨10,11⟩,⟨3,43⟩,⟨479,958⟩]
private def b63478 : Box := ![⟨109,126⟩,⟨42,50⟩,⟨10,11⟩,⟨3,43⟩,⟨479,638⟩]
private def b63485 : Box := ![⟨109,126⟩,⟨42,50⟩,⟨10,11⟩,⟨3,43⟩,⟨639,958⟩]
private def b63492 : Box := ![⟨95,126⟩,⟨51,62⟩,⟨10,11⟩,⟨3,46⟩,⟨479,958⟩]
private def b63493 : Box := ![⟨95,108⟩,⟨51,62⟩,⟨10,11⟩,⟨3,46⟩,⟨479,958⟩]
private def b63494 : Box := ![⟨95,108⟩,⟨51,62⟩,⟨10,11⟩,⟨3,42⟩,⟨479,638⟩]
private def b63501 : Box := ![⟨95,108⟩,⟨51,62⟩,⟨10,11⟩,⟨3,42⟩,⟨639,958⟩]
private def b63508 : Box := ![⟨109,126⟩,⟨51,62⟩,⟨10,11⟩,⟨3,46⟩,⟨479,958⟩]
private def b63515 : Box := ![⟨95,126⟩,⟨42,62⟩,⟨12,14⟩,⟨3,47⟩,⟨479,958⟩]
private def b63516 : Box := ![⟨95,126⟩,⟨42,50⟩,⟨12,14⟩,⟨3,47⟩,⟨479,958⟩]
private def b63517 : Box := ![⟨95,108⟩,⟨42,50⟩,⟨12,14⟩,⟨3,44⟩,⟨479,958⟩]
private def b63518 : Box := ![⟨95,108⟩,⟨42,50⟩,⟨12,14⟩,⟨3,41⟩,⟨479,638⟩]
private def b63525 : Box := ![⟨95,108⟩,⟨42,50⟩,⟨12,14⟩,⟨3,41⟩,⟨639,958⟩]
private def b63534 : Box := ![⟨109,126⟩,⟨42,50⟩,⟨12,14⟩,⟨3,44⟩,⟨479,958⟩]
private def b63541 : Box := ![⟨95,126⟩,⟨51,62⟩,⟨12,14⟩,⟨3,47⟩,⟨479,958⟩]
private def b63548 : Box := ![⟨95,126⟩,⟨42,62⟩,⟨10,14⟩,⟨1,53⟩,⟨959,999999999999999999⟩]
private def b63549 : Box := ![⟨95,126⟩,⟨42,62⟩,⟨10,11⟩,⟨1,47⟩,⟨959,999999999999999999⟩]
private def b63550 : Box := ![⟨95,126⟩,⟨42,50⟩,⟨10,11⟩,⟨1,46⟩,⟨959,999999999999999999⟩]
private def b63557 : Box := ![⟨95,126⟩,⟨51,62⟩,⟨10,11⟩,⟨1,46⟩,⟨959,999999999999999999⟩]
private def b63558 : Box := ![⟨95,108⟩,⟨51,62⟩,⟨10,11⟩,⟨1,46⟩,⟨959,999999999999999999⟩]
private def b63559 : Box := ![⟨95,108⟩,⟨51,62⟩,⟨10,11⟩,⟨1,2⟩,⟨959,25772⟩]
private def b63560 : Box := ![⟨95,108⟩,⟨51,62⟩,⟨10,11⟩,⟨3,43⟩,⟨959,25772⟩]
private def b63561 : Box := ![⟨95,108⟩,⟨51,62⟩,⟨10,11⟩,⟨3,39⟩,⟨959,1849⟩]
private def b63568 : Box := ![⟨95,108⟩,⟨51,62⟩,⟨10,11⟩,⟨3,39⟩,⟨1850,25741⟩]
private def b63573 : Box := ![⟨109,126⟩,⟨51,62⟩,⟨10,11⟩,⟨1,46⟩,⟨959,999999999999999999⟩]
private def b63574 : Box := ![⟨109,126⟩,⟨51,62⟩,⟨10,11⟩,⟨1,46⟩,⟨959,1918⟩]
private def b63585 : Box := ![⟨109,126⟩,⟨51,62⟩,⟨10,11⟩,⟨1,46⟩,⟨1919,999999999999999999⟩]
private def b63596 : Box := ![⟨95,126⟩,⟨42,62⟩,⟨12,14⟩,⟨1,47⟩,⟨959,999999999999999999⟩]
private def b63597 : Box := ![⟨95,126⟩,⟨42,50⟩,⟨12,14⟩,⟨1,47⟩,⟨959,999999999999999999⟩]
private def b63598 : Box := ![⟨95,108⟩,⟨42,50⟩,⟨12,14⟩,⟨1,44⟩,⟨959,999999999999999999⟩]
private def b63599 : Box := ![⟨95,108⟩,⟨42,50⟩,⟨12,14⟩,⟨1,41⟩,⟨959,1918⟩]
private def b63610 : Box := ![⟨95,108⟩,⟨42,50⟩,⟨12,14⟩,⟨1,41⟩,⟨1919,999999999999999999⟩]
private def b63619 : Box := ![⟨109,126⟩,⟨42,50⟩,⟨12,14⟩,⟨1,44⟩,⟨959,999999999999999999⟩]
private def b63620 : Box := ![⟨109,126⟩,⟨42,50⟩,⟨12,14⟩,⟨1,44⟩,⟨959,1918⟩]
private def b63631 : Box := ![⟨109,126⟩,⟨42,50⟩,⟨12,14⟩,⟨1,44⟩,⟨1919,999999999999999999⟩]
private def b63642 : Box := ![⟨95,126⟩,⟨51,62⟩,⟨12,14⟩,⟨1,47⟩,⟨959,999999999999999999⟩]
private def b63643 : Box := ![⟨95,108⟩,⟨51,62⟩,⟨12,14⟩,⟨1,47⟩,⟨959,999999999999999999⟩]
private def b63644 : Box := ![⟨95,108⟩,⟨51,62⟩,⟨12,14⟩,⟨1,44⟩,⟨959,1918⟩]
private def b63655 : Box := ![⟨95,108⟩,⟨51,62⟩,⟨12,14⟩,⟨1,44⟩,⟨1919,999999999999999999⟩]
private def b63666 : Box := ![⟨109,126⟩,⟨51,62⟩,⟨12,14⟩,⟨1,47⟩,⟨959,999999999999999999⟩]
private theorem e63460 : Deny 5 13 b63460 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
private theorem e63465 : Deny 5 13 b63465 := by
    apply closeAction rule_sound _ _ 64 [0xc3e372430898c8]
    decide +kernel
private theorem e63472 : Deny 5 13 b63472 := by
    apply closeAction rule_sound _ _ 64 [0xc225be37da3223]
    decide +kernel
private theorem e63464 : Deny 5 13 b63464 :=
    branchAction rule_sound _ _ 2
      0x2e3 b63464 b63465 b63472 (by decide +kernel) e63465 e63472
private theorem e63478 : Deny 5 13 b63478 := by
    apply closeAction rule_sound _ _ 64 [0x3e370c90c3263223]
    decide +kernel
private theorem e63485 : Deny 5 13 b63485 := by
    apply closeAction rule_sound _ _ 64 [0xc38c90dbe37263223]
    decide +kernel
private theorem e63477 : Deny 5 13 b63477 :=
    branchAction rule_sound _ _ 1
      0xb b63477 b63478 b63485 (by decide +kernel) e63478 e63485
private theorem e63463 : Deny 5 13 b63463 :=
    branchAction rule_sound _ _ 2
      0x1e3 b63463 b63464 b63477 (by decide +kernel) e63464 e63477
private theorem e63494 : Deny 5 13 b63494 := by
    apply closeAction rule_sound _ _ 64 [0x20c90f8dc38c98c8]
    decide +kernel
private theorem e63501 : Deny 5 13 b63501 := by
    apply closeAction rule_sound _ _ 64 [0x3e038c90c3e23263223]
    decide +kernel
private theorem e63493 : Deny 5 13 b63493 :=
    branchAction rule_sound _ _ 2
      0x2e3 b63493 b63494 b63501 (by decide +kernel) e63494 e63501
private theorem e63508 : Deny 5 13 b63508 := by
    apply closeAction rule_sound _ _ 64 [0x4f8de30838c7e03e23223278]
    decide +kernel
private theorem e63492 : Deny 5 13 b63492 :=
    branchAction rule_sound _ _ 1
      0x7 b63492 b63493 b63508 (by decide +kernel) e63493 e63508
private theorem e63462 : Deny 5 13 b63462 :=
    branchAction rule_sound _ _ 2
      0x223 b63462 b63463 b63492 (by decide +kernel) e63463 e63492
private theorem e63518 : Deny 5 13 b63518 := by
    apply closeAction rule_sound _ _ 64 [0x20c9e370c38c78c8]
    decide +kernel
private theorem e63525 : Deny 5 13 b63525 := by
    apply closeAction rule_sound _ _ 64 [0x20e31f80e32430e31e3223]
    decide +kernel
private theorem e63517 : Deny 5 13 b63517 :=
    branchAction rule_sound _ _ 2
      0x2e3 b63517 b63518 b63525 (by decide +kernel) e63518 e63525
private theorem e63534 : Deny 5 13 b63534 := by
    apply closeAction rule_sound _ _ 64 [0x13e378c20c41f8dc3e23263238]
    decide +kernel
private theorem e63516 : Deny 5 13 b63516 :=
    branchAction rule_sound _ _ 2
      0x1e3 b63516 b63517 b63534 (by decide +kernel) e63517 e63534
private theorem e63541 : Deny 5 13 b63541 := by
    apply closeAction rule_sound _ _ 64 [0x82083e08247e37]
    decide +kernel
private theorem e63515 : Deny 5 13 b63515 :=
    branchAction rule_sound _ _ 1
      0x8 b63515 b63516 b63541 (by decide +kernel) e63516 e63541
private theorem e63461 : Deny 5 13 b63461 :=
    branchAction rule_sound _ _ 1
      0x9 b63461 b63462 b63515 (by decide +kernel) e63462 e63515
private theorem e63459 : Deny 5 13 b63459 :=
    branchAction rule_sound _ _ 2
      0x2a3 b63459 b63460 b63461 (by decide +kernel) e63460 e63461
private theorem e63550 : Deny 5 13 b63550 := by
    apply closeAction rule_sound _ _ 64 [0xc3e378c8e1be372788dbe378c7e23]
    decide +kernel
private theorem e63559 : Deny 5 13 b63559 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
private theorem e63561 : Deny 5 13 b63561 := by
    apply closeAction rule_sound _ _ 64 [0x30f8243089e23223]
    decide +kernel
private theorem e63568 : Deny 5 13 b63568 := by
    apply closeAction rule_sound _ _ 64 [0x3e02278088e23]
    decide +kernel
private theorem e63560 : Deny 5 13 b63560 :=
    branchAction rule_sound _ _ 3
      0xbe23 b63560 b63561 b63568 (by decide +kernel) e63561 e63568
private theorem e63558 : Deny 5 13 b63558 :=
    branchAction rule_sound _ _ 3
      0xae23 b63558 b63559 b63560 (by decide +kernel) e63559 e63560
private theorem e63574 : Deny 5 13 b63574 := by
    apply closeAction rule_sound _ _ 64 [0x4f8dc3e038c72430f82632132a3]
    decide +kernel
private theorem e63585 : Deny 5 13 b63585 := by
    apply closeAction rule_sound _ _ 64 [0xf80e31c3e230f8de31f88c90c2263223]
    decide +kernel
private theorem e63573 : Deny 5 13 b63573 :=
    branchAction rule_sound _ _ 1
      0xb b63573 b63574 b63585 (by decide +kernel) e63574 e63585
private theorem e63557 : Deny 5 13 b63557 :=
    branchAction rule_sound _ _ 1
      0x7 b63557 b63558 b63573 (by decide +kernel) e63558 e63573
private theorem e63549 : Deny 5 13 b63549 :=
    branchAction rule_sound _ _ 2
      0x223 b63549 b63550 b63557 (by decide +kernel) e63550 e63557
private theorem e63599 : Deny 5 13 b63599 := by
    apply closeAction rule_sound _ _ 64 [0x3e038c70e32430e31e32132a3]
    decide +kernel
private theorem e63610 : Deny 5 13 b63610 := by
    apply closeAction rule_sound _ _ 64 [0xc38c70f8de3243e230f8df68c7e23223]
    decide +kernel
private theorem e63598 : Deny 5 13 b63598 :=
    branchAction rule_sound _ _ 2
      0x2e3 b63598 b63599 b63610 (by decide +kernel) e63599 e63610
private theorem e63620 : Deny 5 13 b63620 := by
    apply closeAction rule_sound _ _ 64 [0x20c90f80e31c32632132a3]
    decide +kernel
private theorem e63631 : Deny 5 13 b63631 := by
    apply closeAction rule_sound _ _ 64 [0x832432430e31c3e37263223]
    decide +kernel
private theorem e63619 : Deny 5 13 b63619 :=
    branchAction rule_sound _ _ 1
      0xb b63619 b63620 b63631 (by decide +kernel) e63620 e63631
private theorem e63597 : Deny 5 13 b63597 :=
    branchAction rule_sound _ _ 2
      0x1e3 b63597 b63598 b63619 (by decide +kernel) e63598 e63619
private theorem e63644 : Deny 5 13 b63644 := by
    apply closeAction rule_sound _ _ 64 [0x820e31f8238dc3e038c82532a3]
    decide +kernel
private theorem e63655 : Deny 5 13 b63655 := by
    apply closeAction rule_sound _ _ 64 [0x20f88c7e03e038c78c80c38c8263]
    decide +kernel
private theorem e63643 : Deny 5 13 b63643 :=
    branchAction rule_sound _ _ 2
      0x2e3 b63643 b63644 b63655 (by decide +kernel) e63644 e63655
private theorem e63666 : Deny 5 13 b63666 := by
    apply closeAction rule_sound _ _ 64 [0x820f88c8e23278]
    decide +kernel
private theorem e63642 : Deny 5 13 b63642 :=
    branchAction rule_sound _ _ 1
      0x7 b63642 b63643 b63666 (by decide +kernel) e63643 e63666
private theorem e63596 : Deny 5 13 b63596 :=
    branchAction rule_sound _ _ 1
      0x8 b63596 b63597 b63642 (by decide +kernel) e63597 e63642
private theorem e63548 : Deny 5 13 b63548 :=
    branchAction rule_sound _ _ 2
      0x263 b63548 b63549 b63596 (by decide +kernel) e63549 e63596
private theorem e63458 : Deny 5 13 b63458 :=
    branchAction rule_sound _ _ 2
      0x2e3 b63458 b63459 b63548 (by decide +kernel) e63459 e63548
theorem deny5_13 : Deny 5 13 ![⟨95,126⟩,⟨42,62⟩,⟨10,14⟩,⟨1,64⟩,⟨479,999999999999999999⟩] := by
  exact e63458
end OMA.Blocks5_13_245212.S63458
