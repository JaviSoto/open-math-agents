import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S48118
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b48118 : Box := ![⟨191,254⟩,⟨18,20⟩,⟨127,1920000000000000011376⟩,⟨3,718295185477505923831⟩,⟨959,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨191,254⟩,⟨18,20⟩,⟨127,1920000000000000011376⟩,⟨3,718295185477505923831⟩,⟨959,999999999999999999⟩] := by
  have e48118 : Deny 5 13 b48118 := by
    apply closeAction rule_sound _ _ 64 [0xbe326f76f8c9da376f8cb8ddbe32c21e376f8cb8ddbe32e376f8cb8ddbe32e376f8cb7552b88c98dd54a8cb57888a223,0x1e32637552b8be32e31f88c98c8e0208208272f8c9e2f72f8c9d87bdcbe326f087daf8c7bdcbe3247bdcbe326f8c7bdd,0x2e376f8cb8ddbe32e376f8cb8ddbe32e376f8cb8ddbe32c3e038c97552b88c78c98dd54ae2f8cb76f8dd54ae2f8c9e23,0x8cb8ddbe32e376f8cb8ddbe32e376f8cb8ddbe32e376f8cbe2f75d7552d52d52ca54b54b54a54b54b2a376f8cb8ddbe3,0x82083e232788c7e232788c7e2327875dbdd7542d42d42d42c2b222942e228950b88a8ddbe32e376f8cb8ddbe32e376f,0x208276f8c9e2f8c7e2f082]
    decide +kernel
  exact e48118
end OMA.Blocks5_13_245212.S48118
