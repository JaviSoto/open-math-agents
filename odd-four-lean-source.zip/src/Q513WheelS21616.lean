import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S21616
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b21616 : Box := ![⟨23,26⟩,⟨63,126⟩,⟨15,30⟩,⟨3,74⟩,⟨94,113⟩]
theorem deny5_13 : Deny 5 13 ![⟨23,26⟩,⟨63,126⟩,⟨15,30⟩,⟨3,74⟩,⟨94,113⟩] := by
  have e21616 : Deny 5 13 b21616 := by
    apply closeAction rule_sound _ _ 64 [0x21ae37d632447b8df6d63108e37d631c3ac3e378c80f8deb8c90c21c4088e37ae326b6b8df6d63204087e37d632778c4,0x2a129e0eb8c9ac30f8dc78c88c910b0e1103e2baa1109e2baa12830f8de3203e378c911ee37da3107e378c87ab7b8de3,0x79e0c40f8df6108e2129ee37db584784a0eb0f8de321ae37db51f78c98c479e0f80f88470e1261]
    decide +kernel
  exact e21616
end OMA.Blocks5_13_245212.S21616
