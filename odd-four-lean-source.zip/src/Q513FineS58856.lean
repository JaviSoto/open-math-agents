import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S58856
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b58856 : Box := ![⟨47,62⟩,⟨42,62⟩,⟨31,62⟩,⟨1,799016681299385430589⟩,⟨479,999999999999999999⟩]
private def b58857 : Box := ![⟨47,53⟩,⟨42,62⟩,⟨31,62⟩,⟨1,61⟩,⟨479,999999999999999999⟩]
private def b58978 : Box := ![⟨54,62⟩,⟨42,62⟩,⟨31,62⟩,⟨1,61⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,62⟩,⟨42,62⟩,⟨31,62⟩,⟨1,799016681299385430589⟩,⟨479,999999999999999999⟩] := by
  have e58857 : Deny 5 13 b58857 := by
    apply closeAction rule_sound _ _ 64 [0x8dfe37da32388c78c97df0f85f8d87e17e361f8088e365cbe17e361f8d8ae362b88d72b8da32237df7cb5ca2972a32e3,0x5f82422361d72ca2972a32e31c30f81c3e237f8df68c7e23243e23087e368c88df7d728a5ca8cb0dfe37d877f8de3278,0x1c38c80c3e371e32632237df5ca2972a32c30f88c80f8dc70f87f8df68c8e23087e23243088e23087e37da32237df5c3,0x20f80e32231c3e038c80c3e232231e3243e03]
    decide +kernel
  have e58978 : Deny 5 13 b58978 := by
    apply closeAction rule_sound _ _ 64 [0x1c30c70c3e078c90c3e371c3e232632237df5ca2972a32df7d75f81f82b82b88d72b88c78c98c88df7d729728a5ca8cb,0x2232632235f8dd7e370f80e32232632232c3e038c70e32030f88c78c90c3e231c3e23087e232632237df5ca2972a32e3,0x8c88c20820c7e232788c88cbe020c70c31e32430e31c38c98c88df7d728a5ca8cb8c78c90820c78c9083e232380c70c3,0x20820f88c8e03e031e32630820c7e232632f88c88c7e02083e07e23278083e231f80f80c78c9]
    decide +kernel
  have e58856 : Deny 5 13 b58856 :=
    branchAction rule_sound _ _ 2
      0x1e3 b58856 b58857 b58978 (by decide +kernel) e58857 e58978
  exact e58856
end OMA.Blocks5_13_245212.S58856
