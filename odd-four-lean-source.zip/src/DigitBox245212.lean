import BoxKernel245212
import PrefixLeaf245212

/-! Certified tightening of all four exponents by the top base-p digit
    of the divisor identity, including the variable fourth prime. -/
namespace OMA.DigitBox245212
open Finset OMA.Box245212 OMA.Smooth245212 OMA.Moving245212 OMA.LastDigit245212 ArithmeticFunction
open scoped ArithmeticFunction.sigma
open private OMA.PrefixLeaf245212.trim_sound from PrefixLeaf245212
open private OMA.Large245212.y_both from LargeWindow245212

def den (x y : ℚ) (d : ℕ) := ((d:ℚ)+1)*(2-x)-y
def num (x y : ℚ) (d : ℕ) := (d:ℚ)*x+y

private theorem digitsQ {r d : ℕ} (hp : r.Prime) (hd : 0<d) {x y : ℚ} (hx : 0≤x) (hy : 0<y)
    (value : x*X r (some d)+y*Y r (some d)=2) :
    0<den x y d ∧ ((r:ℚ)-1)*den x y d<num x y d ∧ num x y d≤r*den x y d := by
  let A := x.num.toNat*y.den
  let S := y.num.toNat*x.den
  let T := x.den*y.den
  have pos : 0<T := Nat.mul_pos x.den_pos y.den_pos
  have sp : 0<S := Nat.mul_pos (by have := Rat.num_pos.mpr hy; omega) x.den_pos
  have scale (z : ℚ) (hz : 0≤z) : (z.num.toNat:ℚ)=z*z.den := by
    rw [Rat.mul_den_eq_num]
    exact_mod_cast Int.toNat_of_nonneg (Rat.num_nonneg.mpr hz)
  have a : (A:ℚ)=x*T := by simp only [A,T,Nat.cast_mul,scale x hx,mul_assoc]
  have s : (S:ℚ)=y*T := by simp only [S,T,Nat.cast_mul,scale y hy.le]; ring
  have eq : A*W (r^d)+S*σ 1 (r^d)=2*T*((d+1)*r^d) := by
    exact_mod_cast (show (A:ℚ)*(W (r^d):ℚ)+(S:ℚ)*(σ 1 (r^d):ℚ)=2*(T:ℚ)*(((d:ℚ)+1)*(r:ℚ)^d) from by
      rw [a,s,←x_factor hp,←y_factor hp]
      linear_combination (T:ℚ)*(((d:ℚ)+1)*(r:ℚ)^d)*value)
  have form : digitSum r A S (d+1)=r^d*(2*T*(d+1)) := by
    rw [w_pow hp,sigma_one_apply_prime_pow hp] at eq
    unfold digitSum
    simp_rw [show ∀ j:ℕ,r^j*(A*(j+1)+S)=A*(r^j*(j+1))+S*r^j by intro j; ring]
    rw [sum_add_distrib,←mul_sum,←mul_sum]
    nlinarith only [eq]
  obtain ⟨pd,lo,hi,_⟩ := digits hp.one_lt sp hd form
  have eqD : denom A S T d+(A*(d+1)+S)=2*T*(d+1) := Nat.sub_add_cancel (Nat.sub_pos_iff_lt.mp pd).le
  have dQ : (denom A S T d:ℚ)=den x y d*T := by
    have e : (denom A S T d:ℚ)+((A:ℚ)*(d+1)+S)=2*(T:ℚ)*(d+1) := by exact_mod_cast eqD
    rw [a,s] at e; unfold den; linarith only [e]
  have nQ : (A:ℚ)*d+S=num x y d*T := by rw [a,s]; unfold num;ring
  have lo' : (denom A S T d:ℚ)*((r-1:ℕ):ℚ)<(A:ℚ)*d+S := by exact_mod_cast lo
  have hi' : (A:ℚ)*d+S≤(denom A S T d:ℚ)*r := by exact_mod_cast hi
  have posT : (0:ℚ)<T := by exact_mod_cast pos
  have posD : 0<(denom A S T d:ℚ) := by exact_mod_cast pd
  rw [dQ] at posD
  rw [dQ,nQ,Nat.cast_sub hp.pos,Nat.cast_one] at lo'
  rw [dQ,nQ] at hi'
  refine ⟨pos_of_mul_pos_left posD posT.le,?_,?_⟩
  · exact lt_of_mul_lt_mul_right (show (((r:ℚ)-1)*den x y d)*T<num x y d*T by linarith only [lo']) posT.le
  · exact le_of_mul_le_mul_right (show num x y d*T≤((r:ℚ)*den x y d)*T by linarith only [hi']) posT

private def cut (R : Range) (strict : Bool) (v w : ℚ) : Range :=
  let z := w-v
  let a := v.num*z.den
  let b := z.num*v.den
  let c := OMA.PrefixLeaf245212.trim (R.lo,R.hi) a (b-(if strict then 1 else 0))
  ⟨c.1,c.2⟩

private theorem cut_ok {R : Range} {d : ℕ} {v w : ℚ} (hr : R.has d) (strict : Bool)
    (eq : if strict then v*((d:ℚ)+1)<w else v*((d:ℚ)+1)≤w) : (cut R strict v w).has d := by
  let z := w-v
  let a := v.num*(z.den:ℤ)
  let b := z.num*(v.den:ℤ)
  have e1 : (a:ℚ)*(d:ℚ)=(v*d)*((v.den:ℚ)*z.den) := by
    simp only [a,Int.cast_mul,Int.cast_natCast,←Rat.mul_den_eq_num]; ring
  have e2 : (b:ℚ)=z*((v.den:ℚ)*z.den) := by
    simp only [b,Int.cast_mul,Int.cast_natCast,←Rat.mul_den_eq_num]; ring
  have pos : 0<(v.den:ℚ)*z.den := by exact_mod_cast Nat.mul_pos v.den_pos z.den_pos
  apply OMA.PrefixLeaf245212.trim_sound hr.1 hr.2
  change a*d≤b-(if strict then 1 else 0)
  cases strict with
  | false =>
    simp only [Bool.false_eq_true,if_false,sub_zero] at eq ⊢
    have e : (a:ℚ)*d≤(b:ℚ) := by
      rw [e1,e2]
      apply mul_le_mul_of_nonneg_right _ pos.le
      dsimp [z]; linarith only [eq]
    exact_mod_cast e
  | true =>
    simp only [if_true] at eq ⊢
    have e : (a:ℚ)*d<(b:ℚ) := by
      rw [e1,e2]
      apply mul_lt_mul_of_pos_right _ pos
      dsimp [z]; linarith only [eq]
    have e' : a*d<b := by exact_mod_cast e
    omega

def co (f : Band→Band→ℚ) (p q : ℕ) (b : Box245212.Box) (i : Fin 4) :=
  ∏ j∈univ.erase i,factor f p q b j

private def digitAt (p q : ℕ) (b : Box245212.Box) (i : Fin 4) : Range :=
  let x := co xl p q b i
  let y := co yl p q b i
  let u := co xu p q b i
  let v := co yu p q b i
  let P : ℚ := (baseBox p q b i).hi
  let r : ℚ := (baseBox p q b i).lo
  let R := cut (b i.castSucc) true (x-2) (-y)
  let R := cut R false ((P+1)*x-2*P) (x-(P+1)*y)
  cut R true (2*(r-1)-r*u) (r*v-u)

theorem facts {p q : ℕ} {b : Box245212.Box} {v : Values}
    (cand : Candidate p q v) (fit : Fits b v) (start : ∀ i,1<(baseBox p q b i).lo)
    (i : Fin 4) (l h : ℕ) (lp : 1≤l) (hl : l≤bases p q v i) (hh : bases p q v i≤h) :
    let d := exponents v i
    let X := co xl p q b i; let Y := co yl p q b i
    let U := co xu p q b i; let V := co yu p q b i
    0<den X Y d ∧ num X Y d≤h*den X Y d ∧ ((l:ℚ)-1)*den U V d<num U V d := by
  let d := exponents v i
  let r := bases p q v i
  let xj (j : Fin 4) := X (bases p q v j) (some (exponents v j))
  let yj (j : Fin 4) := Y (bases p q v j) (some (exponents v j))
  let x := ∏ j∈univ.erase i,xj j
  let y := ∏ j∈univ.erase i,yj j
  have bx := moments fit start
  have yl0 (j : Fin 4) : 0<yj j := by
    exact (show (0:ℚ)<1/((exponents v j:ℚ)+1) by positivity).trans_le
      (OMA.Large245212.y_both (cand.prime j).one_lt).1
  have xl0 : 0≤x := prod_nonneg (fun j _=>(bx j).1.trans (bx j).2.1)
  have yp : 0<y := prod_pos (fun j _=>yl0 j)
  have xl' : co xl p q b i≤x := prod_le_prod (fun j _=>(bx j).1) (fun j _=>(bx j).2.1)
  have xu' : x≤co xu p q b i := prod_le_prod (fun j _=>(bx j).1.trans (bx j).2.1) (fun j _=>(bx j).2.2.1)
  have yl' : co yl p q b i≤y := prod_le_prod (fun j _=>(bx j).2.2.2.1) (fun j _=>(bx j).2.2.2.2.1)
  have yu' : y≤co yu p q b i := prod_le_prod (fun j _=>(yl0 j).le) (fun j _=>(bx j).2.2.2.2.2)
  have eq : x*X r (some d)+y*Y r (some d)=2 := by
    change (∏ j∈univ.erase i,xj j)*xj i+(∏ j∈univ.erase i,yj j)*yj i=2
    rw [prod_erase_mul _ _ (mem_univ i),prod_erase_mul _ _ (mem_univ i)]
    exact cand.score
  obtain ⟨dp,low,up⟩ := digitsQ (cand.prime i) (cand.pos i) xl0 yp eq
  have ph : (r:ℚ)≤(h:ℚ) := by exact_mod_cast hh
  have pl : (l:ℚ)≤(r:ℚ) := by exact_mod_cast hl
  have ps : (1:ℚ)≤l := by exact_mod_cast lp
  have a1 : den x y d≤den (co xl p q b i) (co yl p q b i) d := by
    unfold den; nlinarith only [xl',yl',mul_nonneg (sub_nonneg.mpr xl') (Nat.cast_nonneg (α:=ℚ) d)]
  have a2 : den (co xu p q b i) (co yu p q b i) d≤den x y d := by
    unfold den; nlinarith only [xu',yu',mul_nonneg (sub_nonneg.mpr xu') (Nat.cast_nonneg (α:=ℚ) d)]
  have b1 : num (co xl p q b i) (co yl p q b i) d≤num x y d :=
    add_le_add (mul_le_mul_of_nonneg_left xl' (Nat.cast_nonneg d)) yl'
  have b2 : num x y d≤num (co xu p q b i) (co yu p q b i) d :=
    add_le_add (mul_le_mul_of_nonneg_left xu' (Nat.cast_nonneg d)) yu'
  have h1 := dp.trans_le a1
  have h2 := (b1.trans up).trans (mul_le_mul ph a1 dp.le (Nat.cast_nonneg h))
  have h3 := ((mul_le_mul_of_nonneg_left a2 (show 0≤(l:ℚ)-1 by linarith)).trans
    (mul_le_mul_of_nonneg_right (sub_le_sub_right pl 1) dp.le)).trans_lt (low.trans_le b2)
  exact ⟨h1,h2,h3⟩

private theorem digitAt_ok {p q : ℕ} {b : Box245212.Box} {v : Values}
    (cand : Candidate p q v) (fit : Fits b v) (start : ∀ i,1<(baseBox p q b i).lo)
    (i : Fin 4) : (digitAt p q b i).has (exponents v i) := by
  have sp := inside_primes (p:=p) (q:=q) fit i
  obtain ⟨h1,h2,h3⟩ := facts cand fit start i _ _ (start i).le sp.1 sp.2
  dsimp only [exponents] at h1 h2 h3
  unfold digitAt
  refine cut_ok (cut_ok (cut_ok (fit i.castSucc) true ?_) false ?_) true ?_
  · dsimp only [den] at h1; simp only [if_true]; linarith only [h1]
  · dsimp only [den,num] at h2; simp only [Bool.false_eq_true,if_false]; linarith only [h2]
  · dsimp only [den,num] at h3; simp only [if_true]; linarith only [h3]

private def rawBox (p q : ℕ) (b : Box245212.Box) : Box245212.Box :=
  Fin.lastCases (b 4) (digitAt p q b)

/-- Tighten the four exponent ranges simultaneously, using the initial
    box to enclose each of the four cofactors. -/
def digit (p q : ℕ) (b : Box245212.Box) : Option Box245212.Box :=
  let out := rawBox p q b
  if ∀ i,(out i).lo≤(out i).hi then some out else none

theorem digit_sound {p q : ℕ} {v : Values} {b : Box245212.Box}
    (c : Candidate p q v) (fit : Fits b v) (start : ∀ i,1<(baseBox p q b i).lo) :
    ∃ b',digit p q b=some b' ∧ Fits b' v := by
  have f : Fits (rawBox p q b) v := by
    intro i
    refine Fin.lastCases ?_ (fun j=>?_) i
    · exact fit 4
    · simpa [rawBox,exponents] using digitAt_ok c fit start j
  exact ⟨_,if_pos (fun i=>(f i).1.trans (f i).2),f⟩

end OMA.DigitBox245212
