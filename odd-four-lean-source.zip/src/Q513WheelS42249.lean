import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S42249
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b42249 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨31,62⟩,⟨1,59⟩,⟨479,999999999999999999⟩]
private def b42250 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨31,62⟩,⟨1,59⟩,⟨479,958⟩]
private def b42251 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨31,62⟩,⟨1,2⟩,⟨479,958⟩]
private def b42252 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨31,62⟩,⟨3,53⟩,⟨479,958⟩]
private def b42253 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨31,62⟩,⟨3,6⟩,⟨479,958⟩]
private def b42254 : Box := ![⟨76,94⟩,⟨25,27⟩,⟨31,62⟩,⟨3,6⟩,⟨479,958⟩]
private def b42255 : Box := ![⟨76,94⟩,⟨25,27⟩,⟨31,41⟩,⟨3,6⟩,⟨479,958⟩]
private def b42256 : Box := ![⟨76,94⟩,⟨25,27⟩,⟨31,41⟩,⟨3,4⟩,⟨479,958⟩]
private def b42267 : Box := ![⟨76,94⟩,⟨25,27⟩,⟨31,41⟩,⟨5,6⟩,⟨479,958⟩]
private def b42268 : Box := ![⟨76,94⟩,⟨25,27⟩,⟨42,62⟩,⟨3,6⟩,⟨479,958⟩]
private def b42269 : Box := ![⟨76,84⟩,⟨25,27⟩,⟨42,62⟩,⟨3,6⟩,⟨479,958⟩]
private def b42270 : Box := ![⟨76,84⟩,⟨25,27⟩,⟨42,62⟩,⟨3,4⟩,⟨479,958⟩]
private def b42271 : Box := ![⟨76,84⟩,⟨25,27⟩,⟨42,62⟩,⟨3,3⟩,⟨479,958⟩]
private def b42272 : Box := ![⟨76,84⟩,⟨25,27⟩,⟨42,62⟩,⟨4,4⟩,⟨479,958⟩]
private def b42273 : Box := ![⟨76,84⟩,⟨25,27⟩,⟨42,62⟩,⟨4,4⟩,⟨479,638⟩]
private def b42280 : Box := ![⟨76,84⟩,⟨25,27⟩,⟨42,62⟩,⟨4,4⟩,⟨639,958⟩]
private def b42291 : Box := ![⟨76,84⟩,⟨25,27⟩,⟨42,62⟩,⟨5,6⟩,⟨479,958⟩]
private def b42292 : Box := ![⟨85,94⟩,⟨25,27⟩,⟨42,62⟩,⟨3,6⟩,⟨479,958⟩]
private def b42297 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨31,62⟩,⟨3,6⟩,⟨479,958⟩]
private def b42298 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨31,41⟩,⟨3,6⟩,⟨479,958⟩]
private def b42299 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨31,41⟩,⟨3,4⟩,⟨479,958⟩]
private def b42300 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨31,41⟩,⟨3,3⟩,⟨479,958⟩]
private def b42301 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨31,41⟩,⟨4,4⟩,⟨479,958⟩]
private def b42302 : Box := ![⟨76,84⟩,⟨28,30⟩,⟨31,41⟩,⟨4,4⟩,⟨479,958⟩]
private def b42307 : Box := ![⟨85,94⟩,⟨28,30⟩,⟨31,41⟩,⟨4,4⟩,⟨479,958⟩]
private def b42308 : Box := ![⟨85,94⟩,⟨28,30⟩,⟨31,41⟩,⟨4,4⟩,⟨503,659⟩]
private def b42313 : Box := ![⟨85,94⟩,⟨28,30⟩,⟨31,41⟩,⟨4,4⟩,⟨660,958⟩]
private def b42320 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨31,41⟩,⟨5,6⟩,⟨479,958⟩]
private def b42321 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨42,62⟩,⟨3,6⟩,⟨479,958⟩]
private def b42322 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨42,62⟩,⟨3,4⟩,⟨479,958⟩]
private def b42323 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨42,62⟩,⟨3,3⟩,⟨479,958⟩]
private def b42324 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨42,62⟩,⟨4,4⟩,⟨479,958⟩]
private def b42325 : Box := ![⟨76,84⟩,⟨28,30⟩,⟨42,62⟩,⟨4,4⟩,⟨498,958⟩]
private def b42326 : Box := ![⟨76,84⟩,⟨28,30⟩,⟨42,62⟩,⟨4,4⟩,⟨498,655⟩]
private def b42337 : Box := ![⟨76,84⟩,⟨28,30⟩,⟨42,62⟩,⟨4,4⟩,⟨656,958⟩]
private def b42338 : Box := ![⟨76,84⟩,⟨28,30⟩,⟨42,50⟩,⟨4,4⟩,⟨656,958⟩]
private def b42343 : Box := ![⟨76,84⟩,⟨28,30⟩,⟨51,62⟩,⟨4,4⟩,⟨656,958⟩]
private def b42350 : Box := ![⟨85,94⟩,⟨28,30⟩,⟨42,62⟩,⟨4,4⟩,⟨498,958⟩]
private def b42353 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨42,62⟩,⟨5,6⟩,⟨479,958⟩]
private def b42354 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨31,62⟩,⟨7,53⟩,⟨479,958⟩]
private def b42355 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨31,62⟩,⟨1,59⟩,⟨959,999999999999999999⟩]
private def b42356 : Box := ![⟨76,94⟩,⟨25,27⟩,⟨31,62⟩,⟨1,53⟩,⟨959,999999999999999999⟩]
private def b42357 : Box := ![⟨76,94⟩,⟨25,27⟩,⟨33,62⟩,⟨1,2⟩,⟨959,15121⟩]
private def b42358 : Box := ![⟨76,94⟩,⟨25,27⟩,⟨33,62⟩,⟨3,52⟩,⟨959,15121⟩]
private def b42359 : Box := ![⟨76,84⟩,⟨25,27⟩,⟨33,62⟩,⟨3,47⟩,⟨959,15097⟩]
private def b42366 : Box := ![⟨85,94⟩,⟨25,27⟩,⟨33,62⟩,⟨3,47⟩,⟨959,15097⟩]
private def b42367 : Box := ![⟨85,94⟩,⟨25,27⟩,⟨33,43⟩,⟨3,47⟩,⟨959,15090⟩]
private def b42374 : Box := ![⟨85,94⟩,⟨25,27⟩,⟨44,62⟩,⟨3,47⟩,⟨959,15090⟩]
private def b42375 : Box := ![⟨85,94⟩,⟨25,27⟩,⟨44,62⟩,⟨3,47⟩,⟨959,1804⟩]
private def b42380 : Box := ![⟨85,94⟩,⟨25,27⟩,⟨44,62⟩,⟨3,47⟩,⟨1805,15074⟩]
private def b42389 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨31,62⟩,⟨1,53⟩,⟨959,999999999999999999⟩]
private def b42390 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨31,41⟩,⟨1,53⟩,⟨959,999999999999999999⟩]
private def b42391 : Box := ![⟨76,84⟩,⟨28,30⟩,⟨31,41⟩,⟨1,45⟩,⟨959,999999999999999999⟩]
private def b42396 : Box := ![⟨85,94⟩,⟨28,30⟩,⟨31,41⟩,⟨1,45⟩,⟨959,999999999999999999⟩]
private def b42397 : Box := ![⟨85,94⟩,⟨28,30⟩,⟨31,41⟩,⟨1,45⟩,⟨959,1918⟩]
private def b42398 : Box := ![⟨85,94⟩,⟨28,30⟩,⟨31,41⟩,⟨1,2⟩,⟨959,1918⟩]
private def b42399 : Box := ![⟨85,94⟩,⟨28,30⟩,⟨31,41⟩,⟨3,40⟩,⟨959,1918⟩]
private def b42400 : Box := ![⟨85,94⟩,⟨28,30⟩,⟨31,41⟩,⟨3,6⟩,⟨959,1918⟩]
private def b42411 : Box := ![⟨85,94⟩,⟨28,30⟩,⟨31,41⟩,⟨7,40⟩,⟨959,1918⟩]
private def b42412 : Box := ![⟨85,94⟩,⟨28,30⟩,⟨31,41⟩,⟨1,45⟩,⟨1919,999999999999999999⟩]
private def b42419 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨42,62⟩,⟨1,53⟩,⟨959,999999999999999999⟩]
private def b42420 : Box := ![⟨76,84⟩,⟨28,30⟩,⟨42,62⟩,⟨1,53⟩,⟨959,999999999999999999⟩]
private def b42421 : Box := ![⟨76,84⟩,⟨28,30⟩,⟨42,62⟩,⟨1,51⟩,⟨959,1918⟩]
private def b42422 : Box := ![⟨76,84⟩,⟨28,30⟩,⟨42,62⟩,⟨1,2⟩,⟨959,1918⟩]
private def b42423 : Box := ![⟨76,84⟩,⟨28,30⟩,⟨42,62⟩,⟨3,46⟩,⟨959,1918⟩]
private def b42424 : Box := ![⟨76,84⟩,⟨28,30⟩,⟨42,62⟩,⟨3,6⟩,⟨959,1918⟩]
private def b42425 : Box := ![⟨76,84⟩,⟨28,30⟩,⟨42,62⟩,⟨3,4⟩,⟨959,1918⟩]
private def b42426 : Box := ![⟨76,84⟩,⟨28,30⟩,⟨42,62⟩,⟨3,3⟩,⟨959,1918⟩]
private def b42427 : Box := ![⟨76,84⟩,⟨28,30⟩,⟨42,62⟩,⟨4,4⟩,⟨959,1918⟩]
private def b42428 : Box := ![⟨76,84⟩,⟨28,30⟩,⟨42,50⟩,⟨4,4⟩,⟨959,1918⟩]
private def b42433 : Box := ![⟨76,84⟩,⟨28,30⟩,⟨51,62⟩,⟨4,4⟩,⟨959,1918⟩]
private def b42442 : Box := ![⟨76,84⟩,⟨28,30⟩,⟨42,62⟩,⟨5,6⟩,⟨959,1918⟩]
private def b42443 : Box := ![⟨76,84⟩,⟨28,30⟩,⟨42,62⟩,⟨7,46⟩,⟨959,1918⟩]
private def b42444 : Box := ![⟨76,84⟩,⟨28,30⟩,⟨42,62⟩,⟨1,51⟩,⟨1919,999999999999999999⟩]
private def b42455 : Box := ![⟨85,94⟩,⟨28,30⟩,⟨42,62⟩,⟨1,53⟩,⟨959,999999999999999999⟩]
private def b42456 : Box := ![⟨85,94⟩,⟨28,30⟩,⟨42,62⟩,⟨1,53⟩,⟨959,1918⟩]
private def b42457 : Box := ![⟨85,94⟩,⟨28,30⟩,⟨42,62⟩,⟨1,2⟩,⟨959,1918⟩]
private def b42458 : Box := ![⟨85,94⟩,⟨28,30⟩,⟨42,62⟩,⟨3,48⟩,⟨959,1918⟩]
private def b42459 : Box := ![⟨85,94⟩,⟨28,30⟩,⟨42,62⟩,⟨3,6⟩,⟨959,1918⟩]
private def b42460 : Box := ![⟨85,94⟩,⟨28,30⟩,⟨42,62⟩,⟨3,4⟩,⟨959,1918⟩]
private def b42471 : Box := ![⟨85,94⟩,⟨28,30⟩,⟨42,62⟩,⟨5,6⟩,⟨959,1918⟩]
private def b42472 : Box := ![⟨85,94⟩,⟨28,30⟩,⟨42,62⟩,⟨7,48⟩,⟨959,1918⟩]
private def b42473 : Box := ![⟨85,94⟩,⟨28,30⟩,⟨42,62⟩,⟨1,53⟩,⟨1919,999999999999999999⟩]
private def b42474 : Box := ![⟨85,94⟩,⟨28,30⟩,⟨42,50⟩,⟨1,48⟩,⟨1919,999999999999999999⟩]
private def b42479 : Box := ![⟨85,94⟩,⟨28,30⟩,⟨51,62⟩,⟨1,48⟩,⟨1919,999999999999999999⟩]
private theorem e42251 : Deny 5 13 b42251 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
private theorem e42256 : Deny 5 13 b42256 := by
    apply closeAction rule_sound _ _ 64 [0x150f82431021f8d875ca578d88]
    decide +kernel
private theorem e42267 : Deny 5 13 b42267 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e42255 : Deny 5 13 b42255 :=
    branchAction rule_sound _ _ 1
      0xa b42255 b42256 b42267 (by decide +kernel) e42256 e42267
private theorem e42271 : Deny 5 13 b42271 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
private theorem e42273 : Deny 5 13 b42273 := by
    apply closeAction rule_sound _ _ 64 [0x5430f8242207]
    decide +kernel
private theorem e42280 : Deny 5 13 b42280 := by
    apply closeAction rule_sound _ _ 64 [0x35480f81c3087e09088]
    decide +kernel
private theorem e42272 : Deny 5 13 b42272 :=
    branchAction rule_sound _ _ 1
      0xb b42272 b42273 b42280 (by decide +kernel) e42273 e42280
private theorem e42270 : Deny 5 13 b42270 :=
    branchAction rule_sound _ _ 1
      0xa b42270 b42271 b42272 (by decide +kernel) e42271 e42272
private theorem e42291 : Deny 5 13 b42291 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e42269 : Deny 5 13 b42269 :=
    branchAction rule_sound _ _ 1
      0xa b42269 b42270 b42291 (by decide +kernel) e42270 e42291
private theorem e42292 : Deny 5 13 b42292 := by
    apply closeAction rule_sound _ _ 64 [0x1f7cb54a]
    decide +kernel
private theorem e42268 : Deny 5 13 b42268 :=
    branchAction rule_sound _ _ 1
      0x7 b42268 b42269 b42292 (by decide +kernel) e42269 e42292
private theorem e42254 : Deny 5 13 b42254 :=
    branchAction rule_sound _ _ 1
      0x9 b42254 b42255 b42268 (by decide +kernel) e42255 e42268
private theorem e42300 : Deny 5 13 b42300 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e42302 : Deny 5 13 b42302 := by
    apply closeAction rule_sound _ _ 64 [0xc3203e08]
    decide +kernel
private theorem e42308 : Deny 5 13 b42308 := by
    apply closeAction rule_sound _ _ 64 [0x543e03209]
    decide +kernel
private theorem e42313 : Deny 5 13 b42313 := by
    apply closeAction rule_sound _ _ 64 [0x150c70c3209]
    decide +kernel
private theorem e42307 : Deny 5 13 b42307 :=
    branchAction rule_sound _ _ 2
      0x2f8 b42307 b42308 b42313 (by decide +kernel) e42308 e42313
private theorem e42301 : Deny 5 13 b42301 :=
    branchAction rule_sound _ _ 1
      0x7 b42301 b42302 b42307 (by decide +kernel) e42302 e42307
private theorem e42299 : Deny 5 13 b42299 :=
    branchAction rule_sound _ _ 1
      0xa b42299 b42300 b42301 (by decide +kernel) e42300 e42301
private theorem e42320 : Deny 5 13 b42320 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e42298 : Deny 5 13 b42298 :=
    branchAction rule_sound _ _ 1
      0xa b42298 b42299 b42320 (by decide +kernel) e42299 e42320
private theorem e42323 : Deny 5 13 b42323 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e42326 : Deny 5 13 b42326 := by
    apply closeAction rule_sound _ _ 64 [0x820c8107e020f8107e03209]
    decide +kernel
private theorem e42338 : Deny 5 13 b42338 := by
    apply closeAction rule_sound _ _ 64 [0xf80c70c8]
    decide +kernel
private theorem e42343 : Deny 5 13 b42343 := by
    apply closeAction rule_sound _ _ 64 [0x83108e03e03207]
    decide +kernel
private theorem e42337 : Deny 5 13 b42337 :=
    branchAction rule_sound _ _ 1
      0x9 b42337 b42338 b42343 (by decide +kernel) e42338 e42343
private theorem e42325 : Deny 5 13 b42325 :=
    branchAction rule_sound _ _ 1
      0xb b42325 b42326 b42337 (by decide +kernel) e42326 e42337
private theorem e42350 : Deny 5 13 b42350 := by
    apply closeAction rule_sound _ _ 64 [0x95238]
    decide +kernel
private theorem e42324 : Deny 5 13 b42324 :=
    branchAction rule_sound _ _ 2
      0x1f8 b42324 b42325 b42350 (by decide +kernel) e42325 e42350
private theorem e42322 : Deny 5 13 b42322 :=
    branchAction rule_sound _ _ 1
      0xa b42322 b42323 b42324 (by decide +kernel) e42323 e42324
private theorem e42353 : Deny 5 13 b42353 := by
    apply closeAction rule_sound _ _ 64 [0x7f8]
    decide +kernel
private theorem e42321 : Deny 5 13 b42321 :=
    branchAction rule_sound _ _ 1
      0xa b42321 b42322 b42353 (by decide +kernel) e42322 e42353
private theorem e42297 : Deny 5 13 b42297 :=
    branchAction rule_sound _ _ 1
      0x9 b42297 b42298 b42321 (by decide +kernel) e42298 e42321
private theorem e42253 : Deny 5 13 b42253 :=
    branchAction rule_sound _ _ 1
      0x8 b42253 b42254 b42297 (by decide +kernel) e42254 e42297
private theorem e42354 : Deny 5 13 b42354 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e42252 : Deny 5 13 b42252 :=
    branchAction rule_sound _ _ 1
      0xa b42252 b42253 b42354 (by decide +kernel) e42253 e42354
private theorem e42250 : Deny 5 13 b42250 :=
    branchAction rule_sound _ _ 2
      0x2a3 b42250 b42251 b42252 (by decide +kernel) e42251 e42252
private theorem e42357 : Deny 5 13 b42357 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
private theorem e42359 : Deny 5 13 b42359 := by
    apply closeAction rule_sound _ _ 64 [0xdfe378c90878c2238da3]
    decide +kernel
private theorem e42367 : Deny 5 13 b42367 := by
    apply closeAction rule_sound _ _ 64 [0x1f0f8d8a7f8df68c7088e23]
    decide +kernel
private theorem e42375 : Deny 5 13 b42375 := by
    apply closeAction rule_sound _ _ 64 [0x1f7d528a]
    decide +kernel
private theorem e42380 : Deny 5 13 b42380 := by
    apply closeAction rule_sound _ _ 64 [0x3e03e362380c2238da31f8088e23]
    decide +kernel
private theorem e42374 : Deny 5 13 b42374 :=
    branchAction rule_sound _ _ 2
      0x2f8 b42374 b42375 b42380 (by decide +kernel) e42375 e42380
private theorem e42366 : Deny 5 13 b42366 :=
    branchAction rule_sound _ _ 2
      0x278 b42366 b42367 b42374 (by decide +kernel) e42367 e42374
private theorem e42358 : Deny 5 13 b42358 :=
    branchAction rule_sound _ _ 3
      0x7e23 b42358 b42359 b42366 (by decide +kernel) e42359 e42366
private theorem e42356 : Deny 5 13 b42356 :=
    branchAction rule_sound _ _ 4
      0x2b8da3 b42356 b42357 b42358 (by decide +kernel) e42357 e42358
private theorem e42391 : Deny 5 13 b42391 := by
    apply closeAction rule_sound _ _ 64 [0xc3e378c9e237f8df68c7e23]
    decide +kernel
private theorem e42398 : Deny 5 13 b42398 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
private theorem e42400 : Deny 5 13 b42400 := by
    apply closeAction rule_sound _ _ 64 [0x1f0f80c70c90f621728a]
    decide +kernel
private theorem e42411 : Deny 5 13 b42411 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e42399 : Deny 5 13 b42399 :=
    branchAction rule_sound _ _ 1
      0xa b42399 b42400 b42411 (by decide +kernel) e42400 e42411
private theorem e42397 : Deny 5 13 b42397 :=
    branchAction rule_sound _ _ 2
      0x2a3 b42397 b42398 b42399 (by decide +kernel) e42398 e42399
private theorem e42412 : Deny 5 13 b42412 := by
    apply closeAction rule_sound _ _ 64 [0xc3e231c3e23243e37da3223]
    decide +kernel
private theorem e42396 : Deny 5 13 b42396 :=
    branchAction rule_sound _ _ 1
      0xb b42396 b42397 b42412 (by decide +kernel) e42397 e42412
private theorem e42390 : Deny 5 13 b42390 :=
    branchAction rule_sound _ _ 2
      0x1e3 b42390 b42391 b42396 (by decide +kernel) e42391 e42396
private theorem e42422 : Deny 5 13 b42422 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
private theorem e42426 : Deny 5 13 b42426 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e42428 : Deny 5 13 b42428 := by
    apply closeAction rule_sound _ _ 64 [0xc3e070f8d88]
    decide +kernel
private theorem e42433 : Deny 5 13 b42433 := by
    apply closeAction rule_sound _ _ 64 [0x832380c80c3e36207]
    decide +kernel
private theorem e42427 : Deny 5 13 b42427 :=
    branchAction rule_sound _ _ 1
      0x9 b42427 b42428 b42433 (by decide +kernel) e42428 e42433
private theorem e42425 : Deny 5 13 b42425 :=
    branchAction rule_sound _ _ 1
      0xa b42425 b42426 b42427 (by decide +kernel) e42426 e42427
private theorem e42442 : Deny 5 13 b42442 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e42424 : Deny 5 13 b42424 :=
    branchAction rule_sound _ _ 1
      0xa b42424 b42425 b42442 (by decide +kernel) e42425 e42442
private theorem e42443 : Deny 5 13 b42443 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e42423 : Deny 5 13 b42423 :=
    branchAction rule_sound _ _ 1
      0xa b42423 b42424 b42443 (by decide +kernel) e42424 e42443
private theorem e42421 : Deny 5 13 b42421 :=
    branchAction rule_sound _ _ 2
      0x2a3 b42421 b42422 b42423 (by decide +kernel) e42422 e42423
private theorem e42444 : Deny 5 13 b42444 := by
    apply closeAction rule_sound _ _ 64 [0x30f81c3e070f88dfe37da31f88c90f8df6223]
    decide +kernel
private theorem e42420 : Deny 5 13 b42420 :=
    branchAction rule_sound _ _ 2
      0x2e3 b42420 b42421 b42444 (by decide +kernel) e42421 e42444
private theorem e42457 : Deny 5 13 b42457 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
private theorem e42460 : Deny 5 13 b42460 := by
    apply closeAction rule_sound _ _ 64 [0x150832380f80c8255287]
    decide +kernel
private theorem e42471 : Deny 5 13 b42471 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e42459 : Deny 5 13 b42459 :=
    branchAction rule_sound _ _ 1
      0xa b42459 b42460 b42471 (by decide +kernel) e42460 e42471
private theorem e42472 : Deny 5 13 b42472 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e42458 : Deny 5 13 b42458 :=
    branchAction rule_sound _ _ 1
      0xa b42458 b42459 b42472 (by decide +kernel) e42459 e42472
private theorem e42456 : Deny 5 13 b42456 :=
    branchAction rule_sound _ _ 2
      0x2a3 b42456 b42457 b42458 (by decide +kernel) e42457 e42458
private theorem e42474 : Deny 5 13 b42474 := by
    apply closeAction rule_sound _ _ 64 [0x30e31c3e23223]
    decide +kernel
private theorem e42479 : Deny 5 13 b42479 := by
    apply closeAction rule_sound _ _ 64 [0x83e038c98c70c3e078c8]
    decide +kernel
private theorem e42473 : Deny 5 13 b42473 :=
    branchAction rule_sound _ _ 2
      0x263 b42473 b42474 b42479 (by decide +kernel) e42474 e42479
private theorem e42455 : Deny 5 13 b42455 :=
    branchAction rule_sound _ _ 1
      0xb b42455 b42456 b42473 (by decide +kernel) e42456 e42473
private theorem e42419 : Deny 5 13 b42419 :=
    branchAction rule_sound _ _ 1
      0x7 b42419 b42420 b42455 (by decide +kernel) e42420 e42455
private theorem e42389 : Deny 5 13 b42389 :=
    branchAction rule_sound _ _ 1
      0x9 b42389 b42390 b42419 (by decide +kernel) e42390 e42419
private theorem e42355 : Deny 5 13 b42355 :=
    branchAction rule_sound _ _ 2
      0x223 b42355 b42356 b42389 (by decide +kernel) e42356 e42389
private theorem e42249 : Deny 5 13 b42249 :=
    branchAction rule_sound _ _ 1
      0xb b42249 b42250 b42355 (by decide +kernel) e42250 e42355
theorem deny5_13 : Deny 5 13 ![⟨76,94⟩,⟨25,30⟩,⟨31,62⟩,⟨1,59⟩,⟨479,999999999999999999⟩] := by
  exact e42249
end OMA.Blocks5_13_245212.S42249
