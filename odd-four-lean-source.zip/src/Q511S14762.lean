import FastReplay245212
import SparseDigit245212
import FastRound245212
import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S14762
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b14762 : Box := ![⟨23,1920000000000000011376⟩,⟨7,14⟩,⟨3,6⟩,⟨1,1708429752066115712643⟩,⟨51,999999999999999999⟩]
private def b14763 : Box := ![⟨23,46⟩,⟨7,14⟩,⟨3,6⟩,⟨1,536859504132231408173⟩,⟨51,999999999999999999⟩]
private def b14772 : Box := ![⟨47,1920000000000000011376⟩,⟨7,14⟩,⟨3,6⟩,⟨1,536859504132231408173⟩,⟨51,999999999999999999⟩]
private def b14773 : Box := ![⟨47,1920000000000000011376⟩,⟨7,14⟩,⟨3,6⟩,⟨1,536859504132231408173⟩,⟨51,102⟩]
private def b14774 : Box := ![⟨47,1920000000000000011376⟩,⟨7,14⟩,⟨3,6⟩,⟨1,2⟩,⟨53,101⟩]
private def b14775 : Box := ![⟨47,1920000000000000011376⟩,⟨7,14⟩,⟨3,6⟩,⟨3,531732605729877220091⟩,⟨53,101⟩]
private def b14776 : Box := ![⟨47,1920000000000000011376⟩,⟨7,9⟩,⟨3,6⟩,⟨3,531732605729877220091⟩,⟨53,101⟩]
private def b14791 : Box := ![⟨47,1920000000000000011376⟩,⟨10,14⟩,⟨3,6⟩,⟨3,531732605729877220091⟩,⟨53,101⟩]
private def b14792 : Box := ![⟨47,1920000000000000011376⟩,⟨10,14⟩,⟨3,4⟩,⟨3,531732605729877220091⟩,⟨53,101⟩]
private def b14793 : Box := ![⟨47,1920000000000000011376⟩,⟨10,14⟩,⟨3,4⟩,⟨3,6⟩,⟨53,101⟩]
private def b14794 : Box := ![⟨47,1920000000000000011376⟩,⟨10,14⟩,⟨3,4⟩,⟨7,531732605729877220090⟩,⟨53,101⟩]
private def b14795 : Box := ![⟨47,94⟩,⟨10,14⟩,⟨3,4⟩,⟨7,531732605729877220090⟩,⟨53,101⟩]
private def b14796 : Box := ![⟨47,94⟩,⟨10,14⟩,⟨3,4⟩,⟨7,37⟩,⟨53,65⟩]
private def b14805 : Box := ![⟨47,94⟩,⟨10,14⟩,⟨3,4⟩,⟨7,37⟩,⟨66,85⟩]
private def b14812 : Box := ![⟨95,1920000000000000011376⟩,⟨10,14⟩,⟨3,4⟩,⟨7,531732605729877220090⟩,⟨53,101⟩]
private def b14815 : Box := ![⟨47,1920000000000000011376⟩,⟨10,14⟩,⟨5,6⟩,⟨3,531732605729877220091⟩,⟨53,101⟩]
private def b14816 : Box := ![⟨47,94⟩,⟨10,14⟩,⟨5,6⟩,⟨3,531732605729877220091⟩,⟨53,101⟩]
private def b14817 : Box := ![⟨47,94⟩,⟨10,14⟩,⟨5,6⟩,⟨3,38⟩,⟨53,69⟩]
private def b14826 : Box := ![⟨47,94⟩,⟨10,14⟩,⟨5,6⟩,⟨3,38⟩,⟨70,101⟩]
private def b14835 : Box := ![⟨95,1920000000000000011376⟩,⟨10,14⟩,⟨5,6⟩,⟨3,531732605729877220091⟩,⟨53,101⟩]
private def b14840 : Box := ![⟨47,1920000000000000011376⟩,⟨7,14⟩,⟨3,6⟩,⟨1,536859504132231408173⟩,⟨103,5656⟩]
private def b14841 : Box := ![⟨47,1920000000000000011376⟩,⟨7,14⟩,⟨3,6⟩,⟨1,2⟩,⟨103,5656⟩]
private def b14842 : Box := ![⟨47,1920000000000000011376⟩,⟨7,14⟩,⟨3,6⟩,⟨3,455859649122807020266⟩,⟨103,5656⟩]
private def b14843 : Box := ![⟨47,1920000000000000011376⟩,⟨7,9⟩,⟨3,6⟩,⟨3,455859649122807020266⟩,⟨103,2926⟩]
private def b14846 : Box := ![⟨47,1920000000000000011376⟩,⟨10,14⟩,⟨3,6⟩,⟨3,455859649122807020266⟩,⟨103,2926⟩]
private def b14847 : Box := ![⟨47,1920000000000000011376⟩,⟨10,14⟩,⟨3,4⟩,⟨3,455859649122807020266⟩,⟨103,2483⟩]
private def b14850 : Box := ![⟨47,1920000000000000011376⟩,⟨10,14⟩,⟨5,6⟩,⟨3,455859649122807020266⟩,⟨103,2483⟩]
private def b14851 : Box := ![⟨47,94⟩,⟨10,14⟩,⟨5,6⟩,⟨3,455859649122807020266⟩,⟨103,2357⟩]
private def b14858 : Box := ![⟨95,1920000000000000011376⟩,⟨10,14⟩,⟨5,6⟩,⟨3,455859649122807020266⟩,⟨103,2357⟩]
private def b14859 : Box := ![⟨95,1920000000000000011376⟩,⟨10,14⟩,⟨5,6⟩,⟨3,6⟩,⟨103,2357⟩]
private def b14860 : Box := ![⟨95,1920000000000000011376⟩,⟨10,14⟩,⟨5,6⟩,⟨7,455859649122807020266⟩,⟨103,2357⟩]
private def b14861 : Box := ![⟨95,1920000000000000011376⟩,⟨10,14⟩,⟨5,6⟩,⟨7,455859649122807020266⟩,⟨103,198⟩]
private def b14870 : Box := ![⟨95,1920000000000000011376⟩,⟨10,14⟩,⟨5,6⟩,⟨7,455859649122807020266⟩,⟨199,2357⟩]
theorem deny5_11 : Deny 5 11 ![⟨23,1920000000000000011376⟩,⟨7,14⟩,⟨3,6⟩,⟨1,1708429752066115712643⟩,⟨51,999999999999999999⟩] := by
  have e14763 : Deny 5 11 b14763 := by
    apply closeAction rule_sound _ _ 64 [0x30f8de3243e37da3203e37da31f68c4084238de3]
    decide +kernel
  have e14774 : Deny 5 11 b14774 := by
    apply closeAction rule_sound _ _ 64 [0xf89e6960]
    decide +kernel
  have e14776 : Deny 5 11 b14776 := by
    apply closeAction rule_sound _ _ 64 [0x199d99e31c30f8df4204088e231d99c46678c41f8d232429e02a3]
    decide +kernel
  have e14793 : Deny 5 11 b14793 := by
    apply closeAction rule_sound _ _ 64 [0xf8da0]
    decide +kernel
  have e14796 : Deny 5 11 b14796 := by
    apply closeAction rule_sound _ _ 64 [0x30f89e32438c70c2263204]
    decide +kernel
  have e14805 : Deny 5 11 b14805 := by
    apply closeAction rule_sound _ _ 64 [0xc3e378c70890888c4]
    decide +kernel
  have e14795 : Deny 5 11 b14795 :=
    branchAction rule_sound _ _ 3
      0xbe23 b14795 b14796 b14805 (by decide +kernel) e14796 e14805
  have e14812 : Deny 5 11 b14812 := by
    apply closeAction rule_sound _ _ 64 [0x6676678c7]
    decide +kernel
  have e14794 : Deny 5 11 b14794 :=
    branchAction rule_sound _ _ 1
      0x7 b14794 b14795 b14812 (by decide +kernel) e14795 e14812
  have e14792 : Deny 5 11 b14792 :=
    branchAction rule_sound _ _ 2
      0x2a3 b14792 b14793 b14794 (by decide +kernel) e14793 e14794
  have e14817 : Deny 5 11 b14817 := by
    apply closeAction rule_sound _ _ 64 [0x20e7804238de70e31c30e3263204]
    decide +kernel
  have e14826 : Deny 5 11 b14826 := by
    apply closeAction rule_sound _ _ 64 [0x3e039e32670e31c3103e37d042788c88c4]
    decide +kernel
  have e14816 : Deny 5 11 b14816 :=
    branchAction rule_sound _ _ 2
      0x2e3 b14816 b14817 b14826 (by decide +kernel) e14817 e14826
  have e14835 : Deny 5 11 b14835 := by
    apply closeAction rule_sound _ _ 64 [0x6676788c4648e278c7]
    decide +kernel
  have e14815 : Deny 5 11 b14815 :=
    branchAction rule_sound _ _ 1
      0x7 b14815 b14816 b14835 (by decide +kernel) e14816 e14835
  have e14791 : Deny 5 11 b14791 :=
    branchAction rule_sound _ _ 1
      0x9 b14791 b14792 b14815 (by decide +kernel) e14792 e14815
  have e14775 : Deny 5 11 b14775 :=
    branchAction rule_sound _ _ 1
      0x8 b14775 b14776 b14791 (by decide +kernel) e14776 e14791
  have e14773 : Deny 5 11 b14773 :=
    branchAction rule_sound _ _ 3
      0xa8c4 b14773 b14774 b14775 (by decide +kernel) e14774 e14775
  have e14841 : Deny 5 11 b14841 := by
    apply closeAction rule_sound _ _ 64 [0x2960]
    decide +kernel
  have e14843 : Deny 5 11 b14843 := by
    apply closeAction rule_sound _ _ 64 [0x199e3102238df6d23]
    decide +kernel
  have e14847 : Deny 5 11 b14847 := by
    apply closeAction rule_sound _ _ 64 [0x199c46678c41f8d23]
    decide +kernel
  have e14851 : Deny 5 11 b14851 := by
    apply closeAction rule_sound _ _ 64 [0xc3e232670f8de31c4088e23]
    decide +kernel
  have e14859 : Deny 5 11 b14859 := by
    apply closeAction rule_sound _ _ 64 [0x11]
    decide +kernel
  have e14861 : Deny 5 11 b14861 := by
    apply closeAction rule_sound _ _ 64 [0x6676599c42e31199c42d92278c78c4]
    decide +kernel
  have e14870 : Deny 5 11 b14870 := by
    apply closeAction rule_sound _ _ 64 [0x6676479d9678df69e010ae278c7667102238df6d23223]
    decide +kernel
  have e14860 : Deny 5 11 b14860 :=
    branchAction rule_sound _ _ 1
      0xb b14860 b14861 b14870 (by decide +kernel) e14861 e14870
  have e14858 : Deny 5 11 b14858 :=
    branchAction rule_sound _ _ 1
      0xa b14858 b14859 b14860 (by decide +kernel) e14859 e14860
  have e14850 : Deny 5 11 b14850 :=
    branchAction rule_sound _ _ 2
      0x1f8 b14850 b14851 b14858 (by decide +kernel) e14851 e14858
  have e14846 : Deny 5 11 b14846 :=
    branchAction rule_sound _ _ 2
      0x278 b14846 b14847 b14850 (by decide +kernel) e14847 e14850
  have e14842 : Deny 5 11 b14842 :=
    branchAction rule_sound _ _ 2
      0x238 b14842 b14843 b14846 (by decide +kernel) e14843 e14846
  have e14840 : Deny 5 11 b14840 :=
    branchAction rule_sound _ _ 2
      0x2a3 b14840 b14841 b14842 (by decide +kernel) e14841 e14842
  have e14772 : Deny 5 11 b14772 :=
    branchAction rule_sound _ _ 2
      0x2f8 b14772 b14773 b14840 (by decide +kernel) e14773 e14840
  have e14762 : Deny 5 11 b14762 :=
    branchAction rule_sound _ _ 2
      0x1e3 b14762 b14763 b14772 (by decide +kernel) e14763 e14772
  exact e14762
end OMA.Blocks5_11_245212.S14762
