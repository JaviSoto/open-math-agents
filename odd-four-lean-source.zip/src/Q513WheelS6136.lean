import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S6136
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b6136 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨11,22⟩,⟨3,1366486486486486494634⟩,⟨37,47⟩]
theorem deny5_13 : Deny 5 13 ![⟨18,22⟩,⟨31,62⟩,⟨11,22⟩,⟨3,1366486486486486494634⟩,⟨37,47⟩] := by
  have e6136 : Deny 5 13 b6136 := by
    apply closeAction rule_sound _ _ 64 [0xe370f70e1261243e370c8dc31c30c72480838490c32481042f80f8dc31c32038492830f78498490c3203e372481cb2a3,0xc3df62021c40831c30f7d872042c30f7d88102df6d441f8283102238de1243102238df62361c40820e12430c884710a,0x8c88c72c20832442380f80c81c3dc31c30c92040820c72042c30c81ca0c3203e378478490c3203dc70c3e37db51f7248,0x2042ca0c38c88c90c38c80f8de32632078c40820c41f8dc3e370c7248dc2083244238dc3e370e3223243e370e32038c9,0xf8dc32370e31e3243e370c8dc31c30e31e32632020c70c38c98c88c40820c92378c42c30f61c30f72481020c9dc30c9,0x820c8107e37]
    decide +kernel
  exact e6136
end OMA.Blocks5_13_245212.S6136
