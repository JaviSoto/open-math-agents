import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S40977
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b40977 : Box := ![⟨47,94⟩,⟨15,20⟩,⟨15,1920000000000000011376⟩,⟨1,900178041543026711610⟩,⟨239,999999999999999999⟩]
private def b40978 : Box := ![⟨47,62⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨1,900178041543026711607⟩,⟨239,572⟩]
private def b40979 : Box := ![⟨63,94⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨1,900178041543026711607⟩,⟨239,572⟩]
private def b40980 : Box := ![⟨63,94⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨1,2⟩,⟨239,572⟩]
private def b40981 : Box := ![⟨63,94⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨3,900178041543026711601⟩,⟨239,572⟩]
private def b40982 : Box := ![⟨63,94⟩,⟨15,17⟩,⟨31,1920000000000000011376⟩,⟨3,900178041543026711601⟩,⟨239,572⟩]
private def b40985 : Box := ![⟨63,94⟩,⟨18,20⟩,⟨31,1920000000000000011376⟩,⟨3,900178041543026711601⟩,⟨239,572⟩]
private def b40986 : Box := ![⟨63,94⟩,⟨18,20⟩,⟨31,62⟩,⟨3,900178041543026711601⟩,⟨239,572⟩]
private def b40987 : Box := ![⟨63,75⟩,⟨18,20⟩,⟨32,62⟩,⟨3,57⟩,⟨239,320⟩]
private def b40988 : Box := ![⟨76,94⟩,⟨18,20⟩,⟨32,62⟩,⟨3,57⟩,⟨239,320⟩]
private def b40989 : Box := ![⟨76,94⟩,⟨18,18⟩,⟨32,62⟩,⟨3,57⟩,⟨239,317⟩]
private def b40990 : Box := ![⟨76,94⟩,⟨19,20⟩,⟨32,62⟩,⟨3,57⟩,⟨239,317⟩]
private def b40991 : Box := ![⟨76,84⟩,⟨19,20⟩,⟨32,62⟩,⟨3,57⟩,⟨239,317⟩]
private def b40996 : Box := ![⟨85,94⟩,⟨19,20⟩,⟨32,62⟩,⟨3,57⟩,⟨239,317⟩]
private def b40997 : Box := ![⟨85,94⟩,⟨19,20⟩,⟨32,62⟩,⟨3,6⟩,⟨239,317⟩]
private def b40998 : Box := ![⟨85,94⟩,⟨19,20⟩,⟨32,62⟩,⟨7,57⟩,⟨239,317⟩]
private def b40999 : Box := ![⟨85,94⟩,⟨19,20⟩,⟨32,62⟩,⟨7,13⟩,⟨239,317⟩]
private def b41000 : Box := ![⟨85,94⟩,⟨19,20⟩,⟨35,44⟩,⟨7,13⟩,⟨239,302⟩]
private def b41003 : Box := ![⟨85,94⟩,⟨19,20⟩,⟨45,62⟩,⟨7,13⟩,⟨239,302⟩]
private def b41004 : Box := ![⟨85,94⟩,⟨19,20⟩,⟨45,62⟩,⟨7,13⟩,⟨239,263⟩]
private def b41011 : Box := ![⟨85,94⟩,⟨19,20⟩,⟨45,62⟩,⟨7,13⟩,⟨264,293⟩]
private def b41016 : Box := ![⟨85,94⟩,⟨19,20⟩,⟨32,62⟩,⟨14,57⟩,⟨239,317⟩]
private def b41017 : Box := ![⟨63,94⟩,⟨18,20⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711601⟩,⟨239,572⟩]
private def b41018 : Box := ![⟨63,75⟩,⟨18,20⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711601⟩,⟨239,572⟩]
private def b41029 : Box := ![⟨76,94⟩,⟨18,20⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711601⟩,⟨239,572⟩]
private def b41030 : Box := ![⟨76,94⟩,⟨18,20⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711601⟩,⟨239,337⟩]
private def b41031 : Box := ![⟨76,94⟩,⟨18,20⟩,⟨63,126⟩,⟨3,900178041543026711601⟩,⟨239,337⟩]
private def b41032 : Box := ![⟨76,94⟩,⟨18,20⟩,⟨63,84⟩,⟨3,87⟩,⟨239,337⟩]
private def b41033 : Box := ![⟨76,94⟩,⟨18,18⟩,⟨63,84⟩,⟨3,67⟩,⟨239,337⟩]
private def b41034 : Box := ![⟨76,94⟩,⟨19,20⟩,⟨63,84⟩,⟨3,67⟩,⟨239,337⟩]
private def b41035 : Box := ![⟨76,84⟩,⟨19,20⟩,⟨63,84⟩,⟨3,67⟩,⟨239,337⟩]
private def b41046 : Box := ![⟨85,94⟩,⟨19,20⟩,⟨63,84⟩,⟨3,67⟩,⟨239,337⟩]
private def b41047 : Box := ![⟨85,94⟩,⟨19,20⟩,⟨63,84⟩,⟨3,6⟩,⟨239,337⟩]
private def b41048 : Box := ![⟨85,94⟩,⟨19,20⟩,⟨63,84⟩,⟨7,67⟩,⟨239,337⟩]
private def b41049 : Box := ![⟨85,94⟩,⟨19,20⟩,⟨63,84⟩,⟨7,13⟩,⟨239,337⟩]
private def b41050 : Box := ![⟨85,94⟩,⟨19,20⟩,⟨63,84⟩,⟨7,13⟩,⟨239,279⟩]
private def b41061 : Box := ![⟨85,94⟩,⟨19,20⟩,⟨63,84⟩,⟨7,13⟩,⟨280,337⟩]
private def b41068 : Box := ![⟨85,94⟩,⟨19,20⟩,⟨63,84⟩,⟨14,67⟩,⟨239,337⟩]
private def b41069 : Box := ![⟨76,94⟩,⟨18,20⟩,⟨85,126⟩,⟨3,87⟩,⟨239,337⟩]
private def b41070 : Box := ![⟨76,94⟩,⟨18,20⟩,⟨127,1920000000000000011376⟩,⟨3,900178041543026711601⟩,⟨239,337⟩]
private def b41073 : Box := ![⟨76,94⟩,⟨18,20⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711601⟩,⟨338,572⟩]
private theorem e40978 : Deny 5 13 b40978 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e40980 : Deny 5 13 b40980 := by
    apply closeAction rule_sound _ _ 64 [0xa2]
    decide +kernel
private theorem e40982 : Deny 5 13 b40982 := by
    apply closeAction rule_sound _ _ 64 [0x1cbc4087e37da3]
    decide +kernel
private theorem e40987 : Deny 5 13 b40987 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e40989 : Deny 5 13 b40989 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e40991 : Deny 5 13 b40991 := by
    apply closeAction rule_sound _ _ 64 [0x3088da311de37da3107e37da3]
    decide +kernel
private theorem e40997 : Deny 5 13 b40997 := by
    apply closeAction rule_sound _ _ 64 [0x15e36]
    decide +kernel
private theorem e41000 : Deny 5 13 b41000 := by
    apply closeAction rule_sound _ _ 64 [0xc4088e04]
    decide +kernel
private theorem e41004 : Deny 5 13 b41004 := by
    apply closeAction rule_sound _ _ 64 [0x30c70c4087e37d88]
    decide +kernel
private theorem e41011 : Deny 5 13 b41011 := by
    apply closeAction rule_sound _ _ 64 [0x30f8df61c2204]
    decide +kernel
private theorem e41003 : Deny 5 13 b41003 :=
    branchAction rule_sound _ _ 2
      0x2c4 b41003 b41004 b41011 (by decide +kernel) e41004 e41011
private theorem e40999 : Deny 5 13 b40999 :=
    branchAction rule_sound _ _ 3
      0x9e36 b40999 b41000 b41003 (by decide +kernel) e41000 e41003
private theorem e41016 : Deny 5 13 b41016 := by
    apply closeAction rule_sound _ _ 64 [0x1d]
    decide +kernel
private theorem e40998 : Deny 5 13 b40998 :=
    branchAction rule_sound _ _ 1
      0xa b40998 b40999 b41016 (by decide +kernel) e40999 e41016
private theorem e40996 : Deny 5 13 b40996 :=
    branchAction rule_sound _ _ 1
      0xa b40996 b40997 b40998 (by decide +kernel) e40997 e40998
private theorem e40990 : Deny 5 13 b40990 :=
    branchAction rule_sound _ _ 1
      0x7 b40990 b40991 b40996 (by decide +kernel) e40991 e40996
private theorem e40988 : Deny 5 13 b40988 :=
    branchAction rule_sound _ _ 2
      0x204 b40988 b40989 b40990 (by decide +kernel) e40989 e40990
private theorem e40986 : Deny 5 13 b40986 :=
    branchAction rule_sound _ _ 4
      0x1f8da3 b40986 b40987 b40988 (by decide +kernel) e40987 e40988
private theorem e41018 : Deny 5 13 b41018 := by
    apply closeAction rule_sound _ _ 64 [0x72f709bdd8c90af88a50a102238da3]
    decide +kernel
private theorem e41033 : Deny 5 13 b41033 := by
    apply closeAction rule_sound _ _ 64 [0x1de37da3]
    decide +kernel
private theorem e41035 : Deny 5 13 b41035 := by
    apply closeAction rule_sound _ _ 64 [0x1d74311de37da2107e222b8283e37be2284778df6bc4238be3]
    decide +kernel
private theorem e41047 : Deny 5 13 b41047 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
private theorem e41050 : Deny 5 13 b41050 := by
    apply closeAction rule_sound _ _ 64 [0x20f8bc41f8103109e03e03e2f887bc3e09204]
    decide +kernel
private theorem e41061 : Deny 5 13 b41061 := by
    apply closeAction rule_sound _ _ 64 [0xf80f8bc70f8242204]
    decide +kernel
private theorem e41049 : Deny 5 13 b41049 :=
    branchAction rule_sound _ _ 1
      0xb b41049 b41050 b41061 (by decide +kernel) e41050 e41061
private theorem e41068 : Deny 5 13 b41068 := by
    apply closeAction rule_sound _ _ 64 [0x1d]
    decide +kernel
private theorem e41048 : Deny 5 13 b41048 :=
    branchAction rule_sound _ _ 1
      0xa b41048 b41049 b41068 (by decide +kernel) e41049 e41068
private theorem e41046 : Deny 5 13 b41046 :=
    branchAction rule_sound _ _ 1
      0xa b41046 b41047 b41048 (by decide +kernel) e41047 e41048
private theorem e41034 : Deny 5 13 b41034 :=
    branchAction rule_sound _ _ 1
      0x7 b41034 b41035 b41046 (by decide +kernel) e41035 e41046
private theorem e41032 : Deny 5 13 b41032 :=
    branchAction rule_sound _ _ 2
      0x223 b41032 b41033 b41034 (by decide +kernel) e41033 e41034
private theorem e41069 : Deny 5 13 b41069 := by
    apply closeAction rule_sound _ _ 64 [0x76f]
    decide +kernel
private theorem e41031 : Deny 5 13 b41031 :=
    branchAction rule_sound _ _ 2
      0x263 b41031 b41032 b41069 (by decide +kernel) e41032 e41069
private theorem e41070 : Deny 5 13 b41070 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdcbe326f]
    decide +kernel
private theorem e41030 : Deny 5 13 b41030 :=
    branchAction rule_sound _ _ 1
      0x9 b41030 b41031 b41070 (by decide +kernel) e41031 e41070
private theorem e41073 : Deny 5 13 b41073 := by
    apply closeAction rule_sound _ _ 64 [0x72f72f8c9bddbe311de37da3109e368c90a2282223]
    decide +kernel
private theorem e41029 : Deny 5 13 b41029 :=
    branchAction rule_sound _ _ 1
      0xb b41029 b41030 b41073 (by decide +kernel) e41030 e41073
private theorem e41017 : Deny 5 13 b41017 :=
    branchAction rule_sound _ _ 1
      0x7 b41017 b41018 b41029 (by decide +kernel) e41018 e41029
private theorem e40985 : Deny 5 13 b40985 :=
    branchAction rule_sound _ _ 1
      0x9 b40985 b40986 b41017 (by decide +kernel) e40986 e41017
private theorem e40981 : Deny 5 13 b40981 :=
    branchAction rule_sound _ _ 1
      0x8 b40981 b40982 b40985 (by decide +kernel) e40982 e40985
private theorem e40979 : Deny 5 13 b40979 :=
    branchAction rule_sound _ _ 2
      0x2a3 b40979 b40980 b40981 (by decide +kernel) e40980 e40981
private theorem e40977 : Deny 5 13 b40977 :=
    branchAction rule_sound _ _ 4
      0x1f8da3 b40977 b40978 b40979 (by decide +kernel) e40978 e40979
theorem deny5_13 : Deny 5 13 ![⟨47,94⟩,⟨15,20⟩,⟨15,1920000000000000011376⟩,⟨1,900178041543026711610⟩,⟨239,999999999999999999⟩] := by
  exact e40977
end OMA.Blocks5_13_245212.S40977
