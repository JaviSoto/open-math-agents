import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S5329
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b5329 : Box := ![⟨15,22⟩,⟨31,1920000000000000011376⟩,⟨5,10⟩,⟨3,1920000000000000011376⟩,⟨29,47⟩]
theorem deny5_13 : Deny 5 13 ![⟨15,22⟩,⟨31,1920000000000000011376⟩,⟨5,10⟩,⟨3,1920000000000000011376⟩,⟨29,47⟩] := by
  have e5329 : Deny 5 13 b5329 := by
    apply closeAction rule_sound _ _ 64 [0x84784984a8c809aadaae3223242aeaa212820c9dc31c30e31e32030e32632632030f8df6d611c3e37849da12a31c42e3,0x6b7d63244087e37da320284a8c78c44b70820c88441f8dc20c8dc3dc38c88c78c90aa8442f8de10c8dc30e12611c30f7,0x1cbe3684a8c86ab688adae37db58c88c46ab688adaac30f88c98c86b8df68c78c82daada238d63243e2baa12830f78c8,0x8c70c38c98c80c38c90e32231cb0c3e378c911ae37d63107e23243dc2235087df6d440c3de11c3203e378490f8df6d61,0xae320b6ab6ab6ab1038c4238ae322b8c88c948a0c38c90e31c30f8de326320311adf6d441f8df6d631e3103e370e3243,0xeb8441f80eb84984a8c8ae321aada22b6ab0c3e23263223203e36ae12a31e3102ada083ae1109e03e03ae126b84784a,0x26ab844278deb6ab683dc4]
    decide +kernel
  exact e5329
end OMA.Blocks5_13_245212.S5329
