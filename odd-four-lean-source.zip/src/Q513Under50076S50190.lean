import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S50190
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b50190 : Box := ![⟨153,169⟩,⟨23,24⟩,⟨31,41⟩,⟨1,53⟩,⟨1919,999999999999999999⟩]
private def b50191 : Box := ![⟨153,169⟩,⟨23,24⟩,⟨31,35⟩,⟨1,50⟩,⟨1919,999999999999999999⟩]
private def b50192 : Box := ![⟨153,169⟩,⟨23,23⟩,⟨31,35⟩,⟨1,48⟩,⟨1919,999999999999999999⟩]
private def b50193 : Box := ![⟨153,169⟩,⟨24,24⟩,⟨31,35⟩,⟨1,48⟩,⟨1919,999999999999999999⟩]
private def b50194 : Box := ![⟨153,169⟩,⟨23,24⟩,⟨36,41⟩,⟨1,50⟩,⟨1919,999999999999999999⟩]
private def b50195 : Box := ![⟨153,160⟩,⟨23,24⟩,⟨36,41⟩,⟨1,50⟩,⟨1919,999999999999999999⟩]
private def b50196 : Box := ![⟨161,169⟩,⟨23,24⟩,⟨36,41⟩,⟨1,50⟩,⟨1919,999999999999999999⟩]
private def b50197 : Box := ![⟨161,169⟩,⟨23,23⟩,⟨36,41⟩,⟨1,50⟩,⟨1919,999999999999999999⟩]
private def b50198 : Box := ![⟨161,169⟩,⟨24,24⟩,⟨36,41⟩,⟨1,50⟩,⟨1919,999999999999999999⟩]
private theorem e50192 : Deny 5 13 b50192 := by
    apply closeAction rule_sound _ _ 64 [0xf8]
    decide +kernel
private theorem e50193 : Deny 5 13 b50193 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e50191 : Deny 5 13 b50191 :=
    branchAction rule_sound _ _ 2
      0x223 b50191 b50192 b50193 (by decide +kernel) e50192 e50193
private theorem e50195 : Deny 5 13 b50195 := by
    apply closeAction rule_sound _ _ 64 [0xe3]
    decide +kernel
private theorem e50197 : Deny 5 13 b50197 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e50198 : Deny 5 13 b50198 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e50196 : Deny 5 13 b50196 :=
    branchAction rule_sound _ _ 1
      0x8 b50196 b50197 b50198 (by decide +kernel) e50197 e50198
private theorem e50194 : Deny 5 13 b50194 :=
    branchAction rule_sound _ _ 1
      0x7 b50194 b50195 b50196 (by decide +kernel) e50195 e50196
private theorem e50190 : Deny 5 13 b50190 :=
    branchAction rule_sound _ _ 2
      0x263 b50190 b50191 b50194 (by decide +kernel) e50191 e50194
theorem deny5_13 : Deny 5 13 ![⟨153,169⟩,⟨23,24⟩,⟨31,41⟩,⟨1,53⟩,⟨1919,999999999999999999⟩] := by
  exact e50190
end OMA.Blocks5_13_245212.S50190
