import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S44179
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b44179 : Box := ![⟨95,190⟩,⟨15,17⟩,⟨15,30⟩,⟨3,68⟩,⟨127,164⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨15,17⟩,⟨15,30⟩,⟨3,68⟩,⟨127,164⟩] := by
  have e44179 : Deny 5 13 b44179 := by
    apply closeAction rule_sound _ _ 64 [0x1f7d840832031c380956680a0c3e37243e37d881c42c220a0c3e379e3243e37da32270c2238df68c7102238de32631c4,0x8c47420f80c720a0f8dc38c88c90f70c80dde378c88c98c710b0dde37da31c4778df68c41f88c80c3e378090880b8df6,0x2030f82278c98c710b6439e0087e20284678de78c42789c89e32677430c70f8df620a0d9e37d888c90c3e378c90888c7,0x9c42f88c78c86590f80f88080f89e02602a72a70d9e37d88678de78c98c78c46420e7109e199c31e78092a70f8dc39e3,0x1e31029c209de379c31c8109e02083e278099a0108e15e379a02a680adc7dc42dd9dddf68c4743e270c7778df69e024a,0x9d7439e32678c99c89dd75d083107e030f81e020a28a0f8dc38080e780980a0f8dc39c89c38c79e3263]
    decide +kernel
  exact e44179
end OMA.Blocks5_13_245212.S44179
