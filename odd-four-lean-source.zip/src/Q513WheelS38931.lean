import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S38931
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b38931 : Box := ![⟨47,62⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨1,1017986577181208059763⟩,⟨127,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,62⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨1,1017986577181208059763⟩,⟨127,233⟩] := by
  have e38931 : Deny 5 13 b38931 := by
    apply closeAction rule_sound _ _ 64 [0xd88087102238df68c78c90c22021c2204087e37da22842c472f72f8c9bdde37da3242204738df68c41f8df68c4238de3,0x8c475d7c30f824828a0c38c98c70c38880c4088e221e229ddf68c4743087d8a10bdc80c3dc8778df622326310b0dce37,0x878c471cbe22af0c3e3722325c0f8df688abc78cb11ce37da3108e2f8c98c70efb6c88a75f088d8a0f8df68c7088df6,0x820e31ef22f0f70c88c98c40af083bc88c9dc42e31dd0e229c76229d2af8c78c88c910b72f0dc1ef0f8de325ce37d88,0x2b7da311cbdc26f09d22f76f0e326325cbc3738de322326f0c22232631dd087e37da3223263102708e2f0820c7109e37,0xe37be3107e23109e2326f102238be326f7778c474388a738df62042ef778df68c9087102238da325cbc2238df68c70a2,0x72f72f72f11c74a11c]
    decide +kernel
  exact e38931
end OMA.Blocks5_13_245212.S38931
