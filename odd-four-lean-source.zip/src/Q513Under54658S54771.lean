import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S54771
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b54771 : Box := ![⟨54,57⟩,⟨87,126⟩,⟨13,14⟩,⟨3,48⟩,⟨959,434784⟩]
private def b54772 : Box := ![⟨54,57⟩,⟨87,102⟩,⟨13,14⟩,⟨3,47⟩,⟨959,1409⟩]
private def b54773 : Box := ![⟨54,57⟩,⟨103,126⟩,⟨13,14⟩,⟨3,47⟩,⟨959,1409⟩]
private def b54774 : Box := ![⟨54,57⟩,⟨103,126⟩,⟨13,13⟩,⟨8,46⟩,⟨959,1408⟩]
private def b54775 : Box := ![⟨54,57⟩,⟨103,126⟩,⟨14,14⟩,⟨8,46⟩,⟨959,1408⟩]
private theorem e54772 : Deny 5 13 b54772 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e54774 : Deny 5 13 b54774 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e54775 : Deny 5 13 b54775 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e54773 : Deny 5 13 b54773 :=
    branchAction rule_sound _ _ 4
      0x278ae3 b54773 b54774 b54775 (by decide +kernel) e54774 e54775
private theorem e54771 : Deny 5 13 b54771 :=
    branchAction rule_sound _ _ 3
      0x8e23 b54771 b54772 b54773 (by decide +kernel) e54772 e54773
theorem deny5_13 : Deny 5 13 ![⟨54,57⟩,⟨87,126⟩,⟨13,14⟩,⟨3,48⟩,⟨959,434784⟩] := by
  exact e54771
end OMA.Blocks5_13_245212.S54771
