import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S37113
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b37113 : Box := ![⟨47,62⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨3,1129131513647642686627⟩,⟨94,113⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,62⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨3,1129131513647642686627⟩,⟨94,113⟩] := by
  have e37113 : Deny 5 13 b37113 := by
    apply closeAction rule_sound _ _ 64 [0x2442ca0c3e37d880f82552a20f8df6887e3788a778df68c80c3e37da31c3e378c9738df68c8d84088e378c78c98c88c4,0xe2f8878842b8be325ce37daf8c8be31ef8c950a7430f8dc90f8df61dde37d88d840f8dc32032430f8df62070c3e37d88,0x21f0e32038c88c910b0c3e372421f7d840c3dc90dfe37277da21e210b0f8df688888a8c78c972f75dbe229cbdc0dd203,0xdc90f78878888842e2283dc38c90c38c98c70dce37da31f72030f78c70f8df68c88c98c47f8dc3e370c72370c3de31e3,0x238dc20c41f8dc38c88c9dc42c3dc38880c90c3df62221c30f8dc90f8df6887df6888115e378832770f70e22221c3dc3,0x26f8c88c40820af0c9bc7108e37bc42ef8c7be3254282083207ddd0f8dc32431ca8c87f70c80e3223263102083887884,0x1ce2f082bec884238dc2bdfe37083be31ef8c88c972f0c3e37be31e3]
    decide +kernel
  exact e37113
end OMA.Blocks5_13_245212.S37113
