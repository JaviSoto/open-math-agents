import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S50210
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b50210 : Box := ![⟨153,190⟩,⟨23,24⟩,⟨42,62⟩,⟨1,67⟩,⟨959,999999999999999999⟩]
private def b50211 : Box := ![⟨153,169⟩,⟨23,24⟩,⟨42,62⟩,⟨1,67⟩,⟨3178,999999999999999999⟩]
private def b50212 : Box := ![⟨153,169⟩,⟨23,24⟩,⟨42,50⟩,⟨1,54⟩,⟨3183,999999999999999999⟩]
private def b50213 : Box := ![⟨153,169⟩,⟨23,23⟩,⟨42,50⟩,⟨1,50⟩,⟨3192,999999999999999999⟩]
private def b50214 : Box := ![⟨153,160⟩,⟨23,23⟩,⟨42,50⟩,⟨1,50⟩,⟨3194,999999999999999999⟩]
private def b50215 : Box := ![⟨161,169⟩,⟨23,23⟩,⟨42,50⟩,⟨1,50⟩,⟨3194,999999999999999999⟩]
private def b50216 : Box := ![⟨153,169⟩,⟨24,24⟩,⟨42,50⟩,⟨1,50⟩,⟨3192,999999999999999999⟩]
private def b50217 : Box := ![⟨153,169⟩,⟨23,24⟩,⟨51,62⟩,⟨1,54⟩,⟨3183,999999999999999999⟩]
private def b50218 : Box := ![⟨170,190⟩,⟨23,24⟩,⟨42,62⟩,⟨1,67⟩,⟨3178,999999999999999999⟩]
private theorem e50214 : Deny 5 13 b50214 := by
    apply closeAction rule_sound _ _ 64 [0x3e23]
    decide +kernel
private theorem e50215 : Deny 5 13 b50215 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e50213 : Deny 5 13 b50213 :=
    branchAction rule_sound _ _ 2
      0x1f8 b50213 b50214 b50215 (by decide +kernel) e50214 e50215
private theorem e50216 : Deny 5 13 b50216 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e50212 : Deny 5 13 b50212 :=
    branchAction rule_sound _ _ 3
      0x8e23 b50212 b50213 b50216 (by decide +kernel) e50213 e50216
private theorem e50217 : Deny 5 13 b50217 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e50211 : Deny 5 13 b50211 :=
    branchAction rule_sound _ _ 3
      0x9e23 b50211 b50212 b50217 (by decide +kernel) e50212 e50217
private theorem e50218 : Deny 5 13 b50218 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e50210 : Deny 5 13 b50210 :=
    branchAction rule_sound _ _ 2
      0x1f8 b50210 b50211 b50218 (by decide +kernel) e50211 e50218
theorem deny5_13 : Deny 5 13 ![⟨153,190⟩,⟨23,24⟩,⟨42,62⟩,⟨1,67⟩,⟨959,999999999999999999⟩] := by
  exact e50210
end OMA.Blocks5_13_245212.S50210
