import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S43855
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b43855 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨10,14⟩,⟨5,342194907813871819440⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨191,382⟩,⟨25,30⟩,⟨10,14⟩,⟨5,342194907813871819440⟩,⟨479,999999999999999999⟩] := by
  have e43855 : Deny 5 13 b43855 := by
    apply closeAction rule_sound _ _ 64 [0x8cb0898d99e32e36678cb667667088e231f8089e278d99e32f88c76678d99e31f88c86678c2238d232636599cb9e32e3,0x44b44b44b44b44b44b44b44b2a36678cb8d99e32e36678cb8d99e32e36678cb8d99e32d9e372236678cb8d99e32e3667,0x1964308808980a0a780b]
    decide +kernel
  exact e43855
end OMA.Blocks5_13_245212.S43855
