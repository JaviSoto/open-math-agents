import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S23101
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b23101 : Box := ![⟨31,46⟩,⟨63,1920000000000000011376⟩,⟨7,14⟩,⟨1,648707482993197282786⟩,⟨119,218⟩]
theorem deny5_13 : Deny 5 13 ![⟨31,46⟩,⟨63,1920000000000000011376⟩,⟨7,14⟩,⟨1,648707482993197282786⟩,⟨119,218⟩] := by
  have e23101 : Deny 5 13 b23101 := by
    apply closeAction rule_sound _ _ 64 [0x2421f884aac46b8df58c4238d6325f6b8df58c4278db58c710be2321aac46ab8c4238d6325fe37da12a31d7aa884a8c4,0x8c42788c80ab84a8c96ab6ab8c8adf0eb0881021f8deb8c9adfe37da32021f68c47da0c3e211c3e0884a8c97e129a0c2,0x8c8d6311a0f86c90eb84784aac30f78c80f8de31e32042c30f8deb8c76b8df5ae326b11ae37db58c4238d631c46b8df5,0x8c4683e2b0c80e11e12ab10bac3ac40f8de3108e378c8ae32631c42e321aadaae322b683087e2129ae37d49adae37db5,0xae31e31020eb847deb8c42f8ac3e2b0e32038c78c88c97c3e2b0e322b8c4278ac3ac38c80e326321a0c3e37da11e12ab,0xe37db5ac7ac4088e37d6325fe37da12a31e3102adf0f8dc38c78c42780f8ac320384784a8c80820eb248dc3e37ac38c8,0x203ac70eb0e322b8c710bac30f8de32046b8df58c41f88c80a12a325f0eb0f88c8ac46b8df58c42388c90eb0f8de321a,0x26b8c78c40ab7c3ae326322b10badf0c3e078c90eb0f8203e3784784a8c80eb0e32031c3ac4088e37d6b1e3103e2b0e3,0x1aae3102687e378c4689e1aae31eb8c4238adfe370f8deb0e322b8c97c3ae3]
    decide +kernel
  exact e23101
end OMA.Blocks5_13_245212.S23101
