import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S47
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b47 : Box := ![⟨5,1920000000000000011376⟩,⟨1,2⟩,⟨1,1920000000000000011376⟩,⟨1,1920000000000000011376⟩,⟨12,999999999999999999⟩]
theorem deny5_11 : Deny 5 11 ![⟨5,1920000000000000011376⟩,⟨1,2⟩,⟨1,1920000000000000011376⟩,⟨1,1920000000000000011376⟩,⟨12,999999999999999999⟩] := by
  have e47 : Deny 5 11 b47 := by
    apply closeAction rule_sound _ _ 64 [0x9e31d1284df6d23107e37d2327771cbe229c8c9737da325cdf688a737da31f7d821f8df68c7d82237d84db5d23107e34,0xda21d52a229ddf688788a0c3de325ddf68c7de32631c42d50a79a02665621c29e6809884577db48841f888a6676479d9,0x87df6d231f7db410208208380980988a887dc29c20a70e31e32430f7da780980a8c78c909d88a76325d5432550f6887,0x8254788a0a77478c975d88a8c7566547db488a6677631f7d2325d737da31dcdf68c7]
    decide +kernel
  exact e47
end OMA.Blocks5_11_245212.S47
