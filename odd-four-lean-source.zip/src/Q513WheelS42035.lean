import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S42035
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b42035 : Box := ![⟨63,94⟩,⟨21,24⟩,⟨31,1920000000000000011376⟩,⟨1,799016681299385430586⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨21,24⟩,⟨31,1920000000000000011376⟩,⟨1,799016681299385430586⟩,⟨479,999999999999999999⟩] := by
  have e42035 : Deny 5 13 b42035 := by
    apply closeAction rule_sound _ _ 64 [0xde32637df54a28b7f8de325fe37da31f88dde37da3238da3255e3688a72f7421f8daf8c9be3738df6be3238df68c7da3,0x88a8c772f72f8c9bddbc30f88c908811de37da3107e232788c972f76f8c9e368c70a22888cb0dfe378c7778df68c87f8,0xbe3278bddbdd7ca54a7c3e2f88a778df6bc8e231e375f2b854a75f2af0e326f8c72e326325cbdcbe326f76325f88a7ef,0x2e372f8cb7788c953888a538be22af76f8c3bdfe378c9088087e232788c972f8dcbe3278da31dcbe3087e3622372f8dc,0x72f8c9e2f8dcbe3278bdcbe326f087da31ef72f8c9bdcbe32768dcbe32f68dcbe32c21f68dcbe32c222372f8cb8dcbe3,0x82]
    decide +kernel
  exact e42035
end OMA.Blocks5_13_245212.S42035
