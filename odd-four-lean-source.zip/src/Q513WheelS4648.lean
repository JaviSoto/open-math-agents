import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S4648
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b4648 : Box := ![⟨15,22⟩,⟨15,30⟩,⟨5,10⟩,⟨3,1465507246376811602925⟩,⟨29,47⟩]
theorem deny5_13 : Deny 5 13 ![⟨15,22⟩,⟨15,30⟩,⟨5,10⟩,⟨3,1465507246376811602925⟩,⟨29,47⟩] := by
  have e4648 : Deny 5 13 b4648 := by
    apply closeAction rule_sound _ _ 64 [0xda3235087df68c40c38c90e32430e32232030c90f72430f8df61f620a0c3e37da31c3e378c90f8df68c8de31e310be23,0xc3e378c90f8df6d631c3e37]
    decide +kernel
  exact e4648
end OMA.Blocks5_13_245212.S4648
