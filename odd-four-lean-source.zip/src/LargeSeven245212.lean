import LargeChecker245212

/-! Exact large-prime arithmetic certificate from large_last_245212.py. -/
namespace OMA.Large245212
private def bp7x1 : B := ![⟨1,some 3⟩,⟨1,none⟩,⟨1,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x1 : Deny 1000000000000000000 7 bp7x1 :=
  sound (by decide) (by decide) 2 2 (tail:=0) (by decide +kernel)
private def bp7x4 : B := ![⟨4,none⟩,⟨1,none⟩,⟨1,none⟩]
private def bp7x5 : B := ![⟨4,none⟩,⟨1,some 3⟩,⟨1,none⟩]
private def bp7x6 : B := ![⟨4,some 9⟩,⟨1,some 3⟩,⟨1,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x6 : Deny 1000000000000000000 7 bp7x6 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x7 : B := ![⟨10,none⟩,⟨1,some 3⟩,⟨1,none⟩]
private def bp7x8 : B := ![⟨10,none⟩,⟨1,some 3⟩,⟨1,some 3⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x8 : Deny 1000000000000000000 7 bp7x8 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x9 : B := ![⟨10,none⟩,⟨1,some 3⟩,⟨4,none⟩]
private def bp7x10 : B := ![⟨10,none⟩,⟨1,some 1⟩,⟨4,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x10 : Deny 1000000000000000000 7 bp7x10 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x11 : B := ![⟨10,none⟩,⟨2,some 3⟩,⟨4,none⟩]
private def bp7x12 : B := ![⟨10,some 21⟩,⟨2,some 3⟩,⟨4,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x12 : Deny 1000000000000000000 7 bp7x12 :=
  sound (by decide) (by decide) 19 348125124684521755609490311241395566883347 (tail:=0) (by decide +kernel)
private def bp7x89 : B := ![⟨22,none⟩,⟨2,some 3⟩,⟨4,none⟩]
private def bp7x90 : B := ![⟨22,none⟩,⟨2,some 3⟩,⟨4,some 9⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x90 : Deny 1000000000000000000 7 bp7x90 :=
  sound (by decide) (by decide) 19 437590918020134875709605246735920263637171891770914098747069217 (tail:=0) (by decide +kernel)
private def bp7x203 : B := ![⟨22,none⟩,⟨2,some 3⟩,⟨10,none⟩]
private def bp7x204 : B := ![⟨22,some 45⟩,⟨2,some 3⟩,⟨10,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x204 : Deny 1000000000000000000 7 bp7x204 :=
  sound (by decide) (by decide) 14 1558097095929717096477193612472295186938665121649519602540087118321216833477839418488460146 (tail:=0) (by decide +kernel)
private def bp7x363 : B := ![⟨46,none⟩,⟨2,some 3⟩,⟨10,none⟩]
private def bp7x364 : B := ![⟨46,none⟩,⟨2,some 2⟩,⟨10,none⟩]
private def bp7x365 : B := ![⟨46,none⟩,⟨2,some 2⟩,⟨10,some 21⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x365 : Deny 1000000000000000000 7 bp7x365 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x366 : B := ![⟨46,none⟩,⟨2,some 2⟩,⟨22,none⟩]
private def bp7x367 : B := ![⟨46,some 93⟩,⟨2,some 2⟩,⟨22,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x367 : Deny 1000000000000000000 7 bp7x367 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x368 : B := ![⟨94,none⟩,⟨2,some 2⟩,⟨22,none⟩]
private def bp7x369 : B := ![⟨94,none⟩,⟨2,some 2⟩,⟨22,some 45⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x369 : Deny 1000000000000000000 7 bp7x369 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x370 : B := ![⟨94,none⟩,⟨2,some 2⟩,⟨46,none⟩]
private def bp7x371 : B := ![⟨94,some 189⟩,⟨2,some 2⟩,⟨46,none⟩]
private def bp7x372 : B := ![⟨94,some 189⟩,⟨2,some 2⟩,⟨46,some 93⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x372 : Deny 1000000000000000000 7 bp7x372 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x373 : B := ![⟨94,some 189⟩,⟨2,some 2⟩,⟨94,none⟩]
private def bp7x374 : B := ![⟨94,some 125⟩,⟨2,some 2⟩,⟨94,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x374 : Deny 1000000000000000000 7 bp7x374 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x375 : B := ![⟨126,some 189⟩,⟨2,some 2⟩,⟨94,none⟩]
private def bp7x376 : B := ![⟨126,some 189⟩,⟨2,some 2⟩,⟨94,some 189⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x376 : Deny 1000000000000000000 7 bp7x376 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x377 : B := ![⟨126,some 189⟩,⟨2,some 2⟩,⟨190,none⟩]
private def bp7x378 : B := ![⟨126,some 151⟩,⟨2,some 2⟩,⟨190,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x378 : Deny 1000000000000000000 7 bp7x378 :=
  sound (by decide) (by decide) 27 39789850035605221556824393974825920426244404065852349462829888974601227997387117868807771979631354163644279576806993366815507 (tail:=0) (by decide +kernel)
private def bp7x593 : B := ![⟨152,some 189⟩,⟨2,some 2⟩,⟨190,none⟩]
private def bp7x594 : B := ![⟨152,some 189⟩,⟨2,some 2⟩,⟨190,some 381⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x594 : Deny 1000000000000000000 7 bp7x594 :=
  sound (by decide) (by decide) 16 633534167611339095582889415573339302984703539382831630937056999223141517835163760406011400681051393197878913918351028828782990834618986662743153 (tail:=0) (by decide +kernel)
private def bp7x841 : B := ![⟨152,some 189⟩,⟨2,some 2⟩,⟨382,none⟩]
private def bp7x842 : B := ![⟨152,some 168⟩,⟨2,some 2⟩,⟨382,none⟩]
private def bp7x843 : B := ![⟨152,some 168⟩,⟨2,some 2⟩,⟨382,some 765⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x843 : Deny 1000000000000000000 7 bp7x843 :=
  sound (by decide) (by decide) 15 505508076513544477032919635501009870803032295748008346977735350734979743971440040619301790374380953715089421868845661703281 (tail:=0) (by decide +kernel)
private def bp7x1054 : B := ![⟨152,some 168⟩,⟨2,some 2⟩,⟨766,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x1054 : Deny 1000000000000000000 7 bp7x1054 :=
  sound (by decide) (by decide) 19 11820772455675699963571836257934539226499531463707084460051641500385589452469118699219430779822133309186401880197276851021387596803953256043807165902975331737017171231687901 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x842 : Deny 1000000000000000000 7 bp7x842 := by
  apply split bp7x842 2
  · rw [show leftB bp7x842 2=bp7x843 by funext i; fin_cases i <;> rfl]; exact p7x843
  · rw [show rightB bp7x842 2=bp7x1054 by funext i; fin_cases i <;> rfl]; exact p7x1054
private def bp7x1349 : B := ![⟨169,some 189⟩,⟨2,some 2⟩,⟨382,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x1349 : Deny 1000000000000000000 7 bp7x1349 :=
  sound (by decide) (by decide) 15 69073189823581560714318255443939899255 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x841 : Deny 1000000000000000000 7 bp7x841 := by
  apply split bp7x841 0
  · rw [show leftB bp7x841 0=bp7x842 by funext i; fin_cases i <;> rfl]; exact p7x842
  · rw [show rightB bp7x841 0=bp7x1349 by funext i; fin_cases i <;> rfl]; exact p7x1349
set_option maxRecDepth 100000 in
private theorem p7x593 : Deny 1000000000000000000 7 bp7x593 := by
  apply split bp7x593 2
  · rw [show leftB bp7x593 2=bp7x594 by funext i; fin_cases i <;> rfl]; exact p7x594
  · rw [show rightB bp7x593 2=bp7x841 by funext i; fin_cases i <;> rfl]; exact p7x841
set_option maxRecDepth 100000 in
private theorem p7x377 : Deny 1000000000000000000 7 bp7x377 := by
  apply split bp7x377 0
  · rw [show leftB bp7x377 0=bp7x378 by funext i; fin_cases i <;> rfl]; exact p7x378
  · rw [show rightB bp7x377 0=bp7x593 by funext i; fin_cases i <;> rfl]; exact p7x593
set_option maxRecDepth 100000 in
private theorem p7x375 : Deny 1000000000000000000 7 bp7x375 := by
  apply split bp7x375 2
  · rw [show leftB bp7x375 2=bp7x376 by funext i; fin_cases i <;> rfl]; exact p7x376
  · rw [show rightB bp7x375 2=bp7x377 by funext i; fin_cases i <;> rfl]; exact p7x377
set_option maxRecDepth 100000 in
private theorem p7x373 : Deny 1000000000000000000 7 bp7x373 := by
  apply split bp7x373 0
  · rw [show leftB bp7x373 0=bp7x374 by funext i; fin_cases i <;> rfl]; exact p7x374
  · rw [show rightB bp7x373 0=bp7x375 by funext i; fin_cases i <;> rfl]; exact p7x375
set_option maxRecDepth 100000 in
private theorem p7x371 : Deny 1000000000000000000 7 bp7x371 := by
  apply split bp7x371 2
  · rw [show leftB bp7x371 2=bp7x372 by funext i; fin_cases i <;> rfl]; exact p7x372
  · rw [show rightB bp7x371 2=bp7x373 by funext i; fin_cases i <;> rfl]; exact p7x373
private def bp7x1424 : B := ![⟨190,none⟩,⟨2,some 2⟩,⟨46,none⟩]
private def bp7x1425 : B := ![⟨190,none⟩,⟨2,some 2⟩,⟨46,some 93⟩]
private def bp7x1426 : B := ![⟨190,some 381⟩,⟨2,some 2⟩,⟨46,some 93⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x1426 : Deny 1000000000000000000 7 bp7x1426 :=
  sound (by decide) (by decide) 17 156225044640168005756796662308779955780351162190479691173268996508760596844206188074068541277763327693587 (tail:=0) (by decide +kernel)
private def bp7x1607 : B := ![⟨382,none⟩,⟨2,some 2⟩,⟨46,some 93⟩]
private def bp7x1608 : B := ![⟨382,none⟩,⟨2,some 2⟩,⟨46,some 61⟩]
private def bp7x1609 : B := ![⟨382,some 765⟩,⟨2,some 2⟩,⟨46,some 61⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x1609 : Deny 1000000000000000000 7 bp7x1609 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x1610 : B := ![⟨766,none⟩,⟨2,some 2⟩,⟨46,some 61⟩]
private def bp7x1611 : B := ![⟨766,none⟩,⟨2,some 2⟩,⟨46,some 52⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x1611 : Deny 1000000000000000000 7 bp7x1611 :=
  sound (by decide) (by decide) 21 14243261768259240021603039163103205509384866916889859714280580118404080519671898260120635778035834970874613735015751883401835183361329 (tail:=0) (by decide +kernel)
private def bp7x1842 : B := ![⟨766,none⟩,⟨2,some 2⟩,⟨53,some 61⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x1842 : Deny 1000000000000000000 7 bp7x1842 :=
  sound (by decide) (by decide) 17 1223943793804438948949340461478392621780509031411437173610610025367908609017840602340826181184205147911150752750779599811019479387148122854677608204555677199141515549 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x1610 : Deny 1000000000000000000 7 bp7x1610 := by
  apply split bp7x1610 2
  · rw [show leftB bp7x1610 2=bp7x1611 by funext i; fin_cases i <;> rfl]; exact p7x1611
  · rw [show rightB bp7x1610 2=bp7x1842 by funext i; fin_cases i <;> rfl]; exact p7x1842
set_option maxRecDepth 100000 in
private theorem p7x1608 : Deny 1000000000000000000 7 bp7x1608 := by
  apply split bp7x1608 0
  · rw [show leftB bp7x1608 0=bp7x1609 by funext i; fin_cases i <;> rfl]; exact p7x1609
  · rw [show rightB bp7x1608 0=bp7x1610 by funext i; fin_cases i <;> rfl]; exact p7x1610
private def bp7x2129 : B := ![⟨382,none⟩,⟨2,some 2⟩,⟨62,some 93⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x2129 : Deny 1000000000000000000 7 bp7x2129 :=
  sound (by decide) (by decide) 17 96305429621891620346637392318511359409037145677997980963308422555110613662530552414788403676442264082040132828604158075298822945019040243074557009997305728410616432553280362337072702394397880952646909203778281558623453 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x1607 : Deny 1000000000000000000 7 bp7x1607 := by
  apply split bp7x1607 2
  · rw [show leftB bp7x1607 2=bp7x1608 by funext i; fin_cases i <;> rfl]; exact p7x1608
  · rw [show rightB bp7x1607 2=bp7x2129 by funext i; fin_cases i <;> rfl]; exact p7x2129
set_option maxRecDepth 100000 in
private theorem p7x1425 : Deny 1000000000000000000 7 bp7x1425 := by
  apply split bp7x1425 0
  · rw [show leftB bp7x1425 0=bp7x1426 by funext i; fin_cases i <;> rfl]; exact p7x1426
  · rw [show rightB bp7x1425 0=bp7x1607 by funext i; fin_cases i <;> rfl]; exact p7x1607
private def bp7x2504 : B := ![⟨190,none⟩,⟨2,some 2⟩,⟨94,none⟩]
private def bp7x2505 : B := ![⟨190,some 381⟩,⟨2,some 2⟩,⟨94,none⟩]
private def bp7x2506 : B := ![⟨190,some 381⟩,⟨2,some 2⟩,⟨94,some 189⟩]
private def bp7x2507 : B := ![⟨190,some 253⟩,⟨2,some 2⟩,⟨94,some 189⟩]
private def bp7x2508 : B := ![⟨190,some 253⟩,⟨2,some 2⟩,⟨94,some 125⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x2508 : Deny 1000000000000000000 7 bp7x2508 :=
  sound (by decide) (by decide) 13 529436564365240410648881 (tail:=0) (by decide +kernel)
private def bp7x2551 : B := ![⟨190,some 253⟩,⟨2,some 2⟩,⟨126,some 189⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x2551 : Deny 1000000000000000000 7 bp7x2551 :=
  sound (by decide) (by decide) 14 278100806588828477424009755857615427973126688386799263539225677420771755833795741193277026427993573907574437551420861203431049328168121846144892210906298082395600456286190407920228565600235314688273954315341 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x2507 : Deny 1000000000000000000 7 bp7x2507 := by
  apply split bp7x2507 2
  · rw [show leftB bp7x2507 2=bp7x2508 by funext i; fin_cases i <;> rfl]; exact p7x2508
  · rw [show rightB bp7x2507 2=bp7x2551 by funext i; fin_cases i <;> rfl]; exact p7x2551
private def bp7x2904 : B := ![⟨254,some 381⟩,⟨2,some 2⟩,⟨94,some 189⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x2904 : Deny 1000000000000000000 7 bp7x2904 :=
  sound (by decide) (by decide) 15 88511233415714268498816490965730956423956271527343650858835596342622751518031725693997453938976507385799613985755728132890989663357299849281075116251123120368979199335543 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x2506 : Deny 1000000000000000000 7 bp7x2506 := by
  apply split bp7x2506 0
  · rw [show leftB bp7x2506 0=bp7x2507 by funext i; fin_cases i <;> rfl]; exact p7x2507
  · rw [show rightB bp7x2506 0=bp7x2904 by funext i; fin_cases i <;> rfl]; exact p7x2904
private def bp7x3199 : B := ![⟨190,some 381⟩,⟨2,some 2⟩,⟨190,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x3199 : Deny 1000000000000000000 7 bp7x3199 :=
  sound (by decide) (by decide) 16 122846148997683172288249715925874161339374742092173723157470145911094428188267994451074525 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x2505 : Deny 1000000000000000000 7 bp7x2505 := by
  apply split bp7x2505 2
  · rw [show leftB bp7x2505 2=bp7x2506 by funext i; fin_cases i <;> rfl]; exact p7x2506
  · rw [show rightB bp7x2505 2=bp7x3199 by funext i; fin_cases i <;> rfl]; exact p7x3199
private def bp7x3360 : B := ![⟨382,none⟩,⟨2,some 2⟩,⟨94,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x3360 : Deny 1000000000000000000 7 bp7x3360 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x2504 : Deny 1000000000000000000 7 bp7x2504 := by
  apply split bp7x2504 0
  · rw [show leftB bp7x2504 0=bp7x2505 by funext i; fin_cases i <;> rfl]; exact p7x2505
  · rw [show rightB bp7x2504 0=bp7x3360 by funext i; fin_cases i <;> rfl]; exact p7x3360
set_option maxRecDepth 100000 in
private theorem p7x1424 : Deny 1000000000000000000 7 bp7x1424 := by
  apply split bp7x1424 2
  · rw [show leftB bp7x1424 2=bp7x1425 by funext i; fin_cases i <;> rfl]; exact p7x1425
  · rw [show rightB bp7x1424 2=bp7x2504 by funext i; fin_cases i <;> rfl]; exact p7x2504
set_option maxRecDepth 100000 in
private theorem p7x370 : Deny 1000000000000000000 7 bp7x370 := by
  apply split bp7x370 0
  · rw [show leftB bp7x370 0=bp7x371 by funext i; fin_cases i <;> rfl]; exact p7x371
  · rw [show rightB bp7x370 0=bp7x1424 by funext i; fin_cases i <;> rfl]; exact p7x1424
set_option maxRecDepth 100000 in
private theorem p7x368 : Deny 1000000000000000000 7 bp7x368 := by
  apply split bp7x368 2
  · rw [show leftB bp7x368 2=bp7x369 by funext i; fin_cases i <;> rfl]; exact p7x369
  · rw [show rightB bp7x368 2=bp7x370 by funext i; fin_cases i <;> rfl]; exact p7x370
set_option maxRecDepth 100000 in
private theorem p7x366 : Deny 1000000000000000000 7 bp7x366 := by
  apply split bp7x366 0
  · rw [show leftB bp7x366 0=bp7x367 by funext i; fin_cases i <;> rfl]; exact p7x367
  · rw [show rightB bp7x366 0=bp7x368 by funext i; fin_cases i <;> rfl]; exact p7x368
set_option maxRecDepth 100000 in
private theorem p7x364 : Deny 1000000000000000000 7 bp7x364 := by
  apply split bp7x364 2
  · rw [show leftB bp7x364 2=bp7x365 by funext i; fin_cases i <;> rfl]; exact p7x365
  · rw [show rightB bp7x364 2=bp7x366 by funext i; fin_cases i <;> rfl]; exact p7x366
private def bp7x3361 : B := ![⟨46,none⟩,⟨3,some 3⟩,⟨10,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x3361 : Deny 1000000000000000000 7 bp7x3361 :=
  sound (by decide) (by decide) 11 1341303 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x363 : Deny 1000000000000000000 7 bp7x363 := by
  apply split bp7x363 1
  · rw [show leftB bp7x363 1=bp7x364 by funext i; fin_cases i <;> rfl]; exact p7x364
  · rw [show rightB bp7x363 1=bp7x3361 by funext i; fin_cases i <;> rfl]; exact p7x3361
set_option maxRecDepth 100000 in
private theorem p7x203 : Deny 1000000000000000000 7 bp7x203 := by
  apply split bp7x203 0
  · rw [show leftB bp7x203 0=bp7x204 by funext i; fin_cases i <;> rfl]; exact p7x204
  · rw [show rightB bp7x203 0=bp7x363 by funext i; fin_cases i <;> rfl]; exact p7x363
set_option maxRecDepth 100000 in
private theorem p7x89 : Deny 1000000000000000000 7 bp7x89 := by
  apply split bp7x89 2
  · rw [show leftB bp7x89 2=bp7x90 by funext i; fin_cases i <;> rfl]; exact p7x90
  · rw [show rightB bp7x89 2=bp7x203 by funext i; fin_cases i <;> rfl]; exact p7x203
set_option maxRecDepth 100000 in
private theorem p7x11 : Deny 1000000000000000000 7 bp7x11 := by
  apply split bp7x11 0
  · rw [show leftB bp7x11 0=bp7x12 by funext i; fin_cases i <;> rfl]; exact p7x12
  · rw [show rightB bp7x11 0=bp7x89 by funext i; fin_cases i <;> rfl]; exact p7x89
set_option maxRecDepth 100000 in
private theorem p7x9 : Deny 1000000000000000000 7 bp7x9 := by
  apply split bp7x9 1
  · rw [show leftB bp7x9 1=bp7x10 by funext i; fin_cases i <;> rfl]; exact p7x10
  · rw [show rightB bp7x9 1=bp7x11 by funext i; fin_cases i <;> rfl]; exact p7x11
set_option maxRecDepth 100000 in
private theorem p7x7 : Deny 1000000000000000000 7 bp7x7 := by
  apply split bp7x7 2
  · rw [show leftB bp7x7 2=bp7x8 by funext i; fin_cases i <;> rfl]; exact p7x8
  · rw [show rightB bp7x7 2=bp7x9 by funext i; fin_cases i <;> rfl]; exact p7x9
set_option maxRecDepth 100000 in
private theorem p7x5 : Deny 1000000000000000000 7 bp7x5 := by
  apply split bp7x5 0
  · rw [show leftB bp7x5 0=bp7x6 by funext i; fin_cases i <;> rfl]; exact p7x6
  · rw [show rightB bp7x5 0=bp7x7 by funext i; fin_cases i <;> rfl]; exact p7x7
private def bp7x3382 : B := ![⟨4,none⟩,⟨4,none⟩,⟨1,none⟩]
private def bp7x3383 : B := ![⟨4,some 9⟩,⟨4,none⟩,⟨1,none⟩]
private def bp7x3384 : B := ![⟨4,some 9⟩,⟨4,none⟩,⟨1,some 3⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x3384 : Deny 1000000000000000000 7 bp7x3384 :=
  sound (by decide) (by decide) 3 18 (tail:=0) (by decide +kernel)
private def bp7x3389 : B := ![⟨4,some 9⟩,⟨4,none⟩,⟨4,none⟩]
private def bp7x3390 : B := ![⟨4,some 5⟩,⟨4,none⟩,⟨4,none⟩]
private def bp7x3391 : B := ![⟨4,some 5⟩,⟨4,some 9⟩,⟨4,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x3391 : Deny 1000000000000000000 7 bp7x3391 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x3392 : B := ![⟨4,some 5⟩,⟨10,none⟩,⟨4,none⟩]
private def bp7x3393 : B := ![⟨4,some 5⟩,⟨10,none⟩,⟨4,some 9⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x3393 : Deny 1000000000000000000 7 bp7x3393 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x3394 : B := ![⟨4,some 5⟩,⟨10,none⟩,⟨10,none⟩]
private def bp7x3395 : B := ![⟨4,some 5⟩,⟨10,some 21⟩,⟨10,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x3395 : Deny 1000000000000000000 7 bp7x3395 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x3396 : B := ![⟨4,some 5⟩,⟨22,none⟩,⟨10,none⟩]
private def bp7x3397 : B := ![⟨4,some 4⟩,⟨22,none⟩,⟨10,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x3397 : Deny 1000000000000000000 7 bp7x3397 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x3398 : B := ![⟨5,some 5⟩,⟨22,none⟩,⟨10,none⟩]
private def bp7x3399 : B := ![⟨5,some 5⟩,⟨22,none⟩,⟨10,some 21⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x3399 : Deny 1000000000000000000 7 bp7x3399 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x3400 : B := ![⟨5,some 5⟩,⟨22,none⟩,⟨22,none⟩]
private def bp7x3401 : B := ![⟨5,some 5⟩,⟨22,some 45⟩,⟨22,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x3401 : Deny 1000000000000000000 7 bp7x3401 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x3402 : B := ![⟨5,some 5⟩,⟨46,none⟩,⟨22,none⟩]
private def bp7x3403 : B := ![⟨5,some 5⟩,⟨46,none⟩,⟨22,some 45⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x3403 : Deny 1000000000000000000 7 bp7x3403 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x3404 : B := ![⟨5,some 5⟩,⟨46,none⟩,⟨46,none⟩]
private def bp7x3405 : B := ![⟨5,some 5⟩,⟨46,some 93⟩,⟨46,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x3405 : Deny 1000000000000000000 7 bp7x3405 :=
  sound (by decide) (by decide) 32 822880066514288764474002072405358039311471642564003871571972425641522111834853917310490714636116421372018067220687791570332804515645850064461227982086935833210091299382354977571 (tail:=0) (by decide +kernel)
private def bp7x3710 : B := ![⟨5,some 5⟩,⟨94,none⟩,⟨46,none⟩]
private def bp7x3711 : B := ![⟨5,some 5⟩,⟨94,none⟩,⟨46,some 93⟩]
private def bp7x3712 : B := ![⟨5,some 5⟩,⟨94,some 189⟩,⟨46,some 93⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x3712 : Deny 1000000000000000000 7 bp7x3712 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x3713 : B := ![⟨5,some 5⟩,⟨190,none⟩,⟨46,some 93⟩]
private def bp7x3714 : B := ![⟨5,some 5⟩,⟨190,none⟩,⟨46,some 61⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x3714 : Deny 1000000000000000000 7 bp7x3714 :=
  sound (by decide) (by decide) 25 195552584974555941553844574099105771998715335117255218 (tail:=0) (by decide +kernel)
private def bp7x3813 : B := ![⟨5,some 5⟩,⟨190,none⟩,⟨62,some 93⟩]
private def bp7x3814 : B := ![⟨5,some 5⟩,⟨190,some 381⟩,⟨62,some 93⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x3814 : Deny 1000000000000000000 7 bp7x3814 :=
  sound (by decide) (by decide) 16 21863189718305632422144120726052037222228768212555176491207303947688088150975044159527971675454769421474154855425166115 (tail:=0) (by decide +kernel)
private def bp7x4019 : B := ![⟨5,some 5⟩,⟨382,none⟩,⟨62,some 93⟩]
private def bp7x4020 : B := ![⟨5,some 5⟩,⟨382,none⟩,⟨62,some 74⟩]
private def bp7x4021 : B := ![⟨5,some 5⟩,⟨382,some 765⟩,⟨62,some 74⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x4021 : Deny 1000000000000000000 7 bp7x4021 :=
  sound (by decide) (by decide) 15 964563891948521531051717026373582093693544827148101560178583368398641595364722915 (tail:=0) (by decide +kernel)
private def bp7x4162 : B := ![⟨5,some 5⟩,⟨766,none⟩,⟨62,some 74⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x4162 : Deny 1000000000000000000 7 bp7x4162 :=
  sound (by decide) (by decide) 18 8018607878468577627084358046815551550679695515541288587938212322770537024411291082609892058809817464180304373358687714642238504786766555096039344699 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x4020 : Deny 1000000000000000000 7 bp7x4020 := by
  apply split bp7x4020 1
  · rw [show leftB bp7x4020 1=bp7x4021 by funext i; fin_cases i <;> rfl]; exact p7x4021
  · rw [show rightB bp7x4020 1=bp7x4162 by funext i; fin_cases i <;> rfl]; exact p7x4162
private def bp7x4417 : B := ![⟨5,some 5⟩,⟨382,none⟩,⟨75,some 93⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x4417 : Deny 1000000000000000000 7 bp7x4417 :=
  sound (by decide) (by decide) 15 12622121431918694995717163195630209088480842256110 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x4019 : Deny 1000000000000000000 7 bp7x4019 := by
  apply split bp7x4019 2
  · rw [show leftB bp7x4019 2=bp7x4020 by funext i; fin_cases i <;> rfl]; exact p7x4020
  · rw [show rightB bp7x4019 2=bp7x4417 by funext i; fin_cases i <;> rfl]; exact p7x4417
set_option maxRecDepth 100000 in
private theorem p7x3813 : Deny 1000000000000000000 7 bp7x3813 := by
  apply split bp7x3813 1
  · rw [show leftB bp7x3813 1=bp7x3814 by funext i; fin_cases i <;> rfl]; exact p7x3814
  · rw [show rightB bp7x3813 1=bp7x4019 by funext i; fin_cases i <;> rfl]; exact p7x4019
set_option maxRecDepth 100000 in
private theorem p7x3713 : Deny 1000000000000000000 7 bp7x3713 := by
  apply split bp7x3713 2
  · rw [show leftB bp7x3713 2=bp7x3714 by funext i; fin_cases i <;> rfl]; exact p7x3714
  · rw [show rightB bp7x3713 2=bp7x3813 by funext i; fin_cases i <;> rfl]; exact p7x3813
set_option maxRecDepth 100000 in
private theorem p7x3711 : Deny 1000000000000000000 7 bp7x3711 := by
  apply split bp7x3711 1
  · rw [show leftB bp7x3711 1=bp7x3712 by funext i; fin_cases i <;> rfl]; exact p7x3712
  · rw [show rightB bp7x3711 1=bp7x3713 by funext i; fin_cases i <;> rfl]; exact p7x3713
private def bp7x4510 : B := ![⟨5,some 5⟩,⟨94,none⟩,⟨94,none⟩]
private def bp7x4511 : B := ![⟨5,some 5⟩,⟨94,some 189⟩,⟨94,none⟩]
private def bp7x4512 : B := ![⟨5,some 5⟩,⟨94,some 189⟩,⟨94,some 189⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x4512 : Deny 1000000000000000000 7 bp7x4512 :=
  sound (by decide) (by decide) 16 1034188506159426900177206764423528552964510003116898470062939623972167083901582555155335990080770204687963500501311422743673195191316725827486861168437137895613978079062946744744700348220553994033277323901481759193992370 (tail:=0) (by decide +kernel)
private def bp7x4885 : B := ![⟨5,some 5⟩,⟨94,some 189⟩,⟨190,none⟩]
private def bp7x4886 : B := ![⟨5,some 5⟩,⟨94,some 125⟩,⟨190,none⟩]
private def bp7x4887 : B := ![⟨5,some 5⟩,⟨94,some 125⟩,⟨190,some 381⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x4887 : Deny 1000000000000000000 7 bp7x4887 :=
  sound (by decide) (by decide) 15 831451800180665916128416396273104835979489455537027999319789547061344691381651600064621386442350927916261923298111512843919995205256786750539689603153235122 (tail:=0) (by decide +kernel)
private def bp7x5154 : B := ![⟨5,some 5⟩,⟨94,some 125⟩,⟨382,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x5154 : Deny 1000000000000000000 7 bp7x5154 :=
  sound (by decide) (by decide) 19 282655273634290572152448514093184567047008590361198606621622231861319849886064825116223984969082554044193117497503570255892174073962750143409181846850149476586142972335839246610817213856291431447589895967213570843265262 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x4886 : Deny 1000000000000000000 7 bp7x4886 := by
  apply split bp7x4886 2
  · rw [show leftB bp7x4886 2=bp7x4887 by funext i; fin_cases i <;> rfl]; exact p7x4887
  · rw [show rightB bp7x4886 2=bp7x5154 by funext i; fin_cases i <;> rfl]; exact p7x5154
private def bp7x5529 : B := ![⟨5,some 5⟩,⟨126,some 189⟩,⟨190,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x5529 : Deny 1000000000000000000 7 bp7x5529 :=
  sound (by decide) (by decide) 15 24417413171514222118719493080773725371577378151252933563 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x4885 : Deny 1000000000000000000 7 bp7x4885 := by
  apply split bp7x4885 1
  · rw [show leftB bp7x4885 1=bp7x4886 by funext i; fin_cases i <;> rfl]; exact p7x4886
  · rw [show rightB bp7x4885 1=bp7x5529 by funext i; fin_cases i <;> rfl]; exact p7x5529
set_option maxRecDepth 100000 in
private theorem p7x4511 : Deny 1000000000000000000 7 bp7x4511 := by
  apply split bp7x4511 2
  · rw [show leftB bp7x4511 2=bp7x4512 by funext i; fin_cases i <;> rfl]; exact p7x4512
  · rw [show rightB bp7x4511 2=bp7x4885 by funext i; fin_cases i <;> rfl]; exact p7x4885
private def bp7x5634 : B := ![⟨5,some 5⟩,⟨190,none⟩,⟨94,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x5634 : Deny 1000000000000000000 7 bp7x5634 :=
  sound (by decide) (by decide) 17 111630362524272665636485359993582636884990148637417961453205079708356048837578014151075663087902375307415410965363060870776519943621333978986658806715 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x4510 : Deny 1000000000000000000 7 bp7x4510 := by
  apply split bp7x4510 1
  · rw [show leftB bp7x4510 1=bp7x4511 by funext i; fin_cases i <;> rfl]; exact p7x4511
  · rw [show rightB bp7x4510 1=bp7x5634 by funext i; fin_cases i <;> rfl]; exact p7x5634
set_option maxRecDepth 100000 in
private theorem p7x3710 : Deny 1000000000000000000 7 bp7x3710 := by
  apply split bp7x3710 2
  · rw [show leftB bp7x3710 2=bp7x3711 by funext i; fin_cases i <;> rfl]; exact p7x3711
  · rw [show rightB bp7x3710 2=bp7x4510 by funext i; fin_cases i <;> rfl]; exact p7x4510
set_option maxRecDepth 100000 in
private theorem p7x3404 : Deny 1000000000000000000 7 bp7x3404 := by
  apply split bp7x3404 1
  · rw [show leftB bp7x3404 1=bp7x3405 by funext i; fin_cases i <;> rfl]; exact p7x3405
  · rw [show rightB bp7x3404 1=bp7x3710 by funext i; fin_cases i <;> rfl]; exact p7x3710
set_option maxRecDepth 100000 in
private theorem p7x3402 : Deny 1000000000000000000 7 bp7x3402 := by
  apply split bp7x3402 2
  · rw [show leftB bp7x3402 2=bp7x3403 by funext i; fin_cases i <;> rfl]; exact p7x3403
  · rw [show rightB bp7x3402 2=bp7x3404 by funext i; fin_cases i <;> rfl]; exact p7x3404
set_option maxRecDepth 100000 in
private theorem p7x3400 : Deny 1000000000000000000 7 bp7x3400 := by
  apply split bp7x3400 1
  · rw [show leftB bp7x3400 1=bp7x3401 by funext i; fin_cases i <;> rfl]; exact p7x3401
  · rw [show rightB bp7x3400 1=bp7x3402 by funext i; fin_cases i <;> rfl]; exact p7x3402
set_option maxRecDepth 100000 in
private theorem p7x3398 : Deny 1000000000000000000 7 bp7x3398 := by
  apply split bp7x3398 2
  · rw [show leftB bp7x3398 2=bp7x3399 by funext i; fin_cases i <;> rfl]; exact p7x3399
  · rw [show rightB bp7x3398 2=bp7x3400 by funext i; fin_cases i <;> rfl]; exact p7x3400
set_option maxRecDepth 100000 in
private theorem p7x3396 : Deny 1000000000000000000 7 bp7x3396 := by
  apply split bp7x3396 0
  · rw [show leftB bp7x3396 0=bp7x3397 by funext i; fin_cases i <;> rfl]; exact p7x3397
  · rw [show rightB bp7x3396 0=bp7x3398 by funext i; fin_cases i <;> rfl]; exact p7x3398
set_option maxRecDepth 100000 in
private theorem p7x3394 : Deny 1000000000000000000 7 bp7x3394 := by
  apply split bp7x3394 1
  · rw [show leftB bp7x3394 1=bp7x3395 by funext i; fin_cases i <;> rfl]; exact p7x3395
  · rw [show rightB bp7x3394 1=bp7x3396 by funext i; fin_cases i <;> rfl]; exact p7x3396
set_option maxRecDepth 100000 in
private theorem p7x3392 : Deny 1000000000000000000 7 bp7x3392 := by
  apply split bp7x3392 2
  · rw [show leftB bp7x3392 2=bp7x3393 by funext i; fin_cases i <;> rfl]; exact p7x3393
  · rw [show rightB bp7x3392 2=bp7x3394 by funext i; fin_cases i <;> rfl]; exact p7x3394
set_option maxRecDepth 100000 in
private theorem p7x3390 : Deny 1000000000000000000 7 bp7x3390 := by
  apply split bp7x3390 1
  · rw [show leftB bp7x3390 1=bp7x3391 by funext i; fin_cases i <;> rfl]; exact p7x3391
  · rw [show rightB bp7x3390 1=bp7x3392 by funext i; fin_cases i <;> rfl]; exact p7x3392
private def bp7x5895 : B := ![⟨6,some 9⟩,⟨4,none⟩,⟨4,none⟩]
private def bp7x5896 : B := ![⟨6,some 9⟩,⟨4,some 9⟩,⟨4,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x5896 : Deny 1000000000000000000 7 bp7x5896 :=
  sound (by decide) (by decide) 20 114378720596353245186608931995747078153723177922925752402225431294565373218083 (tail:=0) (by decide +kernel)
private def bp7x6031 : B := ![⟨6,some 9⟩,⟨10,none⟩,⟨4,none⟩]
private def bp7x6032 : B := ![⟨6,some 9⟩,⟨10,none⟩,⟨4,some 9⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x6032 : Deny 1000000000000000000 7 bp7x6032 :=
  sound (by decide) (by decide) 19 5648974216979365473514966766879159145205925970302494397613642485578988600990543631366930844219849180489365958264058448738502 (tail:=0) (by decide +kernel)
private def bp7x6245 : B := ![⟨6,some 9⟩,⟨10,none⟩,⟨10,none⟩]
private def bp7x6246 : B := ![⟨6,some 9⟩,⟨10,some 21⟩,⟨10,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x6246 : Deny 1000000000000000000 7 bp7x6246 :=
  sound (by decide) (by decide) 19 37849213102717346189210830491057853889456263031836251619592119715869801131548986538488222678643407957109207330460949717813837011064206381414639964589165 (tail:=0) (by decide +kernel)
private def bp7x6505 : B := ![⟨6,some 9⟩,⟨22,none⟩,⟨10,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x6505 : Deny 1000000000000000000 7 bp7x6505 :=
  sound (by decide) (by decide) 22 11865614248219443361379330834888718549687055706881693030990180007749819640730664957662815205843111901677094609511301696393524369392173283516891498659513890414942430061 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x6245 : Deny 1000000000000000000 7 bp7x6245 := by
  apply split bp7x6245 1
  · rw [show leftB bp7x6245 1=bp7x6246 by funext i; fin_cases i <;> rfl]; exact p7x6246
  · rw [show rightB bp7x6245 1=bp7x6505 by funext i; fin_cases i <;> rfl]; exact p7x6505
set_option maxRecDepth 100000 in
private theorem p7x6031 : Deny 1000000000000000000 7 bp7x6031 := by
  apply split bp7x6031 2
  · rw [show leftB bp7x6031 2=bp7x6032 by funext i; fin_cases i <;> rfl]; exact p7x6032
  · rw [show rightB bp7x6031 2=bp7x6245 by funext i; fin_cases i <;> rfl]; exact p7x6245
set_option maxRecDepth 100000 in
private theorem p7x5895 : Deny 1000000000000000000 7 bp7x5895 := by
  apply split bp7x5895 1
  · rw [show leftB bp7x5895 1=bp7x5896 by funext i; fin_cases i <;> rfl]; exact p7x5896
  · rw [show rightB bp7x5895 1=bp7x6031 by funext i; fin_cases i <;> rfl]; exact p7x6031
set_option maxRecDepth 100000 in
private theorem p7x3389 : Deny 1000000000000000000 7 bp7x3389 := by
  apply split bp7x3389 0
  · rw [show leftB bp7x3389 0=bp7x3390 by funext i; fin_cases i <;> rfl]; exact p7x3390
  · rw [show rightB bp7x3389 0=bp7x5895 by funext i; fin_cases i <;> rfl]; exact p7x5895
set_option maxRecDepth 100000 in
private theorem p7x3383 : Deny 1000000000000000000 7 bp7x3383 := by
  apply split bp7x3383 2
  · rw [show leftB bp7x3383 2=bp7x3384 by funext i; fin_cases i <;> rfl]; exact p7x3384
  · rw [show rightB bp7x3383 2=bp7x3389 by funext i; fin_cases i <;> rfl]; exact p7x3389
private def bp7x6792 : B := ![⟨10,none⟩,⟨4,none⟩,⟨1,none⟩]
private def bp7x6793 : B := ![⟨10,none⟩,⟨4,none⟩,⟨1,some 3⟩]
private def bp7x6794 : B := ![⟨10,none⟩,⟨4,some 9⟩,⟨1,some 3⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x6794 : Deny 1000000000000000000 7 bp7x6794 :=
  sound (by decide) (by decide) 21 2513739694968616508172654909201027615617087941067089187923497479487476297600132598607872496674202887828899984098445 (tail:=0) (by decide +kernel)
private def bp7x6993 : B := ![⟨10,none⟩,⟨10,none⟩,⟨1,some 3⟩]
private def bp7x6994 : B := ![⟨10,some 21⟩,⟨10,none⟩,⟨1,some 3⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x6994 : Deny 1000000000000000000 7 bp7x6994 :=
  sound (by decide) (by decide) 20 529364597235340412859983396747396551834516421926712783684376988895746234477467966542318124586877864754553452082287280016557595439909773389786851967742292683183733578012539020714851 (tail:=0) (by decide +kernel)
private def bp7x7301 : B := ![⟨22,none⟩,⟨10,none⟩,⟨1,some 3⟩]
private def bp7x7302 : B := ![⟨22,none⟩,⟨10,none⟩,⟨1,some 1⟩]
private def bp7x7303 : B := ![⟨22,none⟩,⟨10,some 21⟩,⟨1,some 1⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x7303 : Deny 1000000000000000000 7 bp7x7303 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x7304 : B := ![⟨22,none⟩,⟨22,none⟩,⟨1,some 1⟩]
private def bp7x7305 : B := ![⟨22,some 45⟩,⟨22,none⟩,⟨1,some 1⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x7305 : Deny 1000000000000000000 7 bp7x7305 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x7306 : B := ![⟨46,none⟩,⟨22,none⟩,⟨1,some 1⟩]
private def bp7x7307 : B := ![⟨46,none⟩,⟨22,some 45⟩,⟨1,some 1⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x7307 : Deny 1000000000000000000 7 bp7x7307 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x7308 : B := ![⟨46,none⟩,⟨46,none⟩,⟨1,some 1⟩]
private def bp7x7309 : B := ![⟨46,some 93⟩,⟨46,none⟩,⟨1,some 1⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x7309 : Deny 1000000000000000000 7 bp7x7309 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x7310 : B := ![⟨94,none⟩,⟨46,none⟩,⟨1,some 1⟩]
private def bp7x7311 : B := ![⟨94,none⟩,⟨46,some 93⟩,⟨1,some 1⟩]
private def bp7x7312 : B := ![⟨94,some 189⟩,⟨46,some 93⟩,⟨1,some 1⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x7312 : Deny 1000000000000000000 7 bp7x7312 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x7313 : B := ![⟨190,none⟩,⟨46,some 93⟩,⟨1,some 1⟩]
private def bp7x7314 : B := ![⟨190,none⟩,⟨46,some 61⟩,⟨1,some 1⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x7314 : Deny 1000000000000000000 7 bp7x7314 :=
  sound (by decide) (by decide) 24 1342424161440391153838416447306917538663090978108466031747013960836594761088414684983443293404225248218239715645504166933109692949951435730899276251810414484077549451861996643840184138440442449447477895361761809 (tail:=0) (by decide +kernel)
private def bp7x7675 : B := ![⟨190,none⟩,⟨62,some 93⟩,⟨1,some 1⟩]
private def bp7x7676 : B := ![⟨190,some 381⟩,⟨62,some 93⟩,⟨1,some 1⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x7676 : Deny 1000000000000000000 7 bp7x7676 :=
  sound (by decide) (by decide) 16 3948466785104265552681033560819675434354751706345458659531341820779592309587890129000910881240942079386212345246077282643809953925409 (tail:=0) (by decide +kernel)
private def bp7x7905 : B := ![⟨382,none⟩,⟨62,some 93⟩,⟨1,some 1⟩]
private def bp7x7906 : B := ![⟨382,some 765⟩,⟨62,some 93⟩,⟨1,some 1⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x7906 : Deny 1000000000000000000 7 bp7x7906 :=
  sound (by decide) (by decide) 16 21291275319168999365618484092456665499021802184190712426439015357529176012241162825381495433173950656598584857591550025070781875845043193479176862639495575692173074646309142077734 (tail:=0) (by decide +kernel)
private def bp7x8213 : B := ![⟨766,none⟩,⟨62,some 93⟩,⟨1,some 1⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x8213 : Deny 1000000000000000000 7 bp7x8213 :=
  sound (by decide) (by decide) 17 31808494170589684328668617574765019213088086112151142 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x7905 : Deny 1000000000000000000 7 bp7x7905 := by
  apply split bp7x7905 0
  · rw [show leftB bp7x7905 0=bp7x7906 by funext i; fin_cases i <;> rfl]; exact p7x7906
  · rw [show rightB bp7x7905 0=bp7x8213 by funext i; fin_cases i <;> rfl]; exact p7x8213
set_option maxRecDepth 100000 in
private theorem p7x7675 : Deny 1000000000000000000 7 bp7x7675 := by
  apply split bp7x7675 0
  · rw [show leftB bp7x7675 0=bp7x7676 by funext i; fin_cases i <;> rfl]; exact p7x7676
  · rw [show rightB bp7x7675 0=bp7x7905 by funext i; fin_cases i <;> rfl]; exact p7x7905
set_option maxRecDepth 100000 in
private theorem p7x7313 : Deny 1000000000000000000 7 bp7x7313 := by
  apply split bp7x7313 1
  · rw [show leftB bp7x7313 1=bp7x7314 by funext i; fin_cases i <;> rfl]; exact p7x7314
  · rw [show rightB bp7x7313 1=bp7x7675 by funext i; fin_cases i <;> rfl]; exact p7x7675
set_option maxRecDepth 100000 in
private theorem p7x7311 : Deny 1000000000000000000 7 bp7x7311 := by
  apply split bp7x7311 0
  · rw [show leftB bp7x7311 0=bp7x7312 by funext i; fin_cases i <;> rfl]; exact p7x7312
  · rw [show rightB bp7x7311 0=bp7x7313 by funext i; fin_cases i <;> rfl]; exact p7x7313
private def bp7x8314 : B := ![⟨94,none⟩,⟨94,none⟩,⟨1,some 1⟩]
private def bp7x8315 : B := ![⟨94,some 189⟩,⟨94,none⟩,⟨1,some 1⟩]
private def bp7x8316 : B := ![⟨94,some 189⟩,⟨94,some 189⟩,⟨1,some 1⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x8316 : Deny 1000000000000000000 7 bp7x8316 :=
  sound (by decide) (by decide) 17 38750382944166589301912260358568151411551652903573005243145118785021933351092270335198029370328245124290194275299161055610330229489050295096711288361489482882884007777144235647265 (tail:=0) (by decide +kernel)
private def bp7x8621 : B := ![⟨94,some 189⟩,⟨190,none⟩,⟨1,some 1⟩]
private def bp7x8622 : B := ![⟨94,some 125⟩,⟨190,none⟩,⟨1,some 1⟩]
private def bp7x8623 : B := ![⟨94,some 125⟩,⟨190,some 381⟩,⟨1,some 1⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x8623 : Deny 1000000000000000000 7 bp7x8623 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x8624 : B := ![⟨94,some 125⟩,⟨382,none⟩,⟨1,some 1⟩]
private def bp7x8625 : B := ![⟨94,some 107⟩,⟨382,none⟩,⟨1,some 1⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x8625 : Deny 1000000000000000000 7 bp7x8625 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp7x8626 : B := ![⟨108,some 125⟩,⟨382,none⟩,⟨1,some 1⟩]
private def bp7x8627 : B := ![⟨108,some 125⟩,⟨382,some 765⟩,⟨1,some 1⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x8627 : Deny 1000000000000000000 7 bp7x8627 :=
  sound (by decide) (by decide) 15 229967119298250164008804974629508828874832274490117577379355492071352328481 (tail:=0) (by decide +kernel)
private def bp7x8756 : B := ![⟨108,some 125⟩,⟨766,none⟩,⟨1,some 1⟩]
private def bp7x8757 : B := ![⟨108,some 115⟩,⟨766,none⟩,⟨1,some 1⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x8757 : Deny 1000000000000000000 7 bp7x8757 :=
  sound (by decide) (by decide) 22 135386685227564950244732332136204038735640367235244036519605770717760210090843837583713230201987150729560462956261884948770439985439520574788804598725967141393646722719964349808674322 (tail:=0) (by decide +kernel)
private def bp7x9070 : B := ![⟨116,some 125⟩,⟨766,none⟩,⟨1,some 1⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x9070 : Deny 1000000000000000000 7 bp7x9070 :=
  sound (by decide) (by decide) 16 4910017017327092986519719180635000356058854873477120016608087034999694761692720483054949931855017769138406168678 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x8756 : Deny 1000000000000000000 7 bp7x8756 := by
  apply split bp7x8756 0
  · rw [show leftB bp7x8756 0=bp7x8757 by funext i; fin_cases i <;> rfl]; exact p7x8757
  · rw [show rightB bp7x8756 0=bp7x9070 by funext i; fin_cases i <;> rfl]; exact p7x9070
set_option maxRecDepth 100000 in
private theorem p7x8626 : Deny 1000000000000000000 7 bp7x8626 := by
  apply split bp7x8626 1
  · rw [show leftB bp7x8626 1=bp7x8627 by funext i; fin_cases i <;> rfl]; exact p7x8627
  · rw [show rightB bp7x8626 1=bp7x8756 by funext i; fin_cases i <;> rfl]; exact p7x8756
set_option maxRecDepth 100000 in
private theorem p7x8624 : Deny 1000000000000000000 7 bp7x8624 := by
  apply split bp7x8624 0
  · rw [show leftB bp7x8624 0=bp7x8625 by funext i; fin_cases i <;> rfl]; exact p7x8625
  · rw [show rightB bp7x8624 0=bp7x8626 by funext i; fin_cases i <;> rfl]; exact p7x8626
set_option maxRecDepth 100000 in
private theorem p7x8622 : Deny 1000000000000000000 7 bp7x8622 := by
  apply split bp7x8622 1
  · rw [show leftB bp7x8622 1=bp7x8623 by funext i; fin_cases i <;> rfl]; exact p7x8623
  · rw [show rightB bp7x8622 1=bp7x8624 by funext i; fin_cases i <;> rfl]; exact p7x8624
private def bp7x9267 : B := ![⟨126,some 189⟩,⟨190,none⟩,⟨1,some 1⟩]
private def bp7x9268 : B := ![⟨126,some 189⟩,⟨190,some 381⟩,⟨1,some 1⟩]
private def bp7x9269 : B := ![⟨126,some 151⟩,⟨190,some 381⟩,⟨1,some 1⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x9269 : Deny 1000000000000000000 7 bp7x9269 :=
  sound (by decide) (by decide) 15 647356190353747911791792864843920047846390402054746662034581976627247180585606336077025498187745761763105324329956524911841821882913713975699753671748073749385154274771111468782477590623898786931078 (tail:=0) (by decide +kernel)
private def bp7x9606 : B := ![⟨152,some 189⟩,⟨190,some 381⟩,⟨1,some 1⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x9606 : Deny 1000000000000000000 7 bp7x9606 :=
  sound (by decide) (by decide) 13 56572140858956931920558070341103163352678 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x9268 : Deny 1000000000000000000 7 bp7x9268 := by
  apply split bp7x9268 0
  · rw [show leftB bp7x9268 0=bp7x9269 by funext i; fin_cases i <;> rfl]; exact p7x9269
  · rw [show rightB bp7x9268 0=bp7x9606 by funext i; fin_cases i <;> rfl]; exact p7x9606
private def bp7x9685 : B := ![⟨126,some 189⟩,⟨382,none⟩,⟨1,some 1⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x9685 : Deny 1000000000000000000 7 bp7x9685 :=
  sound (by decide) (by decide) 17 57356595490065035923408133471184615645147491453967122198425325836697 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x9267 : Deny 1000000000000000000 7 bp7x9267 := by
  apply split bp7x9267 1
  · rw [show leftB bp7x9267 1=bp7x9268 by funext i; fin_cases i <;> rfl]; exact p7x9268
  · rw [show rightB bp7x9267 1=bp7x9685 by funext i; fin_cases i <;> rfl]; exact p7x9685
set_option maxRecDepth 100000 in
private theorem p7x8621 : Deny 1000000000000000000 7 bp7x8621 := by
  apply split bp7x8621 0
  · rw [show leftB bp7x8621 0=bp7x8622 by funext i; fin_cases i <;> rfl]; exact p7x8622
  · rw [show rightB bp7x8621 0=bp7x9267 by funext i; fin_cases i <;> rfl]; exact p7x9267
set_option maxRecDepth 100000 in
private theorem p7x8315 : Deny 1000000000000000000 7 bp7x8315 := by
  apply split bp7x8315 1
  · rw [show leftB bp7x8315 1=bp7x8316 by funext i; fin_cases i <;> rfl]; exact p7x8316
  · rw [show rightB bp7x8315 1=bp7x8621 by funext i; fin_cases i <;> rfl]; exact p7x8621
private def bp7x9808 : B := ![⟨190,none⟩,⟨94,none⟩,⟨1,some 1⟩]
private def bp7x9809 : B := ![⟨190,none⟩,⟨94,some 189⟩,⟨1,some 1⟩]
private def bp7x9810 : B := ![⟨190,some 381⟩,⟨94,some 189⟩,⟨1,some 1⟩]
private def bp7x9811 : B := ![⟨190,some 381⟩,⟨94,some 125⟩,⟨1,some 1⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x9811 : Deny 1000000000000000000 7 bp7x9811 :=
  sound (by decide) (by decide) 14 544055878852479461150492264194231373736917312290836725679280358977286218644808022476822212705275807290072425231842252047209990685066029541774746150107880214452820840212333047825196070094752797565541780225493987510565 (tail:=0) (by decide +kernel)
private def bp7x10180 : B := ![⟨190,some 381⟩,⟨126,some 189⟩,⟨1,some 1⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x10180 : Deny 1000000000000000000 7 bp7x10180 :=
  sound (by decide) (by decide) 14 51578661820484700406413797370398084901935705 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x9810 : Deny 1000000000000000000 7 bp7x9810 := by
  apply split bp7x9810 1
  · rw [show leftB bp7x9810 1=bp7x9811 by funext i; fin_cases i <;> rfl]; exact p7x9811
  · rw [show rightB bp7x9810 1=bp7x10180 by funext i; fin_cases i <;> rfl]; exact p7x10180
private def bp7x10263 : B := ![⟨382,none⟩,⟨94,some 189⟩,⟨1,some 1⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x10263 : Deny 1000000000000000000 7 bp7x10263 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x9809 : Deny 1000000000000000000 7 bp7x9809 := by
  apply split bp7x9809 0
  · rw [show leftB bp7x9809 0=bp7x9810 by funext i; fin_cases i <;> rfl]; exact p7x9810
  · rw [show rightB bp7x9809 0=bp7x10263 by funext i; fin_cases i <;> rfl]; exact p7x10263
private def bp7x10264 : B := ![⟨190,none⟩,⟨190,none⟩,⟨1,some 1⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x10264 : Deny 1000000000000000000 7 bp7x10264 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x9808 : Deny 1000000000000000000 7 bp7x9808 := by
  apply split bp7x9808 1
  · rw [show leftB bp7x9808 1=bp7x9809 by funext i; fin_cases i <;> rfl]; exact p7x9809
  · rw [show rightB bp7x9808 1=bp7x10264 by funext i; fin_cases i <;> rfl]; exact p7x10264
set_option maxRecDepth 100000 in
private theorem p7x8314 : Deny 1000000000000000000 7 bp7x8314 := by
  apply split bp7x8314 0
  · rw [show leftB bp7x8314 0=bp7x8315 by funext i; fin_cases i <;> rfl]; exact p7x8315
  · rw [show rightB bp7x8314 0=bp7x9808 by funext i; fin_cases i <;> rfl]; exact p7x9808
set_option maxRecDepth 100000 in
private theorem p7x7310 : Deny 1000000000000000000 7 bp7x7310 := by
  apply split bp7x7310 1
  · rw [show leftB bp7x7310 1=bp7x7311 by funext i; fin_cases i <;> rfl]; exact p7x7311
  · rw [show rightB bp7x7310 1=bp7x8314 by funext i; fin_cases i <;> rfl]; exact p7x8314
set_option maxRecDepth 100000 in
private theorem p7x7308 : Deny 1000000000000000000 7 bp7x7308 := by
  apply split bp7x7308 0
  · rw [show leftB bp7x7308 0=bp7x7309 by funext i; fin_cases i <;> rfl]; exact p7x7309
  · rw [show rightB bp7x7308 0=bp7x7310 by funext i; fin_cases i <;> rfl]; exact p7x7310
set_option maxRecDepth 100000 in
private theorem p7x7306 : Deny 1000000000000000000 7 bp7x7306 := by
  apply split bp7x7306 1
  · rw [show leftB bp7x7306 1=bp7x7307 by funext i; fin_cases i <;> rfl]; exact p7x7307
  · rw [show rightB bp7x7306 1=bp7x7308 by funext i; fin_cases i <;> rfl]; exact p7x7308
set_option maxRecDepth 100000 in
private theorem p7x7304 : Deny 1000000000000000000 7 bp7x7304 := by
  apply split bp7x7304 0
  · rw [show leftB bp7x7304 0=bp7x7305 by funext i; fin_cases i <;> rfl]; exact p7x7305
  · rw [show rightB bp7x7304 0=bp7x7306 by funext i; fin_cases i <;> rfl]; exact p7x7306
set_option maxRecDepth 100000 in
private theorem p7x7302 : Deny 1000000000000000000 7 bp7x7302 := by
  apply split bp7x7302 1
  · rw [show leftB bp7x7302 1=bp7x7303 by funext i; fin_cases i <;> rfl]; exact p7x7303
  · rw [show rightB bp7x7302 1=bp7x7304 by funext i; fin_cases i <;> rfl]; exact p7x7304
private def bp7x10265 : B := ![⟨22,none⟩,⟨10,none⟩,⟨2,some 3⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x10265 : Deny 1000000000000000000 7 bp7x10265 :=
  sound (by decide) (by decide) 13 71142846206484608100402113762640538128003278424496718511809716471728737133826486 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x7301 : Deny 1000000000000000000 7 bp7x7301 := by
  apply split bp7x7301 2
  · rw [show leftB bp7x7301 2=bp7x7302 by funext i; fin_cases i <;> rfl]; exact p7x7302
  · rw [show rightB bp7x7301 2=bp7x10265 by funext i; fin_cases i <;> rfl]; exact p7x10265
set_option maxRecDepth 100000 in
private theorem p7x6993 : Deny 1000000000000000000 7 bp7x6993 := by
  apply split bp7x6993 0
  · rw [show leftB bp7x6993 0=bp7x6994 by funext i; fin_cases i <;> rfl]; exact p7x6994
  · rw [show rightB bp7x6993 0=bp7x7301 by funext i; fin_cases i <;> rfl]; exact p7x7301
set_option maxRecDepth 100000 in
private theorem p7x6793 : Deny 1000000000000000000 7 bp7x6793 := by
  apply split bp7x6793 1
  · rw [show leftB bp7x6793 1=bp7x6794 by funext i; fin_cases i <;> rfl]; exact p7x6794
  · rw [show rightB bp7x6793 1=bp7x6993 by funext i; fin_cases i <;> rfl]; exact p7x6993
private def bp7x10410 : B := ![⟨10,none⟩,⟨4,none⟩,⟨4,none⟩]
private def bp7x10411 : B := ![⟨10,none⟩,⟨4,some 9⟩,⟨4,none⟩]
private def bp7x10412 : B := ![⟨10,some 21⟩,⟨4,some 9⟩,⟨4,none⟩]
private def bp7x10413 : B := ![⟨10,some 21⟩,⟨4,some 9⟩,⟨4,some 9⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x10413 : Deny 1000000000000000000 7 bp7x10413 :=
  sound (by decide) (by decide) 11 27218285888196243955078380993219521248875215504519089115453605473641552947892461887998435468486 (tail:=0) (by decide +kernel)
private def bp7x10576 : B := ![⟨10,some 21⟩,⟨4,some 9⟩,⟨10,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x10576 : Deny 1000000000000000000 7 bp7x10576 :=
  sound (by decide) (by decide) 19 52257171680035204612992618109867765274322412625527920381792551857115905265567687003853014358577095614434794204283551174763143188209790232305715973507190 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x10412 : Deny 1000000000000000000 7 bp7x10412 := by
  apply split bp7x10412 2
  · rw [show leftB bp7x10412 2=bp7x10413 by funext i; fin_cases i <;> rfl]; exact p7x10413
  · rw [show rightB bp7x10412 2=bp7x10576 by funext i; fin_cases i <;> rfl]; exact p7x10576
private def bp7x10839 : B := ![⟨22,none⟩,⟨4,some 9⟩,⟨4,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x10839 : Deny 1000000000000000000 7 bp7x10839 :=
  sound (by decide) (by decide) 15 32642174422030809378030185015951749767125837566140275738191060026500666856098267 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x10411 : Deny 1000000000000000000 7 bp7x10411 := by
  apply split bp7x10411 0
  · rw [show leftB bp7x10411 0=bp7x10412 by funext i; fin_cases i <;> rfl]; exact p7x10412
  · rw [show rightB bp7x10411 0=bp7x10839 by funext i; fin_cases i <;> rfl]; exact p7x10839
private def bp7x10982 : B := ![⟨10,none⟩,⟨10,none⟩,⟨4,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p7x10982 : Deny 1000000000000000000 7 bp7x10982 :=
  sound (by decide) (by decide) 14 16368656584948380708704373562113641429485958051548740147256318548893 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p7x10410 : Deny 1000000000000000000 7 bp7x10410 := by
  apply split bp7x10410 1
  · rw [show leftB bp7x10410 1=bp7x10411 by funext i; fin_cases i <;> rfl]; exact p7x10411
  · rw [show rightB bp7x10410 1=bp7x10982 by funext i; fin_cases i <;> rfl]; exact p7x10982
set_option maxRecDepth 100000 in
private theorem p7x6792 : Deny 1000000000000000000 7 bp7x6792 := by
  apply split bp7x6792 2
  · rw [show leftB bp7x6792 2=bp7x6793 by funext i; fin_cases i <;> rfl]; exact p7x6793
  · rw [show rightB bp7x6792 2=bp7x10410 by funext i; fin_cases i <;> rfl]; exact p7x10410
set_option maxRecDepth 100000 in
private theorem p7x3382 : Deny 1000000000000000000 7 bp7x3382 := by
  apply split bp7x3382 0
  · rw [show leftB bp7x3382 0=bp7x3383 by funext i; fin_cases i <;> rfl]; exact p7x3383
  · rw [show rightB bp7x3382 0=bp7x6792 by funext i; fin_cases i <;> rfl]; exact p7x6792
set_option maxRecDepth 100000 in
private theorem p7x4 : Deny 1000000000000000000 7 bp7x4 := by
  apply split bp7x4 1
  · rw [show leftB bp7x4 1=bp7x5 by funext i; fin_cases i <;> rfl]; exact p7x5
  · rw [show rightB bp7x4 1=bp7x3382 by funext i; fin_cases i <;> rfl]; exact p7x3382
set_option maxRecDepth 100000 in
theorem p7x0 : Deny 1000000000000000000 7 start := by
  apply split start 0
  · rw [show leftB start 0=bp7x1 by funext i; fin_cases i <;> rfl]; exact p7x1
  · rw [show rightB start 0=bp7x4 by funext i; fin_cases i <;> rfl]; exact p7x4
end OMA.Large245212
