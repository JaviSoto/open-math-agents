import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S52804
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b52804 : Box := ![⟨63,94⟩,⟨31,41⟩,⟨7,9⟩,⟨3,50⟩,⟨127,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨31,41⟩,⟨7,9⟩,⟨3,50⟩,⟨127,233⟩] := by
  have e52804 : Deny 5 13 b52804 := by
    apply closeAction rule_sound _ _ 64 [0x1020c42780f80c91d32842ca0c38c78c80c3e378c76f8de3238de32430f8de31c30f8de31f8de321be37d632631c42e3,0x1ca2830f8dc90c2278dc72842c3089e378c80896f8df68c78c46c3e370c90c32471020f8dc31c910b2830c90c3e37247,0xc225be378c7de311b6c30f8243102278]
    decide +kernel
  exact e52804
end OMA.Blocks5_13_245212.S52804
