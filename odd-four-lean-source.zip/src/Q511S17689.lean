import FastReplay245212
import SparseDigit245212
import FastRound245212
import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S17689
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b17689 : Box := ![⟨95,1920000000000000011376⟩,⟨8,9⟩,⟨15,30⟩,⟨1,1260487804878048787985⟩,⟨207,999999999999999999⟩]
private def b17690 : Box := ![⟨95,190⟩,⟨8,9⟩,⟨15,30⟩,⟨1,396097560975609758478⟩,⟨207,999999999999999999⟩]
private def b17691 : Box := ![⟨95,190⟩,⟨8,9⟩,⟨15,30⟩,⟨1,2⟩,⟨207,2479⟩]
private def b17692 : Box := ![⟨95,190⟩,⟨8,9⟩,⟨15,30⟩,⟨3,65⟩,⟨207,2479⟩]
private def b17693 : Box := ![⟨95,190⟩,⟨8,9⟩,⟨15,30⟩,⟨3,58⟩,⟨207,382⟩]
private def b17694 : Box := ![⟨95,190⟩,⟨8,9⟩,⟨15,20⟩,⟨3,58⟩,⟨207,382⟩]
private def b17705 : Box := ![⟨95,190⟩,⟨8,9⟩,⟨21,30⟩,⟨3,58⟩,⟨207,382⟩]
private def b17706 : Box := ![⟨95,190⟩,⟨8,8⟩,⟨21,30⟩,⟨3,58⟩,⟨207,382⟩]
private def b17709 : Box := ![⟨95,190⟩,⟨9,9⟩,⟨21,30⟩,⟨3,58⟩,⟨207,382⟩]
private def b17710 : Box := ![⟨95,126⟩,⟨9,9⟩,⟨21,30⟩,⟨3,58⟩,⟨207,382⟩]
private def b17725 : Box := ![⟨127,190⟩,⟨9,9⟩,⟨21,30⟩,⟨3,58⟩,⟨207,382⟩]
private def b17728 : Box := ![⟨95,190⟩,⟨8,9⟩,⟨15,30⟩,⟨3,58⟩,⟨383,2475⟩]
private def b17729 : Box := ![⟨95,190⟩,⟨8,8⟩,⟨16,30⟩,⟨3,52⟩,⟨383,2471⟩]
private def b17730 : Box := ![⟨95,190⟩,⟨9,9⟩,⟨16,30⟩,⟨3,52⟩,⟨383,2471⟩]
private def b17731 : Box := ![⟨95,190⟩,⟨9,9⟩,⟨16,20⟩,⟨3,52⟩,⟨383,2470⟩]
private def b17736 : Box := ![⟨95,190⟩,⟨9,9⟩,⟨21,30⟩,⟨3,52⟩,⟨383,2470⟩]
private def b17751 : Box := ![⟨191,1920000000000000011376⟩,⟨8,9⟩,⟨15,30⟩,⟨1,396097560975609758478⟩,⟨207,999999999999999999⟩]
private def b17752 : Box := ![⟨191,1920000000000000011376⟩,⟨8,9⟩,⟨15,30⟩,⟨2,396097560975609758478⟩,⟨207,414⟩]
private def b17757 : Box := ![⟨191,1920000000000000011376⟩,⟨8,9⟩,⟨15,30⟩,⟨2,396097560975609758478⟩,⟨415,999999999999999999⟩]
private def b17758 : Box := ![⟨191,1920000000000000011376⟩,⟨8,9⟩,⟨15,20⟩,⟨2,350188679245283020973⟩,⟨415,999999999999999999⟩]
private def b17759 : Box := ![⟨191,1920000000000000011376⟩,⟨8,9⟩,⟨15,20⟩,⟨3,6⟩,⟨415,999999999999999999⟩]
private def b17760 : Box := ![⟨191,1920000000000000011376⟩,⟨8,9⟩,⟨15,20⟩,⟨7,350188679245283020969⟩,⟨415,999999999999999999⟩]
private def b17761 : Box := ![⟨191,1920000000000000011376⟩,⟨8,9⟩,⟨15,20⟩,⟨7,14⟩,⟨415,999999999999999999⟩]
private def b17762 : Box := ![⟨191,1920000000000000011376⟩,⟨8,9⟩,⟨15,20⟩,⟨15,350188679245283020969⟩,⟨415,999999999999999999⟩]
private def b17763 : Box := ![⟨191,382⟩,⟨8,9⟩,⟨15,20⟩,⟨15,350188679245283020969⟩,⟨415,999999999999999999⟩]
private def b17764 : Box := ![⟨383,1920000000000000011376⟩,⟨8,9⟩,⟨15,20⟩,⟨15,350188679245283020969⟩,⟨415,999999999999999999⟩]
private def b17765 : Box := ![⟨383,1920000000000000011376⟩,⟨8,9⟩,⟨15,20⟩,⟨15,350188679245283020969⟩,⟨415,830⟩]
private def b17766 : Box := ![⟨383,1920000000000000011376⟩,⟨8,9⟩,⟨15,20⟩,⟨15,350188679245283020969⟩,⟨831,999999999999999999⟩]
private def b17781 : Box := ![⟨191,1920000000000000011376⟩,⟨8,9⟩,⟨21,30⟩,⟨2,350188679245283020973⟩,⟨415,999999999999999999⟩]
private def b17782 : Box := ![⟨191,1920000000000000011376⟩,⟨8,8⟩,⟨21,30⟩,⟨2,350188679245283020973⟩,⟨415,999999999999999999⟩]
private def b17785 : Box := ![⟨191,1920000000000000011376⟩,⟨9,9⟩,⟨21,30⟩,⟨2,350188679245283020973⟩,⟨415,999999999999999999⟩]
private def b17786 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨21,30⟩,⟨2,350188679245283020973⟩,⟨415,999999999999999999⟩]
private def b17787 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨21,30⟩,⟨3,92⟩,⟨439,878⟩]
private def b17788 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨21,30⟩,⟨3,92⟩,⟨879,999999999999999999⟩]
private def b17789 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨21,30⟩,⟨3,82⟩,⟨879,1758⟩]
private def b17790 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨21,30⟩,⟨3,82⟩,⟨1759,999999999999999999⟩]
private def b17791 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨21,30⟩,⟨3,74⟩,⟨1759,3518⟩]
private def b17792 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨21,30⟩,⟨3,74⟩,⟨3519,999999999999999999⟩]
private def b17793 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨21,24⟩,⟨3,68⟩,⟨3519,999999999999999999⟩]
private def b17804 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨25,30⟩,⟨3,68⟩,⟨3519,999999999999999999⟩]
private def b17805 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨25,30⟩,⟨3,68⟩,⟨3519,7038⟩]
private def b17806 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨25,30⟩,⟨3,68⟩,⟨7039,999999999999999999⟩]
private def b17807 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨25,30⟩,⟨3,63⟩,⟨7039,14078⟩]
private def b17808 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨25,30⟩,⟨3,63⟩,⟨14079,999999999999999999⟩]
private def b17809 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨25,30⟩,⟨3,58⟩,⟨14079,28158⟩]
private def b17810 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨25,30⟩,⟨3,58⟩,⟨28159,999999999999999999⟩]
private def b17811 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨25,30⟩,⟨3,54⟩,⟨28159,56318⟩]
private def b17812 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨25,30⟩,⟨3,54⟩,⟨56319,999999999999999999⟩]
private def b17813 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨25,30⟩,⟨3,51⟩,⟨56319,112638⟩]
private def b17814 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨25,30⟩,⟨3,51⟩,⟨112639,999999999999999999⟩]
private def b17815 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨25,30⟩,⟨3,48⟩,⟨112639,225278⟩]
private def b17816 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨25,30⟩,⟨3,48⟩,⟨225279,999999999999999999⟩]
private def b17817 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨25,30⟩,⟨3,45⟩,⟨225279,450558⟩]
private def b17818 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨25,30⟩,⟨3,45⟩,⟨450559,999999999999999999⟩]
private def b17819 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨25,30⟩,⟨3,42⟩,⟨450559,901118⟩]
private def b17820 : Box := ![⟨191,382⟩,⟨9,9⟩,⟨25,30⟩,⟨3,42⟩,⟨901119,999999999999999999⟩]
private def b17821 : Box := ![⟨191,254⟩,⟨9,9⟩,⟨25,30⟩,⟨3,40⟩,⟨901119,999999999999999999⟩]
private def b17826 : Box := ![⟨255,382⟩,⟨9,9⟩,⟨25,30⟩,⟨3,40⟩,⟨901119,999999999999999999⟩]
private def b17827 : Box := ![⟨255,382⟩,⟨9,9⟩,⟨25,27⟩,⟨5,40⟩,⟨901119,999999999999999999⟩]
private def b17828 : Box := ![⟨255,382⟩,⟨9,9⟩,⟨25,27⟩,⟨5,9⟩,⟨901119,999999999999999999⟩]
private def b17829 : Box := ![⟨255,382⟩,⟨9,9⟩,⟨25,27⟩,⟨5,9⟩,⟨901119,1802238⟩]
private def b17830 : Box := ![⟨255,382⟩,⟨9,9⟩,⟨25,27⟩,⟨5,9⟩,⟨1802239,999999999999999999⟩]
private def b17831 : Box := ![⟨255,382⟩,⟨9,9⟩,⟨25,27⟩,⟨5,9⟩,⟨1802239,3604478⟩]
private def b17832 : Box := ![⟨255,382⟩,⟨9,9⟩,⟨25,27⟩,⟨5,9⟩,⟨3604479,999999999999999999⟩]
private def b17833 : Box := ![⟨255,382⟩,⟨9,9⟩,⟨25,27⟩,⟨5,9⟩,⟨3604479,7208958⟩]
private def b17834 : Box := ![⟨255,382⟩,⟨9,9⟩,⟨25,27⟩,⟨5,9⟩,⟨7208959,999999999999999999⟩]
private def b17835 : Box := ![⟨255,382⟩,⟨9,9⟩,⟨25,27⟩,⟨5,9⟩,⟨7208959,14417918⟩]
private def b17836 : Box := ![⟨255,382⟩,⟨9,9⟩,⟨25,27⟩,⟨5,9⟩,⟨14417919,999999999999999999⟩]
private def b17851 : Box := ![⟨255,382⟩,⟨9,9⟩,⟨25,27⟩,⟨10,40⟩,⟨901119,999999999999999999⟩]
private def b17852 : Box := ![⟨255,382⟩,⟨9,9⟩,⟨28,30⟩,⟨5,40⟩,⟨901119,999999999999999999⟩]
private def b17853 : Box := ![⟨383,1920000000000000011376⟩,⟨9,9⟩,⟨21,30⟩,⟨2,350188679245283020973⟩,⟨415,999999999999999999⟩]
private def b17854 : Box := ![⟨383,1920000000000000011376⟩,⟨9,9⟩,⟨21,24⟩,⟨7,350188679245283020973⟩,⟨2161,999999999999999999⟩]
private def b17855 : Box := ![⟨383,766⟩,⟨9,9⟩,⟨21,24⟩,⟨8,275059985885673960720⟩,⟨2195,999999999999999999⟩]
private def b17856 : Box := ![⟨383,766⟩,⟨9,9⟩,⟨21,24⟩,⟨9,125⟩,⟨2226,4452⟩]
private def b17857 : Box := ![⟨383,766⟩,⟨9,9⟩,⟨21,24⟩,⟨9,125⟩,⟨4453,999999999999999999⟩]
private def b17858 : Box := ![⟨383,766⟩,⟨9,9⟩,⟨21,24⟩,⟨9,115⟩,⟨4453,8906⟩]
private def b17859 : Box := ![⟨383,766⟩,⟨9,9⟩,⟨21,24⟩,⟨9,115⟩,⟨8907,999999999999999999⟩]
private def b17860 : Box := ![⟨383,766⟩,⟨9,9⟩,⟨21,24⟩,⟨9,106⟩,⟨8907,17814⟩]
private def b17861 : Box := ![⟨383,766⟩,⟨9,9⟩,⟨21,24⟩,⟨9,106⟩,⟨17815,999999999999999999⟩]
private def b17862 : Box := ![⟨383,766⟩,⟨9,9⟩,⟨21,24⟩,⟨9,98⟩,⟨17815,35630⟩]
private def b17863 : Box := ![⟨383,766⟩,⟨9,9⟩,⟨21,24⟩,⟨9,98⟩,⟨35631,999999999999999999⟩]
private def b17864 : Box := ![⟨383,766⟩,⟨9,9⟩,⟨21,24⟩,⟨9,92⟩,⟨35631,71262⟩]
private def b17865 : Box := ![⟨383,766⟩,⟨9,9⟩,⟨21,24⟩,⟨9,92⟩,⟨71263,999999999999999999⟩]
private def b17880 : Box := ![⟨767,1920000000000000011376⟩,⟨9,9⟩,⟨21,24⟩,⟨8,275059985885673960720⟩,⟨2195,999999999999999999⟩]
private def b17881 : Box := ![⟨383,1920000000000000011376⟩,⟨9,9⟩,⟨25,30⟩,⟨7,350188679245283020973⟩,⟨2161,999999999999999999⟩]
theorem deny5_11 : Deny 5 11 ![⟨95,1920000000000000011376⟩,⟨8,9⟩,⟨15,30⟩,⟨1,1260487804878048787985⟩,⟨207,999999999999999999⟩] := by
  have e17691 : Deny 5 11 b17691 := by
    apply closeAction rule_sound _ _ 64 [0x5679a0]
    decide +kernel
  have e17694 : Deny 5 11 b17694 := by
    apply closeAction rule_sound _ _ 64 [0x6670f80f89e32788c79c3103e278c42788c70889e3]
    decide +kernel
  have e17706 : Deny 5 11 b17706 := by
    apply closeAction rule_sound _ _ 64 [0x1d9c4778df68c41f8]
    decide +kernel
  have e17710 : Deny 5 11 b17710 := by
    apply closeAction rule_sound _ _ 64 [0x30e325d0f880a9e32631029c31f774380a9e32442e3]
    decide +kernel
  have e17725 : Deny 5 11 b17725 := by
    apply closeAction rule_sound _ _ 64 [0x1de378c4749e27]
    decide +kernel
  have e17709 : Deny 5 11 b17709 :=
    branchAction rule_sound _ _ 1
      0x7 b17709 b17710 b17725 (by decide +kernel) e17710 e17725
  have e17705 : Deny 5 11 b17705 :=
    branchAction rule_sound _ _ 1
      0x8 b17705 b17706 b17709 (by decide +kernel) e17706 e17709
  have e17693 : Deny 5 11 b17693 :=
    branchAction rule_sound _ _ 1
      0x9 b17693 b17694 b17705 (by decide +kernel) e17694 e17705
  have e17729 : Deny 5 11 b17729 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e17731 : Deny 5 11 b17731 := by
    apply closeAction rule_sound _ _ 64 [0x667678df68c79c4087e349e3]
    decide +kernel
  have e17736 : Deny 5 11 b17736 := by
    apply closeAction rule_sound _ _ 64 [0x1d9dd7672b88c77678c9e237672f89c3778de78c99dde37da31f8da31f8]
    decide +kernel
  have e17730 : Deny 5 11 b17730 :=
    branchAction rule_sound _ _ 2
      0x278 b17730 b17731 b17736 (by decide +kernel) e17731 e17736
  have e17728 : Deny 5 11 b17728 :=
    branchAction rule_sound _ _ 4
      0x238da3 b17728 b17729 b17730 (by decide +kernel) e17729 e17730
  have e17692 : Deny 5 11 b17692 :=
    branchAction rule_sound _ _ 3
      0xbe23 b17692 b17693 b17728 (by decide +kernel) e17693 e17728
  have e17690 : Deny 5 11 b17690 :=
    branchAction rule_sound _ _ 3
      0xae23 b17690 b17691 b17692 (by decide +kernel) e17691 e17692
  have e17752 : Deny 5 11 b17752 := by
    apply closeAction rule_sound _ _ 64 [0x6677592678c79e3]
    decide +kernel
  have e17759 : Deny 5 11 b17759 := by
    apply closeAction rule_sound _ _ 64 [0x4789e0]
    decide +kernel
  have e17761 : Deny 5 11 b17761 := by
    apply closeAction rule_sound _ _ 64 [0x11e20]
    decide +kernel
  have e17763 : Deny 5 11 b17763 := by
    apply closeAction rule_sound _ _ 64 [0x19e23]
    decide +kernel
  have e17765 : Deny 5 11 b17765 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e17766 : Deny 5 11 b17766 := by
    apply closeAction rule_sound _ _ 64 [0x26678c7e276678c7678d232676631e36678cb8d99e32c2223]
    decide +kernel
  have e17764 : Deny 5 11 b17764 :=
    branchAction rule_sound _ _ 1
      0xb b17764 b17765 b17766 (by decide +kernel) e17765 e17766
  have e17762 : Deny 5 11 b17762 :=
    branchAction rule_sound _ _ 1
      0x7 b17762 b17763 b17764 (by decide +kernel) e17763 e17764
  have e17760 : Deny 5 11 b17760 :=
    branchAction rule_sound _ _ 1
      0xa b17760 b17761 b17762 (by decide +kernel) e17761 e17762
  have e17758 : Deny 5 11 b17758 :=
    branchAction rule_sound _ _ 3
      0xa9e3 b17758 b17759 b17760 (by decide +kernel) e17759 e17760
  have e17782 : Deny 5 11 b17782 := by
    apply closeAction rule_sound _ _ 64 [0x199e37678c7e23]
    decide +kernel
  have e17787 : Deny 5 11 b17787 := by
    apply closeAction rule_sound _ _ 64 [0x1d9e3]
    decide +kernel
  have e17789 : Deny 5 11 b17789 := by
    apply closeAction rule_sound _ _ 64 [0x1d9e3]
    decide +kernel
  have e17791 : Deny 5 11 b17791 := by
    apply closeAction rule_sound _ _ 64 [0x1d9e3]
    decide +kernel
  have e17793 : Deny 5 11 b17793 := by
    apply closeAction rule_sound _ _ 64 [0x37788c70899c21e36678cb9c21f49e3]
    decide +kernel
  have e17805 : Deny 5 11 b17805 := by
    apply closeAction rule_sound _ _ 64 [0x1d9e3]
    decide +kernel
  have e17807 : Deny 5 11 b17807 := by
    apply closeAction rule_sound _ _ 64 [0x1d9e3]
    decide +kernel
  have e17809 : Deny 5 11 b17809 := by
    apply closeAction rule_sound _ _ 64 [0x1d9e3]
    decide +kernel
  have e17811 : Deny 5 11 b17811 := by
    apply closeAction rule_sound _ _ 64 [0x1d9e3]
    decide +kernel
  have e17813 : Deny 5 11 b17813 := by
    apply closeAction rule_sound _ _ 64 [0x1d9e3]
    decide +kernel
  have e17815 : Deny 5 11 b17815 := by
    apply closeAction rule_sound _ _ 64 [0x1d9e3]
    decide +kernel
  have e17817 : Deny 5 11 b17817 := by
    apply closeAction rule_sound _ _ 64 [0x1d9e3]
    decide +kernel
  have e17819 : Deny 5 11 b17819 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e17821 : Deny 5 11 b17821 := by
    apply closeAction rule_sound _ _ 64 [0xc3da31e7087da3]
    decide +kernel
  have e17829 : Deny 5 11 b17829 := by
    apply closeAction rule_sound _ _ 64 [0x11]
    decide +kernel
  have e17831 : Deny 5 11 b17831 := by
    apply closeAction rule_sound _ _ 64 [0x11]
    decide +kernel
  have e17833 : Deny 5 11 b17833 := by
    apply closeAction rule_sound _ _ 64 [0x11]
    decide +kernel
  have e17835 : Deny 5 11 b17835 := by
    apply closeAction rule_sound _ _ 64 [0x11]
    decide +kernel
  have e17836 : Deny 5 11 b17836 := by
    apply closeAction rule_sound _ _ 64 [0x190e70c780a44b44b44b44b44b]
    decide +kernel
  have e17834 : Deny 5 11 b17834 :=
    branchAction rule_sound _ _ 1
      0xb b17834 b17835 b17836 (by decide +kernel) e17835 e17836
  have e17832 : Deny 5 11 b17832 :=
    branchAction rule_sound _ _ 1
      0xb b17832 b17833 b17834 (by decide +kernel) e17833 e17834
  have e17830 : Deny 5 11 b17830 :=
    branchAction rule_sound _ _ 1
      0xb b17830 b17831 b17832 (by decide +kernel) e17831 e17832
  have e17828 : Deny 5 11 b17828 :=
    branchAction rule_sound _ _ 1
      0xb b17828 b17829 b17830 (by decide +kernel) e17829 e17830
  have e17851 : Deny 5 11 b17851 := by
    apply closeAction rule_sound _ _ 64 [0x19]
    decide +kernel
  have e17827 : Deny 5 11 b17827 :=
    branchAction rule_sound _ _ 1
      0xa b17827 b17828 b17851 (by decide +kernel) e17828 e17851
  have e17852 : Deny 5 11 b17852 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e17826 : Deny 5 11 b17826 :=
    branchAction rule_sound _ _ 2
      0x267 b17826 b17827 b17852 (by decide +kernel) e17827 e17852
  have e17820 : Deny 5 11 b17820 :=
    branchAction rule_sound _ _ 2
      0x1e3 b17820 b17821 b17826 (by decide +kernel) e17821 e17826
  have e17818 : Deny 5 11 b17818 :=
    branchAction rule_sound _ _ 2
      0x2e3 b17818 b17819 b17820 (by decide +kernel) e17819 e17820
  have e17816 : Deny 5 11 b17816 :=
    branchAction rule_sound _ _ 2
      0x2e3 b17816 b17817 b17818 (by decide +kernel) e17817 e17818
  have e17814 : Deny 5 11 b17814 :=
    branchAction rule_sound _ _ 2
      0x2e3 b17814 b17815 b17816 (by decide +kernel) e17815 e17816
  have e17812 : Deny 5 11 b17812 :=
    branchAction rule_sound _ _ 2
      0x2e3 b17812 b17813 b17814 (by decide +kernel) e17813 e17814
  have e17810 : Deny 5 11 b17810 :=
    branchAction rule_sound _ _ 2
      0x2e3 b17810 b17811 b17812 (by decide +kernel) e17811 e17812
  have e17808 : Deny 5 11 b17808 :=
    branchAction rule_sound _ _ 2
      0x2e3 b17808 b17809 b17810 (by decide +kernel) e17809 e17810
  have e17806 : Deny 5 11 b17806 :=
    branchAction rule_sound _ _ 2
      0x2e3 b17806 b17807 b17808 (by decide +kernel) e17807 e17808
  have e17804 : Deny 5 11 b17804 :=
    branchAction rule_sound _ _ 1
      0xb b17804 b17805 b17806 (by decide +kernel) e17805 e17806
  have e17792 : Deny 5 11 b17792 :=
    branchAction rule_sound _ _ 2
      0x263 b17792 b17793 b17804 (by decide +kernel) e17793 e17804
  have e17790 : Deny 5 11 b17790 :=
    branchAction rule_sound _ _ 2
      0x2e3 b17790 b17791 b17792 (by decide +kernel) e17791 e17792
  have e17788 : Deny 5 11 b17788 :=
    branchAction rule_sound _ _ 2
      0x2e3 b17788 b17789 b17790 (by decide +kernel) e17789 e17790
  have e17786 : Deny 5 11 b17786 :=
    branchAction rule_sound _ _ 4
      0x2f89e3 b17786 b17787 b17788 (by decide +kernel) e17787 e17788
  have e17856 : Deny 5 11 b17856 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e17858 : Deny 5 11 b17858 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e17860 : Deny 5 11 b17860 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e17862 : Deny 5 11 b17862 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e17864 : Deny 5 11 b17864 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e17865 : Deny 5 11 b17865 := by
    apply closeAction rule_sound _ _ 64 [0x199d99c20c90898c78d92e364b8d92e31e3]
    decide +kernel
  have e17863 : Deny 5 11 b17863 :=
    branchAction rule_sound _ _ 2
      0x2e3 b17863 b17864 b17865 (by decide +kernel) e17864 e17865
  have e17861 : Deny 5 11 b17861 :=
    branchAction rule_sound _ _ 2
      0x2e3 b17861 b17862 b17863 (by decide +kernel) e17862 e17863
  have e17859 : Deny 5 11 b17859 :=
    branchAction rule_sound _ _ 2
      0x2e3 b17859 b17860 b17861 (by decide +kernel) e17860 e17861
  have e17857 : Deny 5 11 b17857 :=
    branchAction rule_sound _ _ 2
      0x2e3 b17857 b17858 b17859 (by decide +kernel) e17858 e17859
  have e17855 : Deny 5 11 b17855 :=
    branchAction rule_sound _ _ 4
      0x2f89e3 b17855 b17856 b17857 (by decide +kernel) e17856 e17857
  have e17880 : Deny 5 11 b17880 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e17854 : Deny 5 11 b17854 :=
    branchAction rule_sound _ _ 4
      0x1f89e3 b17854 b17855 b17880 (by decide +kernel) e17855 e17880
  have e17881 : Deny 5 11 b17881 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e17853 : Deny 5 11 b17853 :=
    branchAction rule_sound _ _ 3
      0x9e27 b17853 b17854 b17881 (by decide +kernel) e17854 e17881
  have e17785 : Deny 5 11 b17785 :=
    branchAction rule_sound _ _ 1
      0x7 b17785 b17786 b17853 (by decide +kernel) e17786 e17853
  have e17781 : Deny 5 11 b17781 :=
    branchAction rule_sound _ _ 1
      0x8 b17781 b17782 b17785 (by decide +kernel) e17782 e17785
  have e17757 : Deny 5 11 b17757 :=
    branchAction rule_sound _ _ 2
      0x263 b17757 b17758 b17781 (by decide +kernel) e17758 e17781
  have e17751 : Deny 5 11 b17751 :=
    branchAction rule_sound _ _ 2
      0x2e7 b17751 b17752 b17757 (by decide +kernel) e17752 e17757
  have e17689 : Deny 5 11 b17689 :=
    branchAction rule_sound _ _ 2
      0x1e3 b17689 b17690 b17751 (by decide +kernel) e17690 e17751
  exact e17689
end OMA.Blocks5_11_245212.S17689
