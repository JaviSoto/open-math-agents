import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S17156
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b17156 : Box := ![⟨23,30⟩,⟨21,30⟩,⟨15,30⟩,⟨5,1210212765957446815715⟩,⟨59,73⟩]
theorem deny5_13 : Deny 5 13 ![⟨23,30⟩,⟨21,30⟩,⟨15,30⟩,⟨5,1210212765957446815715⟩,⟨59,73⟩] := by
  have e17156 : Deny 5 13 b17156 := by
    apply closeAction rule_sound _ _ 64 [0xf70c7dc38c90c38c78c910b0c3e378c7103e378c42788c80c3e378c70f78c90c4087e378c9103087e37da3108e231e3,0x30f78c70e32430f8df61f78c98c4]
    decide +kernel
  exact e17156
end OMA.Blocks5_13_245212.S17156
