import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S45792
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b45792 : Box := ![⟨95,126⟩,⟨18,20⟩,⟨31,62⟩,⟨3,76⟩,⟨239,478⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,126⟩,⟨18,20⟩,⟨31,62⟩,⟨3,76⟩,⟨239,478⟩] := by
  have e45792 : Deny 5 13 b45792 := by
    apply closeAction rule_sound _ _ 64 [0x2492842dddf611d0c21f62842f8de3203088778df68c7de311d0c31c3e3620a543e37255e37d872842c22231e32442e3,0x881150c324710b1d5e3620728a54a29529d0f80f82031c30f81c92950c4088e3724a8c47420c42380c70c31c9295543,0x24a74810b54a0c3e37243e37d87d84088e072952830f8de31c3e378c9088102107e378c9778df68c88dd75d5550c3e09,0x1d75d5550c9]
    decide +kernel
  exact e45792
end OMA.Blocks5_13_245212.S45792
