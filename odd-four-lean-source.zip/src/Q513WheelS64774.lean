import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S64774
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b64774 : Box := ![⟨127,190⟩,⟨63,126⟩,⟨7,9⟩,⟨1,79⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨127,190⟩,⟨63,126⟩,⟨7,9⟩,⟨1,79⟩,⟨479,999999999999999999⟩] := by
  have e64774 : Deny 5 13 b64774 := by
    apply closeAction rule_sound _ _ 64 [0x6d32a32e31db4cae232236d32a32db4cae231d329b4ca4cae19e379e32388c21f8de32236c26c7e1b20b4ca4ca8cb8c9,0xe231f84ca2532a32232c2083e232388c7e230f80e32030f88c88c78db4ca8cbe232380f80e321b4cae231db4cae23223,0x4cae23243e038c80c3e232231dbe372632236f86c94ca4ca8cb8c78c88d3e3709be378dbe1b4f8ddbe370e32231cb8c8,0xe232388c7e03e03e232270f88c70f89e30f8de78c8e231e32632234f8dc26d32899e32232c2083e232388c7e1b4cae23,0x1f80f80f88c7e232380f80f81c3e232231e36d32a32f88c8e132a32631c20820f88c7e232380f80e32038c78c7242083,0x20820820f88c7e232388c7e23083e23]
    decide +kernel
  exact e64774
end OMA.Blocks5_13_245212.S64774
