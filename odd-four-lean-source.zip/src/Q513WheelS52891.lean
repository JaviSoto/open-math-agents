import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S52891
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b52891 : Box := ![⟨63,94⟩,⟨42,62⟩,⟨7,9⟩,⟨3,50⟩,⟨127,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨42,62⟩,⟨7,9⟩,⟨3,50⟩,⟨127,233⟩] := by
  have e52891 : Deny 5 13 b52891 := by
    apply closeAction rule_sound _ _ 64 [0x1132ca6c30c90c3e372471020c42780f8dc324710b2930c84c91132ca8c86db4c3e07103087e0423828a4ca8c98c710b,0x28be2321be37d632631e3113e374f8dc3e370e31e326321b6d34c3e0820a2932a325b0832780f8dc324710ae130d3247,0x243089de31e311b6c3e032430f824728a4c34c91ca10b0c225be37da31f78c46db0c3e372431022781ca2830f8dc7089,0x2b84ca0c3de32436f8de32631e311b6c20c90f80c91ca2930c84c92842e321b6d30c21f82042b82844cae232430f8de3,0x6dbe13284]
    decide +kernel
  exact e52891
end OMA.Blocks5_13_245212.S52891
