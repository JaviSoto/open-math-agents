import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S63153
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b63153 : Box := ![⟨95,126⟩,⟨31,41⟩,⟨10,14⟩,⟨1,59⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,126⟩,⟨31,41⟩,⟨10,14⟩,⟨1,59⟩,⟨479,999999999999999999⟩] := by
  have e63153 : Deny 5 13 b63153 := by
    apply closeAction rule_sound _ _ 64 [0xe378c80f8de32631c39c3e231c3e378c90c2244088e378c70a02a32030f8de78c8678de725be37da31c2238de32632e3,0x8c70c21c22388c21f8de325f089e37da32368c3e370e32038c70c3e378c88c98c20c8e370e31c30e32092c39e580a0c3,0x30f8203e231c3e23088e37]
    decide +kernel
  exact e63153
end OMA.Blocks5_13_245212.S63153
