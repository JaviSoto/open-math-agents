import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S59935
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b59935 : Box := ![⟨63,94⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨1,900178041543026711620⟩,⟨239,478⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨1,900178041543026711620⟩,⟨239,478⟩] := by
  have e59935 : Deny 5 13 b59935 := by
    apply closeAction rule_sound _ _ 64 [0x20825f8ddf7d70827c9107e1fe03e032472482b85ca2a32231e32785e22a3223]
    decide +kernel
  exact e59935
end OMA.Blocks5_13_245212.S59935
