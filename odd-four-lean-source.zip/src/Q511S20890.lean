import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S20890
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b20890 : Box := ![⟨47,1920000000000000011376⟩,⟨15,1920000000000000011376⟩,⟨3,6⟩,⟨1,1324958677685950421113⟩,⟨51,102⟩]
theorem deny5_11 : Deny 5 11 ![⟨47,1920000000000000011376⟩,⟨15,1920000000000000011376⟩,⟨3,6⟩,⟨1,1324958677685950421113⟩,⟨51,102⟩] := by
  have e20890 : Deny 5 11 b20890 := by
    apply closeAction rule_sound _ _ 64 [0x204278dc20c4238dc30e32232631c20e7804238dc30e78c89c99c30f78c98c78c810b4c3e37da580880a8c78c98c88c4,0xe376c39e50f81e02a3243e038c80c46f8de3108e098c70f80e78c80f79e32389e32670c22631e32231024f8ddb0e02a7,0x10b1e02a31c209b2678c41f86670999c3e231c96678c89e31e32230829c26678c42389e31e322310be112912820e0108,0xdc20820c72041f8de30829c38c7e278c80c38c88c78c40820c81f710b8c8e13e379530c80c3e20208113e370f70e0208,0x2093960108e37082083ae1107e2b8498441f8de3113e376f84ca263108e1384a8c78c9478]
    decide +kernel
  exact e20890
end OMA.Blocks5_11_245212.S20890
