import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S58154
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b58154 : Box := ![⟨47,62⟩,⟨31,41⟩,⟨31,1920000000000000011376⟩,⟨1,799016681299385430589⟩,⟨479,999999999999999999⟩]
private def b58155 : Box := ![⟨47,62⟩,⟨31,41⟩,⟨31,62⟩,⟨1,799016681299385430584⟩,⟨479,999999999999999999⟩]
private def b58218 : Box := ![⟨47,62⟩,⟨31,41⟩,⟨63,1920000000000000011376⟩,⟨1,799016681299385430584⟩,⟨479,999999999999999999⟩]
private def b58219 : Box := ![⟨47,53⟩,⟨31,41⟩,⟨63,1920000000000000011376⟩,⟨1,799016681299385430584⟩,⟨479,999999999999999999⟩]
private def b58288 : Box := ![⟨54,62⟩,⟨31,41⟩,⟨63,1920000000000000011376⟩,⟨1,799016681299385430584⟩,⟨479,999999999999999999⟩]
private def b58289 : Box := ![⟨54,62⟩,⟨31,41⟩,⟨63,1920000000000000011376⟩,⟨1,799016681299385430584⟩,⟨479,958⟩]
private def b58318 : Box := ![⟨54,62⟩,⟨31,41⟩,⟨63,1920000000000000011376⟩,⟨1,799016681299385430584⟩,⟨959,999999999999999999⟩]
private def b58319 : Box := ![⟨54,62⟩,⟨31,35⟩,⟨63,1920000000000000011376⟩,⟨1,718295185477505923784⟩,⟨959,999999999999999999⟩]
private def b58442 : Box := ![⟨54,62⟩,⟨36,41⟩,⟨63,1920000000000000011376⟩,⟨1,718295185477505923784⟩,⟨959,999999999999999999⟩]
private def b58443 : Box := ![⟨54,62⟩,⟨36,41⟩,⟨63,126⟩,⟨1,718295185477505923784⟩,⟨959,999999999999999999⟩]
private def b58584 : Box := ![⟨54,62⟩,⟨36,41⟩,⟨127,1920000000000000011376⟩,⟨1,718295185477505923784⟩,⟨959,999999999999999999⟩]
private def b58585 : Box := ![⟨54,57⟩,⟨36,41⟩,⟨127,1920000000000000011376⟩,⟨4,718295185477505923784⟩,⟨959,999999999999999999⟩]
private def b58760 : Box := ![⟨58,62⟩,⟨36,41⟩,⟨127,1920000000000000011376⟩,⟨4,718295185477505923784⟩,⟨959,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,62⟩,⟨31,41⟩,⟨31,1920000000000000011376⟩,⟨1,799016681299385430589⟩,⟨479,999999999999999999⟩] := by
  have e58155 : Deny 5 13 b58155 := by
    apply closeAction rule_sound _ _ 64 [0x7f8df68c8e231c30f8de325fe37d88e23087e23243088087088e23087e37da32237df7cb5ca2972a32df5cae37da31e3,0x30f81c3e23243e36203088e23087e362237df5ca2972a32df7d72b8d8a5cae23]
    decide +kernel
  have e58219 : Deny 5 13 b58219 := by
    apply closeAction rule_sound _ _ 64 [0xaf88ae2325cbe3087e368c88dcbdcbe326f7ef7df0f888a7ef88788a8c9be325cbdc26f7e3242be22a32232d4e222a3,0xbe32f6be372f8cbda372f8cb088da372f8cb738df68c70888dcbe32e372f8cb738df61e372f8cbbdfe23254e2f88abdf,0x209cbe3242207bdcbe326f72f8c9daf8dc]
    decide +kernel
  have e58289 : Deny 5 13 b58289 := by
    apply closeAction rule_sound _ _ 64 [0x9cbe3109e2f7ef7dfe1f887e172a22a326325cbdcbe326f7ef7df0e229fbe21e22a326f8c98c80622a3]
    decide +kernel
  have e58319 : Deny 5 13 b58319 := by
    apply closeAction rule_sound _ _ 64 [0x8c972f8dcbe31f8d888dcbdcbe326f8cb72f8dcbe32788c7bdfbe37ef0dfe37daf1f88c9e022021f88c9e23254e222a3,0x2e372f8cb8dcbe32e372f8cb8df2e37cbda37cbda37cbda37cbda37cbda37cb8df2e37cb7f8d877f8d888df2dfe231ef,0x88d878dcbe32e372f8cb8dcbe32e372f8cb8dcbe32e372f8cb8dcbe32ef703bc324222f88a8dcbe32e372f8cb8dcbe3,0x9cbe326f72f72f71c2e370b8dc2e326326f8c908272f8c9d87bdcbe326f087d8808272f8c9d87bdcbe324222f]
    decide +kernel
  have e58443 : Deny 5 13 b58443 := by
    apply closeAction rule_sound _ _ 64 [0x2422021e37ef8cb8dfbe32e37ef8cb7ef8c3087e232788c97ef8c21f8da32237ef7ef7df5ca2a32632632d4e222a31e3,0x8dfbe32e37ef8cb8dfbe32e37ef8cb8dfbe32e37ef8cb8dfbe32ef0ef0f88c90f821f5cae371e32488df5cabe32c30e3,0xc38c98c78c9083203d878dfbe32e37ef8cb0f6203daf088d878dfbe32e37ef8cb8dfbe32e37ef8cb8dfbe32e37ef8cb,0x8dfbe32e37ef8cb8dfbe32e37ef8cb8dfbe32e37ef8cb8dfbe32e37ef8cb8dfbe32e37ef8cbe231f8bc20f88c8e038c9,0x820e3243d888dfbe32e37ef8cb8dfbe32e37ef8cb8dfbe32e37ef8cb]
    decide +kernel
  have e58585 : Deny 5 13 b58585 := by
    apply closeAction rule_sound _ _ 64 [0x8cb8dcbe32e372f8cb8dcbe32ef0f87f8d877f8d888df2dfe2324221fe361e37cb8c9538be22a322372f72f8c9be32e3,0x8c909cbe326f72f72f0c222326326f8c909cbe326f087d8809cbe32421c222f088d878dcbe32e372f8cb8dcbe32e372f,0x50b88a8dcbe32e372f8cb8dcbe32e372f8cb8df2e37cb8df2e37cb8df2e37cb8df2e37cb8df2e37cb8df2e37cb8df2ef,0x2dcbedb222c188b50b50b50b88a25cbe22dcbe22dcbe22dcbe22dcbe22dcbe22dcbe22dcbe22dcbe22dcbe22dcbec88b,0x72f0831c222326370b8c9be326372f8cb8dcbe32e372f8cb8dcbe32e372f8cb8dcbe32e31f8bdc72f71cbc308725cbe2,0x209cbe326f72f]
    decide +kernel
  have e58760 : Deny 5 13 b58760 := by
    apply closeAction rule_sound _ _ 64 [0x2e372f8cb8dcbe32e372f8cb8dcbe32e37cb8df2e37cb8df2e37cb8df2e37cb8df2e37cb8df2e37cb8df2f8be3263238,0x88b50b50b50b88a25cbe22dcbe22dcbe22dcbe22dcbe22dcbe22dcbe22dcbe22dcbe22dcbe22dcbec88b50b88a8dcbe3,0x82082738bc27f81f88c9e2f8c98c88c7e2f71cbdc72f0c324972f88b72fb222c1]
    decide +kernel
  have e58584 : Deny 5 13 b58584 :=
    branchAction rule_sound _ _ 2
      0x1ef b58584 b58585 b58760 (by decide +kernel) e58585 e58760
  have e58442 : Deny 5 13 b58442 :=
    branchAction rule_sound _ _ 1
      0x9 b58442 b58443 b58584 (by decide +kernel) e58443 e58584
  have e58318 : Deny 5 13 b58318 :=
    branchAction rule_sound _ _ 2
      0x223 b58318 b58319 b58442 (by decide +kernel) e58319 e58442
  have e58288 : Deny 5 13 b58288 :=
    branchAction rule_sound _ _ 1
      0xb b58288 b58289 b58318 (by decide +kernel) e58289 e58318
  have e58218 : Deny 5 13 b58218 :=
    branchAction rule_sound _ _ 1
      0x7 b58218 b58219 b58288 (by decide +kernel) e58219 e58288
  have e58154 : Deny 5 13 b58154 :=
    branchAction rule_sound _ _ 2
      0x263 b58154 b58155 b58218 (by decide +kernel) e58155 e58218
  exact e58154
end OMA.Blocks5_13_245212.S58154
