import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S63082
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b63082 : Box := ![⟨95,190⟩,⟨42,62⟩,⟨10,14⟩,⟨1,66⟩,⟨239,478⟩]
private def b63083 : Box := ![⟨95,190⟩,⟨42,62⟩,⟨10,14⟩,⟨1,2⟩,⟨239,478⟩]
private def b63084 : Box := ![⟨95,190⟩,⟨42,62⟩,⟨10,14⟩,⟨3,66⟩,⟨239,478⟩]
private def b63085 : Box := ![⟨95,126⟩,⟨42,62⟩,⟨10,14⟩,⟨3,66⟩,⟨239,478⟩]
private def b63086 : Box := ![⟨95,126⟩,⟨42,62⟩,⟨10,14⟩,⟨3,53⟩,⟨239,318⟩]
private def b63097 : Box := ![⟨95,126⟩,⟨42,62⟩,⟨10,14⟩,⟨3,53⟩,⟨319,478⟩]
private def b63098 : Box := ![⟨95,126⟩,⟨42,62⟩,⟨10,11⟩,⟨3,50⟩,⟨319,478⟩]
private def b63099 : Box := ![⟨95,126⟩,⟨42,50⟩,⟨10,11⟩,⟨3,49⟩,⟨319,478⟩]
private def b63100 : Box := ![⟨95,108⟩,⟨42,50⟩,⟨10,11⟩,⟨3,45⟩,⟨319,478⟩]
private def b63101 : Box := ![⟨95,108⟩,⟨42,50⟩,⟨10,11⟩,⟨3,42⟩,⟨319,382⟩]
private def b63108 : Box := ![⟨95,108⟩,⟨42,50⟩,⟨10,11⟩,⟨3,42⟩,⟨383,478⟩]
private def b63115 : Box := ![⟨109,126⟩,⟨42,50⟩,⟨10,11⟩,⟨3,45⟩,⟨319,478⟩]
private def b63116 : Box := ![⟨109,126⟩,⟨42,50⟩,⟨10,11⟩,⟨3,45⟩,⟨319,382⟩]
private def b63121 : Box := ![⟨109,126⟩,⟨42,50⟩,⟨10,11⟩,⟨3,45⟩,⟨383,478⟩]
private def b63128 : Box := ![⟨95,126⟩,⟨51,62⟩,⟨10,11⟩,⟨3,49⟩,⟨319,478⟩]
private def b63135 : Box := ![⟨95,126⟩,⟨42,62⟩,⟨12,14⟩,⟨3,50⟩,⟨319,478⟩]
private def b63144 : Box := ![⟨127,190⟩,⟨42,62⟩,⟨10,14⟩,⟨3,66⟩,⟨239,478⟩]
private theorem e63083 : Deny 5 13 b63083 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
private theorem e63086 : Deny 5 13 b63086 := by
    apply closeAction rule_sound _ _ 64 [0x2093e374f8dd3e370e32632231e3223244]
    decide +kernel
private theorem e63101 : Deny 5 13 b63101 := by
    apply closeAction rule_sound _ _ 64 [0x13e370e3243dc3263204]
    decide +kernel
private theorem e63108 : Deny 5 13 b63108 := by
    apply closeAction rule_sound _ _ 64 [0xf70e32430f8dc98c88c4]
    decide +kernel
private theorem e63100 : Deny 5 13 b63100 :=
    branchAction rule_sound _ _ 2
      0x2e3 b63100 b63101 b63108 (by decide +kernel) e63101 e63108
private theorem e63116 : Deny 5 13 b63116 := by
    apply closeAction rule_sound _ _ 64 [0x13e37083248dc4]
    decide +kernel
private theorem e63121 : Deny 5 13 b63121 := by
    apply closeAction rule_sound _ _ 64 [0x832770f8dc38c98c88c4]
    decide +kernel
private theorem e63115 : Deny 5 13 b63115 :=
    branchAction rule_sound _ _ 1
      0xb b63115 b63116 b63121 (by decide +kernel) e63116 e63121
private theorem e63099 : Deny 5 13 b63099 :=
    branchAction rule_sound _ _ 2
      0x1e3 b63099 b63100 b63115 (by decide +kernel) e63100 e63115
private theorem e63128 : Deny 5 13 b63128 := by
    apply closeAction rule_sound _ _ 64 [0x93e370838c98c88c41f8]
    decide +kernel
private theorem e63098 : Deny 5 13 b63098 :=
    branchAction rule_sound _ _ 2
      0x223 b63098 b63099 b63128 (by decide +kernel) e63099 e63128
private theorem e63135 : Deny 5 13 b63135 := by
    apply closeAction rule_sound _ _ 64 [0x20820832442381f7108e37]
    decide +kernel
private theorem e63097 : Deny 5 13 b63097 :=
    branchAction rule_sound _ _ 2
      0x263 b63097 b63098 b63135 (by decide +kernel) e63098 e63135
private theorem e63085 : Deny 5 13 b63085 :=
    branchAction rule_sound _ _ 2
      0x2e3 b63085 b63086 b63097 (by decide +kernel) e63086 e63097
private theorem e63144 : Deny 5 13 b63144 := by
    apply closeAction rule_sound _ _ 64 [0x20820f89e0108e27808de0109e37]
    decide +kernel
private theorem e63084 : Deny 5 13 b63084 :=
    branchAction rule_sound _ _ 1
      0x7 b63084 b63085 b63144 (by decide +kernel) e63085 e63144
private theorem e63082 : Deny 5 13 b63082 :=
    branchAction rule_sound _ _ 1
      0xa b63082 b63083 b63084 (by decide +kernel) e63083 e63084
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨42,62⟩,⟨10,14⟩,⟨1,66⟩,⟨239,478⟩] := by
  exact e63082
end OMA.Blocks5_13_245212.S63082
