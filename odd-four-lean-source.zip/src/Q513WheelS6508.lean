import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S6508
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b6508 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨11,1920000000000000011376⟩,⟨3,1920000000000000011376⟩,⟨37,47⟩]
theorem deny5_13 : Deny 5 13 ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨11,1920000000000000011376⟩,⟨3,1920000000000000011376⟩,⟨37,47⟩] := by
  have e6508 : Deny 5 13 b6508 := by
    apply closeAction rule_sound _ _ 64 [0xe1261288e3709aae326b0c3ae3263223102083e2b248dcbae3263107e16dea84410be37103e2baa1107e2a84a8c88c9,0x82a820820832472212562845b788b888887e370ab0820aa84aae1109e378c40ab8420831c42780838441f8]
    decide +kernel
  exact e6508
end OMA.Blocks5_13_245212.S6508
