import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S16377
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b16377 : Box := ![⟨95,190⟩,⟨11,14⟩,⟨19,1920000000000000011376⟩,⟨1,1490642201834862394180⟩,⟨113,193⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨11,14⟩,⟨19,1920000000000000011376⟩,⟨1,1490642201834862394180⟩,⟨113,193⟩] := by
  have e16377 : Deny 5 13 b16377 := by
    apply closeAction rule_sound _ _ 64 [0x29de37da321de378c9df68c710be2325d76229d8c9578da229cbdd26f778df68c9088e37da31c456210ae362159a22a3,0x8088042e029d743e278c42789e32670e711ddf68c41f88c7778df68c89e32559a029d0831f774974710b543dc91021f8,0x7559a010ae2780a0889dde378c7778de78c9087df68c475d543e3780980a778de0242204095dc3de70c7247755df680a,0x25cbe311d278bdd25588a09cbc8bdd25dbe22a31e3115de275dbe22af887dc42dd755295295e3620a8c98c710b56229d,0xbdd25588a75d54ae0a778df622325cbdd25d25de37da22b8da31e3102538def7552a3263108e1d55577874854a2492a3,0x72f749]
    decide +kernel
  exact e16377
end OMA.Blocks5_13_245212.S16377
