import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S20151
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b20151 : Box := ![⟨27,30⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨3,1210212765957446815728⟩,⟨59,73⟩]
theorem deny5_13 : Deny 5 13 ![⟨27,30⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨3,1210212765957446815728⟩,⟨59,73⟩] := by
  have e20151 : Deny 5 13 b20151 := by
    apply closeAction rule_sound _ _ 64 [0x83884238dc3e370c8262222107e020c4278dd6e370e22032621c3dc32430c91e2204082083887887888dc42e22a2237,0x2587e378820820c8109e37]
    decide +kernel
  exact e20151
end OMA.Blocks5_13_245212.S20151
