import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S49573
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b49573 : Box := ![⟨95,126⟩,⟨21,24⟩,⟨31,62⟩,⟨1,74⟩,⟨479,999999999999999999⟩]
private def b49574 : Box := ![⟨95,126⟩,⟨21,24⟩,⟨31,62⟩,⟨1,63⟩,⟨479,958⟩]
private def b49575 : Box := ![⟨95,126⟩,⟨21,24⟩,⟨31,62⟩,⟨1,2⟩,⟨479,958⟩]
private def b49576 : Box := ![⟨95,126⟩,⟨21,24⟩,⟨31,62⟩,⟨3,57⟩,⟨479,958⟩]
private def b49577 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨31,62⟩,⟨3,57⟩,⟨479,958⟩]
private def b49578 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨31,41⟩,⟨3,57⟩,⟨479,958⟩]
private def b49579 : Box := ![⟨95,108⟩,⟨21,22⟩,⟨31,41⟩,⟨3,48⟩,⟨479,723⟩]
private def b49580 : Box := ![⟨109,126⟩,⟨21,22⟩,⟨31,41⟩,⟨3,48⟩,⟨479,723⟩]
private def b49581 : Box := ![⟨109,126⟩,⟨21,22⟩,⟨31,41⟩,⟨3,48⟩,⟨479,576⟩]
private def b49592 : Box := ![⟨109,126⟩,⟨21,22⟩,⟨31,41⟩,⟨3,48⟩,⟨577,723⟩]
private def b49597 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨42,62⟩,⟨3,57⟩,⟨479,958⟩]
private def b49598 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨42,62⟩,⟨3,6⟩,⟨479,958⟩]
private def b49599 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨42,62⟩,⟨7,57⟩,⟨479,958⟩]
private def b49600 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨42,62⟩,⟨7,13⟩,⟨479,958⟩]
private def b49601 : Box := ![⟨95,108⟩,⟨21,22⟩,⟨42,62⟩,⟨7,13⟩,⟨479,958⟩]
private def b49602 : Box := ![⟨95,108⟩,⟨21,22⟩,⟨42,62⟩,⟨7,13⟩,⟨479,565⟩]
private def b49607 : Box := ![⟨95,108⟩,⟨21,22⟩,⟨42,62⟩,⟨7,13⟩,⟨566,690⟩]
private def b49614 : Box := ![⟨109,126⟩,⟨21,22⟩,⟨42,62⟩,⟨7,13⟩,⟨479,958⟩]
private def b49615 : Box := ![⟨109,126⟩,⟨21,22⟩,⟨42,62⟩,⟨7,13⟩,⟨479,638⟩]
private def b49616 : Box := ![⟨109,126⟩,⟨21,22⟩,⟨42,50⟩,⟨7,13⟩,⟨479,638⟩]
private def b49623 : Box := ![⟨109,126⟩,⟨21,22⟩,⟨51,62⟩,⟨7,13⟩,⟨479,638⟩]
private def b49628 : Box := ![⟨109,126⟩,⟨21,22⟩,⟨42,62⟩,⟨7,13⟩,⟨639,958⟩]
private def b49637 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨42,62⟩,⟨14,57⟩,⟨479,958⟩]
private def b49638 : Box := ![⟨95,126⟩,⟨23,24⟩,⟨31,62⟩,⟨3,57⟩,⟨479,958⟩]
private def b49639 : Box := ![⟨95,126⟩,⟨23,24⟩,⟨31,41⟩,⟨3,57⟩,⟨479,958⟩]
private def b49640 : Box := ![⟨95,108⟩,⟨23,24⟩,⟨31,41⟩,⟨3,48⟩,⟨479,958⟩]
private def b49641 : Box := ![⟨95,108⟩,⟨23,24⟩,⟨31,41⟩,⟨3,45⟩,⟨479,616⟩]
private def b49650 : Box := ![⟨95,108⟩,⟨23,24⟩,⟨31,41⟩,⟨3,45⟩,⟨617,866⟩]
private def b49655 : Box := ![⟨109,126⟩,⟨23,24⟩,⟨31,41⟩,⟨3,48⟩,⟨479,958⟩]
private def b49656 : Box := ![⟨109,126⟩,⟨23,24⟩,⟨31,41⟩,⟨3,48⟩,⟨479,638⟩]
private def b49665 : Box := ![⟨109,126⟩,⟨23,24⟩,⟨31,41⟩,⟨3,48⟩,⟨639,958⟩]
private def b49674 : Box := ![⟨95,126⟩,⟨23,24⟩,⟨42,62⟩,⟨3,57⟩,⟨479,958⟩]
private def b49679 : Box := ![⟨95,126⟩,⟨21,24⟩,⟨31,62⟩,⟨1,63⟩,⟨959,999999999999999999⟩]
private def b49680 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨31,62⟩,⟨1,56⟩,⟨959,999999999999999999⟩]
private def b49689 : Box := ![⟨95,126⟩,⟨23,24⟩,⟨31,62⟩,⟨1,56⟩,⟨959,999999999999999999⟩]
private def b49690 : Box := ![⟨95,126⟩,⟨23,24⟩,⟨31,41⟩,⟨1,56⟩,⟨959,999999999999999999⟩]
private def b49691 : Box := ![⟨95,108⟩,⟨23,24⟩,⟨31,41⟩,⟨1,48⟩,⟨959,2055⟩]
private def b49692 : Box := ![⟨109,126⟩,⟨23,24⟩,⟨31,41⟩,⟨1,48⟩,⟨959,2055⟩]
private def b49703 : Box := ![⟨95,126⟩,⟨23,24⟩,⟨42,62⟩,⟨1,56⟩,⟨959,999999999999999999⟩]
private def b49704 : Box := ![⟨95,108⟩,⟨23,24⟩,⟨42,62⟩,⟨1,56⟩,⟨959,999999999999999999⟩]
private def b49713 : Box := ![⟨109,126⟩,⟨23,24⟩,⟨42,62⟩,⟨1,56⟩,⟨959,999999999999999999⟩]
private def b49714 : Box := ![⟨109,126⟩,⟨23,24⟩,⟨42,62⟩,⟨1,56⟩,⟨959,1918⟩]
private def b49715 : Box := ![⟨109,126⟩,⟨23,24⟩,⟨42,62⟩,⟨1,2⟩,⟨959,1918⟩]
private def b49716 : Box := ![⟨109,126⟩,⟨23,24⟩,⟨42,62⟩,⟨3,51⟩,⟨959,1918⟩]
private def b49717 : Box := ![⟨109,126⟩,⟨23,24⟩,⟨42,62⟩,⟨3,6⟩,⟨959,1918⟩]
private def b49718 : Box := ![⟨109,126⟩,⟨23,24⟩,⟨42,62⟩,⟨7,51⟩,⟨959,1918⟩]
private def b49719 : Box := ![⟨109,126⟩,⟨23,24⟩,⟨42,62⟩,⟨7,12⟩,⟨959,1918⟩]
private def b49720 : Box := ![⟨109,126⟩,⟨23,23⟩,⟨42,62⟩,⟨7,12⟩,⟨959,1918⟩]
private def b49721 : Box := ![⟨109,126⟩,⟨23,23⟩,⟨42,50⟩,⟨7,12⟩,⟨959,1918⟩]
private def b49724 : Box := ![⟨109,126⟩,⟨23,23⟩,⟨51,62⟩,⟨7,12⟩,⟨959,1918⟩]
private def b49725 : Box := ![⟨109,126⟩,⟨23,23⟩,⟨51,62⟩,⟨7,8⟩,⟨959,1918⟩]
private def b49726 : Box := ![⟨109,126⟩,⟨23,23⟩,⟨51,62⟩,⟨9,12⟩,⟨959,1918⟩]
private def b49737 : Box := ![⟨109,126⟩,⟨24,24⟩,⟨42,62⟩,⟨7,12⟩,⟨959,1918⟩]
private def b49738 : Box := ![⟨109,126⟩,⟨23,24⟩,⟨42,62⟩,⟨13,51⟩,⟨959,1918⟩]
private def b49739 : Box := ![⟨109,126⟩,⟨23,24⟩,⟨42,62⟩,⟨1,56⟩,⟨1919,999999999999999999⟩]
private def b49740 : Box := ![⟨109,126⟩,⟨23,24⟩,⟨42,50⟩,⟨1,51⟩,⟨1919,999999999999999999⟩]
private def b49745 : Box := ![⟨109,126⟩,⟨23,24⟩,⟨51,62⟩,⟨1,51⟩,⟨1919,999999999999999999⟩]
private theorem e49575 : Deny 5 13 b49575 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
private theorem e49579 : Deny 5 13 b49579 := by
    apply closeAction rule_sound _ _ 64 [0x1de37da3]
    decide +kernel
private theorem e49581 : Deny 5 13 b49581 := by
    apply closeAction rule_sound _ _ 64 [0x1d7c3e37d88295283088de3244]
    decide +kernel
private theorem e49592 : Deny 5 13 b49592 := by
    apply closeAction rule_sound _ _ 64 [0x3088778df68c7e37da3]
    decide +kernel
private theorem e49580 : Deny 5 13 b49580 :=
    branchAction rule_sound _ _ 1
      0xb b49580 b49581 b49592 (by decide +kernel) e49581 e49592
private theorem e49578 : Deny 5 13 b49578 :=
    branchAction rule_sound _ _ 3
      0x7e23 b49578 b49579 b49580 (by decide +kernel) e49579 e49580
private theorem e49598 : Deny 5 13 b49598 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
private theorem e49602 : Deny 5 13 b49602 := by
    apply closeAction rule_sound _ _ 64 [0x1f0c21f8df6204]
    decide +kernel
private theorem e49607 : Deny 5 13 b49607 := by
    apply closeAction rule_sound _ _ 64 [0x1d7f8d8a088087d84]
    decide +kernel
private theorem e49601 : Deny 5 13 b49601 :=
    branchAction rule_sound _ _ 2
      0x2f8 b49601 b49602 b49607 (by decide +kernel) e49602 e49607
private theorem e49616 : Deny 5 13 b49616 := by
    apply closeAction rule_sound _ _ 64 [0xf80f82030f8df6207]
    decide +kernel
private theorem e49623 : Deny 5 13 b49623 := by
    apply closeAction rule_sound _ _ 64 [0x77874854a]
    decide +kernel
private theorem e49615 : Deny 5 13 b49615 :=
    branchAction rule_sound _ _ 1
      0x9 b49615 b49616 b49623 (by decide +kernel) e49616 e49623
private theorem e49628 : Deny 5 13 b49628 := by
    apply closeAction rule_sound _ _ 64 [0x7550c2215e361f824a]
    decide +kernel
private theorem e49614 : Deny 5 13 b49614 :=
    branchAction rule_sound _ _ 1
      0xb b49614 b49615 b49628 (by decide +kernel) e49615 e49628
private theorem e49600 : Deny 5 13 b49600 :=
    branchAction rule_sound _ _ 1
      0x7 b49600 b49601 b49614 (by decide +kernel) e49601 e49614
private theorem e49637 : Deny 5 13 b49637 := by
    apply closeAction rule_sound _ _ 64 [0x1d]
    decide +kernel
private theorem e49599 : Deny 5 13 b49599 :=
    branchAction rule_sound _ _ 1
      0xa b49599 b49600 b49637 (by decide +kernel) e49600 e49637
private theorem e49597 : Deny 5 13 b49597 :=
    branchAction rule_sound _ _ 1
      0xa b49597 b49598 b49599 (by decide +kernel) e49598 e49599
private theorem e49577 : Deny 5 13 b49577 :=
    branchAction rule_sound _ _ 1
      0x9 b49577 b49578 b49597 (by decide +kernel) e49578 e49597
private theorem e49641 : Deny 5 13 b49641 := by
    apply closeAction rule_sound _ _ 64 [0x7df543e09578d8728a]
    decide +kernel
private theorem e49650 : Deny 5 13 b49650 := by
    apply closeAction rule_sound _ _ 64 [0xdfe378c97f8df68c7e23]
    decide +kernel
private theorem e49640 : Deny 5 13 b49640 :=
    branchAction rule_sound _ _ 3
      0xbe23 b49640 b49641 b49650 (by decide +kernel) e49641 e49650
private theorem e49656 : Deny 5 13 b49656 := by
    apply closeAction rule_sound _ _ 64 [0x1f7d50d520928a]
    decide +kernel
private theorem e49665 : Deny 5 13 b49665 := by
    apply closeAction rule_sound _ _ 64 [0x3e032038c70c3e231e3263]
    decide +kernel
private theorem e49655 : Deny 5 13 b49655 :=
    branchAction rule_sound _ _ 1
      0xb b49655 b49656 b49665 (by decide +kernel) e49656 e49665
private theorem e49639 : Deny 5 13 b49639 :=
    branchAction rule_sound _ _ 2
      0x1e3 b49639 b49640 b49655 (by decide +kernel) e49640 e49655
private theorem e49674 : Deny 5 13 b49674 := by
    apply closeAction rule_sound _ _ 64 [0x1d7ca54a]
    decide +kernel
private theorem e49638 : Deny 5 13 b49638 :=
    branchAction rule_sound _ _ 1
      0x9 b49638 b49639 b49674 (by decide +kernel) e49639 e49674
private theorem e49576 : Deny 5 13 b49576 :=
    branchAction rule_sound _ _ 1
      0x8 b49576 b49577 b49638 (by decide +kernel) e49577 e49638
private theorem e49574 : Deny 5 13 b49574 :=
    branchAction rule_sound _ _ 2
      0x2a3 b49574 b49575 b49576 (by decide +kernel) e49575 e49576
private theorem e49680 : Deny 5 13 b49680 := by
    apply closeAction rule_sound _ _ 64 [0x3778de32422021f88c21f8df6]
    decide +kernel
private theorem e49691 : Deny 5 13 b49691 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e49692 : Deny 5 13 b49692 := by
    apply closeAction rule_sound _ _ 64 [0xc3e378c80f8de31c3087e378c954ae23]
    decide +kernel
private theorem e49690 : Deny 5 13 b49690 :=
    branchAction rule_sound _ _ 3
      0x7e23 b49690 b49691 b49692 (by decide +kernel) e49691 e49692
private theorem e49704 : Deny 5 13 b49704 := by
    apply closeAction rule_sound _ _ 64 [0x75f7f8d88e0a54ae2354ae23]
    decide +kernel
private theorem e49715 : Deny 5 13 b49715 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
private theorem e49717 : Deny 5 13 b49717 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
private theorem e49721 : Deny 5 13 b49721 := by
    apply closeAction rule_sound _ _ 64 [0xdfe361f8]
    decide +kernel
private theorem e49725 : Deny 5 13 b49725 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
private theorem e49726 : Deny 5 13 b49726 := by
    apply closeAction rule_sound _ _ 64 [0x75d7550f61ca2df2ca]
    decide +kernel
private theorem e49724 : Deny 5 13 b49724 :=
    branchAction rule_sound _ _ 1
      0xa b49724 b49725 b49726 (by decide +kernel) e49725 e49726
private theorem e49720 : Deny 5 13 b49720 :=
    branchAction rule_sound _ _ 1
      0x9 b49720 b49721 b49724 (by decide +kernel) e49721 e49724
private theorem e49737 : Deny 5 13 b49737 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e49719 : Deny 5 13 b49719 :=
    branchAction rule_sound _ _ 1
      0x8 b49719 b49720 b49737 (by decide +kernel) e49720 e49737
private theorem e49738 : Deny 5 13 b49738 := by
    apply closeAction rule_sound _ _ 64 [0x1d]
    decide +kernel
private theorem e49718 : Deny 5 13 b49718 :=
    branchAction rule_sound _ _ 1
      0xa b49718 b49719 b49738 (by decide +kernel) e49719 e49738
private theorem e49716 : Deny 5 13 b49716 :=
    branchAction rule_sound _ _ 1
      0xa b49716 b49717 b49718 (by decide +kernel) e49717 e49718
private theorem e49714 : Deny 5 13 b49714 :=
    branchAction rule_sound _ _ 2
      0x2a3 b49714 b49715 b49716 (by decide +kernel) e49715 e49716
private theorem e49740 : Deny 5 13 b49740 := by
    apply closeAction rule_sound _ _ 64 [0xf80f8df68c7e23088e23]
    decide +kernel
private theorem e49745 : Deny 5 13 b49745 := by
    apply closeAction rule_sound _ _ 64 [0xf80f82038c90f88c22388c7]
    decide +kernel
private theorem e49739 : Deny 5 13 b49739 :=
    branchAction rule_sound _ _ 2
      0x263 b49739 b49740 b49745 (by decide +kernel) e49740 e49745
private theorem e49713 : Deny 5 13 b49713 :=
    branchAction rule_sound _ _ 1
      0xb b49713 b49714 b49739 (by decide +kernel) e49714 e49739
private theorem e49703 : Deny 5 13 b49703 :=
    branchAction rule_sound _ _ 1
      0x7 b49703 b49704 b49713 (by decide +kernel) e49704 e49713
private theorem e49689 : Deny 5 13 b49689 :=
    branchAction rule_sound _ _ 1
      0x9 b49689 b49690 b49703 (by decide +kernel) e49690 e49703
private theorem e49679 : Deny 5 13 b49679 :=
    branchAction rule_sound _ _ 2
      0x223 b49679 b49680 b49689 (by decide +kernel) e49680 e49689
private theorem e49573 : Deny 5 13 b49573 :=
    branchAction rule_sound _ _ 2
      0x2e3 b49573 b49574 b49679 (by decide +kernel) e49574 e49679
theorem deny5_13 : Deny 5 13 ![⟨95,126⟩,⟨21,24⟩,⟨31,62⟩,⟨1,74⟩,⟨479,999999999999999999⟩] := by
  exact e49573
end OMA.Blocks5_13_245212.S49573
