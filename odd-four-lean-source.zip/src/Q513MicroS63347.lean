import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S63347
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b63347 : Box := ![⟨127,190⟩,⟨31,41⟩,⟨10,11⟩,⟨1,53⟩,⟨959,999999999999999999⟩]
private def b63348 : Box := ![⟨127,190⟩,⟨31,35⟩,⟨10,11⟩,⟨1,51⟩,⟨959,17688⟩]
private def b63349 : Box := ![⟨127,190⟩,⟨36,41⟩,⟨10,11⟩,⟨1,51⟩,⟨959,17688⟩]
private def b63350 : Box := ![⟨127,152⟩,⟨36,41⟩,⟨10,11⟩,⟨4,47⟩,⟨959,17650⟩]
private def b63355 : Box := ![⟨153,190⟩,⟨36,41⟩,⟨10,11⟩,⟨4,47⟩,⟨959,17650⟩]
private def b63356 : Box := ![⟨153,190⟩,⟨36,41⟩,⟨10,11⟩,⟨7,47⟩,⟨959,1819⟩]
private def b63363 : Box := ![⟨153,190⟩,⟨36,41⟩,⟨10,11⟩,⟨7,47⟩,⟨1820,17628⟩]
private theorem e63348 : Deny 5 13 b63348 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e63350 : Deny 5 13 b63350 := by
    apply closeAction rule_sound _ _ 64 [0x39c21f89e3088e23]
    decide +kernel
private theorem e63356 : Deny 5 13 b63356 := by
    apply closeAction rule_sound _ _ 64 [0x6c39c3e231c22489e3]
    decide +kernel
private theorem e63363 : Deny 5 13 b63363 := by
    apply closeAction rule_sound _ _ 64 [0x3e270f88c7e02278678df68c8e23]
    decide +kernel
private theorem e63355 : Deny 5 13 b63355 :=
    branchAction rule_sound _ _ 3
      0xbe27 b63355 b63356 b63363 (by decide +kernel) e63356 e63363
private theorem e63349 : Deny 5 13 b63349 :=
    branchAction rule_sound _ _ 4
      0x1f89e3 b63349 b63350 b63355 (by decide +kernel) e63350 e63355
private theorem e63347 : Deny 5 13 b63347 :=
    branchAction rule_sound _ _ 3
      0x8e23 b63347 b63348 b63349 (by decide +kernel) e63348 e63349
theorem deny5_13 : Deny 5 13 ![⟨127,190⟩,⟨31,41⟩,⟨10,11⟩,⟨1,53⟩,⟨959,999999999999999999⟩] := by
  exact e63347
end OMA.Blocks5_13_245212.S63347
