import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S43311
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b43311 : Box := ![⟨95,190⟩,⟨21,30⟩,⟨7,9⟩,⟨3,64⟩,⟨127,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨21,30⟩,⟨7,9⟩,⟨3,64⟩,⟨127,233⟩] := by
  have e43311 : Deny 5 13 b43311 := by
    apply closeAction rule_sound _ _ 64 [0xde78c99e31d90e70870881039c31c3804089e278088042e0103102238107e20283e37da780a678df49e32678c810b9e3,0xf88099e02040820e02678088042db0f89e0108e278099e02a70c3de32430899e3223103dc32430c99e32042c3102238,0x8090e01022789e022010b80a9c3678de3259e37da3238de31d99c4087e37d278c8678df5d278c98c46420f89c31e0243,0x6439c3e07089088103e27103107e03e27]
    decide +kernel
  exact e43311
end OMA.Blocks5_13_245212.S43311
