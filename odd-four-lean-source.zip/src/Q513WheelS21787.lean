import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S21787
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b21787 : Box := ![⟨27,30⟩,⟨63,126⟩,⟨15,30⟩,⟨3,75⟩,⟨94,113⟩]
theorem deny5_13 : Deny 5 13 ![⟨27,30⟩,⟨63,126⟩,⟨15,30⟩,⟨3,75⟩,⟨94,113⟩] := by
  have e21787 : Deny 5 13 b21787 := by
    apply closeAction rule_sound _ _ 64 [0x8c87c3e371e326311f0c38c91c42df283088df68c40c3de32036b8de32378c92f81e32037f8df6849087e3784a8c98c4,0xac20c722b27710b0eb0e3203ae32436b8df61eb6b8de322b8c98c40ab0e3203ae3243ac38c80eb8c9ae32442e31eb0c3,0xa1277d840f8deb0c80f78470eb8490c3e371c3e372772042e11e1282adfe370c72370f8deb0e3203ae326b8c98c4082,0xdea84184adc3203ae12430f72030f8dc8dc92040aa8432370eb8490f70c80c922110b0c3e37da11c3e37d885b8db584a,0x7f8ddfe37103108e370e32477830c70dee37d8720a0c3de322326311e0c38c88c90831c30c72030c824a10b8c78c85b8,0x9f849e377820e11eb0f8dc31c884adc20c70f8dc38c78c80c3e2b1e12a3263102ac20e11f8dc3e370eb1c923710b8c7]
    decide +kernel
  exact e21787
end OMA.Blocks5_13_245212.S21787
