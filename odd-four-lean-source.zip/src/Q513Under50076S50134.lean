import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S50134
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b50134 : Box := ![⟨127,138⟩,⟨23,24⟩,⟨42,62⟩,⟨1,55⟩,⟨1919,999999999999999999⟩]
private def b50135 : Box := ![⟨127,138⟩,⟨23,24⟩,⟨42,50⟩,⟨1,53⟩,⟨1919,999999999999999999⟩]
private def b50136 : Box := ![⟨127,138⟩,⟨23,24⟩,⟨42,45⟩,⟨1,49⟩,⟨1919,999999999999999999⟩]
private def b50137 : Box := ![⟨127,138⟩,⟨23,24⟩,⟨46,50⟩,⟨1,49⟩,⟨1919,999999999999999999⟩]
private def b50138 : Box := ![⟨127,138⟩,⟨23,23⟩,⟨46,50⟩,⟨1,49⟩,⟨1919,999999999999999999⟩]
private def b50139 : Box := ![⟨127,138⟩,⟨24,24⟩,⟨46,50⟩,⟨1,49⟩,⟨1919,999999999999999999⟩]
private def b50140 : Box := ![⟨127,138⟩,⟨23,24⟩,⟨51,62⟩,⟨1,53⟩,⟨1919,999999999999999999⟩]
private def b50141 : Box := ![⟨127,138⟩,⟨23,24⟩,⟨51,62⟩,⟨1,53⟩,⟨1919,3838⟩]
private def b50142 : Box := ![⟨127,138⟩,⟨23,23⟩,⟨51,62⟩,⟨1,48⟩,⟨1919,3838⟩]
private def b50143 : Box := ![⟨127,132⟩,⟨23,23⟩,⟨51,62⟩,⟨1,48⟩,⟨1919,3838⟩]
private def b50144 : Box := ![⟨133,138⟩,⟨23,23⟩,⟨51,62⟩,⟨1,48⟩,⟨1919,3838⟩]
private def b50145 : Box := ![⟨127,138⟩,⟨24,24⟩,⟨51,62⟩,⟨1,48⟩,⟨1919,3838⟩]
private def b50146 : Box := ![⟨127,138⟩,⟨23,24⟩,⟨51,62⟩,⟨1,53⟩,⟨3839,999999999999999999⟩]
private def b50147 : Box := ![⟨127,138⟩,⟨23,23⟩,⟨51,62⟩,⟨1,48⟩,⟨3839,999999999999999999⟩]
private def b50148 : Box := ![⟨127,132⟩,⟨23,23⟩,⟨51,62⟩,⟨1,48⟩,⟨3839,999999999999999999⟩]
private def b50149 : Box := ![⟨133,138⟩,⟨23,23⟩,⟨51,62⟩,⟨1,48⟩,⟨3839,999999999999999999⟩]
private def b50150 : Box := ![⟨127,138⟩,⟨24,24⟩,⟨51,62⟩,⟨1,48⟩,⟨3839,999999999999999999⟩]
private def b50151 : Box := ![⟨127,132⟩,⟨24,24⟩,⟨51,62⟩,⟨1,48⟩,⟨8120,999999999999999999⟩]
private def b50152 : Box := ![⟨133,138⟩,⟨24,24⟩,⟨51,62⟩,⟨1,48⟩,⟨8120,999999999999999999⟩]
private theorem e50136 : Deny 5 13 b50136 := by
    apply closeAction rule_sound _ _ 64 [0xe3]
    decide +kernel
private theorem e50138 : Deny 5 13 b50138 := by
    apply closeAction rule_sound _ _ 64 [0xf8]
    decide +kernel
private theorem e50139 : Deny 5 13 b50139 := by
    apply closeAction rule_sound _ _ 64 [0xf8]
    decide +kernel
private theorem e50137 : Deny 5 13 b50137 :=
    branchAction rule_sound _ _ 1
      0x8 b50137 b50138 b50139 (by decide +kernel) e50138 e50139
private theorem e50135 : Deny 5 13 b50135 :=
    branchAction rule_sound _ _ 2
      0x263 b50135 b50136 b50137 (by decide +kernel) e50136 e50137
private theorem e50143 : Deny 5 13 b50143 := by
    apply closeAction rule_sound _ _ 64 [0xe3]
    decide +kernel
private theorem e50144 : Deny 5 13 b50144 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e50142 : Deny 5 13 b50142 :=
    branchAction rule_sound _ _ 1
      0x7 b50142 b50143 b50144 (by decide +kernel) e50143 e50144
private theorem e50145 : Deny 5 13 b50145 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e50141 : Deny 5 13 b50141 :=
    branchAction rule_sound _ _ 2
      0x223 b50141 b50142 b50145 (by decide +kernel) e50142 e50145
private theorem e50148 : Deny 5 13 b50148 := by
    apply closeAction rule_sound _ _ 64 [0x3e23]
    decide +kernel
private theorem e50149 : Deny 5 13 b50149 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e50147 : Deny 5 13 b50147 :=
    branchAction rule_sound _ _ 1
      0x7 b50147 b50148 b50149 (by decide +kernel) e50148 e50149
private theorem e50151 : Deny 5 13 b50151 := by
    apply closeAction rule_sound _ _ 64 [0x3e23]
    decide +kernel
private theorem e50152 : Deny 5 13 b50152 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e50150 : Deny 5 13 b50150 :=
    branchAction rule_sound _ _ 2
      0x1f8 b50150 b50151 b50152 (by decide +kernel) e50151 e50152
private theorem e50146 : Deny 5 13 b50146 :=
    branchAction rule_sound _ _ 2
      0x223 b50146 b50147 b50150 (by decide +kernel) e50147 e50150
private theorem e50140 : Deny 5 13 b50140 :=
    branchAction rule_sound _ _ 1
      0xb b50140 b50141 b50146 (by decide +kernel) e50141 e50146
private theorem e50134 : Deny 5 13 b50134 :=
    branchAction rule_sound _ _ 2
      0x263 b50134 b50135 b50140 (by decide +kernel) e50135 e50140
theorem deny5_13 : Deny 5 13 ![⟨127,138⟩,⟨23,24⟩,⟨42,62⟩,⟨1,55⟩,⟨1919,999999999999999999⟩] := by
  exact e50134
end OMA.Blocks5_13_245212.S50134
