import HeightMixed245212

/-! A selected prime divides both numerators of its rounded pair. Consequently
a rounded score of two forces the largest selected odd prime to divide an
exponent-plus-one. -/
namespace OMA.Height245212
open OMA.Smooth245212 Finset
open scoped ArithmeticFunction.sigma
noncomputable section

theorem selected_numerator (p e : Fin 4 → ℕ) (prime : ∀ i,(p i).Prime) (s : Finset (Fin 4))
    (t : Fin 4) (ht : t∈s) :
    ∃ z : ℤ,(z:ℚ)=scoreM p e s*commonDen p e s ∧ (p t:ℤ)∣z := by
  have ints (i : Fin 4) : ∃ u v : ℤ,
      (u:ℚ)=xm p e s i*localDen p e s i ∧ (v:ℚ)=ym p e s i*localDen p e s i ∧
      (i=t → (p t:ℤ)∣u ∧ (p t:ℤ)∣v) := by
    by_cases h : i∈s
    · refine ⟨(p i:ℤ)*(((p i:ℤ)-1)*((e i:ℤ)+1)-1),(p i:ℤ)*((p i:ℤ)-1),?_,?_,?_⟩
      · have pi : (1:ℚ)<p i := by exact_mod_cast (prime i).one_lt
        simp only [xm,localDen,h,if_pos,xr,yr,den]; push_cast [Nat.cast_sub (prime i).pos]
        field_simp [sub_ne_zero.mpr pi.ne']; ring
      · have pi : (1:ℚ)<p i := by exact_mod_cast (prime i).one_lt
        simp only [ym,localDen,h,if_pos,yr,den]; push_cast [Nat.cast_sub (prime i).pos]
        field_simp [sub_ne_zero.mpr pi.ne']
      · rintro rfl; exact ⟨dvd_mul_right _ _,dvd_mul_right _ _⟩
    · refine ⟨(W (p i^e i):ℕ),(σ 1 (p i^e i):ℕ),?_,?_,fun h' => (h (h' ▸ ht)).elim⟩
      · simpa [xm,localDen,h] using (x_factor (prime i) (e i)).symm
      · simpa [ym,localDen,h] using (y_factor (prime i) (e i)).symm
  choose u v hu hv d using ints
  refine ⟨(∏ i,u i)+∏ i,v i,?_,dvd_add ((d t rfl).1.trans
    (dvd_prod_of_mem u (mem_univ t))) ((d t rfl).2.trans (dvd_prod_of_mem v (mem_univ t)))⟩
  simp only [scoreM,commonDen,Int.cast_add,Int.cast_prod,Nat.cast_prod,hu,hv,
    prod_mul_distrib,add_mul]

theorem selected_divides (p e : Fin 4 → ℕ) (prime : ∀ i,(p i).Prime) (ord : StrictMono p)
    (s : Finset (Fin 4)) (t : Fin 4) (ht : t∈s) (high : ∀ j∈s,p j≤p t)
    (odd : 2<p t) (score : scoreM p e s=2) : ∃ j,p t∣e j+1 := by
  obtain ⟨z,h,d⟩ := selected_numerator p e prime s t ht
  rw [score] at h
  have h' : z=2*(commonDen p e s:ℤ) := by exact_mod_cast h
  rw [h'] at d
  have dd : p t∣2*commonDen p e s := by exact_mod_cast d
  have div := ((prime t).dvd_mul.mp dd).resolve_left (fun h => (Nat.le_of_dvd (by decide) h).not_gt odd)
  obtain ⟨j,_,dj⟩ := ((prime t).prime.dvd_finsetProd_iff _).mp div
  by_cases hj : j∈s
  · simp only [localDen,hj,if_pos,den] at dj
    rcases (prime t).dvd_mul.mp dj with d|d
    · exact ⟨j,d⟩
    · have bad := Nat.le_of_dvd (show 0 < p j-1 by have := (prime j).one_lt; omega)
        ((prime t).dvd_of_dvd_pow d)
      have := high j hj; omega
  · simp only [localDen,hj] at dj
    rcases (prime t).dvd_mul.mp dj with d|d
    · exact ⟨j,d⟩
    · have same := (Nat.prime_dvd_prime_iff_eq (prime t) (prime j)).mp ((prime t).dvd_of_dvd_pow d)
      exact (hj (ord.injective same ▸ ht)).elim

end
end OMA.Height245212
