import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S20049
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b20049 : Box := ![⟨23,46⟩,⟨15,1920000000000000011376⟩,⟨3,6⟩,⟨1,788099173553719012974⟩,⟨51,102⟩]
private def b20050 : Box := ![⟨23,46⟩,⟨15,30⟩,⟨3,6⟩,⟨1,780572987721691682691⟩,⟨53,101⟩]
private def b20133 : Box := ![⟨23,46⟩,⟨31,1920000000000000011376⟩,⟨3,6⟩,⟨1,780572987721691682691⟩,⟨53,101⟩]
theorem deny5_11 : Deny 5 11 ![⟨23,46⟩,⟨15,1920000000000000011376⟩,⟨3,6⟩,⟨1,788099173553719012974⟩,⟨51,102⟩] := by
  have e20050 : Deny 5 11 b20050 := by
    apply closeAction rule_sound _ _ 64 [0xf8de31c3e378c86f8df5263103e370e31c30f8de31c90c3e378c98c810b4c3e37d88e0a0c3e378c8102278de31e3263,0x820c9107e370c38c88c88c42d30c80c3e081d32830f8dc8204083107e132532830c82042ca0c3e378c70f8de32231c3,0xf8dc32780c38c88c70c38c88c88c4]
    decide +kernel
  have e20133 : Deny 5 11 b20133 := by
    apply closeAction rule_sound _ _ 64 [0xe376ab6ab0f80f8ae31e322b8c8252283e370eb8c7ac38c80c3e37ae31c40f8de3108e378c98c810b0f8df684a8c78c9,0x2042d384a09aae3107e2b6a3203ae129aada8c8102ae110ae232522830f8deb8c70f8de3202263223102083108e2b847,0xe211c3e084ca8440a1107e212898c88c409bae1277093e370e11e1107e376c20e1107e040c42384ca0c3e0884784a263,0x2c30f884784a8c7083e2b8441f8ddaae311a238adb8c88c948a6f88c40838441f8dc322110ae03e038c70e32231db0c3,0x9aac38c88c9e2b8c88c70f8dc40e3109e038c80f80eb2438c88c78c88c40820c4238dc20eb844278deb0e32231e3204,0xab853e370820e1107e370e3223109e024c9e038474ca84a8c7113dc42c8dd2e370ab]
    decide +kernel
  have e20049 : Deny 5 11 b20049 :=
    branchAction rule_sound _ _ 3
      0x88c4 b20049 b20050 b20133 (by decide +kernel) e20050 e20133
  exact e20049
end OMA.Blocks5_11_245212.S20049
