import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S36266
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b36266 : Box := ![⟨47,94⟩,⟨15,30⟩,⟨15,1920000000000000011376⟩,⟨3,1210212765957446815733⟩,⟨59,77⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,94⟩,⟨15,30⟩,⟨15,1920000000000000011376⟩,⟨3,1210212765957446815733⟩,⟨59,77⟩] := by
  have e36266 : Deny 5 13 b36266 := by
    apply closeAction rule_sound _ _ 64 [0x83dc320727710b0f70c70c80c31c3e37d881c30c90f8df62091020c8dc3dc31f70c81c30c90c82442c82a31e3263204,0xe31c38c88c70c38c90e32232631020832041f8dc20c7dc38c88c98c42e32020c4238dc3e370c7dc32070c3243209102,0xe370f70c92095770f70c7243dc32432091c4082083278dc32091f710b20adc27f8dc38c88c4278083107e370c8dc3e37,0x888887102083887e370e22221f78842e22222a21f70820820c9e370c88c91c4238082083209107e37095238dc20e0109,0x238dc2083247e370f8dc31c82621e2108e020838888841f8dd50838888841f8dd5dc38878880f70c90e21c30f8de21f7,0x20820825f8dc32072481c4278dd5e378820820afb22]
    decide +kernel
  exact e36266
end OMA.Blocks5_13_245212.S36266
