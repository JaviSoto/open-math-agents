import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S50664
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b50664 : Box := ![⟨95,126⟩,⟨23,24⟩,⟨127,1920000000000000011376⟩,⟨1,718295185477505923790⟩,⟨959,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,126⟩,⟨23,24⟩,⟨127,1920000000000000011376⟩,⟨1,718295185477505923790⟩,⟨959,999999999999999999⟩] := by
  have e50664 : Deny 5 13 b50664 := by
    apply closeAction rule_sound _ _ 64 [0x2e376f8cb8ddbe32e376f8cb8ddbe32e376f8cb8ddbe32e376f8cb8ddbe32e376f8cbbe326372f8ddbe3278be32e31ef,0x50b08788abc22368c78dd2e376f8cb8ddbe32e376f8cb8ddbe32e376f8cb8ddbe32e376f8cb8ddbe32e376f8cb8ddbe3,0x74b8dd2e374b8dd2e374b8dd2dc70388a72f88b72f88b72f88b72f88b72f88b72f88b72f88b0af88b0af88b74b74b74b,0x87d888c78dcbe32e372f8cb8dcbe32e372f8cb8dcbe32e372f8cb8dcbe32ef0820838c91e325cbc30878c9bc21f6223,0x72f0831c21e326374b8dd2e374b8dd2e326374bbe324808272f0838c90878c98c7be324209cbe326f087d87bdcbe326f,0x8cb8ddbe32e376f8cb8ddbe32e376f8cb8ddbe32e376f8cb8ddbe32e376f8cb8ddbe32e376f8cb2231f8be327808272f,0x74b74b8dd2e374b8dd2e374b8dd2e374b8dd2e374b8dd2e376f8cb8ddbe32e376f8cb8ddbe32e376f8cb8ddbe32e376f,0x8209c0832420c7bc327688774b74b74b74b88a8dd2e3]
    decide +kernel
  exact e50664
end OMA.Blocks5_13_245212.S50664
