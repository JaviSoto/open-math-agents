import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S62535
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b62535 : Box := ![⟨95,190⟩,⟨31,62⟩,⟨7,9⟩,⟨1,70⟩,⟨239,478⟩]
private def b62536 : Box := ![⟨95,190⟩,⟨31,62⟩,⟨7,9⟩,⟨1,2⟩,⟨239,478⟩]
private def b62537 : Box := ![⟨95,190⟩,⟨31,62⟩,⟨7,9⟩,⟨3,63⟩,⟨239,478⟩]
private def b62538 : Box := ![⟨95,190⟩,⟨31,41⟩,⟨7,9⟩,⟨3,63⟩,⟨239,478⟩]
private def b62539 : Box := ![⟨95,126⟩,⟨31,41⟩,⟨7,9⟩,⟨3,57⟩,⟨239,478⟩]
private def b62550 : Box := ![⟨127,190⟩,⟨31,41⟩,⟨7,9⟩,⟨3,57⟩,⟨239,478⟩]
private def b62551 : Box := ![⟨127,190⟩,⟨31,41⟩,⟨7,7⟩,⟨7,57⟩,⟨239,478⟩]
private def b62554 : Box := ![⟨127,190⟩,⟨31,41⟩,⟨8,9⟩,⟨7,57⟩,⟨239,478⟩]
private def b62555 : Box := ![⟨127,190⟩,⟨31,41⟩,⟨8,9⟩,⟨7,57⟩,⟨239,318⟩]
private def b62556 : Box := ![⟨127,190⟩,⟨31,35⟩,⟨8,9⟩,⟨7,57⟩,⟨239,317⟩]
private def b62563 : Box := ![⟨127,190⟩,⟨36,41⟩,⟨8,9⟩,⟨7,57⟩,⟨239,317⟩]
private def b62570 : Box := ![⟨127,190⟩,⟨31,41⟩,⟨8,9⟩,⟨7,57⟩,⟨319,478⟩]
private def b62571 : Box := ![⟨127,190⟩,⟨31,35⟩,⟨8,9⟩,⟨7,54⟩,⟨319,478⟩]
private def b62576 : Box := ![⟨127,190⟩,⟨36,41⟩,⟨8,9⟩,⟨7,54⟩,⟨319,478⟩]
private def b62583 : Box := ![⟨95,190⟩,⟨42,62⟩,⟨7,9⟩,⟨3,63⟩,⟨239,478⟩]
private def b62584 : Box := ![⟨95,126⟩,⟨42,62⟩,⟨7,9⟩,⟨3,63⟩,⟨239,478⟩]
private def b62585 : Box := ![⟨95,126⟩,⟨42,62⟩,⟨7,7⟩,⟨3,50⟩,⟨239,478⟩]
private def b62594 : Box := ![⟨95,126⟩,⟨42,62⟩,⟨8,9⟩,⟨3,50⟩,⟨239,478⟩]
private def b62595 : Box := ![⟨95,126⟩,⟨42,62⟩,⟨8,9⟩,⟨3,50⟩,⟨239,318⟩]
private def b62596 : Box := ![⟨95,126⟩,⟨42,50⟩,⟨8,9⟩,⟨3,50⟩,⟨239,317⟩]
private def b62597 : Box := ![⟨95,108⟩,⟨42,50⟩,⟨8,9⟩,⟨3,47⟩,⟨239,317⟩]
private def b62598 : Box := ![⟨95,108⟩,⟨42,50⟩,⟨8,9⟩,⟨3,43⟩,⟨239,272⟩]
private def b62599 : Box := ![⟨95,108⟩,⟨42,50⟩,⟨8,9⟩,⟨3,6⟩,⟨239,271⟩]
private def b62604 : Box := ![⟨95,108⟩,⟨42,50⟩,⟨8,9⟩,⟨7,43⟩,⟨239,271⟩]
private def b62615 : Box := ![⟨95,108⟩,⟨42,50⟩,⟨8,9⟩,⟨3,43⟩,⟨273,317⟩]
private def b62620 : Box := ![⟨109,126⟩,⟨42,50⟩,⟨8,9⟩,⟨3,47⟩,⟨239,317⟩]
private def b62621 : Box := ![⟨109,126⟩,⟨42,50⟩,⟨8,9⟩,⟨3,47⟩,⟨239,272⟩]
private def b62622 : Box := ![⟨109,126⟩,⟨42,50⟩,⟨8,9⟩,⟨3,6⟩,⟨239,271⟩]
private def b62627 : Box := ![⟨109,126⟩,⟨42,50⟩,⟨8,9⟩,⟨7,47⟩,⟨239,271⟩]
private def b62638 : Box := ![⟨109,126⟩,⟨42,50⟩,⟨8,9⟩,⟨3,47⟩,⟨273,317⟩]
private def b62645 : Box := ![⟨95,126⟩,⟨51,62⟩,⟨8,9⟩,⟨3,50⟩,⟨239,317⟩]
private def b62646 : Box := ![⟨95,126⟩,⟨51,62⟩,⟨8,9⟩,⟨3,6⟩,⟨239,317⟩]
private def b62647 : Box := ![⟨95,126⟩,⟨51,62⟩,⟨8,9⟩,⟨7,50⟩,⟨239,317⟩]
private def b62658 : Box := ![⟨95,126⟩,⟨42,62⟩,⟨8,9⟩,⟨3,50⟩,⟨319,478⟩]
private def b62659 : Box := ![⟨95,126⟩,⟨42,50⟩,⟨8,9⟩,⟨3,48⟩,⟨319,478⟩]
private def b62660 : Box := ![⟨95,108⟩,⟨42,50⟩,⟨8,9⟩,⟨3,45⟩,⟨319,478⟩]
private def b62665 : Box := ![⟨109,126⟩,⟨42,50⟩,⟨8,9⟩,⟨3,45⟩,⟨319,478⟩]
private def b62676 : Box := ![⟨95,126⟩,⟨51,62⟩,⟨8,9⟩,⟨3,48⟩,⟨319,478⟩]
private def b62677 : Box := ![⟨95,126⟩,⟨51,62⟩,⟨8,9⟩,⟨3,6⟩,⟨319,478⟩]
private def b62678 : Box := ![⟨95,126⟩,⟨51,62⟩,⟨8,9⟩,⟨7,48⟩,⟨319,478⟩]
private def b62679 : Box := ![⟨95,126⟩,⟨51,62⟩,⟨8,9⟩,⟨7,12⟩,⟨319,478⟩]
private def b62680 : Box := ![⟨95,126⟩,⟨51,62⟩,⟨8,9⟩,⟨7,8⟩,⟨319,478⟩]
private def b62691 : Box := ![⟨95,126⟩,⟨51,62⟩,⟨8,9⟩,⟨9,12⟩,⟨319,478⟩]
private def b62692 : Box := ![⟨95,126⟩,⟨51,62⟩,⟨8,9⟩,⟨13,48⟩,⟨319,478⟩]
private def b62693 : Box := ![⟨127,190⟩,⟨42,62⟩,⟨7,9⟩,⟨3,63⟩,⟨239,478⟩]
private def b62694 : Box := ![⟨127,190⟩,⟨42,62⟩,⟨7,7⟩,⟨3,63⟩,⟨239,478⟩]
private def b62705 : Box := ![⟨127,190⟩,⟨42,62⟩,⟨8,9⟩,⟨3,63⟩,⟨239,478⟩]
private def b62706 : Box := ![⟨127,190⟩,⟨42,62⟩,⟨8,9⟩,⟨3,63⟩,⟨239,318⟩]
private def b62717 : Box := ![⟨127,190⟩,⟨42,62⟩,⟨8,9⟩,⟨3,63⟩,⟨319,478⟩]
private def b62718 : Box := ![⟨127,190⟩,⟨42,50⟩,⟨8,9⟩,⟨3,60⟩,⟨319,478⟩]
private def b62719 : Box := ![⟨127,152⟩,⟨42,50⟩,⟨8,9⟩,⟨4,57⟩,⟨319,478⟩]
private def b62720 : Box := ![⟨127,152⟩,⟨42,50⟩,⟨8,9⟩,⟨4,8⟩,⟨319,478⟩]
private def b62721 : Box := ![⟨127,149⟩,⟨42,50⟩,⟨8,9⟩,⟨4,5⟩,⟨319,478⟩]
private def b62722 : Box := ![⟨127,149⟩,⟨42,50⟩,⟨8,9⟩,⟨6,8⟩,⟨319,478⟩]
private def b62723 : Box := ![⟨127,149⟩,⟨42,50⟩,⟨8,9⟩,⟨6,8⟩,⟨319,382⟩]
private def b62730 : Box := ![⟨127,149⟩,⟨42,50⟩,⟨8,9⟩,⟨6,8⟩,⟨383,478⟩]
private def b62737 : Box := ![⟨127,152⟩,⟨42,50⟩,⟨8,9⟩,⟨9,50⟩,⟨319,478⟩]
private def b62738 : Box := ![⟨153,190⟩,⟨42,50⟩,⟨8,9⟩,⟨4,57⟩,⟨319,478⟩]
private def b62739 : Box := ![⟨127,190⟩,⟨51,62⟩,⟨8,9⟩,⟨3,60⟩,⟨319,478⟩]
private theorem e62536 : Deny 5 13 b62536 := by
    apply closeAction rule_sound _ _ 64 [0x13960]
    decide +kernel
private theorem e62539 : Deny 5 13 b62539 := by
    apply closeAction rule_sound _ _ 64 [0xc3e378c86c2238de321be37244089e23]
    decide +kernel
private theorem e62551 : Deny 5 13 b62551 := by
    apply closeAction rule_sound _ _ 64 [0x1b9c4088e23]
    decide +kernel
private theorem e62556 : Deny 5 13 b62556 := by
    apply closeAction rule_sound _ _ 64 [0x1b643e202a78c86c99e3]
    decide +kernel
private theorem e62563 : Deny 5 13 b62563 := by
    apply closeAction rule_sound _ _ 64 [0x6e76e70f80f88c98c78c7]
    decide +kernel
private theorem e62555 : Deny 5 13 b62555 :=
    branchAction rule_sound _ _ 2
      0x204 b62555 b62556 b62563 (by decide +kernel) e62556 e62563
private theorem e62571 : Deny 5 13 b62571 := by
    apply closeAction rule_sound _ _ 64 [0x1b0889e31021f89e3]
    decide +kernel
private theorem e62576 : Deny 5 13 b62576 := by
    apply closeAction rule_sound _ _ 64 [0x6e70c3e23219e372788c7]
    decide +kernel
private theorem e62570 : Deny 5 13 b62570 :=
    branchAction rule_sound _ _ 2
      0x223 b62570 b62571 b62576 (by decide +kernel) e62571 e62576
private theorem e62554 : Deny 5 13 b62554 :=
    branchAction rule_sound _ _ 1
      0xb b62554 b62555 b62570 (by decide +kernel) e62555 e62570
private theorem e62550 : Deny 5 13 b62550 :=
    branchAction rule_sound _ _ 2
      0x267 b62550 b62551 b62554 (by decide +kernel) e62551 e62554
private theorem e62538 : Deny 5 13 b62538 :=
    branchAction rule_sound _ _ 2
      0x1e3 b62538 b62539 b62550 (by decide +kernel) e62539 e62550
private theorem e62585 : Deny 5 13 b62585 := by
    apply closeAction rule_sound _ _ 64 [0x1b6d32b82932a311be378c4238]
    decide +kernel
private theorem e62599 : Deny 5 13 b62599 := by
    apply closeAction rule_sound _ _ 64 [0x130c2248]
    decide +kernel
private theorem e62604 : Deny 5 13 b62604 := by
    apply closeAction rule_sound _ _ 64 [0x1b6c3e03203088e0928a]
    decide +kernel
private theorem e62598 : Deny 5 13 b62598 :=
    branchAction rule_sound _ _ 2
      0x284 b62598 b62599 b62604 (by decide +kernel) e62599 e62604
private theorem e62615 : Deny 5 13 b62615 := by
    apply closeAction rule_sound _ _ 64 [0x30f78c86f8dc98c4]
    decide +kernel
private theorem e62597 : Deny 5 13 b62597 :=
    branchAction rule_sound _ _ 2
      0x2e3 b62597 b62598 b62615 (by decide +kernel) e62598 e62615
private theorem e62622 : Deny 5 13 b62622 := by
    apply closeAction rule_sound _ _ 64 [0x4c30f8de0248]
    decide +kernel
private theorem e62627 : Deny 5 13 b62627 := by
    apply closeAction rule_sound _ _ 64 [0x1b6c20c8e370c320928a]
    decide +kernel
private theorem e62621 : Deny 5 13 b62621 :=
    branchAction rule_sound _ _ 2
      0x284 b62621 b62622 b62627 (by decide +kernel) e62622 e62627
private theorem e62638 : Deny 5 13 b62638 := by
    apply closeAction rule_sound _ _ 64 [0x13dc38c80dbe378c88c98c4]
    decide +kernel
private theorem e62620 : Deny 5 13 b62620 :=
    branchAction rule_sound _ _ 1
      0xb b62620 b62621 b62638 (by decide +kernel) e62621 e62638
private theorem e62596 : Deny 5 13 b62596 :=
    branchAction rule_sound _ _ 2
      0x1e3 b62596 b62597 b62620 (by decide +kernel) e62597 e62620
private theorem e62646 : Deny 5 13 b62646 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
private theorem e62647 : Deny 5 13 b62647 := by
    apply closeAction rule_sound _ _ 64 [0x1b6c20832041f84c928a]
    decide +kernel
private theorem e62645 : Deny 5 13 b62645 :=
    branchAction rule_sound _ _ 1
      0xa b62645 b62646 b62647 (by decide +kernel) e62646 e62647
private theorem e62595 : Deny 5 13 b62595 :=
    branchAction rule_sound _ _ 2
      0x204 b62595 b62596 b62645 (by decide +kernel) e62596 e62645
private theorem e62660 : Deny 5 13 b62660 := by
    apply closeAction rule_sound _ _ 64 [0xdbe378c8102278de3]
    decide +kernel
private theorem e62665 : Deny 5 13 b62665 := by
    apply closeAction rule_sound _ _ 64 [0x30f8de32022631030e321be3726310b]
    decide +kernel
private theorem e62659 : Deny 5 13 b62659 :=
    branchAction rule_sound _ _ 2
      0x1e3 b62659 b62660 b62665 (by decide +kernel) e62660 e62665
private theorem e62677 : Deny 5 13 b62677 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
private theorem e62680 : Deny 5 13 b62680 := by
    apply closeAction rule_sound _ _ 64 [0x4db0831db2442d3288]
    decide +kernel
private theorem e62691 : Deny 5 13 b62691 := by
    apply closeAction rule_sound _ _ 64 [0x1b]
    decide +kernel
private theorem e62679 : Deny 5 13 b62679 :=
    branchAction rule_sound _ _ 1
      0xa b62679 b62680 b62691 (by decide +kernel) e62680 e62691
private theorem e62692 : Deny 5 13 b62692 := by
    apply closeAction rule_sound _ _ 64 [0x1b]
    decide +kernel
private theorem e62678 : Deny 5 13 b62678 :=
    branchAction rule_sound _ _ 1
      0xa b62678 b62679 b62692 (by decide +kernel) e62679 e62692
private theorem e62676 : Deny 5 13 b62676 :=
    branchAction rule_sound _ _ 1
      0xa b62676 b62677 b62678 (by decide +kernel) e62677 e62678
private theorem e62658 : Deny 5 13 b62658 :=
    branchAction rule_sound _ _ 2
      0x223 b62658 b62659 b62676 (by decide +kernel) e62659 e62676
private theorem e62594 : Deny 5 13 b62594 :=
    branchAction rule_sound _ _ 1
      0xb b62594 b62595 b62658 (by decide +kernel) e62595 e62658
private theorem e62584 : Deny 5 13 b62584 :=
    branchAction rule_sound _ _ 2
      0x263 b62584 b62585 b62594 (by decide +kernel) e62585 e62594
private theorem e62694 : Deny 5 13 b62694 := by
    apply closeAction rule_sound _ _ 64 [0x1b6db4c3e25808e202b880a2939602a3]
    decide +kernel
private theorem e62706 : Deny 5 13 b62706 := by
    apply closeAction rule_sound _ _ 64 [0x13e376e7478ddb0f89e50c780a9c98c79e3204]
    decide +kernel
private theorem e62721 : Deny 5 13 b62721 := by
    apply closeAction rule_sound _ _ 64 [0x4e7960]
    decide +kernel
private theorem e62723 : Deny 5 13 b62723 := by
    apply closeAction rule_sound _ _ 64 [0x838080c2808809804]
    decide +kernel
private theorem e62730 : Deny 5 13 b62730 := by
    apply closeAction rule_sound _ _ 64 [0x3e250c70f8804088e20244]
    decide +kernel
private theorem e62722 : Deny 5 13 b62722 :=
    branchAction rule_sound _ _ 1
      0xb b62722 b62723 b62730 (by decide +kernel) e62723 e62730
private theorem e62720 : Deny 5 13 b62720 :=
    branchAction rule_sound _ _ 2
      0x2a0 b62720 b62721 b62722 (by decide +kernel) e62721 e62722
private theorem e62737 : Deny 5 13 b62737 := by
    apply closeAction rule_sound _ _ 64 [0x1b]
    decide +kernel
private theorem e62719 : Deny 5 13 b62719 :=
    branchAction rule_sound _ _ 2
      0x2a3 b62719 b62720 b62737 (by decide +kernel) e62720 e62737
private theorem e62738 : Deny 5 13 b62738 := by
    apply closeAction rule_sound _ _ 64 [0x6e7]
    decide +kernel
private theorem e62718 : Deny 5 13 b62718 :=
    branchAction rule_sound _ _ 3
      0x79e3 b62718 b62719 b62738 (by decide +kernel) e62719 e62738
private theorem e62739 : Deny 5 13 b62739 := by
    apply closeAction rule_sound _ _ 64 [0x13e376db6d32a028ae13289]
    decide +kernel
private theorem e62717 : Deny 5 13 b62717 :=
    branchAction rule_sound _ _ 2
      0x223 b62717 b62718 b62739 (by decide +kernel) e62718 e62739
private theorem e62705 : Deny 5 13 b62705 :=
    branchAction rule_sound _ _ 1
      0xb b62705 b62706 b62717 (by decide +kernel) e62706 e62717
private theorem e62693 : Deny 5 13 b62693 :=
    branchAction rule_sound _ _ 1
      0x9 b62693 b62694 b62705 (by decide +kernel) e62694 e62705
private theorem e62583 : Deny 5 13 b62583 :=
    branchAction rule_sound _ _ 1
      0x7 b62583 b62584 b62693 (by decide +kernel) e62584 e62693
private theorem e62537 : Deny 5 13 b62537 :=
    branchAction rule_sound _ _ 1
      0x8 b62537 b62538 b62583 (by decide +kernel) e62538 e62583
private theorem e62535 : Deny 5 13 b62535 :=
    branchAction rule_sound _ _ 2
      0x2a3 b62535 b62536 b62537 (by decide +kernel) e62536 e62537
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨31,62⟩,⟨7,9⟩,⟨1,70⟩,⟨239,478⟩] := by
  exact e62535
end OMA.Blocks5_13_245212.S62535
