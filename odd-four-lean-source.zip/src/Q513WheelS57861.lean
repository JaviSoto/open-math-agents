import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S57861
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b57861 : Box := ![⟨76,94⟩,⟨42,62⟩,⟨15,30⟩,⟨1,54⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨76,94⟩,⟨42,62⟩,⟨15,30⟩,⟨1,54⟩,⟨479,999999999999999999⟩] := by
  have e57861 : Deny 5 13 b57861 := by
    apply closeAction rule_sound _ _ 64 [0x2631c30e32032430f88c80f8de32631e32632237df0824c92780970c91f80832380c9e03e0320324724828a5ca8cb8c9,0x1f8083e03e09e232380838c90e31c30c78c88df7c20c7e03e031c84ca28a4ca8cb8c78c9083e232380e3243e038c80e3,0x820820f81f88c8e020f88c7e03e031e3223263082083e231e32388c98cbe231f88c8e020820f81f88c8e23]
    decide +kernel
  exact e57861
end OMA.Blocks5_13_245212.S57861
