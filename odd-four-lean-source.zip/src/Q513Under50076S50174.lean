import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S50174
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b50174 : Box := ![⟨153,190⟩,⟨23,24⟩,⟨31,41⟩,⟨1,59⟩,⟨959,1918⟩]
private def b50175 : Box := ![⟨153,190⟩,⟨23,23⟩,⟨31,41⟩,⟨2,54⟩,⟨959,1918⟩]
private def b50176 : Box := ![⟨153,190⟩,⟨23,23⟩,⟨31,41⟩,⟨2,4⟩,⟨959,1918⟩]
private def b50177 : Box := ![⟨153,190⟩,⟨23,23⟩,⟨31,41⟩,⟨5,54⟩,⟨959,1918⟩]
private def b50178 : Box := ![⟨153,190⟩,⟨23,23⟩,⟨31,41⟩,⟨5,9⟩,⟨1009,1918⟩]
private def b50179 : Box := ![⟨153,190⟩,⟨23,23⟩,⟨31,41⟩,⟨5,9⟩,⟨1009,1322⟩]
private def b50180 : Box := ![⟨153,190⟩,⟨23,23⟩,⟨31,41⟩,⟨5,9⟩,⟨1323,1918⟩]
private def b50181 : Box := ![⟨153,169⟩,⟨23,23⟩,⟨31,41⟩,⟨5,9⟩,⟨1323,1918⟩]
private def b50182 : Box := ![⟨153,160⟩,⟨23,23⟩,⟨31,41⟩,⟨5,9⟩,⟨1323,1918⟩]
private def b50183 : Box := ![⟨161,169⟩,⟨23,23⟩,⟨31,41⟩,⟨5,9⟩,⟨1323,1918⟩]
private def b50184 : Box := ![⟨170,190⟩,⟨23,23⟩,⟨31,41⟩,⟨5,9⟩,⟨1323,1918⟩]
private def b50185 : Box := ![⟨170,190⟩,⟨23,23⟩,⟨31,35⟩,⟨5,9⟩,⟨1660,1918⟩]
private def b50186 : Box := ![⟨170,190⟩,⟨23,23⟩,⟨36,41⟩,⟨5,9⟩,⟨1660,1918⟩]
private def b50187 : Box := ![⟨153,190⟩,⟨23,23⟩,⟨31,41⟩,⟨10,54⟩,⟨1009,1918⟩]
private def b50188 : Box := ![⟨153,190⟩,⟨24,24⟩,⟨31,41⟩,⟨2,54⟩,⟨959,1918⟩]
private theorem e50176 : Deny 5 13 b50176 := by
    apply closeAction rule_sound _ _ 64 [0x159a0]
    decide +kernel
private theorem e50179 : Deny 5 13 b50179 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e50182 : Deny 5 13 b50182 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e50183 : Deny 5 13 b50183 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e50181 : Deny 5 13 b50181 :=
    branchAction rule_sound _ _ 1
      0x7 b50181 b50182 b50183 (by decide +kernel) e50182 e50183
private theorem e50185 : Deny 5 13 b50185 := by
    apply closeAction rule_sound _ _ 64 [0xf89e0]
    decide +kernel
private theorem e50186 : Deny 5 13 b50186 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e50184 : Deny 5 13 b50184 :=
    branchAction rule_sound _ _ 2
      0x278 b50184 b50185 b50186 (by decide +kernel) e50185 e50186
private theorem e50180 : Deny 5 13 b50180 :=
    branchAction rule_sound _ _ 1
      0x7 b50180 b50181 b50184 (by decide +kernel) e50181 e50184
private theorem e50178 : Deny 5 13 b50178 :=
    branchAction rule_sound _ _ 1
      0xb b50178 b50179 b50180 (by decide +kernel) e50179 e50180
private theorem e50187 : Deny 5 13 b50187 := by
    apply closeAction rule_sound _ _ 64 [0x1d]
    decide +kernel
private theorem e50177 : Deny 5 13 b50177 :=
    branchAction rule_sound _ _ 2
      0x2b8 b50177 b50178 b50187 (by decide +kernel) e50178 e50187
private theorem e50175 : Deny 5 13 b50175 :=
    branchAction rule_sound _ _ 1
      0xa b50175 b50176 b50177 (by decide +kernel) e50176 e50177
private theorem e50188 : Deny 5 13 b50188 := by
    apply closeAction rule_sound _ _ 64 [0x15e37]
    decide +kernel
private theorem e50174 : Deny 5 13 b50174 :=
    branchAction rule_sound _ _ 3
      0x89e3 b50174 b50175 b50188 (by decide +kernel) e50175 e50188
theorem deny5_13 : Deny 5 13 ![⟨153,190⟩,⟨23,24⟩,⟨31,41⟩,⟨1,59⟩,⟨959,1918⟩] := by
  exact e50174
end OMA.Blocks5_13_245212.S50174
