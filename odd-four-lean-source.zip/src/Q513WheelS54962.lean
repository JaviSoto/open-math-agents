import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S54962
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b54962 : Box := ![⟨54,62⟩,⟨127,254⟩,⟨12,14⟩,⟨2,451586424625098660952⟩,⟨959,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨54,62⟩,⟨127,254⟩,⟨12,14⟩,⟨2,451586424625098660952⟩,⟨959,999999999999999999⟩] := by
  have e54962 : Deny 5 13 b54962 := by
    apply closeAction rule_sound _ _ 64 [0x8cbac3e02278ae36b8df5ae31f88c80898daada0eb0c868284ae211c3ac3203ac3e08847ae12e128226322b8cb8c7ae3,0x682083248e03e2b0c8e2b847e1b6f8847ae12612a322b8cb0c3d47df51e36ab8cb8daae32c22636ab8cb8daae32e36ab,0xae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cbac3e038c80c70c3e232076eb8c21f82632236ab,0x2d22d22e12a36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8da,0xada68384a6ab84b0abaa884b48b48b48b48b48b84a08921aae12daae12daae12daae12daae12daae12daae12c2aeaa21,0x69a]
    decide +kernel
  exact e54962
end OMA.Blocks5_13_245212.S54962
