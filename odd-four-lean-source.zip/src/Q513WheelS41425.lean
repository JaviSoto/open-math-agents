import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S41425
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b41425 : Box := ![⟨63,94⟩,⟨21,24⟩,⟨31,62⟩,⟨3,900178041543026711602⟩,⟨239,478⟩]
private def b41426 : Box := ![⟨63,75⟩,⟨21,24⟩,⟨31,62⟩,⟨3,58⟩,⟨239,478⟩]
private def b41427 : Box := ![⟨63,75⟩,⟨21,24⟩,⟨31,62⟩,⟨3,54⟩,⟨239,298⟩]
private def b41428 : Box := ![⟨63,75⟩,⟨21,22⟩,⟨31,62⟩,⟨3,54⟩,⟨239,293⟩]
private def b41439 : Box := ![⟨63,75⟩,⟨23,24⟩,⟨31,62⟩,⟨3,54⟩,⟨239,293⟩]
private def b41440 : Box := ![⟨63,75⟩,⟨23,24⟩,⟨31,62⟩,⟨3,6⟩,⟨239,293⟩]
private def b41441 : Box := ![⟨63,75⟩,⟨23,24⟩,⟨31,41⟩,⟨3,6⟩,⟨239,293⟩]
private def b41446 : Box := ![⟨63,75⟩,⟨23,24⟩,⟨42,62⟩,⟨3,6⟩,⟨239,293⟩]
private def b41447 : Box := ![⟨63,68⟩,⟨23,24⟩,⟨42,62⟩,⟨3,6⟩,⟨239,293⟩]
private def b41452 : Box := ![⟨69,75⟩,⟨23,24⟩,⟨42,62⟩,⟨3,6⟩,⟨239,293⟩]
private def b41453 : Box := ![⟨69,75⟩,⟨23,24⟩,⟨42,62⟩,⟨3,6⟩,⟨239,263⟩]
private def b41460 : Box := ![⟨69,75⟩,⟨23,24⟩,⟨42,62⟩,⟨3,6⟩,⟨264,293⟩]
private def b41467 : Box := ![⟨63,75⟩,⟨23,24⟩,⟨31,62⟩,⟨7,54⟩,⟨239,293⟩]
private def b41468 : Box := ![⟨63,75⟩,⟨21,24⟩,⟨31,62⟩,⟨3,54⟩,⟨299,397⟩]
private def b41469 : Box := ![⟨63,75⟩,⟨21,22⟩,⟨37,62⟩,⟨4,52⟩,⟨307,397⟩]
private def b41470 : Box := ![⟨63,75⟩,⟨23,24⟩,⟨37,62⟩,⟨4,52⟩,⟨307,397⟩]
private def b41471 : Box := ![⟨63,68⟩,⟨23,24⟩,⟨37,62⟩,⟨4,52⟩,⟨307,397⟩]
private def b41472 : Box := ![⟨69,75⟩,⟨23,24⟩,⟨37,62⟩,⟨4,52⟩,⟨307,397⟩]
private def b41483 : Box := ![⟨76,94⟩,⟨21,24⟩,⟨31,62⟩,⟨3,58⟩,⟨239,478⟩]
private def b41484 : Box := ![⟨76,94⟩,⟨21,24⟩,⟨31,62⟩,⟨3,58⟩,⟨239,318⟩]
private def b41485 : Box := ![⟨76,94⟩,⟨21,22⟩,⟨31,62⟩,⟨3,58⟩,⟨239,317⟩]
private def b41486 : Box := ![⟨76,94⟩,⟨21,22⟩,⟨31,41⟩,⟨3,57⟩,⟨239,317⟩]
private def b41495 : Box := ![⟨76,94⟩,⟨21,22⟩,⟨42,62⟩,⟨3,57⟩,⟨239,317⟩]
private def b41496 : Box := ![⟨76,84⟩,⟨21,22⟩,⟨42,62⟩,⟨3,57⟩,⟨239,317⟩]
private def b41497 : Box := ![⟨76,84⟩,⟨21,22⟩,⟨42,62⟩,⟨3,55⟩,⟨239,272⟩]
private def b41506 : Box := ![⟨76,84⟩,⟨21,22⟩,⟨42,62⟩,⟨3,55⟩,⟨273,317⟩]
private def b41517 : Box := ![⟨85,94⟩,⟨21,22⟩,⟨42,62⟩,⟨3,57⟩,⟨239,317⟩]
private def b41518 : Box := ![⟨85,94⟩,⟨21,22⟩,⟨42,62⟩,⟨3,6⟩,⟨239,317⟩]
private def b41519 : Box := ![⟨85,94⟩,⟨21,22⟩,⟨42,62⟩,⟨7,57⟩,⟨239,317⟩]
private def b41520 : Box := ![⟨85,94⟩,⟨21,22⟩,⟨42,62⟩,⟨7,13⟩,⟨239,317⟩]
private def b41521 : Box := ![⟨85,94⟩,⟨21,22⟩,⟨42,62⟩,⟨7,13⟩,⟨239,272⟩]
private def b41522 : Box := ![⟨85,94⟩,⟨21,22⟩,⟨42,62⟩,⟨7,13⟩,⟨273,317⟩]
private def b41533 : Box := ![⟨85,94⟩,⟨21,22⟩,⟨42,62⟩,⟨14,57⟩,⟨239,317⟩]
private def b41534 : Box := ![⟨76,94⟩,⟨23,24⟩,⟨31,62⟩,⟨3,58⟩,⟨239,317⟩]
private def b41535 : Box := ![⟨76,94⟩,⟨23,24⟩,⟨31,62⟩,⟨3,6⟩,⟨239,317⟩]
private def b41536 : Box := ![⟨76,94⟩,⟨23,24⟩,⟨31,62⟩,⟨3,4⟩,⟨239,317⟩]
private def b41537 : Box := ![⟨76,94⟩,⟨23,24⟩,⟨31,62⟩,⟨5,6⟩,⟨239,317⟩]
private def b41538 : Box := ![⟨76,94⟩,⟨23,24⟩,⟨31,62⟩,⟨5,5⟩,⟨239,317⟩]
private def b41539 : Box := ![⟨76,94⟩,⟨23,24⟩,⟨31,41⟩,⟨5,5⟩,⟨239,317⟩]
private def b41546 : Box := ![⟨76,94⟩,⟨23,24⟩,⟨42,62⟩,⟨5,5⟩,⟨239,317⟩]
private def b41553 : Box := ![⟨76,94⟩,⟨23,24⟩,⟨31,62⟩,⟨6,6⟩,⟨239,317⟩]
private def b41554 : Box := ![⟨76,94⟩,⟨23,24⟩,⟨31,62⟩,⟨7,58⟩,⟨239,317⟩]
private def b41555 : Box := ![⟨76,94⟩,⟨21,24⟩,⟨31,62⟩,⟨3,58⟩,⟨319,478⟩]
private def b41556 : Box := ![⟨76,94⟩,⟨21,22⟩,⟨31,62⟩,⟨3,55⟩,⟨319,478⟩]
private def b41557 : Box := ![⟨76,84⟩,⟨21,22⟩,⟨32,62⟩,⟨3,54⟩,⟨319,478⟩]
private def b41562 : Box := ![⟨85,94⟩,⟨21,22⟩,⟨32,62⟩,⟨3,54⟩,⟨319,478⟩]
private def b41571 : Box := ![⟨76,94⟩,⟨23,24⟩,⟨31,62⟩,⟨3,55⟩,⟨319,478⟩]
private def b41572 : Box := ![⟨76,94⟩,⟨23,24⟩,⟨31,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b41573 : Box := ![⟨76,94⟩,⟨23,24⟩,⟨31,62⟩,⟨3,4⟩,⟨319,478⟩]
private def b41574 : Box := ![⟨76,94⟩,⟨23,24⟩,⟨31,62⟩,⟨5,6⟩,⟨319,478⟩]
private def b41575 : Box := ![⟨76,94⟩,⟨23,24⟩,⟨31,62⟩,⟨5,5⟩,⟨319,478⟩]
private def b41576 : Box := ![⟨76,94⟩,⟨23,24⟩,⟨31,41⟩,⟨5,5⟩,⟨319,478⟩]
private def b41583 : Box := ![⟨76,94⟩,⟨23,24⟩,⟨42,62⟩,⟨5,5⟩,⟨319,478⟩]
private def b41590 : Box := ![⟨76,94⟩,⟨23,24⟩,⟨31,62⟩,⟨6,6⟩,⟨319,478⟩]
private def b41591 : Box := ![⟨76,94⟩,⟨23,24⟩,⟨31,62⟩,⟨7,55⟩,⟨319,478⟩]
private theorem e41428 : Deny 5 13 b41428 := by
    apply closeAction rule_sound _ _ 64 [0x7f7da311f7c3e37da22b628b778df621de37da31f7da3]
    decide +kernel
private theorem e41441 : Deny 5 13 b41441 := by
    apply closeAction rule_sound _ _ 64 [0x30f8dc91021f8]
    decide +kernel
private theorem e41447 : Deny 5 13 b41447 := by
    apply closeAction rule_sound _ _ 64 [0x30f8dc911fe37da2107e36]
    decide +kernel
private theorem e41453 : Deny 5 13 b41453 := by
    apply closeAction rule_sound _ _ 64 [0xc31c30f71c9]
    decide +kernel
private theorem e41460 : Deny 5 13 b41460 := by
    apply closeAction rule_sound _ _ 64 [0x30f71c3088244]
    decide +kernel
private theorem e41452 : Deny 5 13 b41452 :=
    branchAction rule_sound _ _ 1
      0xb b41452 b41453 b41460 (by decide +kernel) e41453 e41460
private theorem e41446 : Deny 5 13 b41446 :=
    branchAction rule_sound _ _ 1
      0x7 b41446 b41447 b41452 (by decide +kernel) e41447 e41452
private theorem e41440 : Deny 5 13 b41440 :=
    branchAction rule_sound _ _ 1
      0x9 b41440 b41441 b41446 (by decide +kernel) e41441 e41446
private theorem e41467 : Deny 5 13 b41467 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e41439 : Deny 5 13 b41439 :=
    branchAction rule_sound _ _ 1
      0xa b41439 b41440 b41467 (by decide +kernel) e41440 e41467
private theorem e41427 : Deny 5 13 b41427 :=
    branchAction rule_sound _ _ 2
      0x204 b41427 b41428 b41439 (by decide +kernel) e41428 e41439
private theorem e41469 : Deny 5 13 b41469 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e41471 : Deny 5 13 b41471 := by
    apply closeAction rule_sound _ _ 64 [0x1ce37da3]
    decide +kernel
private theorem e41472 : Deny 5 13 b41472 := by
    apply closeAction rule_sound _ _ 64 [0x1fde37c37f8df61dfe37d882842dfe378c9]
    decide +kernel
private theorem e41470 : Deny 5 13 b41470 :=
    branchAction rule_sound _ _ 1
      0x7 b41470 b41471 b41472 (by decide +kernel) e41471 e41472
private theorem e41468 : Deny 5 13 b41468 :=
    branchAction rule_sound _ _ 5
      0x8df68c4 b41468 b41469 b41470 (by decide +kernel) e41469 e41470
private theorem e41426 : Deny 5 13 b41426 :=
    branchAction rule_sound _ _ 3
      0xbe23 b41426 b41427 b41468 (by decide +kernel) e41427 e41468
private theorem e41486 : Deny 5 13 b41486 := by
    apply closeAction rule_sound _ _ 64 [0xc38c70e3243103e37d84238de31e3]
    decide +kernel
private theorem e41497 : Deny 5 13 b41497 := by
    apply closeAction rule_sound _ _ 64 [0x75f2950c3e37247284]
    decide +kernel
private theorem e41506 : Deny 5 13 b41506 := by
    apply closeAction rule_sound _ _ 64 [0x1f75fe3610ae368c80c221fe37d87d8a8c4]
    decide +kernel
private theorem e41496 : Deny 5 13 b41496 :=
    branchAction rule_sound _ _ 2
      0x2e3 b41496 b41497 b41506 (by decide +kernel) e41497 e41506
private theorem e41518 : Deny 5 13 b41518 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
private theorem e41521 : Deny 5 13 b41521 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e41522 : Deny 5 13 b41522 := by
    apply closeAction rule_sound _ _ 64 [0x1f743e031df24a7ca204]
    decide +kernel
private theorem e41520 : Deny 5 13 b41520 :=
    branchAction rule_sound _ _ 1
      0xb b41520 b41521 b41522 (by decide +kernel) e41521 e41522
private theorem e41533 : Deny 5 13 b41533 := by
    apply closeAction rule_sound _ _ 64 [0x1d]
    decide +kernel
private theorem e41519 : Deny 5 13 b41519 :=
    branchAction rule_sound _ _ 1
      0xa b41519 b41520 b41533 (by decide +kernel) e41520 e41533
private theorem e41517 : Deny 5 13 b41517 :=
    branchAction rule_sound _ _ 1
      0xa b41517 b41518 b41519 (by decide +kernel) e41518 e41519
private theorem e41495 : Deny 5 13 b41495 :=
    branchAction rule_sound _ _ 1
      0x7 b41495 b41496 b41517 (by decide +kernel) e41496 e41517
private theorem e41485 : Deny 5 13 b41485 :=
    branchAction rule_sound _ _ 2
      0x263 b41485 b41486 b41495 (by decide +kernel) e41486 e41495
private theorem e41536 : Deny 5 13 b41536 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
private theorem e41539 : Deny 5 13 b41539 := by
    apply closeAction rule_sound _ _ 64 [0x543109e030f8207]
    decide +kernel
private theorem e41546 : Deny 5 13 b41546 := by
    apply closeAction rule_sound _ _ 64 [0x5550f80c91c41f8]
    decide +kernel
private theorem e41538 : Deny 5 13 b41538 :=
    branchAction rule_sound _ _ 1
      0x9 b41538 b41539 b41546 (by decide +kernel) e41539 e41546
private theorem e41553 : Deny 5 13 b41553 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e41537 : Deny 5 13 b41537 :=
    branchAction rule_sound _ _ 1
      0xa b41537 b41538 b41553 (by decide +kernel) e41538 e41553
private theorem e41535 : Deny 5 13 b41535 :=
    branchAction rule_sound _ _ 1
      0xa b41535 b41536 b41537 (by decide +kernel) e41536 e41537
private theorem e41554 : Deny 5 13 b41554 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e41534 : Deny 5 13 b41534 :=
    branchAction rule_sound _ _ 1
      0xa b41534 b41535 b41554 (by decide +kernel) e41535 e41554
private theorem e41484 : Deny 5 13 b41484 :=
    branchAction rule_sound _ _ 2
      0x204 b41484 b41485 b41534 (by decide +kernel) e41485 e41534
private theorem e41557 : Deny 5 13 b41557 := by
    apply closeAction rule_sound _ _ 64 [0x3088df6102107e37da3]
    decide +kernel
private theorem e41562 : Deny 5 13 b41562 := by
    apply closeAction rule_sound _ _ 64 [0x75f0f6102107e36238d8a578d8a]
    decide +kernel
private theorem e41556 : Deny 5 13 b41556 :=
    branchAction rule_sound _ _ 3
      0x7da3 b41556 b41557 b41562 (by decide +kernel) e41557 e41562
private theorem e41573 : Deny 5 13 b41573 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
private theorem e41576 : Deny 5 13 b41576 := by
    apply closeAction rule_sound _ _ 64 [0x1f543243e361c42f8]
    decide +kernel
private theorem e41583 : Deny 5 13 b41583 := by
    apply closeAction rule_sound _ _ 64 [0x15543103e36109e07e07]
    decide +kernel
private theorem e41575 : Deny 5 13 b41575 :=
    branchAction rule_sound _ _ 1
      0x9 b41575 b41576 b41583 (by decide +kernel) e41576 e41583
private theorem e41590 : Deny 5 13 b41590 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e41574 : Deny 5 13 b41574 :=
    branchAction rule_sound _ _ 1
      0xa b41574 b41575 b41590 (by decide +kernel) e41575 e41590
private theorem e41572 : Deny 5 13 b41572 :=
    branchAction rule_sound _ _ 1
      0xa b41572 b41573 b41574 (by decide +kernel) e41573 e41574
private theorem e41591 : Deny 5 13 b41591 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e41571 : Deny 5 13 b41571 :=
    branchAction rule_sound _ _ 1
      0xa b41571 b41572 b41591 (by decide +kernel) e41572 e41591
private theorem e41555 : Deny 5 13 b41555 :=
    branchAction rule_sound _ _ 2
      0x223 b41555 b41556 b41571 (by decide +kernel) e41556 e41571
private theorem e41483 : Deny 5 13 b41483 :=
    branchAction rule_sound _ _ 1
      0xb b41483 b41484 b41555 (by decide +kernel) e41484 e41555
private theorem e41425 : Deny 5 13 b41425 :=
    branchAction rule_sound _ _ 2
      0x1e3 b41425 b41426 b41483 (by decide +kernel) e41426 e41483
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨21,24⟩,⟨31,62⟩,⟨3,900178041543026711602⟩,⟨239,478⟩] := by
  exact e41425
end OMA.Blocks5_13_245212.S41425
