import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S6572
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b6572 : Box := ![⟨15,22⟩,⟨15,30⟩,⟨5,1920000000000000011376⟩,⟨1,1920000000000000011376⟩,⟨53,151⟩]
theorem deny5_13 : Deny 5 13 ![⟨15,22⟩,⟨15,30⟩,⟨5,1920000000000000011376⟩,⟨1,1920000000000000011376⟩,⟨53,151⟩] := by
  have e6572 : Deny 5 13 b6572 := by
    apply closeAction rule_sound _ _ 64 [0x29ce37d878c80c21c4088e37d6228b0c3df68c8087d84088e37da325cbc472f8c4278df68c7738df68c8d84087e37da3,0x263203dc38870c288788888a10b703df688a11cdf68c4238df68c78c972f72f8c90dcde3244737da3108e23243e37da2,0xbdc0f62821c4088e37da324288a087738df68c8df68c472f72f8c9bc30f78c9737d87737da32378c40838c90838c70e3,0x72f72f8c9]
    decide +kernel
  exact e6572
end OMA.Blocks5_13_245212.S6572
