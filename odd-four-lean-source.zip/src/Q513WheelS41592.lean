import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S41592
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b41592 : Box := ![⟨63,94⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711602⟩,⟨239,478⟩]
private def b41593 : Box := ![⟨63,75⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711602⟩,⟨239,478⟩]
private def b41594 : Box := ![⟨63,75⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711598⟩,⟨239,318⟩]
private def b41595 : Box := ![⟨63,75⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨3,6⟩,⟨239,317⟩]
private def b41596 : Box := ![⟨63,75⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨7,900178041543026711598⟩,⟨239,317⟩]
private def b41597 : Box := ![⟨63,75⟩,⟨21,22⟩,⟨63,1920000000000000011376⟩,⟨7,900178041543026711598⟩,⟨239,317⟩]
private def b41608 : Box := ![⟨63,75⟩,⟨23,24⟩,⟨63,1920000000000000011376⟩,⟨7,900178041543026711598⟩,⟨239,317⟩]
private def b41613 : Box := ![⟨63,75⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711598⟩,⟨319,478⟩]
private def b41614 : Box := ![⟨63,75⟩,⟨21,22⟩,⟨63,1920000000000000011376⟩,⟨3,855338345864661659235⟩,⟨319,478⟩]
private def b41623 : Box := ![⟨63,75⟩,⟨23,24⟩,⟨63,1920000000000000011376⟩,⟨3,855338345864661659235⟩,⟨319,478⟩]
private def b41634 : Box := ![⟨76,94⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711602⟩,⟨239,478⟩]
private def b41635 : Box := ![⟨76,94⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711602⟩,⟨239,318⟩]
private def b41636 : Box := ![⟨76,94⟩,⟨21,22⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711602⟩,⟨239,317⟩]
private def b41637 : Box := ![⟨76,94⟩,⟨21,22⟩,⟨63,126⟩,⟨3,900178041543026711601⟩,⟨239,317⟩]
private def b41638 : Box := ![⟨76,94⟩,⟨21,22⟩,⟨63,84⟩,⟨3,87⟩,⟨239,317⟩]
private def b41639 : Box := ![⟨76,84⟩,⟨21,22⟩,⟨63,84⟩,⟨3,68⟩,⟨239,317⟩]
private def b41640 : Box := ![⟨76,84⟩,⟨21,22⟩,⟨63,84⟩,⟨4,65⟩,⟨239,272⟩]
private def b41651 : Box := ![⟨76,84⟩,⟨21,22⟩,⟨63,84⟩,⟨4,65⟩,⟨273,317⟩]
private def b41652 : Box := ![⟨76,84⟩,⟨21,22⟩,⟨63,84⟩,⟨4,8⟩,⟨277,317⟩]
private def b41655 : Box := ![⟨76,84⟩,⟨21,22⟩,⟨63,84⟩,⟨9,64⟩,⟨277,317⟩]
private def b41664 : Box := ![⟨85,94⟩,⟨21,22⟩,⟨63,84⟩,⟨3,68⟩,⟨239,317⟩]
private def b41675 : Box := ![⟨76,94⟩,⟨21,22⟩,⟨85,126⟩,⟨3,87⟩,⟨239,317⟩]
private def b41676 : Box := ![⟨76,94⟩,⟨21,22⟩,⟨127,1920000000000000011376⟩,⟨3,900178041543026711601⟩,⟨239,317⟩]
private def b41679 : Box := ![⟨76,94⟩,⟨23,24⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711602⟩,⟨239,317⟩]
private def b41686 : Box := ![⟨76,94⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711602⟩,⟨319,478⟩]
private def b41687 : Box := ![⟨76,94⟩,⟨21,22⟩,⟨63,1920000000000000011376⟩,⟨3,855338345864661659238⟩,⟨319,478⟩]
private def b41688 : Box := ![⟨76,94⟩,⟨21,22⟩,⟨63,126⟩,⟨3,855338345864661659238⟩,⟨319,478⟩]
private def b41689 : Box := ![⟨76,94⟩,⟨21,22⟩,⟨63,84⟩,⟨3,83⟩,⟨319,478⟩]
private def b41690 : Box := ![⟨76,84⟩,⟨21,22⟩,⟨63,84⟩,⟨3,64⟩,⟨319,478⟩]
private def b41691 : Box := ![⟨76,84⟩,⟨21,22⟩,⟨63,84⟩,⟨4,62⟩,⟨319,365⟩]
private def b41698 : Box := ![⟨76,84⟩,⟨21,22⟩,⟨63,84⟩,⟨4,62⟩,⟨366,427⟩]
private def b41705 : Box := ![⟨85,94⟩,⟨21,22⟩,⟨63,84⟩,⟨3,64⟩,⟨319,478⟩]
private def b41716 : Box := ![⟨76,94⟩,⟨21,22⟩,⟨85,126⟩,⟨3,83⟩,⟨319,478⟩]
private def b41717 : Box := ![⟨76,94⟩,⟨21,22⟩,⟨127,1920000000000000011376⟩,⟨3,855338345864661659238⟩,⟨319,478⟩]
private def b41720 : Box := ![⟨76,94⟩,⟨23,24⟩,⟨63,1920000000000000011376⟩,⟨3,855338345864661659238⟩,⟨319,478⟩]
private def b41721 : Box := ![⟨76,94⟩,⟨23,24⟩,⟨63,126⟩,⟨3,855338345864661659238⟩,⟨319,478⟩]
private def b41722 : Box := ![⟨76,84⟩,⟨23,24⟩,⟨63,126⟩,⟨3,84⟩,⟨319,478⟩]
private def b41729 : Box := ![⟨85,94⟩,⟨23,24⟩,⟨63,126⟩,⟨3,84⟩,⟨319,478⟩]
private def b41736 : Box := ![⟨76,94⟩,⟨23,24⟩,⟨127,1920000000000000011376⟩,⟨3,855338345864661659238⟩,⟨319,478⟩]
private theorem e41595 : Deny 5 13 b41595 := by
    apply closeAction rule_sound _ _ 64 [0xefb22]
    decide +kernel
private theorem e41597 : Deny 5 13 b41597 := by
    apply closeAction rule_sound _ _ 64 [0x72f72f8c9bddbdd7dfe22108e222a3263263]
    decide +kernel
private theorem e41608 : Deny 5 13 b41608 := by
    apply closeAction rule_sound _ _ 64 [0x72f8c472f8c4278bdf8c9]
    decide +kernel
private theorem e41596 : Deny 5 13 b41596 :=
    branchAction rule_sound _ _ 1
      0x8 b41596 b41597 b41608 (by decide +kernel) e41597 e41608
private theorem e41594 : Deny 5 13 b41594 :=
    branchAction rule_sound _ _ 2
      0x284 b41594 b41595 b41596 (by decide +kernel) e41595 e41596
private theorem e41614 : Deny 5 13 b41614 := by
    apply closeAction rule_sound _ _ 64 [0x72f709bdde368c9d8288a50ada3]
    decide +kernel
private theorem e41623 : Deny 5 13 b41623 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdc25c8c97e229f88a0f8bec88a]
    decide +kernel
private theorem e41613 : Deny 5 13 b41613 :=
    branchAction rule_sound _ _ 2
      0x223 b41613 b41614 b41623 (by decide +kernel) e41614 e41623
private theorem e41593 : Deny 5 13 b41593 :=
    branchAction rule_sound _ _ 2
      0x2e3 b41593 b41594 b41613 (by decide +kernel) e41594 e41613
private theorem e41640 : Deny 5 13 b41640 := by
    apply closeAction rule_sound _ _ 64 [0x275d7e228a2387d52a2284]
    decide +kernel
private theorem e41652 : Deny 5 13 b41652 := by
    apply closeAction rule_sound _ _ 64 [0x7d52a2]
    decide +kernel
private theorem e41655 : Deny 5 13 b41655 := by
    apply closeAction rule_sound _ _ 64 [0x75f7437f8df688788a20a]
    decide +kernel
private theorem e41651 : Deny 5 13 b41651 :=
    branchAction rule_sound _ _ 3
      0xa8c4 b41651 b41652 b41655 (by decide +kernel) e41652 e41655
private theorem e41639 : Deny 5 13 b41639 :=
    branchAction rule_sound _ _ 3
      0xbbe3 b41639 b41640 b41651 (by decide +kernel) e41640 e41651
private theorem e41664 : Deny 5 13 b41664 := by
    apply closeAction rule_sound _ _ 64 [0x8274388a2041f854a57710be37]
    decide +kernel
private theorem e41638 : Deny 5 13 b41638 :=
    branchAction rule_sound _ _ 2
      0x1e3 b41638 b41639 b41664 (by decide +kernel) e41639 e41664
private theorem e41675 : Deny 5 13 b41675 := by
    apply closeAction rule_sound _ _ 64 [0x76f]
    decide +kernel
private theorem e41637 : Deny 5 13 b41637 :=
    branchAction rule_sound _ _ 2
      0x263 b41637 b41638 b41675 (by decide +kernel) e41638 e41675
private theorem e41676 : Deny 5 13 b41676 := by
    apply closeAction rule_sound _ _ 64 [0x272f8841f8def]
    decide +kernel
private theorem e41636 : Deny 5 13 b41636 :=
    branchAction rule_sound _ _ 2
      0x263 b41636 b41637 b41676 (by decide +kernel) e41637 e41676
private theorem e41679 : Deny 5 13 b41679 := by
    apply closeAction rule_sound _ _ 64 [0x20820f8be2107e2f8841f8889e37]
    decide +kernel
private theorem e41635 : Deny 5 13 b41635 :=
    branchAction rule_sound _ _ 2
      0x204 b41635 b41636 b41679 (by decide +kernel) e41636 e41679
private theorem e41691 : Deny 5 13 b41691 := by
    apply closeAction rule_sound _ _ 64 [0x3bc3de3243def8c7778df6204]
    decide +kernel
private theorem e41698 : Deny 5 13 b41698 := by
    apply closeAction rule_sound _ _ 64 [0x75f28221ce37da31f78c4]
    decide +kernel
private theorem e41690 : Deny 5 13 b41690 :=
    branchAction rule_sound _ _ 4
      0x2f8be3 b41690 b41691 b41698 (by decide +kernel) e41691 e41698
private theorem e41705 : Deny 5 13 b41705 := by
    apply closeAction rule_sound _ _ 64 [0x1d7c3e03e07103e0427820a54a]
    decide +kernel
private theorem e41689 : Deny 5 13 b41689 :=
    branchAction rule_sound _ _ 2
      0x1e3 b41689 b41690 b41705 (by decide +kernel) e41690 e41705
private theorem e41716 : Deny 5 13 b41716 := by
    apply closeAction rule_sound _ _ 64 [0x76f]
    decide +kernel
private theorem e41688 : Deny 5 13 b41688 :=
    branchAction rule_sound _ _ 2
      0x263 b41688 b41689 b41716 (by decide +kernel) e41689 e41716
private theorem e41717 : Deny 5 13 b41717 := by
    apply closeAction rule_sound _ _ 64 [0x1cbddbe326f]
    decide +kernel
private theorem e41687 : Deny 5 13 b41687 :=
    branchAction rule_sound _ _ 1
      0x9 b41687 b41688 b41717 (by decide +kernel) e41688 e41717
private theorem e41722 : Deny 5 13 b41722 := by
    apply closeAction rule_sound _ _ 64 [0x76f7c30f8be21e22a3263]
    decide +kernel
private theorem e41729 : Deny 5 13 b41729 := by
    apply closeAction rule_sound _ _ 64 [0x2be311f578dd52222b78c4278]
    decide +kernel
private theorem e41721 : Deny 5 13 b41721 :=
    branchAction rule_sound _ _ 2
      0x1e3 b41721 b41722 b41729 (by decide +kernel) e41722 e41729
private theorem e41736 : Deny 5 13 b41736 := by
    apply closeAction rule_sound _ _ 64 [0x9cbe3109e2f]
    decide +kernel
private theorem e41720 : Deny 5 13 b41720 :=
    branchAction rule_sound _ _ 1
      0x9 b41720 b41721 b41736 (by decide +kernel) e41721 e41736
private theorem e41686 : Deny 5 13 b41686 :=
    branchAction rule_sound _ _ 2
      0x223 b41686 b41687 b41720 (by decide +kernel) e41687 e41720
private theorem e41634 : Deny 5 13 b41634 :=
    branchAction rule_sound _ _ 1
      0xb b41634 b41635 b41686 (by decide +kernel) e41635 e41686
private theorem e41592 : Deny 5 13 b41592 :=
    branchAction rule_sound _ _ 1
      0x7 b41592 b41593 b41634 (by decide +kernel) e41593 e41634
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711602⟩,⟨239,478⟩] := by
  exact e41592
end OMA.Blocks5_13_245212.S41592
