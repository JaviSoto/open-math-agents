import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S27065
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b27065 : Box := ![⟨38,46⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711604⟩,⟨239,478⟩]
private def b27066 : Box := ![⟨38,41⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711604⟩,⟨239,478⟩]
private def b27067 : Box := ![⟨38,41⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711603⟩,⟨239,318⟩]
private def b27068 : Box := ![⟨38,41⟩,⟨42,50⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711602⟩,⟨239,317⟩]
private def b27077 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711602⟩,⟨239,317⟩]
private def b27078 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨63,126⟩,⟨3,900178041543026711602⟩,⟨239,317⟩]
private def b27079 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨63,126⟩,⟨3,6⟩,⟨239,317⟩]
private def b27080 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨63,75⟩,⟨3,6⟩,⟨239,272⟩]
private def b27085 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨63,75⟩,⟨3,6⟩,⟨273,317⟩]
private def b27094 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨63,126⟩,⟨7,88⟩,⟨239,317⟩]
private def b27095 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨127,1920000000000000011376⟩,⟨3,900178041543026711602⟩,⟨239,317⟩]
private def b27096 : Box := ![⟨38,41⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711603⟩,⟨319,478⟩]
private def b27097 : Box := ![⟨38,41⟩,⟨42,50⟩,⟨63,1920000000000000011376⟩,⟨3,855338345864661659239⟩,⟨319,478⟩]
private def b27098 : Box := ![⟨38,41⟩,⟨42,50⟩,⟨63,126⟩,⟨3,855338345864661659235⟩,⟨319,478⟩]
private def b27107 : Box := ![⟨38,41⟩,⟨42,50⟩,⟨127,1920000000000000011376⟩,⟨3,855338345864661659235⟩,⟨319,478⟩]
private def b27110 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨63,1920000000000000011376⟩,⟨3,855338345864661659239⟩,⟨319,478⟩]
private def b27111 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨63,126⟩,⟨3,855338345864661659239⟩,⟨319,478⟩]
private def b27112 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨63,126⟩,⟨3,6⟩,⟨319,478⟩]
private def b27113 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨63,76⟩,⟨3,6⟩,⟨319,382⟩]
private def b27124 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨63,76⟩,⟨3,6⟩,⟨383,478⟩]
private def b27133 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨63,126⟩,⟨7,84⟩,⟨319,478⟩]
private def b27134 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨127,1920000000000000011376⟩,⟨3,855338345864661659239⟩,⟨319,478⟩]
private def b27137 : Box := ![⟨42,46⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711604⟩,⟨239,478⟩]
private def b27138 : Box := ![⟨42,46⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711604⟩,⟨239,318⟩]
private def b27139 : Box := ![⟨42,46⟩,⟨42,50⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711603⟩,⟨239,317⟩]
private def b27150 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711603⟩,⟨239,317⟩]
private def b27151 : Box := ![⟨42,46⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711604⟩,⟨319,478⟩]
private def b27152 : Box := ![⟨42,46⟩,⟨42,50⟩,⟨63,1920000000000000011376⟩,⟨3,855338345864661659240⟩,⟨319,478⟩]
private def b27163 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨63,1920000000000000011376⟩,⟨3,855338345864661659240⟩,⟨319,478⟩]
private def b27164 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨63,126⟩,⟨3,855338345864661659240⟩,⟨324,478⟩]
private def b27165 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨63,126⟩,⟨3,6⟩,⟨324,478⟩]
private def b27176 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨63,126⟩,⟨7,85⟩,⟨324,478⟩]
private def b27177 : Box := ![⟨42,46⟩,⟨51,62⟩,⟨127,1920000000000000011376⟩,⟨3,855338345864661659240⟩,⟨324,478⟩]
private theorem e27068 : Deny 5 13 b27068 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe311cbe3109e2f7df0f8bed88a88abe3263]
    decide +kernel
private theorem e27080 : Deny 5 13 b27080 := by
    apply closeAction rule_sound _ _ 64 [0x5b8dd6e370ef888887884]
    decide +kernel
private theorem e27085 : Deny 5 13 b27085 := by
    apply closeAction rule_sound _ _ 64 [0x5b8dc38880c38880f8de22221c4]
    decide +kernel
private theorem e27079 : Deny 5 13 b27079 :=
    branchAction rule_sound _ _ 2
      0x2e2 b27079 b27080 b27085 (by decide +kernel) e27080 e27085
private theorem e27094 : Deny 5 13 b27094 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e27078 : Deny 5 13 b27078 :=
    branchAction rule_sound _ _ 2
      0x2a3 b27078 b27079 b27094 (by decide +kernel) e27079 e27094
private theorem e27095 : Deny 5 13 b27095 := by
    apply closeAction rule_sound _ _ 64 [0xaf]
    decide +kernel
private theorem e27077 : Deny 5 13 b27077 :=
    branchAction rule_sound _ _ 1
      0x9 b27077 b27078 b27095 (by decide +kernel) e27078 e27095
private theorem e27067 : Deny 5 13 b27067 :=
    branchAction rule_sound _ _ 3
      0x88c4 b27067 b27068 b27077 (by decide +kernel) e27068 e27077
private theorem e27098 : Deny 5 13 b27098 := by
    apply closeAction rule_sound _ _ 64 [0x1fbdf7f8de22a311fe37daf8c42388c97f8df68c7be3]
    decide +kernel
private theorem e27107 : Deny 5 13 b27107 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdcbe326f]
    decide +kernel
private theorem e27097 : Deny 5 13 b27097 :=
    branchAction rule_sound _ _ 2
      0x263 b27097 b27098 b27107 (by decide +kernel) e27098 e27107
private theorem e27113 : Deny 5 13 b27113 := by
    apply closeAction rule_sound _ _ 64 [0x16e370e22038880c3e37888088887884]
    decide +kernel
private theorem e27124 : Deny 5 13 b27124 := by
    apply closeAction rule_sound _ _ 64 [0x30f88870f8de221f0a210ae37da21c4]
    decide +kernel
private theorem e27112 : Deny 5 13 b27112 :=
    branchAction rule_sound _ _ 2
      0x2e2 b27112 b27113 b27124 (by decide +kernel) e27113 e27124
private theorem e27133 : Deny 5 13 b27133 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e27111 : Deny 5 13 b27111 :=
    branchAction rule_sound _ _ 2
      0x2a3 b27111 b27112 b27133 (by decide +kernel) e27112 e27133
private theorem e27134 : Deny 5 13 b27134 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe37af8c9e2f]
    decide +kernel
private theorem e27110 : Deny 5 13 b27110 :=
    branchAction rule_sound _ _ 1
      0x9 b27110 b27111 b27134 (by decide +kernel) e27111 e27134
private theorem e27096 : Deny 5 13 b27096 :=
    branchAction rule_sound _ _ 2
      0x223 b27096 b27097 b27110 (by decide +kernel) e27097 e27110
private theorem e27066 : Deny 5 13 b27066 :=
    branchAction rule_sound _ _ 2
      0x2e3 b27066 b27067 b27096 (by decide +kernel) e27067 e27096
private theorem e27139 : Deny 5 13 b27139 := by
    apply closeAction rule_sound _ _ 64 [0x2bdf7c20f8b62107e2d88ae172b8be22a3263]
    decide +kernel
private theorem e27150 : Deny 5 13 b27150 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e27138 : Deny 5 13 b27138 :=
    branchAction rule_sound _ _ 3
      0x88c4 b27138 b27139 b27150 (by decide +kernel) e27139 e27150
private theorem e27152 : Deny 5 13 b27152 := by
    apply closeAction rule_sound _ _ 64 [0x72f8c472f8c4278bdf0ef0c90f8be22222a3263]
    decide +kernel
private theorem e27165 : Deny 5 13 b27165 := by
    apply closeAction rule_sound _ _ 64 [0x820e21e2108e375b8de21038842380e22221e2]
    decide +kernel
private theorem e27176 : Deny 5 13 b27176 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e27164 : Deny 5 13 b27164 :=
    branchAction rule_sound _ _ 2
      0x2a3 b27164 b27165 b27176 (by decide +kernel) e27165 e27176
private theorem e27177 : Deny 5 13 b27177 := by
    apply closeAction rule_sound _ _ 64 [0x2be3]
    decide +kernel
private theorem e27163 : Deny 5 13 b27163 :=
    branchAction rule_sound _ _ 2
      0x278 b27163 b27164 b27177 (by decide +kernel) e27164 e27177
private theorem e27151 : Deny 5 13 b27151 :=
    branchAction rule_sound _ _ 2
      0x223 b27151 b27152 b27163 (by decide +kernel) e27152 e27163
private theorem e27137 : Deny 5 13 b27137 :=
    branchAction rule_sound _ _ 1
      0xb b27137 b27138 b27151 (by decide +kernel) e27138 e27151
private theorem e27065 : Deny 5 13 b27065 :=
    branchAction rule_sound _ _ 1
      0x7 b27065 b27066 b27137 (by decide +kernel) e27066 e27137
theorem deny5_13 : Deny 5 13 ![⟨38,46⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711604⟩,⟨239,478⟩] := by
  exact e27065
end OMA.Blocks5_13_245212.S27065
