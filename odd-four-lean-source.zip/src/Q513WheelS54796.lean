import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S54796
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b54796 : Box := ![⟨47,53⟩,⟨127,1920000000000000011376⟩,⟨10,14⟩,⟨2,502335381913959616705⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,53⟩,⟨127,1920000000000000011376⟩,⟨10,14⟩,⟨2,502335381913959616705⟩,⟨479,999999999999999999⟩] := by
  have e54796 : Deny 5 13 b54796 := by
    apply closeAction rule_sound _ _ 64 [0xd632636ab6ab69aadf6b8dc9e086ab7c3e0922b84b7c2278847682ae110ae212612b68c8ae32232d2e21292e36ae12a3,0x8c8d636ab8cbd636ab8cb087d636ab8cb089d636ab8cb8daae32e36ab8cb6ab6ab088e368c8e2b8c21f88c86ab8c21f8,0x2082247adaae322b6ab8c8adaae322b6ab0c21eb0880898c8087]
    decide +kernel
  exact e54796
end OMA.Blocks5_13_245212.S54796
