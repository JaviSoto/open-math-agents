import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S53826
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b53826 : Box := ![⟨47,62⟩,⟨31,62⟩,⟨7,14⟩,⟨1,53⟩,⟨239,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,62⟩,⟨31,62⟩,⟨7,14⟩,⟨1,53⟩,⟨239,999999999999999999⟩] := by
  have e53826 : Deny 5 13 b53826 := by
    apply closeAction rule_sound _ _ 64 [0xde32631c36f8de3243e378c78c80dbe378c8087102238de3257d8a10b0c22421c4088e37da31f88dfe37db58c8e36d63,0xc3e378c86f8de3243e37da31dfe37da3237da30c38c80e32430f8]
    decide +kernel
  exact e53826
end OMA.Blocks5_13_245212.S53826
