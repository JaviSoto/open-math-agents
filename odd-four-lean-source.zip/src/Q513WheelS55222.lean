import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S55222
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b55222 : Box := ![⟨63,94⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨1,565934718100890211109⟩,⟨239,478⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨1,565934718100890211109⟩,⟨239,478⟩] := by
  have e55222 : Deny 5 13 b55222 := by
    apply closeAction rule_sound _ _ 64 [0x4ca84aadb6c30f82022440f80f82430892042ca2932830f8de321be37d498c78c810b6eb102238df58c98c78c84e12a3,0x84a4f8ae129bac36b8dc7de31022788c8e2b8c70c225be37da3204087e378c88db083e21109e038474ca0c3e37849847,0x1aadbae322b6db6d36d30c38478476c98442c24c31c42384c98442e11e129b2532a128a4ca6db0f80f821be3784984a]
    decide +kernel
  exact e55222
end OMA.Blocks5_13_245212.S55222
