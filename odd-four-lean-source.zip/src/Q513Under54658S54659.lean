import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S54659
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b54659 : Box := ![⟨47,53⟩,⟨63,126⟩,⟨10,14⟩,⟨1,58⟩,⟨479,999999999999999999⟩]
private def b54660 : Box := ![⟨47,49⟩,⟨74,126⟩,⟨12,14⟩,⟨2,56⟩,⟨479,734⟩]
private def b54661 : Box := ![⟨50,53⟩,⟨74,126⟩,⟨12,14⟩,⟨2,56⟩,⟨479,734⟩]
private def b54662 : Box := ![⟨50,53⟩,⟨74,126⟩,⟨12,12⟩,⟨2,51⟩,⟨479,732⟩]
private def b54663 : Box := ![⟨50,53⟩,⟨74,126⟩,⟨13,14⟩,⟨2,51⟩,⟨479,732⟩]
private def b54664 : Box := ![⟨50,53⟩,⟨74,126⟩,⟨13,14⟩,⟨2,4⟩,⟨479,732⟩]
private def b54665 : Box := ![⟨50,53⟩,⟨74,126⟩,⟨13,14⟩,⟨5,51⟩,⟨479,732⟩]
private def b54666 : Box := ![⟨50,53⟩,⟨74,126⟩,⟨13,13⟩,⟨5,51⟩,⟨479,732⟩]
private def b54667 : Box := ![⟨50,53⟩,⟨87,102⟩,⟨13,13⟩,⟨5,50⟩,⟨479,564⟩]
private def b54668 : Box := ![⟨50,53⟩,⟨103,126⟩,⟨13,13⟩,⟨5,50⟩,⟨479,564⟩]
private def b54669 : Box := ![⟨50,53⟩,⟨74,126⟩,⟨14,14⟩,⟨5,51⟩,⟨479,732⟩]
private theorem e54660 : Deny 5 13 b54660 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e54662 : Deny 5 13 b54662 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e54664 : Deny 5 13 b54664 := by
    apply closeAction rule_sound _ _ 64 [0x2ae1]
    decide +kernel
private theorem e54667 : Deny 5 13 b54667 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e54668 : Deny 5 13 b54668 := by
    apply closeAction rule_sound _ _ 64 [0x3ac4]
    decide +kernel
private theorem e54666 : Deny 5 13 b54666 :=
    branchAction rule_sound _ _ 4
      0x238d63 b54666 b54667 b54668 (by decide +kernel) e54667 e54668
private theorem e54669 : Deny 5 13 b54669 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e54665 : Deny 5 13 b54665 :=
    branchAction rule_sound _ _ 1
      0x9 b54665 b54666 b54669 (by decide +kernel) e54666 e54669
private theorem e54663 : Deny 5 13 b54663 :=
    branchAction rule_sound _ _ 1
      0xa b54663 b54664 b54665 (by decide +kernel) e54664 e54665
private theorem e54661 : Deny 5 13 b54661 :=
    branchAction rule_sound _ _ 3
      0x9e23 b54661 b54662 b54663 (by decide +kernel) e54662 e54663
private theorem e54659 : Deny 5 13 b54659 :=
    branchAction rule_sound _ _ 6
      0x1f8df6d63 b54659 b54660 b54661 (by decide +kernel) e54660 e54661
theorem deny5_13 : Deny 5 13 ![⟨47,53⟩,⟨63,126⟩,⟨10,14⟩,⟨1,58⟩,⟨479,999999999999999999⟩] := by
  exact e54659
end OMA.Blocks5_13_245212.S54659
