import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S41309
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b41309 : Box := ![⟨47,62⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨1,900178041543026711610⟩,⟨239,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,62⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨1,900178041543026711610⟩,⟨239,999999999999999999⟩] := by
  have e41309 : Deny 5 13 b41309 := by
    apply closeAction rule_sound _ _ 64 [0xe37da21ca8c972f7dcbc21f8daf8c4238be325f088e368c972f102238da31dfe3688a0a22b8da32232e35f8db588ae23,0x2380e22030f8243e368888870c3e090f8d872622972830f8243e37243e37da221fe37da21f688810b0c21c4087e22088,0xda31c22368dcbdcbe326f7e325fbedb2229f7c30f8243e09d8a5ca0f8d880f8884087e37d877f8df623611f0f8103884,0x72f7ef8c9bdf0f8de229fe37da321fe378c97f8df68c7088e368c972f8c4088e37]
    decide +kernel
  exact e41309
end OMA.Blocks5_13_245212.S41309
