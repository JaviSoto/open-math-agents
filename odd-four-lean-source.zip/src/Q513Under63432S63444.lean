import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S63444
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b63444 : Box := ![⟨153,190⟩,⟨36,38⟩,⟨12,12⟩,⟨2,47⟩,⟨1919,999999999999999999⟩]
private def b63445 : Box := ![⟨153,169⟩,⟨36,38⟩,⟨12,12⟩,⟨2,46⟩,⟨1919,999999999999999999⟩]
private def b63446 : Box := ![⟨170,190⟩,⟨36,38⟩,⟨12,12⟩,⟨2,46⟩,⟨1919,999999999999999999⟩]
private theorem e63445 : Deny 5 13 b63445 := by
    apply closeAction rule_sound _ _ 64 [0x3e23]
    decide +kernel
private theorem e63446 : Deny 5 13 b63446 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e63444 : Deny 5 13 b63444 :=
    branchAction rule_sound _ _ 2
      0x1e3 b63444 b63445 b63446 (by decide +kernel) e63445 e63446
theorem deny5_13 : Deny 5 13 ![⟨153,190⟩,⟨36,38⟩,⟨12,12⟩,⟨2,47⟩,⟨1919,999999999999999999⟩] := by
  exact e63444
end OMA.Blocks5_13_245212.S63444
