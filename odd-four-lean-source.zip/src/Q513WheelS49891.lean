import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S49891
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b49891 : Box := ![⟨127,190⟩,⟨21,22⟩,⟨31,62⟩,⟨1,67⟩,⟨959,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨127,190⟩,⟨21,22⟩,⟨31,62⟩,⟨1,67⟩,⟨959,999999999999999999⟩] := by
  have e49891 : Deny 5 13 b49891 := by
    apply closeAction rule_sound _ _ 64 [0xda31f8da31f8778df68c8e2375d5550f80f81dde3720924a2952a32f80c3e378c90f8df68c7088e232788d52b8da31e3,0x778df68089e024a9c3e03e379c80e31c39c22389e32631e32f88d52b88c90f80f88c7e03e230f8df68c7e232780dde37,0x1d528928a54a54a8cb743e03e272789c3e361f82b89c3089e368c7e022388dd0831f80f89c3e37d87e080839c31c82c3,0x8c21f8df622375d54a2952952a32c3e03e231f88dde37da32388c98c78dd755083e031c8e1d543e03e0824a0950c920b,0xe231e375d54a2952952a32c80f80e31c3e368c21f8df62237420c7e030f8d8721528a54a9e32e32420f88c9e038c70f8,0x830f88c90f88c3e378c9]
    decide +kernel
  exact e49891
end OMA.Blocks5_13_245212.S49891
