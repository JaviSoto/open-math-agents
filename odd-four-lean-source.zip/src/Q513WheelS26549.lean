import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S26549
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b26549 : Box := ![⟨31,37⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨1,900178041543026711610⟩,⟨239,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨31,37⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨1,900178041543026711610⟩,⟨239,999999999999999999⟩] := by
  have e26549 : Deny 5 13 b26549 := by
    apply closeAction rule_sound _ _ 64 [0xbe3109e37da31df583e37d8811fe37d8423829fe37da31dfe37da325fe37da3204087e2325cbc21f8df68c88c288ae23,0x7e2282b622a372f7af8c9bdf7d60f888423888a58a1028841f888a8c972f72f8c9bdf8c90afb622a32042dcbc47b8db5,0x1cbdc25e8c972f8c4087e368c87f8db588a]
    decide +kernel
  exact e26549
end OMA.Blocks5_13_245212.S26549
