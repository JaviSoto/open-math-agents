import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S26039
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b26039 : Box := ![⟨38,46⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨3,640000000000000003831⟩,⟨127,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨38,46⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨3,640000000000000003831⟩,⟨127,233⟩] := by
  have e26039 : Deny 5 13 b26039 := by
    apply closeAction rule_sound _ _ 64 [0xc82488441f8dc25f8dc38498442785f70f70c88470c3ae11c32212445f8dc3e215cadc32212442e11e126110b84a8c8,0x84a5ca0e12612442c30f8de11c3e2125f0a110ae378491030e11c38490c3e2b8470f8dc88498442e11e1244082097e37,0xdc32075f8dc40c42380c32072488442e11df0838441f80f80c72212972830e11c32038498491025f8dc31c87c3e03849,0x1c9108e025f8dd7e370c9221107e17e370e11c38498495f8dc32030c91c30c80c3e37207248102083847844278dc25f8,0xab8c47eb8c4238adf097e375f8dd7e370c8]
    decide +kernel
  exact e26039
end OMA.Blocks5_13_245212.S26039
