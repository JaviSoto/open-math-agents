import FastReplay245212
import SparseDigit245212
import FastRound245212
import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S23419
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b23419 : Box := ![⟨23,30⟩,⟨15,30⟩,⟨15,1920000000000000011376⟩,⟨1,994807017543859655055⟩,⟨207,999999999999999999⟩]
private def b23420 : Box := ![⟨23,30⟩,⟨15,20⟩,⟨15,1920000000000000011376⟩,⟨1,864390243902439029545⟩,⟨207,999999999999999999⟩]
private def b23421 : Box := ![⟨23,30⟩,⟨15,20⟩,⟨15,30⟩,⟨1,864390243902439029542⟩,⟨207,999999999999999999⟩]
private def b23422 : Box := ![⟨23,26⟩,⟨15,20⟩,⟨15,30⟩,⟨1,35⟩,⟨207,1406⟩]
private def b23427 : Box := ![⟨27,30⟩,⟨15,20⟩,⟨15,30⟩,⟨1,35⟩,⟨207,1406⟩]
private def b23440 : Box := ![⟨23,30⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029542⟩,⟨207,999999999999999999⟩]
private def b23441 : Box := ![⟨23,30⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029542⟩,⟨207,414⟩]
private def b23442 : Box := ![⟨23,26⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029535⟩,⟨207,414⟩]
private def b23443 : Box := ![⟨23,26⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨1,2⟩,⟨207,414⟩]
private def b23444 : Box := ![⟨23,26⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨3,864390243902439029534⟩,⟨207,414⟩]
private def b23445 : Box := ![⟨23,26⟩,⟨15,17⟩,⟨31,1920000000000000011376⟩,⟨3,864390243902439029534⟩,⟨207,414⟩]
private def b23446 : Box := ![⟨23,26⟩,⟨15,17⟩,⟨31,1920000000000000011376⟩,⟨3,6⟩,⟨207,414⟩]
private def b23447 : Box := ![⟨23,26⟩,⟨15,17⟩,⟨31,1920000000000000011376⟩,⟨7,864390243902439029533⟩,⟨207,414⟩]
private def b23462 : Box := ![⟨23,26⟩,⟨18,20⟩,⟨31,1920000000000000011376⟩,⟨3,864390243902439029534⟩,⟨207,414⟩]
private def b23463 : Box := ![⟨23,26⟩,⟨18,20⟩,⟨31,62⟩,⟨3,864390243902439029534⟩,⟨207,414⟩]
private def b23478 : Box := ![⟨23,26⟩,⟨18,20⟩,⟨63,1920000000000000011376⟩,⟨3,864390243902439029534⟩,⟨207,414⟩]
private def b23487 : Box := ![⟨27,30⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029535⟩,⟨207,414⟩]
private def b23488 : Box := ![⟨27,30⟩,⟨15,17⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029535⟩,⟨207,414⟩]
private def b23489 : Box := ![⟨27,30⟩,⟨15,17⟩,⟨31,1920000000000000011376⟩,⟨1,2⟩,⟨207,414⟩]
private def b23490 : Box := ![⟨27,30⟩,⟨15,17⟩,⟨31,1920000000000000011376⟩,⟨3,864390243902439029534⟩,⟨207,414⟩]
private def b23491 : Box := ![⟨27,30⟩,⟨15,17⟩,⟨31,62⟩,⟨3,864390243902439029534⟩,⟨207,414⟩]
private def b23492 : Box := ![⟨27,30⟩,⟨15,17⟩,⟨31,62⟩,⟨3,42⟩,⟨207,276⟩]
private def b23501 : Box := ![⟨27,30⟩,⟨15,17⟩,⟨31,62⟩,⟨3,42⟩,⟨277,414⟩]
private def b23508 : Box := ![⟨27,30⟩,⟨15,17⟩,⟨63,1920000000000000011376⟩,⟨3,864390243902439029534⟩,⟨207,414⟩]
private def b23517 : Box := ![⟨27,30⟩,⟨18,20⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029535⟩,⟨207,414⟩]
private def b23518 : Box := ![⟨27,30⟩,⟨18,20⟩,⟨31,62⟩,⟨1,864390243902439029535⟩,⟨207,414⟩]
private def b23533 : Box := ![⟨27,30⟩,⟨18,20⟩,⟨63,1920000000000000011376⟩,⟨1,864390243902439029535⟩,⟨207,414⟩]
private def b23534 : Box := ![⟨23,30⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029542⟩,⟨415,999999999999999999⟩]
private def b23535 : Box := ![⟨23,26⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨1,764204851752021567897⟩,⟨415,999999999999999999⟩]
private def b23536 : Box := ![⟨23,26⟩,⟨15,20⟩,⟨35,1920000000000000011376⟩,⟨1,2⟩,⟨415,999999999999999999⟩]
private def b23537 : Box := ![⟨23,26⟩,⟨15,20⟩,⟨35,1920000000000000011376⟩,⟨3,764204851752021567896⟩,⟨415,999999999999999999⟩]
private def b23538 : Box := ![⟨23,26⟩,⟨15,17⟩,⟨35,1920000000000000011376⟩,⟨3,764204851752021567896⟩,⟨415,999999999999999999⟩]
private def b23541 : Box := ![⟨23,26⟩,⟨18,20⟩,⟨35,1920000000000000011376⟩,⟨3,764204851752021567896⟩,⟨415,999999999999999999⟩]
private def b23542 : Box := ![⟨23,26⟩,⟨18,20⟩,⟨35,70⟩,⟨3,764204851752021567896⟩,⟨415,999999999999999999⟩]
private def b23549 : Box := ![⟨23,26⟩,⟨18,20⟩,⟨71,1920000000000000011376⟩,⟨3,764204851752021567896⟩,⟨415,999999999999999999⟩]
private def b23550 : Box := ![⟨23,26⟩,⟨18,20⟩,⟨71,1920000000000000011376⟩,⟨3,6⟩,⟨415,999999999999999999⟩]
private def b23551 : Box := ![⟨23,26⟩,⟨18,20⟩,⟨71,1920000000000000011376⟩,⟨7,764204851752021567896⟩,⟨415,999999999999999999⟩]
private def b23552 : Box := ![⟨23,26⟩,⟨18,20⟩,⟨71,1920000000000000011376⟩,⟨7,764204851752021567896⟩,⟨415,830⟩]
private def b23555 : Box := ![⟨23,26⟩,⟨18,20⟩,⟨71,1920000000000000011376⟩,⟨7,764204851752021567896⟩,⟨831,999999999999999999⟩]
private def b23556 : Box := ![⟨23,24⟩,⟨18,20⟩,⟨71,1920000000000000011376⟩,⟨7,685382755842062856622⟩,⟨831,999999999999999999⟩]
private def b23557 : Box := ![⟨25,26⟩,⟨18,20⟩,⟨71,1920000000000000011376⟩,⟨7,685382755842062856622⟩,⟨831,999999999999999999⟩]
private def b23558 : Box := ![⟨25,26⟩,⟨18,18⟩,⟨71,1920000000000000011376⟩,⟨7,685382755842062856622⟩,⟨831,999999999999999999⟩]
private def b23559 : Box := ![⟨25,26⟩,⟨19,20⟩,⟨71,1920000000000000011376⟩,⟨7,685382755842062856622⟩,⟨831,999999999999999999⟩]
private def b23560 : Box := ![⟨25,26⟩,⟨19,20⟩,⟨71,142⟩,⟨7,685382755842062856622⟩,⟨831,999999999999999999⟩]
private def b23563 : Box := ![⟨25,26⟩,⟨19,20⟩,⟨143,1920000000000000011376⟩,⟨7,685382755842062856622⟩,⟨831,999999999999999999⟩]
private def b23578 : Box := ![⟨27,30⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨1,764204851752021567897⟩,⟨415,999999999999999999⟩]
private def b23579 : Box := ![⟨27,30⟩,⟨15,17⟩,⟨31,1920000000000000011376⟩,⟨1,764204851752021567897⟩,⟨415,999999999999999999⟩]
private def b23580 : Box := ![⟨27,30⟩,⟨15,17⟩,⟨31,1920000000000000011376⟩,⟨1,2⟩,⟨415,999999999999999999⟩]
private def b23581 : Box := ![⟨27,30⟩,⟨15,17⟩,⟨31,1920000000000000011376⟩,⟨3,764204851752021567896⟩,⟨415,999999999999999999⟩]
private def b23582 : Box := ![⟨27,30⟩,⟨15,17⟩,⟨31,62⟩,⟨3,764204851752021567896⟩,⟨415,999999999999999999⟩]
private def b23589 : Box := ![⟨27,30⟩,⟨15,17⟩,⟨63,1920000000000000011376⟩,⟨3,764204851752021567896⟩,⟨415,999999999999999999⟩]
private def b23590 : Box := ![⟨27,30⟩,⟨15,17⟩,⟨63,1920000000000000011376⟩,⟨3,6⟩,⟨415,999999999999999999⟩]
private def b23591 : Box := ![⟨27,30⟩,⟨15,17⟩,⟨63,1920000000000000011376⟩,⟨7,764204851752021567896⟩,⟨415,999999999999999999⟩]
private def b23592 : Box := ![⟨27,30⟩,⟨15,17⟩,⟨63,1920000000000000011376⟩,⟨7,764204851752021567896⟩,⟨415,830⟩]
private def b23601 : Box := ![⟨27,30⟩,⟨15,17⟩,⟨63,1920000000000000011376⟩,⟨7,764204851752021567896⟩,⟨831,999999999999999999⟩]
private def b23602 : Box := ![⟨27,30⟩,⟨15,15⟩,⟨63,1920000000000000011376⟩,⟨7,685382755842062856622⟩,⟨831,999999999999999999⟩]
private def b23603 : Box := ![⟨27,30⟩,⟨16,17⟩,⟨63,1920000000000000011376⟩,⟨7,685382755842062856622⟩,⟨831,999999999999999999⟩]
private def b23604 : Box := ![⟨27,28⟩,⟨16,17⟩,⟨63,1920000000000000011376⟩,⟨7,685382755842062856622⟩,⟨831,999999999999999999⟩]
private def b23607 : Box := ![⟨29,30⟩,⟨16,17⟩,⟨63,1920000000000000011376⟩,⟨7,685382755842062856622⟩,⟨831,999999999999999999⟩]
private def b23608 : Box := ![⟨29,30⟩,⟨16,17⟩,⟨63,126⟩,⟨7,685382755842062856622⟩,⟨831,999999999999999999⟩]
private def b23611 : Box := ![⟨29,30⟩,⟨16,17⟩,⟨127,1920000000000000011376⟩,⟨7,685382755842062856622⟩,⟨831,999999999999999999⟩]
private def b23612 : Box := ![⟨29,30⟩,⟨16,17⟩,⟨127,1920000000000000011376⟩,⟨7,685382755842062856622⟩,⟨831,1662⟩]
private def b23613 : Box := ![⟨29,30⟩,⟨16,17⟩,⟨127,1920000000000000011376⟩,⟨7,685382755842062856622⟩,⟨1663,999999999999999999⟩]
private def b23614 : Box := ![⟨29,30⟩,⟨16,17⟩,⟨127,1920000000000000011376⟩,⟨7,621300219138056979597⟩,⟨1663,3326⟩]
private def b23615 : Box := ![⟨29,30⟩,⟨16,17⟩,⟨127,1920000000000000011376⟩,⟨7,621300219138056979597⟩,⟨3327,999999999999999999⟩]
private def b23616 : Box := ![⟨29,30⟩,⟨16,16⟩,⟨127,1920000000000000011376⟩,⟨7,568176352705410825029⟩,⟨3327,999999999999999999⟩]
private def b23617 : Box := ![⟨29,30⟩,⟨17,17⟩,⟨127,1920000000000000011376⟩,⟨7,568176352705410825029⟩,⟨3327,999999999999999999⟩]
private def b23632 : Box := ![⟨27,30⟩,⟨18,20⟩,⟨31,1920000000000000011376⟩,⟨1,764204851752021567897⟩,⟨415,999999999999999999⟩]
private def b23633 : Box := ![⟨27,30⟩,⟨18,20⟩,⟨31,62⟩,⟨1,764204851752021567897⟩,⟨415,999999999999999999⟩]
private def b23634 : Box := ![⟨27,30⟩,⟨18,20⟩,⟨31,62⟩,⟨1,44⟩,⟨415,830⟩]
private def b23643 : Box := ![⟨27,30⟩,⟨18,20⟩,⟨31,62⟩,⟨1,44⟩,⟨831,999999999999999999⟩]
private def b23650 : Box := ![⟨27,30⟩,⟨18,20⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567897⟩,⟨415,999999999999999999⟩]
private def b23651 : Box := ![⟨27,30⟩,⟨18,20⟩,⟨63,1920000000000000011376⟩,⟨1,2⟩,⟨415,999999999999999999⟩]
private def b23652 : Box := ![⟨27,30⟩,⟨18,20⟩,⟨63,1920000000000000011376⟩,⟨3,764204851752021567897⟩,⟨415,999999999999999999⟩]
private def b23653 : Box := ![⟨27,30⟩,⟨18,20⟩,⟨63,1920000000000000011376⟩,⟨3,764204851752021567897⟩,⟨415,830⟩]
private def b23662 : Box := ![⟨27,30⟩,⟨18,20⟩,⟨63,1920000000000000011376⟩,⟨3,764204851752021567897⟩,⟨831,999999999999999999⟩]
private def b23663 : Box := ![⟨27,28⟩,⟨18,20⟩,⟨63,1920000000000000011376⟩,⟨3,685382755842062856623⟩,⟨831,999999999999999999⟩]
private def b23664 : Box := ![⟨27,28⟩,⟨18,20⟩,⟨63,126⟩,⟨3,685382755842062856622⟩,⟨831,999999999999999999⟩]
private def b23673 : Box := ![⟨27,28⟩,⟨18,20⟩,⟨127,1920000000000000011376⟩,⟨3,685382755842062856622⟩,⟨831,999999999999999999⟩]
private def b23674 : Box := ![⟨27,28⟩,⟨18,20⟩,⟨127,1920000000000000011376⟩,⟨5,685382755842062856622⟩,⟨831,1662⟩]
private def b23675 : Box := ![⟨27,28⟩,⟨18,20⟩,⟨127,1920000000000000011376⟩,⟨5,685382755842062856622⟩,⟨1663,999999999999999999⟩]
private def b23676 : Box := ![⟨27,28⟩,⟨18,20⟩,⟨127,1920000000000000011376⟩,⟨5,621300219138056979597⟩,⟨1663,3326⟩]
private def b23677 : Box := ![⟨27,28⟩,⟨18,20⟩,⟨127,1920000000000000011376⟩,⟨5,621300219138056979597⟩,⟨3327,999999999999999999⟩]
private def b23678 : Box := ![⟨27,28⟩,⟨18,20⟩,⟨127,1920000000000000011376⟩,⟨5,568176352705410825029⟩,⟨3327,6654⟩]
private def b23679 : Box := ![⟨27,28⟩,⟨18,20⟩,⟨127,1920000000000000011376⟩,⟨5,568176352705410825029⟩,⟨6655,999999999999999999⟩]
private def b23680 : Box := ![⟨27,28⟩,⟨18,20⟩,⟨127,1920000000000000011376⟩,⟨5,523421538461538464657⟩,⟨6655,13310⟩]
private def b23681 : Box := ![⟨27,28⟩,⟨18,20⟩,⟨127,1920000000000000011376⟩,⟨5,523421538461538464657⟩,⟨13311,999999999999999999⟩]
private def b23682 : Box := ![⟨27,28⟩,⟨18,20⟩,⟨127,1920000000000000011376⟩,⟨5,485202509982886483211⟩,⟨13311,26622⟩]
private def b23683 : Box := ![⟨27,28⟩,⟨18,20⟩,⟨127,1920000000000000011376⟩,⟨5,485202509982886483211⟩,⟨26623,999999999999999999⟩]
private def b23684 : Box := ![⟨27,28⟩,⟨18,18⟩,⟨127,1920000000000000011376⟩,⟨5,452185007974481661387⟩,⟨26623,999999999999999999⟩]
private def b23689 : Box := ![⟨27,28⟩,⟨19,20⟩,⟨127,1920000000000000011376⟩,⟨5,452185007974481661387⟩,⟨26623,999999999999999999⟩]
private def b23702 : Box := ![⟨29,30⟩,⟨18,20⟩,⟨63,1920000000000000011376⟩,⟨3,685382755842062856623⟩,⟨831,999999999999999999⟩]
private def b23717 : Box := ![⟨23,30⟩,⟨21,30⟩,⟨15,1920000000000000011376⟩,⟨1,864390243902439029545⟩,⟨207,999999999999999999⟩]
private def b23718 : Box := ![⟨23,30⟩,⟨21,30⟩,⟨15,30⟩,⟨1,864390243902439029545⟩,⟨207,999999999999999999⟩]
private def b23719 : Box := ![⟨23,30⟩,⟨21,30⟩,⟨15,30⟩,⟨1,38⟩,⟨207,414⟩]
private def b23720 : Box := ![⟨23,26⟩,⟨21,30⟩,⟨15,30⟩,⟨1,31⟩,⟨207,414⟩]
private def b23735 : Box := ![⟨27,30⟩,⟨21,30⟩,⟨15,30⟩,⟨1,31⟩,⟨207,414⟩]
private def b23746 : Box := ![⟨23,30⟩,⟨21,30⟩,⟨15,30⟩,⟨1,38⟩,⟨415,999999999999999999⟩]
private def b23747 : Box := ![⟨23,26⟩,⟨21,30⟩,⟨15,30⟩,⟨1,34⟩,⟨415,999999999999999999⟩]
private def b23760 : Box := ![⟨27,30⟩,⟨21,30⟩,⟨15,30⟩,⟨1,34⟩,⟨415,999999999999999999⟩]
private def b23775 : Box := ![⟨23,30⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029545⟩,⟨207,999999999999999999⟩]
private def b23776 : Box := ![⟨23,30⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029545⟩,⟨207,414⟩]
private def b23777 : Box := ![⟨23,26⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029538⟩,⟨207,414⟩]
private def b23778 : Box := ![⟨23,26⟩,⟨21,24⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029537⟩,⟨207,414⟩]
private def b23779 : Box := ![⟨23,26⟩,⟨21,24⟩,⟨31,62⟩,⟨1,864390243902439029535⟩,⟨207,414⟩]
private def b23780 : Box := ![⟨23,26⟩,⟨21,24⟩,⟨31,62⟩,⟨1,43⟩,⟨207,276⟩]
private def b23791 : Box := ![⟨23,26⟩,⟨21,24⟩,⟨31,62⟩,⟨1,43⟩,⟨277,414⟩]
private def b23806 : Box := ![⟨23,26⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨1,864390243902439029535⟩,⟨207,414⟩]
private def b23815 : Box := ![⟨23,26⟩,⟨25,30⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029537⟩,⟨207,414⟩]
private def b23816 : Box := ![⟨23,26⟩,⟨25,30⟩,⟨31,62⟩,⟨1,864390243902439029537⟩,⟨207,414⟩]
private def b23817 : Box := ![⟨23,24⟩,⟨25,30⟩,⟨31,62⟩,⟨1,45⟩,⟨207,414⟩]
private def b23832 : Box := ![⟨25,26⟩,⟨25,30⟩,⟨31,62⟩,⟨1,45⟩,⟨207,414⟩]
private def b23833 : Box := ![⟨23,26⟩,⟨25,30⟩,⟨63,1920000000000000011376⟩,⟨1,864390243902439029537⟩,⟨207,414⟩]
private def b23834 : Box := ![⟨27,30⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029538⟩,⟨207,414⟩]
private def b23839 : Box := ![⟨23,30⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029545⟩,⟨415,999999999999999999⟩]
private def b23840 : Box := ![⟨23,26⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨1,764204851752021567899⟩,⟨415,999999999999999999⟩]
private def b23841 : Box := ![⟨23,26⟩,⟨21,24⟩,⟨31,1920000000000000011376⟩,⟨1,764204851752021567899⟩,⟨415,999999999999999999⟩]
private def b23842 : Box := ![⟨23,26⟩,⟨21,24⟩,⟨31,62⟩,⟨1,764204851752021567897⟩,⟨415,999999999999999999⟩]
private def b23843 : Box := ![⟨23,26⟩,⟨21,24⟩,⟨31,62⟩,⟨1,44⟩,⟨415,830⟩]
private def b23856 : Box := ![⟨23,26⟩,⟨21,24⟩,⟨31,62⟩,⟨1,44⟩,⟨831,999999999999999999⟩]
private def b23863 : Box := ![⟨23,26⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567897⟩,⟨415,999999999999999999⟩]
private def b23864 : Box := ![⟨23,26⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨1,2⟩,⟨415,999999999999999999⟩]
private def b23865 : Box := ![⟨23,26⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨3,764204851752021567897⟩,⟨415,999999999999999999⟩]
private def b23866 : Box := ![⟨23,26⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨3,764204851752021567897⟩,⟨415,830⟩]
private def b23879 : Box := ![⟨23,26⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨3,764204851752021567897⟩,⟨831,999999999999999999⟩]
private def b23880 : Box := ![⟨23,24⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨3,685382755842062856623⟩,⟨831,999999999999999999⟩]
private def b23881 : Box := ![⟨23,24⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨3,6⟩,⟨831,999999999999999999⟩]
private def b23882 : Box := ![⟨23,24⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨7,685382755842062856623⟩,⟨831,999999999999999999⟩]
private def b23883 : Box := ![⟨23,24⟩,⟨21,24⟩,⟨63,126⟩,⟨7,685382755842062856623⟩,⟨831,999999999999999999⟩]
private def b23888 : Box := ![⟨23,24⟩,⟨21,24⟩,⟨127,1920000000000000011376⟩,⟨7,685382755842062856623⟩,⟨831,999999999999999999⟩]
private def b23889 : Box := ![⟨23,24⟩,⟨21,24⟩,⟨127,1920000000000000011376⟩,⟨7,685382755842062856623⟩,⟨831,1662⟩]
private def b23890 : Box := ![⟨23,24⟩,⟨21,24⟩,⟨127,1920000000000000011376⟩,⟨7,685382755842062856623⟩,⟨1663,999999999999999999⟩]
private def b23891 : Box := ![⟨23,24⟩,⟨21,24⟩,⟨127,1920000000000000011376⟩,⟨7,621300219138056979597⟩,⟨1663,3326⟩]
private def b23892 : Box := ![⟨23,24⟩,⟨21,24⟩,⟨127,1920000000000000011376⟩,⟨7,621300219138056979597⟩,⟨3327,999999999999999999⟩]
private def b23893 : Box := ![⟨23,24⟩,⟨21,22⟩,⟨127,1920000000000000011376⟩,⟨7,568176352705410825029⟩,⟨3327,999999999999999999⟩]
private def b23894 : Box := ![⟨23,24⟩,⟨23,24⟩,⟨127,1920000000000000011376⟩,⟨7,568176352705410825029⟩,⟨3327,999999999999999999⟩]
private def b23895 : Box := ![⟨23,23⟩,⟨23,24⟩,⟨127,1920000000000000011376⟩,⟨7,568176352705410825029⟩,⟨3327,999999999999999999⟩]
private def b23896 : Box := ![⟨24,24⟩,⟨23,24⟩,⟨127,1920000000000000011376⟩,⟨7,568176352705410825029⟩,⟨3327,999999999999999999⟩]
private def b23897 : Box := ![⟨24,24⟩,⟨23,24⟩,⟨127,1920000000000000011376⟩,⟨7,568176352705410825029⟩,⟨3327,6654⟩]
private def b23898 : Box := ![⟨24,24⟩,⟨23,24⟩,⟨127,1920000000000000011376⟩,⟨7,568176352705410825029⟩,⟨6655,999999999999999999⟩]
private def b23913 : Box := ![⟨25,26⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨3,685382755842062856623⟩,⟨831,999999999999999999⟩]
private def b23914 : Box := ![⟨25,26⟩,⟨21,24⟩,⟨63,126⟩,⟨3,685382755842062856623⟩,⟨831,999999999999999999⟩]
private def b23925 : Box := ![⟨25,26⟩,⟨21,24⟩,⟨127,1920000000000000011376⟩,⟨3,685382755842062856623⟩,⟨831,999999999999999999⟩]
private def b23926 : Box := ![⟨25,26⟩,⟨21,22⟩,⟨127,1920000000000000011376⟩,⟨5,685382755842062856623⟩,⟨973,999999999999999999⟩]
private def b23927 : Box := ![⟨25,26⟩,⟨21,22⟩,⟨127,1920000000000000011376⟩,⟨5,669732283464566933125⟩,⟨973,1946⟩]
private def b23928 : Box := ![⟨25,26⟩,⟨21,22⟩,⟨127,1920000000000000011376⟩,⟨5,669732283464566933125⟩,⟨1947,999999999999999999⟩]
private def b23929 : Box := ![⟨25,26⟩,⟨21,22⟩,⟨127,1920000000000000011376⟩,⟨5,608412017167381977875⟩,⟨1947,3894⟩]
private def b23930 : Box := ![⟨25,26⟩,⟨21,22⟩,⟨127,1920000000000000011376⟩,⟨5,608412017167381977875⟩,⟨3895,999999999999999999⟩]
private def b23931 : Box := ![⟨25,26⟩,⟨21,22⟩,⟨127,1920000000000000011376⟩,⟨5,557378768020969859154⟩,⟨3895,7790⟩]
private def b23932 : Box := ![⟨25,26⟩,⟨21,22⟩,⟨127,1920000000000000011376⟩,⟨5,557378768020969859154⟩,⟨7791,999999999999999999⟩]
private def b23933 : Box := ![⟨25,26⟩,⟨21,22⟩,⟨127,1920000000000000011376⟩,⟨5,514244256348246677792⟩,⟨7791,15582⟩]
private def b23934 : Box := ![⟨25,26⟩,⟨21,22⟩,⟨127,1920000000000000011376⟩,⟨5,514244256348246677792⟩,⟨15583,999999999999999999⟩]
private def b23935 : Box := ![⟨25,26⟩,⟨21,22⟩,⟨127,1920000000000000011376⟩,⟨5,477306397306397309242⟩,⟨15583,31166⟩]
private def b23936 : Box := ![⟨25,26⟩,⟨21,22⟩,⟨127,1920000000000000011376⟩,⟨5,477306397306397309242⟩,⟨31167,999999999999999999⟩]
private def b23937 : Box := ![⟨25,26⟩,⟨21,22⟩,⟨127,254⟩,⟨5,445319371727748693753⟩,⟨31167,999999999999999999⟩]
private def b23952 : Box := ![⟨25,26⟩,⟨21,22⟩,⟨255,1920000000000000011376⟩,⟨5,445319371727748693753⟩,⟨31167,999999999999999999⟩]
private def b23957 : Box := ![⟨25,26⟩,⟨23,24⟩,⟨127,1920000000000000011376⟩,⟨5,685382755842062856623⟩,⟨973,999999999999999999⟩]
private def b23958 : Box := ![⟨23,26⟩,⟨25,30⟩,⟨31,1920000000000000011376⟩,⟨1,764204851752021567899⟩,⟨415,999999999999999999⟩]
private def b23959 : Box := ![⟨23,26⟩,⟨25,30⟩,⟨31,62⟩,⟨1,764204851752021567899⟩,⟨415,999999999999999999⟩]
private def b23960 : Box := ![⟨23,26⟩,⟨25,30⟩,⟨31,62⟩,⟨1,46⟩,⟨415,830⟩]
private def b23973 : Box := ![⟨23,26⟩,⟨25,30⟩,⟨31,62⟩,⟨1,46⟩,⟨831,999999999999999999⟩]
private def b23988 : Box := ![⟨23,26⟩,⟨25,30⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567899⟩,⟨415,999999999999999999⟩]
private def b23989 : Box := ![⟨23,24⟩,⟨25,30⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567899⟩,⟨415,999999999999999999⟩]
private def b23990 : Box := ![⟨23,24⟩,⟨25,30⟩,⟨63,1920000000000000011376⟩,⟨1,2⟩,⟨415,999999999999999999⟩]
private def b23991 : Box := ![⟨23,24⟩,⟨25,30⟩,⟨63,1920000000000000011376⟩,⟨3,764204851752021567898⟩,⟨415,999999999999999999⟩]
private def b23992 : Box := ![⟨23,24⟩,⟨25,30⟩,⟨63,1920000000000000011376⟩,⟨3,764204851752021567898⟩,⟨498,996⟩]
private def b24001 : Box := ![⟨23,24⟩,⟨25,30⟩,⟨63,1920000000000000011376⟩,⟨3,764204851752021567898⟩,⟨997,999999999999999999⟩]
private def b24002 : Box := ![⟨23,24⟩,⟨25,30⟩,⟨63,126⟩,⟨3,667105882352941180448⟩,⟨997,999999999999999999⟩]
private def b24003 : Box := ![⟨23,24⟩,⟨25,27⟩,⟨63,126⟩,⟨3,62⟩,⟨997,999999999999999999⟩]
private def b24018 : Box := ![⟨23,24⟩,⟨28,30⟩,⟨63,126⟩,⟨3,62⟩,⟨997,999999999999999999⟩]
private def b24025 : Box := ![⟨23,24⟩,⟨25,30⟩,⟨127,1920000000000000011376⟩,⟨3,667105882352941180448⟩,⟨997,999999999999999999⟩]
private def b24026 : Box := ![⟨23,24⟩,⟨25,27⟩,⟨127,1920000000000000011376⟩,⟨5,667105882352941180448⟩,⟨1149,999999999999999999⟩]
private def b24027 : Box := ![⟨23,24⟩,⟨25,27⟩,⟨127,1920000000000000011376⟩,⟨5,653774019984627213735⟩,⟨1149,2298⟩]
private def b24028 : Box := ![⟨23,24⟩,⟨25,27⟩,⟨127,1920000000000000011376⟩,⟨5,653774019984627213735⟩,⟨2299,999999999999999999⟩]
private def b24029 : Box := ![⟨23,23⟩,⟨25,27⟩,⟨127,1920000000000000011376⟩,⟨5,595213435969209240777⟩,⟨2299,999999999999999999⟩]
private def b24030 : Box := ![⟨23,23⟩,⟨25,27⟩,⟨127,1920000000000000011376⟩,⟨5,595213435969209240776⟩,⟨2299,4598⟩]
private def b24031 : Box := ![⟨23,23⟩,⟨25,27⟩,⟨127,1920000000000000011376⟩,⟨5,595213435969209240776⟩,⟨4599,999999999999999999⟩]
private def b24032 : Box := ![⟨23,23⟩,⟨25,27⟩,⟨127,1920000000000000011376⟩,⟨5,546281310211946053352⟩,⟨4599,9198⟩]
private def b24033 : Box := ![⟨23,23⟩,⟨25,27⟩,⟨127,1920000000000000011376⟩,⟨5,546281310211946053352⟩,⟨9199,999999999999999999⟩]
private def b24034 : Box := ![⟨23,23⟩,⟨25,27⟩,⟨127,1920000000000000011376⟩,⟨5,504783382789317510427⟩,⟨9199,18398⟩]
private def b24035 : Box := ![⟨23,23⟩,⟨25,27⟩,⟨127,1920000000000000011376⟩,⟨5,504783382789317510427⟩,⟨18399,999999999999999999⟩]
private def b24036 : Box := ![⟨23,23⟩,⟨25,27⟩,⟨127,1920000000000000011376⟩,⟨5,469145063430777719288⟩,⟨18399,36798⟩]
private def b24037 : Box := ![⟨23,23⟩,⟨25,27⟩,⟨127,1920000000000000011376⟩,⟨5,469145063430777719288⟩,⟨36799,999999999999999999⟩]
private def b24038 : Box := ![⟨23,23⟩,⟨25,27⟩,⟨127,254⟩,⟨5,438207109737248843415⟩,⟨36799,999999999999999999⟩]
private def b24053 : Box := ![⟨23,23⟩,⟨25,27⟩,⟨255,1920000000000000011376⟩,⟨5,438207109737248843415⟩,⟨36799,999999999999999999⟩]
private def b24058 : Box := ![⟨24,24⟩,⟨25,27⟩,⟨127,1920000000000000011376⟩,⟨5,595213435969209240777⟩,⟨2299,999999999999999999⟩]
private def b24059 : Box := ![⟨23,24⟩,⟨28,30⟩,⟨127,1920000000000000011376⟩,⟨5,667105882352941180448⟩,⟨1149,999999999999999999⟩]
private def b24060 : Box := ![⟨25,26⟩,⟨25,30⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567899⟩,⟨415,999999999999999999⟩]
private def b24061 : Box := ![⟨27,30⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨1,764204851752021567899⟩,⟨415,999999999999999999⟩]
private def b24062 : Box := ![⟨27,30⟩,⟨21,24⟩,⟨31,1920000000000000011376⟩,⟨1,764204851752021567899⟩,⟨415,999999999999999999⟩]
private def b24063 : Box := ![⟨27,30⟩,⟨21,24⟩,⟨31,62⟩,⟨1,764204851752021567898⟩,⟨415,999999999999999999⟩]
private def b24064 : Box := ![⟨27,30⟩,⟨21,24⟩,⟨31,62⟩,⟨1,45⟩,⟨415,830⟩]
private def b24071 : Box := ![⟨27,30⟩,⟨21,24⟩,⟨31,62⟩,⟨1,45⟩,⟨831,999999999999999999⟩]
private def b24080 : Box := ![⟨27,30⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567898⟩,⟨415,999999999999999999⟩]
private def b24089 : Box := ![⟨27,30⟩,⟨25,30⟩,⟨31,1920000000000000011376⟩,⟨1,764204851752021567899⟩,⟨415,999999999999999999⟩]
theorem deny5_11 : Deny 5 11 ![⟨23,30⟩,⟨15,30⟩,⟨15,1920000000000000011376⟩,⟨1,994807017543859655055⟩,⟨207,999999999999999999⟩] := by
  have e23422 : Deny 5 11 b23422 := by
    apply closeAction rule_sound _ _ 64 [0xc21f68c4088e37da3]
    decide +kernel
  have e23427 : Deny 5 11 b23427 := by
    apply closeAction rule_sound _ _ 64 [0xc3e37da31f8df68c8e368c30c70c3e37d87e37da320be23]
    decide +kernel
  have e23421 : Deny 5 11 b23421 :=
    branchAction rule_sound _ _ 3
      0x7e23 b23421 b23422 b23427 (by decide +kernel) e23422 e23427
  have e23443 : Deny 5 11 b23443 := by
    apply closeAction rule_sound _ _ 64 [0x3e37d62]
    decide +kernel
  have e23446 : Deny 5 11 b23446 := by
    apply closeAction rule_sound _ _ 64 [0xa2]
    decide +kernel
  have e23447 : Deny 5 11 b23447 := by
    apply closeAction rule_sound _ _ 64 [0x72f71cbcb8c472f10b72f8c7e2f8c90c3e37d87d84087e368c9]
    decide +kernel
  have e23445 : Deny 5 11 b23445 :=
    branchAction rule_sound _ _ 2
      0x2a3 b23445 b23446 b23447 (by decide +kernel) e23446 e23447
  have e23463 : Deny 5 11 b23463 := by
    apply closeAction rule_sound _ _ 64 [0x3bc38c90f8df68c70f8df68c88c30e31c30f8df61e31c42e3]
    decide +kernel
  have e23478 : Deny 5 11 b23478 := by
    apply closeAction rule_sound _ _ 64 [0x72f72f72f0f80f8bc78c98c9be326f]
    decide +kernel
  have e23462 : Deny 5 11 b23462 :=
    branchAction rule_sound _ _ 1
      0x9 b23462 b23463 b23478 (by decide +kernel) e23463 e23478
  have e23444 : Deny 5 11 b23444 :=
    branchAction rule_sound _ _ 1
      0x8 b23444 b23445 b23462 (by decide +kernel) e23445 e23462
  have e23442 : Deny 5 11 b23442 :=
    branchAction rule_sound _ _ 2
      0x2a3 b23442 b23443 b23444 (by decide +kernel) e23443 e23444
  have e23489 : Deny 5 11 b23489 := by
    apply closeAction rule_sound _ _ 64 [0x3e22]
    decide +kernel
  have e23492 : Deny 5 11 b23492 := by
    apply closeAction rule_sound _ _ 64 [0xf8dc3be31ef0e32430f8df61e3204]
    decide +kernel
  have e23501 : Deny 5 11 b23501 := by
    apply closeAction rule_sound _ _ 64 [0x30e31ef0e3243e37da3223]
    decide +kernel
  have e23491 : Deny 5 11 b23491 :=
    branchAction rule_sound _ _ 2
      0x2e3 b23491 b23492 b23501 (by decide +kernel) e23492 e23501
  have e23508 : Deny 5 11 b23508 := by
    apply closeAction rule_sound _ _ 64 [0x72f72f72f0f80f8bc88c98c9be326f]
    decide +kernel
  have e23490 : Deny 5 11 b23490 :=
    branchAction rule_sound _ _ 1
      0x9 b23490 b23491 b23508 (by decide +kernel) e23491 e23508
  have e23488 : Deny 5 11 b23488 :=
    branchAction rule_sound _ _ 2
      0x2a3 b23488 b23489 b23490 (by decide +kernel) e23489 e23490
  have e23518 : Deny 5 11 b23518 := by
    apply closeAction rule_sound _ _ 64 [0x20e3109e030c78c78c20af0e32631c42f80e22a3]
    decide +kernel
  have e23533 : Deny 5 11 b23533 := by
    apply closeAction rule_sound _ _ 64 [0x538def]
    decide +kernel
  have e23517 : Deny 5 11 b23517 :=
    branchAction rule_sound _ _ 1
      0x9 b23517 b23518 b23533 (by decide +kernel) e23518 e23533
  have e23487 : Deny 5 11 b23487 :=
    branchAction rule_sound _ _ 1
      0x8 b23487 b23488 b23517 (by decide +kernel) e23488 e23517
  have e23441 : Deny 5 11 b23441 :=
    branchAction rule_sound _ _ 2
      0x1e3 b23441 b23442 b23487 (by decide +kernel) e23442 e23487
  have e23536 : Deny 5 11 b23536 := by
    apply closeAction rule_sound _ _ 64 [0x538df6d62]
    decide +kernel
  have e23538 : Deny 5 11 b23538 := by
    apply closeAction rule_sound _ _ 64 [0x72f8c4087e37da3]
    decide +kernel
  have e23542 : Deny 5 11 b23542 := by
    apply closeAction rule_sound _ _ 64 [0x3bc3e37da32422388c21f8da3]
    decide +kernel
  have e23550 : Deny 5 11 b23550 := by
    apply closeAction rule_sound _ _ 64 [0x14e22]
    decide +kernel
  have e23552 : Deny 5 11 b23552 := by
    apply closeAction rule_sound _ _ 64 [0x72f72f8c9be3]
    decide +kernel
  have e23556 : Deny 5 11 b23556 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e23558 : Deny 5 11 b23558 := by
    apply closeAction rule_sound _ _ 64 [0x738df6]
    decide +kernel
  have e23560 : Deny 5 11 b23560 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3087e23]
    decide +kernel
  have e23563 : Deny 5 11 b23563 := by
    apply closeAction rule_sound _ _ 64 [0x9cbe3278be372f8c9e2f738daf8c9bc22368dcbe32c21e372f8cb]
    decide +kernel
  have e23559 : Deny 5 11 b23559 :=
    branchAction rule_sound _ _ 1
      0x9 b23559 b23560 b23563 (by decide +kernel) e23560 e23563
  have e23557 : Deny 5 11 b23557 :=
    branchAction rule_sound _ _ 1
      0x8 b23557 b23558 b23559 (by decide +kernel) e23558 e23559
  have e23555 : Deny 5 11 b23555 :=
    branchAction rule_sound _ _ 2
      0x1e3 b23555 b23556 b23557 (by decide +kernel) e23556 e23557
  have e23551 : Deny 5 11 b23551 :=
    branchAction rule_sound _ _ 1
      0xb b23551 b23552 b23555 (by decide +kernel) e23552 e23555
  have e23549 : Deny 5 11 b23549 :=
    branchAction rule_sound _ _ 1
      0xa b23549 b23550 b23551 (by decide +kernel) e23550 e23551
  have e23541 : Deny 5 11 b23541 :=
    branchAction rule_sound _ _ 1
      0x9 b23541 b23542 b23549 (by decide +kernel) e23542 e23549
  have e23537 : Deny 5 11 b23537 :=
    branchAction rule_sound _ _ 1
      0x8 b23537 b23538 b23541 (by decide +kernel) e23538 e23541
  have e23535 : Deny 5 11 b23535 :=
    branchAction rule_sound _ _ 3
      0xada3 b23535 b23536 b23537 (by decide +kernel) e23536 e23537
  have e23580 : Deny 5 11 b23580 := by
    apply closeAction rule_sound _ _ 64 [0x538da2]
    decide +kernel
  have e23582 : Deny 5 11 b23582 := by
    apply closeAction rule_sound _ _ 64 [0x3e2f0f8de3243e37d87e23088e23]
    decide +kernel
  have e23590 : Deny 5 11 b23590 := by
    apply closeAction rule_sound _ _ 64 [0x14e22]
    decide +kernel
  have e23592 : Deny 5 11 b23592 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdcbc30f88c70888c9be3263]
    decide +kernel
  have e23602 : Deny 5 11 b23602 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e23604 : Deny 5 11 b23604 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3088e36]
    decide +kernel
  have e23608 : Deny 5 11 b23608 := by
    apply closeAction rule_sound _ _ 64 [0x72f8c3e2f8c9e23]
    decide +kernel
  have e23612 : Deny 5 11 b23612 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e23614 : Deny 5 11 b23614 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e23616 : Deny 5 11 b23616 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e23617 : Deny 5 11 b23617 := by
    apply closeAction rule_sound _ _ 64 [0x2738d87bc20e32421ef8c9da372f8cbda372f8cbda372f8cb]
    decide +kernel
  have e23615 : Deny 5 11 b23615 :=
    branchAction rule_sound _ _ 2
      0x223 b23615 b23616 b23617 (by decide +kernel) e23616 e23617
  have e23613 : Deny 5 11 b23613 :=
    branchAction rule_sound _ _ 2
      0x2e3 b23613 b23614 b23615 (by decide +kernel) e23614 e23615
  have e23611 : Deny 5 11 b23611 :=
    branchAction rule_sound _ _ 1
      0xb b23611 b23612 b23613 (by decide +kernel) e23612 e23613
  have e23607 : Deny 5 11 b23607 :=
    branchAction rule_sound _ _ 1
      0x9 b23607 b23608 b23611 (by decide +kernel) e23608 e23611
  have e23603 : Deny 5 11 b23603 :=
    branchAction rule_sound _ _ 1
      0x7 b23603 b23604 b23607 (by decide +kernel) e23604 e23607
  have e23601 : Deny 5 11 b23601 :=
    branchAction rule_sound _ _ 2
      0x223 b23601 b23602 b23603 (by decide +kernel) e23602 e23603
  have e23591 : Deny 5 11 b23591 :=
    branchAction rule_sound _ _ 1
      0xb b23591 b23592 b23601 (by decide +kernel) e23592 e23601
  have e23589 : Deny 5 11 b23589 :=
    branchAction rule_sound _ _ 1
      0xa b23589 b23590 b23591 (by decide +kernel) e23590 e23591
  have e23581 : Deny 5 11 b23581 :=
    branchAction rule_sound _ _ 1
      0x9 b23581 b23582 b23589 (by decide +kernel) e23582 e23589
  have e23579 : Deny 5 11 b23579 :=
    branchAction rule_sound _ _ 2
      0x2a3 b23579 b23580 b23581 (by decide +kernel) e23580 e23581
  have e23634 : Deny 5 11 b23634 := by
    apply closeAction rule_sound _ _ 64 [0xc31c30e31c70e22a3]
    decide +kernel
  have e23643 : Deny 5 11 b23643 := by
    apply closeAction rule_sound _ _ 64 [0x30c70f8da30f8df68c7e361e3]
    decide +kernel
  have e23633 : Deny 5 11 b23633 :=
    branchAction rule_sound _ _ 2
      0x2e3 b23633 b23634 b23643 (by decide +kernel) e23634 e23643
  have e23651 : Deny 5 11 b23651 := by
    apply closeAction rule_sound _ _ 64 [0x3be2]
    decide +kernel
  have e23653 : Deny 5 11 b23653 := by
    apply closeAction rule_sound _ _ 64 [0x9cbdcbe30f80e3223278be3247be3]
    decide +kernel
  have e23664 : Deny 5 11 b23664 := by
    apply closeAction rule_sound _ _ 64 [0x3e03e07bc38c972f8dcbe32f8da3223]
    decide +kernel
  have e23674 : Deny 5 11 b23674 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e23676 : Deny 5 11 b23676 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e23678 : Deny 5 11 b23678 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e23680 : Deny 5 11 b23680 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e23682 : Deny 5 11 b23682 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e23684 : Deny 5 11 b23684 := by
    apply closeAction rule_sound _ _ 64 [0x272f8c9daf087da3]
    decide +kernel
  have e23689 : Deny 5 11 b23689 := by
    apply closeAction rule_sound _ _ 64 [0x208272f8c9d88bc20f88c9e0222f8c98c7]
    decide +kernel
  have e23683 : Deny 5 11 b23683 :=
    branchAction rule_sound _ _ 2
      0x223 b23683 b23684 b23689 (by decide +kernel) e23684 e23689
  have e23681 : Deny 5 11 b23681 :=
    branchAction rule_sound _ _ 2
      0x2e3 b23681 b23682 b23683 (by decide +kernel) e23682 e23683
  have e23679 : Deny 5 11 b23679 :=
    branchAction rule_sound _ _ 2
      0x2e3 b23679 b23680 b23681 (by decide +kernel) e23680 e23681
  have e23677 : Deny 5 11 b23677 :=
    branchAction rule_sound _ _ 2
      0x2e3 b23677 b23678 b23679 (by decide +kernel) e23678 e23679
  have e23675 : Deny 5 11 b23675 :=
    branchAction rule_sound _ _ 2
      0x2e3 b23675 b23676 b23677 (by decide +kernel) e23676 e23677
  have e23673 : Deny 5 11 b23673 :=
    branchAction rule_sound _ _ 2
      0x2ef b23673 b23674 b23675 (by decide +kernel) e23674 e23675
  have e23663 : Deny 5 11 b23663 :=
    branchAction rule_sound _ _ 2
      0x263 b23663 b23664 b23673 (by decide +kernel) e23664 e23673
  have e23702 : Deny 5 11 b23702 := by
    apply closeAction rule_sound _ _ 64 [0x82083e23278be3263238be3083e232780f8bc3e23248e23278]
    decide +kernel
  have e23662 : Deny 5 11 b23662 :=
    branchAction rule_sound _ _ 2
      0x1e3 b23662 b23663 b23702 (by decide +kernel) e23663 e23702
  have e23652 : Deny 5 11 b23652 :=
    branchAction rule_sound _ _ 1
      0xb b23652 b23653 b23662 (by decide +kernel) e23653 e23662
  have e23650 : Deny 5 11 b23650 :=
    branchAction rule_sound _ _ 1
      0xa b23650 b23651 b23652 (by decide +kernel) e23651 e23652
  have e23632 : Deny 5 11 b23632 :=
    branchAction rule_sound _ _ 1
      0x9 b23632 b23633 b23650 (by decide +kernel) e23633 e23650
  have e23578 : Deny 5 11 b23578 :=
    branchAction rule_sound _ _ 1
      0x8 b23578 b23579 b23632 (by decide +kernel) e23579 e23632
  have e23534 : Deny 5 11 b23534 :=
    branchAction rule_sound _ _ 2
      0x1e3 b23534 b23535 b23578 (by decide +kernel) e23535 e23578
  have e23440 : Deny 5 11 b23440 :=
    branchAction rule_sound _ _ 1
      0xb b23440 b23441 b23534 (by decide +kernel) e23441 e23534
  have e23420 : Deny 5 11 b23420 :=
    branchAction rule_sound _ _ 2
      0x263 b23420 b23421 b23440 (by decide +kernel) e23421 e23440
  have e23720 : Deny 5 11 b23720 := by
    apply closeAction rule_sound _ _ 64 [0xf8dc31c38c90c38c78c90c3e378c70f8de3263223]
    decide +kernel
  have e23735 : Deny 5 11 b23735 := by
    apply closeAction rule_sound _ _ 64 [0x17e370f8dc38c78c90f8dc31c38c98c8]
    decide +kernel
  have e23719 : Deny 5 11 b23719 :=
    branchAction rule_sound _ _ 2
      0x1e3 b23719 b23720 b23735 (by decide +kernel) e23720 e23735
  have e23747 : Deny 5 11 b23747 := by
    apply closeAction rule_sound _ _ 64 [0xc3e231c38c90f88c3e37da31f88c90f88c21f8da3223]
    decide +kernel
  have e23760 : Deny 5 11 b23760 := by
    apply closeAction rule_sound _ _ 64 [0x20f88c7e038c90c31e32430c70f88c98c8]
    decide +kernel
  have e23746 : Deny 5 11 b23746 :=
    branchAction rule_sound _ _ 2
      0x1e3 b23746 b23747 b23760 (by decide +kernel) e23747 e23760
  have e23718 : Deny 5 11 b23718 :=
    branchAction rule_sound _ _ 2
      0x2e3 b23718 b23719 b23746 (by decide +kernel) e23719 e23746
  have e23780 : Deny 5 11 b23780 := by
    apply closeAction rule_sound _ _ 64 [0xaf8832770f8dc3be322f0e324388a1c4]
    decide +kernel
  have e23791 : Deny 5 11 b23791 := by
    apply closeAction rule_sound _ _ 64 [0x20e3108e2f0e324388a0c3be322f0e3243e3788a1e3]
    decide +kernel
  have e23779 : Deny 5 11 b23779 :=
    branchAction rule_sound _ _ 2
      0x2e3 b23779 b23780 b23791 (by decide +kernel) e23780 e23791
  have e23806 : Deny 5 11 b23806 := by
    apply closeAction rule_sound _ _ 64 [0x9cbdcbe30f8dc38c8e2f8c9e2f8c98c7e2f]
    decide +kernel
  have e23778 : Deny 5 11 b23778 :=
    branchAction rule_sound _ _ 2
      0x263 b23778 b23779 b23806 (by decide +kernel) e23779 e23806
  have e23817 : Deny 5 11 b23817 := by
    apply closeAction rule_sound _ _ 64 [0x20c4278dc3e370c78c80c388888a8d7e37883887de310b]
    decide +kernel
  have e23832 : Deny 5 11 b23832 := by
    apply closeAction rule_sound _ _ 64 [0x17e37]
    decide +kernel
  have e23816 : Deny 5 11 b23816 :=
    branchAction rule_sound _ _ 2
      0x1e3 b23816 b23817 b23832 (by decide +kernel) e23817 e23832
  have e23833 : Deny 5 11 b23833 := by
    apply closeAction rule_sound _ _ 64 [0xaf]
    decide +kernel
  have e23815 : Deny 5 11 b23815 :=
    branchAction rule_sound _ _ 1
      0x9 b23815 b23816 b23833 (by decide +kernel) e23816 e23833
  have e23777 : Deny 5 11 b23777 :=
    branchAction rule_sound _ _ 2
      0x223 b23777 b23778 b23815 (by decide +kernel) e23778 e23815
  have e23834 : Deny 5 11 b23834 := by
    apply closeAction rule_sound _ _ 64 [0x820e21f8888e37]
    decide +kernel
  have e23776 : Deny 5 11 b23776 :=
    branchAction rule_sound _ _ 2
      0x1e3 b23776 b23777 b23834 (by decide +kernel) e23777 e23834
  have e23843 : Deny 5 11 b23843 := by
    apply closeAction rule_sound _ _ 64 [0x3e03bc8bc38c90c3e37da322f0f8de324288a1e3]
    decide +kernel
  have e23856 : Deny 5 11 b23856 := by
    apply closeAction rule_sound _ _ 64 [0xc3e080f88c90f8df61e3]
    decide +kernel
  have e23842 : Deny 5 11 b23842 :=
    branchAction rule_sound _ _ 2
      0x2e3 b23842 b23843 b23856 (by decide +kernel) e23843 e23856
  have e23864 : Deny 5 11 b23864 := by
    apply closeAction rule_sound _ _ 64 [0x3be2]
    decide +kernel
  have e23866 : Deny 5 11 b23866 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdcbdc083e2f888e030f8be22221e22a326f8c9be3]
    decide +kernel
  have e23881 : Deny 5 11 b23881 := by
    apply closeAction rule_sound _ _ 64 [0x14e22]
    decide +kernel
  have e23883 : Deny 5 11 b23883 := by
    apply closeAction rule_sound _ _ 64 [0x72f0f88c9e2f8dce37daf8c8e23]
    decide +kernel
  have e23889 : Deny 5 11 b23889 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e23891 : Deny 5 11 b23891 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e23893 : Deny 5 11 b23893 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e23895 : Deny 5 11 b23895 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e23897 : Deny 5 11 b23897 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e23898 : Deny 5 11 b23898 := by
    apply closeAction rule_sound _ _ 64 [0x8272f8c9d88bc20e324222f8c9da372f8cbda372f8cbda3]
    decide +kernel
  have e23896 : Deny 5 11 b23896 :=
    branchAction rule_sound _ _ 1
      0xb b23896 b23897 b23898 (by decide +kernel) e23897 e23898
  have e23894 : Deny 5 11 b23894 :=
    branchAction rule_sound _ _ 1
      0x7 b23894 b23895 b23896 (by decide +kernel) e23895 e23896
  have e23892 : Deny 5 11 b23892 :=
    branchAction rule_sound _ _ 2
      0x223 b23892 b23893 b23894 (by decide +kernel) e23893 e23894
  have e23890 : Deny 5 11 b23890 :=
    branchAction rule_sound _ _ 2
      0x2e3 b23890 b23891 b23892 (by decide +kernel) e23891 e23892
  have e23888 : Deny 5 11 b23888 :=
    branchAction rule_sound _ _ 1
      0xb b23888 b23889 b23890 (by decide +kernel) e23889 e23890
  have e23882 : Deny 5 11 b23882 :=
    branchAction rule_sound _ _ 1
      0x9 b23882 b23883 b23888 (by decide +kernel) e23883 e23888
  have e23880 : Deny 5 11 b23880 :=
    branchAction rule_sound _ _ 1
      0xa b23880 b23881 b23882 (by decide +kernel) e23881 e23882
  have e23914 : Deny 5 11 b23914 := by
    apply closeAction rule_sound _ _ 64 [0x83e03e232631f80f80f81ef0f88c9223]
    decide +kernel
  have e23927 : Deny 5 11 b23927 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e23929 : Deny 5 11 b23929 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e23931 : Deny 5 11 b23931 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e23933 : Deny 5 11 b23933 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e23935 : Deny 5 11 b23935 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e23937 : Deny 5 11 b23937 := by
    apply closeAction rule_sound _ _ 64 [0x7020f688808788a8dcbe32e372f8cb8dcbe32e372f8cbbe3]
    decide +kernel
  have e23952 : Deny 5 11 b23952 := by
    apply closeAction rule_sound _ _ 64 [0x820881ef]
    decide +kernel
  have e23936 : Deny 5 11 b23936 :=
    branchAction rule_sound _ _ 2
      0x263 b23936 b23937 b23952 (by decide +kernel) e23937 e23952
  have e23934 : Deny 5 11 b23934 :=
    branchAction rule_sound _ _ 2
      0x2e3 b23934 b23935 b23936 (by decide +kernel) e23935 e23936
  have e23932 : Deny 5 11 b23932 :=
    branchAction rule_sound _ _ 2
      0x2e3 b23932 b23933 b23934 (by decide +kernel) e23933 e23934
  have e23930 : Deny 5 11 b23930 :=
    branchAction rule_sound _ _ 2
      0x2e3 b23930 b23931 b23932 (by decide +kernel) e23931 e23932
  have e23928 : Deny 5 11 b23928 :=
    branchAction rule_sound _ _ 2
      0x2e3 b23928 b23929 b23930 (by decide +kernel) e23929 e23930
  have e23926 : Deny 5 11 b23926 :=
    branchAction rule_sound _ _ 2
      0x2e3 b23926 b23927 b23928 (by decide +kernel) e23927 e23928
  have e23957 : Deny 5 11 b23957 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e23925 : Deny 5 11 b23925 :=
    branchAction rule_sound _ _ 3
      0x8e2f b23925 b23926 b23957 (by decide +kernel) e23926 e23957
  have e23913 : Deny 5 11 b23913 :=
    branchAction rule_sound _ _ 1
      0x9 b23913 b23914 b23925 (by decide +kernel) e23914 e23925
  have e23879 : Deny 5 11 b23879 :=
    branchAction rule_sound _ _ 2
      0x1e3 b23879 b23880 b23913 (by decide +kernel) e23880 e23913
  have e23865 : Deny 5 11 b23865 :=
    branchAction rule_sound _ _ 1
      0xb b23865 b23866 b23879 (by decide +kernel) e23866 e23879
  have e23863 : Deny 5 11 b23863 :=
    branchAction rule_sound _ _ 1
      0xa b23863 b23864 b23865 (by decide +kernel) e23864 e23865
  have e23841 : Deny 5 11 b23841 :=
    branchAction rule_sound _ _ 2
      0x263 b23841 b23842 b23863 (by decide +kernel) e23842 e23863
  have e23960 : Deny 5 11 b23960 := by
    apply closeAction rule_sound _ _ 64 [0x20af0e32632030c70c38c72231e3]
    decide +kernel
  have e23973 : Deny 5 11 b23973 := by
    apply closeAction rule_sound _ _ 64 [0x20f88c9e030c78c80c3da31c30f8df61f68c81e3]
    decide +kernel
  have e23959 : Deny 5 11 b23959 :=
    branchAction rule_sound _ _ 2
      0x2e3 b23959 b23960 b23973 (by decide +kernel) e23960 e23973
  have e23990 : Deny 5 11 b23990 := by
    apply closeAction rule_sound _ _ 64 [0xf8be2]
    decide +kernel
  have e23992 : Deny 5 11 b23992 := by
    apply closeAction rule_sound _ _ 64 [0x208272f0e32631e3238be3263]
    decide +kernel
  have e24003 : Deny 5 11 b24003 := by
    apply closeAction rule_sound _ _ 64 [0x83e232380e325cbe30f8daf8c9e361e372f0f80ef8c78c9be32e3]
    decide +kernel
  have e24018 : Deny 5 11 b24018 := by
    apply closeAction rule_sound _ _ 64 [0x2083e232380f88c9e231f8]
    decide +kernel
  have e24002 : Deny 5 11 b24002 :=
    branchAction rule_sound _ _ 2
      0x223 b24002 b24003 b24018 (by decide +kernel) e24003 e24018
  have e24027 : Deny 5 11 b24027 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e24030 : Deny 5 11 b24030 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e24032 : Deny 5 11 b24032 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e24034 : Deny 5 11 b24034 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e24036 : Deny 5 11 b24036 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e24038 : Deny 5 11 b24038 := by
    apply closeAction rule_sound _ _ 64 [0x70308888a8dcbe32e372f8cb8dcbe32e372f8cb088be3]
    decide +kernel
  have e24053 : Deny 5 11 b24053 := by
    apply closeAction rule_sound _ _ 64 [0x209cbe327622f]
    decide +kernel
  have e24037 : Deny 5 11 b24037 :=
    branchAction rule_sound _ _ 2
      0x263 b24037 b24038 b24053 (by decide +kernel) e24038 e24053
  have e24035 : Deny 5 11 b24035 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24035 b24036 b24037 (by decide +kernel) e24036 e24037
  have e24033 : Deny 5 11 b24033 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24033 b24034 b24035 (by decide +kernel) e24034 e24035
  have e24031 : Deny 5 11 b24031 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24031 b24032 b24033 (by decide +kernel) e24032 e24033
  have e24029 : Deny 5 11 b24029 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24029 b24030 b24031 (by decide +kernel) e24030 e24031
  have e24058 : Deny 5 11 b24058 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e24028 : Deny 5 11 b24028 :=
    branchAction rule_sound _ _ 2
      0x1e3 b24028 b24029 b24058 (by decide +kernel) e24029 e24058
  have e24026 : Deny 5 11 b24026 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24026 b24027 b24028 (by decide +kernel) e24027 e24028
  have e24059 : Deny 5 11 b24059 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e24025 : Deny 5 11 b24025 :=
    branchAction rule_sound _ _ 3
      0x8e2f b24025 b24026 b24059 (by decide +kernel) e24026 e24059
  have e24001 : Deny 5 11 b24001 :=
    branchAction rule_sound _ _ 2
      0x263 b24001 b24002 b24025 (by decide +kernel) e24002 e24025
  have e23991 : Deny 5 11 b23991 :=
    branchAction rule_sound _ _ 2
      0x2f8 b23991 b23992 b24001 (by decide +kernel) e23992 e24001
  have e23989 : Deny 5 11 b23989 :=
    branchAction rule_sound _ _ 2
      0x2a3 b23989 b23990 b23991 (by decide +kernel) e23990 e23991
  have e24060 : Deny 5 11 b24060 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e23988 : Deny 5 11 b23988 :=
    branchAction rule_sound _ _ 1
      0x7 b23988 b23989 b24060 (by decide +kernel) e23989 e24060
  have e23958 : Deny 5 11 b23958 :=
    branchAction rule_sound _ _ 1
      0x9 b23958 b23959 b23988 (by decide +kernel) e23959 e23988
  have e23840 : Deny 5 11 b23840 :=
    branchAction rule_sound _ _ 1
      0x8 b23840 b23841 b23958 (by decide +kernel) e23841 e23958
  have e24064 : Deny 5 11 b24064 := by
    apply closeAction rule_sound _ _ 64 [0x820f8be2108e37bc38c91e3]
    decide +kernel
  have e24071 : Deny 5 11 b24071 := by
    apply closeAction rule_sound _ _ 64 [0x83e232780f80e32038c91e3]
    decide +kernel
  have e24063 : Deny 5 11 b24063 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24063 b24064 b24071 (by decide +kernel) e24064 e24071
  have e24080 : Deny 5 11 b24080 := by
    apply closeAction rule_sound _ _ 64 [0x820820f88c9e23238be32631f8]
    decide +kernel
  have e24062 : Deny 5 11 b24062 :=
    branchAction rule_sound _ _ 2
      0x263 b24062 b24063 b24080 (by decide +kernel) e24063 e24080
  have e24089 : Deny 5 11 b24089 := by
    apply closeAction rule_sound _ _ 64 [0x2082083e232782388c7e23278]
    decide +kernel
  have e24061 : Deny 5 11 b24061 :=
    branchAction rule_sound _ _ 1
      0x8 b24061 b24062 b24089 (by decide +kernel) e24062 e24089
  have e23839 : Deny 5 11 b23839 :=
    branchAction rule_sound _ _ 2
      0x1e3 b23839 b23840 b24061 (by decide +kernel) e23840 e24061
  have e23775 : Deny 5 11 b23775 :=
    branchAction rule_sound _ _ 1
      0xb b23775 b23776 b23839 (by decide +kernel) e23776 e23839
  have e23717 : Deny 5 11 b23717 :=
    branchAction rule_sound _ _ 1
      0x9 b23717 b23718 b23775 (by decide +kernel) e23718 e23775
  have e23419 : Deny 5 11 b23419 :=
    branchAction rule_sound _ _ 2
      0x223 b23419 b23420 b23717 (by decide +kernel) e23420 e23717
  exact e23419
end OMA.Blocks5_11_245212.S23419
