import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S48812
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b48812 : Box := ![⟨95,190⟩,⟨21,24⟩,⟨15,30⟩,⟨1,62⟩,⟨479,999999999999999999⟩]
private def b48813 : Box := ![⟨95,126⟩,⟨21,24⟩,⟨15,30⟩,⟨1,61⟩,⟨479,999999999999999999⟩]
private def b48814 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨21,30⟩,⟨2,49⟩,⟨479,829⟩]
private def b48815 : Box := ![⟨95,126⟩,⟨23,24⟩,⟨21,30⟩,⟨2,49⟩,⟨479,829⟩]
private def b48816 : Box := ![⟨95,108⟩,⟨23,24⟩,⟨21,30⟩,⟨2,44⟩,⟨479,827⟩]
private def b48817 : Box := ![⟨109,126⟩,⟨23,24⟩,⟨21,30⟩,⟨2,44⟩,⟨479,827⟩]
private def b48828 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨15,30⟩,⟨1,61⟩,⟨479,999999999999999999⟩]
private def b48829 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨15,20⟩,⟨1,61⟩,⟨479,999999999999999999⟩]
private def b48832 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨21,30⟩,⟨1,61⟩,⟨479,999999999999999999⟩]
private def b48833 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨21,30⟩,⟨1,61⟩,⟨479,958⟩]
private def b48834 : Box := ![⟨127,190⟩,⟨21,22⟩,⟨21,30⟩,⟨2,55⟩,⟨479,958⟩]
private def b48835 : Box := ![⟨127,190⟩,⟨21,22⟩,⟨21,30⟩,⟨2,4⟩,⟨479,958⟩]
private def b48836 : Box := ![⟨127,190⟩,⟨21,22⟩,⟨21,30⟩,⟨5,55⟩,⟨479,958⟩]
private def b48837 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨21,30⟩,⟨5,55⟩,⟨479,958⟩]
private def b48846 : Box := ![⟨153,190⟩,⟨21,22⟩,⟨21,30⟩,⟨5,55⟩,⟨479,958⟩]
private def b48847 : Box := ![⟨153,190⟩,⟨21,22⟩,⟨21,24⟩,⟨7,55⟩,⟨479,958⟩]
private def b48848 : Box := ![⟨153,190⟩,⟨21,22⟩,⟨21,24⟩,⟨9,52⟩,⟨479,571⟩]
private def b48855 : Box := ![⟨153,190⟩,⟨21,22⟩,⟨21,24⟩,⟨9,52⟩,⟨572,709⟩]
private def b48860 : Box := ![⟨153,190⟩,⟨21,22⟩,⟨25,30⟩,⟨7,55⟩,⟨479,958⟩]
private def b48861 : Box := ![⟨153,190⟩,⟨21,22⟩,⟨25,30⟩,⟨7,55⟩,⟨479,638⟩]
private def b48872 : Box := ![⟨153,190⟩,⟨21,22⟩,⟨25,30⟩,⟨7,55⟩,⟨639,958⟩]
private def b48873 : Box := ![⟨153,169⟩,⟨21,22⟩,⟨25,30⟩,⟨7,52⟩,⟨639,958⟩]
private def b48878 : Box := ![⟨170,190⟩,⟨21,22⟩,⟨25,30⟩,⟨7,52⟩,⟨639,958⟩]
private def b48889 : Box := ![⟨127,190⟩,⟨23,24⟩,⟨21,30⟩,⟨2,55⟩,⟨479,958⟩]
private def b48890 : Box := ![⟨127,152⟩,⟨23,24⟩,⟨21,30⟩,⟨2,55⟩,⟨479,958⟩]
private def b48891 : Box := ![⟨127,152⟩,⟨23,24⟩,⟨21,24⟩,⟨2,48⟩,⟨479,958⟩]
private def b48894 : Box := ![⟨127,152⟩,⟨23,24⟩,⟨25,30⟩,⟨2,48⟩,⟨479,958⟩]
private def b48895 : Box := ![⟨127,152⟩,⟨23,24⟩,⟨25,30⟩,⟨2,48⟩,⟨479,638⟩]
private def b48900 : Box := ![⟨127,152⟩,⟨23,24⟩,⟨25,30⟩,⟨2,48⟩,⟨639,958⟩]
private def b48907 : Box := ![⟨153,190⟩,⟨23,24⟩,⟨21,30⟩,⟨2,55⟩,⟨479,958⟩]
private def b48908 : Box := ![⟨153,190⟩,⟨23,24⟩,⟨21,30⟩,⟨6,55⟩,⟨479,638⟩]
private def b48909 : Box := ![⟨153,190⟩,⟨23,24⟩,⟨21,30⟩,⟨6,55⟩,⟨639,958⟩]
private def b48920 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨21,30⟩,⟨1,61⟩,⟨959,999999999999999999⟩]
private def b48921 : Box := ![⟨127,190⟩,⟨21,22⟩,⟨21,30⟩,⟨1,55⟩,⟨959,999999999999999999⟩]
private def b48930 : Box := ![⟨127,190⟩,⟨23,24⟩,⟨21,30⟩,⟨1,55⟩,⟨959,999999999999999999⟩]
private def b48931 : Box := ![⟨127,152⟩,⟨23,24⟩,⟨21,30⟩,⟨1,55⟩,⟨959,999999999999999999⟩]
private def b48942 : Box := ![⟨153,190⟩,⟨23,24⟩,⟨21,30⟩,⟨1,55⟩,⟨959,999999999999999999⟩]
private def b48943 : Box := ![⟨153,190⟩,⟨23,24⟩,⟨21,24⟩,⟨1,55⟩,⟨959,999999999999999999⟩]
private def b48952 : Box := ![⟨153,190⟩,⟨23,24⟩,⟨25,30⟩,⟨1,55⟩,⟨959,999999999999999999⟩]
private def b48953 : Box := ![⟨153,190⟩,⟨23,24⟩,⟨25,30⟩,⟨1,55⟩,⟨959,1918⟩]
private def b48954 : Box := ![⟨153,169⟩,⟨23,24⟩,⟨25,30⟩,⟨6,50⟩,⟨959,1918⟩]
private def b48959 : Box := ![⟨170,190⟩,⟨23,24⟩,⟨25,30⟩,⟨6,50⟩,⟨959,1918⟩]
private def b48960 : Box := ![⟨170,190⟩,⟨23,24⟩,⟨25,30⟩,⟨8,50⟩,⟨959,1278⟩]
private def b48965 : Box := ![⟨170,190⟩,⟨23,24⟩,⟨25,30⟩,⟨8,50⟩,⟨1279,1918⟩]
private def b48972 : Box := ![⟨153,190⟩,⟨23,24⟩,⟨25,30⟩,⟨1,55⟩,⟨1919,999999999999999999⟩]
private def b48973 : Box := ![⟨153,169⟩,⟨23,24⟩,⟨25,30⟩,⟨1,50⟩,⟨1919,999999999999999999⟩]
private def b48978 : Box := ![⟨170,190⟩,⟨23,24⟩,⟨25,30⟩,⟨1,50⟩,⟨1919,999999999999999999⟩]
private def b48979 : Box := ![⟨170,190⟩,⟨23,24⟩,⟨25,30⟩,⟨2,50⟩,⟨1919,3838⟩]
private def b48986 : Box := ![⟨170,190⟩,⟨23,24⟩,⟨25,30⟩,⟨2,50⟩,⟨3839,999999999999999999⟩]
private theorem e48814 : Deny 5 13 b48814 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e48816 : Deny 5 13 b48816 := by
    apply closeAction rule_sound _ _ 64 [0x1fe37da3]
    decide +kernel
private theorem e48817 : Deny 5 13 b48817 := by
    apply closeAction rule_sound _ _ 64 [0x7c30f8243e361d72b829fe378c9]
    decide +kernel
private theorem e48815 : Deny 5 13 b48815 :=
    branchAction rule_sound _ _ 3
      0x7e23 b48815 b48816 b48817 (by decide +kernel) e48816 e48817
private theorem e48813 : Deny 5 13 b48813 :=
    branchAction rule_sound _ _ 5
      0x8e37da3 b48813 b48814 b48815 (by decide +kernel) e48814 e48815
private theorem e48829 : Deny 5 13 b48829 := by
    apply closeAction rule_sound _ _ 64 [0x1f9e3678df69e3238de3]
    decide +kernel
private theorem e48835 : Deny 5 13 b48835 := by
    apply closeAction rule_sound _ _ 64 [0xa79a0]
    decide +kernel
private theorem e48837 : Deny 5 13 b48837 := by
    apply closeAction rule_sound _ _ 64 [0x30f88c70f8df68c97ca778df6238da3]
    decide +kernel
private theorem e48848 : Deny 5 13 b48848 := by
    apply closeAction rule_sound _ _ 64 [0xc3e272270c22231e7]
    decide +kernel
private theorem e48855 : Deny 5 13 b48855 := by
    apply closeAction rule_sound _ _ 64 [0xc2227678df68c7e23]
    decide +kernel
private theorem e48847 : Deny 5 13 b48847 :=
    branchAction rule_sound _ _ 4
      0x2f89e3 b48847 b48848 b48855 (by decide +kernel) e48848 e48855
private theorem e48861 : Deny 5 13 b48861 := by
    apply closeAction rule_sound _ _ 64 [0x1de03e032278c99c30e78c99c38c78c7]
    decide +kernel
private theorem e48873 : Deny 5 13 b48873 := by
    apply closeAction rule_sound _ _ 64 [0xc3e278c9088e23]
    decide +kernel
private theorem e48878 : Deny 5 13 b48878 := by
    apply closeAction rule_sound _ _ 64 [0x30f89e325de37da78c88dd0d9e372278c99c42e7]
    decide +kernel
private theorem e48872 : Deny 5 13 b48872 :=
    branchAction rule_sound _ _ 2
      0x1e3 b48872 b48873 b48878 (by decide +kernel) e48873 e48878
private theorem e48860 : Deny 5 13 b48860 :=
    branchAction rule_sound _ _ 1
      0xb b48860 b48861 b48872 (by decide +kernel) e48861 e48872
private theorem e48846 : Deny 5 13 b48846 :=
    branchAction rule_sound _ _ 2
      0x267 b48846 b48847 b48860 (by decide +kernel) e48847 e48860
private theorem e48836 : Deny 5 13 b48836 :=
    branchAction rule_sound _ _ 1
      0x7 b48836 b48837 b48846 (by decide +kernel) e48837 e48846
private theorem e48834 : Deny 5 13 b48834 :=
    branchAction rule_sound _ _ 1
      0xa b48834 b48835 b48836 (by decide +kernel) e48835 e48836
private theorem e48891 : Deny 5 13 b48891 := by
    apply closeAction rule_sound _ _ 64 [0x7df9e02b89e3]
    decide +kernel
private theorem e48895 : Deny 5 13 b48895 := by
    apply closeAction rule_sound _ _ 64 [0x1f0c3e2780980a]
    decide +kernel
private theorem e48900 : Deny 5 13 b48900 := by
    apply closeAction rule_sound _ _ 64 [0x30e78c99c30f89e32631e3]
    decide +kernel
private theorem e48894 : Deny 5 13 b48894 :=
    branchAction rule_sound _ _ 1
      0xb b48894 b48895 b48900 (by decide +kernel) e48895 e48900
private theorem e48890 : Deny 5 13 b48890 :=
    branchAction rule_sound _ _ 2
      0x263 b48890 b48891 b48894 (by decide +kernel) e48891 e48894
private theorem e48908 : Deny 5 13 b48908 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e48909 : Deny 5 13 b48909 := by
    apply closeAction rule_sound _ _ 64 [0x7dd649e1925f29f2a3223]
    decide +kernel
private theorem e48907 : Deny 5 13 b48907 :=
    branchAction rule_sound _ _ 2
      0x2e7 b48907 b48908 b48909 (by decide +kernel) e48908 e48909
private theorem e48889 : Deny 5 13 b48889 :=
    branchAction rule_sound _ _ 1
      0x7 b48889 b48890 b48907 (by decide +kernel) e48890 e48907
private theorem e48833 : Deny 5 13 b48833 :=
    branchAction rule_sound _ _ 3
      0x89e3 b48833 b48834 b48889 (by decide +kernel) e48834 e48889
private theorem e48921 : Deny 5 13 b48921 := by
    apply closeAction rule_sound _ _ 64 [0xc22022789c21f89e3087e37da3]
    decide +kernel
private theorem e48931 : Deny 5 13 b48931 := by
    apply closeAction rule_sound _ _ 64 [0x30f8de32270f8de31f87c2238de32788d72b8da3]
    decide +kernel
private theorem e48943 : Deny 5 13 b48943 := by
    apply closeAction rule_sound _ _ 64 [0xc3e272677c22388c7e278d12b89e3]
    decide +kernel
private theorem e48954 : Deny 5 13 b48954 := by
    apply closeAction rule_sound _ _ 64 [0xc39e32670e31e3]
    decide +kernel
private theorem e48960 : Deny 5 13 b48960 := by
    apply closeAction rule_sound _ _ 64 [0x83e039e3263227]
    decide +kernel
private theorem e48965 : Deny 5 13 b48965 := by
    apply closeAction rule_sound _ _ 64 [0x838c80f80f88c89e3263]
    decide +kernel
private theorem e48959 : Deny 5 13 b48959 :=
    branchAction rule_sound _ _ 2
      0x2e7 b48959 b48960 b48965 (by decide +kernel) e48960 e48965
private theorem e48953 : Deny 5 13 b48953 :=
    branchAction rule_sound _ _ 3
      0x79e3 b48953 b48954 b48959 (by decide +kernel) e48954 e48959
private theorem e48973 : Deny 5 13 b48973 := by
    apply closeAction rule_sound _ _ 64 [0x3e03e379e32789e3088e23]
    decide +kernel
private theorem e48979 : Deny 5 13 b48979 := by
    apply closeAction rule_sound _ _ 64 [0xf80f89c80c22278c99e3]
    decide +kernel
private theorem e48986 : Deny 5 13 b48986 := by
    apply closeAction rule_sound _ _ 64 [0xc3e23242223]
    decide +kernel
private theorem e48978 : Deny 5 13 b48978 :=
    branchAction rule_sound _ _ 2
      0x2e7 b48978 b48979 b48986 (by decide +kernel) e48979 e48986
private theorem e48972 : Deny 5 13 b48972 :=
    branchAction rule_sound _ _ 2
      0x1e3 b48972 b48973 b48978 (by decide +kernel) e48973 e48978
private theorem e48952 : Deny 5 13 b48952 :=
    branchAction rule_sound _ _ 1
      0xb b48952 b48953 b48972 (by decide +kernel) e48953 e48972
private theorem e48942 : Deny 5 13 b48942 :=
    branchAction rule_sound _ _ 1
      0x9 b48942 b48943 b48952 (by decide +kernel) e48943 e48952
private theorem e48930 : Deny 5 13 b48930 :=
    branchAction rule_sound _ _ 1
      0x7 b48930 b48931 b48942 (by decide +kernel) e48931 e48942
private theorem e48920 : Deny 5 13 b48920 :=
    branchAction rule_sound _ _ 2
      0x223 b48920 b48921 b48930 (by decide +kernel) e48921 e48930
private theorem e48832 : Deny 5 13 b48832 :=
    branchAction rule_sound _ _ 1
      0xb b48832 b48833 b48920 (by decide +kernel) e48833 e48920
private theorem e48828 : Deny 5 13 b48828 :=
    branchAction rule_sound _ _ 1
      0x9 b48828 b48829 b48832 (by decide +kernel) e48829 e48832
private theorem e48812 : Deny 5 13 b48812 :=
    branchAction rule_sound _ _ 2
      0x1e3 b48812 b48813 b48828 (by decide +kernel) e48813 e48828
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨21,24⟩,⟨15,30⟩,⟨1,62⟩,⟨479,999999999999999999⟩] := by
  exact e48812
end OMA.Blocks5_13_245212.S48812
