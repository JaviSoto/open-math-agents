import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S65084
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b65084 : Box := ![⟨95,126⟩,⟨127,1920000000000000011376⟩,⟨8,9⟩,⟨1,502335381913959616714⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,126⟩,⟨127,1920000000000000011376⟩,⟨8,9⟩,⟨1,502335381913959616714⟩,⟨479,999999999999999999⟩] := by
  have e65084 : Deny 5 13 b65084 := by
    apply closeAction rule_sound _ _ 64 [0xe231f88c8e231f80c3e2b1dbe378c80878dbae32e36eb8cb26309b26b8cb8c8ae31e30826eb8c8e2b8c7e2b8cbe23238,0x8dbae32e36eb8cb8dbae32e36eb8cb8dbae32e36eb8cb8dbae32e36eb8cb8dbae32e36eb8cb8dbae32f88c9e2b082083,0x6cb6cb8db2e36cb6cb8db2e36cb8db2e36cb8dbae32e36eb8cb8dbae32e36eb8cb8dbae32e36eb8cb8dbae32e36eb8cb,0xc7e23238ae31f88c9e232380820830c8ae31e321a6830c808884a0a12a12ab1e36cb6cb6cb8db2db2e36cb6cb8db2e3,0x20820820f88c7e230f8]
    decide +kernel
  exact e65084
end OMA.Blocks5_13_245212.S65084
