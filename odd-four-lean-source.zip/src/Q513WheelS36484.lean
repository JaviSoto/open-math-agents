import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S36484
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b36484 : Box := ![⟨47,62⟩,⟨15,20⟩,⟨15,30⟩,⟨3,52⟩,⟨79,113⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,62⟩,⟨15,20⟩,⟨15,30⟩,⟨3,52⟩,⟨79,113⟩] := by
  have e36484 : Deny 5 13 b36484 := by
    apply closeAction rule_sound _ _ 64 [0xf72092830e31c32030f8de31c3e37da32231c30f88c90f8df68c88c90c3e371c3e37243e37d870f8df62362a32042e3,0xde3243778df68c8088087e37da322311fe37103108e377c32032231df0e32038c88c90f8dc31c32030c70f8dc81c30c9,0xc3de31c3de32030f8dc70f8df62378c70c3e378c90f8df68c7]
    decide +kernel
  exact e36484
end OMA.Blocks5_13_245212.S36484
