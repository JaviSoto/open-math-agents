import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S9214
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b9214 : Box := ![⟨23,46⟩,⟨10,14⟩,⟨7,14⟩,⟨3,1328583941605839423966⟩,⟨41,53⟩]
theorem deny5_13 : Deny 5 13 ![⟨23,46⟩,⟨10,14⟩,⟨7,14⟩,⟨3,1328583941605839423966⟩,⟨41,53⟩] := by
  have e9214 : Deny 5 13 b9214 := by
    apply closeAction rule_sound _ _ 64 [0x8c80f8de3243e37da31f7da30c32038c90c3de32768c70c3dc80f7243df61f62a310b0f61021f8df68c80f8df6d631e3,0x30f8df6]
    decide +kernel
  exact e9214
end OMA.Blocks5_13_245212.S9214
