import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S9767
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b9767 : Box := ![⟨47,1920000000000000011376⟩,⟨7,14⟩,⟨7,1920000000000000011376⟩,⟨1,2⟩,⟨29,53⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,1920000000000000011376⟩,⟨7,14⟩,⟨7,1920000000000000011376⟩,⟨1,2⟩,⟨29,53⟩] := by
  have e9767 : Deny 5 13 b9767 := by
    apply closeAction rule_sound _ _ 64 [0x10b8098090c3da02031c2809088df61039a0088dc31c3de0243983d87de680810b8098875665475621c29a02622222e2,0xda02621d59959a21e60b8df6d221f6d222040a65668879955420c3207542260283088de02045430c7809dd50f7809808,0x159959a21e65550c3e070880870838080e02030881e010b08a0888098090c22021c4088e37]
    decide +kernel
  exact e9767
end OMA.Blocks5_13_245212.S9767
