import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S54912
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b54912 : Box := ![⟨54,62⟩,⟨127,1920000000000000011376⟩,⟨10,11⟩,⟨2,451586424625098660952⟩,⟨959,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨54,62⟩,⟨127,1920000000000000011376⟩,⟨10,11⟩,⟨2,451586424625098660952⟩,⟨959,999999999999999999⟩] := by
  have e54912 : Deny 5 13 b54912 := by
    apply closeAction rule_sound _ _ 64 [0x880878c80878c8d636ab8cbd636ab8cb089087d636ab8cbd636ab8cb8daae32e36ab8cb6c21f88c84b8d61282ae12a3,0x8209a8c8e2b6ab8c8d47adaae3207adaae322b6ab0c21eb]
    decide +kernel
  exact e54912
end OMA.Blocks5_13_245212.S54912
