import HeightGap245212
import HeightSingleton245212
import Size245212

/-! Exact bounds on each prime power in terms of the other three.
Use outward-rounded binary logarithms to contract all four exponent ranges. -/
namespace OMA.Height245212
open Finset OMA.Smooth245212
open scoped ArithmeticFunction.sigma

theorem singleton_bound (p e : Fin 4 → ℕ) (prime : ∀ i,(p i).Prime)
    (odd : ∀ i,3≤p i) (pos : ∀ i,0<e i) (inj : Function.Injective p)
    (sol : OeisA245212.a (total p e)=(σ 1 (total p e):ℤ)) (i : Fin 4) :
    p i^e i ≤ (8+(p i-1))*(∏ j∈univ.erase i,(e j+1)*p j^e j) := by
  let A := ∏ j∈univ.erase i,(e j+1)*p j^e j
  have hden : commonDen p e {i}=A*den (p i) (e i) := by
    unfold commonDen
    rw [←prod_erase_mul _ _ (mem_univ i)]
    have cut : (∏ j∈univ.erase i,localDen p e {i} j)=A :=
      prod_congr rfl fun j hj=>by simp [localDen,(mem_erase.mp hj).1]
    rw [cut]; simp [localDen]
  have norm := normalized_of_eq p prime inj e sol
  by_contra! wrong
  change (8+(p i-1))*A<p i^e i at wrong
  have less : (8+((p i:ℚ)-1))*A<(p i:ℚ)^e i := by
    have cast : ((8+(p i-1):ℕ):ℚ)*A<(p i:ℚ)^e i := by exact_mod_cast wrong
    simpa only [Nat.cast_add,Nat.cast_ofNat,Nat.cast_sub (prime i).pos,Nat.cast_one] using cast
  have n0 : (0:ℚ)<den (p i) (e i) := by exact_mod_cast den_pos (prime i).one_lt (e i)
  have a0 : (0:ℚ)<(p i:ℚ)^e i := pow_pos (by exact_mod_cast (prime i).pos) _
  have budget : (∑ j∈({i}:Finset (Fin 4)),err (p j) (e j)*(8+((p j:ℚ)-1)))*
      commonDen p e {i}<1 := by
    simp only [sum_singleton,hden,Nat.cast_mul,err]
    field_simp
    nlinarith only [mul_lt_mul_of_pos_right less n0]
  exact singleton_ne p e prime odd inj sol i ((gap_eq p e prime pos {i} norm budget).trans norm.symm)

end OMA.Height245212

namespace OMA.Box245212
open Finset OMA.Height245212

def coefficientHi (p q : ℕ) (b : Box) (i : Fin 4) : ℕ :=
  sizeHi (8+((baseBox p q b i).hi-1)) +
  ∑ j∈univ.erase i,sizeHi ((b j.castSucc).hi+1)

theorem linear_bound {p q : ℕ} {b : Box} {v : Values} (fit : Fits b v) (c : Candidate p q v)
    (start : ∀ j,0<(baseBox p q b j).lo) (i : Fin 4) :
    exponents v i*sizeLo (baseBox p q b i).lo ≤ coefficientHi p q b i +
      ∑ j∈univ.erase i,exponents v j*sizeHi (baseBox p q b j).hi := by
  let P := bases p q v
  let E := exponents v
  let U := baseBox p q b
  have odd (j : Fin 4) : 3≤P j := c.ordered.monotone (show (0:Fin 4)≤j from Fin.zero_le j)
  have bp (j) := inside_primes (p:=p) (q:=q) fit j
  have ep (j) : (b j.castSucc).has (E j) := fit _
  have encP (j) := enc_range (start j) (bp j)
  have encE (j : Fin 4) : Enc 0 (sizeHi ((b j.castSucc).hi+1)) (E j+1) := by
    have h := enc_range (r:=⟨1,(b j.castSucc).hi+1⟩) (show 0<1 by decide)
      (n:=E j+1) ⟨Nat.succ_le_succ (Nat.zero_le _),Nat.succ_le_succ (ep j).2⟩
    simpa only [show sizeLo 1=0 by decide +kernel] using h
  have encT (j : Fin 4) := enc_mul (encE j) (enc_pow (b:=⟨E j,E j⟩) (encP j) (show Range.has _ (E j) from ⟨le_rfl,le_rfl⟩))
  have encC := enc_range (r:=⟨1,8+((U i).hi-1)⟩) (n:=8+(P i-1)) (show 0<1 by decide)
    (show Range.has _ _ from ⟨show 1≤8+(P i-1) by omega,Nat.add_le_add_left (Nat.sub_le_sub_right (bp i).2 1) 8⟩)
  have upper := (enc_mul encC (enc_prod (univ.erase i) _ _ _ (fun j _=>encT j))).2
  have lower := (enc_pow (b:=⟨E i,E i⟩) (encP i) (show Range.has _ (E i) from ⟨le_rfl,le_rfl⟩)).1
  have bound := singleton_bound P E c.prime odd c.pos c.ordered.injective c.eqn i
  have powers := lower.trans ((Nat.pow_le_pow_left bound 128).trans upper)
  apply le_of_not_gt
  intro contrary
  apply (Nat.pow_lt_pow_right (by decide : 1<2) contrary).not_ge
  simpa [coefficientHi,P,E,U,mul_comm,Finset.sum_add_distrib,Nat.add_assoc] using powers

def upperClip (p q : ℕ) (b : Box) (i : Fin 4) : Box :=
  let U := baseBox p q b
  let z := coefficientHi p q b i + ∑ j∈univ.erase i,(b j.castSucc).hi*sizeHi (U j).hi
  clip b i.castSucc ⟨(b i.castSucc).lo,min (b i.castSucc).hi (z/sizeLo (U i).lo)⟩

theorem upper_sound {p q : ℕ} {b : Box} {v : Values} (fit : Fits b v) (c : Candidate p q v)
    (starts : ∀ j,1<(baseBox p q b j).lo) (i : Fin 4) : Fits (upperClip p q b i) v := by
  let U := baseBox p q b
  have hp : 0<(U i).lo := Nat.zero_lt_one.trans (starts i)
  have hd : 1 ≤ sizeLo (U i).lo := (Nat.le_log_iff_pow_le (by decide : 1<2) (pow_ne_zero 128 hp.ne')).mpr (by
    have t := Nat.pow_le_pow_left (starts i) 128
    exact (by decide : 2^1≤2^128).trans t)
  apply clip_fits fit
  refine ⟨(fit _).1,le_min (fit _).2 ((Nat.le_div_iff_mul_le hd).mpr ?_)⟩
  have h := linear_bound fit c (fun j=>Nat.zero_lt_one.trans (starts j)) i
  apply h.trans
  apply Nat.add_le_add_left
  exact sum_le_sum fun j _=>Nat.mul_le_mul_right _ (fit j.castSucc).2

/-- Least integer whose product with d reaches z; d is positive here. -/
def upDiv (z d : ℕ) := if z=0 then 0 else (z-1)/d+1
theorem upDiv_le {z d v : ℕ} (dpos : 0<d) (bounded : z≤v*d) : upDiv z d≤v := by
  unfold upDiv; split_ifs with h
  · omega
  · exact Nat.succ_le_of_lt ((Nat.div_lt_iff_lt_mul dpos).mpr (by omega))

def lowerClip (p q : ℕ) (b : Box) (i j : Fin 4) : Box :=
  if i=j then b else
  let U := baseBox p q b
  let others := coefficientHi p q b i +
    ∑ k∈(univ.erase i).erase j,(b k.castSucc).hi*sizeHi (U k).hi
  let floor := upDiv ((b i.castSucc).lo*sizeLo (U i).lo-others) (sizeHi (U j).hi)
  clip b j.castSucc ⟨max (b j.castSucc).lo floor,(b j.castSucc).hi⟩

theorem lower_sound {p q : ℕ} {b : Box} {v : Values} (fit : Fits b v) (c : Candidate p q v)
    (starts : ∀ x,1<(baseBox p q b x).lo) (i j : Fin 4) : Fits (lowerClip p q b i j) v := by
  unfold lowerClip
  split_ifs with h
  · exact fit
  · apply clip_fits fit
    refine ⟨max_le (fit _).1 (upDiv_le (Nat.zero_lt_succ _) ?_), (fit _).2⟩
    let U := baseBox p q b
    have lj := (Nat.mul_le_mul_right (sizeLo (U i).lo) (fit i.castSucc).1).trans
      (linear_bound fit c (fun k=>Nat.zero_lt_one.trans (starts k)) i)
    have jm : j∈univ.erase i := by simp [Ne.symm h]
    rw [←sum_erase_add _ _ jm] at lj
    have other := sum_le_sum (s:=(univ.erase i).erase j) (fun k _=>
      Nat.mul_le_mul_right (sizeHi (U k).hi) (fit k.castSucc).2)
    change (b i.castSucc).lo*sizeLo (U i).lo-(coefficientHi p q b i+
      ∑ k∈(univ.erase i).erase j,(b k.castSucc).hi*sizeHi (U k).hi)≤
      v j.castSucc*sizeHi (U j).hi
    change (b i.castSucc).lo*sizeLo (U i).lo ≤ coefficientHi p q b i +
      ((∑ k∈(univ.erase i).erase j,v k.castSucc*sizeHi (U k).hi)+v j.castSucc*sizeHi (U j).hi) at lj
    omega

def topPass (p q : ℕ) (b : Box) := (List.finRange 4).foldl (upperClip p q) b
def bottomPass (p q : ℕ) (b : Box) := (List.finRange 4).foldl
  (fun box i => (List.finRange 4).foldl (fun w j=>lowerClip p q w i j) box) b
def singletonCaps (p q : ℕ) (b : Box) :=
  if ∀ j,1<(baseBox p q b j).lo then bottomPass p q (topPass p q (topPass p q b)) else b

private theorem fold_keep {α : Type*} (g : Box → α → Box) (P : Box → Prop)
    (step : ∀ b i,P b → P (g b i)) (xs : List α) (b : Box) (ok : P b) : P (xs.foldl g b) := by
  induction xs generalizing b with
  | nil => exact ok
  | cons x xs ih => exact ih _ (step b x ok)

theorem singletonCaps_sound {p q : ℕ} {b : Box} {v : Values} (fit : Fits b v) (c : Candidate p q v) :
    Fits (singletonCaps p q b) v := by
  unfold singletonCaps
  split_ifs with init
  · let good (w : Box) := Fits w v ∧ ∀ j,1<(baseBox p q w j).lo
    have preserved {x y : Box} (eq : x 4=y 4) : baseBox p q x=baseBox p q y := by simp [baseBox,eq]
    have last (i : Fin 4) : (4:Fin 5)≠i.castSucc := by intro h; have := congrArg Fin.val h; simp at this; omega
    have up (w : Box) (i : Fin 4) (g : good w) : good (upperClip p q w i) := by
      have e : upperClip p q w i 4=w 4 := by simp [upperClip,clip,Function.update_of_ne (last i)]
      exact ⟨upper_sound g.1 c g.2 i, preserved e ▸ g.2⟩
    have down (i : Fin 4) (w : Box) (j : Fin 4) (g : good w) : good (lowerClip p q w i j) := by
      have e : lowerClip p q w i j 4=w 4 := by
        unfold lowerClip; split_ifs <;> simp [clip,Function.update_of_ne (last j)]
      exact ⟨lower_sound g.1 c g.2 i j,preserved e ▸ g.2⟩
    have top (w : Box) (g : good w) : good (topPass p q w) :=
      fold_keep _ good up _ w g
    exact (fold_keep _ good (fun w i g=>fold_keep _ good (down i) _ w g) (List.finRange 4) _
      (top _ (top _ ⟨fit,init⟩))).1
  · exact fit

end OMA.Box245212
