import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S6460
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b6460 : Box := ![⟨11,22⟩,⟨15,1920000000000000011376⟩,⟨3,6⟩,⟨1,1920000000000000011376⟩,⟨51,999999999999999999⟩]
theorem deny5_11 : Deny 5 11 ![⟨11,22⟩,⟨15,1920000000000000011376⟩,⟨3,6⟩,⟨1,1920000000000000011376⟩,⟨51,999999999999999999⟩] := by
  have e6460 : Deny 5 11 b6460 := by
    apply closeAction rule_sound _ _ 64 [0x89e2321aac4087e37db58c70a12a326310b0c3e37da3202244087e368c86ab1021f8df6d631e3103e37db5d2110ae23,0xe37d631e3103dc38c90eb0f78c88c710b8c86ab69aacbe2b8c80c46b8df5109e2320284a8c76ab69aacbe2b8c80c21c4,0xe2322320226b8c82c30891021f8db58c80a129ae37db58c7da36ab6ab8c46ab0e3223108e2b8c848a0c3de3243d44089,0x1aadaae3236d6311aadaadaac3]
    decide +kernel
  exact e6460
end OMA.Blocks5_11_245212.S6460
