import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S38142
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b38142 : Box := ![⟨47,94⟩,⟨31,1920000000000000011376⟩,⟨7,14⟩,⟨1,2⟩,⟨59,113⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,94⟩,⟨31,1920000000000000011376⟩,⟨7,14⟩,⟨1,2⟩,⟨59,113⟩] := by
  have e38142 : Deny 5 13 b38142 := by
    apply closeAction rule_sound _ _ 64 [0x170824c38478478441f80820c8107e135f81d720720409722110be13261109e17293261]
    decide +kernel
  exact e38142
end OMA.Blocks5_13_245212.S38142
