import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S24454
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b24454 : Box := ![⟨23,30⟩,⟨63,1920000000000000011376⟩,⟨15,1920000000000000011376⟩,⟨1,1680544217687074839918⟩,⟨220,1322⟩]
theorem deny5_13 : Deny 5 13 ![⟨23,30⟩,⟨63,1920000000000000011376⟩,⟨15,1920000000000000011376⟩,⟨1,1680544217687074839918⟩,⟨220,1322⟩] := by
  have e24454 : Deny 5 13 b24454 := by
    apply closeAction rule_sound _ _ 64 [0x7b8db58c87b8df6d61282aea84ad522b8df58c979629eae325ebc4789e368c85b8db588a58adb58c4087e37db58c7da3,0x58ae0a7b8df68c77b8df68c97b8df68c8d84087e368c972f7af8c9da31021f8da3216e36d622b65a22b8de321aada22b,0xaa12a32560aa84988a2dcbde26f7897b8db588a087da311cbde26f79e58a88a8c972f11ee37db58c4278da31e310b79e,0xe36d622a37967a125e88888a58a58a6ab7ab8c8ade59e58a58a0ab849844087e21109e21116e37db58441f884ae23216,0x7967a125e888e2229629629aadeae3238d63256]
    decide +kernel
  exact e24454
end OMA.Blocks5_13_245212.S24454
