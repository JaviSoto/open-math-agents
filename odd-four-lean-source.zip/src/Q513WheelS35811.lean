import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S35811
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b35811 : Box := ![⟨47,94⟩,⟨15,20⟩,⟨7,14⟩,⟨3,46⟩,⟨79,113⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,94⟩,⟨15,20⟩,⟨7,14⟩,⟨3,46⟩,⟨79,113⟩] := by
  have e35811 : Deny 5 13 b35811 := by
    apply closeAction rule_sound _ _ 64 [0xf8df61c223680a8c810b0e70f78c70f8df68c7119087e37da3108e378c90c3e378c90f8df68c70f8df68c8e37da31e3,0x8c47f8dc38c90e32030c80e32631c3e270c70e02430f8dc80f8dc91ca0c38c70f8da32030f8de32422231c30f8de7809,0x30f78c70f72030f8df68c80f8df68c9de31c30f8df68c71021f8df68c8]
    decide +kernel
  exact e35811
end OMA.Blocks5_13_245212.S35811
