import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S38440
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b38440 : Box := ![⟨63,94⟩,⟨31,62⟩,⟨7,14⟩,⟨3,58⟩,⟨79,113⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨31,62⟩,⟨7,14⟩,⟨3,58⟩,⟨79,113⟩] := by
  have e38440 : Deny 5 13 b38440 := by
    apply closeAction rule_sound _ _ 64 [0x1c80c3e0824a0c31c30c72030f8dc824a8c78c4082083209107e02083808dc4278083e370c72130c82472b710b8c88c9,0x82083e370e31e32232631f81132b8ddb0820c72386c20c41f80c8289293e370f8dc31c84c320320929b083107e03e03,0x82093e370f8dc31c8247108e37]
    decide +kernel
  exact e38440
end OMA.Blocks5_13_245212.S38440
