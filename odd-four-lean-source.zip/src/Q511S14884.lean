import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S14884
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b14884 : Box := ![⟨23,46⟩,⟨7,9⟩,⟨7,1920000000000000011376⟩,⟨1,1160381991814461125599⟩,⟨53,101⟩]
private def b14885 : Box := ![⟨23,46⟩,⟨7,9⟩,⟨7,14⟩,⟨1,1160381991814461125597⟩,⟨53,101⟩]
private def b14894 : Box := ![⟨23,46⟩,⟨7,9⟩,⟨15,1920000000000000011376⟩,⟨1,1160381991814461125597⟩,⟨53,101⟩]
private def b14895 : Box := ![⟨23,30⟩,⟨7,9⟩,⟨15,1920000000000000011376⟩,⟨1,1160381991814461125597⟩,⟨53,101⟩]
private def b14974 : Box := ![⟨31,46⟩,⟨7,9⟩,⟨15,1920000000000000011376⟩,⟨1,1160381991814461125597⟩,⟨53,101⟩]
private def b14975 : Box := ![⟨31,46⟩,⟨7,9⟩,⟨15,1920000000000000011376⟩,⟨1,2⟩,⟨53,101⟩]
private def b14992 : Box := ![⟨31,46⟩,⟨7,9⟩,⟨15,1920000000000000011376⟩,⟨3,1160381991814461125597⟩,⟨53,101⟩]
private def b14993 : Box := ![⟨31,46⟩,⟨7,9⟩,⟨15,1920000000000000011376⟩,⟨3,1160381991814461125597⟩,⟨53,69⟩]
private def b15114 : Box := ![⟨31,46⟩,⟨7,9⟩,⟨15,1920000000000000011376⟩,⟨3,1160381991814461125597⟩,⟨70,101⟩]
theorem deny5_11 : Deny 5 11 ![⟨23,46⟩,⟨7,9⟩,⟨7,1920000000000000011376⟩,⟨1,1160381991814461125599⟩,⟨53,101⟩] := by
  have e14885 : Deny 5 11 b14885 := by
    apply closeAction rule_sound _ _ 64 [0xc3e378c70f8de3243e37da32040f8df68c41f8de3]
    decide +kernel
  have e14895 : Deny 5 11 b14895 := by
    apply closeAction rule_sound _ _ 64 [0x26f703738df688888a8c92c3e222a31c30f8de31c3e2326325cbc4737daf8c4278df68c80c21e2102238df688a2f8de3,0xf8df688888a8c98c40af8c472f8c4278bdc0f8dc388888a8c92c388a72f72f8c9bc31021f88c9738df622311cbdcbe3,0x72f72f11ce2f8c4278be3243102238da325cbc4088e37da31c288a088df68c472f72f8c9703e03887]
    decide +kernel
  have e14975 : Deny 5 11 b14975 := by
    apply closeAction rule_sound _ _ 64 [0x15087d84543088243088da21e210b578da2284088e22]
    decide +kernel
  have e14993 : Deny 5 11 b14993 := by
    apply closeAction rule_sound _ _ 64 [0x71cdf68842b8da3242be22b68c472f72f8c9bc3bc38c90f8de31e324b0a22a31c30f8de32440f8df68c41f8de32488c4,0xc824b2830c80e32631e3242bddbe326f75d0c4087e222a22a3263114e37bdd743e0388788a88a8c92c3e2229cbdc26f,0x8c88c98c40820831c82778c42f80f80f888888a8c7083203e370c88c98c40820c88c92c3e370c80c3dc8244083203e37,0x502578dc3887222109e3709cbe2108e37bc20e2107e370f8def0e32438c7]
    decide +kernel
  have e15114 : Deny 5 11 b15114 := by
    apply closeAction rule_sound _ _ 64 [0x888c40f80c80dde37d888c90c3243e37d8828b0c3e378c9102238de31e325cbdcbe326f778df68c9d84087e37d888c4,0x8c70888c90a22a311cbdcbe326f0f8def8c38c9e038c70ef0f8de3244738df68c41f88c88c90c222228b8c70c3e378c9,0x2631020af88409c109e2f8841f8ddd743e03e221e22a22a3248578dc3e080e21e228b72f72f8c9bc3bc3e378c9738df6,0x14e3772f75cbe31ef8c922f0afb2210210be370f8be31ef0e325d0f8df688a738df68c7de3223]
    decide +kernel
  have e14992 : Deny 5 11 b14992 :=
    branchAction rule_sound _ _ 1
      0xb b14992 b14993 b15114 (by decide +kernel) e14993 e15114
  have e14974 : Deny 5 11 b14974 :=
    branchAction rule_sound _ _ 1
      0xa b14974 b14975 b14992 (by decide +kernel) e14975 e14992
  have e14894 : Deny 5 11 b14894 :=
    branchAction rule_sound _ _ 1
      0x7 b14894 b14895 b14974 (by decide +kernel) e14895 e14974
  have e14884 : Deny 5 11 b14884 :=
    branchAction rule_sound _ _ 2
      0x263 b14884 b14885 b14894 (by decide +kernel) e14885 e14894
  exact e14884
end OMA.Blocks5_11_245212.S14884
