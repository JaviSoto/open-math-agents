import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S23413
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b23413 : Box := ![⟨23,30⟩,⟨31,62⟩,⟨15,1920000000000000011376⟩,⟨1,1680544217687074839926⟩,⟨119,1322⟩]
theorem deny5_13 : Deny 5 13 ![⟨23,30⟩,⟨31,62⟩,⟨15,1920000000000000011376⟩,⟨1,1680544217687074839926⟩,⟨119,1322⟩] := by
  have e23413 : Deny 5 13 b23413 := by
    apply closeAction rule_sound _ _ 64 [0x78a7080a22821c4088e37daf8c9738df61e3738df68c8e37da3216e37db588ada311cbc47af8c4278df6d63107e37da3,0x1f8d8a7b8df68c8de311e79f0c4088e361ca29f0f8df61d628a2c31021f8de325ee37da31c47b8df68c4238da325cbdc,0x8c8df68c479e79f29ee37da21dee37da22222a229f087e37da22842f88c972f11ee37daf8c4278df68c78c810b79f102,0x2162a22a310b8c972f7af8c9bde0c3e372421c4088e37da210ae378c98c772f7af8c9bdebdee378c97b8df68c9738df6,0xd872440820e2108e032478842c30c90e22222222a22a229fdc30a22221df0872447c20e22032562a21c42df0f8df61e2,0xe2f79e79e0c3e368880f827688ada229ee37d877b8df688888a88a0df2421c4088e37da22a311e79e0830f68888877c3,0x7af8c9bdebdee378c97b8de3244738df68c4238da325cbc4088e37da31dcbc4087e37da320288ada311cbe311ebe3109,0x72f]
    decide +kernel
  exact e23413
end OMA.Blocks5_13_245212.S23413
