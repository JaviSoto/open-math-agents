import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S56378
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b56378 : Box := ![⟨63,94⟩,⟨127,1920000000000000011376⟩,⟨10,14⟩,⟨1,502335381913959616710⟩,⟨479,999999999999999999⟩]
private def b56379 : Box := ![⟨63,75⟩,⟨127,1920000000000000011376⟩,⟨10,14⟩,⟨1,502335381913959616710⟩,⟨479,999999999999999999⟩]
private def b56380 : Box := ![⟨63,75⟩,⟨127,1920000000000000011376⟩,⟨10,14⟩,⟨1,502335381913959616707⟩,⟨479,958⟩]
private def b56385 : Box := ![⟨63,75⟩,⟨127,1920000000000000011376⟩,⟨10,14⟩,⟨1,502335381913959616707⟩,⟨959,999999999999999999⟩]
private def b56386 : Box := ![⟨63,75⟩,⟨127,1920000000000000011376⟩,⟨10,11⟩,⟨1,451586424625098660954⟩,⟨959,999999999999999999⟩]
private def b56603 : Box := ![⟨63,75⟩,⟨127,1920000000000000011376⟩,⟨12,14⟩,⟨1,451586424625098660954⟩,⟨959,999999999999999999⟩]
private def b56650 : Box := ![⟨76,94⟩,⟨127,1920000000000000011376⟩,⟨10,14⟩,⟨1,502335381913959616710⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨127,1920000000000000011376⟩,⟨10,14⟩,⟨1,502335381913959616710⟩,⟨479,999999999999999999⟩] := by
  have e56380 : Deny 5 13 b56380 := by
    apply closeAction rule_sound _ _ 64 [0x82adbae322b8c9ae3]
    decide +kernel
  have e56386 : Deny 5 13 b56386 := by
    apply closeAction rule_sound _ _ 64 [0x8cb8daae32e36ab8cb8daae32e36ab8cb087ac222b089d631e36eb8cb8dbae32e36eb8cb8dbae32e36eb8cb8c80612a3,0x8cb8dbae32da68308784a6ab84b6ab84b0ab84b48b48b48b48b48b48b48b2a36ab8cb8daae32e36ab8cb8daae32e36ab,0x8cb8daae32e36ab8cb8daae32e36ab8cb8daae32eb0c38c80c22231e36eb8cb0898c88dbae32e36eb8cb8dbae32e36eb,0xae12c2ae12c2ae12c21c96ab84b6ab84b6ab84b6ab84b6aba212ca8daae32e36ab8cb8daae32e36ab8cb8daae32e36ab,0x6ab8cbae322b8c78daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cbada0820e11e11daac308721aae12daae12c2,0x8209aae32351eb6ab8c88c7adaae322b26b69a083ac32021e11c22612922e12a36ab8cb8daae32e36ab8cb8daae32e3,0x8209ae37ac3ac38c80878db2e36cb8db2e36cb8c8ae31c9ae3202]
    decide +kernel
  have e56603 : Deny 5 13 b56603 := by
    apply closeAction rule_sound _ _ 64 [0x278ac2083e03e232388c9e2b8c7e030e3203e2b8c2238d478dbae32e36eb8cb8dbae32eb26322309b278ae32e31eb8c8,0x20820820f88c8e231f82788c8e020820f80c7e23207e23]
    decide +kernel
  have e56385 : Deny 5 13 b56385 :=
    branchAction rule_sound _ _ 2
      0x263 b56385 b56386 b56603 (by decide +kernel) e56386 e56603
  have e56379 : Deny 5 13 b56379 :=
    branchAction rule_sound _ _ 2
      0x2e3 b56379 b56380 b56385 (by decide +kernel) e56380 e56385
  have e56650 : Deny 5 13 b56650 := by
    apply closeAction rule_sound _ _ 64 [0xae32e36eb8cb8dbae32e36eb8cb8dbae32e36eb8cb8dbae32e36eb8cb8dbae32e36eb8cb8c98dbae32e31f8ae3223278,0x20820820820c78c81eb0838c80eb0881e32236eb8cb8dbae32e36eb8cb8dbae32e36eb8cb8dbae32e36eb8cb8db]
    decide +kernel
  have e56378 : Deny 5 13 b56378 :=
    branchAction rule_sound _ _ 1
      0x7 b56378 b56379 b56650 (by decide +kernel) e56379 e56650
  exact e56378
end OMA.Blocks5_13_245212.S56378
