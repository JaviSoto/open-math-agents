import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S54685
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b54685 : Box := ![⟨54,57⟩,⟨63,84⟩,⟨12,14⟩,⟨3,41⟩,⟨479,958⟩]
private def b54686 : Box := ![⟨54,57⟩,⟨63,72⟩,⟨12,14⟩,⟨4,40⟩,⟨479,584⟩]
private def b54687 : Box := ![⟨54,57⟩,⟨73,84⟩,⟨12,14⟩,⟨4,40⟩,⟨479,584⟩]
private def b54688 : Box := ![⟨54,57⟩,⟨73,84⟩,⟨12,12⟩,⟨4,40⟩,⟨479,577⟩]
private def b54689 : Box := ![⟨54,57⟩,⟨73,84⟩,⟨13,14⟩,⟨4,40⟩,⟨479,577⟩]
private theorem e54686 : Deny 5 13 b54686 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e54688 : Deny 5 13 b54688 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e54689 : Deny 5 13 b54689 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e54687 : Deny 5 13 b54687 :=
    branchAction rule_sound _ _ 2
      0x244 b54687 b54688 b54689 (by decide +kernel) e54688 e54689
private theorem e54685 : Deny 5 13 b54685 :=
    branchAction rule_sound _ _ 4
      0x238de3 b54685 b54686 b54687 (by decide +kernel) e54686 e54687
theorem deny5_13 : Deny 5 13 ![⟨54,57⟩,⟨63,84⟩,⟨12,14⟩,⟨3,41⟩,⟨479,958⟩] := by
  exact e54685
end OMA.Blocks5_13_245212.S54685
