import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S63372
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b63372 : Box := ![⟨127,152⟩,⟨31,35⟩,⟨12,14⟩,⟨1,51⟩,⟨959,999999999999999999⟩]
private theorem e63372 : Deny 5 13 b63372 := by
    apply closeAction rule_sound _ _ 64 [0xe70f88c70f71021f8de32389e3089e23]
    decide +kernel
theorem deny5_13 : Deny 5 13 ![⟨127,152⟩,⟨31,35⟩,⟨12,14⟩,⟨1,51⟩,⟨959,999999999999999999⟩] := by
  exact e63372
end OMA.Blocks5_13_245212.S63372
