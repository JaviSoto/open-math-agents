import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S31918
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b31918 : Box := ![⟨38,41⟩,⟨85,101⟩,⟨127,1920000000000000011376⟩,⟨3,652387096774193552298⟩,⟨1919,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨38,41⟩,⟨85,101⟩,⟨127,1920000000000000011376⟩,⟨3,652387096774193552298⟩,⟨1919,999999999999999999⟩] := by
  have e31918 : Deny 5 13 b31918 := by
    apply closeAction rule_sound _ _ 64 [0x2e37af8cbda37af8cbda37af8cbda37af8cbdaf8debe32f68debe32ef088da37af8cb087da37af8cb8debe32e32631e3,0x2ef087da322372f8cb8dcbe32e372f8cb8dcbe32e372f8cb8dcbe32e372f8cbbde78388a50b08888ada37af8cb8debe3,0xbdcbe326f72f8c91ef7af8c908209cbe326f72f8c9d88bdcbe32768c8bdcbdcbc38c9da378b0888c9088be32768dcbe3,0x8debe32e37af8cb8debe32e37af8cb8debe32e37af8cb8debe32e37af8cb8debe32f88c9e0208272f8c9088bc22368c8,0x7af8cb8debe32e37af8cb8debe32e37af8cb8debe32e37af8cb8debe32e37af8cb8debe32e37af8cb8debe32e37af8cb,0xbe32debcb8debe32debcb8debcb8debe32e37af8cb7af2e37af2e37af2e37af8cb8debe32e37af8cb8debe32e37af2e3,0xe07e2f8c98c8e2f8c20820838c92078c909cbdc70308888a2a3247bc20838c9203088bc22361e32637af2c88debcb8de,0x20820820820f88c9e08e232788c8]
    decide +kernel
  exact e31918
end OMA.Blocks5_13_245212.S31918
