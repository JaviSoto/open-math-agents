import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S17828
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b17828 : Box := ![⟨31,46⟩,⟨21,30⟩,⟨15,1920000000000000011376⟩,⟨3,1210212765957446815720⟩,⟨59,73⟩]
theorem deny5_13 : Deny 5 13 ![⟨31,46⟩,⟨21,30⟩,⟨15,1920000000000000011376⟩,⟨3,1210212765957446815720⟩,⟨59,73⟩] := by
  have e17828 : Deny 5 13 b17828 := by
    apply closeAction rule_sound _ _ 64 [0xe37d88dc7244097dc3207dd7dc32370c32072442c30f7203088e371c3087dc9117dc32030f72070c3dc72442c81ca8c9,0x8c77d7e375f8dd7dc320724210be17e370c9dc3dc32070c32031c9117e375f70c72442c85f8dc32032430c81c30c80c3,0x8df8c9e025c3887888dc38842f8dc38880e21e21c45f710be03dc38880c90c3e37888887117dc3dc388888710b88888a,0x2097e375f8dc3887888887884238dc20af888e37]
    decide +kernel
  exact e17828
end OMA.Blocks5_13_245212.S17828
