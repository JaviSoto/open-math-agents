import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S26666
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b26666 : Box := ![⟨38,41⟩,⟨42,62⟩,⟨31,62⟩,⟨3,6⟩,⟨239,478⟩]
private def b26667 : Box := ![⟨38,41⟩,⟨42,62⟩,⟨31,62⟩,⟨3,6⟩,⟨239,318⟩]
private def b26668 : Box := ![⟨38,41⟩,⟨42,50⟩,⟨31,62⟩,⟨3,6⟩,⟨239,317⟩]
private def b26669 : Box := ![⟨38,41⟩,⟨42,50⟩,⟨34,44⟩,⟨3,6⟩,⟨239,317⟩]
private def b26674 : Box := ![⟨38,41⟩,⟨42,50⟩,⟨45,62⟩,⟨3,6⟩,⟨239,317⟩]
private def b26675 : Box := ![⟨38,41⟩,⟨42,50⟩,⟨45,62⟩,⟨3,6⟩,⟨239,272⟩]
private def b26676 : Box := ![⟨38,39⟩,⟨42,50⟩,⟨45,62⟩,⟨3,6⟩,⟨239,271⟩]
private def b26681 : Box := ![⟨40,41⟩,⟨42,50⟩,⟨45,62⟩,⟨3,6⟩,⟨239,271⟩]
private def b26688 : Box := ![⟨38,41⟩,⟨42,50⟩,⟨45,62⟩,⟨3,6⟩,⟨273,317⟩]
private def b26695 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨31,62⟩,⟨3,6⟩,⟨239,317⟩]
private def b26696 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨31,41⟩,⟨3,6⟩,⟨239,317⟩]
private def b26697 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨31,41⟩,⟨3,6⟩,⟨239,272⟩]
private def b26698 : Box := ![⟨38,39⟩,⟨51,62⟩,⟨31,41⟩,⟨3,6⟩,⟨239,271⟩]
private def b26703 : Box := ![⟨40,41⟩,⟨51,62⟩,⟨31,41⟩,⟨3,6⟩,⟨239,271⟩]
private def b26710 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨31,41⟩,⟨3,6⟩,⟨273,317⟩]
private def b26717 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨42,62⟩,⟨3,6⟩,⟨239,317⟩]
private def b26718 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨42,62⟩,⟨3,6⟩,⟨239,272⟩]
private def b26719 : Box := ![⟨38,39⟩,⟨51,62⟩,⟨42,62⟩,⟨3,6⟩,⟨239,271⟩]
private def b26730 : Box := ![⟨40,41⟩,⟨51,62⟩,⟨42,62⟩,⟨3,6⟩,⟨239,271⟩]
private def b26741 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨42,62⟩,⟨3,6⟩,⟨273,317⟩]
private def b26742 : Box := ![⟨38,39⟩,⟨51,62⟩,⟨42,62⟩,⟨3,6⟩,⟨277,317⟩]
private def b26743 : Box := ![⟨38,39⟩,⟨51,55⟩,⟨42,62⟩,⟨3,6⟩,⟨277,317⟩]
private def b26746 : Box := ![⟨38,39⟩,⟨56,62⟩,⟨42,62⟩,⟨3,6⟩,⟨277,317⟩]
private def b26755 : Box := ![⟨40,41⟩,⟨51,62⟩,⟨42,62⟩,⟨3,6⟩,⟨277,317⟩]
private def b26756 : Box := ![⟨40,41⟩,⟨51,55⟩,⟨42,62⟩,⟨3,6⟩,⟨277,317⟩]
private def b26761 : Box := ![⟨40,41⟩,⟨56,62⟩,⟨42,62⟩,⟨3,6⟩,⟨277,317⟩]
private def b26770 : Box := ![⟨38,41⟩,⟨42,62⟩,⟨31,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b26771 : Box := ![⟨38,41⟩,⟨42,50⟩,⟨34,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b26772 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨34,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b26773 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨34,44⟩,⟨3,6⟩,⟨319,478⟩]
private def b26780 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨45,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b26781 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨45,62⟩,⟨3,6⟩,⟨319,382⟩]
private def b26782 : Box := ![⟨38,39⟩,⟨51,62⟩,⟨45,62⟩,⟨3,6⟩,⟨331,379⟩]
private def b26787 : Box := ![⟨40,41⟩,⟨51,62⟩,⟨45,62⟩,⟨3,6⟩,⟨331,379⟩]
private def b26788 : Box := ![⟨40,41⟩,⟨51,55⟩,⟨45,62⟩,⟨3,6⟩,⟨331,379⟩]
private def b26791 : Box := ![⟨40,41⟩,⟨56,62⟩,⟨45,62⟩,⟨3,6⟩,⟨331,379⟩]
private def b26800 : Box := ![⟨38,41⟩,⟨51,62⟩,⟨45,62⟩,⟨3,6⟩,⟨383,478⟩]
private def b26801 : Box := ![⟨38,39⟩,⟨51,62⟩,⟨45,62⟩,⟨3,6⟩,⟨383,467⟩]
private def b26802 : Box := ![⟨40,41⟩,⟨51,62⟩,⟨45,62⟩,⟨3,6⟩,⟨383,467⟩]
private theorem e26669 : Deny 5 13 b26669 := by
    apply closeAction rule_sound _ _ 64 [0x37f8df61c4087e37]
    decide +kernel
private theorem e26676 : Deny 5 13 b26676 := by
    apply closeAction rule_sound _ _ 64 [0x3088102238df6]
    decide +kernel
private theorem e26681 : Deny 5 13 b26681 := by
    apply closeAction rule_sound _ _ 64 [0xc3243103e37d84278dc8]
    decide +kernel
private theorem e26675 : Deny 5 13 b26675 :=
    branchAction rule_sound _ _ 2
      0x1c4 b26675 b26676 b26681 (by decide +kernel) e26676 e26681
private theorem e26688 : Deny 5 13 b26688 := by
    apply closeAction rule_sound _ _ 64 [0xc3e372422021c4]
    decide +kernel
private theorem e26674 : Deny 5 13 b26674 :=
    branchAction rule_sound _ _ 1
      0xb b26674 b26675 b26688 (by decide +kernel) e26675 e26688
private theorem e26668 : Deny 5 13 b26668 :=
    branchAction rule_sound _ _ 2
      0x276 b26668 b26669 b26674 (by decide +kernel) e26669 e26674
private theorem e26698 : Deny 5 13 b26698 := by
    apply closeAction rule_sound _ _ 64 [0xc3e3725fe37d88]
    decide +kernel
private theorem e26703 : Deny 5 13 b26703 := by
    apply closeAction rule_sound _ _ 64 [0x30c90c3e37248]
    decide +kernel
private theorem e26697 : Deny 5 13 b26697 :=
    branchAction rule_sound _ _ 2
      0x1c4 b26697 b26698 b26703 (by decide +kernel) e26698 e26703
private theorem e26710 : Deny 5 13 b26710 := by
    apply closeAction rule_sound _ _ 64 [0xc3e37243e37d887f8df61c4]
    decide +kernel
private theorem e26696 : Deny 5 13 b26696 :=
    branchAction rule_sound _ _ 1
      0xb b26696 b26697 b26710 (by decide +kernel) e26697 e26710
private theorem e26719 : Deny 5 13 b26719 := by
    apply closeAction rule_sound _ _ 64 [0x1f58a58a0c3203e37248]
    decide +kernel
private theorem e26730 : Deny 5 13 b26730 := by
    apply closeAction rule_sound _ _ 64 [0x960c8109e370f8dc3203248]
    decide +kernel
private theorem e26718 : Deny 5 13 b26718 :=
    branchAction rule_sound _ _ 2
      0x1c4 b26718 b26719 b26730 (by decide +kernel) e26719 e26730
private theorem e26743 : Deny 5 13 b26743 := by
    apply closeAction rule_sound _ _ 64 [0x3102238df6]
    decide +kernel
private theorem e26746 : Deny 5 13 b26746 := by
    apply closeAction rule_sound _ _ 64 [0x1f583e085b824a58a]
    decide +kernel
private theorem e26742 : Deny 5 13 b26742 :=
    branchAction rule_sound _ _ 1
      0x8 b26742 b26743 b26746 (by decide +kernel) e26743 e26746
private theorem e26756 : Deny 5 13 b26756 := by
    apply closeAction rule_sound _ _ 64 [0x30c80c9]
    decide +kernel
private theorem e26761 : Deny 5 13 b26761 := by
    apply closeAction rule_sound _ _ 64 [0x7d60f80c920a58a]
    decide +kernel
private theorem e26755 : Deny 5 13 b26755 :=
    branchAction rule_sound _ _ 1
      0x8 b26755 b26756 b26761 (by decide +kernel) e26756 e26761
private theorem e26741 : Deny 5 13 b26741 :=
    branchAction rule_sound _ _ 2
      0x1c4 b26741 b26742 b26755 (by decide +kernel) e26742 e26755
private theorem e26717 : Deny 5 13 b26717 :=
    branchAction rule_sound _ _ 1
      0xb b26717 b26718 b26741 (by decide +kernel) e26718 e26741
private theorem e26695 : Deny 5 13 b26695 :=
    branchAction rule_sound _ _ 1
      0x9 b26695 b26696 b26717 (by decide +kernel) e26696 e26717
private theorem e26667 : Deny 5 13 b26667 :=
    branchAction rule_sound _ _ 2
      0x204 b26667 b26668 b26695 (by decide +kernel) e26668 e26695
private theorem e26771 : Deny 5 13 b26771 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e26773 : Deny 5 13 b26773 := by
    apply closeAction rule_sound _ _ 64 [0x3087088df61021f8]
    decide +kernel
private theorem e26782 : Deny 5 13 b26782 := by
    apply closeAction rule_sound _ _ 64 [0x3087102238df6]
    decide +kernel
private theorem e26788 : Deny 5 13 b26788 := by
    apply closeAction rule_sound _ _ 64 [0x3103e37109e36]
    decide +kernel
private theorem e26791 : Deny 5 13 b26791 := by
    apply closeAction rule_sound _ _ 64 [0x7d60c3e0920a58a]
    decide +kernel
private theorem e26787 : Deny 5 13 b26787 :=
    branchAction rule_sound _ _ 1
      0x8 b26787 b26788 b26791 (by decide +kernel) e26788 e26791
private theorem e26781 : Deny 5 13 b26781 :=
    branchAction rule_sound _ _ 2
      0x1c4 b26781 b26782 b26787 (by decide +kernel) e26782 e26787
private theorem e26801 : Deny 5 13 b26801 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e26802 : Deny 5 13 b26802 := by
    apply closeAction rule_sound _ _ 64 [0x7df583e3620a10b58a088]
    decide +kernel
private theorem e26800 : Deny 5 13 b26800 :=
    branchAction rule_sound _ _ 2
      0x1c4 b26800 b26801 b26802 (by decide +kernel) e26801 e26802
private theorem e26780 : Deny 5 13 b26780 :=
    branchAction rule_sound _ _ 1
      0xb b26780 b26781 b26800 (by decide +kernel) e26781 e26800
private theorem e26772 : Deny 5 13 b26772 :=
    branchAction rule_sound _ _ 1
      0x9 b26772 b26773 b26780 (by decide +kernel) e26773 e26780
private theorem e26770 : Deny 5 13 b26770 :=
    branchAction rule_sound _ _ 2
      0x236 b26770 b26771 b26772 (by decide +kernel) e26771 e26772
private theorem e26666 : Deny 5 13 b26666 :=
    branchAction rule_sound _ _ 1
      0xb b26666 b26667 b26770 (by decide +kernel) e26667 e26770
theorem deny5_13 : Deny 5 13 ![⟨38,41⟩,⟨42,62⟩,⟨31,62⟩,⟨3,6⟩,⟨239,478⟩] := by
  exact e26666
end OMA.Blocks5_13_245212.S26666
