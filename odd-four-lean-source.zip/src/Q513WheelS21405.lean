import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S21405
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b21405 : Box := ![⟨23,26⟩,⟨63,126⟩,⟨15,30⟩,⟨3,74⟩,⟨79,93⟩]
theorem deny5_13 : Deny 5 13 ![⟨23,26⟩,⟨63,126⟩,⟨15,30⟩,⟨3,74⟩,⟨79,93⟩] := by
  have e21405 : Deny 5 13 b21405 := by
    apply closeAction rule_sound _ _ 64 [0x87d885b684adc40838441f80e1243e031c3248583e3784984a2d60f8de12440a1109e37da11c3844087e37da1261284,0x870a3237da3103ac38c80eb8c968384a6b8de31eb8c92eb0c3e378c811ae378c4278de32231e32430f68470f7da1243,0xae32631020eb844238dc20c7dc3ae326b8c92eb0c3de321ade32778c40f70e32030e32232430c80eb0f8dc824a2e3203,0xae126128b783d8a0877b7da3237da311e0de1e32430f71c30f8df61c80c21c928b8c88c70ab0e32370eb8c968308784a,0xc824adcb8c879e0e325adf51e3243ac3dc80877b7dab849da12a311e79e0e32632632420c4238dc3ac32211c30f8847,0xab1020e1107e37083107e2b244238dde7838c98c90831c3dc3dc72030f72092a31020832090820c7203]
    decide +kernel
  exact e21405
end OMA.Blocks5_13_245212.S21405
