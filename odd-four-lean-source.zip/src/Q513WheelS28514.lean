import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S28514
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b28514 : Box := ![⟨31,37⟩,⟨63,126⟩,⟨31,1920000000000000011376⟩,⟨1,1466112759643916922660⟩,⟨239,478⟩]
private def b28515 : Box := ![⟨31,37⟩,⟨63,126⟩,⟨31,1920000000000000011376⟩,⟨1,2⟩,⟨239,478⟩]
private def b28516 : Box := ![⟨31,37⟩,⟨63,126⟩,⟨31,1920000000000000011376⟩,⟨3,900178041543026711621⟩,⟨239,478⟩]
private def b28517 : Box := ![⟨31,37⟩,⟨63,126⟩,⟨31,62⟩,⟨3,900178041543026711621⟩,⟨239,478⟩]
private def b28518 : Box := ![⟨31,33⟩,⟨63,126⟩,⟨31,62⟩,⟨3,77⟩,⟨239,478⟩]
private def b28519 : Box := ![⟨31,33⟩,⟨63,84⟩,⟨31,62⟩,⟨3,76⟩,⟨239,379⟩]
private def b28524 : Box := ![⟨31,33⟩,⟨85,126⟩,⟨31,62⟩,⟨3,76⟩,⟨239,379⟩]
private def b28525 : Box := ![⟨31,33⟩,⟨85,126⟩,⟨31,62⟩,⟨3,76⟩,⟨239,293⟩]
private def b28526 : Box := ![⟨31,33⟩,⟨85,126⟩,⟨31,41⟩,⟨3,76⟩,⟨239,293⟩]
private def b28527 : Box := ![⟨31,31⟩,⟨85,126⟩,⟨31,41⟩,⟨4,66⟩,⟨239,293⟩]
private def b28528 : Box := ![⟨32,33⟩,⟨85,126⟩,⟨31,41⟩,⟨4,66⟩,⟨239,293⟩]
private def b28539 : Box := ![⟨31,33⟩,⟨85,126⟩,⟨42,62⟩,⟨3,76⟩,⟨239,293⟩]
private def b28548 : Box := ![⟨31,33⟩,⟨85,126⟩,⟨31,62⟩,⟨3,76⟩,⟨294,379⟩]
private def b28549 : Box := ![⟨31,33⟩,⟨85,101⟩,⟨39,62⟩,⟨4,72⟩,⟨307,379⟩]
private def b28550 : Box := ![⟨31,33⟩,⟨102,126⟩,⟨39,62⟩,⟨4,72⟩,⟨307,379⟩]
private def b28561 : Box := ![⟨34,37⟩,⟨63,126⟩,⟨31,62⟩,⟨3,77⟩,⟨239,478⟩]
private def b28562 : Box := ![⟨34,37⟩,⟨63,126⟩,⟨31,62⟩,⟨3,77⟩,⟨239,318⟩]
private def b28563 : Box := ![⟨34,37⟩,⟨63,126⟩,⟨31,62⟩,⟨3,6⟩,⟨239,317⟩]
private def b28564 : Box := ![⟨34,37⟩,⟨63,126⟩,⟨31,41⟩,⟨3,6⟩,⟨239,317⟩]
private def b28565 : Box := ![⟨34,37⟩,⟨63,82⟩,⟨31,41⟩,⟨3,6⟩,⟨239,317⟩]
private def b28566 : Box := ![⟨34,35⟩,⟨63,82⟩,⟨31,41⟩,⟨3,6⟩,⟨239,313⟩]
private def b28567 : Box := ![⟨36,37⟩,⟨63,82⟩,⟨31,41⟩,⟨3,6⟩,⟨239,313⟩]
private def b28568 : Box := ![⟨36,37⟩,⟨63,82⟩,⟨31,41⟩,⟨3,6⟩,⟨239,271⟩]
private def b28573 : Box := ![⟨36,37⟩,⟨63,82⟩,⟨31,41⟩,⟨3,6⟩,⟨272,313⟩]
private def b28580 : Box := ![⟨34,37⟩,⟨83,119⟩,⟨31,41⟩,⟨3,6⟩,⟨239,317⟩]
private def b28581 : Box := ![⟨34,35⟩,⟨83,119⟩,⟨31,41⟩,⟨3,6⟩,⟨239,317⟩]
private def b28590 : Box := ![⟨36,37⟩,⟨83,119⟩,⟨31,41⟩,⟨3,6⟩,⟨239,317⟩]
private def b28591 : Box := ![⟨36,37⟩,⟨83,119⟩,⟨31,41⟩,⟨3,6⟩,⟨239,272⟩]
private def b28602 : Box := ![⟨36,37⟩,⟨83,119⟩,⟨31,41⟩,⟨3,6⟩,⟨273,317⟩]
private def b28603 : Box := ![⟨36,37⟩,⟨83,97⟩,⟨31,41⟩,⟨3,6⟩,⟨277,317⟩]
private def b28610 : Box := ![⟨36,37⟩,⟨98,119⟩,⟨31,41⟩,⟨3,6⟩,⟨277,317⟩]
private def b28617 : Box := ![⟨34,37⟩,⟨63,126⟩,⟨42,62⟩,⟨3,6⟩,⟨239,317⟩]
private def b28618 : Box := ![⟨34,37⟩,⟨63,126⟩,⟨31,62⟩,⟨7,77⟩,⟨239,317⟩]
private def b28619 : Box := ![⟨34,37⟩,⟨63,126⟩,⟨31,62⟩,⟨3,77⟩,⟨319,478⟩]
private def b28620 : Box := ![⟨34,37⟩,⟨63,84⟩,⟨31,62⟩,⟨3,73⟩,⟨319,478⟩]
private def b28623 : Box := ![⟨34,37⟩,⟨85,126⟩,⟨31,62⟩,⟨3,73⟩,⟨319,478⟩]
private def b28624 : Box := ![⟨34,37⟩,⟨85,126⟩,⟨31,41⟩,⟨3,73⟩,⟨319,478⟩]
private def b28625 : Box := ![⟨34,37⟩,⟨85,126⟩,⟨31,41⟩,⟨3,6⟩,⟨319,478⟩]
private def b28626 : Box := ![⟨34,35⟩,⟨85,121⟩,⟨31,41⟩,⟨3,6⟩,⟨319,478⟩]
private def b28627 : Box := ![⟨36,37⟩,⟨85,121⟩,⟨31,41⟩,⟨3,6⟩,⟨319,478⟩]
private def b28628 : Box := ![⟨36,37⟩,⟨85,121⟩,⟨31,41⟩,⟨3,6⟩,⟨319,382⟩]
private def b28629 : Box := ![⟨36,37⟩,⟨85,99⟩,⟨31,41⟩,⟨3,6⟩,⟨331,379⟩]
private def b28634 : Box := ![⟨36,37⟩,⟨100,120⟩,⟨31,41⟩,⟨3,6⟩,⟨331,379⟩]
private def b28641 : Box := ![⟨36,37⟩,⟨85,121⟩,⟨31,41⟩,⟨3,6⟩,⟨383,478⟩]
private def b28650 : Box := ![⟨34,37⟩,⟨85,126⟩,⟨31,41⟩,⟨7,63⟩,⟨319,478⟩]
private def b28651 : Box := ![⟨34,37⟩,⟨85,126⟩,⟨42,62⟩,⟨3,73⟩,⟨319,478⟩]
private def b28656 : Box := ![⟨31,37⟩,⟨63,126⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711621⟩,⟨239,478⟩]
private def b28657 : Box := ![⟨31,37⟩,⟨63,126⟩,⟨63,1920000000000000011376⟩,⟨3,6⟩,⟨239,478⟩]
private def b28658 : Box := ![⟨31,37⟩,⟨63,126⟩,⟨63,1920000000000000011376⟩,⟨7,900178041543026711621⟩,⟨239,478⟩]
private def b28659 : Box := ![⟨31,33⟩,⟨63,126⟩,⟨63,1920000000000000011376⟩,⟨7,900178041543026711621⟩,⟨239,478⟩]
private def b28660 : Box := ![⟨31,33⟩,⟨63,126⟩,⟨63,1920000000000000011376⟩,⟨7,900178041543026711620⟩,⟨239,318⟩]
private def b28661 : Box := ![⟨31,33⟩,⟨63,84⟩,⟨63,1920000000000000011376⟩,⟨7,900178041543026711620⟩,⟨239,317⟩]
private def b28672 : Box := ![⟨31,33⟩,⟨85,126⟩,⟨63,1920000000000000011376⟩,⟨7,900178041543026711620⟩,⟨239,317⟩]
private def b28679 : Box := ![⟨31,33⟩,⟨63,126⟩,⟨63,1920000000000000011376⟩,⟨7,900178041543026711620⟩,⟨319,478⟩]
private def b28680 : Box := ![⟨31,33⟩,⟨63,84⟩,⟨63,1920000000000000011376⟩,⟨7,855338345864661659255⟩,⟨319,478⟩]
private def b28687 : Box := ![⟨31,33⟩,⟨85,126⟩,⟨63,1920000000000000011376⟩,⟨7,855338345864661659255⟩,⟨319,478⟩]
private def b28694 : Box := ![⟨34,37⟩,⟨63,126⟩,⟨63,1920000000000000011376⟩,⟨7,900178041543026711621⟩,⟨239,478⟩]
private theorem e28515 : Deny 5 13 b28515 := by
    apply closeAction rule_sound _ _ 64 [0x5a2]
    decide +kernel
private theorem e28519 : Deny 5 13 b28519 := by
    apply closeAction rule_sound _ _ 64 [0x1e5b8d8a11ee37da3108e37da3]
    decide +kernel
private theorem e28527 : Deny 5 13 b28527 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e28528 : Deny 5 13 b28528 := by
    apply closeAction rule_sound _ _ 64 [0x1e7ca7d610ae3684a7c21f8df68c8]
    decide +kernel
private theorem e28526 : Deny 5 13 b28526 :=
    branchAction rule_sound _ _ 3
      0x7de3 b28526 b28527 b28528 (by decide +kernel) e28527 e28528
private theorem e28539 : Deny 5 13 b28539 := by
    apply closeAction rule_sound _ _ 64 [0x1e59f7b8df6d4724a58a]
    decide +kernel
private theorem e28525 : Deny 5 13 b28525 :=
    branchAction rule_sound _ _ 1
      0x9 b28525 b28526 b28539 (by decide +kernel) e28526 e28539
private theorem e28549 : Deny 5 13 b28549 := by
    apply closeAction rule_sound _ _ 64 [0x1ee37da3]
    decide +kernel
private theorem e28550 : Deny 5 13 b28550 := by
    apply closeAction rule_sound _ _ 64 [0x1e7ca7b8df61d629ee378c9087]
    decide +kernel
private theorem e28548 : Deny 5 13 b28548 :=
    branchAction rule_sound _ _ 5
      0x8df68c4 b28548 b28549 b28550 (by decide +kernel) e28549 e28550
private theorem e28524 : Deny 5 13 b28524 :=
    branchAction rule_sound _ _ 1
      0xb b28524 b28525 b28548 (by decide +kernel) e28525 e28548
private theorem e28518 : Deny 5 13 b28518 :=
    branchAction rule_sound _ _ 3
      0x8e23 b28518 b28519 b28524 (by decide +kernel) e28519 e28524
private theorem e28566 : Deny 5 13 b28566 := by
    apply closeAction rule_sound _ _ 64 [0x16e37db5]
    decide +kernel
private theorem e28568 : Deny 5 13 b28568 := by
    apply closeAction rule_sound _ _ 64 [0x160c3e371c9]
    decide +kernel
private theorem e28573 : Deny 5 13 b28573 := by
    apply closeAction rule_sound _ _ 64 [0xdfe372421c2237d84]
    decide +kernel
private theorem e28567 : Deny 5 13 b28567 :=
    branchAction rule_sound _ _ 1
      0xb b28567 b28568 b28573 (by decide +kernel) e28568 e28573
private theorem e28565 : Deny 5 13 b28565 :=
    branchAction rule_sound _ _ 2
      0x1f8 b28565 b28566 b28567 (by decide +kernel) e28566 e28567
private theorem e28581 : Deny 5 13 b28581 := by
    apply closeAction rule_sound _ _ 64 [0x5830f82047f8df6107e2158ae21261]
    decide +kernel
private theorem e28591 : Deny 5 13 b28591 := by
    apply closeAction rule_sound _ _ 64 [0x16e375b8dc38478495830c8248844]
    decide +kernel
private theorem e28603 : Deny 5 13 b28603 := by
    apply closeAction rule_sound _ _ 64 [0x35870c3e37209]
    decide +kernel
private theorem e28610 : Deny 5 13 b28610 := by
    apply closeAction rule_sound _ _ 64 [0x1f58384984a5aa84a]
    decide +kernel
private theorem e28602 : Deny 5 13 b28602 :=
    branchAction rule_sound _ _ 2
      0x204 b28602 b28603 b28610 (by decide +kernel) e28603 e28610
private theorem e28590 : Deny 5 13 b28590 :=
    branchAction rule_sound _ _ 1
      0xb b28590 b28591 b28602 (by decide +kernel) e28591 e28602
private theorem e28580 : Deny 5 13 b28580 :=
    branchAction rule_sound _ _ 1
      0x7 b28580 b28581 b28590 (by decide +kernel) e28581 e28590
private theorem e28564 : Deny 5 13 b28564 :=
    branchAction rule_sound _ _ 2
      0x221 b28564 b28565 b28580 (by decide +kernel) e28565 e28580
private theorem e28617 : Deny 5 13 b28617 := by
    apply closeAction rule_sound _ _ 64 [0x16]
    decide +kernel
private theorem e28563 : Deny 5 13 b28563 :=
    branchAction rule_sound _ _ 1
      0x9 b28563 b28564 b28617 (by decide +kernel) e28564 e28617
private theorem e28618 : Deny 5 13 b28618 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e28562 : Deny 5 13 b28562 :=
    branchAction rule_sound _ _ 2
      0x284 b28562 b28563 b28618 (by decide +kernel) e28563 e28618
private theorem e28620 : Deny 5 13 b28620 := by
    apply closeAction rule_sound _ _ 64 [0x1f5b8d8ada3]
    decide +kernel
private theorem e28626 : Deny 5 13 b28626 := by
    apply closeAction rule_sound _ _ 64 [0x5b8df6d61]
    decide +kernel
private theorem e28629 : Deny 5 13 b28629 := by
    apply closeAction rule_sound _ _ 64 [0x583e3725fe37276]
    decide +kernel
private theorem e28634 : Deny 5 13 b28634 := by
    apply closeAction rule_sound _ _ 64 [0x7d60f884984a5aa84a]
    decide +kernel
private theorem e28628 : Deny 5 13 b28628 :=
    branchAction rule_sound _ _ 3
      0x8844 b28628 b28629 b28634 (by decide +kernel) e28629 e28634
private theorem e28641 : Deny 5 13 b28641 := by
    apply closeAction rule_sound _ _ 64 [0x583e378495b8df68470ab8495b8df6204]
    decide +kernel
private theorem e28627 : Deny 5 13 b28627 :=
    branchAction rule_sound _ _ 1
      0xb b28627 b28628 b28641 (by decide +kernel) e28628 e28641
private theorem e28625 : Deny 5 13 b28625 :=
    branchAction rule_sound _ _ 2
      0x1e1 b28625 b28626 b28627 (by decide +kernel) e28626 e28627
private theorem e28650 : Deny 5 13 b28650 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e28624 : Deny 5 13 b28624 :=
    branchAction rule_sound _ _ 2
      0x2a3 b28624 b28625 b28650 (by decide +kernel) e28625 e28650
private theorem e28651 : Deny 5 13 b28651 := by
    apply closeAction rule_sound _ _ 64 [0x1e7ca58a]
    decide +kernel
private theorem e28623 : Deny 5 13 b28623 :=
    branchAction rule_sound _ _ 1
      0x9 b28623 b28624 b28651 (by decide +kernel) e28624 e28651
private theorem e28619 : Deny 5 13 b28619 :=
    branchAction rule_sound _ _ 2
      0x223 b28619 b28620 b28623 (by decide +kernel) e28620 e28623
private theorem e28561 : Deny 5 13 b28561 :=
    branchAction rule_sound _ _ 1
      0xb b28561 b28562 b28619 (by decide +kernel) e28562 e28619
private theorem e28517 : Deny 5 13 b28517 :=
    branchAction rule_sound _ _ 2
      0x1e3 b28517 b28518 b28561 (by decide +kernel) e28518 e28561
private theorem e28657 : Deny 5 13 b28657 := by
    apply closeAction rule_sound _ _ 64 [0x5a2]
    decide +kernel
private theorem e28661 : Deny 5 13 b28661 := by
    apply closeAction rule_sound _ _ 64 [0x72f7af8c9bde7dfe368841f888a7b8df61e3263]
    decide +kernel
private theorem e28672 : Deny 5 13 b28672 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdebe325e58a8c9]
    decide +kernel
private theorem e28660 : Deny 5 13 b28660 :=
    branchAction rule_sound _ _ 2
      0x204 b28660 b28661 b28672 (by decide +kernel) e28661 e28672
private theorem e28680 : Deny 5 13 b28680 := by
    apply closeAction rule_sound _ _ 64 [0x72f7af102238daf8c9da31021f8da3]
    decide +kernel
private theorem e28687 : Deny 5 13 b28687 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdebe325e58a8c9]
    decide +kernel
private theorem e28679 : Deny 5 13 b28679 :=
    branchAction rule_sound _ _ 2
      0x223 b28679 b28680 b28687 (by decide +kernel) e28680 e28687
private theorem e28659 : Deny 5 13 b28659 :=
    branchAction rule_sound _ _ 2
      0x2e3 b28659 b28660 b28679 (by decide +kernel) e28660 e28679
private theorem e28694 : Deny 5 13 b28694 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe37a32787a325f88a]
    decide +kernel
private theorem e28658 : Deny 5 13 b28658 :=
    branchAction rule_sound _ _ 1
      0x7 b28658 b28659 b28694 (by decide +kernel) e28659 e28694
private theorem e28656 : Deny 5 13 b28656 :=
    branchAction rule_sound _ _ 1
      0xa b28656 b28657 b28658 (by decide +kernel) e28657 e28658
private theorem e28516 : Deny 5 13 b28516 :=
    branchAction rule_sound _ _ 1
      0x9 b28516 b28517 b28656 (by decide +kernel) e28517 e28656
private theorem e28514 : Deny 5 13 b28514 :=
    branchAction rule_sound _ _ 2
      0x2a3 b28514 b28515 b28516 (by decide +kernel) e28515 e28516
theorem deny5_13 : Deny 5 13 ![⟨31,37⟩,⟨63,126⟩,⟨31,1920000000000000011376⟩,⟨1,1466112759643916922660⟩,⟨239,478⟩] := by
  exact e28514
end OMA.Blocks5_13_245212.S28514
