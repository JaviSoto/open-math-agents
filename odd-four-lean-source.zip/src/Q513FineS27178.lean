import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S27178
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b27178 : Box := ![⟨38,46⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨1,900178041543026711610⟩,⟨479,999999999999999999⟩]
private def b27179 : Box := ![⟨38,46⟩,⟨31,41⟩,⟨31,1920000000000000011376⟩,⟨1,799016681299385430586⟩,⟨479,999999999999999999⟩]
private def b27182 : Box := ![⟨38,46⟩,⟨42,62⟩,⟨31,1920000000000000011376⟩,⟨1,799016681299385430586⟩,⟨479,999999999999999999⟩]
private def b27183 : Box := ![⟨38,46⟩,⟨42,62⟩,⟨31,62⟩,⟨1,799016681299385430586⟩,⟨479,999999999999999999⟩]
private def b27236 : Box := ![⟨38,46⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨1,799016681299385430586⟩,⟨479,999999999999999999⟩]
private def b27237 : Box := ![⟨38,41⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨1,799016681299385430586⟩,⟨479,999999999999999999⟩]
private def b27264 : Box := ![⟨42,46⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨1,799016681299385430586⟩,⟨479,999999999999999999⟩]
private def b27265 : Box := ![⟨42,46⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨1,2⟩,⟨479,999999999999999999⟩]
private def b27266 : Box := ![⟨42,46⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨3,799016681299385430586⟩,⟨479,999999999999999999⟩]
private def b27267 : Box := ![⟨42,46⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨3,799016681299385430586⟩,⟨479,958⟩]
private def b27320 : Box := ![⟨42,46⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨3,799016681299385430586⟩,⟨959,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨38,46⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨1,900178041543026711610⟩,⟨479,999999999999999999⟩] := by
  have e27179 : Deny 5 13 b27179 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe37ef8c9e37da3]
    decide +kernel
  have e27183 : Deny 5 13 b27183 := by
    apply closeAction rule_sound _ _ 64 [0x2b8d8a087e367d7597e362022361d72d60f8d88088e361d7087e095ca28be1f5ca087e362382972b88dfe37db58c7e23,0x7df0c3e07e17e090f8d87e17087e36217]
    decide +kernel
  have e27237 : Deny 5 13 b27237 := by
    apply closeAction rule_sound _ _ 64 [0xbdfbe32768dcbdebe326f7ef7f78c47df58ae222842dee37da321ce37d87e2326324b72f8dfbe3278da32230ad88ae23,0x1c]
    decide +kernel
  have e27265 : Deny 5 13 b27265 := by
    apply closeAction rule_sound _ _ 64 [0x17e22]
    decide +kernel
  have e27267 : Deny 5 13 b27267 := by
    apply closeAction rule_sound _ _ 64 [0x8822388875ca88a7d7583e22203e222172a21e22a22e22a326325cbdcbe326f7ef7df5cae2229fe378c7e23263263223,0x72f8dfbe3278bdfbdf7d70c7e038870c21f8888582238]
    decide +kernel
  have e27320 : Deny 5 13 b27320 := by
    apply closeAction rule_sound _ _ 64 [0x87e368c80878dfbdf7c30f81c3e368870a21042f8da22172a22a229fe37da31e32632e325cbdc26f8dfbe3278da3223,0xdaf88a1e372f7ef8c9be32c30e325fe37d870888dfbe32e37ef8cb0878dfbe32c30f88c97f8df68c8e23087e2325fbe3,0xda37cb8c9538be22af8c809cbe3278be372f8c9e1ce3622f7b8be32421f6bc22368dcbe32c222372f8cbbdfe23254e37,0xbc88dcbe32e372f8cb8dcbe32e372f8cb8dcbe32c21e372f8cb8dcbe32ef0dfe232422021e37cb7f88c97f8df68c8087,0x2e37cb8dfbe32e37ef8cbbe324208272f8c9d88bdcbe326f088d87bdcbc20f62022232421ef8c908222f72f8c9bc21f6,0x2e372f8cbe2f0820c3d88207bc20c80c22078df2e32420e3243d880f61f68dcbe32f6bc88df2c3088088bc22368c78df,0x26f72f0838c90888c9be324209cbe327622f72f8c9bc22362231e372f8cb8dcbe32e372f8cb8dcbe32e372f8cb8dcbe3,0x208272f083d880888c91ef8c98c809cbe3]
    decide +kernel
  have e27266 : Deny 5 13 b27266 :=
    branchAction rule_sound _ _ 1
      0xb b27266 b27267 b27320 (by decide +kernel) e27267 e27320
  have e27264 : Deny 5 13 b27264 :=
    branchAction rule_sound _ _ 1
      0xa b27264 b27265 b27266 (by decide +kernel) e27265 e27266
  have e27236 : Deny 5 13 b27236 :=
    branchAction rule_sound _ _ 1
      0x7 b27236 b27237 b27264 (by decide +kernel) e27237 e27264
  have e27182 : Deny 5 13 b27182 :=
    branchAction rule_sound _ _ 1
      0x9 b27182 b27183 b27236 (by decide +kernel) e27183 e27236
  have e27178 : Deny 5 13 b27178 :=
    branchAction rule_sound _ _ 2
      0x223 b27178 b27179 b27182 (by decide +kernel) e27179 e27182
  exact e27178
end OMA.Blocks5_13_245212.S27178
