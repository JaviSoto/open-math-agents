import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S39981
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b39981 : Box := ![⟨63,94⟩,⟨21,30⟩,⟨15,30⟩,⟨3,50⟩,⟨127,164⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨21,30⟩,⟨15,30⟩,⟨3,50⟩,⟨127,164⟩] := by
  have e39981 : Deny 5 13 b39981 := by
    apply closeAction rule_sound _ _ 64 [0xc3dc91c30f8dc90f8df61c81020c9dc3dc32470c32430f72472042c3087088df61030c90dfe37d87df62042c91c8284,0x2040820c4278dc3dc31c72042c3dc31c30f71c90c3e37243e37d87204083107e370f70c72430c70c3dc724810b2430c9,0x832770c31c71025c9dc42c42385f70c90c80c32432081025f8dc31c90f70c90c82042c91c25f8dc32470f70c70c31c7,0x1f097e370831f70f70c72440820c727710b2095f8dc4]
    decide +kernel
  exact e39981
end OMA.Blocks5_13_245212.S39981
