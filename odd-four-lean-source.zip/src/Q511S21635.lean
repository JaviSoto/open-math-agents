import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S21635
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b21635 : Box := ![⟨47,94⟩,⟨31,1920000000000000011376⟩,⟨3,4⟩,⟨1,1125052631578947375119⟩,⟨103,999999999999999999⟩]
private def b21636 : Box := ![⟨47,94⟩,⟨31,1920000000000000011376⟩,⟨3,4⟩,⟨1,669192982456140354887⟩,⟨103,206⟩]
private def b21693 : Box := ![⟨47,94⟩,⟨31,1920000000000000011376⟩,⟨3,4⟩,⟨1,669192982456140354887⟩,⟨207,999999999999999999⟩]
private def b21694 : Box := ![⟨47,94⟩,⟨31,62⟩,⟨3,4⟩,⟨1,581463414634146344947⟩,⟨207,999999999999999999⟩]
private def b21783 : Box := ![⟨47,94⟩,⟨63,1920000000000000011376⟩,⟨3,4⟩,⟨1,581463414634146344947⟩,⟨207,999999999999999999⟩]
private def b21784 : Box := ![⟨47,62⟩,⟨63,1920000000000000011376⟩,⟨3,4⟩,⟨1,581463414634146344947⟩,⟨207,999999999999999999⟩]
private def b21785 : Box := ![⟨47,62⟩,⟨63,1920000000000000011376⟩,⟨3,3⟩,⟨1,581463414634146344941⟩,⟨207,999999999999999999⟩]
private def b21790 : Box := ![⟨47,62⟩,⟨63,1920000000000000011376⟩,⟨4,4⟩,⟨1,581463414634146344941⟩,⟨207,999999999999999999⟩]
private def b21791 : Box := ![⟨47,62⟩,⟨63,1920000000000000011376⟩,⟨4,4⟩,⟨1,581463414634146344941⟩,⟨207,414⟩]
private def b21806 : Box := ![⟨47,62⟩,⟨63,1920000000000000011376⟩,⟨4,4⟩,⟨1,581463414634146344941⟩,⟨415,999999999999999999⟩]
private def b21987 : Box := ![⟨63,94⟩,⟨63,1920000000000000011376⟩,⟨3,4⟩,⟨1,581463414634146344947⟩,⟨207,999999999999999999⟩]
theorem deny5_11 : Deny 5 11 ![⟨47,94⟩,⟨31,1920000000000000011376⟩,⟨3,4⟩,⟨1,1125052631578947375119⟩,⟨103,999999999999999999⟩] := by
  have e21636 : Deny 5 11 b21636 := by
    apply closeAction rule_sound _ _ 64 [0xa212898c76d34c20c7e134f8808e092084c3e032041f80c3e07204083e031c810be044cae13e352474ca2a321384a8c4,0x82adb4ca8c88c4278093238ddaae311aae3108e2b6e3213e2b]
    decide +kernel
  have e21694 : Deny 5 11 b21694 := by
    apply closeAction rule_sound _ _ 64 [0x2b80c3e081d32882932a32db4f8d442b8df525b6d32b86f8df51d30c3e081c42f80c4087e084cae0a4cae23089e231e3,0x2232c30f8de31c3e23087e378c88db4ca4ca8cb8c76c3e03e07e03e08e03102238df51f82b88d32b88c88db4dbe130c8,0x20f88c7e038c80c3e231e32234f8dc3e370e31e3]
    decide +kernel
  have e21785 : Deny 5 11 b21785 := by
    apply closeAction rule_sound _ _ 64 [0x6ab688ae36eb8c8e37d63]
    decide +kernel
  have e21791 : Deny 5 11 b21791 := by
    apply closeAction rule_sound _ _ 64 [0xab6eb6db6d32b80f884784a2b84ca8c8ae3223]
    decide +kernel
  have e21806 : Deny 5 11 b21806 := by
    apply closeAction rule_sound _ _ 64 [0x8cb8dbae32e36eb8cbadb0f8ae10f82382b88d32b88c88dbadb6db4ca84a2932a322b8cb6eb8c3087e2b8c8e231e3223,0x6eb8cb8dbae32e36eb8cb8dbae32e36eb8cb8dbae32e36eb8cb8dbae32e36eb8cb8dbae32c21e36eb8cb8dbae32e36eb,0x2f8ac3e031dbe078db2dbe2321be351e36ab8cb8c88c26ab8c8e2b8cbe12e2b84a8c7ac30e31c38c86eb8cb8dbae32e3,0x8c8e0209ae2b0eb0e322322b1eb8c809aae322b6ab8c8adaae3235ae36ab8cbd6b1e36ab8cb8daae32e36ab8cb8daae3,0xae32e36cb8db2e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32f88c7e2b,0x21aae12daae12daae12daae12daae12daae12daae12daae12c2ae884b48b84a8daae32e36ab8cb8daae32e36ab8cb8da,0x8269aac30c7]
    decide +kernel
  have e21790 : Deny 5 11 b21790 :=
    branchAction rule_sound _ _ 1
      0xb b21790 b21791 b21806 (by decide +kernel) e21791 e21806
  have e21784 : Deny 5 11 b21784 :=
    branchAction rule_sound _ _ 2
      0x263 b21784 b21785 b21790 (by decide +kernel) e21785 e21790
  have e21987 : Deny 5 11 b21987 := by
    apply closeAction rule_sound _ _ 64 [0xadaae322368be1ae231dae358c7adbe2b8c88daae32eb6f88c80878daae32e36ab8cbe1be2321be23213e21293e21289,0x820ab0f88c88c7e232232f88c7e232380826ab8c8e2b8daae3238ae36ab8c8e2b6ab8c8ac21f58da2c7adaae322368b,0x82082083e2b1f88c8e231f8083e232380c3e232231e3223]
    decide +kernel
  have e21783 : Deny 5 11 b21783 :=
    branchAction rule_sound _ _ 1
      0x7 b21783 b21784 b21987 (by decide +kernel) e21784 e21987
  have e21693 : Deny 5 11 b21693 :=
    branchAction rule_sound _ _ 2
      0x223 b21693 b21694 b21783 (by decide +kernel) e21694 e21783
  have e21635 : Deny 5 11 b21635 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21635 b21636 b21693 (by decide +kernel) e21636 e21693
  exact e21635
end OMA.Blocks5_11_245212.S21635
