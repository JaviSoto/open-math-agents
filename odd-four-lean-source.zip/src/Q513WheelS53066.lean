import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S53066
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b53066 : Box := ![⟨63,94⟩,⟨31,62⟩,⟨10,14⟩,⟨1,52⟩,⟨127,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨31,62⟩,⟨10,14⟩,⟨1,52⟩,⟨127,233⟩] := by
  have e53066 : Deny 5 13 b53066 := by
    apply closeAction rule_sound _ _ 64 [0x8c78c88c9083107e37103109e370f8dc32370e31e32030e31c30e31e32232631c42d74d30e01021f88084cae0824a8c8,0x1c38c90c3e23203e231e32030f8de31c30f8de31f8de32232631e3102083e370c81c4238dd3e370f8dc31c8e370f8dc3,0x10be03e370e31c38c98c80c38c80c38c88c78c46c20c4238dc3e03207283e370c80c32072842c30f88c78c88c90f80e3,0xe032030c81d328a10b8c88c98c78c2093e374f8dc3e370c81c8247dc42f84ca083109e370f70e32231e3102083247de3,0xdd3e370c91f710b8c84f8dc32370c38c88c78c44f8dc3e370c81f710b0c38c80c3e378c88c78c46c20c42780c3207283,0x13e378c44f8dc20c4278dc3dc38c88c78c2083247dc42e3223109e020832441f8dd3e370c8dc3dc38c88c78c44f8]
    decide +kernel
  exact e53066
end OMA.Blocks5_13_245212.S53066
