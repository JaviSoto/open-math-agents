import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S14663
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b14663 : Box := ![⟨47,1920000000000000011376⟩,⟨7,9⟩,⟨9,1920000000000000011376⟩,⟨1,1728510638297872350698⟩,⟨59,109⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,1920000000000000011376⟩,⟨7,9⟩,⟨9,1920000000000000011376⟩,⟨1,1728510638297872350698⟩,⟨59,109⟩] := by
  have e14663 : Deny 5 13 b14663 := by
    apply closeAction rule_sound _ _ 64 [0x8c810b6676476631c280a678df6d232029e680ad02238df48c911cbddbe325ddf68c9088087d84088e37da3107e37da3,0x6677678c79e325d72f7498c776229d25588a7550a7804278de680a778df68c7102238de32631d59951e229d54ae37db4,0x75d88a54a8c77559a210ae199e325d1d59a229d54ae37da31d5db488adc88c457709127775d88a8c756654788a8c810b,0x7678c975529529dde32631c42d99c47678c41f8d278c976f749087e37da31d5e36d2229de37db4202237db48c4551277,0x75529529d9e325de37da31e3577]
    decide +kernel
  exact e14663
end OMA.Blocks5_13_245212.S14663
