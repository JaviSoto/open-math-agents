import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S16546
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b16546 : Box := ![⟨191,1920000000000000011376⟩,⟨11,14⟩,⟨19,1920000000000000011376⟩,⟨1,1490642201834862394180⟩,⟨113,193⟩]
theorem deny5_13 : Deny 5 13 ![⟨191,1920000000000000011376⟩,⟨11,14⟩,⟨19,1920000000000000011376⟩,⟨1,1490642201834862394180⟩,⟨113,193⟩] := by
  have e16546 : Deny 5 13 b16546 := by
    apply closeAction rule_sound _ _ 64 [0x1e31027429951e22a3108e199dd1e78c956688a56688a75d88a56688a54a8c710b66711de369e3107e278c98c856688a,0x8c78c910b6677599e31199c42f89e32678c79e325d56654788a6677479e32559a22959a229d578da2295284088e37da3,0x578dd99e3747e278c9578ddd56210ae1528875d54a9a02a32552a31e3115e370a7578de78c475598a8c41f854a]
    decide +kernel
  exact e16546
end OMA.Blocks5_13_245212.S16546
