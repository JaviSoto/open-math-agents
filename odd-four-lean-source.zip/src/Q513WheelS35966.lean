import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S35966
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b35966 : Box := ![⟨63,94⟩,⟨21,30⟩,⟨7,14⟩,⟨3,46⟩,⟨79,113⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨21,30⟩,⟨7,14⟩,⟨3,46⟩,⟨79,113⟩] := by
  have e35966 : Deny 5 13 b35966 := by
    apply closeAction rule_sound _ _ 64 [0x8c7083107e370f8de70c72030e02090c3203dc91ca0f8dc38c80e32430e32231c30e78080f71c3e3780980a8c810b8c9,0x88e3724a0c3de3203e378c98c70c3e378c80c4088e378c7089de32231020831c4238dc3e370e3223243e370e32038c9,0x8c9083804238dc3e370e02090f8dc32030c82472a32042c3e371038c41f80c38c78c80c3e378c88c90c31c39c3e07203,0x243e370c80c90c3e2020929f0c3e088c90c3203102238dc92a31e3223102083e370c8247ddf083108e370f8dc38c88c7,0x20831c4238dc20831c42380831f8dc3e031c8289ddf0f80e3223257e370c80c90c32092a31dfe378c47c8e030e3223]
    decide +kernel
  exact e35966
end OMA.Blocks5_13_245212.S35966
