import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S50917
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b50917 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨1,799016681299385430602⟩,⟨479,999999999999999999⟩]
private def b50918 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨1,799016681299385430602⟩,⟨479,958⟩]
private def b50919 : Box := ![⟨127,190⟩,⟨21,22⟩,⟨63,1920000000000000011376⟩,⟨1,799016681299385430596⟩,⟨479,958⟩]
private def b50920 : Box := ![⟨127,190⟩,⟨21,22⟩,⟨63,126⟩,⟨1,799016681299385430596⟩,⟨479,958⟩]
private def b50921 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨63,126⟩,⟨1,95⟩,⟨479,958⟩]
private def b50922 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨63,126⟩,⟨1,88⟩,⟨479,638⟩]
private def b50923 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨63,126⟩,⟨1,88⟩,⟨639,958⟩]
private def b50924 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨63,126⟩,⟨1,2⟩,⟨639,958⟩]
private def b50925 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨63,126⟩,⟨3,84⟩,⟨639,958⟩]
private def b50926 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨63,84⟩,⟨3,84⟩,⟨658,958⟩]
private def b50937 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨85,126⟩,⟨3,84⟩,⟨658,958⟩]
private def b50938 : Box := ![⟨153,190⟩,⟨21,22⟩,⟨63,126⟩,⟨1,95⟩,⟨479,958⟩]
private def b50939 : Box := ![⟨127,190⟩,⟨21,22⟩,⟨127,1920000000000000011376⟩,⟨1,799016681299385430596⟩,⟨479,958⟩]
private def b50940 : Box := ![⟨127,190⟩,⟨23,24⟩,⟨63,1920000000000000011376⟩,⟨1,799016681299385430596⟩,⟨479,958⟩]
private def b50941 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨1,799016681299385430602⟩,⟨959,999999999999999999⟩]
private def b50942 : Box := ![⟨127,190⟩,⟨21,22⟩,⟨63,1920000000000000011376⟩,⟨1,718295185477505923801⟩,⟨959,999999999999999999⟩]
private def b50943 : Box := ![⟨127,190⟩,⟨21,22⟩,⟨63,1920000000000000011376⟩,⟨1,2⟩,⟨959,999999999999999999⟩]
private def b50944 : Box := ![⟨127,190⟩,⟨21,22⟩,⟨63,1920000000000000011376⟩,⟨3,718295185477505923800⟩,⟨959,999999999999999999⟩]
private def b50945 : Box := ![⟨127,190⟩,⟨21,22⟩,⟨63,126⟩,⟨3,718295185477505923800⟩,⟨959,999999999999999999⟩]
private def b50946 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨63,126⟩,⟨3,90⟩,⟨959,999999999999999999⟩]
private def b50947 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨63,126⟩,⟨3,84⟩,⟨959,1918⟩]
private def b50954 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨63,126⟩,⟨3,84⟩,⟨1919,999999999999999999⟩]
private def b50955 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨63,84⟩,⟨3,76⟩,⟨1919,999999999999999999⟩]
private def b50956 : Box := ![⟨127,138⟩,⟨21,22⟩,⟨63,84⟩,⟨3,62⟩,⟨1919,999999999999999999⟩]
private def b50957 : Box := ![⟨127,138⟩,⟨21,21⟩,⟨63,84⟩,⟨3,60⟩,⟨1919,106082⟩]
private def b50958 : Box := ![⟨127,138⟩,⟨22,22⟩,⟨63,84⟩,⟨3,60⟩,⟨1919,106082⟩]
private def b50959 : Box := ![⟨127,138⟩,⟨22,22⟩,⟨63,84⟩,⟨3,6⟩,⟨1919,105982⟩]
private def b50960 : Box := ![⟨127,138⟩,⟨22,22⟩,⟨63,84⟩,⟨7,56⟩,⟨1919,105982⟩]
private def b50971 : Box := ![⟨139,152⟩,⟨21,22⟩,⟨63,84⟩,⟨3,62⟩,⟨1919,999999999999999999⟩]
private def b50972 : Box := ![⟨139,152⟩,⟨21,22⟩,⟨63,84⟩,⟨3,62⟩,⟨1919,3838⟩]
private def b50979 : Box := ![⟨139,152⟩,⟨21,22⟩,⟨63,84⟩,⟨3,62⟩,⟨3839,999999999999999999⟩]
private def b50990 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨85,126⟩,⟨3,76⟩,⟨1919,999999999999999999⟩]
private def b50991 : Box := ![⟨127,138⟩,⟨21,22⟩,⟨85,126⟩,⟨3,76⟩,⟨1919,999999999999999999⟩]
private def b50992 : Box := ![⟨127,138⟩,⟨21,22⟩,⟨85,126⟩,⟨3,74⟩,⟨1919,3838⟩]
private def b50999 : Box := ![⟨127,138⟩,⟨21,22⟩,⟨85,126⟩,⟨3,74⟩,⟨3839,999999999999999999⟩]
private def b51000 : Box := ![⟨127,138⟩,⟨21,21⟩,⟨85,126⟩,⟨3,68⟩,⟨3839,999999999999999999⟩]
private def b51003 : Box := ![⟨127,138⟩,⟨22,22⟩,⟨85,126⟩,⟨3,68⟩,⟨3839,999999999999999999⟩]
private def b51014 : Box := ![⟨139,152⟩,⟨21,22⟩,⟨85,126⟩,⟨3,76⟩,⟨1919,999999999999999999⟩]
private def b51015 : Box := ![⟨139,152⟩,⟨21,21⟩,⟨85,126⟩,⟨3,76⟩,⟨1919,999999999999999999⟩]
private def b51016 : Box := ![⟨139,152⟩,⟨21,21⟩,⟨85,126⟩,⟨3,76⟩,⟨1919,3838⟩]
private def b51023 : Box := ![⟨139,152⟩,⟨21,21⟩,⟨85,126⟩,⟨3,76⟩,⟨3839,999999999999999999⟩]
private def b51024 : Box := ![⟨139,152⟩,⟨21,21⟩,⟨85,101⟩,⟨3,70⟩,⟨3839,999999999999999999⟩]
private def b51031 : Box := ![⟨139,152⟩,⟨21,21⟩,⟨102,126⟩,⟨3,70⟩,⟨3839,999999999999999999⟩]
private def b51038 : Box := ![⟨139,152⟩,⟨22,22⟩,⟨85,126⟩,⟨3,76⟩,⟨1919,999999999999999999⟩]
private def b51039 : Box := ![⟨153,190⟩,⟨21,22⟩,⟨63,126⟩,⟨3,90⟩,⟨959,999999999999999999⟩]
private def b51040 : Box := ![⟨153,190⟩,⟨21,21⟩,⟨63,126⟩,⟨3,90⟩,⟨1566,999999999999999999⟩]
private def b51041 : Box := ![⟨153,190⟩,⟨21,21⟩,⟨63,84⟩,⟨3,84⟩,⟨1566,999999999999999999⟩]
private def b51042 : Box := ![⟨153,190⟩,⟨21,21⟩,⟨63,84⟩,⟨3,69⟩,⟨1567,3134⟩]
private def b51049 : Box := ![⟨153,190⟩,⟨21,21⟩,⟨63,84⟩,⟨3,69⟩,⟨3135,999999999999999999⟩]
private def b51050 : Box := ![⟨153,169⟩,⟨21,21⟩,⟨63,84⟩,⟨3,63⟩,⟨3135,999999999999999999⟩]
private def b51059 : Box := ![⟨170,190⟩,⟨21,21⟩,⟨63,84⟩,⟨3,63⟩,⟨3135,999999999999999999⟩]
private def b51064 : Box := ![⟨153,190⟩,⟨21,21⟩,⟨85,126⟩,⟨3,84⟩,⟨1566,999999999999999999⟩]
private def b51073 : Box := ![⟨153,190⟩,⟨22,22⟩,⟨63,126⟩,⟨3,90⟩,⟨1566,999999999999999999⟩]
private def b51074 : Box := ![⟨127,190⟩,⟨21,22⟩,⟨127,1920000000000000011376⟩,⟨3,718295185477505923800⟩,⟨959,999999999999999999⟩]
private def b51075 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨127,1920000000000000011376⟩,⟨3,718295185477505923800⟩,⟨1532,999999999999999999⟩]
private def b51076 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨127,1920000000000000011376⟩,⟨3,672141802067946828248⟩,⟨1532,999999999999999999⟩]
private def b51077 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨127,1920000000000000011376⟩,⟨3,672141802067946828247⟩,⟨1532,3064⟩]
private def b51080 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨127,1920000000000000011376⟩,⟨3,672141802067946828247⟩,⟨3065,999999999999999999⟩]
private def b51081 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨127,254⟩,⟨3,614089068825910934849⟩,⟨3065,999999999999999999⟩]
private def b51082 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨127,254⟩,⟨3,113⟩,⟨3065,6130⟩]
private def b51083 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨127,254⟩,⟨3,113⟩,⟨6131,999999999999999999⟩]
private def b51084 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨127,254⟩,⟨3,104⟩,⟨6131,12262⟩]
private def b51085 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨127,254⟩,⟨3,104⟩,⟨12263,999999999999999999⟩]
private def b51086 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨127,254⟩,⟨3,96⟩,⟨12263,24526⟩]
private def b51087 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨127,254⟩,⟨3,96⟩,⟨24527,999999999999999999⟩]
private def b51088 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨127,254⟩,⟨3,89⟩,⟨24527,49054⟩]
private def b51089 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨127,254⟩,⟨3,89⟩,⟨49055,999999999999999999⟩]
private def b51090 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨127,254⟩,⟨3,84⟩,⟨49055,98110⟩]
private def b51091 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨127,254⟩,⟨3,84⟩,⟨98111,999999999999999999⟩]
private def b51092 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨127,254⟩,⟨3,79⟩,⟨98111,196222⟩]
private def b51093 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨127,254⟩,⟨3,79⟩,⟨196223,999999999999999999⟩]
private def b51094 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨127,254⟩,⟨3,74⟩,⟨196223,392446⟩]
private def b51095 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨127,254⟩,⟨3,74⟩,⟨392447,999999999999999999⟩]
private def b51096 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨127,254⟩,⟨3,70⟩,⟨392447,784894⟩]
private def b51097 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨127,254⟩,⟨3,70⟩,⟨784895,999999999999999999⟩]
private def b51098 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨127,254⟩,⟨3,66⟩,⟨784895,1569790⟩]
private def b51099 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨127,254⟩,⟨3,66⟩,⟨1569791,999999999999999999⟩]
private def b51100 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨127,254⟩,⟨3,6⟩,⟨1569791,999999999999999999⟩]
private def b51101 : Box := ![⟨127,138⟩,⟨21,21⟩,⟨127,180⟩,⟨3,6⟩,⟨1569791,999999999999999999⟩]
private def b51102 : Box := ![⟨139,152⟩,⟨21,21⟩,⟨127,180⟩,⟨3,6⟩,⟨1569791,999999999999999999⟩]
private def b51103 : Box := ![⟨139,145⟩,⟨21,21⟩,⟨127,180⟩,⟨3,6⟩,⟨1569791,999999999999999999⟩]
private def b51104 : Box := ![⟨139,145⟩,⟨21,21⟩,⟨127,177⟩,⟨3,6⟩,⟨1569791,3139582⟩]
private def b51105 : Box := ![⟨139,145⟩,⟨21,21⟩,⟨127,177⟩,⟨3,6⟩,⟨3139583,999999999999999999⟩]
private def b51106 : Box := ![⟨139,145⟩,⟨21,21⟩,⟨127,177⟩,⟨3,6⟩,⟨3139583,6279166⟩]
private def b51107 : Box := ![⟨139,145⟩,⟨21,21⟩,⟨127,177⟩,⟨3,6⟩,⟨6279167,999999999999999999⟩]
private def b51108 : Box := ![⟨139,145⟩,⟨21,21⟩,⟨127,177⟩,⟨3,6⟩,⟨6279167,12558334⟩]
private def b51109 : Box := ![⟨139,145⟩,⟨21,21⟩,⟨127,177⟩,⟨3,6⟩,⟨12558335,999999999999999999⟩]
private def b51110 : Box := ![⟨139,145⟩,⟨21,21⟩,⟨127,177⟩,⟨3,6⟩,⟨12558335,25116670⟩]
private def b51111 : Box := ![⟨139,145⟩,⟨21,21⟩,⟨127,177⟩,⟨3,6⟩,⟨25116671,999999999999999999⟩]
private def b51112 : Box := ![⟨139,145⟩,⟨21,21⟩,⟨127,177⟩,⟨3,6⟩,⟨25116671,50233342⟩]
private def b51113 : Box := ![⟨139,145⟩,⟨21,21⟩,⟨127,177⟩,⟨3,6⟩,⟨50233343,999999999999999999⟩]
private def b51124 : Box := ![⟨146,152⟩,⟨21,21⟩,⟨127,180⟩,⟨3,6⟩,⟨1569791,999999999999999999⟩]
private def b51125 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨127,254⟩,⟨7,63⟩,⟨1569791,999999999999999999⟩]
private def b51126 : Box := ![⟨127,152⟩,⟨21,21⟩,⟨255,1920000000000000011376⟩,⟨3,614089068825910934849⟩,⟨3065,999999999999999999⟩]
private def b51127 : Box := ![⟨127,138⟩,⟨21,21⟩,⟨255,1920000000000000011376⟩,⟨10,614089068825910934849⟩,⟨5544,999999999999999999⟩]
private def b51128 : Box := ![⟨127,132⟩,⟨21,21⟩,⟨255,1920000000000000011376⟩,⟨10,572017598994343183811⟩,⟨5544,999999999999999999⟩]
private def b51129 : Box := ![⟨127,132⟩,⟨21,21⟩,⟨255,1920000000000000011376⟩,⟨11,572017598994343183811⟩,⟨5590,11180⟩]
private def b51130 : Box := ![⟨127,132⟩,⟨21,21⟩,⟨255,1920000000000000011376⟩,⟨11,572017598994343183811⟩,⟨11181,999999999999999999⟩]
private def b51131 : Box := ![⟨127,132⟩,⟨21,21⟩,⟨255,1920000000000000011376⟩,⟨11,528808832074375366323⟩,⟨11181,22362⟩]
private def b51132 : Box := ![⟨127,132⟩,⟨21,21⟩,⟨255,1920000000000000011376⟩,⟨11,528808832074375366323⟩,⟨22363,999999999999999999⟩]
private def b51133 : Box := ![⟨127,132⟩,⟨21,21⟩,⟨255,1920000000000000011376⟩,⟨11,492201189832341809325⟩,⟨22363,44726⟩]
private def b51134 : Box := ![⟨127,132⟩,⟨21,21⟩,⟨255,1920000000000000011376⟩,⟨11,492201189832341809325⟩,⟨44727,999999999999999999⟩]
private def b51145 : Box := ![⟨133,138⟩,⟨21,21⟩,⟨255,1920000000000000011376⟩,⟨10,572017598994343183811⟩,⟨5544,999999999999999999⟩]
private def b51146 : Box := ![⟨139,152⟩,⟨21,21⟩,⟨255,1920000000000000011376⟩,⟨10,614089068825910934849⟩,⟨5544,999999999999999999⟩]
private def b51147 : Box := ![⟨127,152⟩,⟨22,22⟩,⟨127,1920000000000000011376⟩,⟨3,672141802067946828248⟩,⟨1532,999999999999999999⟩]
private def b51148 : Box := ![⟨153,190⟩,⟨21,22⟩,⟨127,1920000000000000011376⟩,⟨3,718295185477505923800⟩,⟨1532,999999999999999999⟩]
private def b51149 : Box := ![⟨127,190⟩,⟨23,24⟩,⟨63,1920000000000000011376⟩,⟨1,718295185477505923801⟩,⟨959,999999999999999999⟩]
private def b51150 : Box := ![⟨127,190⟩,⟨23,24⟩,⟨63,126⟩,⟨1,718295185477505923801⟩,⟨2718,999999999999999999⟩]
private def b51151 : Box := ![⟨127,152⟩,⟨23,24⟩,⟨63,126⟩,⟨1,79⟩,⟨2731,999999999999999999⟩]
private def b51152 : Box := ![⟨127,152⟩,⟨23,24⟩,⟨63,84⟩,⟨1,73⟩,⟨2734,999999999999999999⟩]
private def b51153 : Box := ![⟨127,138⟩,⟨23,24⟩,⟨63,84⟩,⟨1,60⟩,⟨2742,999999999999999999⟩]
private def b51164 : Box := ![⟨139,152⟩,⟨23,24⟩,⟨63,84⟩,⟨1,60⟩,⟨2742,999999999999999999⟩]
private def b51165 : Box := ![⟨127,152⟩,⟨23,24⟩,⟨85,126⟩,⟨1,73⟩,⟨2734,999999999999999999⟩]
private def b51166 : Box := ![⟨153,190⟩,⟨23,24⟩,⟨63,126⟩,⟨1,79⟩,⟨2731,999999999999999999⟩]
private def b51167 : Box := ![⟨127,190⟩,⟨23,24⟩,⟨127,1920000000000000011376⟩,⟨1,718295185477505923801⟩,⟨2718,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨127,190⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨1,799016681299385430602⟩,⟨479,999999999999999999⟩] := by
  have e50922 : Deny 5 13 b50922 := by
    apply closeAction rule_sound _ _ 64 [0x577]
    decide +kernel
  have e50924 : Deny 5 13 b50924 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
  have e50926 : Deny 5 13 b50926 := by
    apply closeAction rule_sound _ _ 64 [0x15e37095dd5dc38c78c98d5dc42e32231e3]
    decide +kernel
  have e50937 : Deny 5 13 b50937 := by
    apply closeAction rule_sound _ _ 64 [0x15e37]
    decide +kernel
  have e50925 : Deny 5 13 b50925 :=
    branchAction rule_sound _ _ 2
      0x278 b50925 b50926 b50937 (by decide +kernel) e50926 e50937
  have e50923 : Deny 5 13 b50923 :=
    branchAction rule_sound _ _ 2
      0x2a3 b50923 b50924 b50925 (by decide +kernel) e50924 e50925
  have e50921 : Deny 5 13 b50921 :=
    branchAction rule_sound _ _ 2
      0x2e3 b50921 b50922 b50923 (by decide +kernel) e50922 e50923
  have e50938 : Deny 5 13 b50938 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e50920 : Deny 5 13 b50920 :=
    branchAction rule_sound _ _ 2
      0x1e3 b50920 b50921 b50938 (by decide +kernel) e50921 e50938
  have e50939 : Deny 5 13 b50939 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e50919 : Deny 5 13 b50919 :=
    branchAction rule_sound _ _ 1
      0x9 b50919 b50920 b50939 (by decide +kernel) e50920 e50939
  have e50940 : Deny 5 13 b50940 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e50918 : Deny 5 13 b50918 :=
    branchAction rule_sound _ _ 2
      0x223 b50918 b50919 b50940 (by decide +kernel) e50919 e50940
  have e50943 : Deny 5 13 b50943 := by
    apply closeAction rule_sound _ _ 64 [0x562]
    decide +kernel
  have e50947 : Deny 5 13 b50947 := by
    apply closeAction rule_sound _ _ 64 [0x1d7552a22952a3]
    decide +kernel
  have e50957 : Deny 5 13 b50957 := by
    apply closeAction rule_sound _ _ 64 [0x1de37da3]
    decide +kernel
  have e50959 : Deny 5 13 b50959 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
  have e50960 : Deny 5 13 b50960 := by
    apply closeAction rule_sound _ _ 64 [0x1d743e15e07e15e0954be0ae0a]
    decide +kernel
  have e50958 : Deny 5 13 b50958 :=
    branchAction rule_sound _ _ 3
      0xae23 b50958 b50959 b50960 (by decide +kernel) e50959 e50960
  have e50956 : Deny 5 13 b50956 :=
    branchAction rule_sound _ _ 3
      0x8e23 b50956 b50957 b50958 (by decide +kernel) e50957 e50958
  have e50972 : Deny 5 13 b50972 := by
    apply closeAction rule_sound _ _ 64 [0x75d54a2952a3]
    decide +kernel
  have e50979 : Deny 5 13 b50979 := by
    apply closeAction rule_sound _ _ 64 [0x83e231f80f80e31e3243e23087e36223]
    decide +kernel
  have e50971 : Deny 5 13 b50971 :=
    branchAction rule_sound _ _ 1
      0xb b50971 b50972 b50979 (by decide +kernel) e50972 e50979
  have e50955 : Deny 5 13 b50955 :=
    branchAction rule_sound _ _ 2
      0x1e3 b50955 b50956 b50971 (by decide +kernel) e50956 e50971
  have e50992 : Deny 5 13 b50992 := by
    apply closeAction rule_sound _ _ 64 [0x1d7552a22952a3]
    decide +kernel
  have e51000 : Deny 5 13 b51000 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3087e36]
    decide +kernel
  have e51003 : Deny 5 13 b51003 := by
    apply closeAction rule_sound _ _ 64 [0x83e03e232788c7e03e03e231c38c98c9]
    decide +kernel
  have e50999 : Deny 5 13 b50999 :=
    branchAction rule_sound _ _ 2
      0x223 b50999 b51000 b51003 (by decide +kernel) e51000 e51003
  have e50991 : Deny 5 13 b50991 :=
    branchAction rule_sound _ _ 2
      0x2e3 b50991 b50992 b50999 (by decide +kernel) e50992 e50999
  have e51016 : Deny 5 13 b51016 := by
    apply closeAction rule_sound _ _ 64 [0x1d7552a22952a3]
    decide +kernel
  have e51024 : Deny 5 13 b51024 := by
    apply closeAction rule_sound _ _ 64 [0x1d755e0ae0ae2354ae23]
    decide +kernel
  have e51031 : Deny 5 13 b51031 := by
    apply closeAction rule_sound _ _ 64 [0xf88c3e232780f8be30f8be32788c7]
    decide +kernel
  have e51023 : Deny 5 13 b51023 :=
    branchAction rule_sound _ _ 2
      0x263 b51023 b51024 b51031 (by decide +kernel) e51024 e51031
  have e51015 : Deny 5 13 b51015 :=
    branchAction rule_sound _ _ 1
      0xb b51015 b51016 b51023 (by decide +kernel) e51016 e51023
  have e51038 : Deny 5 13 b51038 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e51014 : Deny 5 13 b51014 :=
    branchAction rule_sound _ _ 1
      0x8 b51014 b51015 b51038 (by decide +kernel) e51015 e51038
  have e50990 : Deny 5 13 b50990 :=
    branchAction rule_sound _ _ 1
      0x7 b50990 b50991 b51014 (by decide +kernel) e50991 e51014
  have e50954 : Deny 5 13 b50954 :=
    branchAction rule_sound _ _ 2
      0x263 b50954 b50955 b50990 (by decide +kernel) e50955 e50990
  have e50946 : Deny 5 13 b50946 :=
    branchAction rule_sound _ _ 2
      0x2e3 b50946 b50947 b50954 (by decide +kernel) e50947 e50954
  have e51042 : Deny 5 13 b51042 := by
    apply closeAction rule_sound _ _ 64 [0x9d54ae152a31e3]
    decide +kernel
  have e51050 : Deny 5 13 b51050 := by
    apply closeAction rule_sound _ _ 64 [0x3e230f88c9e03e231c3e230f88c7e23263]
    decide +kernel
  have e51059 : Deny 5 13 b51059 := by
    apply closeAction rule_sound _ _ 64 [0x820f88c7e23278]
    decide +kernel
  have e51049 : Deny 5 13 b51049 :=
    branchAction rule_sound _ _ 2
      0x1e3 b51049 b51050 b51059 (by decide +kernel) e51050 e51059
  have e51041 : Deny 5 13 b51041 :=
    branchAction rule_sound _ _ 3
      0xbe23 b51041 b51042 b51049 (by decide +kernel) e51042 e51049
  have e51064 : Deny 5 13 b51064 := by
    apply closeAction rule_sound _ _ 64 [0x20820f80f88c9e231f88c9e231f8]
    decide +kernel
  have e51040 : Deny 5 13 b51040 :=
    branchAction rule_sound _ _ 2
      0x263 b51040 b51041 b51064 (by decide +kernel) e51041 e51064
  have e51073 : Deny 5 13 b51073 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e51039 : Deny 5 13 b51039 :=
    branchAction rule_sound _ _ 2
      0x238 b51039 b51040 b51073 (by decide +kernel) e51040 e51073
  have e50945 : Deny 5 13 b50945 :=
    branchAction rule_sound _ _ 2
      0x1e3 b50945 b50946 b51039 (by decide +kernel) e50946 e51039
  have e51077 : Deny 5 13 b51077 := by
    apply closeAction rule_sound _ _ 64 [0x9d278be3]
    decide +kernel
  have e51082 : Deny 5 13 b51082 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e51084 : Deny 5 13 b51084 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e51086 : Deny 5 13 b51086 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e51088 : Deny 5 13 b51088 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e51090 : Deny 5 13 b51090 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e51092 : Deny 5 13 b51092 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e51094 : Deny 5 13 b51094 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e51096 : Deny 5 13 b51096 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e51098 : Deny 5 13 b51098 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e51101 : Deny 5 13 b51101 := by
    apply closeAction rule_sound _ _ 64 [0x2be2]
    decide +kernel
  have e51104 : Deny 5 13 b51104 := by
    apply closeAction rule_sound _ _ 64 [0x14]
    decide +kernel
  have e51106 : Deny 5 13 b51106 := by
    apply closeAction rule_sound _ _ 64 [0x14]
    decide +kernel
  have e51108 : Deny 5 13 b51108 := by
    apply closeAction rule_sound _ _ 64 [0x14]
    decide +kernel
  have e51110 : Deny 5 13 b51110 := by
    apply closeAction rule_sound _ _ 64 [0x14]
    decide +kernel
  have e51112 : Deny 5 13 b51112 := by
    apply closeAction rule_sound _ _ 64 [0x14]
    decide +kernel
  have e51113 : Deny 5 13 b51113 := by
    apply closeAction rule_sound _ _ 64 [0x1dbc308724188b50b50b]
    decide +kernel
  have e51111 : Deny 5 13 b51111 :=
    branchAction rule_sound _ _ 1
      0xb b51111 b51112 b51113 (by decide +kernel) e51112 e51113
  have e51109 : Deny 5 13 b51109 :=
    branchAction rule_sound _ _ 1
      0xb b51109 b51110 b51111 (by decide +kernel) e51110 e51111
  have e51107 : Deny 5 13 b51107 :=
    branchAction rule_sound _ _ 1
      0xb b51107 b51108 b51109 (by decide +kernel) e51108 e51109
  have e51105 : Deny 5 13 b51105 :=
    branchAction rule_sound _ _ 1
      0xb b51105 b51106 b51107 (by decide +kernel) e51106 e51107
  have e51103 : Deny 5 13 b51103 :=
    branchAction rule_sound _ _ 2
      0x2e2 b51103 b51104 b51105 (by decide +kernel) e51104 e51105
  have e51124 : Deny 5 13 b51124 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e51102 : Deny 5 13 b51102 :=
    branchAction rule_sound _ _ 1
      0x7 b51102 b51103 b51124 (by decide +kernel) e51103 e51124
  have e51100 : Deny 5 13 b51100 :=
    branchAction rule_sound _ _ 2
      0x1e2 b51100 b51101 b51102 (by decide +kernel) e51101 e51102
  have e51125 : Deny 5 13 b51125 := by
    apply closeAction rule_sound _ _ 64 [0x1d]
    decide +kernel
  have e51099 : Deny 5 13 b51099 :=
    branchAction rule_sound _ _ 2
      0x2a3 b51099 b51100 b51125 (by decide +kernel) e51100 e51125
  have e51097 : Deny 5 13 b51097 :=
    branchAction rule_sound _ _ 2
      0x2e3 b51097 b51098 b51099 (by decide +kernel) e51098 e51099
  have e51095 : Deny 5 13 b51095 :=
    branchAction rule_sound _ _ 2
      0x2e3 b51095 b51096 b51097 (by decide +kernel) e51096 e51097
  have e51093 : Deny 5 13 b51093 :=
    branchAction rule_sound _ _ 2
      0x2e3 b51093 b51094 b51095 (by decide +kernel) e51094 e51095
  have e51091 : Deny 5 13 b51091 :=
    branchAction rule_sound _ _ 2
      0x2e3 b51091 b51092 b51093 (by decide +kernel) e51092 e51093
  have e51089 : Deny 5 13 b51089 :=
    branchAction rule_sound _ _ 2
      0x2e3 b51089 b51090 b51091 (by decide +kernel) e51090 e51091
  have e51087 : Deny 5 13 b51087 :=
    branchAction rule_sound _ _ 2
      0x2e3 b51087 b51088 b51089 (by decide +kernel) e51088 e51089
  have e51085 : Deny 5 13 b51085 :=
    branchAction rule_sound _ _ 2
      0x2e3 b51085 b51086 b51087 (by decide +kernel) e51086 e51087
  have e51083 : Deny 5 13 b51083 :=
    branchAction rule_sound _ _ 2
      0x2e3 b51083 b51084 b51085 (by decide +kernel) e51084 e51085
  have e51081 : Deny 5 13 b51081 :=
    branchAction rule_sound _ _ 2
      0x2e3 b51081 b51082 b51083 (by decide +kernel) e51082 e51083
  have e51129 : Deny 5 13 b51129 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e51131 : Deny 5 13 b51131 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e51133 : Deny 5 13 b51133 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e51134 : Deny 5 13 b51134 := by
    apply closeAction rule_sound _ _ 64 [0x272f8c9e2f72325dbe22a372f8cb8dcbe32e3]
    decide +kernel
  have e51132 : Deny 5 13 b51132 :=
    branchAction rule_sound _ _ 2
      0x2e3 b51132 b51133 b51134 (by decide +kernel) e51133 e51134
  have e51130 : Deny 5 13 b51130 :=
    branchAction rule_sound _ _ 2
      0x2e3 b51130 b51131 b51132 (by decide +kernel) e51131 e51132
  have e51128 : Deny 5 13 b51128 :=
    branchAction rule_sound _ _ 3
      0xbe2f b51128 b51129 b51130 (by decide +kernel) e51129 e51130
  have e51145 : Deny 5 13 b51145 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e51127 : Deny 5 13 b51127 :=
    branchAction rule_sound _ _ 2
      0x1e3 b51127 b51128 b51145 (by decide +kernel) e51128 e51145
  have e51146 : Deny 5 13 b51146 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e51126 : Deny 5 13 b51126 :=
    branchAction rule_sound _ _ 3
      0x7e2f b51126 b51127 b51146 (by decide +kernel) e51127 e51146
  have e51080 : Deny 5 13 b51080 :=
    branchAction rule_sound _ _ 2
      0x263 b51080 b51081 b51126 (by decide +kernel) e51081 e51126
  have e51076 : Deny 5 13 b51076 :=
    branchAction rule_sound _ _ 2
      0x2e3 b51076 b51077 b51080 (by decide +kernel) e51077 e51080
  have e51147 : Deny 5 13 b51147 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e51075 : Deny 5 13 b51075 :=
    branchAction rule_sound _ _ 2
      0x223 b51075 b51076 b51147 (by decide +kernel) e51076 e51147
  have e51148 : Deny 5 13 b51148 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e51074 : Deny 5 13 b51074 :=
    branchAction rule_sound _ _ 2
      0x1f8 b51074 b51075 b51148 (by decide +kernel) e51075 e51148
  have e50944 : Deny 5 13 b50944 :=
    branchAction rule_sound _ _ 1
      0x9 b50944 b50945 b51074 (by decide +kernel) e50945 e51074
  have e50942 : Deny 5 13 b50942 :=
    branchAction rule_sound _ _ 2
      0x2a3 b50942 b50943 b50944 (by decide +kernel) e50943 e50944
  have e51153 : Deny 5 13 b51153 := by
    apply closeAction rule_sound _ _ 64 [0x2083e231f88c3e03e231f88c9e152b88c8e23]
    decide +kernel
  have e51164 : Deny 5 13 b51164 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e51152 : Deny 5 13 b51152 :=
    branchAction rule_sound _ _ 3
      0x7e23 b51152 b51153 b51164 (by decide +kernel) e51153 e51164
  have e51165 : Deny 5 13 b51165 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e51151 : Deny 5 13 b51151 :=
    branchAction rule_sound _ _ 3
      0x9e23 b51151 b51152 b51165 (by decide +kernel) e51152 e51165
  have e51166 : Deny 5 13 b51166 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e51150 : Deny 5 13 b51150 :=
    branchAction rule_sound _ _ 3
      0x7e23 b51150 b51151 b51166 (by decide +kernel) e51151 e51166
  have e51167 : Deny 5 13 b51167 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e51149 : Deny 5 13 b51149 :=
    branchAction rule_sound _ _ 2
      0x278 b51149 b51150 b51167 (by decide +kernel) e51150 e51167
  have e50941 : Deny 5 13 b50941 :=
    branchAction rule_sound _ _ 2
      0x223 b50941 b50942 b51149 (by decide +kernel) e50942 e51149
  have e50917 : Deny 5 13 b50917 :=
    branchAction rule_sound _ _ 1
      0xb b50917 b50918 b50941 (by decide +kernel) e50918 e50941
  exact e50917
end OMA.Blocks5_13_245212.S50917
