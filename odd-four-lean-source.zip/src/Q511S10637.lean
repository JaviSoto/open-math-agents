import FastReplay245212
import SparseDigit245212
import FastRound245212
import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S10637
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b10637 : Box := ![⟨15,17⟩,⟨63,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨1,1445853658536585374450⟩,⟨207,414⟩]
private def b10638 : Box := ![⟨15,17⟩,⟨63,126⟩,⟨31,1920000000000000011376⟩,⟨1,1445853658536585374443⟩,⟨207,414⟩]
private def b10639 : Box := ![⟨15,17⟩,⟨63,126⟩,⟨31,1920000000000000011376⟩,⟨1,2⟩,⟨207,414⟩]
private def b10640 : Box := ![⟨15,17⟩,⟨63,126⟩,⟨31,1920000000000000011376⟩,⟨3,864390243902439029565⟩,⟨207,414⟩]
private def b10641 : Box := ![⟨15,17⟩,⟨63,126⟩,⟨31,1920000000000000011376⟩,⟨3,6⟩,⟨207,414⟩]
private def b10642 : Box := ![⟨15,17⟩,⟨63,126⟩,⟨31,1920000000000000011376⟩,⟨7,864390243902439029565⟩,⟨207,414⟩]
private def b10643 : Box := ![⟨15,15⟩,⟨63,126⟩,⟨31,1920000000000000011376⟩,⟨7,864390243902439029565⟩,⟨207,414⟩]
private def b10652 : Box := ![⟨16,17⟩,⟨63,126⟩,⟨31,1920000000000000011376⟩,⟨7,864390243902439029565⟩,⟨207,414⟩]
private def b10653 : Box := ![⟨16,17⟩,⟨63,126⟩,⟨31,62⟩,⟨7,864390243902439029565⟩,⟨207,414⟩]
private def b10654 : Box := ![⟨16,17⟩,⟨63,126⟩,⟨31,62⟩,⟨7,13⟩,⟨207,414⟩]
private def b10655 : Box := ![⟨16,17⟩,⟨63,126⟩,⟨31,62⟩,⟨7,9⟩,⟨207,414⟩]
private def b10656 : Box := ![⟨16,17⟩,⟨63,126⟩,⟨31,41⟩,⟨7,9⟩,⟨207,414⟩]
private def b10657 : Box := ![⟨16,17⟩,⟨63,113⟩,⟨31,41⟩,⟨7,9⟩,⟨207,276⟩]
private def b10672 : Box := ![⟨16,17⟩,⟨63,113⟩,⟨31,41⟩,⟨7,9⟩,⟨277,414⟩]
private def b10673 : Box := ![⟨16,16⟩,⟨63,113⟩,⟨31,41⟩,⟨7,9⟩,⟨277,414⟩]
private def b10674 : Box := ![⟨17,17⟩,⟨63,113⟩,⟨31,41⟩,⟨7,9⟩,⟨277,414⟩]
private def b10675 : Box := ![⟨17,17⟩,⟨63,80⟩,⟨31,41⟩,⟨7,9⟩,⟨277,414⟩]
private def b10678 : Box := ![⟨17,17⟩,⟨81,113⟩,⟨31,41⟩,⟨7,9⟩,⟨277,414⟩]
private def b10691 : Box := ![⟨16,17⟩,⟨63,126⟩,⟨42,62⟩,⟨7,9⟩,⟨207,414⟩]
private def b10692 : Box := ![⟨16,17⟩,⟨63,126⟩,⟨31,62⟩,⟨10,13⟩,⟨207,414⟩]
private def b10693 : Box := ![⟨16,17⟩,⟨63,126⟩,⟨31,62⟩,⟨14,72⟩,⟨207,414⟩]
private def b10694 : Box := ![⟨16,17⟩,⟨63,126⟩,⟨63,1920000000000000011376⟩,⟨7,864390243902439029565⟩,⟨207,414⟩]
private def b10695 : Box := ![⟨16,17⟩,⟨63,126⟩,⟨63,1920000000000000011376⟩,⟨7,864390243902439029565⟩,⟨207,276⟩]
private def b10710 : Box := ![⟨16,17⟩,⟨63,126⟩,⟨63,1920000000000000011376⟩,⟨7,864390243902439029565⟩,⟨277,414⟩]
private def b10711 : Box := ![⟨16,17⟩,⟨63,84⟩,⟨63,1920000000000000011376⟩,⟨7,819421965317919080050⟩,⟨277,414⟩]
private def b10712 : Box := ![⟨16,16⟩,⟨63,84⟩,⟨63,1920000000000000011376⟩,⟨7,819421965317919080038⟩,⟨277,414⟩]
private def b10721 : Box := ![⟨17,17⟩,⟨63,84⟩,⟨63,1920000000000000011376⟩,⟨7,819421965317919080038⟩,⟨277,414⟩]
private def b10728 : Box := ![⟨16,17⟩,⟨85,126⟩,⟨63,1920000000000000011376⟩,⟨7,819421965317919080050⟩,⟨277,414⟩]
private def b10737 : Box := ![⟨15,17⟩,⟨127,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨1,1445853658536585374443⟩,⟨207,414⟩]
private def b10738 : Box := ![⟨15,17⟩,⟨127,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨1,2⟩,⟨207,414⟩]
private def b10739 : Box := ![⟨15,17⟩,⟨127,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨3,1445853658536585374443⟩,⟨207,414⟩]
private def b10740 : Box := ![⟨15,15⟩,⟨127,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨3,1445853658536585374443⟩,⟨207,414⟩]
private def b10741 : Box := ![⟨15,15⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨3,1445853658536585374443⟩,⟨207,414⟩]
private def b10754 : Box := ![⟨15,15⟩,⟨127,1920000000000000011376⟩,⟨63,1920000000000000011376⟩,⟨3,1445853658536585374443⟩,⟨207,414⟩]
private def b10755 : Box := ![⟨15,15⟩,⟨127,1920000000000000011376⟩,⟨63,1920000000000000011376⟩,⟨3,6⟩,⟨207,414⟩]
private def b10756 : Box := ![⟨15,15⟩,⟨127,1920000000000000011376⟩,⟨63,1920000000000000011376⟩,⟨7,1445853658536585374443⟩,⟨207,414⟩]
private def b10757 : Box := ![⟨15,15⟩,⟨127,1920000000000000011376⟩,⟨63,1920000000000000011376⟩,⟨7,1445853658536585374443⟩,⟨207,276⟩]
private def b10766 : Box := ![⟨15,15⟩,⟨127,1920000000000000011376⟩,⟨63,1920000000000000011376⟩,⟨7,1445853658536585374443⟩,⟨277,414⟩]
private def b10779 : Box := ![⟨16,17⟩,⟨127,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨3,1445853658536585374443⟩,⟨207,414⟩]
private def b10780 : Box := ![⟨16,17⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨3,1445853658536585374443⟩,⟨207,414⟩]
private def b10781 : Box := ![⟨16,17⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨3,6⟩,⟨207,414⟩]
private def b10782 : Box := ![⟨16,17⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨7,581463414634146344951⟩,⟨207,414⟩]
private def b10783 : Box := ![⟨16,17⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨7,581463414634146344951⟩,⟨210,278⟩]
private def b10790 : Box := ![⟨16,17⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨7,581463414634146344951⟩,⟨279,414⟩]
private def b10805 : Box := ![⟨16,17⟩,⟨127,1920000000000000011376⟩,⟨63,1920000000000000011376⟩,⟨3,1445853658536585374443⟩,⟨207,414⟩]
private def b10806 : Box := ![⟨16,17⟩,⟨127,254⟩,⟨63,1920000000000000011376⟩,⟨3,1445853658536585374443⟩,⟨289,414⟩]
private def b10821 : Box := ![⟨16,17⟩,⟨255,1920000000000000011376⟩,⟨63,1920000000000000011376⟩,⟨3,1445853658536585374443⟩,⟨289,414⟩]
theorem deny5_11 : Deny 5 11 ![⟨15,17⟩,⟨63,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨1,1445853658536585374450⟩,⟨207,414⟩] := by
  have e10639 : Deny 5 11 b10639 := by
    apply closeAction rule_sound _ _ 64 [0x16]
    decide +kernel
  have e10641 : Deny 5 11 b10641 := by
    apply closeAction rule_sound _ _ 64 [0x5a2]
    decide +kernel
  have e10643 : Deny 5 11 b10643 := by
    apply closeAction rule_sound _ _ 64 [0x72f789bde25e256e36d622b8da3]
    decide +kernel
  have e10657 : Deny 5 11 b10657 := by
    apply closeAction rule_sound _ _ 64 [0x820c9108e03e040c42780c82160a1109e35847844]
    decide +kernel
  have e10673 : Deny 5 11 b10673 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e10675 : Deny 5 11 b10675 := by
    apply closeAction rule_sound _ _ 64 [0x1e58ae36]
    decide +kernel
  have e10678 : Deny 5 11 b10678 := by
    apply closeAction rule_sound _ _ 64 [0x1e582849da12845b8dc40e1109e030f824884b]
    decide +kernel
  have e10674 : Deny 5 11 b10674 :=
    branchAction rule_sound _ _ 1
      0x8 b10674 b10675 b10678 (by decide +kernel) e10675 e10678
  have e10672 : Deny 5 11 b10672 :=
    branchAction rule_sound _ _ 1
      0x7 b10672 b10673 b10674 (by decide +kernel) e10673 e10674
  have e10656 : Deny 5 11 b10656 :=
    branchAction rule_sound _ _ 2
      0x2e1 b10656 b10657 b10672 (by decide +kernel) e10657 e10672
  have e10691 : Deny 5 11 b10691 := by
    apply closeAction rule_sound _ _ 64 [0x16]
    decide +kernel
  have e10655 : Deny 5 11 b10655 :=
    branchAction rule_sound _ _ 1
      0x9 b10655 b10656 b10691 (by decide +kernel) e10656 e10691
  have e10692 : Deny 5 11 b10692 := by
    apply closeAction rule_sound _ _ 64 [0x1e]
    decide +kernel
  have e10654 : Deny 5 11 b10654 :=
    branchAction rule_sound _ _ 1
      0xa b10654 b10655 b10692 (by decide +kernel) e10655 e10692
  have e10693 : Deny 5 11 b10693 := by
    apply closeAction rule_sound _ _ 64 [0x1e]
    decide +kernel
  have e10653 : Deny 5 11 b10653 :=
    branchAction rule_sound _ _ 2
      0x2a3 b10653 b10654 b10693 (by decide +kernel) e10654 e10693
  have e10695 : Deny 5 11 b10695 := by
    apply closeAction rule_sound _ _ 64 [0x9e8845a210ae3709e278bde7962a22a32632078c4]
    decide +kernel
  have e10712 : Deny 5 11 b10712 := by
    apply closeAction rule_sound _ _ 64 [0x72f789bde58a11ee37da3108e23263]
    decide +kernel
  have e10721 : Deny 5 11 b10721 := by
    apply closeAction rule_sound _ _ 64 [0x279e58a88a8c4278]
    decide +kernel
  have e10711 : Deny 5 11 b10711 :=
    branchAction rule_sound _ _ 2
      0x1e3 b10711 b10712 b10721 (by decide +kernel) e10712 e10721
  have e10728 : Deny 5 11 b10728 := by
    apply closeAction rule_sound _ _ 64 [0x82be311e2787895a2287]
    decide +kernel
  have e10710 : Deny 5 11 b10710 :=
    branchAction rule_sound _ _ 2
      0x223 b10710 b10711 b10728 (by decide +kernel) e10711 e10728
  have e10694 : Deny 5 11 b10694 :=
    branchAction rule_sound _ _ 1
      0xb b10694 b10695 b10710 (by decide +kernel) e10695 e10710
  have e10652 : Deny 5 11 b10652 :=
    branchAction rule_sound _ _ 1
      0x9 b10652 b10653 b10694 (by decide +kernel) e10653 e10694
  have e10642 : Deny 5 11 b10642 :=
    branchAction rule_sound _ _ 1
      0x7 b10642 b10643 b10652 (by decide +kernel) e10643 e10652
  have e10640 : Deny 5 11 b10640 :=
    branchAction rule_sound _ _ 1
      0xa b10640 b10641 b10642 (by decide +kernel) e10641 e10642
  have e10638 : Deny 5 11 b10638 :=
    branchAction rule_sound _ _ 2
      0x2a3 b10638 b10639 b10640 (by decide +kernel) e10639 e10640
  have e10738 : Deny 5 11 b10738 := by
    apply closeAction rule_sound _ _ 64 [0x16aa2]
    decide +kernel
  have e10741 : Deny 5 11 b10741 := by
    apply closeAction rule_sound _ _ 64 [0x6ab7ab8c8db58c46ab6ab8c8ade8c85b8daa84a8c42c2aea84ae23]
    decide +kernel
  have e10755 : Deny 5 11 b10755 := by
    apply closeAction rule_sound _ _ 64 [0x16]
    decide +kernel
  have e10757 : Deny 5 11 b10757 := by
    apply closeAction rule_sound _ _ 64 [0x20abaa1109e3779e88a58a8c88c4]
    decide +kernel
  have e10766 : Deny 5 11 b10766 := by
    apply closeAction rule_sound _ _ 64 [0x7967aa849aa2296aa229e7a22962a3223]
    decide +kernel
  have e10756 : Deny 5 11 b10756 :=
    branchAction rule_sound _ _ 1
      0xb b10756 b10757 b10766 (by decide +kernel) e10757 e10766
  have e10754 : Deny 5 11 b10754 :=
    branchAction rule_sound _ _ 1
      0xa b10754 b10755 b10756 (by decide +kernel) e10755 e10756
  have e10740 : Deny 5 11 b10740 :=
    branchAction rule_sound _ _ 1
      0x9 b10740 b10741 b10754 (by decide +kernel) e10741 e10754
  have e10781 : Deny 5 11 b10781 := by
    apply closeAction rule_sound _ _ 64 [0x5abaa1]
    decide +kernel
  have e10783 : Deny 5 11 b10783 := by
    apply closeAction rule_sound _ _ 64 [0x2ac2796e37aa12878c88c4]
    decide +kernel
  have e10790 : Deny 5 11 b10790 := by
    apply closeAction rule_sound _ _ 64 [0x1ee378c46ab8c4278ac27ab7962b87ab8c98c81deae3263223]
    decide +kernel
  have e10782 : Deny 5 11 b10782 :=
    branchAction rule_sound _ _ 2
      0x2f8 b10782 b10783 b10790 (by decide +kernel) e10783 e10790
  have e10780 : Deny 5 11 b10780 :=
    branchAction rule_sound _ _ 2
      0x2a3 b10780 b10781 b10782 (by decide +kernel) e10781 e10782
  have e10806 : Deny 5 11 b10806 := by
    apply closeAction rule_sound _ _ 64 [0x2096e375b77962962a3263116dc42e32232478c4]
    decide +kernel
  have e10821 : Deny 5 11 b10821 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e10805 : Deny 5 11 b10805 :=
    branchAction rule_sound _ _ 2
      0x238 b10805 b10806 b10821 (by decide +kernel) e10806 e10821
  have e10779 : Deny 5 11 b10779 :=
    branchAction rule_sound _ _ 1
      0x9 b10779 b10780 b10805 (by decide +kernel) e10780 e10805
  have e10739 : Deny 5 11 b10739 :=
    branchAction rule_sound _ _ 1
      0x7 b10739 b10740 b10779 (by decide +kernel) e10740 e10779
  have e10737 : Deny 5 11 b10737 :=
    branchAction rule_sound _ _ 1
      0xa b10737 b10738 b10739 (by decide +kernel) e10738 e10739
  have e10637 : Deny 5 11 b10637 :=
    branchAction rule_sound _ _ 2
      0x223 b10637 b10638 b10737 (by decide +kernel) e10638 e10737
  exact e10637
end OMA.Blocks5_11_245212.S10637
