import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S46124
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b46124 : Box := ![⟨95,190⟩,⟨18,20⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711620⟩,⟨239,478⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨18,20⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711620⟩,⟨239,478⟩] := by
  have e46124 : Deny 5 13 b46124 := by
    apply closeAction rule_sound _ _ 64 [0x72f8c476f8c4278bdd755755083109e15087e368881025438878882e2107e15e222222a21e22952a22a32442e31d588a,0xbe326f75d54a54a75d2d529d0a210ae3688708811d7552a210ae1d215283e03e221c3e090888878842c22221e22a3263,0x211d2788dd2788d588ae1cbdd]
    decide +kernel
  exact e46124
end OMA.Blocks5_13_245212.S46124
