import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S22339
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b22339 : Box := ![⟨31,46⟩,⟨31,1920000000000000011376⟩,⟨15,1920000000000000011376⟩,⟨3,1920000000000000011376⟩,⟨59,77⟩]
theorem deny5_13 : Deny 5 13 ![⟨31,46⟩,⟨31,1920000000000000011376⟩,⟨15,1920000000000000011376⟩,⟨3,1920000000000000011376⟩,⟨59,77⟩] := by
  have e22339 : Deny 5 13 b22339 := by
    apply closeAction rule_sound _ _ 64 [0xc72622221e2238dc2097e370c7247e375f8dd7e370c8257e370c80c90c32091c40820832091f710b20988a887888dc4,0x25f8ddfe020825f8dd7e37]
    decide +kernel
  exact e22339
end OMA.Blocks5_13_245212.S22339
