import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S63279
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b63279 : Box := ![⟨127,152⟩,⟨31,35⟩,⟨12,14⟩,⟨5,51⟩,⟨479,958⟩]
private def b63280 : Box := ![⟨127,152⟩,⟨31,35⟩,⟨12,14⟩,⟨5,45⟩,⟨479,638⟩]
private def b63289 : Box := ![⟨127,152⟩,⟨31,35⟩,⟨12,14⟩,⟨5,45⟩,⟨639,958⟩]
private theorem e63280 : Deny 5 13 b63280 := by
    apply closeAction rule_sound _ _ 64 [0x7c32780e72439c38c79c89e3]
    decide +kernel
private theorem e63289 : Deny 5 13 b63289 := by
    apply closeAction rule_sound _ _ 64 [0x39c38c70f89e32439c3e368c79e3223]
    decide +kernel
private theorem e63279 : Deny 5 13 b63279 :=
    branchAction rule_sound _ _ 2
      0x2e3 b63279 b63280 b63289 (by decide +kernel) e63280 e63289
theorem deny5_13 : Deny 5 13 ![⟨127,152⟩,⟨31,35⟩,⟨12,14⟩,⟨5,51⟩,⟨479,958⟩] := by
  exact e63279
end OMA.Blocks5_13_245212.S63279
