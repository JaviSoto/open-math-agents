import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S1427
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b1427 : Box := ![⟨11,22⟩,⟨7,14⟩,⟨3,1920000000000000011376⟩,⟨1,1920000000000000011376⟩,⟨17,23⟩]
private def b1428 : Box := ![⟨11,22⟩,⟨7,14⟩,⟨3,1920000000000000011376⟩,⟨1,2⟩,⟨17,23⟩]
private def b1487 : Box := ![⟨11,22⟩,⟨7,14⟩,⟨3,1920000000000000011376⟩,⟨3,1740114722753346090653⟩,⟨17,23⟩]
private def b1488 : Box := ![⟨11,22⟩,⟨7,14⟩,⟨3,6⟩,⟨3,1740114722753346090653⟩,⟨17,23⟩]
private def b1497 : Box := ![⟨11,22⟩,⟨7,14⟩,⟨7,1920000000000000011376⟩,⟨3,1740114722753346090653⟩,⟨17,23⟩]
private def b1498 : Box := ![⟨11,14⟩,⟨7,14⟩,⟨7,1920000000000000011376⟩,⟨3,1740114722753346090653⟩,⟨17,23⟩]
private def b1617 : Box := ![⟨15,22⟩,⟨7,14⟩,⟨7,1920000000000000011376⟩,⟨3,1740114722753346090653⟩,⟨17,23⟩]
theorem deny5_13 : Deny 5 13 ![⟨11,22⟩,⟨7,14⟩,⟨3,1920000000000000011376⟩,⟨1,1920000000000000011376⟩,⟨17,23⟩] := by
  have e1428 : Deny 5 13 b1428 := by
    apply closeAction rule_sound _ _ 64 [0x8878882c30c90f8da22221c3088087088087da22830b8db51f72430f8da21c22021f7da220b0f6d62087e37db5887da2,0xc32421c22021f7db51020e21c32430c9da22040832760c3]
    decide +kernel
  have e1488 : Deny 5 13 b1488 := by
    apply closeAction rule_sound _ _ 64 [0xc38c70f88c80c40f8df68c4238de31e3]
    decide +kernel
  have e1498 : Deny 5 13 b1498 := by
    apply closeAction rule_sound _ _ 64 [0xc9c88a0e22822231020e2282737d8772f88a8c82c3bedb222838c91c38c98c80c38870e22032431021f8df688888a2e3,0xe370838c9082bc38c98c70e32632231022c30e21e22870c38c78c908388a73270a737da22a32231022c3bed88a0e325c,0xbe2283df68c98c872f72325cdef88a737da3277088df68c70c21f7db588a0c21f7da325cdf68c8df68c40820e22a2108,0xaf70388abe32430f78c88c971cbe22af723243]
    decide +kernel
  have e1617 : Deny 5 13 b1617 := by
    apply closeAction rule_sound _ _ 64 [0x8c8082083887888dc3dc32091022e2283de21038841f8dc38880c98870f8dc38870e22032430f8de22032621e222228b,0x87df688a8c88c40820e3276107e37d820e2108e370820e21f70e3263108e020e2108e0388888a8c70f80e32038c78c9,0x29cc9c28288a8c70e3243df688a8c873272228388a73270a0a22a31c38c90f7da229cdf68c88c70c22021e3243087088,0x2420e21f70c90c3de21e22030f72090c3df68870f7da2203dc9da21e228208388a887dc30e31e32430c90e21e22820e2,0x2083887888dc20f70c72770af8820e22b7be21f70e32632231c20e32770e32030f7da32231e3]
    decide +kernel
  have e1497 : Deny 5 13 b1497 :=
    branchAction rule_sound _ _ 1
      0x7 b1497 b1498 b1617 (by decide +kernel) e1498 e1617
  have e1487 : Deny 5 13 b1487 :=
    branchAction rule_sound _ _ 1
      0x9 b1487 b1488 b1497 (by decide +kernel) e1488 e1497
  have e1427 : Deny 5 13 b1427 :=
    branchAction rule_sound _ _ 2
      0x2a3 b1427 b1428 b1487 (by decide +kernel) e1428 e1487
  exact e1427
end OMA.Blocks5_13_245212.S1427
