import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S49337
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b49337 : Box := ![⟨95,190⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨1,900178041543026711630⟩,⟨239,478⟩]
private def b49338 : Box := ![⟨95,190⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨1,2⟩,⟨239,478⟩]
private def b49339 : Box := ![⟨95,190⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨3,900178041543026711623⟩,⟨239,478⟩]
private def b49340 : Box := ![⟨95,190⟩,⟨21,24⟩,⟨31,1920000000000000011376⟩,⟨3,900178041543026711623⟩,⟨239,478⟩]
private def b49341 : Box := ![⟨95,190⟩,⟨21,24⟩,⟨31,62⟩,⟨3,900178041543026711621⟩,⟨239,478⟩]
private def b49342 : Box := ![⟨95,126⟩,⟨21,24⟩,⟨31,62⟩,⟨3,77⟩,⟨239,478⟩]
private def b49343 : Box := ![⟨95,126⟩,⟨21,24⟩,⟨31,62⟩,⟨3,64⟩,⟨239,318⟩]
private def b49344 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨31,62⟩,⟨3,64⟩,⟨239,317⟩]
private def b49345 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨31,41⟩,⟨3,64⟩,⟨239,317⟩]
private def b49346 : Box := ![⟨95,108⟩,⟨21,22⟩,⟨31,41⟩,⟨3,54⟩,⟨239,317⟩]
private def b49347 : Box := ![⟨95,108⟩,⟨21,22⟩,⟨31,41⟩,⟨3,50⟩,⟨239,272⟩]
private def b49356 : Box := ![⟨95,108⟩,⟨21,22⟩,⟨31,41⟩,⟨3,50⟩,⟨273,317⟩]
private def b49365 : Box := ![⟨109,126⟩,⟨21,22⟩,⟨31,41⟩,⟨3,54⟩,⟨239,317⟩]
private def b49370 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨42,62⟩,⟨3,64⟩,⟨239,317⟩]
private def b49381 : Box := ![⟨95,126⟩,⟨23,24⟩,⟨31,62⟩,⟨3,64⟩,⟨239,317⟩]
private def b49390 : Box := ![⟨95,126⟩,⟨21,24⟩,⟨31,62⟩,⟨3,64⟩,⟨319,478⟩]
private def b49391 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨31,62⟩,⟨3,61⟩,⟨319,478⟩]
private def b49392 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨31,41⟩,⟨3,61⟩,⟨319,478⟩]
private def b49393 : Box := ![⟨95,108⟩,⟨21,22⟩,⟨31,41⟩,⟨3,51⟩,⟨319,478⟩]
private def b49394 : Box := ![⟨95,108⟩,⟨21,22⟩,⟨31,41⟩,⟨3,48⟩,⟨319,382⟩]
private def b49395 : Box := ![⟨95,108⟩,⟨21,22⟩,⟨31,41⟩,⟨3,6⟩,⟨331,379⟩]
private def b49400 : Box := ![⟨95,108⟩,⟨21,22⟩,⟨31,41⟩,⟨7,47⟩,⟨331,379⟩]
private def b49407 : Box := ![⟨95,108⟩,⟨21,22⟩,⟨31,41⟩,⟨3,48⟩,⟨383,478⟩]
private def b49412 : Box := ![⟨109,126⟩,⟨21,22⟩,⟨31,41⟩,⟨3,51⟩,⟨319,478⟩]
private def b49413 : Box := ![⟨109,126⟩,⟨21,22⟩,⟨31,41⟩,⟨3,51⟩,⟨319,382⟩]
private def b49414 : Box := ![⟨109,126⟩,⟨21,22⟩,⟨31,41⟩,⟨3,6⟩,⟨331,379⟩]
private def b49419 : Box := ![⟨109,126⟩,⟨21,22⟩,⟨31,41⟩,⟨7,51⟩,⟨331,379⟩]
private def b49428 : Box := ![⟨109,126⟩,⟨21,22⟩,⟨31,41⟩,⟨3,51⟩,⟨383,478⟩]
private def b49429 : Box := ![⟨109,126⟩,⟨21,22⟩,⟨31,35⟩,⟨3,49⟩,⟨383,467⟩]
private def b49432 : Box := ![⟨109,126⟩,⟨21,22⟩,⟨36,41⟩,⟨3,49⟩,⟨383,467⟩]
private def b49441 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨42,62⟩,⟨3,61⟩,⟨319,478⟩]
private def b49442 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨42,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b49443 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨42,62⟩,⟨7,61⟩,⟨319,478⟩]
private def b49444 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨42,62⟩,⟨7,13⟩,⟨319,478⟩]
private def b49445 : Box := ![⟨95,126⟩,⟨21,21⟩,⟨42,62⟩,⟨7,13⟩,⟨319,478⟩]
private def b49446 : Box := ![⟨95,108⟩,⟨21,21⟩,⟨42,62⟩,⟨7,13⟩,⟨319,478⟩]
private def b49447 : Box := ![⟨95,108⟩,⟨21,21⟩,⟨42,62⟩,⟨7,13⟩,⟨319,382⟩]
private def b49454 : Box := ![⟨95,108⟩,⟨21,21⟩,⟨42,62⟩,⟨7,13⟩,⟨383,478⟩]
private def b49461 : Box := ![⟨109,126⟩,⟨21,21⟩,⟨42,62⟩,⟨7,13⟩,⟨319,478⟩]
private def b49472 : Box := ![⟨95,126⟩,⟨22,22⟩,⟨42,62⟩,⟨7,13⟩,⟨319,478⟩]
private def b49473 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨42,62⟩,⟨14,61⟩,⟨319,478⟩]
private def b49474 : Box := ![⟨95,126⟩,⟨23,24⟩,⟨31,62⟩,⟨3,61⟩,⟨319,478⟩]
private def b49475 : Box := ![⟨95,126⟩,⟨23,24⟩,⟨31,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b49476 : Box := ![⟨95,126⟩,⟨23,24⟩,⟨31,41⟩,⟨3,6⟩,⟨319,478⟩]
private def b49477 : Box := ![⟨95,108⟩,⟨23,24⟩,⟨31,41⟩,⟨3,6⟩,⟨319,478⟩]
private def b49488 : Box := ![⟨109,126⟩,⟨23,24⟩,⟨31,41⟩,⟨3,6⟩,⟨319,478⟩]
private def b49493 : Box := ![⟨95,126⟩,⟨23,24⟩,⟨42,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b49494 : Box := ![⟨95,126⟩,⟨23,24⟩,⟨31,62⟩,⟨7,61⟩,⟨319,478⟩]
private def b49495 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨31,62⟩,⟨3,77⟩,⟨239,478⟩]
private def b49496 : Box := ![⟨127,190⟩,⟨21,22⟩,⟨31,62⟩,⟨3,77⟩,⟨307,478⟩]
private def b49497 : Box := ![⟨127,190⟩,⟨21,22⟩,⟨31,41⟩,⟨3,73⟩,⟨307,478⟩]
private def b49498 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨31,41⟩,⟨3,64⟩,⟨307,478⟩]
private def b49499 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨31,41⟩,⟨3,56⟩,⟨307,373⟩]
private def b49506 : Box := ![⟨127,152⟩,⟨21,22⟩,⟨31,41⟩,⟨3,56⟩,⟨374,478⟩]
private def b49507 : Box := ![⟨127,138⟩,⟨21,22⟩,⟨31,41⟩,⟨3,54⟩,⟨379,467⟩]
private def b49514 : Box := ![⟨139,152⟩,⟨21,22⟩,⟨31,41⟩,⟨3,54⟩,⟨379,467⟩]
private def b49519 : Box := ![⟨153,190⟩,⟨21,22⟩,⟨31,41⟩,⟨3,64⟩,⟨307,478⟩]
private def b49522 : Box := ![⟨127,190⟩,⟨21,22⟩,⟨42,62⟩,⟨3,73⟩,⟨307,478⟩]
private def b49523 : Box := ![⟨127,190⟩,⟨23,24⟩,⟨31,62⟩,⟨3,77⟩,⟨307,478⟩]
private def b49524 : Box := ![⟨95,190⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711621⟩,⟨239,478⟩]
private def b49525 : Box := ![⟨95,126⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711621⟩,⟨306,478⟩]
private def b49526 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨63,1920000000000000011376⟩,⟨3,861818181818181823330⟩,⟨306,478⟩]
private def b49527 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨63,126⟩,⟨3,861818181818181823329⟩,⟨306,478⟩]
private def b49528 : Box := ![⟨95,108⟩,⟨21,22⟩,⟨63,126⟩,⟨3,90⟩,⟨306,478⟩]
private def b49529 : Box := ![⟨95,108⟩,⟨21,22⟩,⟨63,126⟩,⟨3,6⟩,⟨306,478⟩]
private def b49530 : Box := ![⟨95,108⟩,⟨21,22⟩,⟨63,126⟩,⟨7,86⟩,⟨306,478⟩]
private def b49531 : Box := ![⟨95,108⟩,⟨21,22⟩,⟨63,126⟩,⟨7,13⟩,⟨357,478⟩]
private def b49532 : Box := ![⟨95,108⟩,⟨21,21⟩,⟨63,96⟩,⟨7,13⟩,⟨359,467⟩]
private def b49533 : Box := ![⟨95,108⟩,⟨21,21⟩,⟨63,96⟩,⟨7,13⟩,⟨359,405⟩]
private def b49540 : Box := ![⟨95,108⟩,⟨21,21⟩,⟨63,96⟩,⟨7,13⟩,⟨406,467⟩]
private def b49549 : Box := ![⟨95,108⟩,⟨22,22⟩,⟨63,96⟩,⟨7,13⟩,⟨359,467⟩]
private def b49550 : Box := ![⟨95,108⟩,⟨21,22⟩,⟨63,126⟩,⟨14,86⟩,⟨357,478⟩]
private def b49551 : Box := ![⟨109,126⟩,⟨21,22⟩,⟨63,126⟩,⟨3,90⟩,⟨306,478⟩]
private def b49552 : Box := ![⟨95,126⟩,⟨21,22⟩,⟨127,1920000000000000011376⟩,⟨3,861818181818181823329⟩,⟨306,478⟩]
private def b49553 : Box := ![⟨95,126⟩,⟨23,24⟩,⟨63,1920000000000000011376⟩,⟨3,861818181818181823330⟩,⟨306,478⟩]
private def b49554 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨3,900178041543026711621⟩,⟨306,478⟩]
private def b49555 : Box := ![⟨95,190⟩,⟨25,30⟩,⟨31,1920000000000000011376⟩,⟨3,900178041543026711623⟩,⟨239,478⟩]
private def b49556 : Box := ![⟨95,190⟩,⟨25,30⟩,⟨31,62⟩,⟨3,19⟩,⟨378,478⟩]
private def b49557 : Box := ![⟨95,126⟩,⟨25,30⟩,⟨31,62⟩,⟨3,13⟩,⟨379,467⟩]
private def b49568 : Box := ![⟨127,190⟩,⟨25,30⟩,⟨31,62⟩,⟨3,13⟩,⟨379,467⟩]
private def b49569 : Box := ![⟨95,190⟩,⟨25,30⟩,⟨63,1920000000000000011376⟩,⟨3,19⟩,⟨378,478⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨1,900178041543026711630⟩,⟨239,478⟩] := by
  have e49338 : Deny 5 13 b49338 := by
    apply closeAction rule_sound _ _ 64 [0x562]
    decide +kernel
  have e49347 : Deny 5 13 b49347 := by
    apply closeAction rule_sound _ _ 64 [0x75f2950c31c9284]
    decide +kernel
  have e49356 : Deny 5 13 b49356 := by
    apply closeAction rule_sound _ _ 64 [0x1d7ca5430c724a8c4]
    decide +kernel
  have e49346 : Deny 5 13 b49346 :=
    branchAction rule_sound _ _ 2
      0x2e3 b49346 b49347 b49356 (by decide +kernel) e49347 e49356
  have e49365 : Deny 5 13 b49365 := by
    apply closeAction rule_sound _ _ 64 [0x578dc40f8dc38c7109e37]
    decide +kernel
  have e49345 : Deny 5 13 b49345 :=
    branchAction rule_sound _ _ 2
      0x1e3 b49345 b49346 b49365 (by decide +kernel) e49346 e49365
  have e49370 : Deny 5 13 b49370 := by
    apply closeAction rule_sound _ _ 64 [0x15e371020820c82441f854a107e37]
    decide +kernel
  have e49344 : Deny 5 13 b49344 :=
    branchAction rule_sound _ _ 1
      0x9 b49344 b49345 b49370 (by decide +kernel) e49345 e49370
  have e49381 : Deny 5 13 b49381 := by
    apply closeAction rule_sound _ _ 64 [0x82578dd5e370c91c7109e37]
    decide +kernel
  have e49343 : Deny 5 13 b49343 :=
    branchAction rule_sound _ _ 2
      0x204 b49343 b49344 b49381 (by decide +kernel) e49344 e49381
  have e49395 : Deny 5 13 b49395 := by
    apply closeAction rule_sound _ _ 64 [0x150c21f8dc9]
    decide +kernel
  have e49400 : Deny 5 13 b49400 := by
    apply closeAction rule_sound _ _ 64 [0x75f0c4087e3620a]
    decide +kernel
  have e49394 : Deny 5 13 b49394 :=
    branchAction rule_sound _ _ 3
      0xa8c4 b49394 b49395 b49400 (by decide +kernel) e49395 e49400
  have e49407 : Deny 5 13 b49407 := by
    apply closeAction rule_sound _ _ 64 [0x30f8df68c7778df62378c4]
    decide +kernel
  have e49393 : Deny 5 13 b49393 :=
    branchAction rule_sound _ _ 2
      0x2e3 b49393 b49394 b49407 (by decide +kernel) e49394 e49407
  have e49414 : Deny 5 13 b49414 := by
    apply closeAction rule_sound _ _ 64 [0x150c31c9]
    decide +kernel
  have e49419 : Deny 5 13 b49419 := by
    apply closeAction rule_sound _ _ 64 [0x1d7c3e370c70c920a]
    decide +kernel
  have e49413 : Deny 5 13 b49413 :=
    branchAction rule_sound _ _ 2
      0x284 b49413 b49414 b49419 (by decide +kernel) e49414 e49419
  have e49429 : Deny 5 13 b49429 := by
    apply closeAction rule_sound _ _ 64 [0xc3de31e3]
    decide +kernel
  have e49432 : Deny 5 13 b49432 := by
    apply closeAction rule_sound _ _ 64 [0x75f0c3e0720a54a]
    decide +kernel
  have e49428 : Deny 5 13 b49428 :=
    branchAction rule_sound _ _ 3
      0x98c4 b49428 b49429 b49432 (by decide +kernel) e49429 e49432
  have e49412 : Deny 5 13 b49412 :=
    branchAction rule_sound _ _ 1
      0xb b49412 b49413 b49428 (by decide +kernel) e49413 e49428
  have e49392 : Deny 5 13 b49392 :=
    branchAction rule_sound _ _ 2
      0x1e3 b49392 b49393 b49412 (by decide +kernel) e49393 e49412
  have e49442 : Deny 5 13 b49442 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
  have e49447 : Deny 5 13 b49447 := by
    apply closeAction rule_sound _ _ 64 [0x15e370c90c3e091c4]
    decide +kernel
  have e49454 : Deny 5 13 b49454 := by
    apply closeAction rule_sound _ _ 64 [0x30f8243103e37109e361c4]
    decide +kernel
  have e49446 : Deny 5 13 b49446 :=
    branchAction rule_sound _ _ 1
      0xb b49446 b49447 b49454 (by decide +kernel) e49447 e49454
  have e49461 : Deny 5 13 b49461 := by
    apply closeAction rule_sound _ _ 64 [0x1d7555432492842b81152b8]
    decide +kernel
  have e49445 : Deny 5 13 b49445 :=
    branchAction rule_sound _ _ 1
      0x7 b49445 b49446 b49461 (by decide +kernel) e49446 e49461
  have e49472 : Deny 5 13 b49472 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
  have e49444 : Deny 5 13 b49444 :=
    branchAction rule_sound _ _ 1
      0x8 b49444 b49445 b49472 (by decide +kernel) e49445 e49472
  have e49473 : Deny 5 13 b49473 := by
    apply closeAction rule_sound _ _ 64 [0x1d]
    decide +kernel
  have e49443 : Deny 5 13 b49443 :=
    branchAction rule_sound _ _ 1
      0xa b49443 b49444 b49473 (by decide +kernel) e49444 e49473
  have e49441 : Deny 5 13 b49441 :=
    branchAction rule_sound _ _ 1
      0xa b49441 b49442 b49443 (by decide +kernel) e49442 e49443
  have e49391 : Deny 5 13 b49391 :=
    branchAction rule_sound _ _ 1
      0x9 b49391 b49392 b49441 (by decide +kernel) e49392 e49441
  have e49477 : Deny 5 13 b49477 := by
    apply closeAction rule_sound _ _ 64 [0x150c31c91150c31c910b]
    decide +kernel
  have e49488 : Deny 5 13 b49488 := by
    apply closeAction rule_sound _ _ 64 [0x578dc40f8dc31c4278]
    decide +kernel
  have e49476 : Deny 5 13 b49476 :=
    branchAction rule_sound _ _ 1
      0x7 b49476 b49477 b49488 (by decide +kernel) e49477 e49488
  have e49493 : Deny 5 13 b49493 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
  have e49475 : Deny 5 13 b49475 :=
    branchAction rule_sound _ _ 1
      0x9 b49475 b49476 b49493 (by decide +kernel) e49476 e49493
  have e49494 : Deny 5 13 b49494 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
  have e49474 : Deny 5 13 b49474 :=
    branchAction rule_sound _ _ 1
      0xa b49474 b49475 b49494 (by decide +kernel) e49475 e49494
  have e49390 : Deny 5 13 b49390 :=
    branchAction rule_sound _ _ 2
      0x223 b49390 b49391 b49474 (by decide +kernel) e49391 e49474
  have e49342 : Deny 5 13 b49342 :=
    branchAction rule_sound _ _ 2
      0x2e3 b49342 b49343 b49390 (by decide +kernel) e49343 e49390
  have e49499 : Deny 5 13 b49499 := by
    apply closeAction rule_sound _ _ 64 [0x578dd5e370832091f7]
    decide +kernel
  have e49507 : Deny 5 13 b49507 := by
    apply closeAction rule_sound _ _ 64 [0x832370f8dc3223263]
    decide +kernel
  have e49514 : Deny 5 13 b49514 := by
    apply closeAction rule_sound _ _ 64 [0x578dd5e370c88c9]
    decide +kernel
  have e49506 : Deny 5 13 b49506 :=
    branchAction rule_sound _ _ 3
      0x78c4 b49506 b49507 b49514 (by decide +kernel) e49507 e49514
  have e49498 : Deny 5 13 b49498 :=
    branchAction rule_sound _ _ 2
      0x2e3 b49498 b49499 b49506 (by decide +kernel) e49499 e49506
  have e49519 : Deny 5 13 b49519 := by
    apply closeAction rule_sound _ _ 64 [0x829a0107e37]
    decide +kernel
  have e49497 : Deny 5 13 b49497 :=
    branchAction rule_sound _ _ 2
      0x1e3 b49497 b49498 b49519 (by decide +kernel) e49498 e49519
  have e49522 : Deny 5 13 b49522 := by
    apply closeAction rule_sound _ _ 64 [0x15e37]
    decide +kernel
  have e49496 : Deny 5 13 b49496 :=
    branchAction rule_sound _ _ 2
      0x263 b49496 b49497 b49522 (by decide +kernel) e49497 e49522
  have e49523 : Deny 5 13 b49523 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e49495 : Deny 5 13 b49495 :=
    branchAction rule_sound _ _ 2
      0x238 b49495 b49496 b49523 (by decide +kernel) e49496 e49523
  have e49341 : Deny 5 13 b49341 :=
    branchAction rule_sound _ _ 2
      0x1e3 b49341 b49342 b49495 (by decide +kernel) e49342 e49495
  have e49529 : Deny 5 13 b49529 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
  have e49533 : Deny 5 13 b49533 := by
    apply closeAction rule_sound _ _ 64 [0x820e2107e370c9887884]
    decide +kernel
  have e49540 : Deny 5 13 b49540 := by
    apply closeAction rule_sound _ _ 64 [0x20c42780f80e21c32621c4]
    decide +kernel
  have e49532 : Deny 5 13 b49532 :=
    branchAction rule_sound _ _ 1
      0xb b49532 b49533 b49540 (by decide +kernel) e49533 e49540
  have e49549 : Deny 5 13 b49549 := by
    apply closeAction rule_sound _ _ 64 [0x1fe37]
    decide +kernel
  have e49531 : Deny 5 13 b49531 :=
    branchAction rule_sound _ _ 3
      0x8884 b49531 b49532 b49549 (by decide +kernel) e49532 e49549
  have e49550 : Deny 5 13 b49550 := by
    apply closeAction rule_sound _ _ 64 [0x1d]
    decide +kernel
  have e49530 : Deny 5 13 b49530 :=
    branchAction rule_sound _ _ 2
      0x2b8 b49530 b49531 b49550 (by decide +kernel) e49531 e49550
  have e49528 : Deny 5 13 b49528 :=
    branchAction rule_sound _ _ 2
      0x2a3 b49528 b49529 b49530 (by decide +kernel) e49529 e49530
  have e49551 : Deny 5 13 b49551 := by
    apply closeAction rule_sound _ _ 64 [0x15e37]
    decide +kernel
  have e49527 : Deny 5 13 b49527 :=
    branchAction rule_sound _ _ 2
      0x1e3 b49527 b49528 b49551 (by decide +kernel) e49528 e49551
  have e49552 : Deny 5 13 b49552 := by
    apply closeAction rule_sound _ _ 64 [0xaf]
    decide +kernel
  have e49526 : Deny 5 13 b49526 :=
    branchAction rule_sound _ _ 2
      0x263 b49526 b49527 b49552 (by decide +kernel) e49527 e49552
  have e49553 : Deny 5 13 b49553 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e49525 : Deny 5 13 b49525 :=
    branchAction rule_sound _ _ 2
      0x223 b49525 b49526 b49553 (by decide +kernel) e49526 e49553
  have e49554 : Deny 5 13 b49554 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e49524 : Deny 5 13 b49524 :=
    branchAction rule_sound _ _ 2
      0x1f8 b49524 b49525 b49554 (by decide +kernel) e49525 e49554
  have e49340 : Deny 5 13 b49340 :=
    branchAction rule_sound _ _ 2
      0x263 b49340 b49341 b49524 (by decide +kernel) e49341 e49524
  have e49557 : Deny 5 13 b49557 := by
    apply closeAction rule_sound _ _ 64 [0x2082578dd5e370c7207248]
    decide +kernel
  have e49568 : Deny 5 13 b49568 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e49556 : Deny 5 13 b49556 :=
    branchAction rule_sound _ _ 3
      0x7dc4 b49556 b49557 b49568 (by decide +kernel) e49557 e49568
  have e49569 : Deny 5 13 b49569 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e49555 : Deny 5 13 b49555 :=
    branchAction rule_sound _ _ 3
      0x9e37 b49555 b49556 b49569 (by decide +kernel) e49556 e49569
  have e49339 : Deny 5 13 b49339 :=
    branchAction rule_sound _ _ 1
      0x8 b49339 b49340 b49555 (by decide +kernel) e49340 e49555
  have e49337 : Deny 5 13 b49337 :=
    branchAction rule_sound _ _ 2
      0x2a3 b49337 b49338 b49339 (by decide +kernel) e49338 e49339
  exact e49337
end OMA.Blocks5_13_245212.S49337
