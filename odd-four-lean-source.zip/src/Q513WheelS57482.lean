import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S57482
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b57482 : Box := ![⟨63,94⟩,⟨31,41⟩,⟨15,30⟩,⟨1,54⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨31,41⟩,⟨15,30⟩,⟨1,54⟩,⟨479,999999999999999999⟩] := by
  have e57482 : Deny 5 13 b57482 := by
    apply closeAction rule_sound _ _ 64 [0x8c9e237f8df68c8e368c70c21f88c21f8df68c88df7d728a5ca8cb0c3e378c87f8de31dfe378c9e23df68c8e232631e3,0xe08e072575f82430881021f824828a5ca8cb8c90c3e070f88c21f82237df5ca2972a32c3e237f8df68c8e23243e03e37,0x2a32c30f8203e230f8de32388c70dfe37d88e237f8df68c7e23243088e368c21f8df68c88df7d70c31c95cb0c3e080c3,0x2237df5d70c820a2972a32c3e230f88c7e2325f7c3e17e07e17e362172b85f8278d8ae0ae235cae231e32237df5ca297,0x8c88d7e370c38c78c88cb8c90f80e31c30e31e32237df5ca2972a32c30f8203e231e32631c30e31c3e230f8df68c7e23,0x2083e07e232380f80e31c30c7]
    decide +kernel
  exact e57482
end OMA.Blocks5_13_245212.S57482
