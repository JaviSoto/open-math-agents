import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S48992
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b48992 : Box := ![⟨95,126⟩,⟨25,30⟩,⟨15,30⟩,⟨1,62⟩,⟨479,999999999999999999⟩]
private def b48993 : Box := ![⟨95,126⟩,⟨25,30⟩,⟨15,20⟩,⟨1,51⟩,⟨479,999999999999999999⟩]
private def b48994 : Box := ![⟨95,126⟩,⟨25,30⟩,⟨15,20⟩,⟨1,2⟩,⟨479,1907⟩]
private def b48995 : Box := ![⟨95,126⟩,⟨25,30⟩,⟨15,20⟩,⟨3,47⟩,⟨479,1907⟩]
private def b48996 : Box := ![⟨95,126⟩,⟨25,30⟩,⟨15,20⟩,⟨3,6⟩,⟨479,1902⟩]
private def b48997 : Box := ![⟨95,126⟩,⟨25,30⟩,⟨15,20⟩,⟨3,4⟩,⟨479,1680⟩]
private def b48998 : Box := ![⟨95,126⟩,⟨25,27⟩,⟨15,20⟩,⟨3,4⟩,⟨479,1572⟩]
private def b49001 : Box := ![⟨95,126⟩,⟨28,30⟩,⟨15,20⟩,⟨3,4⟩,⟨479,1572⟩]
private def b49002 : Box := ![⟨95,126⟩,⟨28,30⟩,⟨15,20⟩,⟨3,4⟩,⟨479,734⟩]
private def b49013 : Box := ![⟨95,126⟩,⟨28,30⟩,⟨15,20⟩,⟨3,4⟩,⟨735,1571⟩]
private def b49020 : Box := ![⟨95,126⟩,⟨25,30⟩,⟨15,20⟩,⟨5,6⟩,⟨479,1680⟩]
private def b49021 : Box := ![⟨95,126⟩,⟨25,30⟩,⟨15,20⟩,⟨7,41⟩,⟨479,1902⟩]
private def b49022 : Box := ![⟨95,126⟩,⟨25,30⟩,⟨21,30⟩,⟨1,51⟩,⟨479,999999999999999999⟩]
private def b49023 : Box := ![⟨95,126⟩,⟨25,30⟩,⟨21,30⟩,⟨1,51⟩,⟨479,958⟩]
private def b49024 : Box := ![⟨95,126⟩,⟨25,30⟩,⟨21,30⟩,⟨1,2⟩,⟨479,958⟩]
private def b49025 : Box := ![⟨95,126⟩,⟨25,30⟩,⟨21,30⟩,⟨3,45⟩,⟨479,958⟩]
private def b49026 : Box := ![⟨95,126⟩,⟨25,30⟩,⟨21,30⟩,⟨3,6⟩,⟨479,958⟩]
private def b49027 : Box := ![⟨95,126⟩,⟨25,30⟩,⟨21,30⟩,⟨3,4⟩,⟨479,958⟩]
private def b49028 : Box := ![⟨95,126⟩,⟨25,27⟩,⟨21,30⟩,⟨3,4⟩,⟨479,958⟩]
private def b49029 : Box := ![⟨95,108⟩,⟨25,27⟩,⟨21,30⟩,⟨3,4⟩,⟨479,958⟩]
private def b49040 : Box := ![⟨109,126⟩,⟨25,27⟩,⟨21,30⟩,⟨3,4⟩,⟨479,958⟩]
private def b49041 : Box := ![⟨109,126⟩,⟨25,27⟩,⟨21,24⟩,⟨3,4⟩,⟨479,958⟩]
private def b49046 : Box := ![⟨109,126⟩,⟨25,27⟩,⟨25,30⟩,⟨3,4⟩,⟨479,958⟩]
private def b49047 : Box := ![⟨109,126⟩,⟨25,27⟩,⟨25,30⟩,⟨3,4⟩,⟨479,638⟩]
private def b49054 : Box := ![⟨109,126⟩,⟨25,27⟩,⟨25,30⟩,⟨3,4⟩,⟨639,958⟩]
private def b49065 : Box := ![⟨95,126⟩,⟨28,30⟩,⟨21,30⟩,⟨3,4⟩,⟨479,958⟩]
private def b49066 : Box := ![⟨95,126⟩,⟨28,30⟩,⟨21,30⟩,⟨3,3⟩,⟨479,958⟩]
private def b49067 : Box := ![⟨95,126⟩,⟨28,30⟩,⟨21,30⟩,⟨4,4⟩,⟨479,958⟩]
private def b49068 : Box := ![⟨95,108⟩,⟨28,30⟩,⟨21,30⟩,⟨4,4⟩,⟨479,958⟩]
private def b49077 : Box := ![⟨109,126⟩,⟨28,30⟩,⟨21,30⟩,⟨4,4⟩,⟨479,958⟩]
private def b49088 : Box := ![⟨95,126⟩,⟨25,30⟩,⟨21,30⟩,⟨5,6⟩,⟨479,958⟩]
private def b49089 : Box := ![⟨95,126⟩,⟨25,30⟩,⟨21,30⟩,⟨7,45⟩,⟨479,958⟩]
private def b49090 : Box := ![⟨95,126⟩,⟨25,30⟩,⟨21,30⟩,⟨1,51⟩,⟨959,999999999999999999⟩]
private def b49091 : Box := ![⟨95,126⟩,⟨25,27⟩,⟨21,30⟩,⟨1,46⟩,⟨959,999999999999999999⟩]
private def b49092 : Box := ![⟨95,126⟩,⟨25,27⟩,⟨21,30⟩,⟨1,2⟩,⟨959,9719⟩]
private def b49093 : Box := ![⟨95,126⟩,⟨25,27⟩,⟨21,30⟩,⟨3,45⟩,⟨959,9719⟩]
private def b49094 : Box := ![⟨95,108⟩,⟨25,27⟩,⟨21,30⟩,⟨3,40⟩,⟨959,9698⟩]
private def b49099 : Box := ![⟨109,126⟩,⟨25,27⟩,⟨21,30⟩,⟨3,40⟩,⟨959,9698⟩]
private def b49100 : Box := ![⟨109,126⟩,⟨25,25⟩,⟨21,30⟩,⟨3,40⟩,⟨959,9692⟩]
private def b49101 : Box := ![⟨109,126⟩,⟨26,27⟩,⟨21,30⟩,⟨3,40⟩,⟨959,9692⟩]
private def b49112 : Box := ![⟨95,126⟩,⟨28,30⟩,⟨21,30⟩,⟨1,46⟩,⟨959,999999999999999999⟩]
private def b49113 : Box := ![⟨95,108⟩,⟨28,30⟩,⟨21,30⟩,⟨1,46⟩,⟨959,999999999999999999⟩]
private def b49122 : Box := ![⟨109,126⟩,⟨28,30⟩,⟨21,30⟩,⟨1,46⟩,⟨959,999999999999999999⟩]
private def b49123 : Box := ![⟨109,126⟩,⟨28,30⟩,⟨21,24⟩,⟨1,46⟩,⟨959,999999999999999999⟩]
private def b49128 : Box := ![⟨109,126⟩,⟨28,30⟩,⟨25,30⟩,⟨1,46⟩,⟨959,999999999999999999⟩]
private def b49129 : Box := ![⟨109,126⟩,⟨28,30⟩,⟨25,30⟩,⟨1,46⟩,⟨959,1918⟩]
private def b49130 : Box := ![⟨109,126⟩,⟨28,30⟩,⟨25,30⟩,⟨1,2⟩,⟨959,1918⟩]
private def b49131 : Box := ![⟨109,126⟩,⟨28,30⟩,⟨25,30⟩,⟨3,41⟩,⟨959,1918⟩]
private def b49132 : Box := ![⟨109,126⟩,⟨28,30⟩,⟨25,30⟩,⟨3,6⟩,⟨959,1918⟩]
private def b49143 : Box := ![⟨109,126⟩,⟨28,30⟩,⟨25,30⟩,⟨7,41⟩,⟨959,1918⟩]
private def b49144 : Box := ![⟨109,126⟩,⟨28,30⟩,⟨25,30⟩,⟨1,46⟩,⟨1919,999999999999999999⟩]
private theorem e48994 : Deny 5 13 b48994 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e48998 : Deny 5 13 b48998 := by
    apply closeAction rule_sound _ _ 64 [0x3e37da01021f8da0]
    decide +kernel
private theorem e49002 : Deny 5 13 b49002 := by
    apply closeAction rule_sound _ _ 64 [0x170e0203e20203e36804087e20257da02a0]
    decide +kernel
private theorem e49013 : Deny 5 13 b49013 := by
    apply closeAction rule_sound _ _ 64 [0x3e03e07e02278087e36]
    decide +kernel
private theorem e49001 : Deny 5 13 b49001 :=
    branchAction rule_sound _ _ 2
      0x2f8 b49001 b49002 b49013 (by decide +kernel) e49002 e49013
private theorem e48997 : Deny 5 13 b48997 :=
    branchAction rule_sound _ _ 2
      0x238 b48997 b48998 b49001 (by decide +kernel) e48998 e49001
private theorem e49020 : Deny 5 13 b49020 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e48996 : Deny 5 13 b48996 :=
    branchAction rule_sound _ _ 2
      0x2b8 b48996 b48997 b49020 (by decide +kernel) e48997 e49020
private theorem e49021 : Deny 5 13 b49021 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e48995 : Deny 5 13 b48995 :=
    branchAction rule_sound _ _ 3
      0xae23 b48995 b48996 b49021 (by decide +kernel) e48996 e49021
private theorem e48993 : Deny 5 13 b48993 :=
    branchAction rule_sound _ _ 3
      0xae23 b48993 b48994 b48995 (by decide +kernel) e48994 e48995
private theorem e49024 : Deny 5 13 b49024 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e49029 : Deny 5 13 b49029 := by
    apply closeAction rule_sound _ _ 64 [0xc3e070c4087e095ca0f8d88]
    decide +kernel
private theorem e49041 : Deny 5 13 b49041 := by
    apply closeAction rule_sound _ _ 64 [0x30f81c3e08]
    decide +kernel
private theorem e49047 : Deny 5 13 b49047 := by
    apply closeAction rule_sound _ _ 64 [0x5f8dc31f80c31c8]
    decide +kernel
private theorem e49054 : Deny 5 13 b49054 := by
    apply closeAction rule_sound _ _ 64 [0xf80c90c75ca0c3e361c8]
    decide +kernel
private theorem e49046 : Deny 5 13 b49046 :=
    branchAction rule_sound _ _ 1
      0xb b49046 b49047 b49054 (by decide +kernel) e49047 e49054
private theorem e49040 : Deny 5 13 b49040 :=
    branchAction rule_sound _ _ 1
      0x9 b49040 b49041 b49046 (by decide +kernel) e49041 e49046
private theorem e49028 : Deny 5 13 b49028 :=
    branchAction rule_sound _ _ 1
      0x7 b49028 b49029 b49040 (by decide +kernel) e49029 e49040
private theorem e49066 : Deny 5 13 b49066 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e49068 : Deny 5 13 b49068 := by
    apply closeAction rule_sound _ _ 64 [0x3e031f80c8e030f81c9]
    decide +kernel
private theorem e49077 : Deny 5 13 b49077 := by
    apply closeAction rule_sound _ _ 64 [0x20832041f80f80c8e03e07278]
    decide +kernel
private theorem e49067 : Deny 5 13 b49067 :=
    branchAction rule_sound _ _ 1
      0x7 b49067 b49068 b49077 (by decide +kernel) e49068 e49077
private theorem e49065 : Deny 5 13 b49065 :=
    branchAction rule_sound _ _ 1
      0xa b49065 b49066 b49067 (by decide +kernel) e49066 e49067
private theorem e49027 : Deny 5 13 b49027 :=
    branchAction rule_sound _ _ 1
      0x8 b49027 b49028 b49065 (by decide +kernel) e49028 e49065
private theorem e49088 : Deny 5 13 b49088 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e49026 : Deny 5 13 b49026 :=
    branchAction rule_sound _ _ 1
      0xa b49026 b49027 b49088 (by decide +kernel) e49027 e49088
private theorem e49089 : Deny 5 13 b49089 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e49025 : Deny 5 13 b49025 :=
    branchAction rule_sound _ _ 1
      0xa b49025 b49026 b49089 (by decide +kernel) e49026 e49089
private theorem e49023 : Deny 5 13 b49023 :=
    branchAction rule_sound _ _ 2
      0x2a3 b49023 b49024 b49025 (by decide +kernel) e49024 e49025
private theorem e49092 : Deny 5 13 b49092 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e49094 : Deny 5 13 b49094 := by
    apply closeAction rule_sound _ _ 64 [0xc21c2238da3]
    decide +kernel
private theorem e49100 : Deny 5 13 b49100 := by
    apply closeAction rule_sound _ _ 64 [0xf8df6]
    decide +kernel
private theorem e49101 : Deny 5 13 b49101 := by
    apply closeAction rule_sound _ _ 64 [0x7df0f80f81f80f8087e09e0ae362b8]
    decide +kernel
private theorem e49099 : Deny 5 13 b49099 :=
    branchAction rule_sound _ _ 2
      0x238 b49099 b49100 b49101 (by decide +kernel) e49100 e49101
private theorem e49093 : Deny 5 13 b49093 :=
    branchAction rule_sound _ _ 3
      0x7e23 b49093 b49094 b49099 (by decide +kernel) e49094 e49099
private theorem e49091 : Deny 5 13 b49091 :=
    branchAction rule_sound _ _ 3
      0xae23 b49091 b49092 b49093 (by decide +kernel) e49092 e49093
private theorem e49113 : Deny 5 13 b49113 := by
    apply closeAction rule_sound _ _ 64 [0xc3e231c3e23203e378dfe378c7e23263]
    decide +kernel
private theorem e49123 : Deny 5 13 b49123 := by
    apply closeAction rule_sound _ _ 64 [0x30f8203e231e3]
    decide +kernel
private theorem e49130 : Deny 5 13 b49130 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e49132 : Deny 5 13 b49132 := by
    apply closeAction rule_sound _ _ 64 [0x1f0832380f80c81d728a]
    decide +kernel
private theorem e49143 : Deny 5 13 b49143 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e49131 : Deny 5 13 b49131 :=
    branchAction rule_sound _ _ 1
      0xa b49131 b49132 b49143 (by decide +kernel) e49132 e49143
private theorem e49129 : Deny 5 13 b49129 :=
    branchAction rule_sound _ _ 2
      0x2a3 b49129 b49130 b49131 (by decide +kernel) e49130 e49131
private theorem e49144 : Deny 5 13 b49144 := by
    apply closeAction rule_sound _ _ 64 [0x30e32430f82231e3]
    decide +kernel
private theorem e49128 : Deny 5 13 b49128 :=
    branchAction rule_sound _ _ 1
      0xb b49128 b49129 b49144 (by decide +kernel) e49129 e49144
private theorem e49122 : Deny 5 13 b49122 :=
    branchAction rule_sound _ _ 1
      0x9 b49122 b49123 b49128 (by decide +kernel) e49123 e49128
private theorem e49112 : Deny 5 13 b49112 :=
    branchAction rule_sound _ _ 1
      0x7 b49112 b49113 b49122 (by decide +kernel) e49113 e49122
private theorem e49090 : Deny 5 13 b49090 :=
    branchAction rule_sound _ _ 2
      0x223 b49090 b49091 b49112 (by decide +kernel) e49091 e49112
private theorem e49022 : Deny 5 13 b49022 :=
    branchAction rule_sound _ _ 1
      0xb b49022 b49023 b49090 (by decide +kernel) e49023 e49090
private theorem e48992 : Deny 5 13 b48992 :=
    branchAction rule_sound _ _ 2
      0x263 b48992 b48993 b49022 (by decide +kernel) e48993 e49022
theorem deny5_13 : Deny 5 13 ![⟨95,126⟩,⟨25,30⟩,⟨15,30⟩,⟨1,62⟩,⟨479,999999999999999999⟩] := by
  exact e48992
end OMA.Blocks5_13_245212.S48992
