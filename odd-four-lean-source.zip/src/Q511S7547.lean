import FastReplay245212
import SparseDigit245212
import FastRound245212
import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S7547
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b7547 : Box := ![⟨15,22⟩,⟨15,30⟩,⟨7,1920000000000000011376⟩,⟨1,1920000000000000011376⟩,⟨53,101⟩]
private def b7548 : Box := ![⟨15,22⟩,⟨15,30⟩,⟨7,14⟩,⟨1,1160381991814461125599⟩,⟨53,101⟩]
private def b7549 : Box := ![⟨15,17⟩,⟨15,30⟩,⟨7,14⟩,⟨1,30⟩,⟨53,101⟩]
private def b7556 : Box := ![⟨18,22⟩,⟨15,30⟩,⟨7,14⟩,⟨1,30⟩,⟨53,101⟩]
private def b7557 : Box := ![⟨18,22⟩,⟨15,30⟩,⟨7,14⟩,⟨1,2⟩,⟨53,101⟩]
private def b7558 : Box := ![⟨18,22⟩,⟨15,30⟩,⟨7,14⟩,⟨1,2⟩,⟨53,69⟩]
private def b7571 : Box := ![⟨18,22⟩,⟨15,30⟩,⟨7,14⟩,⟨1,2⟩,⟨70,101⟩]
private def b7580 : Box := ![⟨18,22⟩,⟨15,30⟩,⟨7,14⟩,⟨3,30⟩,⟨53,101⟩]
private def b7581 : Box := ![⟨18,22⟩,⟨15,30⟩,⟨7,14⟩,⟨3,30⟩,⟨53,69⟩]
private def b7596 : Box := ![⟨18,22⟩,⟨15,30⟩,⟨7,14⟩,⟨3,30⟩,⟨70,101⟩]
private def b7611 : Box := ![⟨15,22⟩,⟨15,30⟩,⟨15,1920000000000000011376⟩,⟨1,1160381991814461125599⟩,⟨53,101⟩]
private def b7612 : Box := ![⟨15,17⟩,⟨15,30⟩,⟨15,1920000000000000011376⟩,⟨1,1160381991814461125599⟩,⟨53,101⟩]
private def b7613 : Box := ![⟨15,17⟩,⟨15,30⟩,⟨15,1920000000000000011376⟩,⟨1,2⟩,⟨53,101⟩]
private def b7614 : Box := ![⟨15,17⟩,⟨15,20⟩,⟨15,36⟩,⟨1,2⟩,⟨53,82⟩]
private def b7615 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨15,36⟩,⟨1,2⟩,⟨53,82⟩]
private def b7616 : Box := ![⟨15,15⟩,⟨21,30⟩,⟨15,35⟩,⟨1,2⟩,⟨53,79⟩]
private def b7617 : Box := ![⟨16,17⟩,⟨21,30⟩,⟨15,35⟩,⟨1,2⟩,⟨53,79⟩]
private def b7632 : Box := ![⟨15,17⟩,⟨15,30⟩,⟨15,1920000000000000011376⟩,⟨3,1160381991814461125597⟩,⟨53,101⟩]
private def b7633 : Box := ![⟨15,17⟩,⟨15,30⟩,⟨15,1920000000000000011376⟩,⟨3,1160381991814461125597⟩,⟨53,69⟩]
private def b7634 : Box := ![⟨15,17⟩,⟨15,20⟩,⟨15,1920000000000000011376⟩,⟨3,1160381991814461125597⟩,⟨53,67⟩]
private def b7635 : Box := ![⟨15,17⟩,⟨15,20⟩,⟨15,30⟩,⟨3,1160381991814461125593⟩,⟨53,67⟩]
private def b7640 : Box := ![⟨15,17⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨3,1160381991814461125593⟩,⟨53,67⟩]
private def b7641 : Box := ![⟨15,17⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨3,6⟩,⟨53,67⟩]
private def b7644 : Box := ![⟨15,17⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨7,1160381991814461125593⟩,⟨53,67⟩]
private def b7645 : Box := ![⟨15,17⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨7,1160381991814461125593⟩,⟨53,59⟩]
private def b7646 : Box := ![⟨15,17⟩,⟨15,17⟩,⟨31,1920000000000000011376⟩,⟨7,1160381991814461125593⟩,⟨53,59⟩]
private def b7659 : Box := ![⟨15,17⟩,⟨18,20⟩,⟨31,1920000000000000011376⟩,⟨7,1160381991814461125593⟩,⟨53,59⟩]
private def b7666 : Box := ![⟨15,17⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨7,1160381991814461125593⟩,⟨60,67⟩]
private def b7667 : Box := ![⟨15,17⟩,⟨15,17⟩,⟨31,1920000000000000011376⟩,⟨7,1120632411067193682555⟩,⟨61,67⟩]
private def b7678 : Box := ![⟨15,17⟩,⟨18,20⟩,⟨31,1920000000000000011376⟩,⟨7,1120632411067193682555⟩,⟨61,67⟩]
private def b7689 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨15,1920000000000000011376⟩,⟨3,1160381991814461125597⟩,⟨53,67⟩]
private def b7690 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨15,30⟩,⟨3,1160381991814461125597⟩,⟨53,67⟩]
private def b7691 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨15,30⟩,⟨3,6⟩,⟨53,67⟩]
private def b7692 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨15,30⟩,⟨3,6⟩,⟨53,59⟩]
private def b7703 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨15,30⟩,⟨3,6⟩,⟨60,67⟩]
private def b7714 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨15,30⟩,⟨7,38⟩,⟨53,67⟩]
private def b7715 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨15,30⟩,⟨7,38⟩,⟨53,59⟩]
private def b7726 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨15,30⟩,⟨7,38⟩,⟨60,67⟩]
private def b7737 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨3,1160381991814461125597⟩,⟨53,67⟩]
private def b7738 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨31,62⟩,⟨3,1160381991814461125597⟩,⟨53,67⟩]
private def b7739 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨31,62⟩,⟨3,6⟩,⟨53,67⟩]
private def b7754 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨31,62⟩,⟨7,58⟩,⟨53,67⟩]
private def b7767 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨63,1920000000000000011376⟩,⟨3,1160381991814461125597⟩,⟨53,67⟩]
private def b7768 : Box := ![⟨15,17⟩,⟨15,30⟩,⟨15,1920000000000000011376⟩,⟨3,1160381991814461125597⟩,⟨70,101⟩]
private def b7769 : Box := ![⟨15,17⟩,⟨15,20⟩,⟨15,1920000000000000011376⟩,⟨3,1080762388818297338072⟩,⟨71,101⟩]
private def b7770 : Box := ![⟨15,17⟩,⟨15,20⟩,⟨18,1920000000000000011376⟩,⟨3,6⟩,⟨71,101⟩]
private def b7771 : Box := ![⟨15,17⟩,⟨15,20⟩,⟨18,1920000000000000011376⟩,⟨7,1080762388818297338068⟩,⟨71,101⟩]
private def b7772 : Box := ![⟨15,17⟩,⟨15,20⟩,⟨18,36⟩,⟨7,1080762388818297338068⟩,⟨71,101⟩]
private def b7777 : Box := ![⟨15,17⟩,⟨15,20⟩,⟨37,1920000000000000011376⟩,⟨7,1080762388818297338068⟩,⟨71,101⟩]
private def b7778 : Box := ![⟨15,17⟩,⟨15,20⟩,⟨37,1920000000000000011376⟩,⟨7,1080762388818297338068⟩,⟨71,83⟩]
private def b7779 : Box := ![⟨15,17⟩,⟨15,17⟩,⟨37,1920000000000000011376⟩,⟨7,1080762388818297338068⟩,⟨71,83⟩]
private def b7792 : Box := ![⟨15,17⟩,⟨18,20⟩,⟨37,1920000000000000011376⟩,⟨7,1080762388818297338068⟩,⟨71,83⟩]
private def b7793 : Box := ![⟨15,15⟩,⟨18,20⟩,⟨37,1920000000000000011376⟩,⟨7,1080762388818297338068⟩,⟨71,83⟩]
private def b7796 : Box := ![⟨16,17⟩,⟨18,20⟩,⟨37,1920000000000000011376⟩,⟨7,1080762388818297338068⟩,⟨71,83⟩]
private def b7809 : Box := ![⟨15,17⟩,⟨15,20⟩,⟨37,1920000000000000011376⟩,⟨7,1080762388818297338068⟩,⟨84,101⟩]
private def b7822 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨15,1920000000000000011376⟩,⟨3,1080762388818297338072⟩,⟨71,101⟩]
private def b7823 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨15,30⟩,⟨3,1080762388818297338072⟩,⟨71,101⟩]
private def b7824 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨15,30⟩,⟨3,36⟩,⟨71,83⟩]
private def b7835 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨15,30⟩,⟨3,36⟩,⟨84,101⟩]
private def b7842 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨3,1080762388818297338072⟩,⟨71,101⟩]
private def b7843 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨3,1080762388818297338072⟩,⟨71,83⟩]
private def b7844 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨3,6⟩,⟨71,83⟩]
private def b7853 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨7,1080762388818297338072⟩,⟨71,83⟩]
private def b7854 : Box := ![⟨15,15⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨7,1080762388818297338072⟩,⟨71,83⟩]
private def b7855 : Box := ![⟨15,15⟩,⟨21,24⟩,⟨31,1920000000000000011376⟩,⟨7,1080762388818297338071⟩,⟨71,83⟩]
private def b7864 : Box := ![⟨15,15⟩,⟨25,30⟩,⟨31,1920000000000000011376⟩,⟨7,1080762388818297338071⟩,⟨71,83⟩]
private def b7877 : Box := ![⟨16,17⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨7,1080762388818297338072⟩,⟨71,83⟩]
private def b7878 : Box := ![⟨16,17⟩,⟨21,24⟩,⟨31,1920000000000000011376⟩,⟨7,1080762388818297338072⟩,⟨71,83⟩]
private def b7887 : Box := ![⟨16,17⟩,⟨25,30⟩,⟨31,1920000000000000011376⟩,⟨7,1080762388818297338072⟩,⟨71,83⟩]
private def b7894 : Box := ![⟨15,17⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨3,1080762388818297338072⟩,⟨84,101⟩]
private def b7895 : Box := ![⟨15,15⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨3,1027246376811594209013⟩,⟨89,101⟩]
private def b7906 : Box := ![⟨16,17⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨3,1027246376811594209013⟩,⟨89,101⟩]
private def b7907 : Box := ![⟨16,17⟩,⟨21,24⟩,⟨31,1920000000000000011376⟩,⟨3,1027246376811594209013⟩,⟨89,101⟩]
private def b7918 : Box := ![⟨16,17⟩,⟨25,30⟩,⟨31,1920000000000000011376⟩,⟨3,1027246376811594209013⟩,⟨89,101⟩]
private def b7919 : Box := ![⟨16,17⟩,⟨25,30⟩,⟨31,62⟩,⟨3,1027246376811594209013⟩,⟨89,101⟩]
private def b7930 : Box := ![⟨16,17⟩,⟨25,30⟩,⟨63,1920000000000000011376⟩,⟨3,1027246376811594209013⟩,⟨89,101⟩]
private def b7941 : Box := ![⟨18,22⟩,⟨15,30⟩,⟨15,1920000000000000011376⟩,⟨1,1160381991814461125599⟩,⟨53,101⟩]
private def b7942 : Box := ![⟨18,22⟩,⟨15,30⟩,⟨15,1920000000000000011376⟩,⟨1,2⟩,⟨53,101⟩]
private def b7943 : Box := ![⟨18,22⟩,⟨15,30⟩,⟨15,38⟩,⟨1,2⟩,⟨53,69⟩]
private def b7944 : Box := ![⟨18,22⟩,⟨15,20⟩,⟨15,38⟩,⟨1,2⟩,⟨53,67⟩]
private def b7955 : Box := ![⟨18,22⟩,⟨21,30⟩,⟨15,38⟩,⟨1,2⟩,⟨53,67⟩]
private def b7956 : Box := ![⟨18,19⟩,⟨21,30⟩,⟨15,38⟩,⟨1,2⟩,⟨53,67⟩]
private def b7957 : Box := ![⟨18,19⟩,⟨21,30⟩,⟨15,36⟩,⟨1,2⟩,⟨53,59⟩]
private def b7966 : Box := ![⟨18,19⟩,⟨21,30⟩,⟨15,36⟩,⟨1,2⟩,⟨60,67⟩]
private def b7975 : Box := ![⟨20,22⟩,⟨21,30⟩,⟨15,38⟩,⟨1,2⟩,⟨53,67⟩]
private def b7976 : Box := ![⟨20,22⟩,⟨21,30⟩,⟨15,38⟩,⟨1,2⟩,⟨53,59⟩]
private def b7987 : Box := ![⟨20,22⟩,⟨21,30⟩,⟨15,38⟩,⟨1,2⟩,⟨60,67⟩]
private def b7998 : Box := ![⟨18,22⟩,⟨15,30⟩,⟨15,38⟩,⟨1,2⟩,⟨70,101⟩]
private def b7999 : Box := ![⟨18,22⟩,⟨15,20⟩,⟨15,38⟩,⟨1,2⟩,⟨71,101⟩]
private def b8006 : Box := ![⟨18,22⟩,⟨21,30⟩,⟨15,38⟩,⟨1,2⟩,⟨71,101⟩]
private def b8007 : Box := ![⟨18,19⟩,⟨21,30⟩,⟨15,38⟩,⟨1,2⟩,⟨71,101⟩]
private def b8008 : Box := ![⟨18,19⟩,⟨21,30⟩,⟨15,37⟩,⟨1,2⟩,⟨71,83⟩]
private def b8017 : Box := ![⟨18,19⟩,⟨21,30⟩,⟨15,37⟩,⟨1,2⟩,⟨84,101⟩]
private def b8024 : Box := ![⟨20,22⟩,⟨21,30⟩,⟨15,38⟩,⟨1,2⟩,⟨71,101⟩]
private def b8025 : Box := ![⟨20,22⟩,⟨21,30⟩,⟨15,38⟩,⟨1,2⟩,⟨71,83⟩]
private def b8040 : Box := ![⟨20,22⟩,⟨21,30⟩,⟨15,38⟩,⟨1,2⟩,⟨84,101⟩]
private def b8055 : Box := ![⟨18,22⟩,⟨15,30⟩,⟨15,1920000000000000011376⟩,⟨3,1160381991814461125599⟩,⟨53,101⟩]
private def b8056 : Box := ![⟨18,22⟩,⟨15,30⟩,⟨15,1920000000000000011376⟩,⟨3,1160381991814461125599⟩,⟨53,69⟩]
private def b8057 : Box := ![⟨18,22⟩,⟨15,20⟩,⟨15,1920000000000000011376⟩,⟨3,1160381991814461125598⟩,⟨53,67⟩]
private def b8058 : Box := ![⟨18,22⟩,⟨15,20⟩,⟨15,30⟩,⟨3,1160381991814461125594⟩,⟨53,67⟩]
private def b8067 : Box := ![⟨18,22⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨3,1160381991814461125594⟩,⟨53,67⟩]
private def b8080 : Box := ![⟨18,22⟩,⟨21,30⟩,⟨15,1920000000000000011376⟩,⟨3,1160381991814461125598⟩,⟨53,67⟩]
private def b8091 : Box := ![⟨18,22⟩,⟨15,30⟩,⟨15,1920000000000000011376⟩,⟨3,1160381991814461125599⟩,⟨70,101⟩]
private def b8092 : Box := ![⟨18,22⟩,⟨15,20⟩,⟨15,1920000000000000011376⟩,⟨3,1080762388818297338073⟩,⟨71,101⟩]
private def b8093 : Box := ![⟨18,22⟩,⟨15,20⟩,⟨15,30⟩,⟨3,1080762388818297338069⟩,⟨71,101⟩]
private def b8102 : Box := ![⟨18,22⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨3,1080762388818297338069⟩,⟨71,101⟩]
private def b8103 : Box := ![⟨18,19⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨3,1080762388818297338069⟩,⟨71,101⟩]
private def b8104 : Box := ![⟨18,19⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨3,6⟩,⟨71,101⟩]
private def b8105 : Box := ![⟨18,19⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨7,1080762388818297338069⟩,⟨71,101⟩]
private def b8106 : Box := ![⟨18,19⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨7,1080762388818297338069⟩,⟨71,83⟩]
private def b8119 : Box := ![⟨18,19⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨7,1080762388818297338069⟩,⟨84,101⟩]
private def b8120 : Box := ![⟨18,19⟩,⟨15,17⟩,⟨31,1920000000000000011376⟩,⟨7,1027246376811594209010⟩,⟨89,101⟩]
private def b8129 : Box := ![⟨18,19⟩,⟨18,20⟩,⟨31,1920000000000000011376⟩,⟨7,1027246376811594209010⟩,⟨89,101⟩]
private def b8136 : Box := ![⟨20,22⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨3,1080762388818297338069⟩,⟨71,101⟩]
private def b8137 : Box := ![⟨20,22⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨3,1080762388818297338069⟩,⟨71,83⟩]
private def b8150 : Box := ![⟨20,22⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨3,1080762388818297338069⟩,⟨84,101⟩]
private def b8151 : Box := ![⟨20,22⟩,⟨15,17⟩,⟨31,1920000000000000011376⟩,⟨3,1027246376811594209010⟩,⟨89,101⟩]
private def b8162 : Box := ![⟨20,22⟩,⟨18,20⟩,⟨31,1920000000000000011376⟩,⟨3,1027246376811594209010⟩,⟨89,101⟩]
private def b8169 : Box := ![⟨18,22⟩,⟨21,30⟩,⟨15,1920000000000000011376⟩,⟨3,1080762388818297338073⟩,⟨71,101⟩]
private def b8170 : Box := ![⟨18,22⟩,⟨21,30⟩,⟨15,30⟩,⟨3,1080762388818297338073⟩,⟨71,101⟩]
private def b8171 : Box := ![⟨18,19⟩,⟨21,30⟩,⟨15,30⟩,⟨3,37⟩,⟨71,101⟩]
private def b8186 : Box := ![⟨20,22⟩,⟨21,30⟩,⟨15,30⟩,⟨3,37⟩,⟨71,101⟩]
private def b8187 : Box := ![⟨20,22⟩,⟨21,30⟩,⟨15,30⟩,⟨3,37⟩,⟨71,83⟩]
private def b8194 : Box := ![⟨20,22⟩,⟨21,30⟩,⟨15,30⟩,⟨3,37⟩,⟨84,101⟩]
private def b8203 : Box := ![⟨18,22⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨3,1080762388818297338073⟩,⟨71,101⟩]
private def b8204 : Box := ![⟨18,22⟩,⟨21,30⟩,⟨31,62⟩,⟨3,1080762388818297338073⟩,⟨72,101⟩]
private def b8205 : Box := ![⟨18,19⟩,⟨21,30⟩,⟨31,62⟩,⟨3,55⟩,⟨73,101⟩]
private def b8220 : Box := ![⟨20,22⟩,⟨21,30⟩,⟨31,62⟩,⟨3,55⟩,⟨73,101⟩]
private def b8223 : Box := ![⟨18,22⟩,⟨21,30⟩,⟨63,1920000000000000011376⟩,⟨3,1080762388818297338073⟩,⟨72,101⟩]
theorem deny5_11 : Deny 5 11 ![⟨15,22⟩,⟨15,30⟩,⟨7,1920000000000000011376⟩,⟨1,1920000000000000011376⟩,⟨53,101⟩] := by
  have e7549 : Deny 5 11 b7549 := by
    apply closeAction rule_sound _ _ 64 [0x30f8dc70f8de3243e37da3238de3]
    decide +kernel
  have e7558 : Deny 5 11 b7558 := by
    apply closeAction rule_sound _ _ 64 [0xc32031c30b8df6d472430f8d88df6204]
    decide +kernel
  have e7571 : Deny 5 11 b7571 := by
    apply closeAction rule_sound _ _ 64 [0x30f8dc80f8dc90f8df6d470f8df6236d44]
    decide +kernel
  have e7557 : Deny 5 11 b7557 :=
    branchAction rule_sound _ _ 1
      0xb b7557 b7558 b7571 (by decide +kernel) e7558 e7571
  have e7581 : Deny 5 11 b7581 := by
    apply closeAction rule_sound _ _ 64 [0xf8dc40c4238dc38c70c38c78c90c38c70e3263204]
    decide +kernel
  have e7596 : Deny 5 11 b7596 := by
    apply closeAction rule_sound _ _ 64 [0xc38c80e31c30f8df6d631e32430f8de3243e37db58c7e368c88c4]
    decide +kernel
  have e7580 : Deny 5 11 b7580 :=
    branchAction rule_sound _ _ 1
      0xb b7580 b7581 b7596 (by decide +kernel) e7581 e7596
  have e7556 : Deny 5 11 b7556 :=
    branchAction rule_sound _ _ 1
      0xa b7556 b7557 b7580 (by decide +kernel) e7557 e7580
  have e7548 : Deny 5 11 b7548 :=
    branchAction rule_sound _ _ 2
      0x1e3 b7548 b7549 b7556 (by decide +kernel) e7549 e7556
  have e7614 : Deny 5 11 b7614 := by
    apply closeAction rule_sound _ _ 64 [0x2e37db5884]
    decide +kernel
  have e7616 : Deny 5 11 b7616 := by
    apply closeAction rule_sound _ _ 64 [0x3e37db5]
    decide +kernel
  have e7617 : Deny 5 11 b7617 := by
    apply closeAction rule_sound _ _ 64 [0x160f8da2236088df61160e2203de22030f8d88dc910b]
    decide +kernel
  have e7615 : Deny 5 11 b7615 :=
    branchAction rule_sound _ _ 3
      0x7884 b7615 b7616 b7617 (by decide +kernel) e7616 e7617
  have e7613 : Deny 5 11 b7613 :=
    branchAction rule_sound _ _ 3
      0x8e22 b7613 b7614 b7615 (by decide +kernel) e7614 e7615
  have e7635 : Deny 5 11 b7635 := by
    apply closeAction rule_sound _ _ 64 [0x30f8de3203e37da31e3]
    decide +kernel
  have e7641 : Deny 5 11 b7641 := by
    apply closeAction rule_sound _ _ 64 [0x30f8be2222]
    decide +kernel
  have e7646 : Deny 5 11 b7646 := by
    apply closeAction rule_sound _ _ 64 [0x20af884238def0f8dc31e325cbdcbe326f0e32631e3]
    decide +kernel
  have e7659 : Deny 5 11 b7659 := by
    apply closeAction rule_sound _ _ 64 [0x14e37bc20e2107e370c78c9]
    decide +kernel
  have e7645 : Deny 5 11 b7645 :=
    branchAction rule_sound _ _ 1
      0x8 b7645 b7646 b7659 (by decide +kernel) e7646 e7659
  have e7667 : Deny 5 11 b7667 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdcbe326f0c3dc78c972f72f8c9df61e3]
    decide +kernel
  have e7678 : Deny 5 11 b7678 := by
    apply closeAction rule_sound _ _ 64 [0x538def0f8dc38c78c972f72f8c9bc3de3247]
    decide +kernel
  have e7666 : Deny 5 11 b7666 :=
    branchAction rule_sound _ _ 3
      0x88c4 b7666 b7667 b7678 (by decide +kernel) e7667 e7678
  have e7644 : Deny 5 11 b7644 :=
    branchAction rule_sound _ _ 1
      0xb b7644 b7645 b7666 (by decide +kernel) e7645 e7666
  have e7640 : Deny 5 11 b7640 :=
    branchAction rule_sound _ _ 1
      0xa b7640 b7641 b7644 (by decide +kernel) e7641 e7644
  have e7634 : Deny 5 11 b7634 :=
    branchAction rule_sound _ _ 2
      0x263 b7634 b7635 b7640 (by decide +kernel) e7635 e7640
  have e7692 : Deny 5 11 b7692 := by
    apply closeAction rule_sound _ _ 64 [0xf8dc31c30c92030f6207]
    decide +kernel
  have e7703 : Deny 5 11 b7703 := by
    apply closeAction rule_sound _ _ 64 [0x30c70c32480c22361c4]
    decide +kernel
  have e7691 : Deny 5 11 b7691 :=
    branchAction rule_sound _ _ 1
      0xb b7691 b7692 b7703 (by decide +kernel) e7692 e7703
  have e7715 : Deny 5 11 b7715 := by
    apply closeAction rule_sound _ _ 64 [0x83109e370f8dc38c98c80c38c88c7]
    decide +kernel
  have e7726 : Deny 5 11 b7726 := by
    apply closeAction rule_sound _ _ 64 [0x3e370e31c30e32632030f68c88c78c4]
    decide +kernel
  have e7714 : Deny 5 11 b7714 :=
    branchAction rule_sound _ _ 1
      0xb b7714 b7715 b7726 (by decide +kernel) e7715 e7726
  have e7690 : Deny 5 11 b7690 :=
    branchAction rule_sound _ _ 2
      0x2a3 b7690 b7691 b7714 (by decide +kernel) e7691 e7714
  have e7739 : Deny 5 11 b7739 := by
    apply closeAction rule_sound _ _ 64 [0x838841f8dc38880c3e378888871020e2107e370e22222e2]
    decide +kernel
  have e7754 : Deny 5 11 b7754 := by
    apply closeAction rule_sound _ _ 64 [0x2083887884238de31020e2108e370f8bc38c98c88c41f8]
    decide +kernel
  have e7738 : Deny 5 11 b7738 :=
    branchAction rule_sound _ _ 2
      0x2a3 b7738 b7739 b7754 (by decide +kernel) e7739 e7754
  have e7767 : Deny 5 11 b7767 := by
    apply closeAction rule_sound _ _ 64 [0x538def]
    decide +kernel
  have e7737 : Deny 5 11 b7737 :=
    branchAction rule_sound _ _ 1
      0x9 b7737 b7738 b7767 (by decide +kernel) e7738 e7767
  have e7689 : Deny 5 11 b7689 :=
    branchAction rule_sound _ _ 1
      0x9 b7689 b7690 b7737 (by decide +kernel) e7690 e7737
  have e7633 : Deny 5 11 b7633 :=
    branchAction rule_sound _ _ 2
      0x204 b7633 b7634 b7689 (by decide +kernel) e7634 e7689
  have e7770 : Deny 5 11 b7770 := by
    apply closeAction rule_sound _ _ 64 [0xf8df6d62]
    decide +kernel
  have e7772 : Deny 5 11 b7772 := by
    apply closeAction rule_sound _ _ 64 [0xc3e378c9102238da3]
    decide +kernel
  have e7779 : Deny 5 11 b7779 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdc26f0c21c4088e23242be22821e3]
    decide +kernel
  have e7793 : Deny 5 11 b7793 := by
    apply closeAction rule_sound _ _ 64 [0x72f8c472f8c4278df6]
    decide +kernel
  have e7796 : Deny 5 11 b7796 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdcbe326f71c0c3e361e22a22a324388a]
    decide +kernel
  have e7792 : Deny 5 11 b7792 :=
    branchAction rule_sound _ _ 1
      0x7 b7792 b7793 b7796 (by decide +kernel) e7793 e7796
  have e7778 : Deny 5 11 b7778 :=
    branchAction rule_sound _ _ 1
      0x8 b7778 b7779 b7792 (by decide +kernel) e7779 e7792
  have e7809 : Deny 5 11 b7809 := by
    apply closeAction rule_sound _ _ 64 [0x1c723243e3688a0af88a738df61c21c22368c4]
    decide +kernel
  have e7777 : Deny 5 11 b7777 :=
    branchAction rule_sound _ _ 1
      0xb b7777 b7778 b7809 (by decide +kernel) e7778 e7809
  have e7771 : Deny 5 11 b7771 :=
    branchAction rule_sound _ _ 1
      0x9 b7771 b7772 b7777 (by decide +kernel) e7772 e7777
  have e7769 : Deny 5 11 b7769 :=
    branchAction rule_sound _ _ 3
      0xada3 b7769 b7770 b7771 (by decide +kernel) e7770 e7771
  have e7824 : Deny 5 11 b7824 := by
    apply closeAction rule_sound _ _ 64 [0x30c70c3e378c98c80c2238df61e3]
    decide +kernel
  have e7835 : Deny 5 11 b7835 := by
    apply closeAction rule_sound _ _ 64 [0x30f8df68c70f8df68c8087df68c4]
    decide +kernel
  have e7823 : Deny 5 11 b7823 :=
    branchAction rule_sound _ _ 2
      0x2e3 b7823 b7824 b7835 (by decide +kernel) e7824 e7835
  have e7844 : Deny 5 11 b7844 := by
    apply closeAction rule_sound _ _ 64 [0xf8dc31c38880c4088e37d621e2]
    decide +kernel
  have e7855 : Deny 5 11 b7855 := by
    apply closeAction rule_sound _ _ 64 [0x72f72f8c90c40f7da3109e23243e37da22a3]
    decide +kernel
  have e7864 : Deny 5 11 b7864 := by
    apply closeAction rule_sound _ _ 64 [0x2be310272f0e326f8c8be3109e231142b80c38c88c9]
    decide +kernel
  have e7854 : Deny 5 11 b7854 :=
    branchAction rule_sound _ _ 2
      0x223 b7854 b7855 b7864 (by decide +kernel) e7855 e7864
  have e7878 : Deny 5 11 b7878 := by
    apply closeAction rule_sound _ _ 64 [0x2be311cbe3109e2f0f8dc3bc70e3263263]
    decide +kernel
  have e7887 : Deny 5 11 b7887 := by
    apply closeAction rule_sound _ _ 64 [0x820f8dc38c81e3109e37]
    decide +kernel
  have e7877 : Deny 5 11 b7877 :=
    branchAction rule_sound _ _ 1
      0x8 b7877 b7878 b7887 (by decide +kernel) e7878 e7887
  have e7853 : Deny 5 11 b7853 :=
    branchAction rule_sound _ _ 1
      0x7 b7853 b7854 b7877 (by decide +kernel) e7854 e7877
  have e7843 : Deny 5 11 b7843 :=
    branchAction rule_sound _ _ 1
      0xa b7843 b7844 b7853 (by decide +kernel) e7844 e7853
  have e7895 : Deny 5 11 b7895 := by
    apply closeAction rule_sound _ _ 64 [0x72f72f8c9bdc0f7da210ae368c90a229ce37da3237da3]
    decide +kernel
  have e7907 : Deny 5 11 b7907 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdcbe326f0c3e2325ce37d878c90a22a3]
    decide +kernel
  have e7919 : Deny 5 11 b7919 := by
    apply closeAction rule_sound _ _ 64 [0x3e370e32030e32070c3e37da21e22a3]
    decide +kernel
  have e7930 : Deny 5 11 b7930 := by
    apply closeAction rule_sound _ _ 64 [0x14e370af8c409cbc38c9be322f8c427850a1ef]
    decide +kernel
  have e7918 : Deny 5 11 b7918 :=
    branchAction rule_sound _ _ 1
      0x9 b7918 b7919 b7930 (by decide +kernel) e7919 e7930
  have e7906 : Deny 5 11 b7906 :=
    branchAction rule_sound _ _ 1
      0x8 b7906 b7907 b7918 (by decide +kernel) e7907 e7918
  have e7894 : Deny 5 11 b7894 :=
    branchAction rule_sound _ _ 3
      0x78c4 b7894 b7895 b7906 (by decide +kernel) e7895 e7906
  have e7842 : Deny 5 11 b7842 :=
    branchAction rule_sound _ _ 1
      0xb b7842 b7843 b7894 (by decide +kernel) e7843 e7894
  have e7822 : Deny 5 11 b7822 :=
    branchAction rule_sound _ _ 1
      0x9 b7822 b7823 b7842 (by decide +kernel) e7823 e7842
  have e7768 : Deny 5 11 b7768 :=
    branchAction rule_sound _ _ 3
      0x88c4 b7768 b7769 b7822 (by decide +kernel) e7769 e7822
  have e7632 : Deny 5 11 b7632 :=
    branchAction rule_sound _ _ 1
      0xb b7632 b7633 b7768 (by decide +kernel) e7633 e7768
  have e7612 : Deny 5 11 b7612 :=
    branchAction rule_sound _ _ 2
      0x2a3 b7612 b7613 b7632 (by decide +kernel) e7613 e7632
  have e7944 : Deny 5 11 b7944 := by
    apply closeAction rule_sound _ _ 64 [0x30c90e22038870c3e36888de21e2]
    decide +kernel
  have e7957 : Deny 5 11 b7957 := by
    apply closeAction rule_sound _ _ 64 [0x583888dc38880c3209]
    decide +kernel
  have e7966 : Deny 5 11 b7966 := by
    apply closeAction rule_sound _ _ 64 [0x583888dc38880c3dc8244]
    decide +kernel
  have e7956 : Deny 5 11 b7956 :=
    branchAction rule_sound _ _ 2
      0x2e2 b7956 b7957 b7966 (by decide +kernel) e7957 e7966
  have e7976 : Deny 5 11 b7976 := by
    apply closeAction rule_sound _ _ 64 [0x20838878842388820c41f80c8277]
    decide +kernel
  have e7987 : Deny 5 11 b7987 := by
    apply closeAction rule_sound _ _ 64 [0x83e03887888dc3e031f70c8244]
    decide +kernel
  have e7975 : Deny 5 11 b7975 :=
    branchAction rule_sound _ _ 1
      0xb b7975 b7976 b7987 (by decide +kernel) e7976 e7987
  have e7955 : Deny 5 11 b7955 :=
    branchAction rule_sound _ _ 1
      0x7 b7955 b7956 b7975 (by decide +kernel) e7956 e7975
  have e7943 : Deny 5 11 b7943 :=
    branchAction rule_sound _ _ 2
      0x204 b7943 b7944 b7955 (by decide +kernel) e7944 e7955
  have e7999 : Deny 5 11 b7999 := by
    apply closeAction rule_sound _ _ 64 [0xc3e37243e37da22021e2]
    decide +kernel
  have e8008 : Deny 5 11 b8008 := by
    apply closeAction rule_sound _ _ 64 [0x30e2203de22030f8d88dc9]
    decide +kernel
  have e8017 : Deny 5 11 b8017 := by
    apply closeAction rule_sound _ _ 64 [0xc3de2203dc90b8df6888d84]
    decide +kernel
  have e8007 : Deny 5 11 b8007 :=
    branchAction rule_sound _ _ 2
      0x2e2 b8007 b8008 b8017 (by decide +kernel) e8008 e8017
  have e8025 : Deny 5 11 b8025 := by
    apply closeAction rule_sound _ _ 64 [0x583e03887888dc30c98880c31c3209]
    decide +kernel
  have e8040 : Deny 5 11 b8040 := by
    apply closeAction rule_sound _ _ 64 [0x16dc3dc38878880c32622030f71c3dc8244]
    decide +kernel
  have e8024 : Deny 5 11 b8024 :=
    branchAction rule_sound _ _ 1
      0xb b8024 b8025 b8040 (by decide +kernel) e8025 e8040
  have e8006 : Deny 5 11 b8006 :=
    branchAction rule_sound _ _ 1
      0x7 b8006 b8007 b8024 (by decide +kernel) e8007 e8024
  have e7998 : Deny 5 11 b7998 :=
    branchAction rule_sound _ _ 2
      0x204 b7998 b7999 b8006 (by decide +kernel) e7999 e8006
  have e7942 : Deny 5 11 b7942 :=
    branchAction rule_sound _ _ 2
      0x2e2 b7942 b7943 b7998 (by decide +kernel) e7943 e7998
  have e8058 : Deny 5 11 b8058 := by
    apply closeAction rule_sound _ _ 64 [0x3e370c8dc31c30e32231e3]
    decide +kernel
  have e8067 : Deny 5 11 b8067 := by
    apply closeAction rule_sound _ _ 64 [0x2be2083884238dc20f8dc31e32380e22a31e3277]
    decide +kernel
  have e8057 : Deny 5 11 b8057 :=
    branchAction rule_sound _ _ 2
      0x263 b8057 b8058 b8067 (by decide +kernel) e8058 e8067
  have e8080 : Deny 5 11 b8080 := by
    apply closeAction rule_sound _ _ 64 [0x82083109e370f8dc3dc9207109e37]
    decide +kernel
  have e8056 : Deny 5 11 b8056 :=
    branchAction rule_sound _ _ 3
      0x88c4 b8056 b8057 b8080 (by decide +kernel) e8057 e8080
  have e8093 : Deny 5 11 b8093 := by
    apply closeAction rule_sound _ _ 64 [0xc38c80e31c3103e37da3108e231e3]
    decide +kernel
  have e8104 : Deny 5 11 b8104 := by
    apply closeAction rule_sound _ _ 64 [0x3e22]
    decide +kernel
  have e8106 : Deny 5 11 b8106 := by
    apply closeAction rule_sound _ _ 64 [0x2bc3e370c78c972f72f8c9bc30c78c98c8]
    decide +kernel
  have e8120 : Deny 5 11 b8120 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdcbe3243087e368c90f8df688ada3]
    decide +kernel
  have e8129 : Deny 5 11 b8129 := by
    apply closeAction rule_sound _ _ 64 [0x72f72f8c9bc30c78c9]
    decide +kernel
  have e8119 : Deny 5 11 b8119 :=
    branchAction rule_sound _ _ 3
      0x88c4 b8119 b8120 b8129 (by decide +kernel) e8120 e8129
  have e8105 : Deny 5 11 b8105 :=
    branchAction rule_sound _ _ 1
      0xb b8105 b8106 b8119 (by decide +kernel) e8106 e8119
  have e8103 : Deny 5 11 b8103 :=
    branchAction rule_sound _ _ 1
      0xa b8103 b8104 b8105 (by decide +kernel) e8104 e8105
  have e8137 : Deny 5 11 b8137 := by
    apply closeAction rule_sound _ _ 64 [0xaf0838841f8dc20e2238dc40e3107e0388a8c88c9]
    decide +kernel
  have e8151 : Deny 5 11 b8151 := by
    apply closeAction rule_sound _ _ 64 [0x72f72f8c9bc30c70c78c90e22a3]
    decide +kernel
  have e8162 : Deny 5 11 b8162 := by
    apply closeAction rule_sound _ _ 64 [0x2be20838c41f80e22a3277]
    decide +kernel
  have e8150 : Deny 5 11 b8150 :=
    branchAction rule_sound _ _ 3
      0x88c4 b8150 b8151 b8162 (by decide +kernel) e8151 e8162
  have e8136 : Deny 5 11 b8136 :=
    branchAction rule_sound _ _ 1
      0xb b8136 b8137 b8150 (by decide +kernel) e8137 e8150
  have e8102 : Deny 5 11 b8102 :=
    branchAction rule_sound _ _ 1
      0x7 b8102 b8103 b8136 (by decide +kernel) e8103 e8136
  have e8092 : Deny 5 11 b8092 :=
    branchAction rule_sound _ _ 2
      0x263 b8092 b8093 b8102 (by decide +kernel) e8093 e8102
  have e8171 : Deny 5 11 b8171 := by
    apply closeAction rule_sound _ _ 64 [0xc38c80c3de3263223103dc38c80c38c98c82e3]
    decide +kernel
  have e8187 : Deny 5 11 b8187 := by
    apply closeAction rule_sound _ _ 64 [0x20c41f8dc3e370c8237]
    decide +kernel
  have e8194 : Deny 5 11 b8194 := by
    apply closeAction rule_sound _ _ 64 [0x20c4278dc31f70c38c88c88c4]
    decide +kernel
  have e8186 : Deny 5 11 b8186 :=
    branchAction rule_sound _ _ 1
      0xb b8186 b8187 b8194 (by decide +kernel) e8187 e8194
  have e8170 : Deny 5 11 b8170 :=
    branchAction rule_sound _ _ 2
      0x1e3 b8170 b8171 b8186 (by decide +kernel) e8171 e8186
  have e8205 : Deny 5 11 b8205 := by
    apply closeAction rule_sound _ _ 64 [0x20e21f7083108e370e324388a8c88c4083888dc42e3]
    decide +kernel
  have e8220 : Deny 5 11 b8220 := by
    apply closeAction rule_sound _ _ 64 [0x20e2108e37]
    decide +kernel
  have e8204 : Deny 5 11 b8204 :=
    branchAction rule_sound _ _ 3
      0x78c4 b8204 b8205 b8220 (by decide +kernel) e8205 e8220
  have e8223 : Deny 5 11 b8223 := by
    apply closeAction rule_sound _ _ 64 [0x538def8c4]
    decide +kernel
  have e8203 : Deny 5 11 b8203 :=
    branchAction rule_sound _ _ 2
      0x278 b8203 b8204 b8223 (by decide +kernel) e8204 e8223
  have e8169 : Deny 5 11 b8169 :=
    branchAction rule_sound _ _ 1
      0x9 b8169 b8170 b8203 (by decide +kernel) e8170 e8203
  have e8091 : Deny 5 11 b8091 :=
    branchAction rule_sound _ _ 3
      0x88c4 b8091 b8092 b8169 (by decide +kernel) e8092 e8169
  have e8055 : Deny 5 11 b8055 :=
    branchAction rule_sound _ _ 1
      0xb b8055 b8056 b8091 (by decide +kernel) e8056 e8091
  have e7941 : Deny 5 11 b7941 :=
    branchAction rule_sound _ _ 1
      0xa b7941 b7942 b8055 (by decide +kernel) e7942 e8055
  have e7611 : Deny 5 11 b7611 :=
    branchAction rule_sound _ _ 1
      0x7 b7611 b7612 b7941 (by decide +kernel) e7612 e7941
  have e7547 : Deny 5 11 b7547 :=
    branchAction rule_sound _ _ 2
      0x263 b7547 b7548 b7611 (by decide +kernel) e7548 e7611
  exact e7547
end OMA.Blocks5_11_245212.S7547
