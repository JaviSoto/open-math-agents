import FastReplay245212
import SparseDigit245212
import FastRound245212
import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S15874
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b15874 : Box := ![⟨31,46⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨1,994807017543859655053⟩,⟨103,999999999999999999⟩]
private def b15875 : Box := ![⟨31,46⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨1,994807017543859655053⟩,⟨103,206⟩]
private def b15876 : Box := ![⟨31,46⟩,⟨10,14⟩,⟨15,30⟩,⟨1,994807017543859655045⟩,⟨103,199⟩]
private def b15877 : Box := ![⟨31,46⟩,⟨10,11⟩,⟨15,30⟩,⟨1,34⟩,⟨103,199⟩]
private def b15878 : Box := ![⟨31,37⟩,⟨10,11⟩,⟨15,30⟩,⟨1,33⟩,⟨103,199⟩]
private def b15883 : Box := ![⟨38,46⟩,⟨10,11⟩,⟨15,30⟩,⟨1,33⟩,⟨103,199⟩]
private def b15884 : Box := ![⟨38,46⟩,⟨10,11⟩,⟨15,30⟩,⟨1,33⟩,⟨103,135⟩]
private def b15897 : Box := ![⟨38,46⟩,⟨10,11⟩,⟨15,30⟩,⟨1,33⟩,⟨136,199⟩]
private def b15902 : Box := ![⟨31,46⟩,⟨12,14⟩,⟨15,30⟩,⟨1,34⟩,⟨103,199⟩]
private def b15903 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨15,30⟩,⟨1,34⟩,⟨103,199⟩]
private def b15904 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨15,30⟩,⟨1,32⟩,⟨103,135⟩]
private def b15905 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨15,30⟩,⟨1,2⟩,⟨103,131⟩]
private def b15912 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨15,30⟩,⟨3,32⟩,⟨103,131⟩]
private def b15921 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨15,30⟩,⟨1,32⟩,⟨136,199⟩]
private def b15928 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨15,30⟩,⟨1,34⟩,⟨103,199⟩]
private def b15929 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨15,30⟩,⟨1,34⟩,⟨103,135⟩]
private def b15930 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨15,30⟩,⟨1,2⟩,⟨103,131⟩]
private def b15939 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨15,30⟩,⟨3,34⟩,⟨103,131⟩]
private def b15946 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨15,30⟩,⟨1,34⟩,⟨136,199⟩]
private def b15947 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨15,30⟩,⟨1,2⟩,⟨137,199⟩]
private def b15956 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨15,30⟩,⟨3,32⟩,⟨137,199⟩]
private def b15965 : Box := ![⟨31,46⟩,⟨10,14⟩,⟨31,1920000000000000011376⟩,⟨1,994807017543859655045⟩,⟨103,199⟩]
private def b15966 : Box := ![⟨31,46⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨1,994807017543859655045⟩,⟨103,199⟩]
private def b15967 : Box := ![⟨31,37⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨1,994807017543859655044⟩,⟨103,199⟩]
private def b15968 : Box := ![⟨31,37⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨1,2⟩,⟨103,199⟩]
private def b15969 : Box := ![⟨31,37⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655042⟩,⟨103,199⟩]
private def b15970 : Box := ![⟨31,37⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655042⟩,⟨103,135⟩]
private def b15971 : Box := ![⟨31,37⟩,⟨10,11⟩,⟨31,62⟩,⟨3,994807017543859655042⟩,⟨103,131⟩]
private def b15982 : Box := ![⟨31,37⟩,⟨10,11⟩,⟨63,1920000000000000011376⟩,⟨3,994807017543859655042⟩,⟨103,131⟩]
private def b15987 : Box := ![⟨31,37⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655042⟩,⟨136,199⟩]
private def b15988 : Box := ![⟨31,37⟩,⟨10,11⟩,⟨31,62⟩,⟨3,936740088105726877821⟩,⟨137,199⟩]
private def b15995 : Box := ![⟨31,37⟩,⟨10,11⟩,⟨63,1920000000000000011376⟩,⟨3,936740088105726877821⟩,⟨137,199⟩]
private def b16004 : Box := ![⟨38,46⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨1,994807017543859655044⟩,⟨103,199⟩]
private def b16005 : Box := ![⟨38,46⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨1,2⟩,⟨103,199⟩]
private def b16008 : Box := ![⟨38,46⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655044⟩,⟨103,199⟩]
private def b16009 : Box := ![⟨38,46⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655044⟩,⟨103,135⟩]
private def b16010 : Box := ![⟨38,46⟩,⟨10,11⟩,⟨31,62⟩,⟨3,994807017543859655044⟩,⟨103,131⟩]
private def b16025 : Box := ![⟨38,46⟩,⟨10,11⟩,⟨63,1920000000000000011376⟩,⟨3,994807017543859655044⟩,⟨103,131⟩]
private def b16026 : Box := ![⟨38,46⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655044⟩,⟨136,199⟩]
private def b16027 : Box := ![⟨38,46⟩,⟨10,11⟩,⟨31,62⟩,⟨3,936740088105726877823⟩,⟨137,199⟩]
private def b16028 : Box := ![⟨38,46⟩,⟨10,11⟩,⟨31,62⟩,⟨3,47⟩,⟨137,162⟩]
private def b16041 : Box := ![⟨38,46⟩,⟨10,11⟩,⟨31,62⟩,⟨3,47⟩,⟨163,199⟩]
private def b16054 : Box := ![⟨38,46⟩,⟨10,11⟩,⟨63,1920000000000000011376⟩,⟨3,936740088105726877823⟩,⟨137,199⟩]
private def b16067 : Box := ![⟨31,46⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨1,994807017543859655045⟩,⟨103,199⟩]
private def b16068 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨1,994807017543859655045⟩,⟨103,199⟩]
private def b16069 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨1,2⟩,⟨103,199⟩]
private def b16072 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655043⟩,⟨103,199⟩]
private def b16073 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655043⟩,⟨103,135⟩]
private def b16084 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655043⟩,⟨136,199⟩]
private def b16085 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨31,62⟩,⟨3,936740088105726877822⟩,⟨137,199⟩]
private def b16098 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨63,1920000000000000011376⟩,⟨3,936740088105726877822⟩,⟨137,199⟩]
private def b16105 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨1,994807017543859655045⟩,⟨103,199⟩]
private def b16106 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨31,62⟩,⟨1,14⟩,⟨107,199⟩]
private def b16121 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨63,1920000000000000011376⟩,⟨1,14⟩,⟨107,199⟩]
private def b16122 : Box := ![⟨31,46⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨1,994807017543859655053⟩,⟨207,999999999999999999⟩]
private def b16123 : Box := ![⟨31,46⟩,⟨10,14⟩,⟨15,30⟩,⟨1,864390243902439029543⟩,⟨207,999999999999999999⟩]
private def b16124 : Box := ![⟨31,46⟩,⟨10,11⟩,⟨15,30⟩,⟨1,36⟩,⟨207,999999999999999999⟩]
private def b16129 : Box := ![⟨31,46⟩,⟨12,14⟩,⟨15,30⟩,⟨1,36⟩,⟨207,999999999999999999⟩]
private def b16130 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨15,30⟩,⟨1,36⟩,⟨207,999999999999999999⟩]
private def b16137 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨15,30⟩,⟨1,36⟩,⟨207,999999999999999999⟩]
private def b16138 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨15,30⟩,⟨1,36⟩,⟨207,414⟩]
private def b16147 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨15,30⟩,⟨1,36⟩,⟨415,999999999999999999⟩]
private def b16154 : Box := ![⟨31,46⟩,⟨10,14⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029543⟩,⟨207,999999999999999999⟩]
private def b16155 : Box := ![⟨31,46⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029543⟩,⟨207,999999999999999999⟩]
private def b16156 : Box := ![⟨31,46⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨1,2⟩,⟨207,1024⟩]
private def b16157 : Box := ![⟨31,46⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,864390243902439029542⟩,⟨207,1024⟩]
private def b16158 : Box := ![⟨31,37⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,864390243902439029536⟩,⟨207,1024⟩]
private def b16161 : Box := ![⟨38,46⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,864390243902439029536⟩,⟨207,1024⟩]
private def b16162 : Box := ![⟨38,46⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,864390243902439029536⟩,⟨207,344⟩]
private def b16163 : Box := ![⟨38,46⟩,⟨10,11⟩,⟨31,62⟩,⟨3,864390243902439029536⟩,⟨207,344⟩]
private def b16172 : Box := ![⟨38,46⟩,⟨10,11⟩,⟨63,1920000000000000011376⟩,⟨3,864390243902439029536⟩,⟨207,344⟩]
private def b16185 : Box := ![⟨38,46⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,864390243902439029536⟩,⟨345,1024⟩]
private def b16186 : Box := ![⟨38,46⟩,⟨10,10⟩,⟨46,1920000000000000011376⟩,⟨3,788285449490268772070⟩,⟨345,1024⟩]
private def b16187 : Box := ![⟨38,46⟩,⟨11,11⟩,⟨46,1920000000000000011376⟩,⟨3,788285449490268772070⟩,⟨345,1024⟩]
private def b16202 : Box := ![⟨31,46⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029543⟩,⟨207,999999999999999999⟩]
private def b16203 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029543⟩,⟨207,999999999999999999⟩]
private def b16204 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029541⟩,⟨207,414⟩]
private def b16205 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨31,62⟩,⟨1,864390243902439029535⟩,⟨207,414⟩]
private def b16206 : Box := ![⟨31,37⟩,⟨12,12⟩,⟨31,62⟩,⟨1,42⟩,⟨207,414⟩]
private def b16211 : Box := ![⟨31,37⟩,⟨13,14⟩,⟨31,62⟩,⟨1,42⟩,⟨207,414⟩]
private def b16222 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨63,1920000000000000011376⟩,⟨1,864390243902439029535⟩,⟨207,414⟩]
private def b16235 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029541⟩,⟨415,999999999999999999⟩]
private def b16236 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨1,2⟩,⟨415,999999999999999999⟩]
private def b16237 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨3,764204851752021567896⟩,⟨415,999999999999999999⟩]
private def b16238 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨31,62⟩,⟨3,764204851752021567896⟩,⟨415,999999999999999999⟩]
private def b16247 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨63,1920000000000000011376⟩,⟨3,764204851752021567896⟩,⟨415,999999999999999999⟩]
private def b16248 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨63,1920000000000000011376⟩,⟨3,6⟩,⟨415,999999999999999999⟩]
private def b16249 : Box := ![⟨31,37⟩,⟨12,14⟩,⟨63,1920000000000000011376⟩,⟨7,764204851752021567896⟩,⟨415,999999999999999999⟩]
private def b16250 : Box := ![⟨31,37⟩,⟨12,12⟩,⟨63,1920000000000000011376⟩,⟨7,764204851752021567896⟩,⟨415,999999999999999999⟩]
private def b16253 : Box := ![⟨31,37⟩,⟨13,14⟩,⟨63,1920000000000000011376⟩,⟨7,764204851752021567896⟩,⟨415,999999999999999999⟩]
private def b16254 : Box := ![⟨31,33⟩,⟨13,14⟩,⟨63,1920000000000000011376⟩,⟨7,764204851752021567896⟩,⟨415,999999999999999999⟩]
private def b16261 : Box := ![⟨34,37⟩,⟨13,14⟩,⟨63,1920000000000000011376⟩,⟨7,764204851752021567896⟩,⟨415,999999999999999999⟩]
private def b16262 : Box := ![⟨34,37⟩,⟨13,14⟩,⟨63,1920000000000000011376⟩,⟨7,764204851752021567896⟩,⟨415,830⟩]
private def b16269 : Box := ![⟨34,37⟩,⟨13,14⟩,⟨63,1920000000000000011376⟩,⟨7,764204851752021567896⟩,⟨831,999999999999999999⟩]
private def b16270 : Box := ![⟨34,37⟩,⟨13,14⟩,⟨63,126⟩,⟨7,685382755842062856622⟩,⟨831,999999999999999999⟩]
private def b16275 : Box := ![⟨34,37⟩,⟨13,14⟩,⟨127,1920000000000000011376⟩,⟨7,685382755842062856622⟩,⟨831,999999999999999999⟩]
private def b16276 : Box := ![⟨34,37⟩,⟨13,14⟩,⟨127,1920000000000000011376⟩,⟨7,685382755842062856622⟩,⟨831,1662⟩]
private def b16277 : Box := ![⟨34,37⟩,⟨13,14⟩,⟨127,1920000000000000011376⟩,⟨7,685382755842062856622⟩,⟨1663,999999999999999999⟩]
private def b16278 : Box := ![⟨34,37⟩,⟨13,14⟩,⟨127,1920000000000000011376⟩,⟨7,621300219138056979597⟩,⟨1663,3326⟩]
private def b16279 : Box := ![⟨34,37⟩,⟨13,14⟩,⟨127,1920000000000000011376⟩,⟨7,621300219138056979597⟩,⟨3327,999999999999999999⟩]
private def b16280 : Box := ![⟨34,37⟩,⟨13,13⟩,⟨127,1920000000000000011376⟩,⟨7,568176352705410825029⟩,⟨3327,999999999999999999⟩]
private def b16281 : Box := ![⟨34,37⟩,⟨14,14⟩,⟨127,1920000000000000011376⟩,⟨7,568176352705410825029⟩,⟨3327,999999999999999999⟩]
private def b16282 : Box := ![⟨34,37⟩,⟨14,14⟩,⟨127,1920000000000000011376⟩,⟨7,568176352705410825029⟩,⟨3327,6654⟩]
private def b16283 : Box := ![⟨34,37⟩,⟨14,14⟩,⟨127,1920000000000000011376⟩,⟨7,568176352705410825029⟩,⟨6655,999999999999999999⟩]
private def b16284 : Box := ![⟨34,37⟩,⟨14,14⟩,⟨127,1920000000000000011376⟩,⟨7,523421538461538464657⟩,⟨6655,13310⟩]
private def b16285 : Box := ![⟨34,37⟩,⟨14,14⟩,⟨127,1920000000000000011376⟩,⟨7,523421538461538464657⟩,⟨13311,999999999999999999⟩]
private def b16286 : Box := ![⟨34,37⟩,⟨14,14⟩,⟨127,1920000000000000011376⟩,⟨7,485202509982886483211⟩,⟨13311,26622⟩]
private def b16287 : Box := ![⟨34,37⟩,⟨14,14⟩,⟨127,1920000000000000011376⟩,⟨7,485202509982886483211⟩,⟨26623,999999999999999999⟩]
private def b16302 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029543⟩,⟨207,999999999999999999⟩]
private def b16303 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029543⟩,⟨207,414⟩]
private def b16304 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨31,62⟩,⟨1,864390243902439029537⟩,⟨207,414⟩]
private def b16305 : Box := ![⟨38,46⟩,⟨12,12⟩,⟨31,62⟩,⟨1,44⟩,⟨207,414⟩]
private def b16314 : Box := ![⟨38,46⟩,⟨13,14⟩,⟨31,62⟩,⟨1,44⟩,⟨207,414⟩]
private def b16315 : Box := ![⟨38,46⟩,⟨13,14⟩,⟨31,62⟩,⟨1,44⟩,⟨207,276⟩]
private def b16320 : Box := ![⟨38,46⟩,⟨13,14⟩,⟨31,62⟩,⟨1,44⟩,⟨277,414⟩]
private def b16331 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨63,1920000000000000011376⟩,⟨1,864390243902439029537⟩,⟨207,414⟩]
private def b16340 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029543⟩,⟨415,999999999999999999⟩]
private def b16341 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨31,62⟩,⟨1,764204851752021567898⟩,⟨415,999999999999999999⟩]
private def b16342 : Box := ![⟨38,46⟩,⟨12,12⟩,⟨31,62⟩,⟨1,45⟩,⟨415,999999999999999999⟩]
private def b16349 : Box := ![⟨38,46⟩,⟨13,14⟩,⟨31,62⟩,⟨1,45⟩,⟨415,999999999999999999⟩]
private def b16350 : Box := ![⟨38,46⟩,⟨13,14⟩,⟨31,62⟩,⟨1,45⟩,⟨415,830⟩]
private def b16363 : Box := ![⟨38,46⟩,⟨13,14⟩,⟨31,62⟩,⟨1,45⟩,⟨831,999999999999999999⟩]
private def b16378 : Box := ![⟨38,46⟩,⟨12,14⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567898⟩,⟨415,999999999999999999⟩]
private def b16379 : Box := ![⟨38,46⟩,⟨12,12⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567898⟩,⟨415,999999999999999999⟩]
private def b16380 : Box := ![⟨38,46⟩,⟨12,12⟩,⟨63,1920000000000000011376⟩,⟨1,2⟩,⟨415,999999999999999999⟩]
private def b16381 : Box := ![⟨38,46⟩,⟨12,12⟩,⟨63,1920000000000000011376⟩,⟨3,764204851752021567897⟩,⟨415,999999999999999999⟩]
private def b16382 : Box := ![⟨38,46⟩,⟨12,12⟩,⟨63,1920000000000000011376⟩,⟨3,6⟩,⟨415,999999999999999999⟩]
private def b16383 : Box := ![⟨38,46⟩,⟨12,12⟩,⟨63,1920000000000000011376⟩,⟨7,764204851752021567897⟩,⟨415,999999999999999999⟩]
private def b16384 : Box := ![⟨38,46⟩,⟨12,12⟩,⟨63,1920000000000000011376⟩,⟨7,764204851752021567897⟩,⟨415,830⟩]
private def b16395 : Box := ![⟨38,46⟩,⟨12,12⟩,⟨63,1920000000000000011376⟩,⟨7,764204851752021567897⟩,⟨831,999999999999999999⟩]
private def b16396 : Box := ![⟨38,41⟩,⟨12,12⟩,⟨63,1920000000000000011376⟩,⟨7,685382755842062856623⟩,⟨831,999999999999999999⟩]
private def b16399 : Box := ![⟨42,46⟩,⟨12,12⟩,⟨63,1920000000000000011376⟩,⟨7,685382755842062856623⟩,⟨831,999999999999999999⟩]
private def b16400 : Box := ![⟨42,46⟩,⟨12,12⟩,⟨63,126⟩,⟨7,685382755842062856623⟩,⟨831,999999999999999999⟩]
private def b16405 : Box := ![⟨42,46⟩,⟨12,12⟩,⟨127,1920000000000000011376⟩,⟨7,685382755842062856623⟩,⟨831,999999999999999999⟩]
private def b16406 : Box := ![⟨42,46⟩,⟨12,12⟩,⟨127,1920000000000000011376⟩,⟨7,685382755842062856623⟩,⟨831,1662⟩]
private def b16407 : Box := ![⟨42,46⟩,⟨12,12⟩,⟨127,1920000000000000011376⟩,⟨7,685382755842062856623⟩,⟨1663,999999999999999999⟩]
private def b16408 : Box := ![⟨42,46⟩,⟨12,12⟩,⟨127,1920000000000000011376⟩,⟨7,621300219138056979598⟩,⟨1663,3326⟩]
private def b16409 : Box := ![⟨42,46⟩,⟨12,12⟩,⟨127,1920000000000000011376⟩,⟨7,621300219138056979598⟩,⟨3327,999999999999999999⟩]
private def b16410 : Box := ![⟨42,46⟩,⟨12,12⟩,⟨127,1920000000000000011376⟩,⟨7,568176352705410825030⟩,⟨3327,6654⟩]
private def b16411 : Box := ![⟨42,46⟩,⟨12,12⟩,⟨127,1920000000000000011376⟩,⟨7,568176352705410825030⟩,⟨6655,999999999999999999⟩]
private def b16412 : Box := ![⟨42,46⟩,⟨12,12⟩,⟨127,1920000000000000011376⟩,⟨7,523421538461538464658⟩,⟨6655,13310⟩]
private def b16413 : Box := ![⟨42,46⟩,⟨12,12⟩,⟨127,1920000000000000011376⟩,⟨7,523421538461538464658⟩,⟨13311,999999999999999999⟩]
private def b16414 : Box := ![⟨42,43⟩,⟨12,12⟩,⟨127,1920000000000000011376⟩,⟨7,485202509982886483211⟩,⟨13311,999999999999999999⟩]
private def b16415 : Box := ![⟨44,46⟩,⟨12,12⟩,⟨127,1920000000000000011376⟩,⟨7,485202509982886483211⟩,⟨13311,999999999999999999⟩]
private def b16416 : Box := ![⟨44,46⟩,⟨12,12⟩,⟨127,1920000000000000011376⟩,⟨7,485202509982886483211⟩,⟨13311,26622⟩]
private def b16417 : Box := ![⟨44,46⟩,⟨12,12⟩,⟨127,1920000000000000011376⟩,⟨7,485202509982886483211⟩,⟨26623,999999999999999999⟩]
private def b16418 : Box := ![⟨44,46⟩,⟨12,12⟩,⟨130,260⟩,⟨7,452185007974481661387⟩,⟨26623,999999999999999999⟩]
private def b16419 : Box := ![⟨44,44⟩,⟨12,12⟩,⟨130,260⟩,⟨7,73⟩,⟨26623,999999999999999999⟩]
private def b16420 : Box := ![⟨45,46⟩,⟨12,12⟩,⟨130,260⟩,⟨7,73⟩,⟨26623,999999999999999999⟩]
private def b16421 : Box := ![⟨45,46⟩,⟨12,12⟩,⟨130,260⟩,⟨7,73⟩,⟨26623,53246⟩]
private def b16422 : Box := ![⟨45,46⟩,⟨12,12⟩,⟨130,260⟩,⟨7,73⟩,⟨53247,999999999999999999⟩]
private def b16423 : Box := ![⟨45,46⟩,⟨12,12⟩,⟨134,260⟩,⟨7,68⟩,⟨53247,106494⟩]
private def b16424 : Box := ![⟨45,46⟩,⟨12,12⟩,⟨134,260⟩,⟨7,68⟩,⟨106495,999999999999999999⟩]
private def b16439 : Box := ![⟨44,46⟩,⟨12,12⟩,⟨261,1920000000000000011376⟩,⟨7,452185007974481661387⟩,⟨26623,999999999999999999⟩]
private def b16444 : Box := ![⟨38,46⟩,⟨13,14⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567898⟩,⟨415,999999999999999999⟩]
private def b16445 : Box := ![⟨38,46⟩,⟨13,14⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567898⟩,⟨415,830⟩]
private def b16454 : Box := ![⟨38,46⟩,⟨13,14⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567898⟩,⟨831,999999999999999999⟩]
private def b16455 : Box := ![⟨38,41⟩,⟨13,14⟩,⟨63,1920000000000000011376⟩,⟨1,685382755842062856624⟩,⟨831,999999999999999999⟩]
private def b16456 : Box := ![⟨38,41⟩,⟨13,14⟩,⟨63,1920000000000000011376⟩,⟨1,2⟩,⟨831,999999999999999999⟩]
private def b16457 : Box := ![⟨38,41⟩,⟨13,14⟩,⟨63,1920000000000000011376⟩,⟨3,685382755842062856623⟩,⟨831,999999999999999999⟩]
private def b16458 : Box := ![⟨38,41⟩,⟨13,14⟩,⟨63,126⟩,⟨3,685382755842062856623⟩,⟨831,999999999999999999⟩]
private def b16471 : Box := ![⟨38,41⟩,⟨13,14⟩,⟨127,1920000000000000011376⟩,⟨3,685382755842062856623⟩,⟨831,999999999999999999⟩]
private def b16472 : Box := ![⟨38,41⟩,⟨13,13⟩,⟨127,1920000000000000011376⟩,⟨5,685382755842062856623⟩,⟨894,999999999999999999⟩]
private def b16473 : Box := ![⟨38,41⟩,⟨13,13⟩,⟨127,1920000000000000011376⟩,⟨5,678277511961722492081⟩,⟨894,1788⟩]
private def b16474 : Box := ![⟨38,41⟩,⟨13,13⟩,⟨127,1920000000000000011376⟩,⟨5,678277511961722492081⟩,⟨1789,999999999999999999⟩]
private def b16475 : Box := ![⟨38,41⟩,⟨13,13⟩,⟨127,1920000000000000011376⟩,⟨5,615010845986984819283⟩,⟨1789,3578⟩]
private def b16476 : Box := ![⟨38,41⟩,⟨13,13⟩,⟨127,1920000000000000011376⟩,⟨5,615010845986984819283⟩,⟨3579,999999999999999999⟩]
private def b16477 : Box := ![⟨38,41⟩,⟨13,13⟩,⟨127,1920000000000000011376⟩,⟨5,562911978821972207193⟩,⟨3579,7158⟩]
private def b16478 : Box := ![⟨38,41⟩,⟨13,13⟩,⟨127,1920000000000000011376⟩,⟨5,562911978821972207193⟩,⟨7159,999999999999999999⟩]
private def b16479 : Box := ![⟨38,41⟩,⟨13,13⟩,⟨127,1920000000000000011376⟩,⟨5,518950579621720564411⟩,⟨7159,14318⟩]
private def b16480 : Box := ![⟨38,41⟩,⟨13,13⟩,⟨127,1920000000000000011376⟩,⟨5,518950579621720564411⟩,⟨14319,999999999999999999⟩]
private def b16481 : Box := ![⟨38,41⟩,⟨13,13⟩,⟨127,1920000000000000011376⟩,⟨5,481358234295415962122⟩,⟨14319,28638⟩]
private def b16482 : Box := ![⟨38,41⟩,⟨13,13⟩,⟨127,1920000000000000011376⟩,⟨5,481358234295415962122⟩,⟨28639,999999999999999999⟩]
private def b16483 : Box := ![⟨38,39⟩,⟨13,13⟩,⟨127,1920000000000000011376⟩,⟨5,448844327176781005313⟩,⟨28639,999999999999999999⟩]
private def b16488 : Box := ![⟨40,41⟩,⟨13,13⟩,⟨127,1920000000000000011376⟩,⟨5,448844327176781005313⟩,⟨28639,999999999999999999⟩]
private def b16489 : Box := ![⟨40,41⟩,⟨13,13⟩,⟨127,254⟩,⟨5,448844327176781005313⟩,⟨28639,999999999999999999⟩]
private def b16504 : Box := ![⟨40,41⟩,⟨13,13⟩,⟨255,1920000000000000011376⟩,⟨5,448844327176781005313⟩,⟨28639,999999999999999999⟩]
private def b16505 : Box := ![⟨38,41⟩,⟨14,14⟩,⟨127,1920000000000000011376⟩,⟨5,685382755842062856623⟩,⟨894,999999999999999999⟩]
private def b16506 : Box := ![⟨42,46⟩,⟨13,14⟩,⟨63,1920000000000000011376⟩,⟨1,685382755842062856624⟩,⟨831,999999999999999999⟩]
theorem deny5_11 : Deny 5 11 ![⟨31,46⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨1,994807017543859655053⟩,⟨103,999999999999999999⟩] := by
  have e15878 : Deny 5 11 b15878 := by
    apply closeAction rule_sound _ _ 64 [0xc3e378c7103e378c4278de3]
    decide +kernel
  have e15884 : Deny 5 11 b15884 := by
    apply closeAction rule_sound _ _ 64 [0x30e31c30e31e32430f8dc9578df6236284]
    decide +kernel
  have e15897 : Deny 5 11 b15897 := by
    apply closeAction rule_sound _ _ 64 [0xc3e378c90f8df62378c4]
    decide +kernel
  have e15883 : Deny 5 11 b15883 :=
    branchAction rule_sound _ _ 1
      0xb b15883 b15884 b15897 (by decide +kernel) e15884 e15897
  have e15877 : Deny 5 11 b15877 :=
    branchAction rule_sound _ _ 2
      0x1e3 b15877 b15878 b15883 (by decide +kernel) e15878 e15883
  have e15905 : Deny 5 11 b15905 := by
    apply closeAction rule_sound _ _ 64 [0x30c70c90f7d88]
    decide +kernel
  have e15912 : Deny 5 11 b15912 := by
    apply closeAction rule_sound _ _ 64 [0x3e370e31c38c80c38c88c9]
    decide +kernel
  have e15904 : Deny 5 11 b15904 :=
    branchAction rule_sound _ _ 2
      0x284 b15904 b15905 b15912 (by decide +kernel) e15905 e15912
  have e15921 : Deny 5 11 b15921 := by
    apply closeAction rule_sound _ _ 64 [0x30f78c70f78c90f8df68c88c4]
    decide +kernel
  have e15903 : Deny 5 11 b15903 :=
    branchAction rule_sound _ _ 2
      0x2e3 b15903 b15904 b15921 (by decide +kernel) e15904 e15921
  have e15930 : Deny 5 11 b15930 := by
    apply closeAction rule_sound _ _ 64 [0x5770f8dc32070c31c9]
    decide +kernel
  have e15939 : Deny 5 11 b15939 := by
    apply closeAction rule_sound _ _ 64 [0x83108e370f8dc38c78c9]
    decide +kernel
  have e15929 : Deny 5 11 b15929 :=
    branchAction rule_sound _ _ 2
      0x284 b15929 b15930 b15939 (by decide +kernel) e15930 e15939
  have e15947 : Deny 5 11 b15947 := by
    apply closeAction rule_sound _ _ 64 [0xf80c70c80c31c9]
    decide +kernel
  have e15956 : Deny 5 11 b15956 := by
    apply closeAction rule_sound _ _ 64 [0x20c41f8dc38c80c38c78c9]
    decide +kernel
  have e15946 : Deny 5 11 b15946 :=
    branchAction rule_sound _ _ 3
      0xa8c4 b15946 b15947 b15956 (by decide +kernel) e15947 e15956
  have e15928 : Deny 5 11 b15928 :=
    branchAction rule_sound _ _ 1
      0xb b15928 b15929 b15946 (by decide +kernel) e15929 e15946
  have e15902 : Deny 5 11 b15902 :=
    branchAction rule_sound _ _ 1
      0x7 b15902 b15903 b15928 (by decide +kernel) e15903 e15928
  have e15876 : Deny 5 11 b15876 :=
    branchAction rule_sound _ _ 2
      0x223 b15876 b15877 b15902 (by decide +kernel) e15877 e15902
  have e15968 : Deny 5 11 b15968 := by
    apply closeAction rule_sound _ _ 64 [0x3e2fb22]
    decide +kernel
  have e15971 : Deny 5 11 b15971 := by
    apply closeAction rule_sound _ _ 64 [0xf8dc38c80e324388a0c3e37da32231e3]
    decide +kernel
  have e15982 : Deny 5 11 b15982 := by
    apply closeAction rule_sound _ _ 64 [0x72f738707be326f]
    decide +kernel
  have e15970 : Deny 5 11 b15970 :=
    branchAction rule_sound _ _ 2
      0x244 b15970 b15971 b15982 (by decide +kernel) e15971 e15982
  have e15988 : Deny 5 11 b15988 := by
    apply closeAction rule_sound _ _ 64 [0x3bc3e378c90f8df68c7738df68c8e23]
    decide +kernel
  have e15995 : Deny 5 11 b15995 := by
    apply closeAction rule_sound _ _ 64 [0x72f72f0e325cbc772f8c7be326f]
    decide +kernel
  have e15987 : Deny 5 11 b15987 :=
    branchAction rule_sound _ _ 3
      0x98c4 b15987 b15988 b15995 (by decide +kernel) e15988 e15995
  have e15969 : Deny 5 11 b15969 :=
    branchAction rule_sound _ _ 1
      0xb b15969 b15970 b15987 (by decide +kernel) e15970 e15987
  have e15967 : Deny 5 11 b15967 :=
    branchAction rule_sound _ _ 2
      0x2a3 b15967 b15968 b15969 (by decide +kernel) e15968 e15969
  have e16005 : Deny 5 11 b16005 := by
    apply closeAction rule_sound _ _ 64 [0x150f8de2107e22]
    decide +kernel
  have e16010 : Deny 5 11 b16010 := by
    apply closeAction rule_sound _ _ 64 [0x20838c41f8dc38c98c4238083888e03e370e22221e22a3]
    decide +kernel
  have e16025 : Deny 5 11 b16025 := by
    apply closeAction rule_sound _ _ 64 [0x538def]
    decide +kernel
  have e16009 : Deny 5 11 b16009 :=
    branchAction rule_sound _ _ 2
      0x244 b16009 b16010 b16025 (by decide +kernel) e16010 e16025
  have e16028 : Deny 5 11 b16028 := by
    apply closeAction rule_sound _ _ 64 [0x20c4278dc30c78c80f8dc3be322f0e32631c4]
    decide +kernel
  have e16041 : Deny 5 11 b16041 := by
    apply closeAction rule_sound _ _ 64 [0x3e370c70c3e37da31c80ef0f78c90f8df62231e3]
    decide +kernel
  have e16027 : Deny 5 11 b16027 :=
    branchAction rule_sound _ _ 2
      0x2e3 b16027 b16028 b16041 (by decide +kernel) e16028 e16041
  have e16054 : Deny 5 11 b16054 := by
    apply closeAction rule_sound _ _ 64 [0x72f72f8c4702748e1c0e22af88788a8c4278be326f]
    decide +kernel
  have e16026 : Deny 5 11 b16026 :=
    branchAction rule_sound _ _ 3
      0x98c4 b16026 b16027 b16054 (by decide +kernel) e16027 e16054
  have e16008 : Deny 5 11 b16008 :=
    branchAction rule_sound _ _ 1
      0xb b16008 b16009 b16026 (by decide +kernel) e16009 e16026
  have e16004 : Deny 5 11 b16004 :=
    branchAction rule_sound _ _ 1
      0xa b16004 b16005 b16008 (by decide +kernel) e16005 e16008
  have e15966 : Deny 5 11 b15966 :=
    branchAction rule_sound _ _ 2
      0x1e3 b15966 b15967 b16004 (by decide +kernel) e15967 e16004
  have e16069 : Deny 5 11 b16069 := by
    apply closeAction rule_sound _ _ 64 [0xc3e22222]
    decide +kernel
  have e16073 : Deny 5 11 b16073 := by
    apply closeAction rule_sound _ _ 64 [0xaf8820e2107e37083884278dc38c78c88c9dc4]
    decide +kernel
  have e16085 : Deny 5 11 b16085 := by
    apply closeAction rule_sound _ _ 64 [0x2bc40c4278dc3e032231c3e2f0e3243e231e3223]
    decide +kernel
  have e16098 : Deny 5 11 b16098 := by
    apply closeAction rule_sound _ _ 64 [0x14e378c4538ddcbdcbe326f8c7be3108e2f]
    decide +kernel
  have e16084 : Deny 5 11 b16084 :=
    branchAction rule_sound _ _ 3
      0x98c4 b16084 b16085 b16098 (by decide +kernel) e16085 e16098
  have e16072 : Deny 5 11 b16072 :=
    branchAction rule_sound _ _ 1
      0xb b16072 b16073 b16084 (by decide +kernel) e16073 e16084
  have e16068 : Deny 5 11 b16068 :=
    branchAction rule_sound _ _ 2
      0x2a3 b16068 b16069 b16072 (by decide +kernel) e16069 e16072
  have e16106 : Deny 5 11 b16106 := by
    apply closeAction rule_sound _ _ 64 [0x20af0c9108e020e2107e370e22222840952372f7]
    decide +kernel
  have e16121 : Deny 5 11 b16121 := by
    apply closeAction rule_sound _ _ 64 [0xafb22]
    decide +kernel
  have e16105 : Deny 5 11 b16105 :=
    branchAction rule_sound _ _ 3
      0x9e37 b16105 b16106 b16121 (by decide +kernel) e16106 e16121
  have e16067 : Deny 5 11 b16067 :=
    branchAction rule_sound _ _ 1
      0x7 b16067 b16068 b16105 (by decide +kernel) e16068 e16105
  have e15965 : Deny 5 11 b15965 :=
    branchAction rule_sound _ _ 1
      0x8 b15965 b15966 b16067 (by decide +kernel) e15966 e16067
  have e15875 : Deny 5 11 b15875 :=
    branchAction rule_sound _ _ 3
      0x98c4 b15875 b15876 b15965 (by decide +kernel) e15876 e15965
  have e16124 : Deny 5 11 b16124 := by
    apply closeAction rule_sound _ _ 64 [0x3087df68c4087e37da3]
    decide +kernel
  have e16130 : Deny 5 11 b16130 := by
    apply closeAction rule_sound _ _ 64 [0xc3e37da31c3e378c9e23088e37da3]
    decide +kernel
  have e16138 : Deny 5 11 b16138 := by
    apply closeAction rule_sound _ _ 64 [0xc38c70f8de32030f8de31e3263]
    decide +kernel
  have e16147 : Deny 5 11 b16147 := by
    apply closeAction rule_sound _ _ 64 [0xc3e231c3e378c9088da3]
    decide +kernel
  have e16137 : Deny 5 11 b16137 :=
    branchAction rule_sound _ _ 1
      0xb b16137 b16138 b16147 (by decide +kernel) e16138 e16147
  have e16129 : Deny 5 11 b16129 :=
    branchAction rule_sound _ _ 1
      0x7 b16129 b16130 b16137 (by decide +kernel) e16130 e16137
  have e16123 : Deny 5 11 b16123 :=
    branchAction rule_sound _ _ 2
      0x223 b16123 b16124 b16129 (by decide +kernel) e16124 e16129
  have e16156 : Deny 5 11 b16156 := by
    apply closeAction rule_sound _ _ 64 [0xa2]
    decide +kernel
  have e16158 : Deny 5 11 b16158 := by
    apply closeAction rule_sound _ _ 64 [0x72f8c472f8c4278da3]
    decide +kernel
  have e16163 : Deny 5 11 b16163 := by
    apply closeAction rule_sound _ _ 64 [0x30f81dde37d880f7d84088e37da31e3]
    decide +kernel
  have e16172 : Deny 5 11 b16172 := by
    apply closeAction rule_sound _ _ 64 [0x72f72f71d0f88870ef884088e221ef88a8c9be326f]
    decide +kernel
  have e16162 : Deny 5 11 b16162 :=
    branchAction rule_sound _ _ 1
      0x9 b16162 b16163 b16172 (by decide +kernel) e16163 e16172
  have e16186 : Deny 5 11 b16186 := by
    apply closeAction rule_sound _ _ 64 [0xda3]
    decide +kernel
  have e16187 : Deny 5 11 b16187 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdcbe326f0ef0f88c9738df68c7e368c972f8c472f8c41f8da31f60af88a]
    decide +kernel
  have e16185 : Deny 5 11 b16185 :=
    branchAction rule_sound _ _ 3
      0x8da3 b16185 b16186 b16187 (by decide +kernel) e16186 e16187
  have e16161 : Deny 5 11 b16161 :=
    branchAction rule_sound _ _ 1
      0xb b16161 b16162 b16185 (by decide +kernel) e16162 e16185
  have e16157 : Deny 5 11 b16157 :=
    branchAction rule_sound _ _ 2
      0x1e3 b16157 b16158 b16161 (by decide +kernel) e16158 e16161
  have e16155 : Deny 5 11 b16155 :=
    branchAction rule_sound _ _ 3
      0xae23 b16155 b16156 b16157 (by decide +kernel) e16156 e16157
  have e16206 : Deny 5 11 b16206 := by
    apply closeAction rule_sound _ _ 64 [0xef0f8df68c9d84087e37]
    decide +kernel
  have e16211 : Deny 5 11 b16211 := by
    apply closeAction rule_sound _ _ 64 [0x3e03238bc38c90c3e368c8e070f888a]
    decide +kernel
  have e16205 : Deny 5 11 b16205 :=
    branchAction rule_sound _ _ 2
      0x223 b16205 b16206 b16211 (by decide +kernel) e16206 e16211
  have e16222 : Deny 5 11 b16222 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdcbdcbdc0f80ef1c3e2f20a8c98c9be326f]
    decide +kernel
  have e16204 : Deny 5 11 b16204 :=
    branchAction rule_sound _ _ 2
      0x263 b16204 b16205 b16222 (by decide +kernel) e16205 e16222
  have e16236 : Deny 5 11 b16236 := by
    apply closeAction rule_sound _ _ 64 [0x538da2]
    decide +kernel
  have e16238 : Deny 5 11 b16238 := by
    apply closeAction rule_sound _ _ 64 [0x3e03e37da322f0f88c9087e23088e23]
    decide +kernel
  have e16248 : Deny 5 11 b16248 := by
    apply closeAction rule_sound _ _ 64 [0x14e22]
    decide +kernel
  have e16250 : Deny 5 11 b16250 := by
    apply closeAction rule_sound _ _ 64 [0x72f8c4087e36]
    decide +kernel
  have e16254 : Deny 5 11 b16254 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe372f0f88c9bc2238be3278]
    decide +kernel
  have e16262 : Deny 5 11 b16262 := by
    apply closeAction rule_sound _ _ 64 [0x1cbdcbc3e03e088c9be3263]
    decide +kernel
  have e16270 : Deny 5 11 b16270 := by
    apply closeAction rule_sound _ _ 64 [0x1cbc3e23278be3088e23]
    decide +kernel
  have e16276 : Deny 5 11 b16276 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e16278 : Deny 5 11 b16278 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e16280 : Deny 5 11 b16280 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e16282 : Deny 5 11 b16282 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e16284 : Deny 5 11 b16284 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e16286 : Deny 5 11 b16286 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e16287 : Deny 5 11 b16287 := by
    apply closeAction rule_sound _ _ 64 [0x9cbe3278bc20e32421e372f8cb8c972f8c21f8da31e3]
    decide +kernel
  have e16285 : Deny 5 11 b16285 :=
    branchAction rule_sound _ _ 2
      0x2e3 b16285 b16286 b16287 (by decide +kernel) e16286 e16287
  have e16283 : Deny 5 11 b16283 :=
    branchAction rule_sound _ _ 2
      0x2e3 b16283 b16284 b16285 (by decide +kernel) e16284 e16285
  have e16281 : Deny 5 11 b16281 :=
    branchAction rule_sound _ _ 1
      0xb b16281 b16282 b16283 (by decide +kernel) e16282 e16283
  have e16279 : Deny 5 11 b16279 :=
    branchAction rule_sound _ _ 2
      0x223 b16279 b16280 b16281 (by decide +kernel) e16280 e16281
  have e16277 : Deny 5 11 b16277 :=
    branchAction rule_sound _ _ 2
      0x2e3 b16277 b16278 b16279 (by decide +kernel) e16278 e16279
  have e16275 : Deny 5 11 b16275 :=
    branchAction rule_sound _ _ 1
      0xb b16275 b16276 b16277 (by decide +kernel) e16276 e16277
  have e16269 : Deny 5 11 b16269 :=
    branchAction rule_sound _ _ 2
      0x263 b16269 b16270 b16275 (by decide +kernel) e16270 e16275
  have e16261 : Deny 5 11 b16261 :=
    branchAction rule_sound _ _ 1
      0xb b16261 b16262 b16269 (by decide +kernel) e16262 e16269
  have e16253 : Deny 5 11 b16253 :=
    branchAction rule_sound _ _ 1
      0x7 b16253 b16254 b16261 (by decide +kernel) e16254 e16261
  have e16249 : Deny 5 11 b16249 :=
    branchAction rule_sound _ _ 1
      0x8 b16249 b16250 b16253 (by decide +kernel) e16250 e16253
  have e16247 : Deny 5 11 b16247 :=
    branchAction rule_sound _ _ 1
      0xa b16247 b16248 b16249 (by decide +kernel) e16248 e16249
  have e16237 : Deny 5 11 b16237 :=
    branchAction rule_sound _ _ 1
      0x9 b16237 b16238 b16247 (by decide +kernel) e16238 e16247
  have e16235 : Deny 5 11 b16235 :=
    branchAction rule_sound _ _ 2
      0x2a3 b16235 b16236 b16237 (by decide +kernel) e16236 e16237
  have e16203 : Deny 5 11 b16203 :=
    branchAction rule_sound _ _ 2
      0x2e3 b16203 b16204 b16235 (by decide +kernel) e16204 e16235
  have e16305 : Deny 5 11 b16305 := by
    apply closeAction rule_sound _ _ 64 [0x3e378c3e2f8c7e03be31c38c90f888a]
    decide +kernel
  have e16315 : Deny 5 11 b16315 := by
    apply closeAction rule_sound _ _ 64 [0x578de20af0c9887dc4]
    decide +kernel
  have e16320 : Deny 5 11 b16320 := by
    apply closeAction rule_sound _ _ 64 [0x20e22370838c4238bc38c90e22a31e3]
    decide +kernel
  have e16314 : Deny 5 11 b16314 :=
    branchAction rule_sound _ _ 1
      0xb b16314 b16315 b16320 (by decide +kernel) e16315 e16320
  have e16304 : Deny 5 11 b16304 :=
    branchAction rule_sound _ _ 2
      0x223 b16304 b16305 b16314 (by decide +kernel) e16305 e16314
  have e16331 : Deny 5 11 b16331 := by
    apply closeAction rule_sound _ _ 64 [0x2082be372f8c40e3109e2f8c9e2f8c78c8e2f]
    decide +kernel
  have e16303 : Deny 5 11 b16303 :=
    branchAction rule_sound _ _ 2
      0x263 b16303 b16304 b16331 (by decide +kernel) e16304 e16331
  have e16342 : Deny 5 11 b16342 := by
    apply closeAction rule_sound _ _ 64 [0x30f8da31c3e37da31f88c288ae23]
    decide +kernel
  have e16350 : Deny 5 11 b16350 := by
    apply closeAction rule_sound _ _ 64 [0x83e038c720388a0f80ef22f0e32631e3]
    decide +kernel
  have e16363 : Deny 5 11 b16363 := by
    apply closeAction rule_sound _ _ 64 [0x20c80c70c3e232232430f8df6203e232631e3]
    decide +kernel
  have e16349 : Deny 5 11 b16349 :=
    branchAction rule_sound _ _ 1
      0xb b16349 b16350 b16363 (by decide +kernel) e16350 e16363
  have e16341 : Deny 5 11 b16341 :=
    branchAction rule_sound _ _ 2
      0x223 b16341 b16342 b16349 (by decide +kernel) e16342 e16349
  have e16380 : Deny 5 11 b16380 := by
    apply closeAction rule_sound _ _ 64 [0x538be2]
    decide +kernel
  have e16382 : Deny 5 11 b16382 := by
    apply closeAction rule_sound _ _ 64 [0x14e22]
    decide +kernel
  have e16384 : Deny 5 11 b16384 := by
    apply closeAction rule_sound _ _ 64 [0x72f72f703e03e221f80f8be21ca8c9be3263]
    decide +kernel
  have e16396 : Deny 5 11 b16396 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3087e36]
    decide +kernel
  have e16400 : Deny 5 11 b16400 := by
    apply closeAction rule_sound _ _ 64 [0x703e222b8be30f8daf8c7e23]
    decide +kernel
  have e16406 : Deny 5 11 b16406 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e16408 : Deny 5 11 b16408 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e16410 : Deny 5 11 b16410 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e16412 : Deny 5 11 b16412 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e16414 : Deny 5 11 b16414 := by
    apply closeAction rule_sound _ _ 64 [0x738df6]
    decide +kernel
  have e16416 : Deny 5 11 b16416 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e16419 : Deny 5 11 b16419 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e16421 : Deny 5 11 b16421 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e16423 : Deny 5 11 b16423 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e16424 : Deny 5 11 b16424 := by
    apply closeAction rule_sound _ _ 64 [0x71cbc32542d42e22a372f8cbda372f8cbda372f8cbda3]
    decide +kernel
  have e16422 : Deny 5 11 b16422 :=
    branchAction rule_sound _ _ 3
      0xbda3 b16422 b16423 b16424 (by decide +kernel) e16423 e16424
  have e16420 : Deny 5 11 b16420 :=
    branchAction rule_sound _ _ 1
      0xb b16420 b16421 b16422 (by decide +kernel) e16421 e16422
  have e16418 : Deny 5 11 b16418 :=
    branchAction rule_sound _ _ 2
      0x1e3 b16418 b16419 b16420 (by decide +kernel) e16419 e16420
  have e16439 : Deny 5 11 b16439 := by
    apply closeAction rule_sound _ _ 64 [0x209cbe32761ef]
    decide +kernel
  have e16417 : Deny 5 11 b16417 :=
    branchAction rule_sound _ _ 3
      0x9da3 b16417 b16418 b16439 (by decide +kernel) e16418 e16439
  have e16415 : Deny 5 11 b16415 :=
    branchAction rule_sound _ _ 1
      0xb b16415 b16416 b16417 (by decide +kernel) e16416 e16417
  have e16413 : Deny 5 11 b16413 :=
    branchAction rule_sound _ _ 2
      0x1e3 b16413 b16414 b16415 (by decide +kernel) e16414 e16415
  have e16411 : Deny 5 11 b16411 :=
    branchAction rule_sound _ _ 2
      0x2e3 b16411 b16412 b16413 (by decide +kernel) e16412 e16413
  have e16409 : Deny 5 11 b16409 :=
    branchAction rule_sound _ _ 2
      0x2e3 b16409 b16410 b16411 (by decide +kernel) e16410 e16411
  have e16407 : Deny 5 11 b16407 :=
    branchAction rule_sound _ _ 2
      0x2e3 b16407 b16408 b16409 (by decide +kernel) e16408 e16409
  have e16405 : Deny 5 11 b16405 :=
    branchAction rule_sound _ _ 1
      0xb b16405 b16406 b16407 (by decide +kernel) e16406 e16407
  have e16399 : Deny 5 11 b16399 :=
    branchAction rule_sound _ _ 1
      0x9 b16399 b16400 b16405 (by decide +kernel) e16400 e16405
  have e16395 : Deny 5 11 b16395 :=
    branchAction rule_sound _ _ 2
      0x1e3 b16395 b16396 b16399 (by decide +kernel) e16396 e16399
  have e16383 : Deny 5 11 b16383 :=
    branchAction rule_sound _ _ 1
      0xb b16383 b16384 b16395 (by decide +kernel) e16384 e16395
  have e16381 : Deny 5 11 b16381 :=
    branchAction rule_sound _ _ 1
      0xa b16381 b16382 b16383 (by decide +kernel) e16382 e16383
  have e16379 : Deny 5 11 b16379 :=
    branchAction rule_sound _ _ 2
      0x2a3 b16379 b16380 b16381 (by decide +kernel) e16380 e16381
  have e16445 : Deny 5 11 b16445 := by
    apply closeAction rule_sound _ _ 64 [0x208272f0e3263238be3278be31f8be3]
    decide +kernel
  have e16456 : Deny 5 11 b16456 := by
    apply closeAction rule_sound _ _ 64 [0x3be2]
    decide +kernel
  have e16458 : Deny 5 11 b16458 := by
    apply closeAction rule_sound _ _ 64 [0x83e2f0f88c9e231f80f80f88c7e2f0f88c9e230efb222b8223]
    decide +kernel
  have e16473 : Deny 5 11 b16473 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e16475 : Deny 5 11 b16475 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e16477 : Deny 5 11 b16477 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e16479 : Deny 5 11 b16479 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e16481 : Deny 5 11 b16481 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e16483 : Deny 5 11 b16483 := by
    apply closeAction rule_sound _ _ 64 [0x9cbe3276bc21f6]
    decide +kernel
  have e16489 : Deny 5 11 b16489 := by
    apply closeAction rule_sound _ _ 64 [0x7030f61e22a372f8cb8dcbe32e372f8cb8dcbe32e372f8cbbe3]
    decide +kernel
  have e16504 : Deny 5 11 b16504 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e16488 : Deny 5 11 b16488 :=
    branchAction rule_sound _ _ 1
      0x9 b16488 b16489 b16504 (by decide +kernel) e16489 e16504
  have e16482 : Deny 5 11 b16482 :=
    branchAction rule_sound _ _ 2
      0x1e3 b16482 b16483 b16488 (by decide +kernel) e16483 e16488
  have e16480 : Deny 5 11 b16480 :=
    branchAction rule_sound _ _ 2
      0x2e3 b16480 b16481 b16482 (by decide +kernel) e16481 e16482
  have e16478 : Deny 5 11 b16478 :=
    branchAction rule_sound _ _ 2
      0x2e3 b16478 b16479 b16480 (by decide +kernel) e16479 e16480
  have e16476 : Deny 5 11 b16476 :=
    branchAction rule_sound _ _ 2
      0x2e3 b16476 b16477 b16478 (by decide +kernel) e16477 e16478
  have e16474 : Deny 5 11 b16474 :=
    branchAction rule_sound _ _ 2
      0x2e3 b16474 b16475 b16476 (by decide +kernel) e16475 e16476
  have e16472 : Deny 5 11 b16472 :=
    branchAction rule_sound _ _ 2
      0x2e3 b16472 b16473 b16474 (by decide +kernel) e16473 e16474
  have e16505 : Deny 5 11 b16505 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e16471 : Deny 5 11 b16471 :=
    branchAction rule_sound _ _ 3
      0x8e2f b16471 b16472 b16505 (by decide +kernel) e16472 e16505
  have e16457 : Deny 5 11 b16457 :=
    branchAction rule_sound _ _ 1
      0x9 b16457 b16458 b16471 (by decide +kernel) e16458 e16471
  have e16455 : Deny 5 11 b16455 :=
    branchAction rule_sound _ _ 2
      0x2a3 b16455 b16456 b16457 (by decide +kernel) e16456 e16457
  have e16506 : Deny 5 11 b16506 := by
    apply closeAction rule_sound _ _ 64 [0x20820f8bc3e232788c7e23238be3278]
    decide +kernel
  have e16454 : Deny 5 11 b16454 :=
    branchAction rule_sound _ _ 2
      0x1e3 b16454 b16455 b16506 (by decide +kernel) e16455 e16506
  have e16444 : Deny 5 11 b16444 :=
    branchAction rule_sound _ _ 1
      0xb b16444 b16445 b16454 (by decide +kernel) e16445 e16454
  have e16378 : Deny 5 11 b16378 :=
    branchAction rule_sound _ _ 1
      0x8 b16378 b16379 b16444 (by decide +kernel) e16379 e16444
  have e16340 : Deny 5 11 b16340 :=
    branchAction rule_sound _ _ 2
      0x263 b16340 b16341 b16378 (by decide +kernel) e16341 e16378
  have e16302 : Deny 5 11 b16302 :=
    branchAction rule_sound _ _ 1
      0xb b16302 b16303 b16340 (by decide +kernel) e16303 e16340
  have e16202 : Deny 5 11 b16202 :=
    branchAction rule_sound _ _ 1
      0x7 b16202 b16203 b16302 (by decide +kernel) e16203 e16302
  have e16154 : Deny 5 11 b16154 :=
    branchAction rule_sound _ _ 1
      0x8 b16154 b16155 b16202 (by decide +kernel) e16155 e16202
  have e16122 : Deny 5 11 b16122 :=
    branchAction rule_sound _ _ 2
      0x263 b16122 b16123 b16154 (by decide +kernel) e16123 e16154
  have e15874 : Deny 5 11 b15874 :=
    branchAction rule_sound _ _ 1
      0xb b15874 b15875 b16122 (by decide +kernel) e15875 e16122
  exact e15874
end OMA.Blocks5_11_245212.S15874
