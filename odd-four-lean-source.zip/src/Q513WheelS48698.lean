import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S48698
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b48698 : Box := ![⟨95,190⟩,⟨25,30⟩,⟨15,30⟩,⟨3,64⟩,⟨239,478⟩]
private def b48699 : Box := ![⟨95,190⟩,⟨25,30⟩,⟨15,30⟩,⟨3,6⟩,⟨239,478⟩]
private def b48700 : Box := ![⟨95,158⟩,⟨25,30⟩,⟨15,20⟩,⟨3,6⟩,⟨239,478⟩]
private def b48701 : Box := ![⟨95,134⟩,⟨25,30⟩,⟨15,20⟩,⟨3,6⟩,⟨239,318⟩]
private def b48702 : Box := ![⟨95,132⟩,⟨25,27⟩,⟨15,20⟩,⟨3,6⟩,⟨239,317⟩]
private def b48713 : Box := ![⟨95,132⟩,⟨28,30⟩,⟨15,20⟩,⟨3,6⟩,⟨239,317⟩]
private def b48724 : Box := ![⟨95,134⟩,⟨25,30⟩,⟨15,20⟩,⟨3,6⟩,⟨319,478⟩]
private def b48725 : Box := ![⟨95,134⟩,⟨25,27⟩,⟨15,20⟩,⟨3,6⟩,⟨319,478⟩]
private def b48726 : Box := ![⟨95,109⟩,⟨25,27⟩,⟨15,20⟩,⟨3,6⟩,⟨319,478⟩]
private def b48731 : Box := ![⟨110,130⟩,⟨25,27⟩,⟨15,20⟩,⟨3,6⟩,⟨319,478⟩]
private def b48738 : Box := ![⟨95,134⟩,⟨28,30⟩,⟨15,20⟩,⟨3,6⟩,⟨319,478⟩]
private def b48739 : Box := ![⟨95,111⟩,⟨28,30⟩,⟨15,20⟩,⟨3,6⟩,⟨319,478⟩]
private def b48746 : Box := ![⟨112,134⟩,⟨28,30⟩,⟨15,20⟩,⟨3,6⟩,⟨319,478⟩]
private def b48753 : Box := ![⟨95,158⟩,⟨25,30⟩,⟨21,30⟩,⟨3,6⟩,⟨239,478⟩]
private def b48754 : Box := ![⟨95,158⟩,⟨25,30⟩,⟨21,30⟩,⟨3,6⟩,⟨239,318⟩]
private def b48755 : Box := ![⟨95,118⟩,⟨25,30⟩,⟨21,30⟩,⟨3,6⟩,⟨239,317⟩]
private def b48756 : Box := ![⟨95,118⟩,⟨25,27⟩,⟨21,30⟩,⟨3,6⟩,⟨239,317⟩]
private def b48767 : Box := ![⟨95,118⟩,⟨28,30⟩,⟨21,30⟩,⟨3,6⟩,⟨239,317⟩]
private def b48768 : Box := ![⟨119,156⟩,⟨25,30⟩,⟨21,30⟩,⟨3,6⟩,⟨239,317⟩]
private def b48769 : Box := ![⟨95,158⟩,⟨25,30⟩,⟨21,30⟩,⟨3,6⟩,⟨319,478⟩]
private def b48770 : Box := ![⟨95,118⟩,⟨25,30⟩,⟨21,30⟩,⟨3,6⟩,⟨319,478⟩]
private def b48771 : Box := ![⟨95,118⟩,⟨25,27⟩,⟨21,30⟩,⟨3,6⟩,⟨319,478⟩]
private def b48772 : Box := ![⟨95,118⟩,⟨25,27⟩,⟨21,24⟩,⟨3,6⟩,⟨319,478⟩]
private def b48777 : Box := ![⟨95,118⟩,⟨25,27⟩,⟨25,30⟩,⟨3,6⟩,⟨319,478⟩]
private def b48778 : Box := ![⟨95,118⟩,⟨25,27⟩,⟨25,30⟩,⟨3,6⟩,⟨319,382⟩]
private def b48783 : Box := ![⟨95,118⟩,⟨25,27⟩,⟨25,30⟩,⟨3,6⟩,⟨383,478⟩]
private def b48794 : Box := ![⟨95,118⟩,⟨28,30⟩,⟨21,30⟩,⟨3,6⟩,⟨319,478⟩]
private def b48801 : Box := ![⟨119,158⟩,⟨25,30⟩,⟨21,30⟩,⟨3,6⟩,⟨319,478⟩]
private def b48810 : Box := ![⟨95,190⟩,⟨25,30⟩,⟨15,30⟩,⟨7,64⟩,⟨239,478⟩]
private theorem e48702 : Deny 5 13 b48702 := by
    apply closeAction rule_sound _ _ 64 [0x3e27103107e039e02430c90c81e0]
    decide +kernel
private theorem e48713 : Deny 5 13 b48713 := by
    apply closeAction rule_sound _ _ 64 [0x20f8dc3e27809e278042785f8dc3243207]
    decide +kernel
private theorem e48701 : Deny 5 13 b48701 :=
    branchAction rule_sound _ _ 3
      0x8804 b48701 b48702 b48713 (by decide +kernel) e48702 e48713
private theorem e48726 : Deny 5 13 b48726 := by
    apply closeAction rule_sound _ _ 64 [0x3088102109e36]
    decide +kernel
private theorem e48731 : Deny 5 13 b48731 := by
    apply closeAction rule_sound _ _ 64 [0x3e270c70f89e0243e36808]
    decide +kernel
private theorem e48725 : Deny 5 13 b48725 :=
    branchAction rule_sound _ _ 2
      0x1e0 b48725 b48726 b48731 (by decide +kernel) e48726 e48731
private theorem e48739 : Deny 5 13 b48739 := by
    apply closeAction rule_sound _ _ 64 [0xc31c30f81c9]
    decide +kernel
private theorem e48746 : Deny 5 13 b48746 := by
    apply closeAction rule_sound _ _ 64 [0x840c41f80f80f89e0267809]
    decide +kernel
private theorem e48738 : Deny 5 13 b48738 :=
    branchAction rule_sound _ _ 1
      0x7 b48738 b48739 b48746 (by decide +kernel) e48739 e48746
private theorem e48724 : Deny 5 13 b48724 :=
    branchAction rule_sound _ _ 1
      0x8 b48724 b48725 b48738 (by decide +kernel) e48725 e48738
private theorem e48700 : Deny 5 13 b48700 :=
    branchAction rule_sound _ _ 2
      0x2e0 b48700 b48701 b48724 (by decide +kernel) e48701 e48724
private theorem e48756 : Deny 5 13 b48756 := by
    apply closeAction rule_sound _ _ 64 [0x820c8107e37083107e03209]
    decide +kernel
private theorem e48767 : Deny 5 13 b48767 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e48755 : Deny 5 13 b48755 :=
    branchAction rule_sound _ _ 1
      0x8 b48755 b48756 b48767 (by decide +kernel) e48756 e48767
private theorem e48768 : Deny 5 13 b48768 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e48754 : Deny 5 13 b48754 :=
    branchAction rule_sound _ _ 3
      0x7804 b48754 b48755 b48768 (by decide +kernel) e48755 e48768
private theorem e48772 : Deny 5 13 b48772 := by
    apply closeAction rule_sound _ _ 64 [0x30c90c8]
    decide +kernel
private theorem e48778 : Deny 5 13 b48778 := by
    apply closeAction rule_sound _ _ 64 [0x5f8dc3e370c91c4]
    decide +kernel
private theorem e48783 : Deny 5 13 b48783 := by
    apply closeAction rule_sound _ _ 64 [0x7c20c42380c32475ca284]
    decide +kernel
private theorem e48777 : Deny 5 13 b48777 :=
    branchAction rule_sound _ _ 1
      0xb b48777 b48778 b48783 (by decide +kernel) e48778 e48783
private theorem e48771 : Deny 5 13 b48771 :=
    branchAction rule_sound _ _ 1
      0x9 b48771 b48772 b48777 (by decide +kernel) e48772 e48777
private theorem e48794 : Deny 5 13 b48794 := by
    apply closeAction rule_sound _ _ 64 [0x17e375f8dc3e03207278]
    decide +kernel
private theorem e48770 : Deny 5 13 b48770 :=
    branchAction rule_sound _ _ 1
      0x8 b48770 b48771 b48794 (by decide +kernel) e48771 e48794
private theorem e48801 : Deny 5 13 b48801 := by
    apply closeAction rule_sound _ _ 64 [0x827f8de70f8dc3207809804238]
    decide +kernel
private theorem e48769 : Deny 5 13 b48769 :=
    branchAction rule_sound _ _ 1
      0x7 b48769 b48770 b48801 (by decide +kernel) e48770 e48801
private theorem e48753 : Deny 5 13 b48753 :=
    branchAction rule_sound _ _ 1
      0xb b48753 b48754 b48769 (by decide +kernel) e48754 e48769
private theorem e48699 : Deny 5 13 b48699 :=
    branchAction rule_sound _ _ 2
      0x260 b48699 b48700 b48753 (by decide +kernel) e48700 e48753
private theorem e48810 : Deny 5 13 b48810 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e48698 : Deny 5 13 b48698 :=
    branchAction rule_sound _ _ 1
      0xa b48698 b48699 b48810 (by decide +kernel) e48699 e48810
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨25,30⟩,⟨15,30⟩,⟨3,64⟩,⟨239,478⟩] := by
  exact e48698
end OMA.Blocks5_13_245212.S48698
