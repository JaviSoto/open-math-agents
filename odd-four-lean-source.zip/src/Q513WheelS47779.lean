import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S47779
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b47779 : Box := ![⟨191,254⟩,⟨18,20⟩,⟨63,126⟩,⟨3,121⟩,⟨959,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨191,254⟩,⟨18,20⟩,⟨63,126⟩,⟨3,121⟩,⟨959,999999999999999999⟩] := by
  have e47779 : Deny 5 13 b47779 := by
    apply closeAction rule_sound _ _ 64 [0xe37578dc3e038c98c7e232632f80c3e378c7778de32788dde37da31f8d888c78c98c27552952888cb7552b88d52b8223,0x2b88c88c7082083e232788c7e2327875d54ae0ae2354ae08083e231f80f80e31e31c3e038c90f88c3e232788c78c98d5,0xe31f88c98cbe1d54ae2354ae231e32630827552b854a8c7e232632e32380820820f88c9e231f88c9e231f87552b88d5,0x20820f88c9e03e232780c31e31e3095e370f88c98c78cbe231f8083e231f80c3e231e3263095e37]
    decide +kernel
  exact e47779
end OMA.Blocks5_13_245212.S47779
