import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S37513
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b37513 : Box := ![⟨47,94⟩,⟨21,30⟩,⟨15,1920000000000000011376⟩,⟨3,1129131513647642686639⟩,⟨79,113⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,94⟩,⟨21,30⟩,⟨15,1920000000000000011376⟩,⟨3,1129131513647642686639⟩,⟨79,113⟩] := by
  have e37513 : Deny 5 13 b37513 := by
    apply closeAction rule_sound _ _ 64 [0xe371c9204097e375f8dd7e370c9207257e375c32370f70c72045f8dd7dc31c8dcb1d7e370c80c70c320724810b1ca8c9,0x2481ca257283dc31c30c72040831f70f70c72042c30f7d870c21f7d881030c70c3df61c810b1c30c80c70c47f8df6108,0x108e03e370c90c3248117e375f8dc324810b247108e025f8ddf0832780c7288107e1f083109e040f80c9108e170c90c3,0x10b8871020820e21e22221f710b88a8c88c98c7e1f5f8dc4097e37083107e370f8dc31c92042780820c9e370f8dc3247,0xdc3e370e22221e2108e17e378832770f70c98870c38870c3dc9de21e22045f8de25f8dc32621f70f70e21c30c9887888,0x94e375f8ddf5f8dc4083278]
    decide +kernel
  exact e37513
end OMA.Blocks5_13_245212.S37513
