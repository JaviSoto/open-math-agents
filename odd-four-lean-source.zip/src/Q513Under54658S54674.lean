import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S54674
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b54674 : Box := ![⟨54,62⟩,⟨63,126⟩,⟨10,11⟩,⟨3,52⟩,⟨479,958⟩]
private def b54675 : Box := ![⟨54,62⟩,⟨76,94⟩,⟨10,11⟩,⟨3,51⟩,⟨479,699⟩]
private def b54676 : Box := ![⟨54,62⟩,⟨95,126⟩,⟨10,11⟩,⟨3,51⟩,⟨479,699⟩]
private def b54677 : Box := ![⟨54,57⟩,⟨95,126⟩,⟨10,11⟩,⟨7,51⟩,⟨479,699⟩]
private def b54678 : Box := ![⟨58,62⟩,⟨95,126⟩,⟨10,11⟩,⟨7,51⟩,⟨479,699⟩]
private def b54679 : Box := ![⟨58,62⟩,⟨95,108⟩,⟨10,11⟩,⟨7,51⟩,⟨479,699⟩]
private def b54680 : Box := ![⟨58,62⟩,⟨95,108⟩,⟨10,10⟩,⟨7,46⟩,⟨479,566⟩]
private def b54681 : Box := ![⟨58,62⟩,⟨95,108⟩,⟨11,11⟩,⟨7,46⟩,⟨479,566⟩]
private def b54682 : Box := ![⟨58,62⟩,⟨109,126⟩,⟨10,11⟩,⟨7,51⟩,⟨479,699⟩]
private theorem e54675 : Deny 5 13 b54675 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e54677 : Deny 5 13 b54677 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e54680 : Deny 5 13 b54680 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e54681 : Deny 5 13 b54681 := by
    apply closeAction rule_sound _ _ 64 [0xc4]
    decide +kernel
private theorem e54679 : Deny 5 13 b54679 :=
    branchAction rule_sound _ _ 3
      0x9e23 b54679 b54680 b54681 (by decide +kernel) e54680 e54681
private theorem e54682 : Deny 5 13 b54682 := by
    apply closeAction rule_sound _ _ 64 [0x6eb]
    decide +kernel
private theorem e54678 : Deny 5 13 b54678 :=
    branchAction rule_sound _ _ 1
      0x8 b54678 b54679 b54682 (by decide +kernel) e54679 e54682
private theorem e54676 : Deny 5 13 b54676 :=
    branchAction rule_sound _ _ 2
      0x1eb b54676 b54677 b54678 (by decide +kernel) e54677 e54678
private theorem e54674 : Deny 5 13 b54674 :=
    branchAction rule_sound _ _ 4
      0x238d63 b54674 b54675 b54676 (by decide +kernel) e54675 e54676
theorem deny5_13 : Deny 5 13 ![⟨54,62⟩,⟨63,126⟩,⟨10,11⟩,⟨3,52⟩,⟨479,958⟩] := by
  exact e54674
end OMA.Blocks5_13_245212.S54674
