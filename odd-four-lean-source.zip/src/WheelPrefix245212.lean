import QuickPrefix245212

/-! For a fixed three-factor cofactor, the unknown prime r divides A+S,
and its square divides A−(r−1)S if its exponent is at least two. When
the prime interval is short, reject all its eligible integers together
before enumerating possible exponents. -/
namespace OMA.WheelPrefix245212
open OMA.Box245212 OMA.Large245212 ArithmeticFunction Finset
open OMA.Smooth245212 (W total w_mult w_pow)
open scoped ArithmeticFunction.sigma

private theorem localData {m r d : ℕ} (hm : 0 < m) (prime : r.Prime) (cop : m.Coprime r)
    (hd : 0<d) (eq : OeisA245212.a (m*r^d)=(σ 1 (m*r^d):ℤ)) :
    let A:=W m; let S:=σ 1 m; let T:=m*(σ 0 m)
    r∣A+S ∧ (d=1 → A+S+r*(2*A+S)=4*T*r) ∧
      (2≤d → (A+S)%(r*r)=(r*S)%(r*r)) := by
  dsimp only
  refine ⟨OMA.OddCofactor245212.last_dvd hm prime cop hd eq,?_,?_⟩
  · rintro rfl
    have b:=OMA.Abundance245212.balance (mul_ne_zero hm.ne' (pow_ne_zero _ prime.ne_zero)) eq
    simp only [pow_one] at b
    rw [w_mult.map_mul_of_coprime cop,isMultiplicative_sigma.map_mul_of_coprime cop,
      isMultiplicative_sigma.map_mul_of_coprime cop] at b
    have w:=w_pow prime 1
    simp [sum_range_succ] at w
    have sig : (σ 1) (r^1)=∑ j∈range (1+1),r^j := sigma_one_apply_prime_pow prime
    have tau : (σ 0) (r^1)=1+1 := sigma_zero_apply_prime_pow prime
    simp [sum_range_succ] at sig tau
    rw [w,sig,tau] at b
    nlinarith only [b]
  · intro two
    have div := (pow_dvd_pow (r:ℤ) two).trans (OMA.PrimePowerDiv245212.power_divides hm prime cop d eq)
    have div' : (r:ℤ)*(r:ℤ) ∣ (W m:ℤ)+(σ 1 m:ℤ)-(r:ℤ)*(σ 1 m:ℤ) := by
      rw [pow_two] at div
      rwa [show (W m:ℤ)+(σ 1 m:ℤ)-(r:ℤ)*(σ 1 m:ℤ)=
        (W m:ℤ)-((r:ℤ)-1)*(σ 1 m:ℤ) by ring]
    have mod := Int.modEq_iff_dvd.mpr div'
    change ((r:ℤ)*(σ 1 m:ℤ))%((r:ℤ)*(r:ℤ))=((W m:ℤ)+(σ 1 m:ℤ))%((r:ℤ)*(r:ℤ)) at mod
    exact_mod_cast mod.symm

private def eligible (r : ℕ) : Bool :=
  r≤7 || (r%2!=0 && r%3!=0 && r%5!=0 && r%7!=0)
private theorem eligible_of {r : ℕ} (hp : r.Prime) : eligible r=true := by
  by_cases sm : r≤7
  · simp [eligible,sm]
  have nr (x : ℕ) (a : 1<x) (b : x≤7) : r%x≠0 := by
    intro h
    have := (Nat.dvd_prime hp).1 (Nat.dvd_of_mod_eq_zero h)
    omega
  have od:=Nat.odd_iff.mp (hp.odd_of_ne_two (by omega))
  simp [eligible,sm,od,nr 3 (by decide) (by decide),
    nr 5 (by decide) (by decide),nr 7 (by decide) (by decide)]

structure Packet where
  primes : List ℕ
  product : ℕ
def pack (R : Range) : Packet :=
  let cs:=R.entries.filter eligible
  ⟨cs,cs.prod⟩
private theorem divides {r : ℕ} {rs : List ℕ} (h : r∈rs) : r∣rs.prod := by
  induction rs with
  | nil => simp at h
  | cons a rs ih =>
    rw [List.mem_cons] at h
    rw [List.prod_cons]
    rcases h with rfl|h
    · exact dvd_mul_right _ _
    · exact (ih h).trans (dvd_mul_left _ _)

private def viable (A S T : ℕ) (D : Range) (r : ℕ) : Bool :=
  (A+S)%r==0 && ((D.lo≤1 && A+S+r*(2*A+S)==4*T*r) ||
    (2≤D.hi && (A+S)%(r*r)==(r*S)%(r*r)))

def veto (w : Packet) (A S T : ℕ) (R D : Range) : Bool :=
  (Nat.gcd (A+S) w.product < R.lo) || !w.primes.any (viable A S T D)

private theorem veto_false {m r d : ℕ} (hm : 0 < m) (pr : r.Prime) (cop : m.Coprime r)
    (hd : 0<d) (eq : OeisA245212.a (m*r^d)=(σ 1 (m*r^d):ℤ)) {R D : Range}
    (hr : R.has r) (he : D.has d) : veto (pack R) (W m) (σ 1 m) (m*(σ 0 m)) R D=false := by
  have hr' : r∈(pack R).primes := List.mem_filter.mpr ⟨Range.mem_entries hr,eligible_of pr⟩
  obtain ⟨dv,one,two⟩ := localData hm pr cop hd eq
  have dc : r∣Nat.gcd (W m+σ 1 m) (pack R).product := Nat.dvd_gcd dv (divides hr')
  have gp : 0<Nat.gcd (W m+σ 1 m) (pack R).product :=
    Nat.gcd_pos_of_pos_left _ (by have := sigma_pos 1 m hm.ne';omega)
  have large := hr.1.trans (Nat.le_of_dvd gp dc)
  have live : viable (W m) (σ 1 m) (m*(σ 0 m)) D r=true := by
    unfold viable
    rw [Nat.mod_eq_zero_of_dvd dv]
    by_cases h : d=1
    · simp [one h,show D.lo≤1 by simpa [h] using he.1]
    · simp [two (by omega),show 2≤D.hi by have := he.2;omega]
  simp [veto,not_lt.mpr large,List.any_eq_true.mpr ⟨r,hr',live⟩]

private theorem candidateVeto {p q : ℕ} {v : Values} (c : Candidate p q v) {D R : Range}
    (ed : D.has (v 3)) (rr : R.has (v 4)) :
    veto (pack R) (wt 3 (v 0)*wt p (v 1)*wt q (v 2)) (sig 3 (v 0)*sig p (v 1)*sig q (v 2))
      (tax 3 (v 0)*tax p (v 1)*tax q (v 2)) R D=false := by
  let m:=3^(v 0)*p^(v 1)*q^(v 2)
  have hp : p.Prime := c.prime 1
  have hq : q.Prime := c.prime 2
  have hr : (v 4).Prime := c.prime 3
  have p3 : 3<p := c.ordered (show (0:Fin 4)<1 by decide)
  have pq : p<q := c.ordered (show (1:Fin 4)<2 by decide)
  have qr : q<v 4 := c.ordered (show (2:Fin 4)<3 by decide)
  have same : total (Box245212.bases p q v) (exponents v)=m*(v 4)^(v 3) := by
    simp [total,Box245212.bases,exponents,m,Fin.prod_univ_four]
  have s:=c.eqn; dsimp only at s; rw [same] at s
  have cop : m.Coprime (v 4) :=
    (((Nat.coprime_primes Nat.prime_three hr).mpr (by omega)).pow_left _).mul_left
      (((Nat.coprime_primes hp hr).mpr (by omega)).pow_left _) |>.mul_left
        (((Nat.coprime_primes hq hr).mpr qr.ne).pow_left _)
  have mp : 0 < m := mul_pos (mul_pos (pow_pos (by decide) _) (pow_pos hp.pos _)) (pow_pos hq.pos _)
  have no:=veto_false mp hr cop (c.pos 3) s rr ed
  obtain ⟨aa,ss,tt⟩:=OMA.PrefixLeaf245212.triple Nat.prime_three hp hq p3.ne (by omega) pq.ne (v 0) (v 1) (v 2)
  dsimp only [m] at no
  simpa only [aa,ss,tt] using no

/-- `limit` caps how many sequential integers may be put in the wheel.
The same theorem covers any timing-driven choice of the threshold. -/
def test (limit p q : ℕ) (b : Box) : Bool :=
  let short:=decide ((b 4).hi-(b 4).lo<limit)
  let w:=pack (b 4)
  decide (1<(b 4).lo) && ((b 0).entries.all fun k=>(b 1).entries.all fun e=>(b 2).entries.all fun f=>
    (let A:=wt 3 k*wt p e*wt q f; let S:=sig 3 k*sig p e*sig q f
     let T:=tax 3 k*tax p e*tax q f
     (short && veto w A S T (b 4) (b 3)) ||
       OMA.QuickPrefix245212.quick A S T (b 4).lo (b 4).hi (b 3).lo (b 3).hi))

theorem test_ok {limit p q : ℕ} {b : Box} (yes : test limit p q b=true) : Deny p q b := by
  intro v fit c
  obtain ⟨base,all⟩ := Bool.and_eq_true_iff.mp yes
  have yes := List.all_eq_true.mp (List.all_eq_true.mp (List.all_eq_true.mp all (v 0)
    (Range.mem_entries (fit 0))) (v 1) (Range.mem_entries (fit 1))) (v 2) (Range.mem_entries (fit 2))
  dsimp only at yes
  rw [candidateVeto c (fit 3) (fit 4)] at yes
  simp only [Bool.false_or,Bool.and_false] at yes
  exact OMA.QuickPrefix245212.atPrefix fit c base yes

end OMA.WheelPrefix245212
