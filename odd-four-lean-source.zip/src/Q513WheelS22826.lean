import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S22826
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b22826 : Box := ![⟨31,46⟩,⟨63,1920000000000000011376⟩,⟨15,1920000000000000011376⟩,⟨3,1839007444168734502247⟩,⟨79,113⟩]
theorem deny5_13 : Deny 5 13 ![⟨31,46⟩,⟨63,1920000000000000011376⟩,⟨15,1920000000000000011376⟩,⟨3,1839007444168734502247⟩,⟨79,113⟩] := by
  have e22826 : Deny 5 13 b22826 := by
    apply closeAction rule_sound _ _ 64 [0x84a847ddf083847dc3dc38478491020e127710b0c38490e11e11e12a3263102097e370e11e11e127710b8c88c98c41f8,0x825a2108e370ab082083e370c92442380aa0f8dea0c8216dc32430c72481020831c4238dd7e370e11e126110b]
    decide +kernel
  exact e22826
end OMA.Blocks5_13_245212.S22826
