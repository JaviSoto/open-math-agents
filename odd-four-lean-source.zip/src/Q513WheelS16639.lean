import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S16639
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b16639 : Box := ![⟨95,1920000000000000011376⟩,⟨11,14⟩,⟨19,1920000000000000011376⟩,⟨1,1495788262370540860443⟩,⟨195,768⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,1920000000000000011376⟩,⟨11,14⟩,⟨19,1920000000000000011376⟩,⟨1,1495788262370540860443⟩,⟨195,768⟩] := by
  have e16639 : Deny 5 13 b16639 := by
    apply closeAction rule_sound _ _ 64 [0x56688a747578db488a54adb48c4088e37db48c856688ad9d72f11d278da31d5e3688ad952822021f68c4088e37da31e3,0x9a22959a229d76229529d566804578df6107e3680a11de37db48c42388c954a8c78c42d99e311de36d278c41f89e325d,0x75599d887e222999e311d1f89e32559a229dbe311de37db48c4278da31d5e36d222a375599d88788a6677479e3255]
    decide +kernel
  exact e16639
end OMA.Blocks5_13_245212.S16639
