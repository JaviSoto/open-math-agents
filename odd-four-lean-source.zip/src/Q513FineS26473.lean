import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S26473
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b26473 : Box := ![⟨31,46⟩,⟨31,62⟩,⟨15,30⟩,⟨1,900178041543026711610⟩,⟨239,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨31,46⟩,⟨31,62⟩,⟨15,30⟩,⟨1,900178041543026711610⟩,⟨239,999999999999999999⟩] := by
  have e26473 : Deny 5 13 b26473 := by
    apply closeAction rule_sound _ _ 64 [0xc3e080f8244087e080c22421c4088e352442f8297e362830f8df62021c4088e36d47e3629729fe37da32388c21f8d63,0x1f7df0c3e070f8243e36203e361c42f6088e360f80c70c80c3e082420c41f80c80c320910b0c3e080f8247]
    decide +kernel
  exact e26473
end OMA.Blocks5_13_245212.S26473
