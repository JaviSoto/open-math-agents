import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S50221
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b50221 : Box := ![⟨95,126⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨1,799016681299385430590⟩,⟨479,958⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,126⟩,⟨21,24⟩,⟨63,1920000000000000011376⟩,⟨1,799016681299385430590⟩,⟨479,958⟩] := by
  have e50221 : Deny 5 13 b50221 := by
    apply closeAction rule_sound _ _ 64 [0x25522228409d54a88888b7437c988a08811d75f2a229f29d0f8df68842b8da22222e21e22e21e22a326321588a5622a3,0x9d7e22a31e327872f8ddbe3278bdd778748e152b8743e03e221f80f8255283e36884087e3688754a088e2229d578dc3,0x2]
    decide +kernel
  exact e50221
end OMA.Blocks5_13_245212.S50221
