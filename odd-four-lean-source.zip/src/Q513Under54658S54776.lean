import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S54776
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b54776 : Box := ![⟨58,62⟩,⟨87,126⟩,⟨13,14⟩,⟨3,48⟩,⟨959,434784⟩]
private def b54777 : Box := ![⟨58,62⟩,⟨87,126⟩,⟨13,14⟩,⟨3,48⟩,⟨959,1914⟩]
private def b54778 : Box := ![⟨58,62⟩,⟨87,102⟩,⟨13,14⟩,⟨3,47⟩,⟨959,1914⟩]
private def b54779 : Box := ![⟨58,59⟩,⟨87,102⟩,⟨13,14⟩,⟨4,41⟩,⟨959,1914⟩]
private def b54780 : Box := ![⟨60,62⟩,⟨87,102⟩,⟨13,14⟩,⟨4,41⟩,⟨959,1914⟩]
private def b54781 : Box := ![⟨58,62⟩,⟨103,126⟩,⟨13,14⟩,⟨3,47⟩,⟨959,1914⟩]
private def b54782 : Box := ![⟨58,59⟩,⟨103,126⟩,⟨13,14⟩,⟨7,47⟩,⟨959,1914⟩]
private def b54783 : Box := ![⟨60,62⟩,⟨103,126⟩,⟨13,14⟩,⟨7,47⟩,⟨959,1914⟩]
private def b54784 : Box := ![⟨60,62⟩,⟨103,113⟩,⟨13,14⟩,⟨7,47⟩,⟨959,1914⟩]
private def b54785 : Box := ![⟨60,62⟩,⟨114,126⟩,⟨13,14⟩,⟨7,47⟩,⟨959,1914⟩]
private def b54786 : Box := ![⟨58,62⟩,⟨87,126⟩,⟨13,14⟩,⟨3,48⟩,⟨1915,378972⟩]
private def b54787 : Box := ![⟨58,62⟩,⟨87,102⟩,⟨13,14⟩,⟨3,43⟩,⟨1915,378972⟩]
private def b54788 : Box := ![⟨58,59⟩,⟨87,102⟩,⟨13,14⟩,⟨8,38⟩,⟨1915,2096⟩]
private def b54789 : Box := ![⟨60,62⟩,⟨87,102⟩,⟨13,14⟩,⟨8,38⟩,⟨1915,2096⟩]
private def b54790 : Box := ![⟨58,62⟩,⟨103,126⟩,⟨13,14⟩,⟨3,43⟩,⟨1915,378972⟩]
private def b54791 : Box := ![⟨58,59⟩,⟨103,126⟩,⟨13,14⟩,⟨4,43⟩,⟨1915,257435⟩]
private def b54792 : Box := ![⟨60,62⟩,⟨103,126⟩,⟨13,14⟩,⟨4,43⟩,⟨1915,257435⟩]
private def b54793 : Box := ![⟨60,62⟩,⟨103,113⟩,⟨13,14⟩,⟨4,43⟩,⟨1915,251169⟩]
private def b54794 : Box := ![⟨60,62⟩,⟨114,126⟩,⟨13,14⟩,⟨4,43⟩,⟨1915,251169⟩]
private theorem e54779 : Deny 5 13 b54779 := by
    apply closeAction rule_sound _ _ 64 [0x3e37]
    decide +kernel
private theorem e54780 : Deny 5 13 b54780 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e54778 : Deny 5 13 b54778 :=
    branchAction rule_sound _ _ 3
      0x7ae3 b54778 b54779 b54780 (by decide +kernel) e54779 e54780
private theorem e54782 : Deny 5 13 b54782 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e54784 : Deny 5 13 b54784 := by
    apply closeAction rule_sound _ _ 64 [0xe3]
    decide +kernel
private theorem e54785 : Deny 5 13 b54785 := by
    apply closeAction rule_sound _ _ 64 [0x3e2b]
    decide +kernel
private theorem e54783 : Deny 5 13 b54783 :=
    branchAction rule_sound _ _ 1
      0x8 b54783 b54784 b54785 (by decide +kernel) e54784 e54785
private theorem e54781 : Deny 5 13 b54781 :=
    branchAction rule_sound _ _ 2
      0x1eb b54781 b54782 b54783 (by decide +kernel) e54782 e54783
private theorem e54777 : Deny 5 13 b54777 :=
    branchAction rule_sound _ _ 2
      0x223 b54777 b54778 b54781 (by decide +kernel) e54778 e54781
private theorem e54788 : Deny 5 13 b54788 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e54789 : Deny 5 13 b54789 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e54787 : Deny 5 13 b54787 :=
    branchAction rule_sound _ _ 4
      0x1f8de3 b54787 b54788 b54789 (by decide +kernel) e54788 e54789
private theorem e54791 : Deny 5 13 b54791 := by
    apply closeAction rule_sound _ _ 64 [0x3e2b]
    decide +kernel
private theorem e54793 : Deny 5 13 b54793 := by
    apply closeAction rule_sound _ _ 64 [0x3e23]
    decide +kernel
private theorem e54794 : Deny 5 13 b54794 := by
    apply closeAction rule_sound _ _ 64 [0x3e2b]
    decide +kernel
private theorem e54792 : Deny 5 13 b54792 :=
    branchAction rule_sound _ _ 2
      0x238 b54792 b54793 b54794 (by decide +kernel) e54793 e54794
private theorem e54790 : Deny 5 13 b54790 :=
    branchAction rule_sound _ _ 3
      0x7e2b b54790 b54791 b54792 (by decide +kernel) e54791 e54792
private theorem e54786 : Deny 5 13 b54786 :=
    branchAction rule_sound _ _ 2
      0x223 b54786 b54787 b54790 (by decide +kernel) e54787 e54790
private theorem e54776 : Deny 5 13 b54776 :=
    branchAction rule_sound _ _ 2
      0x2f8 b54776 b54777 b54786 (by decide +kernel) e54777 e54786
theorem deny5_13 : Deny 5 13 ![⟨58,62⟩,⟨87,126⟩,⟨13,14⟩,⟨3,48⟩,⟨959,434784⟩] := by
  exact e54776
end OMA.Blocks5_13_245212.S54776
