import FastReplay245212
import SparseDigit245212
import FastRound245212
import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S25260
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b25260 : Box := ![⟨47,1920000000000000011376⟩,⟨15,1920000000000000011376⟩,⟨7,1920000000000000011376⟩,⟨1,1920000000000000011376⟩,⟨51,999999999999999999⟩]
private def b25261 : Box := ![⟨47,1920000000000000011376⟩,⟨15,1920000000000000011376⟩,⟨7,1920000000000000011376⟩,⟨1,1920000000000000011376⟩,⟨63,126⟩]
private def b25262 : Box := ![⟨47,1920000000000000011376⟩,⟨15,30⟩,⟨7,129⟩,⟨1,10⟩,⟨67,113⟩]
private def b25263 : Box := ![⟨47,382⟩,⟨15,30⟩,⟨7,14⟩,⟨1,10⟩,⟨67,113⟩]
private def b25264 : Box := ![⟨47,128⟩,⟨15,20⟩,⟨7,14⟩,⟨1,10⟩,⟨67,113⟩]
private def b25279 : Box := ![⟨47,128⟩,⟨21,30⟩,⟨7,14⟩,⟨1,10⟩,⟨67,113⟩]
private def b25280 : Box := ![⟨47,382⟩,⟨15,30⟩,⟨15,128⟩,⟨1,10⟩,⟨67,113⟩]
private def b25281 : Box := ![⟨47,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨7,129⟩,⟨1,10⟩,⟨67,113⟩]
private def b25282 : Box := ![⟨47,1920000000000000011376⟩,⟨15,1920000000000000011376⟩,⟨7,1920000000000000011376⟩,⟨1,1920000000000000011376⟩,⟨127,999999999999999999⟩]
private def b25283 : Box := ![⟨47,1920000000000000011376⟩,⟨15,30⟩,⟨7,1920000000000000011376⟩,⟨1,1920000000000000011376⟩,⟨127,999999999999999999⟩]
private def b25284 : Box := ![⟨47,1920000000000000011376⟩,⟨15,30⟩,⟨7,14⟩,⟨1,1387382550335570478058⟩,⟨127,999999999999999999⟩]
private def b25285 : Box := ![⟨47,94⟩,⟨15,30⟩,⟨7,14⟩,⟨1,435973154362416110002⟩,⟨127,999999999999999999⟩]
private def b25286 : Box := ![⟨47,94⟩,⟨15,30⟩,⟨7,14⟩,⟨1,49⟩,⟨127,254⟩]
private def b25287 : Box := ![⟨47,94⟩,⟨15,20⟩,⟨7,14⟩,⟨1,41⟩,⟨127,251⟩]
private def b25288 : Box := ![⟨47,94⟩,⟨15,20⟩,⟨7,9⟩,⟨1,38⟩,⟨127,251⟩]
private def b25303 : Box := ![⟨47,94⟩,⟨15,20⟩,⟨10,14⟩,⟨1,38⟩,⟨127,251⟩]
private def b25312 : Box := ![⟨47,94⟩,⟨21,30⟩,⟨7,14⟩,⟨1,41⟩,⟨127,251⟩]
private def b25321 : Box := ![⟨47,94⟩,⟨15,30⟩,⟨7,14⟩,⟨1,49⟩,⟨255,999999999999999999⟩]
private def b25322 : Box := ![⟨47,94⟩,⟨15,20⟩,⟨7,14⟩,⟨1,42⟩,⟨255,999999999999999999⟩]
private def b25323 : Box := ![⟨47,94⟩,⟨15,20⟩,⟨7,9⟩,⟨1,39⟩,⟨255,999999999999999999⟩]
private def b25324 : Box := ![⟨47,62⟩,⟨15,20⟩,⟨7,9⟩,⟨1,37⟩,⟨255,999999999999999999⟩]
private def b25329 : Box := ![⟨63,94⟩,⟨15,20⟩,⟨7,9⟩,⟨1,37⟩,⟨255,999999999999999999⟩]
private def b25330 : Box := ![⟨63,94⟩,⟨15,20⟩,⟨7,9⟩,⟨1,37⟩,⟨255,510⟩]
private def b25343 : Box := ![⟨63,94⟩,⟨15,20⟩,⟨7,9⟩,⟨1,37⟩,⟨511,999999999999999999⟩]
private def b25354 : Box := ![⟨47,94⟩,⟨15,20⟩,⟨10,14⟩,⟨1,39⟩,⟨255,999999999999999999⟩]
private def b25355 : Box := ![⟨47,62⟩,⟨15,20⟩,⟨10,14⟩,⟨1,39⟩,⟨255,999999999999999999⟩]
private def b25356 : Box := ![⟨47,62⟩,⟨15,20⟩,⟨10,14⟩,⟨1,33⟩,⟨255,510⟩]
private def b25365 : Box := ![⟨47,62⟩,⟨15,20⟩,⟨10,14⟩,⟨1,33⟩,⟨511,999999999999999999⟩]
private def b25376 : Box := ![⟨63,94⟩,⟨15,20⟩,⟨10,14⟩,⟨1,39⟩,⟨255,999999999999999999⟩]
private def b25377 : Box := ![⟨63,94⟩,⟨15,17⟩,⟨10,14⟩,⟨1,39⟩,⟨259,999999999999999999⟩]
private def b25392 : Box := ![⟨63,94⟩,⟨18,20⟩,⟨10,14⟩,⟨1,39⟩,⟨259,999999999999999999⟩]
private def b25393 : Box := ![⟨47,94⟩,⟨21,30⟩,⟨7,14⟩,⟨1,42⟩,⟨255,999999999999999999⟩]
private def b25394 : Box := ![⟨47,94⟩,⟨21,30⟩,⟨7,9⟩,⟨1,42⟩,⟨255,999999999999999999⟩]
private def b25395 : Box := ![⟨47,62⟩,⟨21,30⟩,⟨7,9⟩,⟨1,40⟩,⟨255,999999999999999999⟩]
private def b25396 : Box := ![⟨47,62⟩,⟨21,30⟩,⟨7,9⟩,⟨1,34⟩,⟨255,510⟩]
private def b25403 : Box := ![⟨47,62⟩,⟨21,30⟩,⟨7,9⟩,⟨1,34⟩,⟨511,999999999999999999⟩]
private def b25412 : Box := ![⟨63,94⟩,⟨21,30⟩,⟨7,9⟩,⟨1,40⟩,⟨255,999999999999999999⟩]
private def b25419 : Box := ![⟨47,94⟩,⟨21,30⟩,⟨10,14⟩,⟨1,42⟩,⟨255,999999999999999999⟩]
private def b25428 : Box := ![⟨95,1920000000000000011376⟩,⟨15,30⟩,⟨7,14⟩,⟨1,435973154362416110002⟩,⟨127,999999999999999999⟩]
private def b25429 : Box := ![⟨95,1920000000000000011376⟩,⟨15,20⟩,⟨7,14⟩,⟨1,435973154362416110002⟩,⟨180,999999999999999999⟩]
private def b25430 : Box := ![⟨95,1920000000000000011376⟩,⟨15,20⟩,⟨7,9⟩,⟨1,406847599164926933548⟩,⟨180,999999999999999999⟩]
private def b25431 : Box := ![⟨95,1920000000000000011376⟩,⟨15,20⟩,⟨7,9⟩,⟨1,406847599164926933545⟩,⟨180,360⟩]
private def b25440 : Box := ![⟨95,1920000000000000011376⟩,⟨15,20⟩,⟨7,9⟩,⟨1,406847599164926933545⟩,⟨361,999999999999999999⟩]
private def b25441 : Box := ![⟨95,190⟩,⟨15,20⟩,⟨7,9⟩,⟨1,358564857405703773999⟩,⟨361,999999999999999999⟩]
private def b25442 : Box := ![⟨95,190⟩,⟨15,17⟩,⟨7,9⟩,⟨1,53⟩,⟨361,999999999999999999⟩]
private def b25443 : Box := ![⟨95,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,52⟩,⟨361,722⟩]
private def b25452 : Box := ![⟨95,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,52⟩,⟨723,999999999999999999⟩]
private def b25453 : Box := ![⟨95,126⟩,⟨15,17⟩,⟨7,9⟩,⟨2,47⟩,⟨723,999999999999999999⟩]
private def b25458 : Box := ![⟨127,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,47⟩,⟨723,999999999999999999⟩]
private def b25459 : Box := ![⟨127,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,47⟩,⟨723,1446⟩]
private def b25460 : Box := ![⟨127,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,47⟩,⟨1447,999999999999999999⟩]
private def b25461 : Box := ![⟨127,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,42⟩,⟨1447,2894⟩]
private def b25462 : Box := ![⟨127,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,42⟩,⟨2895,999999999999999999⟩]
private def b25463 : Box := ![⟨127,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,38⟩,⟨2895,5790⟩]
private def b25464 : Box := ![⟨127,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,38⟩,⟨5791,999999999999999999⟩]
private def b25465 : Box := ![⟨127,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,35⟩,⟨5791,11582⟩]
private def b25466 : Box := ![⟨127,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,35⟩,⟨11583,999999999999999999⟩]
private def b25467 : Box := ![⟨127,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,33⟩,⟨11583,23166⟩]
private def b25468 : Box := ![⟨127,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,33⟩,⟨23167,999999999999999999⟩]
private def b25469 : Box := ![⟨127,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,30⟩,⟨23167,46334⟩]
private def b25470 : Box := ![⟨127,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,30⟩,⟨46335,999999999999999999⟩]
private def b25471 : Box := ![⟨127,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,28⟩,⟨46335,92670⟩]
private def b25472 : Box := ![⟨127,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,28⟩,⟨92671,999999999999999999⟩]
private def b25473 : Box := ![⟨127,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,27⟩,⟨92671,185342⟩]
private def b25474 : Box := ![⟨127,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,27⟩,⟨185343,999999999999999999⟩]
private def b25475 : Box := ![⟨127,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,25⟩,⟨185343,370686⟩]
private def b25476 : Box := ![⟨127,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,25⟩,⟨370687,999999999999999999⟩]
private def b25477 : Box := ![⟨127,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,24⟩,⟨370687,741374⟩]
private def b25478 : Box := ![⟨127,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,24⟩,⟨741375,999999999999999999⟩]
private def b25479 : Box := ![⟨127,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,22⟩,⟨741375,1482750⟩]
private def b25480 : Box := ![⟨127,190⟩,⟨15,17⟩,⟨7,9⟩,⟨2,22⟩,⟨1482751,999999999999999999⟩]
private def b25495 : Box := ![⟨95,190⟩,⟨18,20⟩,⟨7,9⟩,⟨1,53⟩,⟨361,999999999999999999⟩]
private def b25500 : Box := ![⟨191,1920000000000000011376⟩,⟨15,20⟩,⟨7,9⟩,⟨1,358564857405703773999⟩,⟨361,999999999999999999⟩]
private def b25511 : Box := ![⟨95,1920000000000000011376⟩,⟨15,20⟩,⟨10,14⟩,⟨1,406847599164926933548⟩,⟨180,999999999999999999⟩]
private def b25512 : Box := ![⟨95,1920000000000000011376⟩,⟨21,30⟩,⟨7,14⟩,⟨1,435973154362416110002⟩,⟨180,999999999999999999⟩]
private def b25513 : Box := ![⟨47,1920000000000000011376⟩,⟨15,30⟩,⟨15,1920000000000000011376⟩,⟨1,1387382550335570478058⟩,⟨127,999999999999999999⟩]
private def b25514 : Box := ![⟨47,94⟩,⟨15,30⟩,⟨15,1920000000000000011376⟩,⟨1,1387382550335570478058⟩,⟨291,999999999999999999⟩]
private def b25515 : Box := ![⟨47,94⟩,⟨15,20⟩,⟨15,1920000000000000011376⟩,⟨1,812378223495702010588⟩,⟨291,999999999999999999⟩]
private def b25516 : Box := ![⟨47,94⟩,⟨15,20⟩,⟨15,30⟩,⟨1,812378223495702010585⟩,⟨291,999999999999999999⟩]
private def b25517 : Box := ![⟨47,62⟩,⟨15,20⟩,⟨15,30⟩,⟨1,45⟩,⟨293,999999999999999999⟩]
private def b25518 : Box := ![⟨47,62⟩,⟨15,17⟩,⟨15,30⟩,⟨1,39⟩,⟨294,999999999999999999⟩]
private def b25519 : Box := ![⟨47,62⟩,⟨15,17⟩,⟨15,30⟩,⟨1,38⟩,⟨294,588⟩]
private def b25524 : Box := ![⟨47,62⟩,⟨15,17⟩,⟨15,30⟩,⟨1,38⟩,⟨589,999999999999999999⟩]
private def b25535 : Box := ![⟨47,62⟩,⟨18,20⟩,⟨15,30⟩,⟨1,39⟩,⟨294,999999999999999999⟩]
private def b25536 : Box := ![⟨63,94⟩,⟨15,20⟩,⟨15,30⟩,⟨1,45⟩,⟨293,999999999999999999⟩]
private def b25537 : Box := ![⟨47,94⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨1,812378223495702010585⟩,⟨291,999999999999999999⟩]
private def b25538 : Box := ![⟨47,94⟩,⟨21,30⟩,⟨15,1920000000000000011376⟩,⟨1,812378223495702010588⟩,⟨291,999999999999999999⟩]
private def b25539 : Box := ![⟨95,1920000000000000011376⟩,⟨15,30⟩,⟨15,1920000000000000011376⟩,⟨1,1387382550335570478058⟩,⟨291,999999999999999999⟩]
private def b25540 : Box := ![⟨47,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨7,1920000000000000011376⟩,⟨1,1920000000000000011376⟩,⟨127,999999999999999999⟩]
private def b25541 : Box := ![⟨47,94⟩,⟨31,1920000000000000011376⟩,⟨7,19⟩,⟨1,1920000000000000011376⟩,⟨4112,999999999999999999⟩]
private def b25556 : Box := ![⟨95,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨7,19⟩,⟨1,1920000000000000011376⟩,⟨4112,999999999999999999⟩]
theorem deny5_11 : Deny 5 11 ![⟨47,1920000000000000011376⟩,⟨15,1920000000000000011376⟩,⟨7,1920000000000000011376⟩,⟨1,1920000000000000011376⟩,⟨51,999999999999999999⟩] := by
  have e25264 : Deny 5 11 b25264 := by
    apply closeAction rule_sound _ _ 64 [0x5f8dc29c20831c42380838042380e024a1e0260]
    decide +kernel
  have e25279 : Deny 5 11 b25279 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e25263 : Deny 5 11 b25263 :=
    branchAction rule_sound _ _ 2
      0x220 b25263 b25264 b25279 (by decide +kernel) e25264 e25279
  have e25280 : Deny 5 11 b25280 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e25262 : Deny 5 11 b25262 :=
    branchAction rule_sound _ _ 3
      0x9da0 b25262 b25263 b25280 (by decide +kernel) e25263 e25280
  have e25281 : Deny 5 11 b25281 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e25261 : Deny 5 11 b25261 :=
    branchAction rule_sound _ _ 4
      0x237d84 b25261 b25262 b25281 (by decide +kernel) e25262 e25281
  have e25288 : Deny 5 11 b25288 := by
    apply closeAction rule_sound _ _ 64 [0x820e3107e03e232632380a79a580a0c38c80e32631e3]
    decide +kernel
  have e25303 : Deny 5 11 b25303 := by
    apply closeAction rule_sound _ _ 64 [0x25f8dc20c41f8dc38c98c88c7]
    decide +kernel
  have e25287 : Deny 5 11 b25287 :=
    branchAction rule_sound _ _ 2
      0x263 b25287 b25288 b25303 (by decide +kernel) e25288 e25303
  have e25312 : Deny 5 11 b25312 := by
    apply closeAction rule_sound _ _ 64 [0x82083e370c8207109e37]
    decide +kernel
  have e25286 : Deny 5 11 b25286 :=
    branchAction rule_sound _ _ 3
      0x88c4 b25286 b25287 b25312 (by decide +kernel) e25287 e25312
  have e25324 : Deny 5 11 b25324 := by
    apply closeAction rule_sound _ _ 64 [0xc3e23203e23263]
    decide +kernel
  have e25330 : Deny 5 11 b25330 := by
    apply closeAction rule_sound _ _ 64 [0x11e370f8dc38c9e231f80f80e32438c98c80e79602a3]
    decide +kernel
  have e25343 : Deny 5 11 b25343 := by
    apply closeAction rule_sound _ _ 64 [0xf80c90e32430c90f8de3263223]
    decide +kernel
  have e25329 : Deny 5 11 b25329 :=
    branchAction rule_sound _ _ 1
      0xb b25329 b25330 b25343 (by decide +kernel) e25330 e25343
  have e25323 : Deny 5 11 b25323 :=
    branchAction rule_sound _ _ 2
      0x1e3 b25323 b25324 b25329 (by decide +kernel) e25324 e25329
  have e25356 : Deny 5 11 b25356 := by
    apply closeAction rule_sound _ _ 64 [0x838c90f8dc38c70e3263223]
    decide +kernel
  have e25365 : Deny 5 11 b25365 := by
    apply closeAction rule_sound _ _ 64 [0x20f88c7e038c90c38c70e3263223]
    decide +kernel
  have e25355 : Deny 5 11 b25355 :=
    branchAction rule_sound _ _ 2
      0x2e3 b25355 b25356 b25365 (by decide +kernel) e25356 e25365
  have e25377 : Deny 5 11 b25377 := by
    apply closeAction rule_sound _ _ 64 [0x83e23238083e232380e32631e30820f88c9e231e32e3]
    decide +kernel
  have e25392 : Deny 5 11 b25392 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e25376 : Deny 5 11 b25376 :=
    branchAction rule_sound _ _ 2
      0x238 b25376 b25377 b25392 (by decide +kernel) e25377 e25392
  have e25354 : Deny 5 11 b25354 :=
    branchAction rule_sound _ _ 1
      0x7 b25354 b25355 b25376 (by decide +kernel) e25355 e25376
  have e25322 : Deny 5 11 b25322 :=
    branchAction rule_sound _ _ 2
      0x263 b25322 b25323 b25354 (by decide +kernel) e25323 e25354
  have e25396 : Deny 5 11 b25396 := by
    apply closeAction rule_sound _ _ 64 [0x838c9e030e3223223]
    decide +kernel
  have e25403 : Deny 5 11 b25403 := by
    apply closeAction rule_sound _ _ 64 [0x20f88c7e038c90c3223223]
    decide +kernel
  have e25395 : Deny 5 11 b25395 :=
    branchAction rule_sound _ _ 2
      0x2e3 b25395 b25396 b25403 (by decide +kernel) e25396 e25403
  have e25412 : Deny 5 11 b25412 := by
    apply closeAction rule_sound _ _ 64 [0x82083e232788c7e23238]
    decide +kernel
  have e25394 : Deny 5 11 b25394 :=
    branchAction rule_sound _ _ 2
      0x1e3 b25394 b25395 b25412 (by decide +kernel) e25395 e25412
  have e25419 : Deny 5 11 b25419 := by
    apply closeAction rule_sound _ _ 64 [0x820820f88c9e231f88c8e231f8]
    decide +kernel
  have e25393 : Deny 5 11 b25393 :=
    branchAction rule_sound _ _ 1
      0x9 b25393 b25394 b25419 (by decide +kernel) e25394 e25419
  have e25321 : Deny 5 11 b25321 :=
    branchAction rule_sound _ _ 2
      0x223 b25321 b25322 b25393 (by decide +kernel) e25322 e25393
  have e25285 : Deny 5 11 b25285 :=
    branchAction rule_sound _ _ 2
      0x2e3 b25285 b25286 b25321 (by decide +kernel) e25286 e25321
  have e25431 : Deny 5 11 b25431 := by
    apply closeAction rule_sound _ _ 64 [0x20820839e3263107e278c42389e31e3]
    decide +kernel
  have e25443 : Deny 5 11 b25443 := by
    apply closeAction rule_sound _ _ 64 [0x6676420f89e0108e039e024a8c79e3]
    decide +kernel
  have e25453 : Deny 5 11 b25453 := by
    apply closeAction rule_sound _ _ 64 [0x3e038c90e3263]
    decide +kernel
  have e25459 : Deny 5 11 b25459 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e25461 : Deny 5 11 b25461 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e25463 : Deny 5 11 b25463 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e25465 : Deny 5 11 b25465 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e25467 : Deny 5 11 b25467 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e25469 : Deny 5 11 b25469 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e25471 : Deny 5 11 b25471 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e25473 : Deny 5 11 b25473 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e25475 : Deny 5 11 b25475 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e25477 : Deny 5 11 b25477 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e25479 : Deny 5 11 b25479 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e25480 : Deny 5 11 b25480 := by
    apply closeAction rule_sound _ _ 64 [0x20838c72020e31c22272636678cb8d99e32e3]
    decide +kernel
  have e25478 : Deny 5 11 b25478 :=
    branchAction rule_sound _ _ 2
      0x2e3 b25478 b25479 b25480 (by decide +kernel) e25479 e25480
  have e25476 : Deny 5 11 b25476 :=
    branchAction rule_sound _ _ 2
      0x2e3 b25476 b25477 b25478 (by decide +kernel) e25477 e25478
  have e25474 : Deny 5 11 b25474 :=
    branchAction rule_sound _ _ 2
      0x2e3 b25474 b25475 b25476 (by decide +kernel) e25475 e25476
  have e25472 : Deny 5 11 b25472 :=
    branchAction rule_sound _ _ 2
      0x2e3 b25472 b25473 b25474 (by decide +kernel) e25473 e25474
  have e25470 : Deny 5 11 b25470 :=
    branchAction rule_sound _ _ 2
      0x2e3 b25470 b25471 b25472 (by decide +kernel) e25471 e25472
  have e25468 : Deny 5 11 b25468 :=
    branchAction rule_sound _ _ 2
      0x2e3 b25468 b25469 b25470 (by decide +kernel) e25469 e25470
  have e25466 : Deny 5 11 b25466 :=
    branchAction rule_sound _ _ 2
      0x2e3 b25466 b25467 b25468 (by decide +kernel) e25467 e25468
  have e25464 : Deny 5 11 b25464 :=
    branchAction rule_sound _ _ 2
      0x2e3 b25464 b25465 b25466 (by decide +kernel) e25465 e25466
  have e25462 : Deny 5 11 b25462 :=
    branchAction rule_sound _ _ 2
      0x2e3 b25462 b25463 b25464 (by decide +kernel) e25463 e25464
  have e25460 : Deny 5 11 b25460 :=
    branchAction rule_sound _ _ 2
      0x2e3 b25460 b25461 b25462 (by decide +kernel) e25461 e25462
  have e25458 : Deny 5 11 b25458 :=
    branchAction rule_sound _ _ 1
      0xb b25458 b25459 b25460 (by decide +kernel) e25459 e25460
  have e25452 : Deny 5 11 b25452 :=
    branchAction rule_sound _ _ 2
      0x1e3 b25452 b25453 b25458 (by decide +kernel) e25453 e25458
  have e25442 : Deny 5 11 b25442 :=
    branchAction rule_sound _ _ 3
      0xb9e3 b25442 b25443 b25452 (by decide +kernel) e25443 e25452
  have e25495 : Deny 5 11 b25495 := by
    apply closeAction rule_sound _ _ 64 [0x2083e278c9e231f8]
    decide +kernel
  have e25441 : Deny 5 11 b25441 :=
    branchAction rule_sound _ _ 2
      0x223 b25441 b25442 b25495 (by decide +kernel) e25442 e25495
  have e25500 : Deny 5 11 b25500 := by
    apply closeAction rule_sound _ _ 64 [0x82082083e231f82388c9e278c78c8e27]
    decide +kernel
  have e25440 : Deny 5 11 b25440 :=
    branchAction rule_sound _ _ 2
      0x1e3 b25440 b25441 b25500 (by decide +kernel) e25441 e25500
  have e25430 : Deny 5 11 b25430 :=
    branchAction rule_sound _ _ 2
      0x2e3 b25430 b25431 b25440 (by decide +kernel) e25431 e25440
  have e25511 : Deny 5 11 b25511 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e25429 : Deny 5 11 b25429 :=
    branchAction rule_sound _ _ 2
      0x263 b25429 b25430 b25511 (by decide +kernel) e25430 e25511
  have e25512 : Deny 5 11 b25512 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e25428 : Deny 5 11 b25428 :=
    branchAction rule_sound _ _ 2
      0x238 b25428 b25429 b25512 (by decide +kernel) e25429 e25512
  have e25284 : Deny 5 11 b25284 :=
    branchAction rule_sound _ _ 2
      0x1e3 b25284 b25285 b25428 (by decide +kernel) e25285 e25428
  have e25519 : Deny 5 11 b25519 := by
    apply closeAction rule_sound _ _ 64 [0x820f88c8e23263]
    decide +kernel
  have e25524 : Deny 5 11 b25524 := by
    apply closeAction rule_sound _ _ 64 [0x820f8de3238de31f8dc20f88c7e03223263]
    decide +kernel
  have e25518 : Deny 5 11 b25518 :=
    branchAction rule_sound _ _ 2
      0x2e3 b25518 b25519 b25524 (by decide +kernel) e25519 e25524
  have e25535 : Deny 5 11 b25535 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e25517 : Deny 5 11 b25517 :=
    branchAction rule_sound _ _ 3
      0x8e23 b25517 b25518 b25535 (by decide +kernel) e25518 e25535
  have e25536 : Deny 5 11 b25536 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e25516 : Deny 5 11 b25516 :=
    branchAction rule_sound _ _ 3
      0x7e23 b25516 b25517 b25536 (by decide +kernel) e25517 e25536
  have e25537 : Deny 5 11 b25537 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e25515 : Deny 5 11 b25515 :=
    branchAction rule_sound _ _ 2
      0x263 b25515 b25516 b25537 (by decide +kernel) e25516 e25537
  have e25538 : Deny 5 11 b25538 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e25514 : Deny 5 11 b25514 :=
    branchAction rule_sound _ _ 2
      0x223 b25514 b25515 b25538 (by decide +kernel) e25515 e25538
  have e25539 : Deny 5 11 b25539 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e25513 : Deny 5 11 b25513 :=
    branchAction rule_sound _ _ 2
      0x1f8 b25513 b25514 b25539 (by decide +kernel) e25514 e25539
  have e25283 : Deny 5 11 b25283 :=
    branchAction rule_sound _ _ 2
      0x263 b25283 b25284 b25513 (by decide +kernel) e25284 e25513
  have e25541 : Deny 5 11 b25541 := by
    apply closeAction rule_sound _ _ 64 [0x20820820820f88c8e231f82788c8e231f88c9e23223]
    decide +kernel
  have e25556 : Deny 5 11 b25556 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e25540 : Deny 5 11 b25540 :=
    branchAction rule_sound _ _ 3
      0x7e36 b25540 b25541 b25556 (by decide +kernel) e25541 e25556
  have e25282 : Deny 5 11 b25282 :=
    branchAction rule_sound _ _ 1
      0x8 b25282 b25283 b25540 (by decide +kernel) e25283 e25540
  have e25260 : Deny 5 11 b25260 :=
    branchAction rule_sound _ _ 2
      0x2f8 b25260 b25261 b25282 (by decide +kernel) e25261 e25282
  exact e25260
end OMA.Blocks5_11_245212.S25260
