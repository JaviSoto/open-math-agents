import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S19830
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b19830 : Box := ![⟨27,30⟩,⟨31,62⟩,⟨15,30⟩,⟨3,55⟩,⟨59,73⟩]
theorem deny5_13 : Deny 5 13 ![⟨27,30⟩,⟨31,62⟩,⟨15,30⟩,⟨3,55⟩,⟨59,73⟩] := by
  have e19830 : Deny 5 13 b19830 := by
    apply closeAction rule_sound _ _ 64 [0x278dc3dc32481c9dc42c3dc31c32430f71c80c3dc70c3e37d87dc8244083e370c91f70f70c7203dc31c30c720910b20a,0x2232631027c31c9dc42c78c8096dc32441f8dd6e37103109e370f70c81c80f8dc32770c32470c31c3208244082083844,0x7f8de3102083244238dc20c4278dc3e370e3263223263107e1f0f8dc32770e32030e3]
    decide +kernel
  exact e19830
end OMA.Blocks5_13_245212.S19830
