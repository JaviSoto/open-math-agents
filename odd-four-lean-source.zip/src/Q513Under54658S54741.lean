import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S54741
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b54741 : Box := ![⟨58,62⟩,⟨85,126⟩,⟨12,14⟩,⟨3,52⟩,⟨639,958⟩]
private def b54742 : Box := ![⟨58,62⟩,⟨85,101⟩,⟨12,14⟩,⟨3,50⟩,⟨639,958⟩]
private def b54743 : Box := ![⟨58,62⟩,⟨85,101⟩,⟨12,12⟩,⟨3,44⟩,⟨639,958⟩]
private def b54744 : Box := ![⟨58,62⟩,⟨85,101⟩,⟨13,14⟩,⟨3,44⟩,⟨639,958⟩]
private def b54745 : Box := ![⟨58,62⟩,⟨85,92⟩,⟨13,14⟩,⟨3,44⟩,⟨639,958⟩]
private def b54746 : Box := ![⟨58,62⟩,⟨93,101⟩,⟨13,14⟩,⟨3,44⟩,⟨639,958⟩]
private def b54747 : Box := ![⟨58,62⟩,⟨102,126⟩,⟨12,14⟩,⟨3,50⟩,⟨639,958⟩]
private def b54748 : Box := ![⟨58,62⟩,⟨102,126⟩,⟨12,12⟩,⟨7,50⟩,⟨639,958⟩]
private def b54749 : Box := ![⟨58,59⟩,⟨102,126⟩,⟨12,12⟩,⟨8,49⟩,⟨639,958⟩]
private def b54750 : Box := ![⟨60,62⟩,⟨102,126⟩,⟨12,12⟩,⟨8,49⟩,⟨639,958⟩]
private def b54751 : Box := ![⟨58,62⟩,⟨102,126⟩,⟨13,14⟩,⟨7,50⟩,⟨639,958⟩]
private def b54752 : Box := ![⟨58,59⟩,⟨102,126⟩,⟨13,14⟩,⟨7,50⟩,⟨639,958⟩]
private def b54753 : Box := ![⟨60,62⟩,⟨102,126⟩,⟨13,14⟩,⟨7,50⟩,⟨639,958⟩]
private def b54754 : Box := ![⟨60,62⟩,⟨102,112⟩,⟨13,14⟩,⟨7,50⟩,⟨777,958⟩]
private def b54755 : Box := ![⟨60,62⟩,⟨113,126⟩,⟨13,14⟩,⟨7,50⟩,⟨777,958⟩]
private theorem e54743 : Deny 5 13 b54743 := by
    apply closeAction rule_sound _ _ 64 [0x3e37ae3]
    decide +kernel
private theorem e54745 : Deny 5 13 b54745 := by
    apply closeAction rule_sound _ _ 64 [0xe3]
    decide +kernel
private theorem e54746 : Deny 5 13 b54746 := by
    apply closeAction rule_sound _ _ 64 [0xeb]
    decide +kernel
private theorem e54744 : Deny 5 13 b54744 :=
    branchAction rule_sound _ _ 1
      0x8 b54744 b54745 b54746 (by decide +kernel) e54745 e54746
private theorem e54742 : Deny 5 13 b54742 :=
    branchAction rule_sound _ _ 2
      0x263 b54742 b54743 b54744 (by decide +kernel) e54743 e54744
private theorem e54749 : Deny 5 13 b54749 := by
    apply closeAction rule_sound _ _ 64 [0x6eb]
    decide +kernel
private theorem e54750 : Deny 5 13 b54750 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e54748 : Deny 5 13 b54748 :=
    branchAction rule_sound _ _ 3
      0x7ae3 b54748 b54749 b54750 (by decide +kernel) e54749 e54750
private theorem e54752 : Deny 5 13 b54752 := by
    apply closeAction rule_sound _ _ 64 [0x3ae3]
    decide +kernel
private theorem e54754 : Deny 5 13 b54754 := by
    apply closeAction rule_sound _ _ 64 [0x3e23]
    decide +kernel
private theorem e54755 : Deny 5 13 b54755 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e54753 : Deny 5 13 b54753 :=
    branchAction rule_sound _ _ 2
      0x238 b54753 b54754 b54755 (by decide +kernel) e54754 e54755
private theorem e54751 : Deny 5 13 b54751 :=
    branchAction rule_sound _ _ 1
      0x7 b54751 b54752 b54753 (by decide +kernel) e54752 e54753
private theorem e54747 : Deny 5 13 b54747 :=
    branchAction rule_sound _ _ 2
      0x26b b54747 b54748 b54751 (by decide +kernel) e54748 e54751
private theorem e54741 : Deny 5 13 b54741 :=
    branchAction rule_sound _ _ 2
      0x223 b54741 b54742 b54747 (by decide +kernel) e54742 e54747
theorem deny5_13 : Deny 5 13 ![⟨58,62⟩,⟨85,126⟩,⟨12,14⟩,⟨3,52⟩,⟨639,958⟩] := by
  exact e54741
end OMA.Blocks5_13_245212.S54741
