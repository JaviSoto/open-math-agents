import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S53281
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b53281 : Box := ![⟨47,62⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨1,640000000000000003826⟩,⟨127,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,62⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨1,640000000000000003826⟩,⟨127,233⟩] := by
  have e53281 : Deny 5 13 b53281 := by
    apply closeAction rule_sound _ _ 64 [0x108e1b26b6c30f81dbe37d491030c80c320710b283103e3784427884a8c86eb11be378c4238de32631c42e3213a212a3,0x8498471020f80e11e126110b4ca84a8c86eb8c38c8e1bae31eb0eb0f8de3203e378c78c88c96f8deb8c40f8ddbae31e3,0x6b8df6d631f88c80a12822631e310209bae1109e2b107e37adb083e032090c320710208320710b10ae03e038490c3e37,0x102278de11e12842e321bac46f8de3108e37d6325b6eb84a6b8df5ae31e311bac38c80eb6f88c88c7ac42dbac9ac3089,0x1c81020e1109e03ae11e110baca8c8ac30f8de3203e378c76f8de326311b0f8dc32432030f8207283e03203e21253283,0x1aadb69aacbae3107e2b8c8adbadb6eb0c3e2b]
    decide +kernel
  exact e53281
end OMA.Blocks5_13_245212.S53281
