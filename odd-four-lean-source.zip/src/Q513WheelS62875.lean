import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S62875
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b62875 : Box := ![⟨95,190⟩,⟨31,41⟩,⟨10,14⟩,⟨1,66⟩,⟨239,478⟩]
private def b62876 : Box := ![⟨95,126⟩,⟨31,41⟩,⟨10,14⟩,⟨1,60⟩,⟨239,478⟩]
private def b62877 : Box := ![⟨95,126⟩,⟨31,41⟩,⟨10,14⟩,⟨1,47⟩,⟨239,318⟩]
private def b62878 : Box := ![⟨95,126⟩,⟨31,41⟩,⟨10,11⟩,⟨1,47⟩,⟨239,317⟩]
private def b62879 : Box := ![⟨95,126⟩,⟨31,41⟩,⟨10,11⟩,⟨1,2⟩,⟨239,317⟩]
private def b62880 : Box := ![⟨95,126⟩,⟨31,41⟩,⟨10,11⟩,⟨3,45⟩,⟨239,317⟩]
private def b62881 : Box := ![⟨95,126⟩,⟨31,35⟩,⟨10,11⟩,⟨3,45⟩,⟨239,317⟩]
private def b62888 : Box := ![⟨95,126⟩,⟨36,41⟩,⟨10,11⟩,⟨3,45⟩,⟨239,317⟩]
private def b62897 : Box := ![⟨95,126⟩,⟨31,41⟩,⟨12,14⟩,⟨1,47⟩,⟨239,317⟩]
private def b62898 : Box := ![⟨95,126⟩,⟨31,41⟩,⟨12,14⟩,⟨1,2⟩,⟨239,317⟩]
private def b62903 : Box := ![⟨95,126⟩,⟨31,41⟩,⟨12,14⟩,⟨3,47⟩,⟨239,317⟩]
private def b62904 : Box := ![⟨95,126⟩,⟨31,35⟩,⟨12,14⟩,⟨3,47⟩,⟨239,317⟩]
private def b62915 : Box := ![⟨95,126⟩,⟨36,41⟩,⟨12,14⟩,⟨3,47⟩,⟨239,317⟩]
private def b62922 : Box := ![⟨95,126⟩,⟨31,41⟩,⟨10,14⟩,⟨1,47⟩,⟨319,478⟩]
private def b62923 : Box := ![⟨95,126⟩,⟨31,41⟩,⟨10,11⟩,⟨1,44⟩,⟨319,478⟩]
private def b62924 : Box := ![⟨95,126⟩,⟨31,41⟩,⟨10,11⟩,⟨1,2⟩,⟨319,478⟩]
private def b62925 : Box := ![⟨95,126⟩,⟨31,41⟩,⟨10,11⟩,⟨3,43⟩,⟨319,478⟩]
private def b62926 : Box := ![⟨95,126⟩,⟨31,35⟩,⟨10,11⟩,⟨3,43⟩,⟨319,478⟩]
private def b62931 : Box := ![⟨95,126⟩,⟨36,41⟩,⟨10,11⟩,⟨3,43⟩,⟨319,478⟩]
private def b62940 : Box := ![⟨95,126⟩,⟨31,41⟩,⟨12,14⟩,⟨1,44⟩,⟨319,478⟩]
private def b62941 : Box := ![⟨95,126⟩,⟨31,35⟩,⟨12,14⟩,⟨1,44⟩,⟨319,478⟩]
private def b62942 : Box := ![⟨95,126⟩,⟨31,35⟩,⟨12,14⟩,⟨1,2⟩,⟨319,478⟩]
private def b62943 : Box := ![⟨95,126⟩,⟨31,35⟩,⟨12,14⟩,⟨3,43⟩,⟨319,478⟩]
private def b62954 : Box := ![⟨95,126⟩,⟨36,41⟩,⟨12,14⟩,⟨1,44⟩,⟨319,478⟩]
private def b62955 : Box := ![⟨95,126⟩,⟨36,41⟩,⟨12,14⟩,⟨1,2⟩,⟨319,478⟩]
private def b62958 : Box := ![⟨95,126⟩,⟨36,41⟩,⟨12,14⟩,⟨3,44⟩,⟨319,478⟩]
private def b62959 : Box := ![⟨95,108⟩,⟨36,41⟩,⟨12,14⟩,⟨3,44⟩,⟨319,478⟩]
private def b62964 : Box := ![⟨109,126⟩,⟨36,41⟩,⟨12,14⟩,⟨3,44⟩,⟨319,478⟩]
private def b62965 : Box := ![⟨109,126⟩,⟨36,41⟩,⟨12,14⟩,⟨3,44⟩,⟨332,391⟩]
private def b62970 : Box := ![⟨109,126⟩,⟨36,41⟩,⟨12,14⟩,⟨3,44⟩,⟨392,478⟩]
private def b62977 : Box := ![⟨127,190⟩,⟨31,41⟩,⟨10,14⟩,⟨1,60⟩,⟨239,478⟩]
private def b62978 : Box := ![⟨127,190⟩,⟨31,41⟩,⟨10,14⟩,⟨4,60⟩,⟨239,318⟩]
private def b62979 : Box := ![⟨127,190⟩,⟨31,41⟩,⟨10,11⟩,⟨5,59⟩,⟨239,317⟩]
private def b62980 : Box := ![⟨127,190⟩,⟨31,35⟩,⟨10,11⟩,⟨6,58⟩,⟨239,317⟩]
private def b62981 : Box := ![⟨127,152⟩,⟨31,35⟩,⟨10,11⟩,⟨8,56⟩,⟨239,317⟩]
private def b62982 : Box := ![⟨127,152⟩,⟨31,35⟩,⟨10,11⟩,⟨8,49⟩,⟨239,272⟩]
private def b62987 : Box := ![⟨127,152⟩,⟨31,35⟩,⟨10,11⟩,⟨8,49⟩,⟨273,317⟩]
private def b62994 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨10,11⟩,⟨8,56⟩,⟨239,317⟩]
private def b62999 : Box := ![⟨127,190⟩,⟨36,41⟩,⟨10,11⟩,⟨6,58⟩,⟨239,317⟩]
private def b63002 : Box := ![⟨127,190⟩,⟨31,41⟩,⟨12,14⟩,⟨5,59⟩,⟨239,317⟩]
private def b63005 : Box := ![⟨127,190⟩,⟨31,41⟩,⟨10,14⟩,⟨4,60⟩,⟨319,478⟩]
private def b63006 : Box := ![⟨127,190⟩,⟨31,41⟩,⟨10,11⟩,⟨4,57⟩,⟨319,478⟩]
private def b63007 : Box := ![⟨127,190⟩,⟨31,35⟩,⟨10,11⟩,⟨6,55⟩,⟨319,478⟩]
private def b63008 : Box := ![⟨127,152⟩,⟨31,35⟩,⟨10,11⟩,⟨7,53⟩,⟨319,478⟩]
private def b63009 : Box := ![⟨127,152⟩,⟨31,35⟩,⟨10,11⟩,⟨7,46⟩,⟨319,382⟩]
private def b63016 : Box := ![⟨127,152⟩,⟨31,35⟩,⟨10,11⟩,⟨7,46⟩,⟨383,478⟩]
private def b63023 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨10,11⟩,⟨7,53⟩,⟨319,478⟩]
private def b63024 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨10,11⟩,⟨12,19⟩,⟨319,478⟩]
private def b63025 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨10,11⟩,⟨12,19⟩,⟨319,382⟩]
private def b63034 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨10,11⟩,⟨12,19⟩,⟨383,478⟩]
private def b63043 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨10,11⟩,⟨20,53⟩,⟨319,478⟩]
private def b63044 : Box := ![⟨127,190⟩,⟨36,41⟩,⟨10,11⟩,⟨6,55⟩,⟨319,478⟩]
private def b63045 : Box := ![⟨127,152⟩,⟨36,41⟩,⟨10,11⟩,⟨6,55⟩,⟨319,478⟩]
private def b63046 : Box := ![⟨127,152⟩,⟨36,41⟩,⟨10,11⟩,⟨6,48⟩,⟨319,382⟩]
private def b63051 : Box := ![⟨127,152⟩,⟨36,41⟩,⟨10,11⟩,⟨6,48⟩,⟨383,478⟩]
private def b63058 : Box := ![⟨153,190⟩,⟨36,41⟩,⟨10,11⟩,⟨6,55⟩,⟨319,478⟩]
private def b63061 : Box := ![⟨127,190⟩,⟨31,41⟩,⟨12,14⟩,⟨4,57⟩,⟨319,478⟩]
private def b63062 : Box := ![⟨127,190⟩,⟨31,35⟩,⟨12,14⟩,⟨4,57⟩,⟨319,478⟩]
private def b63063 : Box := ![⟨127,152⟩,⟨31,35⟩,⟨12,14⟩,⟨6,55⟩,⟨320,478⟩]
private def b63064 : Box := ![⟨127,152⟩,⟨31,35⟩,⟨12,14⟩,⟨6,48⟩,⟨320,383⟩]
private def b63069 : Box := ![⟨127,152⟩,⟨31,35⟩,⟨12,14⟩,⟨6,48⟩,⟨384,478⟩]
private def b63076 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨12,14⟩,⟨6,55⟩,⟨320,478⟩]
private def b63081 : Box := ![⟨127,190⟩,⟨36,41⟩,⟨12,14⟩,⟨4,57⟩,⟨319,478⟩]
private theorem e62879 : Deny 5 13 b62879 := by
    apply closeAction rule_sound _ _ 64 [0x13960]
    decide +kernel
private theorem e62881 : Deny 5 13 b62881 := by
    apply closeAction rule_sound _ _ 64 [0xc39c99c30f8de32231e3]
    decide +kernel
private theorem e62888 : Deny 5 13 b62888 := by
    apply closeAction rule_sound _ _ 64 [0x20f89e3109e270e31c30c88c7]
    decide +kernel
private theorem e62880 : Deny 5 13 b62880 :=
    branchAction rule_sound _ _ 1
      0x8 b62880 b62881 b62888 (by decide +kernel) e62881 e62888
private theorem e62878 : Deny 5 13 b62878 :=
    branchAction rule_sound _ _ 2
      0x2a3 b62878 b62879 b62880 (by decide +kernel) e62879 e62880
private theorem e62898 : Deny 5 13 b62898 := by
    apply closeAction rule_sound _ _ 64 [0x174c95e0220]
    decide +kernel
private theorem e62904 : Deny 5 13 b62904 := by
    apply closeAction rule_sound _ _ 64 [0x29c40c41f8dc3e278c90f8dc38c90e32231e3]
    decide +kernel
private theorem e62915 : Deny 5 13 b62915 := by
    apply closeAction rule_sound _ _ 64 [0x820c4238dc3247e37]
    decide +kernel
private theorem e62903 : Deny 5 13 b62903 :=
    branchAction rule_sound _ _ 1
      0x8 b62903 b62904 b62915 (by decide +kernel) e62904 e62915
private theorem e62897 : Deny 5 13 b62897 :=
    branchAction rule_sound _ _ 1
      0xa b62897 b62898 b62903 (by decide +kernel) e62898 e62903
private theorem e62877 : Deny 5 13 b62877 :=
    branchAction rule_sound _ _ 2
      0x244 b62877 b62878 b62897 (by decide +kernel) e62878 e62897
private theorem e62924 : Deny 5 13 b62924 := by
    apply closeAction rule_sound _ _ 64 [0x2960]
    decide +kernel
private theorem e62926 : Deny 5 13 b62926 := by
    apply closeAction rule_sound _ _ 64 [0xc22440841f8de3]
    decide +kernel
private theorem e62931 : Deny 5 13 b62931 := by
    apply closeAction rule_sound _ _ 64 [0xc39e32270e31c30f8dc88c7]
    decide +kernel
private theorem e62925 : Deny 5 13 b62925 :=
    branchAction rule_sound _ _ 1
      0x8 b62925 b62926 b62931 (by decide +kernel) e62926 e62931
private theorem e62923 : Deny 5 13 b62923 :=
    branchAction rule_sound _ _ 2
      0x2a3 b62923 b62924 b62925 (by decide +kernel) e62924 e62925
private theorem e62942 : Deny 5 13 b62942 := by
    apply closeAction rule_sound _ _ 64 [0x17e37da0]
    decide +kernel
private theorem e62943 : Deny 5 13 b62943 := by
    apply closeAction rule_sound _ _ 64 [0x39c38c70e78c90c3e378c90f88c88c7]
    decide +kernel
private theorem e62941 : Deny 5 13 b62941 :=
    branchAction rule_sound _ _ 2
      0x2a3 b62941 b62942 b62943 (by decide +kernel) e62942 e62943
private theorem e62955 : Deny 5 13 b62955 := by
    apply closeAction rule_sound _ _ 64 [0x5d3260]
    decide +kernel
private theorem e62959 : Deny 5 13 b62959 := by
    apply closeAction rule_sound _ _ 64 [0xf8dc38c80e3263]
    decide +kernel
private theorem e62965 : Deny 5 13 b62965 := by
    apply closeAction rule_sound _ _ 64 [0x2083209dc4]
    decide +kernel
private theorem e62970 : Deny 5 13 b62970 := by
    apply closeAction rule_sound _ _ 64 [0x83107e370f8dc38c88c98c4]
    decide +kernel
private theorem e62964 : Deny 5 13 b62964 :=
    branchAction rule_sound _ _ 2
      0x2f8 b62964 b62965 b62970 (by decide +kernel) e62965 e62970
private theorem e62958 : Deny 5 13 b62958 :=
    branchAction rule_sound _ _ 1
      0x7 b62958 b62959 b62964 (by decide +kernel) e62959 e62964
private theorem e62954 : Deny 5 13 b62954 :=
    branchAction rule_sound _ _ 1
      0xa b62954 b62955 b62958 (by decide +kernel) e62955 e62958
private theorem e62940 : Deny 5 13 b62940 :=
    branchAction rule_sound _ _ 1
      0x8 b62940 b62941 b62954 (by decide +kernel) e62941 e62954
private theorem e62922 : Deny 5 13 b62922 :=
    branchAction rule_sound _ _ 2
      0x263 b62922 b62923 b62940 (by decide +kernel) e62923 e62940
private theorem e62876 : Deny 5 13 b62876 :=
    branchAction rule_sound _ _ 2
      0x2e3 b62876 b62877 b62922 (by decide +kernel) e62877 e62922
private theorem e62982 : Deny 5 13 b62982 := by
    apply closeAction rule_sound _ _ 64 [0x20f8dc39e3223244]
    decide +kernel
private theorem e62987 : Deny 5 13 b62987 := by
    apply closeAction rule_sound _ _ 64 [0x20c90e70e31e78c88c4]
    decide +kernel
private theorem e62981 : Deny 5 13 b62981 :=
    branchAction rule_sound _ _ 2
      0x2e3 b62981 b62982 b62987 (by decide +kernel) e62982 e62987
private theorem e62994 : Deny 5 13 b62994 := by
    apply closeAction rule_sound _ _ 64 [0x820c99e3108e27]
    decide +kernel
private theorem e62980 : Deny 5 13 b62980 :=
    branchAction rule_sound _ _ 3
      0x79e3 b62980 b62981 b62994 (by decide +kernel) e62981 e62994
private theorem e62999 : Deny 5 13 b62999 := by
    apply closeAction rule_sound _ _ 64 [0x20a5807e37]
    decide +kernel
private theorem e62979 : Deny 5 13 b62979 :=
    branchAction rule_sound _ _ 3
      0x89e3 b62979 b62980 b62999 (by decide +kernel) e62980 e62999
private theorem e63002 : Deny 5 13 b63002 := by
    apply closeAction rule_sound _ _ 64 [0x2448e37]
    decide +kernel
private theorem e62978 : Deny 5 13 b62978 :=
    branchAction rule_sound _ _ 4
      0x2678c4 b62978 b62979 b63002 (by decide +kernel) e62979 e63002
private theorem e63009 : Deny 5 13 b63009 := by
    apply closeAction rule_sound _ _ 64 [0xe70e31c30898c89c4]
    decide +kernel
private theorem e63016 : Deny 5 13 b63016 := by
    apply closeAction rule_sound _ _ 64 [0x39c38c70e71021f8de78c88c4]
    decide +kernel
private theorem e63008 : Deny 5 13 b63008 :=
    branchAction rule_sound _ _ 2
      0x2e3 b63008 b63009 b63016 (by decide +kernel) e63009 e63016
private theorem e63025 : Deny 5 13 b63025 := by
    apply closeAction rule_sound _ _ 64 [0x20831e78042780f80e78099e0204]
    decide +kernel
private theorem e63034 : Deny 5 13 b63034 := by
    apply closeAction rule_sound _ _ 64 [0x20e72439c80c3e20267204]
    decide +kernel
private theorem e63024 : Deny 5 13 b63024 :=
    branchAction rule_sound _ _ 1
      0xb b63024 b63025 b63034 (by decide +kernel) e63025 e63034
private theorem e63043 : Deny 5 13 b63043 := by
    apply closeAction rule_sound _ _ 64 [0x19]
    decide +kernel
private theorem e63023 : Deny 5 13 b63023 :=
    branchAction rule_sound _ _ 2
      0x2a7 b63023 b63024 b63043 (by decide +kernel) e63024 e63043
private theorem e63007 : Deny 5 13 b63007 :=
    branchAction rule_sound _ _ 3
      0x79e3 b63007 b63008 b63023 (by decide +kernel) e63008 e63023
private theorem e63046 : Deny 5 13 b63046 := by
    apply closeAction rule_sound _ _ 64 [0x20f8dc39e3223244]
    decide +kernel
private theorem e63051 : Deny 5 13 b63051 := by
    apply closeAction rule_sound _ _ 64 [0x832439c38c79c88c4]
    decide +kernel
private theorem e63045 : Deny 5 13 b63045 :=
    branchAction rule_sound _ _ 2
      0x2e3 b63045 b63046 b63051 (by decide +kernel) e63046 e63051
private theorem e63058 : Deny 5 13 b63058 := by
    apply closeAction rule_sound _ _ 64 [0x26c9e27]
    decide +kernel
private theorem e63044 : Deny 5 13 b63044 :=
    branchAction rule_sound _ _ 1
      0x7 b63044 b63045 b63058 (by decide +kernel) e63045 e63058
private theorem e63006 : Deny 5 13 b63006 :=
    branchAction rule_sound _ _ 3
      0x89e3 b63006 b63007 b63044 (by decide +kernel) e63007 e63044
private theorem e63064 : Deny 5 13 b63064 := by
    apply closeAction rule_sound _ _ 64 [0x20839e32678c88c4]
    decide +kernel
private theorem e63069 : Deny 5 13 b63069 := by
    apply closeAction rule_sound _ _ 64 [0x83e278c90e70e31e78c88c4]
    decide +kernel
private theorem e63063 : Deny 5 13 b63063 :=
    branchAction rule_sound _ _ 2
      0x2e3 b63063 b63064 b63069 (by decide +kernel) e63064 e63069
private theorem e63076 : Deny 5 13 b63076 := by
    apply closeAction rule_sound _ _ 64 [0x820e02779c4238de7]
    decide +kernel
private theorem e63062 : Deny 5 13 b63062 :=
    branchAction rule_sound _ _ 4
      0x1f89e3 b63062 b63063 b63076 (by decide +kernel) e63063 e63076
private theorem e63081 : Deny 5 13 b63081 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e63061 : Deny 5 13 b63061 :=
    branchAction rule_sound _ _ 1
      0x8 b63061 b63062 b63081 (by decide +kernel) e63062 e63081
private theorem e63005 : Deny 5 13 b63005 :=
    branchAction rule_sound _ _ 2
      0x263 b63005 b63006 b63061 (by decide +kernel) e63006 e63061
private theorem e62977 : Deny 5 13 b62977 :=
    branchAction rule_sound _ _ 2
      0x2e7 b62977 b62978 b63005 (by decide +kernel) e62978 e63005
private theorem e62875 : Deny 5 13 b62875 :=
    branchAction rule_sound _ _ 2
      0x1e3 b62875 b62876 b62977 (by decide +kernel) e62876 e62977
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨31,41⟩,⟨10,14⟩,⟨1,66⟩,⟨239,478⟩] := by
  exact e62875
end OMA.Blocks5_13_245212.S62875
