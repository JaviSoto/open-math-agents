import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S3798
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b3798 : Box := ![⟨11,22⟩,⟨15,1920000000000000011376⟩,⟨2,4⟩,⟨1,1920000000000000011376⟩,⟨29,151⟩]
theorem deny5_13 : Deny 5 13 ![⟨11,22⟩,⟨15,1920000000000000011376⟩,⟨2,4⟩,⟨1,1920000000000000011376⟩,⟨29,151⟩] := by
  have e3798 : Deny 5 13 b3798 := by
    apply closeAction rule_sound _ _ 64 [0x8c90e32030898c70c21e12a321aadaae322b6b8df6d63237d631c42c3087087e37d6321ae37d6324284ad63d631f8de3,0x6ab688adae37db5ae32021f7d6311aadaae322b0f8dc3]
    decide +kernel
  exact e3798
end OMA.Blocks5_13_245212.S3798
