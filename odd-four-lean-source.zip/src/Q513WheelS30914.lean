import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S30914
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b30914 : Box := ![⟨38,41⟩,⟨63,126⟩,⟨31,62⟩,⟨1,75⟩,⟨479,999999999999999999⟩]
private def b30915 : Box := ![⟨38,41⟩,⟨63,126⟩,⟨31,62⟩,⟨1,74⟩,⟨479,958⟩]
private def b30916 : Box := ![⟨38,41⟩,⟨63,126⟩,⟨31,62⟩,⟨1,2⟩,⟨479,958⟩]
private def b30917 : Box := ![⟨38,41⟩,⟨63,126⟩,⟨31,62⟩,⟨3,69⟩,⟨479,958⟩]
private def b30918 : Box := ![⟨38,41⟩,⟨63,126⟩,⟨31,62⟩,⟨3,6⟩,⟨479,958⟩]
private def b30919 : Box := ![⟨38,41⟩,⟨63,84⟩,⟨31,62⟩,⟨3,6⟩,⟨479,958⟩]
private def b30920 : Box := ![⟨38,39⟩,⟨63,84⟩,⟨32,62⟩,⟨3,6⟩,⟨479,958⟩]
private def b30921 : Box := ![⟨40,41⟩,⟨63,84⟩,⟨32,62⟩,⟨3,6⟩,⟨479,958⟩]
private def b30922 : Box := ![⟨40,41⟩,⟨63,84⟩,⟨32,42⟩,⟨3,6⟩,⟨479,958⟩]
private def b30929 : Box := ![⟨40,41⟩,⟨63,84⟩,⟨43,62⟩,⟨3,6⟩,⟨479,958⟩]
private def b30934 : Box := ![⟨38,41⟩,⟨85,126⟩,⟨31,62⟩,⟨3,6⟩,⟨479,958⟩]
private def b30935 : Box := ![⟨38,41⟩,⟨85,126⟩,⟨31,41⟩,⟨3,6⟩,⟨479,958⟩]
private def b30936 : Box := ![⟨38,41⟩,⟨85,126⟩,⟨31,41⟩,⟨3,6⟩,⟨479,638⟩]
private def b30937 : Box := ![⟨38,41⟩,⟨85,124⟩,⟨31,41⟩,⟨3,4⟩,⟨479,638⟩]
private def b30948 : Box := ![⟨38,41⟩,⟨85,124⟩,⟨31,41⟩,⟨5,6⟩,⟨479,638⟩]
private def b30949 : Box := ![⟨38,41⟩,⟨85,126⟩,⟨31,41⟩,⟨3,6⟩,⟨639,958⟩]
private def b30960 : Box := ![⟨38,41⟩,⟨85,126⟩,⟨42,62⟩,⟨3,6⟩,⟨479,958⟩]
private def b30961 : Box := ![⟨38,41⟩,⟨63,126⟩,⟨31,62⟩,⟨7,69⟩,⟨479,958⟩]
private def b30962 : Box := ![⟨38,41⟩,⟨63,126⟩,⟨31,62⟩,⟨1,74⟩,⟨959,999999999999999999⟩]
private def b30963 : Box := ![⟨38,41⟩,⟨63,84⟩,⟨31,62⟩,⟨1,67⟩,⟨959,999999999999999999⟩]
private def b30968 : Box := ![⟨38,41⟩,⟨85,126⟩,⟨31,62⟩,⟨1,67⟩,⟨959,999999999999999999⟩]
private def b30969 : Box := ![⟨38,41⟩,⟨85,126⟩,⟨31,41⟩,⟨1,67⟩,⟨959,999999999999999999⟩]
private def b30970 : Box := ![⟨38,41⟩,⟨85,101⟩,⟨31,41⟩,⟨1,59⟩,⟨959,2295⟩]
private def b30971 : Box := ![⟨38,41⟩,⟨102,126⟩,⟨31,41⟩,⟨1,59⟩,⟨959,2295⟩]
private def b30982 : Box := ![⟨38,41⟩,⟨85,126⟩,⟨42,62⟩,⟨1,67⟩,⟨959,999999999999999999⟩]
private def b30983 : Box := ![⟨38,41⟩,⟨85,126⟩,⟨42,62⟩,⟨1,67⟩,⟨959,1918⟩]
private def b30990 : Box := ![⟨38,41⟩,⟨85,126⟩,⟨42,62⟩,⟨1,67⟩,⟨1919,999999999999999999⟩]
private def b30991 : Box := ![⟨38,41⟩,⟨85,101⟩,⟨42,62⟩,⟨1,61⟩,⟨1919,999999999999999999⟩]
private def b31000 : Box := ![⟨38,41⟩,⟨102,126⟩,⟨42,62⟩,⟨1,61⟩,⟨1919,999999999999999999⟩]
private def b31001 : Box := ![⟨38,39⟩,⟨102,126⟩,⟨42,62⟩,⟨1,61⟩,⟨1919,999999999999999999⟩]
private def b31004 : Box := ![⟨40,41⟩,⟨102,126⟩,⟨42,62⟩,⟨1,61⟩,⟨1919,999999999999999999⟩]
private def b31005 : Box := ![⟨40,41⟩,⟨102,126⟩,⟨42,50⟩,⟨1,61⟩,⟨1919,999999999999999999⟩]
private def b31012 : Box := ![⟨40,41⟩,⟨102,126⟩,⟨51,62⟩,⟨1,61⟩,⟨1919,999999999999999999⟩]
private def b31013 : Box := ![⟨40,41⟩,⟨102,126⟩,⟨51,62⟩,⟨1,61⟩,⟨1919,3838⟩]
private def b31018 : Box := ![⟨40,41⟩,⟨102,126⟩,⟨51,62⟩,⟨1,61⟩,⟨3839,999999999999999999⟩]
private def b31019 : Box := ![⟨40,41⟩,⟨102,112⟩,⟨51,62⟩,⟨1,55⟩,⟨3839,999999999999999999⟩]
private def b31024 : Box := ![⟨40,41⟩,⟨113,126⟩,⟨51,62⟩,⟨1,55⟩,⟨3839,999999999999999999⟩]
private theorem e30916 : Deny 5 13 b30916 := by
    apply closeAction rule_sound _ _ 64 [0x16]
    decide +kernel
private theorem e30920 : Deny 5 13 b30920 := by
    apply closeAction rule_sound _ _ 64 [0x16e36]
    decide +kernel
private theorem e30922 : Deny 5 13 b30922 := by
    apply closeAction rule_sound _ _ 64 [0x1f583e37109e36282238]
    decide +kernel
private theorem e30929 : Deny 5 13 b30929 := by
    apply closeAction rule_sound _ _ 64 [0x59f58ae08]
    decide +kernel
private theorem e30921 : Deny 5 13 b30921 :=
    branchAction rule_sound _ _ 1
      0x9 b30921 b30922 b30929 (by decide +kernel) e30922 e30929
private theorem e30919 : Deny 5 13 b30919 :=
    branchAction rule_sound _ _ 2
      0x1f6 b30919 b30920 b30921 (by decide +kernel) e30920 e30921
private theorem e30937 : Deny 5 13 b30937 := by
    apply closeAction rule_sound _ _ 64 [0x5830f88470f82172821e1261]
    decide +kernel
private theorem e30948 : Deny 5 13 b30948 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e30936 : Deny 5 13 b30936 :=
    branchAction rule_sound _ _ 2
      0x2a1 b30936 b30937 b30948 (by decide +kernel) e30937 e30948
private theorem e30949 : Deny 5 13 b30949 := by
    apply closeAction rule_sound _ _ 64 [0x1f5831021f8844088e21256e37db584784a]
    decide +kernel
private theorem e30935 : Deny 5 13 b30935 :=
    branchAction rule_sound _ _ 1
      0xb b30935 b30936 b30949 (by decide +kernel) e30936 e30949
private theorem e30960 : Deny 5 13 b30960 := by
    apply closeAction rule_sound _ _ 64 [0x16]
    decide +kernel
private theorem e30934 : Deny 5 13 b30934 :=
    branchAction rule_sound _ _ 1
      0x9 b30934 b30935 b30960 (by decide +kernel) e30935 e30960
private theorem e30918 : Deny 5 13 b30918 :=
    branchAction rule_sound _ _ 1
      0x8 b30918 b30919 b30934 (by decide +kernel) e30919 e30934
private theorem e30961 : Deny 5 13 b30961 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e30917 : Deny 5 13 b30917 :=
    branchAction rule_sound _ _ 1
      0xa b30917 b30918 b30961 (by decide +kernel) e30918 e30961
private theorem e30915 : Deny 5 13 b30915 :=
    branchAction rule_sound _ _ 2
      0x2a3 b30915 b30916 b30917 (by decide +kernel) e30916 e30917
private theorem e30963 : Deny 5 13 b30963 := by
    apply closeAction rule_sound _ _ 64 [0x1f58ae23088e37da3]
    decide +kernel
private theorem e30970 : Deny 5 13 b30970 := by
    apply closeAction rule_sound _ _ 64 [0x1fe37da3]
    decide +kernel
private theorem e30971 : Deny 5 13 b30971 := by
    apply closeAction rule_sound _ _ 64 [0x7df5b884a7f8df6849e0a58a087e23]
    decide +kernel
private theorem e30969 : Deny 5 13 b30969 :=
    branchAction rule_sound _ _ 3
      0x8e23 b30969 b30970 b30971 (by decide +kernel) e30970 e30971
private theorem e30983 : Deny 5 13 b30983 := by
    apply closeAction rule_sound _ _ 64 [0x7df58a2962a3]
    decide +kernel
private theorem e30991 : Deny 5 13 b30991 := by
    apply closeAction rule_sound _ _ 64 [0xc21f87f8de325ee37da32388c21f8da3]
    decide +kernel
private theorem e31001 : Deny 5 13 b31001 := by
    apply closeAction rule_sound _ _ 64 [0x1f58ae37da3]
    decide +kernel
private theorem e31005 : Deny 5 13 b31005 := by
    apply closeAction rule_sound _ _ 64 [0x7df58ae0ae2358ae23]
    decide +kernel
private theorem e31013 : Deny 5 13 b31013 := by
    apply closeAction rule_sound _ _ 64 [0x7d62962a3]
    decide +kernel
private theorem e31019 : Deny 5 13 b31019 := by
    apply closeAction rule_sound _ _ 64 [0x3e03e378c9e23087e23]
    decide +kernel
private theorem e31024 : Deny 5 13 b31024 := by
    apply closeAction rule_sound _ _ 64 [0x3e038c90f88dfe378c9e07]
    decide +kernel
private theorem e31018 : Deny 5 13 b31018 :=
    branchAction rule_sound _ _ 2
      0x223 b31018 b31019 b31024 (by decide +kernel) e31019 e31024
private theorem e31012 : Deny 5 13 b31012 :=
    branchAction rule_sound _ _ 1
      0xb b31012 b31013 b31018 (by decide +kernel) e31013 e31018
private theorem e31004 : Deny 5 13 b31004 :=
    branchAction rule_sound _ _ 1
      0x9 b31004 b31005 b31012 (by decide +kernel) e31005 e31012
private theorem e31000 : Deny 5 13 b31000 :=
    branchAction rule_sound _ _ 1
      0x7 b31000 b31001 b31004 (by decide +kernel) e31001 e31004
private theorem e30990 : Deny 5 13 b30990 :=
    branchAction rule_sound _ _ 2
      0x223 b30990 b30991 b31000 (by decide +kernel) e30991 e31000
private theorem e30982 : Deny 5 13 b30982 :=
    branchAction rule_sound _ _ 1
      0xb b30982 b30983 b30990 (by decide +kernel) e30983 e30990
private theorem e30968 : Deny 5 13 b30968 :=
    branchAction rule_sound _ _ 1
      0x9 b30968 b30969 b30982 (by decide +kernel) e30969 e30982
private theorem e30962 : Deny 5 13 b30962 :=
    branchAction rule_sound _ _ 2
      0x223 b30962 b30963 b30968 (by decide +kernel) e30963 e30968
private theorem e30914 : Deny 5 13 b30914 :=
    branchAction rule_sound _ _ 2
      0x2e3 b30914 b30915 b30962 (by decide +kernel) e30915 e30962
theorem deny5_13 : Deny 5 13 ![⟨38,41⟩,⟨63,126⟩,⟨31,62⟩,⟨1,75⟩,⟨479,999999999999999999⟩] := by
  exact e30914
end OMA.Blocks5_13_245212.S30914
