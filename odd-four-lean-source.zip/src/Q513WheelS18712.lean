import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S18712
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b18712 : Box := ![⟨23,30⟩,⟨31,1920000000000000011376⟩,⟨7,14⟩,⟨3,760851063829787238582⟩,⟨78,113⟩]
theorem deny5_13 : Deny 5 13 ![⟨23,30⟩,⟨31,1920000000000000011376⟩,⟨7,14⟩,⟨3,760851063829787238582⟩,⟨78,113⟩] := by
  have e18712 : Deny 5 13 b18712 := by
    apply closeAction rule_sound _ _ 64 [0x21aac4087e36d631c40ab8442b88c90f8aeaa212830f8de31c3e378c80c21f8df68c90f8df6d63204087e37db58c88c4,0x1e1103e36108e21283e37db584a6b8df5ae32446b8df6d441f88c88c76ab688adaac3e2321ae37d47adae378c8089e23,0xe37d6326311fe37683e2b0c884a1eb0c38c70e326321aac30f81e322b0c3e378c78c88c910b8c86ab6ab8c8ada0c3e21,0x6ab6ab8c8ada7c3e2b847103e37dab8441f884aac30f8de3204087e378c86ab088]
    decide +kernel
  exact e18712
end OMA.Blocks5_13_245212.S18712
