import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S28779
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b28779 : Box := ![⟨31,37⟩,⟨63,126⟩,⟨31,1920000000000000011376⟩,⟨1,1301352063213345047248⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨31,37⟩,⟨63,126⟩,⟨31,1920000000000000011376⟩,⟨1,1301352063213345047248⟩,⟨479,999999999999999999⟩] := by
  have e28779 : Deny 5 13 b28779 := by
    apply closeAction rule_sound _ _ 64 [0x1f8db51df7c21f8db51d62837b8df68c77f8de321ee378c90881021f8de32787b8df6d63223087e358c95b8db588ada3,0xbde7af88abe325e7d67f8da22381ca8c972f7af8c97a325fe222a321688a8cb72f7af8c9bde256e37db588a0ad88a8c2,0xbe372f8c8e368c88dcbde7af88abe32632dcbe37af8c9e077967f8da22382b88c21f88c972f8c21f8da3216e3588a8dc,0x8c8bdcbe326f7af8c9bdebe326372f8cb8dcbe32c21e372f8cb8dcbe32e372f8cbbdebdee2f8c9e36be37af8cbe2325c,0x8209cbe3278be372f8c9e2f72f8c98c8e2f72f8c9088088]
    decide +kernel
  exact e28779
end OMA.Blocks5_13_245212.S28779
