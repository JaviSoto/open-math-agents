import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S59835
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b59835 : Box := ![⟨54,62⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨1,799016681299385430589⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨54,62⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨1,799016681299385430589⟩,⟨479,999999999999999999⟩] := by
  have e59835 : Deny 5 13 b59835 := by
    apply closeAction rule_sound _ _ 64 [0xbe32e37ef8cb8dfbe32e37ef8cbbc3e032030f88c81e32637d72af8cb8c88c78c98c20827d72b8be3207e232632e3238,0x8c9203bc38c90ef0ef8c9d881e37ef8cb8dfbe32e37ef8cb8dfbe32e37ef8cb8dfbe32e37ef8cb8dfbe32e37ef8cb8df,0x82082083e07e232788c81f8be3278be32231f8bc2082083e08e231f88c9e23238082083e232780f88c81f88c9e02083,0x2082]
    decide +kernel
  exact e59835
end OMA.Blocks5_13_245212.S59835
