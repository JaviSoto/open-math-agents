import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S54718
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b54718 : Box := ![⟨54,57⟩,⟨85,126⟩,⟨12,14⟩,⟨4,51⟩,⟨639,958⟩]
private def b54719 : Box := ![⟨54,57⟩,⟨85,126⟩,⟨12,12⟩,⟨4,49⟩,⟨639,958⟩]
private def b54720 : Box := ![⟨54,57⟩,⟨85,126⟩,⟨13,14⟩,⟨4,49⟩,⟨639,958⟩]
private def b54721 : Box := ![⟨54,57⟩,⟨85,101⟩,⟨13,14⟩,⟨4,49⟩,⟨639,958⟩]
private def b54722 : Box := ![⟨54,57⟩,⟨85,101⟩,⟨13,13⟩,⟨4,43⟩,⟨639,829⟩]
private def b54723 : Box := ![⟨54,57⟩,⟨85,101⟩,⟨14,14⟩,⟨4,43⟩,⟨639,829⟩]
private def b54724 : Box := ![⟨54,57⟩,⟨102,126⟩,⟨13,14⟩,⟨4,49⟩,⟨639,958⟩]
private def b54725 : Box := ![⟨54,55⟩,⟨102,126⟩,⟨13,14⟩,⟨8,49⟩,⟨639,958⟩]
private def b54726 : Box := ![⟨56,57⟩,⟨102,126⟩,⟨13,14⟩,⟨8,49⟩,⟨639,958⟩]
private theorem e54719 : Deny 5 13 b54719 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e54722 : Deny 5 13 b54722 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e54723 : Deny 5 13 b54723 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e54721 : Deny 5 13 b54721 :=
    branchAction rule_sound _ _ 3
      0x9e23 b54721 b54722 b54723 (by decide +kernel) e54722 e54723
private theorem e54725 : Deny 5 13 b54725 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e54726 : Deny 5 13 b54726 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e54724 : Deny 5 13 b54724 :=
    branchAction rule_sound _ _ 2
      0x1eb b54724 b54725 b54726 (by decide +kernel) e54725 e54726
private theorem e54720 : Deny 5 13 b54720 :=
    branchAction rule_sound _ _ 1
      0x8 b54720 b54721 b54724 (by decide +kernel) e54721 e54724
private theorem e54718 : Deny 5 13 b54718 :=
    branchAction rule_sound _ _ 2
      0x263 b54718 b54719 b54720 (by decide +kernel) e54719 e54720
theorem deny5_13 : Deny 5 13 ![⟨54,57⟩,⟨85,126⟩,⟨12,14⟩,⟨4,51⟩,⟨639,958⟩] := by
  exact e54718
end OMA.Blocks5_13_245212.S54718
