import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S26618
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b26618 : Box := ![⟨38,46⟩,⟨31,41⟩,⟨31,1920000000000000011376⟩,⟨3,900178041543026711604⟩,⟨239,478⟩]
theorem deny5_13 : Deny 5 13 ![⟨38,46⟩,⟨31,41⟩,⟨31,1920000000000000011376⟩,⟨3,900178041543026711604⟩,⟨239,478⟩] := by
  have e26618 : Deny 5 13 b26618 := by
    apply closeAction rule_sound _ _ 64 [0xe090870a22021f61030c90c3e098880e2102238da21c3088087e0910be3688a5ca11fe37da2108e0a7f8df68c7e23263,0x72f72f8c9bdf8c97efb6c88a7df0c3]
    decide +kernel
  exact e26618
end OMA.Blocks5_13_245212.S26618
