import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S57674
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b57674 : Box := ![⟨63,75⟩,⟨42,62⟩,⟨15,30⟩,⟨1,54⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,75⟩,⟨42,62⟩,⟨15,30⟩,⟨1,54⟩,⟨479,999999999999999999⟩] := by
  have e57674 : Deny 5 13 b57674 := by
    apply closeAction rule_sound _ _ 64 [0xde32632237df5c3e031c95cbe03e032380c90c3e090f82072570d7e072572c30f8243e080c22381c920a2972a32e3263,0x1c3e232231c30f88c80f88c97c3e1fe37238089e0ae235cae231e32430f81c3e23203e23088e378c70c22422388c21f8,0xc3e078c88df7d728a5ca8cb7df0f85f8d87e022172f82b82b88d72b88c98c78c88df7d728a5ca8cb0f80e32032430f8,0x1e32237df5ca2972a32e32631c20f88c7e030c78c88c25f8dc38c78c88cb0c31c30f81e32237df5ca2972a32e32430c7,0x82083e231f88c8e23278083e031f88c8e03e038c70c3]
    decide +kernel
  exact e57674
end OMA.Blocks5_13_245212.S57674
