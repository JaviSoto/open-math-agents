import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S16722
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b16722 : Box := ![⟨23,46⟩,⟨15,1920000000000000011376⟩,⟨3,6⟩,⟨1,1920000000000000011376⟩,⟨59,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨23,46⟩,⟨15,1920000000000000011376⟩,⟨3,6⟩,⟨1,1920000000000000011376⟩,⟨59,999999999999999999⟩] := by
  have e16722 : Deny 5 13 b16722 := by
    apply closeAction rule_sound _ _ 64 [0xdb58c81021f8d6320284a0ab84a8c2278db58c70c3e378c86f8df58c90f8df6d631c4087e37db5d232231028442b8d63,0x2421f784a10be378c78c86ab6db087e37db5ae31f8ae321b087e37db58c80a12a324b6ab6ab8c80dae37d631c225ae37,0xc3e378490e11c30f8dc72212842c30f8df51c225ae37db58c7de31020eb8c90e32036b8df58c98c70c3e37d498c80c2,0x8c748a6db0c3e211c3e0808984a2830890881021f8df584a8c46c26c384a8496c384a8476c3e03e090c3e37d491ca20a,0x1f8d6320284a089db58c46b8ae311b69b2ab8c41f8ae3108e1aadaada683e3684a11aac30eb1c8ae12e110ae2322b8c8,0x6ab6da68be2b8c7ac46ab8c41f8ae321b6f8df684a6b8df6d6b8c76f8df68c8d42]
    decide +kernel
  exact e16722
end OMA.Blocks5_13_245212.S16722
