import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S34694
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b34694 : Box := ![⟨95,1920000000000000011376⟩,⟨33,1920000000000000011376⟩,⟨5,6⟩,⟨1,1090612244897959190168⟩,⟨119,238⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,1920000000000000011376⟩,⟨33,1920000000000000011376⟩,⟨5,6⟩,⟨1,1090612244897959190168⟩,⟨119,238⟩] := by
  have e34694 : Deny 5 13 b34694 := by
    apply closeAction rule_sound _ _ 64 [0x6e78c79db6d36d32b880880a80a4ca6e76db4c280880a4ca8044cae2029be378c8102278de31f88c88c74e580a8c88c4,0x20a7093e376e78c8263113dc42e31e32380826ab8c41f8ae311b2384e884a8c42786d32a321384a8c74ca667]
    decide +kernel
  exact e34694
end OMA.Blocks5_13_245212.S34694
