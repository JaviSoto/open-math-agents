import PrimeWindow245212

/-! Bound four cofactors using a single common integer denominator. The
residue of the highest base-p digit then cuts both the exponent and the
prime using only signed integer products and divisions. -/
namespace OMA.FastDigit245212
open OMA.Box245212 OMA.DigitBox245212 OMA.PrefixLeaf245212
open private OMA.PrefixLeaf245212.trim_sound from PrefixLeaf245212
open private OMA.DigitBox245212.digitsQ from DigitBox245212

structure Span where
  xl : ℕ
  yl : ℕ
  xu : ℕ
  yu : ℕ

def dI (Z A S d : ℕ) : ℤ := (d+1:ℤ)*(2*(Z:ℤ)-A)-S
def nI (A S d : ℕ) : ℤ := d*(A:ℤ)+S
def obey (Z : ℕ) (b : Span) (d l h : ℕ) : Prop :=
  0<dI Z b.xl b.yl d ∧ nI b.xl b.yl d≤h*dI Z b.xl b.yl d ∧
    ((l:ℤ)-1)*dI Z b.xu b.yu d<nI b.xu b.yu d

theorem obey_of_score {Z r d l h : ℕ} {b : Span} {x y : ℚ} (z : 0<Z) (prime : r.Prime)
    (hd : 0<d) (hx : 0≤x) (hy : 0<y) (low : 1≤l) (lr : l≤r) (rh : r≤h)
    (value : x*OMA.Smooth245212.X r (some d)+y*OMA.Smooth245212.Y r (some d)=2)
    (ax : (b.xl:ℚ)≤Z*x) (ay : (b.yl:ℚ)≤Z*y)
    (ux : (Z:ℚ)*x≤b.xu) (uy : (Z:ℚ)*y≤b.yu) : obey Z b d l h := by
  obtain ⟨dp,lo,up⟩ := OMA.DigitBox245212.digitsQ prime hd hx hy value
  have zz : (0:ℚ)<Z := by exact_mod_cast z
  have denLo : (Z:ℚ)*den x y d≤dI Z b.xl b.yl d := by
    unfold dI den; push_cast
    nlinarith only [ax,ay,mul_le_mul_of_nonneg_left ax (Nat.cast_nonneg (α:=ℚ) d)]
  have denHi : (dI Z b.xu b.yu d:ℚ)≤Z*den x y d := by
    unfold dI den; push_cast
    nlinarith only [ux,uy,mul_le_mul_of_nonneg_left ux (Nat.cast_nonneg (α:=ℚ) d)]
  have numLo : (nI b.xl b.yl d:ℚ)≤Z*num x y d := by
    unfold nI num; push_cast
    nlinarith only [ay,mul_le_mul_of_nonneg_left ax (Nat.cast_nonneg (α:=ℚ) d)]
  have numHi : (Z:ℚ)*num x y d≤nI b.xu b.yu d := by
    unfold nI num; push_cast
    nlinarith only [uy,mul_le_mul_of_nonneg_left ux (Nat.cast_nonneg (α:=ℚ) d)]
  have hi' : (r:ℚ)≤h := by exact_mod_cast rh
  have lo' : (l:ℚ)-1≤r-1 := by exact_mod_cast sub_le_sub_right (show (l:ℤ)≤r by exact_mod_cast lr) 1
  have ll : (1:ℚ)≤l := by exact_mod_cast low
  refine ⟨?_,?_,?_⟩
  · exact_mod_cast (mul_pos zz dp).trans_le denLo
  · have h1 := (mul_le_mul_of_nonneg_left up zz.le)
    have h2 := (mul_le_mul hi' denLo (mul_pos zz dp).le (Nat.cast_nonneg h))
    exact_mod_cast numLo.trans ((show (Z:ℚ)*num x y d≤r*(Z*den x y d) by linarith only [h1]).trans h2)
  · have h1 := mul_lt_mul_of_pos_left lo zz
    have h2 := (mul_le_mul_of_nonneg_left denHi (show 0≤(l:ℚ)-1 by linarith)).trans
      (mul_le_mul_of_nonneg_right lo' (mul_pos zz dp).le)
    exact_mod_cast h2.trans_lt ((show ((r:ℚ)-1)*(Z*den x y d)<Z*num x y d by linarith only [h1]).trans_le numHi)

private def cut (r : Range) (v w : ℤ) (strict : Bool) : Range :=
  let c := trim (r.lo,r.hi) v (w-v-(if strict then 1 else 0))
  ⟨c.1,c.2⟩
private theorem cut_ok {r : Range} {v w : ℤ} {d : ℕ} (fit : r.has d) (strict : Bool)
    (h : if strict then v*((d:ℤ)+1)<w else v*((d:ℤ)+1)≤w) : (cut r v w strict).has d := by
  apply OMA.PrefixLeaf245212.trim_sound fit.1 fit.2
  cases strict <;> simp only [Bool.false_eq_true,if_false,if_true,sub_zero] at h ⊢ <;> nlinarith only [h]

def digitAt (Z : ℕ) (b : Span) (d pp : Range) : Range :=
  let X : ℤ := b.xl; let Y : ℤ := b.yl
  let U : ℤ := b.xu; let V : ℤ := b.yu
  let r : ℤ := pp.lo; let P : ℤ := pp.hi
  let d := cut d (X-2*Z) (-Y) true
  let d := cut d ((P+1)*X-2*P*Z) (X-(P+1)*Y) false
  cut d (2*(r-1)*Z-r*U) (r*V-U) true

theorem digitAt_ok {Z d : ℕ} {b : Span} {r pp : Range} (fit : r.has d)
    (h : obey Z b d pp.lo pp.hi) : (digitAt Z b r pp).has d := by
  obtain ⟨h1,h2,h3⟩ := h
  simp only [dI,nI] at h1 h2 h3
  refine cut_ok (cut_ok (cut_ok fit true ?_) false ?_) true ?_
  · simp only [if_true]; linarith only [h1]
  · simp only [Bool.false_eq_true,if_false]; linarith only [h2]
  · simp only [if_true]; linarith only [h3]

def ceilD (Z A S e : ℕ) : ℕ := ((nI A S e+dI Z A S e-1)/dI Z A S e).toNat

private theorem ex (Z A S : ℕ) (u v : ℤ) {E : Range} {d : ℕ} (fit : E.has d) :
    let f (j : ℕ) := u*dI Z A S j+v*nI A S j
    f d≤f E.lo ∨ f d≤f E.hi := by
  have le1 : (E.lo:ℤ)≤d := by exact_mod_cast fit.1
  have le2 : (d:ℤ)≤E.hi := by exact_mod_cast fit.2
  by_cases sign : 0≤u*(2*(Z:ℤ)-A)+v*A
  · right; unfold dI nI; nlinarith only [mul_nonneg (sub_nonneg.mpr le2) sign]
  · left; unfold dI nI; nlinarith only [mul_nonneg (sub_nonneg.mpr le1) (neg_nonneg.mpr (le_of_not_ge sign))]

def lowPrime (Z A S : ℕ) (E R : Range) : Range :=
  if dI Z A S E.lo≤0 ∧ dI Z A S E.hi≤0 then ⟨1,0⟩
  else if 0<dI Z A S E.lo ∧ 0<dI Z A S E.hi then
    ⟨max R.lo (min (ceilD Z A S E.lo) (ceilD Z A S E.hi)),R.hi⟩ else R

def highPrime (Z A S : ℕ) (E R : Range) : Range :=
  if 0<dI Z A S E.lo ∧ 0<dI Z A S E.hi then
    ⟨R.lo,min R.hi (max (ceilD Z A S E.lo) (ceilD Z A S E.hi))⟩ else R

theorem lowPrime_ok {Z A S d r : ℕ} {E R : Range} (ed : E.has d) (rr : R.has r)
    (pos : 0<dI Z A S d) (low : nI A S d≤r*dI Z A S d) : (lowPrime Z A S E R).has r := by
  unfold lowPrime;split_ifs with neg both
  · have ext := ex Z A S 1 0 ed
    simp only [one_mul,zero_mul,add_zero] at ext
    rcases ext with h|h <;> linarith [neg.1,neg.2]
  · refine ⟨max_le rr.1 ?_,rr.2⟩
    have one (j : ℕ) (pd : 0<dI Z A S j)
        (h : r*dI Z A S d+(-1)*nI A S d≤r*dI Z A S j+(-1)*nI A S j) : ceilD Z A S j≤r := by
      apply Int.toNat_le.mpr
      apply Int.le_of_lt_add_one
      apply (Int.ediv_lt_iff_lt_mul pd).mpr
      nlinarith only [low,h]
    rcases ex Z A S r (-1) ed with h|h
    · exact (min_le_left ..).trans (one _ both.1 h)
    · exact (min_le_right ..).trans (one _ both.2 h)
  · exact rr

theorem highPrime_ok {Z A S d r : ℕ} {E R : Range} (ed : E.has d) (rr : R.has r)
    (up : ((r:ℤ)-1)*dI Z A S d<nI A S d) : (highPrime Z A S E R).has r := by
  unfold highPrime;split_ifs with both
  · refine ⟨rr.1,le_min rr.2 ?_⟩
    have one (j : ℕ) (pd : 0<dI Z A S j)
        (h : (1-r)*dI Z A S d+1*nI A S d≤(1-r)*dI Z A S j+1*nI A S j) : r≤ceilD Z A S j := by
      have le : (r:ℤ)≤(nI A S j+dI Z A S j-1)/dI Z A S j := by
        apply (Int.le_ediv_iff_mul_le pd).mpr
        nlinarith only [up,h]
      exact (Int.toNat_le_toNat le)
    rcases ex Z A S (1-r) 1 ed with h|h
    · exact (one _ both.1 h).trans (le_max_left ..)
    · exact (one _ both.2 h).trans (le_max_right ..)
  · exact rr

end OMA.FastDigit245212
