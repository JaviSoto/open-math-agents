import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S44366
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b44366 : Box := ![⟨95,190⟩,⟨15,17⟩,⟨15,30⟩,⟨3,68⟩,⟨165,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨15,17⟩,⟨15,30⟩,⟨3,68⟩,⟨165,233⟩] := by
  have e44366 : Deny 5 13 b44366 := by
    apply closeAction rule_sound _ _ 64 [0x1e710b0e70f88c7088678de78c99c4678df69e3107e278c9da70c221de378c911de37da3107e37da31dde37db48c88c4,0xd880a79a02a311d9dd9c38c78c7743e03e089e32678c99c3e038c77480e70f81c3e37da02202839c3e378c70889e3263,0x1d7670f77678c98c710b743e278c42789e32670dde378c711de378c4278da31dde37]
    decide +kernel
  exact e44366
end OMA.Blocks5_13_245212.S44366
