import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S54616
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b54616 : Box := ![⟨47,62⟩,⟨127,1920000000000000011376⟩,⟨10,14⟩,⟨1,565934718100890211098⟩,⟨239,478⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,62⟩,⟨127,1920000000000000011376⟩,⟨10,14⟩,⟨1,565934718100890211098⟩,⟨239,478⟩] := by
  have e54616 : Deny 5 13 b54616 := by
    apply closeAction rule_sound _ _ 64 [0xf80f8ac922b847683e2110ae211021f8ae124209aae126b8441f86ab103108e1a1eb849ae110bae11e12ab8c8ae322b,0x6ab6ab6820ab8441f86c9e1ae2b0f80f8ac72386ab]
    decide +kernel
  exact e54616
end OMA.Blocks5_13_245212.S54616
