import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S45739
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b45739 : Box := ![⟨95,190⟩,⟨15,17⟩,⟨31,1920000000000000011376⟩,⟨3,900178041543026711620⟩,⟨239,478⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨15,17⟩,⟨31,1920000000000000011376⟩,⟨3,900178041543026711620⟩,⟨239,478⟩] := by
  have e45739 : Deny 5 13 b45739 := by
    apply closeAction rule_sound _ _ 64 [0xe2229de37d888c910b738df62388c756229d7550e6103e36107e20102238809578d87578df61f82b8295e0a088e23263,0x72f74974956229cbdd8c9d82bec88a738df68c8da311cbddbe326f75d54a]
    decide +kernel
  exact e45739
end OMA.Blocks5_13_245212.S45739
