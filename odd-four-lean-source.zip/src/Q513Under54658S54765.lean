import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S54765
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b54765 : Box := ![⟨54,62⟩,⟨87,126⟩,⟨11,12⟩,⟨3,52⟩,⟨959,681527⟩]
private def b54766 : Box := ![⟨54,57⟩,⟨93,126⟩,⟨11,12⟩,⟨5,47⟩,⟨959,1132⟩]
private def b54767 : Box := ![⟨58,62⟩,⟨93,126⟩,⟨11,12⟩,⟨5,47⟩,⟨959,1132⟩]
private def b54768 : Box := ![⟨58,62⟩,⟨94,107⟩,⟨11,12⟩,⟨6,46⟩,⟨959,1131⟩]
private def b54769 : Box := ![⟨58,62⟩,⟨108,126⟩,⟨11,12⟩,⟨6,46⟩,⟨959,1131⟩]
private theorem e54766 : Deny 5 13 b54766 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e54768 : Deny 5 13 b54768 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e54769 : Deny 5 13 b54769 := by
    apply closeAction rule_sound _ _ 64 [0x6eb]
    decide +kernel
private theorem e54767 : Deny 5 13 b54767 :=
    branchAction rule_sound _ _ 5
      0x8e35ae3 b54767 b54768 b54769 (by decide +kernel) e54768 e54769
private theorem e54765 : Deny 5 13 b54765 :=
    branchAction rule_sound _ _ 5
      0x7e37d63 b54765 b54766 b54767 (by decide +kernel) e54766 e54767
theorem deny5_13 : Deny 5 13 ![⟨54,62⟩,⟨87,126⟩,⟨11,12⟩,⟨3,52⟩,⟨959,681527⟩] := by
  exact e54765
end OMA.Blocks5_13_245212.S54765
