import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S62440
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b62440 : Box := ![⟨95,190⟩,⟨31,62⟩,⟨10,14⟩,⟨1,74⟩,⟨127,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨31,62⟩,⟨10,14⟩,⟨1,74⟩,⟨127,233⟩] := by
  have e62440 : Deny 5 13 b62440 := by
    apply closeAction rule_sound _ _ 64 [0xe0108e370f8dc38c88c70f8dc39e02270c780a10b8c88c98c78c20820a70f8dc3207808247de310be174e580980a8c8,0xa7960109e379c2091238dc20c4278dc3207108e370829e6960108e37103e370c8107e370f8dc32670c3de32231e3102,0x4f8dc2]
    decide +kernel
  exact e62440
end OMA.Blocks5_13_245212.S62440
