import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S54481
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b54481 : Box := ![⟨54,62⟩,⟨63,126⟩,⟨10,14⟩,⟨1,59⟩,⟨239,478⟩]
private def b54482 : Box := ![⟨54,62⟩,⟨63,126⟩,⟨10,14⟩,⟨1,59⟩,⟨239,318⟩]
private def b54483 : Box := ![⟨54,62⟩,⟨63,126⟩,⟨10,14⟩,⟨1,2⟩,⟨239,317⟩]
private def b54488 : Box := ![⟨54,62⟩,⟨63,126⟩,⟨10,14⟩,⟨3,59⟩,⟨239,317⟩]
private def b54489 : Box := ![⟨54,62⟩,⟨63,126⟩,⟨10,11⟩,⟨3,59⟩,⟨239,317⟩]
private def b54490 : Box := ![⟨54,62⟩,⟨63,84⟩,⟨10,11⟩,⟨3,57⟩,⟨239,317⟩]
private def b54499 : Box := ![⟨54,62⟩,⟨85,126⟩,⟨10,11⟩,⟨3,57⟩,⟨239,317⟩]
private def b54508 : Box := ![⟨54,62⟩,⟨63,126⟩,⟨12,14⟩,⟨3,59⟩,⟨239,317⟩]
private def b54509 : Box := ![⟨54,62⟩,⟨63,84⟩,⟨12,14⟩,⟨3,59⟩,⟨239,317⟩]
private def b54510 : Box := ![⟨54,57⟩,⟨63,84⟩,⟨12,14⟩,⟨3,46⟩,⟨239,317⟩]
private def b54515 : Box := ![⟨58,62⟩,⟨63,84⟩,⟨12,14⟩,⟨3,46⟩,⟨239,317⟩]
private def b54516 : Box := ![⟨58,62⟩,⟨63,84⟩,⟨12,14⟩,⟨3,46⟩,⟨239,272⟩]
private def b54523 : Box := ![⟨58,62⟩,⟨63,84⟩,⟨12,14⟩,⟨3,46⟩,⟨273,317⟩]
private def b54530 : Box := ![⟨54,62⟩,⟨85,126⟩,⟨12,14⟩,⟨3,59⟩,⟨239,317⟩]
private def b54537 : Box := ![⟨54,62⟩,⟨63,126⟩,⟨10,14⟩,⟨1,59⟩,⟨319,478⟩]
private def b54538 : Box := ![⟨54,62⟩,⟨63,126⟩,⟨10,11⟩,⟨1,56⟩,⟨319,478⟩]
private def b54539 : Box := ![⟨54,62⟩,⟨63,126⟩,⟨10,11⟩,⟨1,2⟩,⟨319,478⟩]
private def b54540 : Box := ![⟨54,62⟩,⟨63,126⟩,⟨10,11⟩,⟨3,55⟩,⟨319,478⟩]
private def b54541 : Box := ![⟨54,62⟩,⟨63,84⟩,⟨10,11⟩,⟨3,55⟩,⟨319,478⟩]
private def b54548 : Box := ![⟨54,62⟩,⟨85,126⟩,⟨10,11⟩,⟨3,55⟩,⟨319,478⟩]
private def b54559 : Box := ![⟨54,62⟩,⟨63,126⟩,⟨12,14⟩,⟨1,56⟩,⟨319,478⟩]
private def b54560 : Box := ![⟨54,62⟩,⟨63,84⟩,⟨12,14⟩,⟨1,56⟩,⟨319,478⟩]
private def b54561 : Box := ![⟨54,62⟩,⟨63,84⟩,⟨12,14⟩,⟨1,2⟩,⟨319,478⟩]
private def b54564 : Box := ![⟨54,62⟩,⟨63,84⟩,⟨12,14⟩,⟨3,44⟩,⟨319,478⟩]
private def b54565 : Box := ![⟨54,57⟩,⟨63,84⟩,⟨12,14⟩,⟨3,44⟩,⟨319,478⟩]
private def b54570 : Box := ![⟨58,62⟩,⟨63,84⟩,⟨12,14⟩,⟨3,44⟩,⟨319,478⟩]
private def b54571 : Box := ![⟨58,62⟩,⟨63,84⟩,⟨12,14⟩,⟨3,44⟩,⟨319,382⟩]
private def b54578 : Box := ![⟨58,62⟩,⟨63,84⟩,⟨12,14⟩,⟨3,44⟩,⟨383,478⟩]
private def b54585 : Box := ![⟨54,62⟩,⟨85,126⟩,⟨12,14⟩,⟨1,56⟩,⟨319,478⟩]
private def b54586 : Box := ![⟨54,57⟩,⟨85,126⟩,⟨12,14⟩,⟨4,56⟩,⟨319,478⟩]
private def b54587 : Box := ![⟨54,57⟩,⟨85,126⟩,⟨12,14⟩,⟨5,55⟩,⟨319,382⟩]
private def b54596 : Box := ![⟨54,57⟩,⟨85,126⟩,⟨12,14⟩,⟨5,55⟩,⟨383,478⟩]
private def b54607 : Box := ![⟨58,62⟩,⟨85,126⟩,⟨12,14⟩,⟨4,56⟩,⟨319,478⟩]
private theorem e54483 : Deny 5 13 b54483 := by
    apply closeAction rule_sound _ _ 64 [0x5d3253261]
    decide +kernel
private theorem e54490 : Deny 5 13 b54490 := by
    apply closeAction rule_sound _ _ 64 [0xc38c90e32030f8de32231e3]
    decide +kernel
private theorem e54499 : Deny 5 13 b54499 := by
    apply closeAction rule_sound _ _ 64 [0x6eb6c3e040e1109e03847ae12a322b]
    decide +kernel
private theorem e54489 : Deny 5 13 b54489 :=
    branchAction rule_sound _ _ 2
      0x223 b54489 b54490 b54499 (by decide +kernel) e54490 e54499
private theorem e54510 : Deny 5 13 b54510 := by
    apply closeAction rule_sound _ _ 64 [0xf8dc38c80e3263]
    decide +kernel
private theorem e54516 : Deny 5 13 b54516 := by
    apply closeAction rule_sound _ _ 64 [0x24c9e370f8dc3248dc4]
    decide +kernel
private theorem e54523 : Deny 5 13 b54523 := by
    apply closeAction rule_sound _ _ 64 [0x20c9dc3dc38c98c88c4]
    decide +kernel
private theorem e54515 : Deny 5 13 b54515 :=
    branchAction rule_sound _ _ 1
      0xb b54515 b54516 b54523 (by decide +kernel) e54516 e54523
private theorem e54509 : Deny 5 13 b54509 :=
    branchAction rule_sound _ _ 2
      0x1e3 b54509 b54510 b54515 (by decide +kernel) e54510 e54515
private theorem e54530 : Deny 5 13 b54530 := by
    apply closeAction rule_sound _ _ 64 [0x20820f8ac9238ac41f8deb]
    decide +kernel
private theorem e54508 : Deny 5 13 b54508 :=
    branchAction rule_sound _ _ 1
      0x8 b54508 b54509 b54530 (by decide +kernel) e54509 e54530
private theorem e54488 : Deny 5 13 b54488 :=
    branchAction rule_sound _ _ 1
      0x9 b54488 b54489 b54508 (by decide +kernel) e54489 e54508
private theorem e54482 : Deny 5 13 b54482 :=
    branchAction rule_sound _ _ 2
      0x284 b54482 b54483 b54488 (by decide +kernel) e54483 e54488
private theorem e54539 : Deny 5 13 b54539 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
private theorem e54541 : Deny 5 13 b54541 := by
    apply closeAction rule_sound _ _ 64 [0xdbe378c80898c40841f8de3]
    decide +kernel
private theorem e54548 : Deny 5 13 b54548 := by
    apply closeAction rule_sound _ _ 64 [0x6c30f88496f8de11022788470f8a212a12ab]
    decide +kernel
private theorem e54540 : Deny 5 13 b54540 :=
    branchAction rule_sound _ _ 1
      0x8 b54540 b54541 b54548 (by decide +kernel) e54541 e54548
private theorem e54538 : Deny 5 13 b54538 :=
    branchAction rule_sound _ _ 2
      0x2a3 b54538 b54539 b54540 (by decide +kernel) e54539 e54540
private theorem e54561 : Deny 5 13 b54561 := by
    apply closeAction rule_sound _ _ 64 [0x4d7e37da11e1]
    decide +kernel
private theorem e54565 : Deny 5 13 b54565 := by
    apply closeAction rule_sound _ _ 64 [0x30f88c80f8de3263]
    decide +kernel
private theorem e54571 : Deny 5 13 b54571 := by
    apply closeAction rule_sound _ _ 64 [0xf70e32030f7263204]
    decide +kernel
private theorem e54578 : Deny 5 13 b54578 := by
    apply closeAction rule_sound _ _ 64 [0x30e32030f8dc98c88c4]
    decide +kernel
private theorem e54570 : Deny 5 13 b54570 :=
    branchAction rule_sound _ _ 1
      0xb b54570 b54571 b54578 (by decide +kernel) e54571 e54578
private theorem e54564 : Deny 5 13 b54564 :=
    branchAction rule_sound _ _ 1
      0x7 b54564 b54565 b54570 (by decide +kernel) e54565 e54570
private theorem e54560 : Deny 5 13 b54560 :=
    branchAction rule_sound _ _ 2
      0x2a3 b54560 b54561 b54564 (by decide +kernel) e54561 e54564
private theorem e54587 : Deny 5 13 b54587 := by
    apply closeAction rule_sound _ _ 64 [0x83ae1109e37ac20c41f8dc3ae3263204]
    decide +kernel
private theorem e54596 : Deny 5 13 b54596 := by
    apply closeAction rule_sound _ _ 64 [0x20eb107e370eb8c9adf0c90c98c88c4]
    decide +kernel
private theorem e54586 : Deny 5 13 b54586 :=
    branchAction rule_sound _ _ 3
      0xbae3 b54586 b54587 b54596 (by decide +kernel) e54587 e54596
private theorem e54607 : Deny 5 13 b54607 := by
    apply closeAction rule_sound _ _ 64 [0x92278deb8c20f7107e370e3263238]
    decide +kernel
private theorem e54585 : Deny 5 13 b54585 :=
    branchAction rule_sound _ _ 2
      0x1eb b54585 b54586 b54607 (by decide +kernel) e54586 e54607
private theorem e54559 : Deny 5 13 b54559 :=
    branchAction rule_sound _ _ 1
      0x8 b54559 b54560 b54585 (by decide +kernel) e54560 e54585
private theorem e54537 : Deny 5 13 b54537 :=
    branchAction rule_sound _ _ 2
      0x263 b54537 b54538 b54559 (by decide +kernel) e54538 e54559
private theorem e54481 : Deny 5 13 b54481 :=
    branchAction rule_sound _ _ 1
      0xb b54481 b54482 b54537 (by decide +kernel) e54482 e54537
theorem deny5_13 : Deny 5 13 ![⟨54,62⟩,⟨63,126⟩,⟨10,14⟩,⟨1,59⟩,⟨239,478⟩] := by
  exact e54481
end OMA.Blocks5_13_245212.S54481
