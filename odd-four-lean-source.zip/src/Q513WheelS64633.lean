import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S64633
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b64633 : Box := ![⟨95,126⟩,⟨63,126⟩,⟨7,9⟩,⟨1,79⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,126⟩,⟨63,126⟩,⟨7,9⟩,⟨1,79⟩,⟨479,999999999999999999⟩] := by
  have e64633 : Deny 5 13 b64633 := by
    apply closeAction rule_sound _ _ 64 [0x2db2532932a32db6db6db4ca2842cb2d32932b88c22788c78c88db6d328a4ca4ca8cb6db2d32932b88dbe378c8e23263,0xe378c8e231c22632236f86f86f80e32231e321b2532932a32e31c3e038c80f88c70f88c21f88c80898db6f80c38c78c8,0xe03e038c88c70f80f8de32388c21f88c98c88d3e376d32932a32632c20f88c8e030e32231db4cae372430f88c80f88db,0x20f80e31c30f88c78c88db4ca8cb6d32b88c74ca2420f88c8]
    decide +kernel
  exact e64633
end OMA.Blocks5_13_245212.S64633
