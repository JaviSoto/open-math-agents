import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S65223
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b65223 : Box := ![⟨127,190⟩,⟨127,1920000000000000011376⟩,⟨7,9⟩,⟨1,502335381913959616726⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨127,190⟩,⟨127,1920000000000000011376⟩,⟨7,9⟩,⟨1,502335381913959616726⟩,⟨479,999999999999999999⟩] := by
  have e65223 : Deny 5 13 b65223 := by
    apply closeAction rule_sound _ _ 64 [0x8dbae32f8083e232380f80e32231c3e03e2321b4cae231e32236d32a32db4cae231e32236d32a32e31f84cae23223278,0x2e12932d32d22d22d22d22e12932d32d32ca8dbae32e36eb8cb8dbae32e36eb8cb8dbae32e36eb8cb8dbae32e36eb8cb,0x820820820f88c8e03e03e232388c7e232388c7e232388db6db6d32d32d22d22d22d22d22d22d2]
    decide +kernel
  exact e65223
end OMA.Blocks5_13_245212.S65223
