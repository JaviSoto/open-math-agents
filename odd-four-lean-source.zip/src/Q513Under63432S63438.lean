import FastReplay245212
import SparseDigit245212
import ShortPrimeTrim245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S63438
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.ShortPrimeTrim245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.ShortPrimeTrim245212.sound
private def b63438 : Box := ![⟨153,190⟩,⟨36,38⟩,⟨13,14⟩,⟨8,47⟩,⟨959,1918⟩]
private def b63439 : Box := ![⟨153,190⟩,⟨36,36⟩,⟨13,14⟩,⟨8,20⟩,⟨1790,1918⟩]
private def b63440 : Box := ![⟨153,190⟩,⟨37,38⟩,⟨13,14⟩,⟨8,20⟩,⟨1790,1918⟩]
private theorem e63439 : Deny 5 13 b63439 := by
    apply closeAction rule_sound _ _ 64 [0x3e379c4]
    decide +kernel
private theorem e63440 : Deny 5 13 b63440 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e63438 : Deny 5 13 b63438 :=
    branchAction rule_sound _ _ 3
      0x8e37 b63438 b63439 b63440 (by decide +kernel) e63439 e63440
theorem deny5_13 : Deny 5 13 ![⟨153,190⟩,⟨36,38⟩,⟨13,14⟩,⟨8,47⟩,⟨959,1918⟩] := by
  exact e63438
end OMA.Blocks5_13_245212.S63438
