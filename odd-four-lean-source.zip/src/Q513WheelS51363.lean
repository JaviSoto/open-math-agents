import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S51363
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b51363 : Box := ![⟨127,190⟩,⟨25,30⟩,⟨31,62⟩,⟨1,76⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨127,190⟩,⟨25,30⟩,⟨31,62⟩,⟨1,76⟩,⟨479,999999999999999999⟩] := by
  have e51363 : Deny 5 13 b51363 := by
    apply closeAction rule_sound _ _ 64 [0x2788c7e020e32430f88c98c78df7d50f80c724a2952a32c88c98c78c2082578dc20e32631e35772c8e232631e32e3238,0x82082083e232788c7e08e232780820820f88c7e232788c7e23238082083e08e23]
    decide +kernel
  exact e51363
end OMA.Blocks5_13_245212.S51363
