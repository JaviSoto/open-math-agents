import FastReplay245212
import SparseDigit245212
import ShortPrimeTrim245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S50113
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.ShortPrimeTrim245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.ShortPrimeTrim245212.sound
private def b50113 : Box := ![⟨127,152⟩,⟨23,23⟩,⟨42,62⟩,⟨3,56⟩,⟨959,1918⟩]
private def b50114 : Box := ![⟨127,152⟩,⟨23,23⟩,⟨42,62⟩,⟨3,6⟩,⟨959,1918⟩]
private def b50115 : Box := ![⟨127,152⟩,⟨23,23⟩,⟨42,62⟩,⟨7,55⟩,⟨959,1918⟩]
private def b50116 : Box := ![⟨127,152⟩,⟨23,23⟩,⟨42,62⟩,⟨7,13⟩,⟨1067,1918⟩]
private def b50117 : Box := ![⟨127,152⟩,⟨23,23⟩,⟨42,62⟩,⟨7,9⟩,⟨1067,1918⟩]
private def b50118 : Box := ![⟨127,152⟩,⟨23,23⟩,⟨42,50⟩,⟨7,9⟩,⟨1067,1918⟩]
private def b50119 : Box := ![⟨127,152⟩,⟨23,23⟩,⟨42,50⟩,⟨7,9⟩,⟨1067,1371⟩]
private def b50120 : Box := ![⟨127,152⟩,⟨23,23⟩,⟨42,50⟩,⟨7,9⟩,⟨1372,1918⟩]
private def b50121 : Box := ![⟨127,152⟩,⟨23,23⟩,⟨42,50⟩,⟨7,7⟩,⟨1372,1918⟩]
private def b50122 : Box := ![⟨127,152⟩,⟨23,23⟩,⟨42,50⟩,⟨8,9⟩,⟨1372,1918⟩]
private def b50123 : Box := ![⟨127,138⟩,⟨23,23⟩,⟨42,50⟩,⟨8,9⟩,⟨1372,1918⟩]
private def b50124 : Box := ![⟨127,132⟩,⟨23,23⟩,⟨42,50⟩,⟨8,9⟩,⟨1372,1918⟩]
private def b50125 : Box := ![⟨133,138⟩,⟨23,23⟩,⟨42,50⟩,⟨8,9⟩,⟨1372,1918⟩]
private def b50126 : Box := ![⟨139,152⟩,⟨23,23⟩,⟨42,50⟩,⟨8,9⟩,⟨1372,1918⟩]
private def b50127 : Box := ![⟨139,152⟩,⟨23,23⟩,⟨42,45⟩,⟨8,9⟩,⟨1836,1918⟩]
private def b50128 : Box := ![⟨139,152⟩,⟨23,23⟩,⟨46,50⟩,⟨8,9⟩,⟨1836,1918⟩]
private def b50129 : Box := ![⟨127,152⟩,⟨23,23⟩,⟨51,62⟩,⟨7,9⟩,⟨1067,1918⟩]
private def b50130 : Box := ![⟨127,152⟩,⟨23,23⟩,⟨42,62⟩,⟨10,13⟩,⟨1067,1918⟩]
private def b50131 : Box := ![⟨127,152⟩,⟨23,23⟩,⟨42,62⟩,⟨14,55⟩,⟨1067,1918⟩]
private theorem e50114 : Deny 5 13 b50114 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
private theorem e50119 : Deny 5 13 b50119 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e50121 : Deny 5 13 b50121 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
private theorem e50124 : Deny 5 13 b50124 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e50125 : Deny 5 13 b50125 := by
    apply closeAction rule_sound _ _ 64 [0xf8]
    decide +kernel
private theorem e50123 : Deny 5 13 b50123 :=
    branchAction rule_sound _ _ 1
      0x7 b50123 b50124 b50125 (by decide +kernel) e50124 e50125
private theorem e50127 : Deny 5 13 b50127 := by
    apply closeAction rule_sound _ _ 64 [0xc4]
    decide +kernel
private theorem e50128 : Deny 5 13 b50128 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e50126 : Deny 5 13 b50126 :=
    branchAction rule_sound _ _ 2
      0x278 b50126 b50127 b50128 (by decide +kernel) e50127 e50128
private theorem e50122 : Deny 5 13 b50122 :=
    branchAction rule_sound _ _ 1
      0x7 b50122 b50123 b50126 (by decide +kernel) e50123 e50126
private theorem e50120 : Deny 5 13 b50120 :=
    branchAction rule_sound _ _ 1
      0xa b50120 b50121 b50122 (by decide +kernel) e50121 e50122
private theorem e50118 : Deny 5 13 b50118 :=
    branchAction rule_sound _ _ 1
      0xb b50118 b50119 b50120 (by decide +kernel) e50119 e50120
private theorem e50129 : Deny 5 13 b50129 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
private theorem e50117 : Deny 5 13 b50117 :=
    branchAction rule_sound _ _ 1
      0x9 b50117 b50118 b50129 (by decide +kernel) e50118 e50129
private theorem e50130 : Deny 5 13 b50130 := by
    apply closeAction rule_sound _ _ 64 [0x1d]
    decide +kernel
private theorem e50116 : Deny 5 13 b50116 :=
    branchAction rule_sound _ _ 1
      0xa b50116 b50117 b50130 (by decide +kernel) e50117 e50130
private theorem e50131 : Deny 5 13 b50131 := by
    apply closeAction rule_sound _ _ 64 [0x1d]
    decide +kernel
private theorem e50115 : Deny 5 13 b50115 :=
    branchAction rule_sound _ _ 2
      0x2b8 b50115 b50116 b50131 (by decide +kernel) e50116 e50131
private theorem e50113 : Deny 5 13 b50113 :=
    branchAction rule_sound _ _ 2
      0x2a3 b50113 b50114 b50115 (by decide +kernel) e50114 e50115
theorem deny5_13 : Deny 5 13 ![⟨127,152⟩,⟨23,23⟩,⟨42,62⟩,⟨3,56⟩,⟨959,1918⟩] := by
  exact e50113
end OMA.Blocks5_13_245212.S50113
