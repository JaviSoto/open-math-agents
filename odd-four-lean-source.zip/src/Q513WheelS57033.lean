import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S57033
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b57033 : Box := ![⟨47,62⟩,⟨31,62⟩,⟨15,30⟩,⟨1,54⟩,⟨239,478⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,62⟩,⟨31,62⟩,⟨15,30⟩,⟨1,54⟩,⟨239,478⟩] := by
  have e57033 : Deny 5 13 b57033 := by
    apply closeAction rule_sound _ _ 64 [0x2490c3e37243e37d880f8df61c810b1c97d75c2238d885cb5f81ca5ca0c3e090f8d870c4087e37d881021f82482972a3,0xc42380c320725f5c324a5ca0c31c32492042df0df21fe0710b5ca0c2204087e3725fe37d887d70c92972830f8dc70f8,0x5df5cb5cb1ca5ca7f80f80c81d7283e032432030f820725f7df2c42d72830891021f8248097e370c8107e020c4278dc4,0x7df]
    decide +kernel
  exact e57033
end OMA.Blocks5_13_245212.S57033
