import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S25039
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b25039 : Box := ![⟨31,37⟩,⟨42,62⟩,⟨31,1920000000000000011376⟩,⟨3,1017986577181208059764⟩,⟨127,164⟩]
theorem deny5_13 : Deny 5 13 ![⟨31,37⟩,⟨42,62⟩,⟨31,1920000000000000011376⟩,⟨3,1017986577181208059764⟩,⟨127,164⟩] := by
  have e25039 : Deny 5 13 b25039 := by
    apply closeAction rule_sound _ _ 64 [0x29e7ca7d6296283087088087df61030f78870c90c3e372778880c4088e37da21c37f8df61c4087e3724be082a31e3244,0xc38880c90c40f8dc4278de22070c31c3102238df61c91025f8dc3262108e375b70e22030c98881c30c70c31c72442c8,0xbe222d88a8c77df096583208107e020f80c92385832430f82481c20961c710b2442b858a0e2116de210bdc32430c9888,0x7e25b8dc40f8defb62108e2d88adc27a3109e2372f8c4709e1c8c98c8e1e88a7e22960f8]
    decide +kernel
  exact e25039
end OMA.Blocks5_13_245212.S25039
