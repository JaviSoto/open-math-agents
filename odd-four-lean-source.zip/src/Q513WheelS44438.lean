import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S44438
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b44438 : Box := ![⟨95,190⟩,⟨18,20⟩,⟨15,30⟩,⟨3,69⟩,⟨127,164⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨18,20⟩,⟨15,30⟩,⟨3,69⟩,⟨127,164⟩] := by
  have e44438 : Deny 5 13 b44438 := by
    apply closeAction rule_sound _ _ 64 [0x8c90f8df68c88c78c40820c8109e370f8dc38c98c80f8dc38c90e32231c42c3e270c70f89e0243e37da02202a32631c4,0x1c90c3e37276207115e37083e379a02389e0277578dc3e370c72770c32481c42ca0f8dc39e32438c70c3e378c98c80c3,0x109e370f8dc38c721fe370f8dc38c92030e32488c78c40820832481f710be15e370f8dc39e02202439831c80f70c70c3,0x9e31038c41f89e32678c42389c20f8de70e31e78c90f80e78c99e32231e31020820e7109e27207dc42f89e32670820c7,0x829e6804278dc2099]
    decide +kernel
  exact e44438
end OMA.Blocks5_13_245212.S44438
