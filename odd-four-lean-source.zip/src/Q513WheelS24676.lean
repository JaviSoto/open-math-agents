import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S24676
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b24676 : Box := ![⟨38,46⟩,⟨31,41⟩,⟨15,30⟩,⟨3,6⟩,⟨127,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨38,46⟩,⟨31,41⟩,⟨15,30⟩,⟨3,6⟩,⟨127,233⟩] := by
  have e24676 : Deny 5 13 b24676 := by
    apply closeAction rule_sound _ _ 64 [0x5ca7c22b8df6d47d847d75c3d871c45cb0c3e070f82431021f8d881ca5ca0c3e090c4087e37d880c4088e37d872442f8,0x1f5c3102238d841f8d8a]
    decide +kernel
  exact e24676
end OMA.Blocks5_13_245212.S24676
