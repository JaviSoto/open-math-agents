import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S17883
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b17883 : Box := ![⟨95,190⟩,⟨8,9⟩,⟨31,1920000000000000011376⟩,⟨1,1260487804878048787985⟩,⟨207,999999999999999999⟩]
private def b17884 : Box := ![⟨95,190⟩,⟨8,9⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029572⟩,⟨207,414⟩]
private def b17915 : Box := ![⟨95,190⟩,⟨8,9⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029572⟩,⟨415,999999999999999999⟩]
private def b17916 : Box := ![⟨95,190⟩,⟨8,9⟩,⟨31,62⟩,⟨1,764204851752021567923⟩,⟨415,999999999999999999⟩]
private def b18009 : Box := ![⟨95,190⟩,⟨8,9⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567923⟩,⟨415,999999999999999999⟩]
private def b18010 : Box := ![⟨95,190⟩,⟨8,8⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567923⟩,⟨415,999999999999999999⟩]
private def b18021 : Box := ![⟨95,190⟩,⟨9,9⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567923⟩,⟨415,999999999999999999⟩]
private def b18022 : Box := ![⟨95,126⟩,⟨9,9⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567923⟩,⟨415,999999999999999999⟩]
private def b18023 : Box := ![⟨95,126⟩,⟨9,9⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567911⟩,⟨415,830⟩]
private def b18034 : Box := ![⟨95,126⟩,⟨9,9⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567911⟩,⟨831,999999999999999999⟩]
private def b18035 : Box := ![⟨95,126⟩,⟨9,9⟩,⟨63,126⟩,⟨1,685382755842062856636⟩,⟨831,999999999999999999⟩]
private def b18136 : Box := ![⟨95,126⟩,⟨9,9⟩,⟨127,1920000000000000011376⟩,⟨1,685382755842062856636⟩,⟨831,999999999999999999⟩]
private def b18239 : Box := ![⟨127,190⟩,⟨9,9⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567923⟩,⟨415,999999999999999999⟩]
theorem deny5_11 : Deny 5 11 ![⟨95,190⟩,⟨8,9⟩,⟨31,1920000000000000011376⟩,⟨1,1260487804878048787985⟩,⟨207,999999999999999999⟩] := by
  have e17884 : Deny 5 11 b17884 := by
    apply closeAction rule_sound _ _ 64 [0x209d27872f749bdd2630af7555621e22a326310b8c78c8e1d75d54a28a8c95622952a3]
    decide +kernel
  have e17916 : Deny 5 11 b17916 := by
    apply closeAction rule_sound _ _ 64 [0x8c98d5e377552b89e32632dd555e09e362b8da375528be2354ae231dd54a54a778de78c9778df68c7e23087e37db4223,0x1e32632e31c20f88c9e030f88c98c70c22421e37678cb8c98dd9e32e309d9e32789e32e77555789e02782b88d52b88c7,0x82083e232788c7e23278083e232788c3e03e232788c7e15283e038c90f88c3e378c9e231e3263578dd5e370f80e3263]
    decide +kernel
  have e18010 : Deny 5 11 b18010 := by
    apply closeAction rule_sound _ _ 64 [0x72f749bdde2325de2325588a8d52b8]
    decide +kernel
  have e18023 : Deny 5 11 b18023 := by
    apply closeAction rule_sound _ _ 64 [0x2578ddd54ae152a35772e31e3263]
    decide +kernel
  have e18035 : Deny 5 11 b18035 := by
    apply closeAction rule_sound _ _ 64 [0x8c97552b88c78c98dd54a8cbe152830f88c9087da376f8cb087da376f8cb8ddbe32dd54ae232637552a32d5e222a31e3,0x54b54b54b54b54b29dbe22ddbe22d52d52d52d52ca8ddbe32e376f8cb8ddbe32e376f8cb8ddbe32f88c7e020f88c7e03,0x275d75d54b54b54b54b54b54b54b54b54b88a54b]
    decide +kernel
  have e18136 : Deny 5 11 b18136 := by
    apply closeAction rule_sound _ _ 64 [0x8dd2e374b8dd2e374b8dd2e374b8dd2e376f8cb8ddbe32e376f8cb8ddbe32e376f8cb8ddbe32e376f8cbe2f8c98c7e2f,0xc3d8725d2dd2dd2dd2dd2dd2dd2dd2dd2dd2dd2c21e22a374b8dd2e374b8dd2e374b8dd2e374b8dd2e374b8dd2e374b,0x8209ce3772f0ef7788c90878c98dd2e374b8dd2e31f8be32631f8bdc72f]
    decide +kernel
  have e18034 : Deny 5 11 b18034 :=
    branchAction rule_sound _ _ 2
      0x263 b18034 b18035 b18136 (by decide +kernel) e18035 e18136
  have e18022 : Deny 5 11 b18022 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18022 b18023 b18034 (by decide +kernel) e18023 e18034
  have e18239 : Deny 5 11 b18239 := by
    apply closeAction rule_sound _ _ 64 [0x820820820f88c7e232788c7e232788c7e23278]
    decide +kernel
  have e18021 : Deny 5 11 b18021 :=
    branchAction rule_sound _ _ 1
      0x7 b18021 b18022 b18239 (by decide +kernel) e18022 e18239
  have e18009 : Deny 5 11 b18009 :=
    branchAction rule_sound _ _ 1
      0x8 b18009 b18010 b18021 (by decide +kernel) e18010 e18021
  have e17915 : Deny 5 11 b17915 :=
    branchAction rule_sound _ _ 2
      0x263 b17915 b17916 b18009 (by decide +kernel) e17916 e18009
  have e17883 : Deny 5 11 b17883 :=
    branchAction rule_sound _ _ 2
      0x2e3 b17883 b17884 b17915 (by decide +kernel) e17884 e17915
  exact e17883
end OMA.Blocks5_11_245212.S17883
