import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S17512
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b17512 : Box := ![⟨31,46⟩,⟨15,20⟩,⟨15,30⟩,⟨3,1210212765957446815716⟩,⟨59,73⟩]
theorem deny5_13 : Deny 5 13 ![⟨31,46⟩,⟨15,20⟩,⟨15,30⟩,⟨3,1210212765957446815716⟩,⟨59,73⟩] := by
  have e17512 : Deny 5 13 b17512 := by
    apply closeAction rule_sound _ _ 64 [0xda31c3e37da31e311f0c38c98c810b0c3e37da31c40f8df68c41f88c80c3e37d870f8df61c40c4087e37d842382a31e3,0x8c80c31c32030f8df61c9103e370c7dc32030c72442c30f8df6237d840c3dc70c3e37d87dc910b103e37d8423820a0c3,0x1fddf8c90e321f0e32232631027c38c88c9dc42c30e31c30f8df68c78c90f8df68c88c40f70e31c38c80c38c78c910b]
    decide +kernel
  exact e17512
end OMA.Blocks5_13_245212.S17512
