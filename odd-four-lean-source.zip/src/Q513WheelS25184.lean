import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S25184
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b25184 : Box := ![⟨31,37⟩,⟨42,62⟩,⟨31,1920000000000000011376⟩,⟨3,1017986577181208059764⟩,⟨165,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨31,37⟩,⟨42,62⟩,⟨31,1920000000000000011376⟩,⟨3,1017986577181208059764⟩,⟨165,233⟩] := by
  have e25184 : Deny 5 13 b25184 := by
    apply closeAction rule_sound _ _ 64 [0x237d870c3e37d87087dc910be0829e7cade311f7d628a10b7f8de321fe378c97b8df68c711ee37da3108e378c78c98c4,0x2160c90c3e092030f8d88116e36107e0724a58a10b0c3e37203e372422021f7d840c32032430f8dc9de22037f8df61c2,0x2dfe22282bedb222a32231df7d60f80f81c3e090872160f8243e36204087e09296d8a11f5820c41f8103109e160f8207,0x1e324288a8c472f8c472f8c4278bde7e22a32567f8def88423888a10b72f782238daf8c9087da311cbdc25c8c97a2284,0x88888a58a88a8c98c47e25b8dd60ef88888788adc42dcbe311cbe3109e2f7e325fbed88a8c872f72f8c9bde7ca7b8df6,0x9cbe3109e2f7df583]
    decide +kernel
  exact e25184
end OMA.Blocks5_13_245212.S25184
