import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S6711
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b6711 : Box := ![⟨15,17⟩,⟨31,1920000000000000011376⟩,⟨13,1920000000000000011376⟩,⟨1,1920000000000000011376⟩,⟨53,73⟩]
theorem deny5_13 : Deny 5 13 ![⟨15,17⟩,⟨31,1920000000000000011376⟩,⟨13,1920000000000000011376⟩,⟨1,1920000000000000011376⟩,⟨53,73⟩] := by
  have e6711 : Deny 5 13 b6711 := by
    apply closeAction rule_sound _ _ 64 [0xe37db584a0a1284087e23256a84588e36d6229cbdc26f7a3242e37db5bed88a7b8df68c908711ce37da3108e37da3237,0x88d6124a29e1c42e32565b8df6d61278da229e737da3108e37db58c78c82daade689e36ae321e6b7d63109e36d6321e,0xdf58c95b8db5aa22b71de5a229cbde26f7890878c88c479688a7a25a22b70af7897897a22a31e32042de79e583788789,0x2a3102ade09e1ea84a8c810b8c9596aa126a88a796e36d622b7db5116dde0abaa12ab8c97962a32042daac47ab8c4238,0xbde25ce37da32021f8df68c85b6d622821f7db58c4082788e377895aa88a1de58a8c8102588dc42daada22b7a321eaa1,0x7962962a3116dc42deae325e58a8c87962b8df6d631daac47ab8c4238d6325e]
    decide +kernel
  exact e6711
end OMA.Blocks5_13_245212.S6711
