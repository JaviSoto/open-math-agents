import FastReplay245212
import SparseDigit245212
import FastRound245212
import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S24424
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b24424 : Box := ![⟨23,46⟩,⟨31,1920000000000000011376⟩,⟨7,14⟩,⟨1,1664000000000000009901⟩,⟨103,999999999999999999⟩]
private def b24425 : Box := ![⟨23,30⟩,⟨31,1920000000000000011376⟩,⟨7,14⟩,⟨1,669192982456140354881⟩,⟨103,999999999999999999⟩]
private def b24426 : Box := ![⟨23,30⟩,⟨31,1920000000000000011376⟩,⟨7,14⟩,⟨1,669192982456140354877⟩,⟨103,206⟩]
private def b24427 : Box := ![⟨23,30⟩,⟨31,62⟩,⟨7,14⟩,⟨1,669192982456140354869⟩,⟨103,199⟩]
private def b24428 : Box := ![⟨23,30⟩,⟨31,62⟩,⟨7,9⟩,⟨1,39⟩,⟨103,199⟩]
private def b24429 : Box := ![⟨23,26⟩,⟨31,62⟩,⟨7,9⟩,⟨1,36⟩,⟨103,199⟩]
private def b24430 : Box := ![⟨23,26⟩,⟨31,62⟩,⟨7,9⟩,⟨1,2⟩,⟨103,199⟩]
private def b24433 : Box := ![⟨23,26⟩,⟨31,62⟩,⟨7,9⟩,⟨3,35⟩,⟨103,199⟩]
private def b24434 : Box := ![⟨23,26⟩,⟨31,62⟩,⟨7,9⟩,⟨3,35⟩,⟨103,135⟩]
private def b24443 : Box := ![⟨23,26⟩,⟨31,62⟩,⟨7,9⟩,⟨3,35⟩,⟨136,199⟩]
private def b24452 : Box := ![⟨27,30⟩,⟨31,62⟩,⟨7,9⟩,⟨1,36⟩,⟨103,199⟩]
private def b24453 : Box := ![⟨27,30⟩,⟨31,62⟩,⟨7,9⟩,⟨1,36⟩,⟨103,135⟩]
private def b24462 : Box := ![⟨27,30⟩,⟨31,62⟩,⟨7,9⟩,⟨1,36⟩,⟨136,199⟩]
private def b24473 : Box := ![⟨23,30⟩,⟨31,62⟩,⟨10,14⟩,⟨1,39⟩,⟨103,199⟩]
private def b24474 : Box := ![⟨23,26⟩,⟨31,62⟩,⟨10,14⟩,⟨1,39⟩,⟨103,199⟩]
private def b24475 : Box := ![⟨23,26⟩,⟨31,62⟩,⟨10,14⟩,⟨1,2⟩,⟨103,199⟩]
private def b24476 : Box := ![⟨23,26⟩,⟨31,51⟩,⟨10,14⟩,⟨1,1⟩,⟨103,199⟩]
private def b24477 : Box := ![⟨23,26⟩,⟨31,51⟩,⟨10,14⟩,⟨2,2⟩,⟨103,199⟩]
private def b24478 : Box := ![⟨23,26⟩,⟨31,51⟩,⟨10,14⟩,⟨2,2⟩,⟨103,135⟩]
private def b24485 : Box := ![⟨23,26⟩,⟨31,51⟩,⟨10,14⟩,⟨2,2⟩,⟨136,199⟩]
private def b24494 : Box := ![⟨23,26⟩,⟨31,62⟩,⟨10,14⟩,⟨3,38⟩,⟨103,199⟩]
private def b24495 : Box := ![⟨23,26⟩,⟨31,62⟩,⟨10,14⟩,⟨3,38⟩,⟨104,136⟩]
private def b24502 : Box := ![⟨23,26⟩,⟨31,62⟩,⟨10,14⟩,⟨3,38⟩,⟨137,199⟩]
private def b24515 : Box := ![⟨27,30⟩,⟨31,62⟩,⟨10,14⟩,⟨1,39⟩,⟨103,199⟩]
private def b24520 : Box := ![⟨23,30⟩,⟨63,1920000000000000011376⟩,⟨7,14⟩,⟨1,669192982456140354869⟩,⟨103,199⟩]
private def b24535 : Box := ![⟨23,30⟩,⟨31,1920000000000000011376⟩,⟨7,14⟩,⟨1,669192982456140354877⟩,⟨207,999999999999999999⟩]
private def b24536 : Box := ![⟨23,30⟩,⟨31,62⟩,⟨7,14⟩,⟨1,581463414634146344939⟩,⟨207,999999999999999999⟩]
private def b24537 : Box := ![⟨23,30⟩,⟨31,62⟩,⟨7,9⟩,⟨1,40⟩,⟨207,999999999999999999⟩]
private def b24538 : Box := ![⟨23,30⟩,⟨31,62⟩,⟨7,9⟩,⟨1,38⟩,⟨207,414⟩]
private def b24539 : Box := ![⟨23,26⟩,⟨31,62⟩,⟨7,9⟩,⟨1,32⟩,⟨207,414⟩]
private def b24548 : Box := ![⟨27,30⟩,⟨31,62⟩,⟨7,9⟩,⟨1,32⟩,⟨207,414⟩]
private def b24557 : Box := ![⟨23,30⟩,⟨31,62⟩,⟨7,9⟩,⟨1,38⟩,⟨415,999999999999999999⟩]
private def b24568 : Box := ![⟨23,30⟩,⟨31,62⟩,⟨10,14⟩,⟨1,40⟩,⟨207,999999999999999999⟩]
private def b24569 : Box := ![⟨23,30⟩,⟨31,62⟩,⟨10,14⟩,⟨1,40⟩,⟨207,414⟩]
private def b24570 : Box := ![⟨23,26⟩,⟨31,62⟩,⟨10,14⟩,⟨1,34⟩,⟨207,414⟩]
private def b24585 : Box := ![⟨27,30⟩,⟨31,62⟩,⟨10,14⟩,⟨1,34⟩,⟨207,414⟩]
private def b24596 : Box := ![⟨23,30⟩,⟨31,62⟩,⟨10,14⟩,⟨1,40⟩,⟨415,999999999999999999⟩]
private def b24597 : Box := ![⟨23,26⟩,⟨31,62⟩,⟨10,14⟩,⟨1,36⟩,⟨415,999999999999999999⟩]
private def b24612 : Box := ![⟨27,30⟩,⟨31,62⟩,⟨10,14⟩,⟨1,36⟩,⟨415,999999999999999999⟩]
private def b24627 : Box := ![⟨23,30⟩,⟨63,1920000000000000011376⟩,⟨7,14⟩,⟨1,581463414634146344939⟩,⟨207,999999999999999999⟩]
private def b24628 : Box := ![⟨23,30⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨1,581463414634146344939⟩,⟨207,999999999999999999⟩]
private def b24629 : Box := ![⟨23,30⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨1,581463414634146344936⟩,⟨207,414⟩]
private def b24630 : Box := ![⟨23,30⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨1,2⟩,⟨207,414⟩]
private def b24631 : Box := ![⟨23,30⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨3,581463414634146344930⟩,⟨207,414⟩]
private def b24632 : Box := ![⟨23,30⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨3,6⟩,⟨207,414⟩]
private def b24633 : Box := ![⟨23,30⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨7,581463414634146344930⟩,⟨207,414⟩]
private def b24634 : Box := ![⟨23,26⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨7,581463414634146344930⟩,⟨207,414⟩]
private def b24635 : Box := ![⟨23,26⟩,⟨63,126⟩,⟨7,9⟩,⟨7,581463414634146344929⟩,⟨207,414⟩]
private def b24650 : Box := ![⟨23,26⟩,⟨127,1920000000000000011376⟩,⟨7,9⟩,⟨7,581463414634146344929⟩,⟨207,414⟩]
private def b24653 : Box := ![⟨27,30⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨7,581463414634146344930⟩,⟨207,414⟩]
private def b24664 : Box := ![⟨23,30⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨1,581463414634146344936⟩,⟨415,999999999999999999⟩]
private def b24665 : Box := ![⟨23,26⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨1,514070080862533695793⟩,⟨415,999999999999999999⟩]
private def b24666 : Box := ![⟨23,26⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨1,2⟩,⟨415,999999999999999999⟩]
private def b24667 : Box := ![⟨23,26⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨3,514070080862533695792⟩,⟨415,999999999999999999⟩]
private def b24668 : Box := ![⟨23,26⟩,⟨63,126⟩,⟨7,9⟩,⟨3,514070080862533695792⟩,⟨415,999999999999999999⟩]
private def b24683 : Box := ![⟨23,26⟩,⟨127,1920000000000000011376⟩,⟨7,9⟩,⟨3,514070080862533695792⟩,⟨415,999999999999999999⟩]
private def b24684 : Box := ![⟨23,26⟩,⟨127,1920000000000000011376⟩,⟨7,7⟩,⟨3,514070080862533695792⟩,⟨415,999999999999999999⟩]
private def b24687 : Box := ![⟨23,26⟩,⟨127,1920000000000000011376⟩,⟨8,9⟩,⟨3,514070080862533695792⟩,⟨415,999999999999999999⟩]
private def b24688 : Box := ![⟨23,26⟩,⟨127,1920000000000000011376⟩,⟨8,9⟩,⟨3,514070080862533695792⟩,⟨415,830⟩]
private def b24691 : Box := ![⟨23,26⟩,⟨127,1920000000000000011376⟩,⟨8,9⟩,⟨3,514070080862533695792⟩,⟨831,999999999999999999⟩]
private def b24692 : Box := ![⟨23,24⟩,⟨127,1920000000000000011376⟩,⟨8,9⟩,⟨3,461047542304593072858⟩,⟨831,999999999999999999⟩]
private def b24707 : Box := ![⟨25,26⟩,⟨127,1920000000000000011376⟩,⟨8,9⟩,⟨3,461047542304593072858⟩,⟨831,999999999999999999⟩]
private def b24708 : Box := ![⟨25,26⟩,⟨127,254⟩,⟨8,9⟩,⟨3,461047542304593072858⟩,⟨831,999999999999999999⟩]
private def b24723 : Box := ![⟨25,26⟩,⟨255,1920000000000000011376⟩,⟨8,9⟩,⟨3,461047542304593072858⟩,⟨831,999999999999999999⟩]
private def b24724 : Box := ![⟨25,26⟩,⟨255,1920000000000000011376⟩,⟨8,8⟩,⟨8,461047542304593072858⟩,⟨1116,999999999999999999⟩]
private def b24725 : Box := ![⟨25,26⟩,⟨255,1920000000000000011376⟩,⟨8,8⟩,⟨8,441822393822393825032⟩,⟨1116,2232⟩]
private def b24726 : Box := ![⟨25,26⟩,⟨255,1920000000000000011376⟩,⟨8,8⟩,⟨8,441822393822393825032⟩,⟨2233,999999999999999999⟩]
private def b24727 : Box := ![⟨25,26⟩,⟨255,1920000000000000011376⟩,⟨8,8⟩,⟨8,402080112438510192140⟩,⟨2233,4466⟩]
private def b24728 : Box := ![⟨25,26⟩,⟨255,1920000000000000011376⟩,⟨8,8⟩,⟨8,402080112438510192140⟩,⟨4467,999999999999999999⟩]
private def b24743 : Box := ![⟨25,26⟩,⟨255,1920000000000000011376⟩,⟨9,9⟩,⟨8,461047542304593072858⟩,⟨1116,999999999999999999⟩]
private def b24744 : Box := ![⟨27,30⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨1,514070080862533695793⟩,⟨415,999999999999999999⟩]
private def b24745 : Box := ![⟨27,30⟩,⟨63,126⟩,⟨7,9⟩,⟨1,514070080862533695793⟩,⟨415,999999999999999999⟩]
private def b24746 : Box := ![⟨27,30⟩,⟨63,126⟩,⟨7,7⟩,⟨1,51⟩,⟨415,999999999999999999⟩]
private def b24753 : Box := ![⟨27,30⟩,⟨63,126⟩,⟨8,9⟩,⟨1,51⟩,⟨415,999999999999999999⟩]
private def b24754 : Box := ![⟨27,30⟩,⟨63,126⟩,⟨8,9⟩,⟨1,51⟩,⟨415,830⟩]
private def b24763 : Box := ![⟨27,30⟩,⟨63,126⟩,⟨8,9⟩,⟨1,51⟩,⟨831,999999999999999999⟩]
private def b24774 : Box := ![⟨27,30⟩,⟨127,1920000000000000011376⟩,⟨7,9⟩,⟨1,514070080862533695793⟩,⟨415,999999999999999999⟩]
private def b24775 : Box := ![⟨27,30⟩,⟨127,1920000000000000011376⟩,⟨7,7⟩,⟨3,514070080862533695793⟩,⟨421,999999999999999999⟩]
private def b24776 : Box := ![⟨27,30⟩,⟨127,1920000000000000011376⟩,⟨7,7⟩,⟨3,513147982062780272122⟩,⟨421,842⟩]
private def b24779 : Box := ![⟨27,30⟩,⟨127,1920000000000000011376⟩,⟨7,7⟩,⟨3,513147982062780272122⟩,⟨843,999999999999999999⟩]
private def b24780 : Box := ![⟨27,30⟩,⟨127,254⟩,⟨7,7⟩,⟨3,459935691318327977023⟩,⟨843,999999999999999999⟩]
private def b24781 : Box := ![⟨27,30⟩,⟨127,254⟩,⟨7,7⟩,⟨4,76⟩,⟨843,1686⟩]
private def b24782 : Box := ![⟨27,30⟩,⟨127,254⟩,⟨7,7⟩,⟨4,76⟩,⟨1687,999999999999999999⟩]
private def b24783 : Box := ![⟨27,30⟩,⟨127,254⟩,⟨7,7⟩,⟨4,68⟩,⟨1687,3374⟩]
private def b24784 : Box := ![⟨27,30⟩,⟨127,254⟩,⟨7,7⟩,⟨4,68⟩,⟨3375,999999999999999999⟩]
private def b24785 : Box := ![⟨27,30⟩,⟨127,254⟩,⟨7,7⟩,⟨4,63⟩,⟨3375,6750⟩]
private def b24786 : Box := ![⟨27,30⟩,⟨127,254⟩,⟨7,7⟩,⟨4,63⟩,⟨6751,999999999999999999⟩]
private def b24787 : Box := ![⟨27,28⟩,⟨127,254⟩,⟨7,7⟩,⟨4,58⟩,⟨6751,999999999999999999⟩]
private def b24788 : Box := ![⟨29,30⟩,⟨127,254⟩,⟨7,7⟩,⟨4,58⟩,⟨6751,999999999999999999⟩]
private def b24789 : Box := ![⟨29,30⟩,⟨127,254⟩,⟨7,7⟩,⟨4,58⟩,⟨6751,13502⟩]
private def b24790 : Box := ![⟨29,30⟩,⟨127,254⟩,⟨7,7⟩,⟨4,58⟩,⟨13503,999999999999999999⟩]
private def b24791 : Box := ![⟨29,30⟩,⟨127,254⟩,⟨7,7⟩,⟨4,53⟩,⟨13503,27006⟩]
private def b24792 : Box := ![⟨29,30⟩,⟨127,254⟩,⟨7,7⟩,⟨4,53⟩,⟨27007,999999999999999999⟩]
private def b24807 : Box := ![⟨27,30⟩,⟨255,1920000000000000011376⟩,⟨7,7⟩,⟨3,459935691318327977023⟩,⟨843,999999999999999999⟩]
private def b24808 : Box := ![⟨27,28⟩,⟨255,1920000000000000011376⟩,⟨7,7⟩,⟨8,459935691318327977023⟩,⟨1107,999999999999999999⟩]
private def b24809 : Box := ![⟨27,28⟩,⟨255,1920000000000000011376⟩,⟨7,7⟩,⟨8,442163833075734160290⟩,⟨1107,2214⟩]
private def b24810 : Box := ![⟨27,28⟩,⟨255,1920000000000000011376⟩,⟨7,7⟩,⟨8,442163833075734160290⟩,⟨2215,999999999999999999⟩]
private def b24811 : Box := ![⟨27,28⟩,⟨255,1920000000000000011376⟩,⟨7,7⟩,⟨8,402362869198312238689⟩,⟨2215,4430⟩]
private def b24812 : Box := ![⟨27,28⟩,⟨255,1920000000000000011376⟩,⟨7,7⟩,⟨8,402362869198312238689⟩,⟨4431,999999999999999999⟩]
private def b24827 : Box := ![⟨29,30⟩,⟨255,1920000000000000011376⟩,⟨7,7⟩,⟨8,459935691318327977023⟩,⟨1107,999999999999999999⟩]
private def b24828 : Box := ![⟨27,30⟩,⟨127,1920000000000000011376⟩,⟨8,9⟩,⟨3,514070080862533695793⟩,⟨421,999999999999999999⟩]
private def b24837 : Box := ![⟨23,30⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨1,581463414634146344939⟩,⟨207,999999999999999999⟩]
private def b24838 : Box := ![⟨23,30⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨1,581463414634146344939⟩,⟨207,414⟩]
private def b24851 : Box := ![⟨23,30⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨1,581463414634146344939⟩,⟨415,999999999999999999⟩]
private def b24852 : Box := ![⟨23,26⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨1,514070080862533695795⟩,⟨415,999999999999999999⟩]
private def b24853 : Box := ![⟨23,26⟩,⟨63,126⟩,⟨10,14⟩,⟨1,514070080862533695794⟩,⟨415,999999999999999999⟩]
private def b24854 : Box := ![⟨23,26⟩,⟨63,126⟩,⟨10,11⟩,⟨1,52⟩,⟨415,999999999999999999⟩]
private def b24855 : Box := ![⟨23,26⟩,⟨63,126⟩,⟨10,11⟩,⟨1,51⟩,⟨415,830⟩]
private def b24864 : Box := ![⟨23,26⟩,⟨63,126⟩,⟨10,11⟩,⟨1,51⟩,⟨831,999999999999999999⟩]
private def b24877 : Box := ![⟨23,26⟩,⟨63,126⟩,⟨12,14⟩,⟨1,52⟩,⟨415,999999999999999999⟩]
private def b24878 : Box := ![⟨23,26⟩,⟨63,126⟩,⟨12,14⟩,⟨1,52⟩,⟨415,830⟩]
private def b24885 : Box := ![⟨23,26⟩,⟨63,126⟩,⟨12,14⟩,⟨1,52⟩,⟨831,999999999999999999⟩]
private def b24900 : Box := ![⟨23,26⟩,⟨127,1920000000000000011376⟩,⟨10,14⟩,⟨1,514070080862533695794⟩,⟨415,999999999999999999⟩]
private def b24901 : Box := ![⟨23,26⟩,⟨127,1920000000000000011376⟩,⟨10,11⟩,⟨3,514070080862533695794⟩,⟨548,999999999999999999⟩]
private def b24902 : Box := ![⟨23,24⟩,⟨127,1920000000000000011376⟩,⟨10,11⟩,⟨3,491546391752577322524⟩,⟨548,999999999999999999⟩]
private def b24903 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨3,491546391752577322523⟩,⟨548,999999999999999999⟩]
private def b24904 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨4,81⟩,⟨586,1172⟩]
private def b24905 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨4,81⟩,⟨1173,999999999999999999⟩]
private def b24906 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨4,72⟩,⟨1173,2346⟩]
private def b24907 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨4,72⟩,⟨2347,999999999999999999⟩]
private def b24908 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨4,66⟩,⟨2347,4694⟩]
private def b24909 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨4,66⟩,⟨4695,999999999999999999⟩]
private def b24910 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨4,60⟩,⟨4695,9390⟩]
private def b24911 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨4,60⟩,⟨9391,999999999999999999⟩]
private def b24912 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨4,56⟩,⟨9391,18782⟩]
private def b24913 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨4,56⟩,⟨18783,999999999999999999⟩]
private def b24914 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨4,52⟩,⟨18783,37566⟩]
private def b24915 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨4,52⟩,⟨37567,999999999999999999⟩]
private def b24916 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨4,48⟩,⟨37567,75134⟩]
private def b24917 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨4,48⟩,⟨75135,999999999999999999⟩]
private def b24918 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨4,45⟩,⟨75135,150270⟩]
private def b24919 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨4,45⟩,⟨150271,999999999999999999⟩]
private def b24920 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨4,43⟩,⟨150271,300542⟩]
private def b24921 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨4,43⟩,⟨300543,999999999999999999⟩]
private def b24922 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨4,40⟩,⟨300543,601086⟩]
private def b24923 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨4,40⟩,⟨601087,999999999999999999⟩]
private def b24924 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨4,38⟩,⟨601087,1202174⟩]
private def b24925 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨4,38⟩,⟨1202175,999999999999999999⟩]
private def b24926 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨4,7⟩,⟨1202175,999999999999999999⟩]
private def b24927 : Box := ![⟨23,24⟩,⟨127,219⟩,⟨10,11⟩,⟨4,7⟩,⟨1202175,2404350⟩]
private def b24928 : Box := ![⟨23,24⟩,⟨127,219⟩,⟨10,11⟩,⟨4,7⟩,⟨2404351,999999999999999999⟩]
private def b24929 : Box := ![⟨23,24⟩,⟨127,219⟩,⟨10,11⟩,⟨4,7⟩,⟨2404351,4808702⟩]
private def b24930 : Box := ![⟨23,24⟩,⟨127,219⟩,⟨10,11⟩,⟨4,7⟩,⟨4808703,999999999999999999⟩]
private def b24945 : Box := ![⟨23,24⟩,⟨127,254⟩,⟨10,11⟩,⟨8,36⟩,⟨1202175,999999999999999999⟩]
private def b24946 : Box := ![⟨23,24⟩,⟨255,1920000000000000011376⟩,⟨10,11⟩,⟨3,491546391752577322523⟩,⟨548,999999999999999999⟩]
private def b24959 : Box := ![⟨25,26⟩,⟨127,1920000000000000011376⟩,⟨10,11⟩,⟨3,491546391752577322524⟩,⟨548,999999999999999999⟩]
private def b24960 : Box := ![⟨23,26⟩,⟨127,1920000000000000011376⟩,⟨12,14⟩,⟨3,514070080862533695794⟩,⟨548,999999999999999999⟩]
private def b24961 : Box := ![⟨27,30⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨1,514070080862533695795⟩,⟨415,999999999999999999⟩]
private def b24970 : Box := ![⟨31,46⟩,⟨31,1920000000000000011376⟩,⟨7,14⟩,⟨1,669192982456140354881⟩,⟨103,999999999999999999⟩]
private def b24971 : Box := ![⟨31,46⟩,⟨31,1920000000000000011376⟩,⟨7,14⟩,⟨1,669192982456140354881⟩,⟨103,206⟩]
private def b24972 : Box := ![⟨31,46⟩,⟨31,62⟩,⟨7,14⟩,⟨1,669192982456140354873⟩,⟨103,199⟩]
private def b24973 : Box := ![⟨31,46⟩,⟨31,62⟩,⟨7,9⟩,⟨1,43⟩,⟨103,199⟩]
private def b24974 : Box := ![⟨31,37⟩,⟨31,62⟩,⟨7,9⟩,⟨1,40⟩,⟨103,199⟩]
private def b24975 : Box := ![⟨31,37⟩,⟨31,62⟩,⟨7,9⟩,⟨1,2⟩,⟨103,199⟩]
private def b24988 : Box := ![⟨31,37⟩,⟨31,62⟩,⟨7,9⟩,⟨3,38⟩,⟨103,199⟩]
private def b24995 : Box := ![⟨38,46⟩,⟨31,62⟩,⟨7,9⟩,⟨1,40⟩,⟨103,199⟩]
private def b24996 : Box := ![⟨31,46⟩,⟨31,62⟩,⟨10,14⟩,⟨1,43⟩,⟨103,199⟩]
private def b24997 : Box := ![⟨31,46⟩,⟨63,1920000000000000011376⟩,⟨7,14⟩,⟨1,669192982456140354873⟩,⟨103,199⟩]
private def b24998 : Box := ![⟨31,46⟩,⟨31,1920000000000000011376⟩,⟨7,14⟩,⟨1,669192982456140354881⟩,⟨207,999999999999999999⟩]
private def b24999 : Box := ![⟨31,46⟩,⟨31,62⟩,⟨7,14⟩,⟨1,581463414634146344942⟩,⟨207,999999999999999999⟩]
private def b25000 : Box := ![⟨31,46⟩,⟨31,62⟩,⟨7,9⟩,⟨1,44⟩,⟨207,999999999999999999⟩]
private def b25001 : Box := ![⟨31,37⟩,⟨31,62⟩,⟨7,9⟩,⟨1,42⟩,⟨207,999999999999999999⟩]
private def b25002 : Box := ![⟨31,37⟩,⟨31,62⟩,⟨7,9⟩,⟨1,40⟩,⟨207,414⟩]
private def b25015 : Box := ![⟨31,37⟩,⟨31,62⟩,⟨7,9⟩,⟨1,40⟩,⟨415,999999999999999999⟩]
private def b25016 : Box := ![⟨31,37⟩,⟨31,41⟩,⟨7,9⟩,⟨1,35⟩,⟨415,999999999999999999⟩]
private def b25021 : Box := ![⟨31,37⟩,⟨42,62⟩,⟨7,9⟩,⟨1,35⟩,⟨415,999999999999999999⟩]
private def b25032 : Box := ![⟨38,46⟩,⟨31,62⟩,⟨7,9⟩,⟨1,42⟩,⟨207,999999999999999999⟩]
private def b25033 : Box := ![⟨38,46⟩,⟨31,62⟩,⟨7,9⟩,⟨1,42⟩,⟨207,414⟩]
private def b25038 : Box := ![⟨38,46⟩,⟨31,62⟩,⟨7,9⟩,⟨1,42⟩,⟨415,999999999999999999⟩]
private def b25049 : Box := ![⟨31,46⟩,⟨31,62⟩,⟨10,14⟩,⟨1,44⟩,⟨207,999999999999999999⟩]
private def b25050 : Box := ![⟨31,37⟩,⟨31,62⟩,⟨10,14⟩,⟨1,44⟩,⟨258,999999999999999999⟩]
private def b25065 : Box := ![⟨38,46⟩,⟨31,62⟩,⟨10,14⟩,⟨1,44⟩,⟨258,999999999999999999⟩]
private def b25066 : Box := ![⟨31,46⟩,⟨63,1920000000000000011376⟩,⟨7,14⟩,⟨1,581463414634146344942⟩,⟨207,999999999999999999⟩]
private def b25067 : Box := ![⟨31,46⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨1,581463414634146344942⟩,⟨341,999999999999999999⟩]
private def b25068 : Box := ![⟨31,37⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨1,531747211895910783848⟩,⟨341,999999999999999999⟩]
private def b25069 : Box := ![⟨31,37⟩,⟨63,126⟩,⟨7,9⟩,⟨1,531747211895910783846⟩,⟨341,999999999999999999⟩]
private def b25070 : Box := ![⟨31,37⟩,⟨63,126⟩,⟨7,9⟩,⟨1,54⟩,⟨343,686⟩]
private def b25077 : Box := ![⟨31,37⟩,⟨63,126⟩,⟨7,9⟩,⟨1,54⟩,⟨687,999999999999999999⟩]
private def b25078 : Box := ![⟨31,37⟩,⟨63,126⟩,⟨7,7⟩,⟨1,48⟩,⟨687,999999999999999999⟩]
private def b25087 : Box := ![⟨31,37⟩,⟨63,126⟩,⟨8,9⟩,⟨1,48⟩,⟨687,999999999999999999⟩]
private def b25094 : Box := ![⟨31,37⟩,⟨127,1920000000000000011376⟩,⟨7,9⟩,⟨1,531747211895910783846⟩,⟨341,999999999999999999⟩]
private def b25095 : Box := ![⟨38,46⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨1,531747211895910783848⟩,⟨341,999999999999999999⟩]
private def b25096 : Box := ![⟨31,46⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨1,581463414634146344942⟩,⟨341,999999999999999999⟩]
theorem deny5_11 : Deny 5 11 ![⟨23,46⟩,⟨31,1920000000000000011376⟩,⟨7,14⟩,⟨1,1664000000000000009901⟩,⟨103,999999999999999999⟩] := by
  have e24430 : Deny 5 11 b24430 := by
    apply closeAction rule_sound _ _ 64 [0x3103e37da1107e21]
    decide +kernel
  have e24434 : Deny 5 11 b24434 := by
    apply closeAction rule_sound _ _ 64 [0x831f70e32430e3263204]
    decide +kernel
  have e24443 : Deny 5 11 b24443 := by
    apply closeAction rule_sound _ _ 64 [0xc31c38c90c3e378c98c88c4]
    decide +kernel
  have e24433 : Deny 5 11 b24433 :=
    branchAction rule_sound _ _ 1
      0xb b24433 b24434 b24443 (by decide +kernel) e24434 e24443
  have e24429 : Deny 5 11 b24429 :=
    branchAction rule_sound _ _ 2
      0x2a3 b24429 b24430 b24433 (by decide +kernel) e24430 e24433
  have e24453 : Deny 5 11 b24453 := by
    apply closeAction rule_sound _ _ 64 [0x83e370e32632030e11e1284]
    decide +kernel
  have e24462 : Deny 5 11 b24462 := by
    apply closeAction rule_sound _ _ 64 [0x20c4238dc38c90e12830f78c98c88c4]
    decide +kernel
  have e24452 : Deny 5 11 b24452 :=
    branchAction rule_sound _ _ 1
      0xb b24452 b24453 b24462 (by decide +kernel) e24453 e24462
  have e24428 : Deny 5 11 b24428 :=
    branchAction rule_sound _ _ 2
      0x1e3 b24428 b24429 b24452 (by decide +kernel) e24429 e24452
  have e24476 : Deny 5 11 b24476 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
  have e24478 : Deny 5 11 b24478 := by
    apply closeAction rule_sound _ _ 64 [0x20e1109e03e03248844]
    decide +kernel
  have e24485 : Deny 5 11 b24485 := by
    apply closeAction rule_sound _ _ 64 [0x20e11f80e12430c9204]
    decide +kernel
  have e24477 : Deny 5 11 b24477 :=
    branchAction rule_sound _ _ 1
      0xb b24477 b24478 b24485 (by decide +kernel) e24478 e24485
  have e24475 : Deny 5 11 b24475 :=
    branchAction rule_sound _ _ 2
      0x2a1 b24475 b24476 b24477 (by decide +kernel) e24476 e24477
  have e24495 : Deny 5 11 b24495 := by
    apply closeAction rule_sound _ _ 64 [0x820f8dc32472378c4]
    decide +kernel
  have e24502 : Deny 5 11 b24502 := by
    apply closeAction rule_sound _ _ 64 [0x820c4238dc38c98c41f80f8dc38c70e3263223]
    decide +kernel
  have e24494 : Deny 5 11 b24494 :=
    branchAction rule_sound _ _ 2
      0x2f8 b24494 b24495 b24502 (by decide +kernel) e24495 e24502
  have e24474 : Deny 5 11 b24474 :=
    branchAction rule_sound _ _ 2
      0x2a3 b24474 b24475 b24494 (by decide +kernel) e24475 e24494
  have e24515 : Deny 5 11 b24515 := by
    apply closeAction rule_sound _ _ 64 [0x97e370c9108e37]
    decide +kernel
  have e24473 : Deny 5 11 b24473 :=
    branchAction rule_sound _ _ 1
      0x7 b24473 b24474 b24515 (by decide +kernel) e24474 e24515
  have e24427 : Deny 5 11 b24427 :=
    branchAction rule_sound _ _ 2
      0x263 b24427 b24428 b24473 (by decide +kernel) e24428 e24473
  have e24520 : Deny 5 11 b24520 := by
    apply closeAction rule_sound _ _ 64 [0x4b8dc24b8deb6ab8c20e3107e03e2b8c98c8e2b8c88c41f848a8c9]
    decide +kernel
  have e24426 : Deny 5 11 b24426 :=
    branchAction rule_sound _ _ 3
      0x88c4 b24426 b24427 b24520 (by decide +kernel) e24427 e24520
  have e24539 : Deny 5 11 b24539 := by
    apply closeAction rule_sound _ _ 64 [0x30f88c70f8df58c90f8df68c80a12a3]
    decide +kernel
  have e24548 : Deny 5 11 b24548 := by
    apply closeAction rule_sound _ _ 64 [0xf8ac38c80eb8c90c3e378c98c8]
    decide +kernel
  have e24538 : Deny 5 11 b24538 :=
    branchAction rule_sound _ _ 2
      0x1e3 b24538 b24539 b24548 (by decide +kernel) e24539 e24548
  have e24557 : Deny 5 11 b24557 := by
    apply closeAction rule_sound _ _ 64 [0xc3e23203e37d63243e37da3203e37d631021f8df6d631e3]
    decide +kernel
  have e24537 : Deny 5 11 b24537 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24537 b24538 b24557 (by decide +kernel) e24538 e24557
  have e24570 : Deny 5 11 b24570 := by
    apply closeAction rule_sound _ _ 64 [0xf8dc31c38c90c38c78c90c38c70e3263223]
    decide +kernel
  have e24585 : Deny 5 11 b24585 := by
    apply closeAction rule_sound _ _ 64 [0x2083238278dc3e370e32038c98c8]
    decide +kernel
  have e24569 : Deny 5 11 b24569 :=
    branchAction rule_sound _ _ 2
      0x1e3 b24569 b24570 b24585 (by decide +kernel) e24570 e24585
  have e24597 : Deny 5 11 b24597 := by
    apply closeAction rule_sound _ _ 64 [0xc3e070e3243e230f8df58c7e23243e03e37db58c7e230f8df58c9e23223]
    decide +kernel
  have e24612 : Deny 5 11 b24612 := by
    apply closeAction rule_sound _ _ 64 [0x2083e07e232380f80e32232430e32038c98c8]
    decide +kernel
  have e24596 : Deny 5 11 b24596 :=
    branchAction rule_sound _ _ 2
      0x1e3 b24596 b24597 b24612 (by decide +kernel) e24597 e24612
  have e24568 : Deny 5 11 b24568 :=
    branchAction rule_sound _ _ 1
      0xb b24568 b24569 b24596 (by decide +kernel) e24569 e24596
  have e24536 : Deny 5 11 b24536 :=
    branchAction rule_sound _ _ 2
      0x263 b24536 b24537 b24568 (by decide +kernel) e24537 e24568
  have e24630 : Deny 5 11 b24630 := by
    apply closeAction rule_sound _ _ 64 [0x12]
    decide +kernel
  have e24632 : Deny 5 11 b24632 := by
    apply closeAction rule_sound _ _ 64 [0x61]
    decide +kernel
  have e24635 : Deny 5 11 b24635 := by
    apply closeAction rule_sound _ _ 64 [0x1aac30f81e32236ab0f80c7ae32042daac3e23238ae3263]
    decide +kernel
  have e24650 : Deny 5 11 b24650 := by
    apply closeAction rule_sound _ _ 64 [0x1aada22b]
    decide +kernel
  have e24634 : Deny 5 11 b24634 :=
    branchAction rule_sound _ _ 2
      0x223 b24634 b24635 b24650 (by decide +kernel) e24635 e24650
  have e24653 : Deny 5 11 b24653 := by
    apply closeAction rule_sound _ _ 64 [0x820831f7108e376ab0e3223263238]
    decide +kernel
  have e24633 : Deny 5 11 b24633 :=
    branchAction rule_sound _ _ 1
      0x7 b24633 b24634 b24653 (by decide +kernel) e24634 e24653
  have e24631 : Deny 5 11 b24631 :=
    branchAction rule_sound _ _ 1
      0xa b24631 b24632 b24633 (by decide +kernel) e24632 e24633
  have e24629 : Deny 5 11 b24629 :=
    branchAction rule_sound _ _ 2
      0x2a3 b24629 b24630 b24631 (by decide +kernel) e24630 e24631
  have e24666 : Deny 5 11 b24666 := by
    apply closeAction rule_sound _ _ 64 [0x12e36ae1]
    decide +kernel
  have e24668 : Deny 5 11 b24668 := by
    apply closeAction rule_sound _ _ 64 [0xc3e37d490f88c80878daac30878c8ae32c2263]
    decide +kernel
  have e24684 : Deny 5 11 b24684 := by
    apply closeAction rule_sound _ _ 64 [0x1aae36ab8c8e23]
    decide +kernel
  have e24688 : Deny 5 11 b24688 := by
    apply closeAction rule_sound _ _ 64 [0x6ab688ae3]
    decide +kernel
  have e24692 : Deny 5 11 b24692 := by
    apply closeAction rule_sound _ _ 64 [0x26b8d47ada8c80898daae32dae23212e21292e35ae12a3]
    decide +kernel
  have e24708 : Deny 5 11 b24708 := by
    apply closeAction rule_sound _ _ 64 [0x83e2b0f8ae32358c7df58c98daae32e36ab8cb8daae32e36ab8cbae3]
    decide +kernel
  have e24725 : Deny 5 11 b24725 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e24727 : Deny 5 11 b24727 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e24728 : Deny 5 11 b24728 := by
    apply closeAction rule_sound _ _ 64 [0x209aae32351eb0838c8087ae32236ab8cb8daae32e3]
    decide +kernel
  have e24726 : Deny 5 11 b24726 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24726 b24727 b24728 (by decide +kernel) e24727 e24728
  have e24724 : Deny 5 11 b24724 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24724 b24725 b24726 (by decide +kernel) e24725 e24726
  have e24743 : Deny 5 11 b24743 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e24723 : Deny 5 11 b24723 :=
    branchAction rule_sound _ _ 3
      0x9e2b b24723 b24724 b24743 (by decide +kernel) e24724 e24743
  have e24707 : Deny 5 11 b24707 :=
    branchAction rule_sound _ _ 1
      0x8 b24707 b24708 b24723 (by decide +kernel) e24708 e24723
  have e24691 : Deny 5 11 b24691 :=
    branchAction rule_sound _ _ 2
      0x1e3 b24691 b24692 b24707 (by decide +kernel) e24692 e24707
  have e24687 : Deny 5 11 b24687 :=
    branchAction rule_sound _ _ 1
      0xb b24687 b24688 b24691 (by decide +kernel) e24688 e24691
  have e24683 : Deny 5 11 b24683 :=
    branchAction rule_sound _ _ 1
      0x9 b24683 b24684 b24687 (by decide +kernel) e24684 e24687
  have e24667 : Deny 5 11 b24667 :=
    branchAction rule_sound _ _ 1
      0x8 b24667 b24668 b24683 (by decide +kernel) e24668 e24683
  have e24665 : Deny 5 11 b24665 :=
    branchAction rule_sound _ _ 2
      0x2a3 b24665 b24666 b24667 (by decide +kernel) e24666 e24667
  have e24746 : Deny 5 11 b24746 := by
    apply closeAction rule_sound _ _ 64 [0xf80f81f8ac3e23238ae348ae23]
    decide +kernel
  have e24754 : Deny 5 11 b24754 := by
    apply closeAction rule_sound _ _ 64 [0x826898c7e2b0f8dc38c78c8ae3]
    decide +kernel
  have e24763 : Deny 5 11 b24763 := by
    apply closeAction rule_sound _ _ 64 [0x20f88c9e03e032631eb0c31e3223]
    decide +kernel
  have e24753 : Deny 5 11 b24753 :=
    branchAction rule_sound _ _ 1
      0xb b24753 b24754 b24763 (by decide +kernel) e24754 e24763
  have e24745 : Deny 5 11 b24745 :=
    branchAction rule_sound _ _ 2
      0x263 b24745 b24746 b24753 (by decide +kernel) e24746 e24753
  have e24776 : Deny 5 11 b24776 := by
    apply closeAction rule_sound _ _ 64 [0x9a238ae3]
    decide +kernel
  have e24781 : Deny 5 11 b24781 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e24783 : Deny 5 11 b24783 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e24785 : Deny 5 11 b24785 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e24787 : Deny 5 11 b24787 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e24789 : Deny 5 11 b24789 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e24791 : Deny 5 11 b24791 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e24792 : Deny 5 11 b24792 := by
    apply closeAction rule_sound _ _ 64 [0x6830f584784a8daae32e36ab8cb8daae32e36ab8cb8daae32e3]
    decide +kernel
  have e24790 : Deny 5 11 b24790 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24790 b24791 b24792 (by decide +kernel) e24791 e24792
  have e24788 : Deny 5 11 b24788 :=
    branchAction rule_sound _ _ 1
      0xb b24788 b24789 b24790 (by decide +kernel) e24789 e24790
  have e24786 : Deny 5 11 b24786 :=
    branchAction rule_sound _ _ 2
      0x1e3 b24786 b24787 b24788 (by decide +kernel) e24787 e24788
  have e24784 : Deny 5 11 b24784 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24784 b24785 b24786 (by decide +kernel) e24785 e24786
  have e24782 : Deny 5 11 b24782 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24782 b24783 b24784 (by decide +kernel) e24783 e24784
  have e24780 : Deny 5 11 b24780 :=
    branchAction rule_sound _ _ 3
      0xbae3 b24780 b24781 b24782 (by decide +kernel) e24781 e24782
  have e24809 : Deny 5 11 b24809 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e24811 : Deny 5 11 b24811 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e24812 : Deny 5 11 b24812 := by
    apply closeAction rule_sound _ _ 64 [0x209aae32351eb0838c8087ae32236ab8cb8daae32e3]
    decide +kernel
  have e24810 : Deny 5 11 b24810 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24810 b24811 b24812 (by decide +kernel) e24811 e24812
  have e24808 : Deny 5 11 b24808 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24808 b24809 b24810 (by decide +kernel) e24809 e24810
  have e24827 : Deny 5 11 b24827 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e24807 : Deny 5 11 b24807 :=
    branchAction rule_sound _ _ 3
      0x7e2b b24807 b24808 b24827 (by decide +kernel) e24808 e24827
  have e24779 : Deny 5 11 b24779 :=
    branchAction rule_sound _ _ 2
      0x223 b24779 b24780 b24807 (by decide +kernel) e24780 e24807
  have e24775 : Deny 5 11 b24775 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24775 b24776 b24779 (by decide +kernel) e24776 e24779
  have e24828 : Deny 5 11 b24828 := by
    apply closeAction rule_sound _ _ 64 [0x820820f88c8e232788c7e2b8c8e23]
    decide +kernel
  have e24774 : Deny 5 11 b24774 :=
    branchAction rule_sound _ _ 3
      0x9e2b b24774 b24775 b24828 (by decide +kernel) e24775 e24828
  have e24744 : Deny 5 11 b24744 :=
    branchAction rule_sound _ _ 1
      0x8 b24744 b24745 b24774 (by decide +kernel) e24745 e24774
  have e24664 : Deny 5 11 b24664 :=
    branchAction rule_sound _ _ 2
      0x1e3 b24664 b24665 b24744 (by decide +kernel) e24665 e24744
  have e24628 : Deny 5 11 b24628 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24628 b24629 b24664 (by decide +kernel) e24629 e24664
  have e24838 : Deny 5 11 b24838 := by
    apply closeAction rule_sound _ _ 64 [0x20ab08209a278deb8c38c8e2b1f8ae3278ae32231e3]
    decide +kernel
  have e24855 : Deny 5 11 b24855 := by
    apply closeAction rule_sound _ _ 64 [0x83e232386ab0e322b0e3207ae3]
    decide +kernel
  have e24864 : Deny 5 11 b24864 := by
    apply closeAction rule_sound _ _ 64 [0x20f88c9e2b0e32030f88c80f88c84b8d612a31e3]
    decide +kernel
  have e24854 : Deny 5 11 b24854 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24854 b24855 b24864 (by decide +kernel) e24855 e24864
  have e24878 : Deny 5 11 b24878 := by
    apply closeAction rule_sound _ _ 64 [0x2083e230f8ae32788c8e2b1f8ae3]
    decide +kernel
  have e24885 : Deny 5 11 b24885 := by
    apply closeAction rule_sound _ _ 64 [0x820f88c9e23238083e232380c9ac30f82632231e3]
    decide +kernel
  have e24877 : Deny 5 11 b24877 :=
    branchAction rule_sound _ _ 1
      0xb b24877 b24878 b24885 (by decide +kernel) e24878 e24885
  have e24853 : Deny 5 11 b24853 :=
    branchAction rule_sound _ _ 2
      0x263 b24853 b24854 b24877 (by decide +kernel) e24854 e24877
  have e24904 : Deny 5 11 b24904 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e24906 : Deny 5 11 b24906 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e24908 : Deny 5 11 b24908 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e24910 : Deny 5 11 b24910 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e24912 : Deny 5 11 b24912 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e24914 : Deny 5 11 b24914 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e24916 : Deny 5 11 b24916 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e24918 : Deny 5 11 b24918 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e24920 : Deny 5 11 b24920 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e24922 : Deny 5 11 b24922 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e24924 : Deny 5 11 b24924 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e24927 : Deny 5 11 b24927 := by
    apply closeAction rule_sound _ _ 64 [0x12]
    decide +kernel
  have e24929 : Deny 5 11 b24929 := by
    apply closeAction rule_sound _ _ 64 [0x12]
    decide +kernel
  have e24930 : Deny 5 11 b24930 := by
    apply closeAction rule_sound _ _ 64 [0x68308784a48b48b48b48b48b]
    decide +kernel
  have e24928 : Deny 5 11 b24928 :=
    branchAction rule_sound _ _ 1
      0xb b24928 b24929 b24930 (by decide +kernel) e24929 e24930
  have e24926 : Deny 5 11 b24926 :=
    branchAction rule_sound _ _ 2
      0x2e1 b24926 b24927 b24928 (by decide +kernel) e24927 e24928
  have e24945 : Deny 5 11 b24945 := by
    apply closeAction rule_sound _ _ 64 [0x1a]
    decide +kernel
  have e24925 : Deny 5 11 b24925 :=
    branchAction rule_sound _ _ 2
      0x2a3 b24925 b24926 b24945 (by decide +kernel) e24926 e24945
  have e24923 : Deny 5 11 b24923 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24923 b24924 b24925 (by decide +kernel) e24924 e24925
  have e24921 : Deny 5 11 b24921 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24921 b24922 b24923 (by decide +kernel) e24922 e24923
  have e24919 : Deny 5 11 b24919 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24919 b24920 b24921 (by decide +kernel) e24920 e24921
  have e24917 : Deny 5 11 b24917 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24917 b24918 b24919 (by decide +kernel) e24918 e24919
  have e24915 : Deny 5 11 b24915 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24915 b24916 b24917 (by decide +kernel) e24916 e24917
  have e24913 : Deny 5 11 b24913 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24913 b24914 b24915 (by decide +kernel) e24914 e24915
  have e24911 : Deny 5 11 b24911 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24911 b24912 b24913 (by decide +kernel) e24912 e24913
  have e24909 : Deny 5 11 b24909 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24909 b24910 b24911 (by decide +kernel) e24910 e24911
  have e24907 : Deny 5 11 b24907 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24907 b24908 b24909 (by decide +kernel) e24908 e24909
  have e24905 : Deny 5 11 b24905 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24905 b24906 b24907 (by decide +kernel) e24906 e24907
  have e24903 : Deny 5 11 b24903 :=
    branchAction rule_sound _ _ 4
      0x2f8ae3 b24903 b24904 b24905 (by decide +kernel) e24904 e24905
  have e24946 : Deny 5 11 b24946 := by
    apply closeAction rule_sound _ _ 64 [0x20826ab6b8ae32358da2e36ab8cbe098c7e2b8c8e2b]
    decide +kernel
  have e24902 : Deny 5 11 b24902 :=
    branchAction rule_sound _ _ 2
      0x223 b24902 b24903 b24946 (by decide +kernel) e24903 e24946
  have e24959 : Deny 5 11 b24959 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e24901 : Deny 5 11 b24901 :=
    branchAction rule_sound _ _ 2
      0x1e3 b24901 b24902 b24959 (by decide +kernel) e24902 e24959
  have e24960 : Deny 5 11 b24960 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e24900 : Deny 5 11 b24900 :=
    branchAction rule_sound _ _ 3
      0x9e2b b24900 b24901 b24960 (by decide +kernel) e24901 e24960
  have e24852 : Deny 5 11 b24852 :=
    branchAction rule_sound _ _ 2
      0x223 b24852 b24853 b24900 (by decide +kernel) e24853 e24900
  have e24961 : Deny 5 11 b24961 := by
    apply closeAction rule_sound _ _ 64 [0x2082083e07e232388c9e23238]
    decide +kernel
  have e24851 : Deny 5 11 b24851 :=
    branchAction rule_sound _ _ 2
      0x1e3 b24851 b24852 b24961 (by decide +kernel) e24852 e24961
  have e24837 : Deny 5 11 b24837 :=
    branchAction rule_sound _ _ 1
      0xb b24837 b24838 b24851 (by decide +kernel) e24838 e24851
  have e24627 : Deny 5 11 b24627 :=
    branchAction rule_sound _ _ 1
      0x9 b24627 b24628 b24837 (by decide +kernel) e24628 e24837
  have e24535 : Deny 5 11 b24535 :=
    branchAction rule_sound _ _ 2
      0x223 b24535 b24536 b24627 (by decide +kernel) e24536 e24627
  have e24425 : Deny 5 11 b24425 :=
    branchAction rule_sound _ _ 2
      0x2e3 b24425 b24426 b24535 (by decide +kernel) e24426 e24535
  have e24975 : Deny 5 11 b24975 := by
    apply closeAction rule_sound _ _ 64 [0x838490c31c81370f8dc31c88442e1]
    decide +kernel
  have e24988 : Deny 5 11 b24988 := by
    apply closeAction rule_sound _ _ 64 [0x820c41f8dc3e23263238]
    decide +kernel
  have e24974 : Deny 5 11 b24974 :=
    branchAction rule_sound _ _ 2
      0x2a3 b24974 b24975 b24988 (by decide +kernel) e24975 e24988
  have e24995 : Deny 5 11 b24995 := by
    apply closeAction rule_sound _ _ 64 [0x13e37]
    decide +kernel
  have e24973 : Deny 5 11 b24973 :=
    branchAction rule_sound _ _ 2
      0x1e3 b24973 b24974 b24995 (by decide +kernel) e24974 e24995
  have e24996 : Deny 5 11 b24996 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e24972 : Deny 5 11 b24972 :=
    branchAction rule_sound _ _ 2
      0x263 b24972 b24973 b24996 (by decide +kernel) e24973 e24996
  have e24997 : Deny 5 11 b24997 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e24971 : Deny 5 11 b24971 :=
    branchAction rule_sound _ _ 3
      0x88c4 b24971 b24972 b24997 (by decide +kernel) e24972 e24997
  have e25002 : Deny 5 11 b25002 := by
    apply closeAction rule_sound _ _ 64 [0x20f8847e370f8dc38c78c90c38c70e3263223]
    decide +kernel
  have e25016 : Deny 5 11 b25016 := by
    apply closeAction rule_sound _ _ 64 [0x30f81c3e23263]
    decide +kernel
  have e25021 : Deny 5 11 b25021 := by
    apply closeAction rule_sound _ _ 64 [0x83e232380f80e32231c30f88c78c9]
    decide +kernel
  have e25015 : Deny 5 11 b25015 :=
    branchAction rule_sound _ _ 2
      0x223 b25015 b25016 b25021 (by decide +kernel) e25016 e25021
  have e25001 : Deny 5 11 b25001 :=
    branchAction rule_sound _ _ 2
      0x2e3 b25001 b25002 b25015 (by decide +kernel) e25002 e25015
  have e25033 : Deny 5 11 b25033 := by
    apply closeAction rule_sound _ _ 64 [0x2083263223]
    decide +kernel
  have e25038 : Deny 5 11 b25038 := by
    apply closeAction rule_sound _ _ 64 [0x2083e07e23278083e231f80e3263223]
    decide +kernel
  have e25032 : Deny 5 11 b25032 :=
    branchAction rule_sound _ _ 1
      0xb b25032 b25033 b25038 (by decide +kernel) e25033 e25038
  have e25000 : Deny 5 11 b25000 :=
    branchAction rule_sound _ _ 2
      0x1e3 b25000 b25001 b25032 (by decide +kernel) e25001 e25032
  have e25050 : Deny 5 11 b25050 := by
    apply closeAction rule_sound _ _ 64 [0x2083e232780f80e32631e30820e32788c78cbe23223]
    decide +kernel
  have e25065 : Deny 5 11 b25065 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e25049 : Deny 5 11 b25049 :=
    branchAction rule_sound _ _ 2
      0x1f8 b25049 b25050 b25065 (by decide +kernel) e25050 e25065
  have e24999 : Deny 5 11 b24999 :=
    branchAction rule_sound _ _ 2
      0x263 b24999 b25000 b25049 (by decide +kernel) e25000 e25049
  have e25070 : Deny 5 11 b25070 := by
    apply closeAction rule_sound _ _ 64 [0x820838c4238ac78c4278ae3]
    decide +kernel
  have e25078 : Deny 5 11 b25078 := by
    apply closeAction rule_sound _ _ 64 [0x83e23238083e23238ac38c81e3]
    decide +kernel
  have e25087 : Deny 5 11 b25087 := by
    apply closeAction rule_sound _ _ 64 [0x20820f82788c8e231f8]
    decide +kernel
  have e25077 : Deny 5 11 b25077 :=
    branchAction rule_sound _ _ 2
      0x263 b25077 b25078 b25087 (by decide +kernel) e25078 e25087
  have e25069 : Deny 5 11 b25069 :=
    branchAction rule_sound _ _ 3
      0xbe23 b25069 b25070 b25077 (by decide +kernel) e25070 e25077
  have e25094 : Deny 5 11 b25094 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e25068 : Deny 5 11 b25068 :=
    branchAction rule_sound _ _ 2
      0x223 b25068 b25069 b25094 (by decide +kernel) e25069 e25094
  have e25095 : Deny 5 11 b25095 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e25067 : Deny 5 11 b25067 :=
    branchAction rule_sound _ _ 2
      0x1e3 b25067 b25068 b25095 (by decide +kernel) e25068 e25095
  have e25096 : Deny 5 11 b25096 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e25066 : Deny 5 11 b25066 :=
    branchAction rule_sound _ _ 2
      0x278 b25066 b25067 b25096 (by decide +kernel) e25067 e25096
  have e24998 : Deny 5 11 b24998 :=
    branchAction rule_sound _ _ 2
      0x223 b24998 b24999 b25066 (by decide +kernel) e24999 e25066
  have e24970 : Deny 5 11 b24970 :=
    branchAction rule_sound _ _ 1
      0xb b24970 b24971 b24998 (by decide +kernel) e24971 e24998
  have e24424 : Deny 5 11 b24424 :=
    branchAction rule_sound _ _ 2
      0x1e3 b24424 b24425 b24970 (by decide +kernel) e24425 e24970
  exact e24424
end OMA.Blocks5_11_245212.S24424
