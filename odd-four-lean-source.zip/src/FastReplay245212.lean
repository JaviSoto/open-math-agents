import SparseEngine245212
import FastContract245212
import FastRound245212

/-! Six-bit arithmetic replay with fixed-denominator four-prime factor cuts. -/
namespace OMA.FastReplay245212
open Box245212 SparseEngine245212 FastDigit245212

private def basic (p q : ℕ) (b : Box) (op : ℕ) :=
  if op=2 then fastInterval p q b else banned p q b op

def leaf := FastRound245212.dispatch basic

theorem leaf_sound : TestSound leaf := by
  apply FastRound245212.dispatch_sound
  intro p q b op check
  unfold basic at check
  split_ifs at check
  · exact fastInterval_sound check
  · exact banned_sound check

theorem certify (p q fuel : ℕ) (ws : List ℕ) (b : Box)
    (check : run (step fastDigit leaf) p q fuel ws [b]=some []) : Deny p q b :=
  SparseEngine245212.certify (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound p q fuel ws b check

end OMA.FastReplay245212
