import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S17048
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b17048 : Box := ![⟨23,30⟩,⟨15,20⟩,⟨15,1920000000000000011376⟩,⟨2,1210212765957446815715⟩,⟨59,73⟩]
theorem deny5_13 : Deny 5 13 ![⟨23,30⟩,⟨15,20⟩,⟨15,1920000000000000011376⟩,⟨2,1210212765957446815715⟩,⟨59,73⟩] := by
  have e17048 : Deny 5 13 b17048 := by
    apply closeAction rule_sound _ _ 64 [0x88e368c91028842b88c80c3e37d87102238df68c972f709bc3087088df68c90a229ce37d87102238df68c70a22b7da3,0xe368c90a22a311cbdcbe326f71f0e22030f61e21e229f0f8df68880f8df688788a8c910b72f72f8c9bdc0f8da22821c4,0x1cbdcbe3243738df68c9088087]
    decide +kernel
  exact e17048
end OMA.Blocks5_13_245212.S17048
