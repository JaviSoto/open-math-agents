import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S6663
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b6663 : Box := ![⟨15,22⟩,⟨31,1920000000000000011376⟩,⟨6,12⟩,⟨1,1920000000000000011376⟩,⟨53,73⟩]
theorem deny5_13 : Deny 5 13 ![⟨15,22⟩,⟨31,1920000000000000011376⟩,⟨6,12⟩,⟨1,1920000000000000011376⟩,⟨53,73⟩] := by
  have e6663 : Deny 5 13 b6663 := by
    apply closeAction rule_sound _ _ 64 [0xae32358c72da6a321ae37d61282ae129ae37d63244087e232430f78c90f7da32021f51021f8df6d6320284ad758c7de3,0x6ab6ab8c8d6311aada22b6830f8ae1261103e37db58441f884aae321aadaac40a3108e37db5]
    decide +kernel
  exact e6663
end OMA.Blocks5_13_245212.S6663
