import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S45146
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b45146 : Box := ![⟨95,190⟩,⟨18,20⟩,⟨31,1920000000000000011376⟩,⟨3,1017986577181208059785⟩,⟨127,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨18,20⟩,⟨31,1920000000000000011376⟩,⟨3,1017986577181208059785⟩,⟨127,233⟩] := by
  have e45146 : Deny 5 13 b45146 := by
    apply closeAction rule_sound _ _ 64 [0x238578dc20c82780c31c81c9295578dd52152092842e31e3263102095e37578dd5e375770c7207255dc42c72778c42f8,0x2a321d0c32430c91c40832030c91c42ca5550c924a0dde37da31f8dc88c78c98dd082578dd5e370c91c81f8095e370c9,0x54a8c88c98c78c45778c42f875d095238082083209107e1d54a20729528a54a578dd50c9dc38c921d0f80f81c3e09295,0x2082095e3776f0f8dc38c78c98c78c98888841f854a8841f8dd5dd5dd5ddd083278dc3e370c91ca]
    decide +kernel
  exact e45146
end OMA.Blocks5_13_245212.S45146
