import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S9677
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b9677 : Box := ![⟨47,1920000000000000011376⟩,⟨7,14⟩,⟨3,6⟩,⟨1,1920000000000000011376⟩,⟨29,53⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,1920000000000000011376⟩,⟨7,14⟩,⟨3,6⟩,⟨1,1920000000000000011376⟩,⟨29,53⟩] := by
  have e9677 : Deny 5 13 b9677 := by
    apply closeAction rule_sound _ _ 64 [0xde32632042c3804088e3780a8c98c76676678c70c38c89c38c7119e37db48c4238da31c29e02a32232c2e369e69602a3,0x2678c744a9c29c31f70e31c30f78c98c88c4083dc38c98c810b0c3e202202839c3de31c22422231020e78c99c38c70c3,0x9d966780a9e31c30f88c90f88c70c2278df48c8678df5d232768c76671199e3107e37db48c80f8df6d602a31199d9e19,0x19]
    decide +kernel
  exact e9677
end OMA.Blocks5_13_245212.S9677
