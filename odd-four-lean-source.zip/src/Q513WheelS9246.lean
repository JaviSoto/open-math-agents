import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S9246
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b9246 : Box := ![⟨23,30⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨3,1328583941605839423966⟩,⟨41,53⟩]
theorem deny5_13 : Deny 5 13 ![⟨23,30⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨3,1328583941605839423966⟩,⟨41,53⟩] := by
  have e9246 : Deny 5 13 b9246 := by
    apply closeAction rule_sound _ _ 64 [0x1c30f78c70e3243df68c88c910b72f72f8c90c4088e37da324288a11ce37da3107e37da32030880888821f8df6d622a3,0xda30af72f8c97020832221c30f8da21e22222a32430c788a72f72f8c97030c90f8da21e229ce37da3223243087de22a3,0xdc3da220388788a8c910b72f11cbe3109e368c80e2102238be2283737da31c4088e37da325cbc4737daf8c4278df68c7,0x72f737daf8c9da3102bdc26f703]
    decide +kernel
  exact e9246
end OMA.Blocks5_13_245212.S9246
