import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S8584
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b8584 : Box := ![⟨23,46⟩,⟨7,14⟩,⟨7,1920000000000000011376⟩,⟨1,2⟩,⟨29,53⟩]
theorem deny5_13 : Deny 5 13 ![⟨23,46⟩,⟨7,14⟩,⟨7,1920000000000000011376⟩,⟨1,2⟩,⟨29,53⟩] := by
  have e8584 : Deny 5 13 b8584 := by
    apply closeAction rule_sound _ _ 64 [0xda2202887da22955432490c2236887de22030c90c90f8d88dc90c3da21c3e36887088df688710b56c088e37db4888e22,0x5421f688810b0c3e361c22090c21c4088e368872c22021f7d840820c82420e2107e038880c32098870c3da21d5d880b8,0xd5202887088087d840d5203da21c22040952430c9887]
    decide +kernel
  exact e8584
end OMA.Blocks5_13_245212.S8584
