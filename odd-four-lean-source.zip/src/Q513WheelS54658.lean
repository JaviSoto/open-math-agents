import FastReplay245212
import SparseDigit245212
import WheelRule245212

import Q513Under54658S54659
import Q513Under54658S54674
import Q513Under54658S54685
import Q513Under54658S54690
import Q513Under54658S54707
import Q513Under54658S54718
import Q513Under54658S54728
import Q513Under54658S54741
import Q513Under54658S54757
import Q513Under54658S54765
import Q513Under54658S54771
import Q513Under54658S54776

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S54658
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b54658 : Box := ![⟨47,62⟩,⟨63,126⟩,⟨10,14⟩,⟨1,502335381913959616705⟩,⟨479,999999999999999999⟩]
private def b54659 : Box := ![⟨47,53⟩,⟨63,126⟩,⟨10,14⟩,⟨1,58⟩,⟨479,999999999999999999⟩]
private def b54670 : Box := ![⟨54,62⟩,⟨63,126⟩,⟨10,14⟩,⟨1,58⟩,⟨479,999999999999999999⟩]
private def b54671 : Box := ![⟨54,62⟩,⟨63,126⟩,⟨10,14⟩,⟨1,58⟩,⟨479,958⟩]
private def b54672 : Box := ![⟨54,62⟩,⟨63,126⟩,⟨10,14⟩,⟨1,2⟩,⟨479,958⟩]
private def b54673 : Box := ![⟨54,62⟩,⟨63,126⟩,⟨10,14⟩,⟨3,52⟩,⟨479,958⟩]
private def b54674 : Box := ![⟨54,62⟩,⟨63,126⟩,⟨10,11⟩,⟨3,52⟩,⟨479,958⟩]
private def b54683 : Box := ![⟨54,62⟩,⟨63,126⟩,⟨12,14⟩,⟨3,52⟩,⟨479,958⟩]
private def b54684 : Box := ![⟨54,62⟩,⟨63,84⟩,⟨12,14⟩,⟨3,52⟩,⟨479,958⟩]
private def b54685 : Box := ![⟨54,57⟩,⟨63,84⟩,⟨12,14⟩,⟨3,41⟩,⟨479,958⟩]
private def b54690 : Box := ![⟨58,62⟩,⟨63,84⟩,⟨12,14⟩,⟨3,41⟩,⟨479,958⟩]
private def b54705 : Box := ![⟨54,62⟩,⟨85,126⟩,⟨12,14⟩,⟨3,52⟩,⟨479,958⟩]
private def b54706 : Box := ![⟨54,57⟩,⟨85,126⟩,⟨12,14⟩,⟨3,52⟩,⟨479,958⟩]
private def b54707 : Box := ![⟨54,57⟩,⟨85,126⟩,⟨12,14⟩,⟨4,51⟩,⟨479,638⟩]
private def b54718 : Box := ![⟨54,57⟩,⟨85,126⟩,⟨12,14⟩,⟨4,51⟩,⟨639,958⟩]
private def b54727 : Box := ![⟨58,62⟩,⟨85,126⟩,⟨12,14⟩,⟨3,52⟩,⟨479,958⟩]
private def b54728 : Box := ![⟨58,62⟩,⟨85,126⟩,⟨12,14⟩,⟨3,52⟩,⟨479,638⟩]
private def b54741 : Box := ![⟨58,62⟩,⟨85,126⟩,⟨12,14⟩,⟨3,52⟩,⟨639,958⟩]
private def b54756 : Box := ![⟨54,62⟩,⟨63,126⟩,⟨10,14⟩,⟨1,58⟩,⟨959,999999999999999999⟩]
private def b54757 : Box := ![⟨54,62⟩,⟨66,86⟩,⟨11,14⟩,⟨1,52⟩,⟨959,999999999999999999⟩]
private def b54762 : Box := ![⟨54,62⟩,⟨87,126⟩,⟨11,14⟩,⟨1,52⟩,⟨959,999999999999999999⟩]
private def b54763 : Box := ![⟨54,62⟩,⟨87,126⟩,⟨11,14⟩,⟨1,2⟩,⟨959,999999999999999999⟩]
private def b54764 : Box := ![⟨54,62⟩,⟨87,126⟩,⟨11,14⟩,⟨3,52⟩,⟨959,999999999999999999⟩]
private def b54765 : Box := ![⟨54,62⟩,⟨87,126⟩,⟨11,12⟩,⟨3,52⟩,⟨959,681527⟩]
private def b54770 : Box := ![⟨54,62⟩,⟨87,126⟩,⟨13,14⟩,⟨3,52⟩,⟨959,681527⟩]
private def b54771 : Box := ![⟨54,57⟩,⟨87,126⟩,⟨13,14⟩,⟨3,48⟩,⟨959,434784⟩]
private def b54776 : Box := ![⟨58,62⟩,⟨87,126⟩,⟨13,14⟩,⟨3,48⟩,⟨959,434784⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,62⟩,⟨63,126⟩,⟨10,14⟩,⟨1,502335381913959616705⟩,⟨479,999999999999999999⟩] := by
  have e54659 : Deny 5 13 b54659 := OMA.Blocks5_13_245212.S54659.deny5_13
  have e54672 : Deny 5 13 b54672 := by
    apply closeAction rule_sound _ _ 64 [0x17e37da1]
    decide +kernel
  have e54674 : Deny 5 13 b54674 := OMA.Blocks5_13_245212.S54674.deny5_13
  have e54685 : Deny 5 13 b54685 := OMA.Blocks5_13_245212.S54685.deny5_13
  have e54690 : Deny 5 13 b54690 := OMA.Blocks5_13_245212.S54690.deny5_13
  have e54684 : Deny 5 13 b54684 :=
    branchAction rule_sound _ _ 2
      0x1e3 b54684 b54685 b54690 (by decide +kernel) e54685 e54690
  have e54707 : Deny 5 13 b54707 := OMA.Blocks5_13_245212.S54707.deny5_13
  have e54718 : Deny 5 13 b54718 := OMA.Blocks5_13_245212.S54718.deny5_13
  have e54706 : Deny 5 13 b54706 :=
    branchAction rule_sound _ _ 3
      0xbae3 b54706 b54707 b54718 (by decide +kernel) e54707 e54718
  have e54728 : Deny 5 13 b54728 := OMA.Blocks5_13_245212.S54728.deny5_13
  have e54741 : Deny 5 13 b54741 := OMA.Blocks5_13_245212.S54741.deny5_13
  have e54727 : Deny 5 13 b54727 :=
    branchAction rule_sound _ _ 1
      0xb b54727 b54728 b54741 (by decide +kernel) e54728 e54741
  have e54705 : Deny 5 13 b54705 :=
    branchAction rule_sound _ _ 1
      0x7 b54705 b54706 b54727 (by decide +kernel) e54706 e54727
  have e54683 : Deny 5 13 b54683 :=
    branchAction rule_sound _ _ 1
      0x8 b54683 b54684 b54705 (by decide +kernel) e54684 e54705
  have e54673 : Deny 5 13 b54673 :=
    branchAction rule_sound _ _ 1
      0x9 b54673 b54674 b54683 (by decide +kernel) e54674 e54683
  have e54671 : Deny 5 13 b54671 :=
    branchAction rule_sound _ _ 2
      0x2a3 b54671 b54672 b54673 (by decide +kernel) e54672 e54673
  have e54757 : Deny 5 13 b54757 := OMA.Blocks5_13_245212.S54757.deny5_13
  have e54763 : Deny 5 13 b54763 := by
    apply closeAction rule_sound _ _ 64 [0x4b8da1]
    decide +kernel
  have e54765 : Deny 5 13 b54765 := OMA.Blocks5_13_245212.S54765.deny5_13
  have e54771 : Deny 5 13 b54771 := OMA.Blocks5_13_245212.S54771.deny5_13
  have e54776 : Deny 5 13 b54776 := OMA.Blocks5_13_245212.S54776.deny5_13
  have e54770 : Deny 5 13 b54770 :=
    branchAction rule_sound _ _ 3
      0x7e23 b54770 b54771 b54776 (by decide +kernel) e54771 e54776
  have e54764 : Deny 5 13 b54764 :=
    branchAction rule_sound _ _ 2
      0x278 b54764 b54765 b54770 (by decide +kernel) e54765 e54770
  have e54762 : Deny 5 13 b54762 :=
    branchAction rule_sound _ _ 1
      0xa b54762 b54763 b54764 (by decide +kernel) e54763 e54764
  have e54756 : Deny 5 13 b54756 :=
    branchAction rule_sound _ _ 4
      0x236d63 b54756 b54757 b54762 (by decide +kernel) e54757 e54762
  have e54670 : Deny 5 13 b54670 :=
    branchAction rule_sound _ _ 1
      0xb b54670 b54671 b54756 (by decide +kernel) e54671 e54756
  have e54658 : Deny 5 13 b54658 :=
    branchAction rule_sound _ _ 2
      0x1e3 b54658 b54659 b54670 (by decide +kernel) e54659 e54670
  exact e54658
end OMA.Blocks5_13_245212.S54658
