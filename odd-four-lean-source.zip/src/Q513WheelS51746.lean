import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S51746
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b51746 : Box := ![⟨191,382⟩,⟨23,24⟩,⟨21,30⟩,⟨3,85⟩,⟨959,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨191,382⟩,⟨23,24⟩,⟨21,30⟩,⟨3,85⟩,⟨959,999999999999999999⟩] := by
  have e51746 : Deny 5 13 b51746 := by
    apply closeAction rule_sound _ _ 64 [0x2389e32788c7e278cb0c3e232422236599cb9e32e70f80f82789e3088e231e365f0f86499c3e079e02202a78cb8c98c7,0xe232380832038c98c98c2099e270e31c8e278c9e278cb0f80c80c3e372232630832380f80c89e32678cb8c78c20820e3,0x9e32e36678cb8d99e32e36678cb8d99e32e36678cb9e36678cb8d99e32e36678cb8d99e32e32636678cbe270820f88c7,0x8880a44b44b44b44b44b80a66780b66780b66780b66780b66780b66780b6679a02d12d12d12ca8d99e32e36678cb8d9,0x820820f88c7e232382788c7e19659083809]
    decide +kernel
  exact e51746
end OMA.Blocks5_13_245212.S51746
