import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S53928
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b53928 : Box := ![⟨63,94⟩,⟨31,62⟩,⟨10,14⟩,⟨1,53⟩,⟨239,478⟩]
private def b53929 : Box := ![⟨63,94⟩,⟨31,41⟩,⟨10,14⟩,⟨1,46⟩,⟨239,478⟩]
private def b53930 : Box := ![⟨63,75⟩,⟨31,41⟩,⟨10,14⟩,⟨1,40⟩,⟨239,478⟩]
private def b53931 : Box := ![⟨63,75⟩,⟨31,41⟩,⟨10,11⟩,⟨2,36⟩,⟨239,369⟩]
private def b53934 : Box := ![⟨63,75⟩,⟨31,41⟩,⟨12,14⟩,⟨2,36⟩,⟨239,369⟩]
private def b53943 : Box := ![⟨76,94⟩,⟨31,41⟩,⟨10,14⟩,⟨1,40⟩,⟨239,478⟩]
private def b53944 : Box := ![⟨76,94⟩,⟨31,41⟩,⟨10,14⟩,⟨1,40⟩,⟨239,318⟩]
private def b53945 : Box := ![⟨76,94⟩,⟨31,41⟩,⟨10,11⟩,⟨1,40⟩,⟨239,317⟩]
private def b53946 : Box := ![⟨76,94⟩,⟨31,35⟩,⟨10,11⟩,⟨2,39⟩,⟨239,317⟩]
private def b53949 : Box := ![⟨76,94⟩,⟨36,41⟩,⟨10,11⟩,⟨2,39⟩,⟨239,317⟩]
private def b53950 : Box := ![⟨76,94⟩,⟨36,41⟩,⟨10,11⟩,⟨2,4⟩,⟨239,317⟩]
private def b53957 : Box := ![⟨76,94⟩,⟨36,41⟩,⟨10,11⟩,⟨5,39⟩,⟨239,317⟩]
private def b53966 : Box := ![⟨76,94⟩,⟨31,41⟩,⟨12,14⟩,⟨1,40⟩,⟨239,317⟩]
private def b53967 : Box := ![⟨76,94⟩,⟨31,41⟩,⟨12,14⟩,⟨1,2⟩,⟨239,317⟩]
private def b53968 : Box := ![⟨76,94⟩,⟨31,41⟩,⟨12,14⟩,⟨3,40⟩,⟨239,317⟩]
private def b53969 : Box := ![⟨76,94⟩,⟨31,35⟩,⟨12,14⟩,⟨3,40⟩,⟨239,317⟩]
private def b53974 : Box := ![⟨76,94⟩,⟨36,41⟩,⟨12,14⟩,⟨3,40⟩,⟨239,317⟩]
private def b53981 : Box := ![⟨76,94⟩,⟨31,41⟩,⟨10,14⟩,⟨1,40⟩,⟨319,478⟩]
private def b53982 : Box := ![⟨76,94⟩,⟨31,41⟩,⟨10,11⟩,⟨1,38⟩,⟨319,478⟩]
private def b53985 : Box := ![⟨76,94⟩,⟨31,41⟩,⟨12,14⟩,⟨1,38⟩,⟨319,478⟩]
private def b53986 : Box := ![⟨76,94⟩,⟨31,35⟩,⟨12,14⟩,⟨1,38⟩,⟨319,478⟩]
private def b53991 : Box := ![⟨76,94⟩,⟨36,41⟩,⟨12,14⟩,⟨1,38⟩,⟨319,478⟩]
private def b54002 : Box := ![⟨63,94⟩,⟨42,62⟩,⟨10,14⟩,⟨1,46⟩,⟨239,478⟩]
private def b54003 : Box := ![⟨63,94⟩,⟨42,62⟩,⟨10,14⟩,⟨1,2⟩,⟨239,478⟩]
private def b54004 : Box := ![⟨63,94⟩,⟨42,62⟩,⟨10,14⟩,⟨3,46⟩,⟨239,478⟩]
private def b54005 : Box := ![⟨63,75⟩,⟨42,62⟩,⟨10,14⟩,⟨3,46⟩,⟨239,478⟩]
private def b54006 : Box := ![⟨63,75⟩,⟨42,62⟩,⟨10,14⟩,⟨3,43⟩,⟨239,318⟩]
private def b54007 : Box := ![⟨63,75⟩,⟨42,62⟩,⟨10,11⟩,⟨3,42⟩,⟨239,317⟩]
private def b54008 : Box := ![⟨63,75⟩,⟨42,50⟩,⟨10,11⟩,⟨3,41⟩,⟨239,317⟩]
private def b54015 : Box := ![⟨63,75⟩,⟨51,62⟩,⟨10,11⟩,⟨3,41⟩,⟨239,317⟩]
private def b54022 : Box := ![⟨63,75⟩,⟨42,62⟩,⟨12,14⟩,⟨3,42⟩,⟨239,317⟩]
private def b54023 : Box := ![⟨63,75⟩,⟨42,50⟩,⟨12,14⟩,⟨3,42⟩,⟨239,317⟩]
private def b54032 : Box := ![⟨63,75⟩,⟨51,62⟩,⟨12,14⟩,⟨3,42⟩,⟨239,317⟩]
private def b54041 : Box := ![⟨63,75⟩,⟨42,62⟩,⟨10,14⟩,⟨3,43⟩,⟨319,478⟩]
private def b54042 : Box := ![⟨63,75⟩,⟨42,62⟩,⟨10,11⟩,⟨3,40⟩,⟨319,478⟩]
private def b54051 : Box := ![⟨63,75⟩,⟨42,62⟩,⟨12,14⟩,⟨3,40⟩,⟨319,478⟩]
private def b54052 : Box := ![⟨63,75⟩,⟨42,50⟩,⟨12,14⟩,⟨3,40⟩,⟨319,478⟩]
private def b54061 : Box := ![⟨63,75⟩,⟨51,62⟩,⟨12,14⟩,⟨3,40⟩,⟨319,478⟩]
private def b54072 : Box := ![⟨76,94⟩,⟨42,62⟩,⟨10,14⟩,⟨3,46⟩,⟨239,478⟩]
private def b54073 : Box := ![⟨76,94⟩,⟨42,62⟩,⟨10,14⟩,⟨3,46⟩,⟨239,318⟩]
private def b54074 : Box := ![⟨76,94⟩,⟨42,62⟩,⟨10,11⟩,⟨3,46⟩,⟨239,317⟩]
private def b54075 : Box := ![⟨76,94⟩,⟨42,50⟩,⟨10,11⟩,⟨3,45⟩,⟨239,317⟩]
private def b54082 : Box := ![⟨76,94⟩,⟨51,62⟩,⟨10,11⟩,⟨3,45⟩,⟨239,317⟩]
private def b54093 : Box := ![⟨76,94⟩,⟨42,62⟩,⟨12,14⟩,⟨3,46⟩,⟨239,317⟩]
private def b54104 : Box := ![⟨76,94⟩,⟨42,62⟩,⟨10,14⟩,⟨3,46⟩,⟨319,478⟩]
private def b54105 : Box := ![⟨76,94⟩,⟨42,62⟩,⟨10,11⟩,⟨3,44⟩,⟨319,478⟩]
private def b54106 : Box := ![⟨76,94⟩,⟨42,50⟩,⟨10,11⟩,⟨3,43⟩,⟨319,478⟩]
private def b54113 : Box := ![⟨76,94⟩,⟨51,62⟩,⟨10,11⟩,⟨3,43⟩,⟨319,478⟩]
private def b54114 : Box := ![⟨76,94⟩,⟨51,62⟩,⟨10,11⟩,⟨3,6⟩,⟨319,478⟩]
private def b54115 : Box := ![⟨76,94⟩,⟨51,62⟩,⟨10,11⟩,⟨7,43⟩,⟨319,478⟩]
private def b54116 : Box := ![⟨76,94⟩,⟨51,62⟩,⟨10,11⟩,⟨7,12⟩,⟨319,478⟩]
private def b54127 : Box := ![⟨76,94⟩,⟨51,62⟩,⟨10,11⟩,⟨13,43⟩,⟨319,478⟩]
private def b54128 : Box := ![⟨76,94⟩,⟨42,62⟩,⟨12,14⟩,⟨3,44⟩,⟨319,478⟩]
private def b54129 : Box := ![⟨76,94⟩,⟨42,50⟩,⟨12,14⟩,⟨3,44⟩,⟨319,478⟩]
private def b54140 : Box := ![⟨76,94⟩,⟨51,62⟩,⟨12,14⟩,⟨3,44⟩,⟨319,478⟩]
private def b54141 : Box := ![⟨76,84⟩,⟨51,62⟩,⟨12,14⟩,⟨3,44⟩,⟨332,478⟩]
private def b54152 : Box := ![⟨85,94⟩,⟨51,62⟩,⟨12,14⟩,⟨3,44⟩,⟨332,478⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨31,62⟩,⟨10,14⟩,⟨1,53⟩,⟨239,478⟩] := by
  have e53931 : Deny 5 13 b53931 := by
    apply closeAction rule_sound _ _ 64 [0x1b088e37d63]
    decide +kernel
  have e53934 : Deny 5 13 b53934 := by
    apply closeAction rule_sound _ _ 64 [0xc3e378c70f8de325f089e378c8]
    decide +kernel
  have e53930 : Deny 5 13 b53930 :=
    branchAction rule_sound _ _ 4
      0x278de3 b53930 b53931 b53934 (by decide +kernel) e53931 e53934
  have e53946 : Deny 5 13 b53946 := by
    apply closeAction rule_sound _ _ 64 [0xc21f8de3]
    decide +kernel
  have e53950 : Deny 5 13 b53950 := by
    apply closeAction rule_sound _ _ 64 [0xc3e37203e37d871132b8]
    decide +kernel
  have e53957 : Deny 5 13 b53957 := by
    apply closeAction rule_sound _ _ 64 [0x6c30f82031022381ca]
    decide +kernel
  have e53949 : Deny 5 13 b53949 :=
    branchAction rule_sound _ _ 1
      0xa b53949 b53950 b53957 (by decide +kernel) e53950 e53957
  have e53945 : Deny 5 13 b53945 :=
    branchAction rule_sound _ _ 3
      0x8de3 b53945 b53946 b53949 (by decide +kernel) e53946 e53949
  have e53967 : Deny 5 13 b53967 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
  have e53969 : Deny 5 13 b53969 := by
    apply closeAction rule_sound _ _ 64 [0xc38c70f8de3263]
    decide +kernel
  have e53974 : Deny 5 13 b53974 := by
    apply closeAction rule_sound _ _ 64 [0xf8dc38c80c38c88c7]
    decide +kernel
  have e53968 : Deny 5 13 b53968 :=
    branchAction rule_sound _ _ 1
      0x8 b53968 b53969 b53974 (by decide +kernel) e53969 e53974
  have e53966 : Deny 5 13 b53966 :=
    branchAction rule_sound _ _ 1
      0xa b53966 b53967 b53968 (by decide +kernel) e53967 e53968
  have e53944 : Deny 5 13 b53944 :=
    branchAction rule_sound _ _ 2
      0x244 b53944 b53945 b53966 (by decide +kernel) e53945 e53966
  have e53982 : Deny 5 13 b53982 := by
    apply closeAction rule_sound _ _ 64 [0x1bde3102238de3]
    decide +kernel
  have e53986 : Deny 5 13 b53986 := by
    apply closeAction rule_sound _ _ 64 [0x3089dc47f8df68c41f8de3]
    decide +kernel
  have e53991 : Deny 5 13 b53991 := by
    apply closeAction rule_sound _ _ 64 [0xc38c80c3e378c88c75c224a]
    decide +kernel
  have e53985 : Deny 5 13 b53985 :=
    branchAction rule_sound _ _ 1
      0x8 b53985 b53986 b53991 (by decide +kernel) e53986 e53991
  have e53981 : Deny 5 13 b53981 :=
    branchAction rule_sound _ _ 2
      0x263 b53981 b53982 b53985 (by decide +kernel) e53982 e53985
  have e53943 : Deny 5 13 b53943 :=
    branchAction rule_sound _ _ 1
      0xb b53943 b53944 b53981 (by decide +kernel) e53944 e53981
  have e53929 : Deny 5 13 b53929 :=
    branchAction rule_sound _ _ 2
      0x1e3 b53929 b53930 b53943 (by decide +kernel) e53930 e53943
  have e54003 : Deny 5 13 b54003 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
  have e54008 : Deny 5 13 b54008 := by
    apply closeAction rule_sound _ _ 64 [0x30f8de3203102238de31e3]
    decide +kernel
  have e54015 : Deny 5 13 b54015 := by
    apply closeAction rule_sound _ _ 64 [0xc38c80c3e378c88c7]
    decide +kernel
  have e54007 : Deny 5 13 b54007 :=
    branchAction rule_sound _ _ 2
      0x223 b54007 b54008 b54015 (by decide +kernel) e54008 e54015
  have e54023 : Deny 5 13 b54023 := by
    apply closeAction rule_sound _ _ 64 [0xf8dc38c90e32030e32231e3]
    decide +kernel
  have e54032 : Deny 5 13 b54032 := by
    apply closeAction rule_sound _ _ 64 [0x13e37103109e370f8dc40e3108e038c98c7]
    decide +kernel
  have e54022 : Deny 5 13 b54022 :=
    branchAction rule_sound _ _ 1
      0x8 b54022 b54023 b54032 (by decide +kernel) e54023 e54032
  have e54006 : Deny 5 13 b54006 :=
    branchAction rule_sound _ _ 3
      0x98c4 b54006 b54007 b54022 (by decide +kernel) e54007 e54022
  have e54042 : Deny 5 13 b54042 := by
    apply closeAction rule_sound _ _ 64 [0xc3e378c86f78c4088e378c76f8de3223]
    decide +kernel
  have e54052 : Deny 5 13 b54052 := by
    apply closeAction rule_sound _ _ 64 [0xc3e378c90f88c80e311be37da3108e231e3]
    decide +kernel
  have e54061 : Deny 5 13 b54061 := by
    apply closeAction rule_sound _ _ 64 [0xf8dc38c80c90c38c80f88c98c7]
    decide +kernel
  have e54051 : Deny 5 13 b54051 :=
    branchAction rule_sound _ _ 1
      0x8 b54051 b54052 b54061 (by decide +kernel) e54052 e54061
  have e54041 : Deny 5 13 b54041 :=
    branchAction rule_sound _ _ 2
      0x263 b54041 b54042 b54051 (by decide +kernel) e54042 e54051
  have e54005 : Deny 5 13 b54005 :=
    branchAction rule_sound _ _ 2
      0x2e3 b54005 b54006 b54041 (by decide +kernel) e54006 e54041
  have e54075 : Deny 5 13 b54075 := by
    apply closeAction rule_sound _ _ 64 [0x30e32030e32231e3]
    decide +kernel
  have e54082 : Deny 5 13 b54082 := by
    apply closeAction rule_sound _ _ 64 [0x4f8ddb083109e032042b84ca8c7]
    decide +kernel
  have e54074 : Deny 5 13 b54074 :=
    branchAction rule_sound _ _ 2
      0x223 b54074 b54075 b54082 (by decide +kernel) e54075 e54082
  have e54093 : Deny 5 13 b54093 := by
    apply closeAction rule_sound _ _ 64 [0x820c4278dc20c4238dc38c98c78c8]
    decide +kernel
  have e54073 : Deny 5 13 b54073 :=
    branchAction rule_sound _ _ 2
      0x244 b54073 b54074 b54093 (by decide +kernel) e54074 e54093
  have e54106 : Deny 5 13 b54106 := by
    apply closeAction rule_sound _ _ 64 [0xc3e23203dc46f8de3108e231e3]
    decide +kernel
  have e54114 : Deny 5 13 b54114 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
  have e54116 : Deny 5 13 b54116 := by
    apply closeAction rule_sound _ _ 64 [0x20c42780c80f80f8243207]
    decide +kernel
  have e54127 : Deny 5 13 b54127 := by
    apply closeAction rule_sound _ _ 64 [0x1b]
    decide +kernel
  have e54115 : Deny 5 13 b54115 :=
    branchAction rule_sound _ _ 1
      0xa b54115 b54116 b54127 (by decide +kernel) e54116 e54127
  have e54113 : Deny 5 13 b54113 :=
    branchAction rule_sound _ _ 1
      0xa b54113 b54114 b54115 (by decide +kernel) e54114 e54115
  have e54105 : Deny 5 13 b54105 :=
    branchAction rule_sound _ _ 2
      0x223 b54105 b54106 b54113 (by decide +kernel) e54106 e54113
  have e54129 : Deny 5 13 b54129 := by
    apply closeAction rule_sound _ _ 64 [0x4f8de31038c42380e3243e038c80e32631e3]
    decide +kernel
  have e54141 : Deny 5 13 b54141 := by
    apply closeAction rule_sound _ _ 64 [0x4f8dc3e370e3223263102083209dc42e3]
    decide +kernel
  have e54152 : Deny 5 13 b54152 := by
    apply closeAction rule_sound _ _ 64 [0x13e37]
    decide +kernel
  have e54140 : Deny 5 13 b54140 :=
    branchAction rule_sound _ _ 2
      0x1f8 b54140 b54141 b54152 (by decide +kernel) e54141 e54152
  have e54128 : Deny 5 13 b54128 :=
    branchAction rule_sound _ _ 1
      0x8 b54128 b54129 b54140 (by decide +kernel) e54129 e54140
  have e54104 : Deny 5 13 b54104 :=
    branchAction rule_sound _ _ 2
      0x263 b54104 b54105 b54128 (by decide +kernel) e54105 e54128
  have e54072 : Deny 5 13 b54072 :=
    branchAction rule_sound _ _ 1
      0xb b54072 b54073 b54104 (by decide +kernel) e54073 e54104
  have e54004 : Deny 5 13 b54004 :=
    branchAction rule_sound _ _ 1
      0x7 b54004 b54005 b54072 (by decide +kernel) e54005 e54072
  have e54002 : Deny 5 13 b54002 :=
    branchAction rule_sound _ _ 1
      0xa b54002 b54003 b54004 (by decide +kernel) e54003 e54004
  have e53928 : Deny 5 13 b53928 :=
    branchAction rule_sound _ _ 2
      0x223 b53928 b53929 b54002 (by decide +kernel) e53929 e54002
  exact e53928
end OMA.Blocks5_13_245212.S53928
