import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S60702
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b60702 : Box := ![⟨47,62⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨1,565934718100890211112⟩,⟨239,478⟩]
private def b60703 : Box := ![⟨47,62⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨1,2⟩,⟨239,478⟩]
private def b60704 : Box := ![⟨47,62⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨3,565934718100890211106⟩,⟨239,478⟩]
private def b60705 : Box := ![⟨47,62⟩,⟨63,126⟩,⟨15,30⟩,⟨3,565934718100890211106⟩,⟨239,478⟩]
private def b60706 : Box := ![⟨47,62⟩,⟨63,126⟩,⟨15,30⟩,⟨3,6⟩,⟨239,478⟩]
private def b60707 : Box := ![⟨47,62⟩,⟨63,120⟩,⟨15,20⟩,⟨3,6⟩,⟨239,478⟩]
private def b60708 : Box := ![⟨47,53⟩,⟨63,104⟩,⟨15,20⟩,⟨3,6⟩,⟨239,478⟩]
private def b60709 : Box := ![⟨47,53⟩,⟨63,98⟩,⟨15,20⟩,⟨3,6⟩,⟨239,318⟩]
private def b60710 : Box := ![⟨47,53⟩,⟨63,76⟩,⟨15,20⟩,⟨3,6⟩,⟨239,317⟩]
private def b60711 : Box := ![⟨47,53⟩,⟨63,76⟩,⟨15,17⟩,⟨3,6⟩,⟨239,317⟩]
private def b60716 : Box := ![⟨47,53⟩,⟨63,76⟩,⟨18,20⟩,⟨3,6⟩,⟨239,317⟩]
private def b60725 : Box := ![⟨47,53⟩,⟨77,96⟩,⟨15,20⟩,⟨3,6⟩,⟨239,317⟩]
private def b60732 : Box := ![⟨47,53⟩,⟨63,98⟩,⟨15,20⟩,⟨3,6⟩,⟨319,478⟩]
private def b60733 : Box := ![⟨47,53⟩,⟨63,76⟩,⟨15,20⟩,⟨3,6⟩,⟨319,478⟩]
private def b60734 : Box := ![⟨47,53⟩,⟨63,76⟩,⟨15,17⟩,⟨3,6⟩,⟨319,478⟩]
private def b60739 : Box := ![⟨47,53⟩,⟨63,76⟩,⟨18,20⟩,⟨3,6⟩,⟨319,478⟩]
private def b60740 : Box := ![⟨47,53⟩,⟨63,76⟩,⟨18,20⟩,⟨3,4⟩,⟨319,478⟩]
private def b60741 : Box := ![⟨47,53⟩,⟨63,76⟩,⟨18,20⟩,⟨5,6⟩,⟨319,478⟩]
private def b60752 : Box := ![⟨47,53⟩,⟨77,98⟩,⟨15,20⟩,⟨3,6⟩,⟨319,478⟩]
private def b60753 : Box := ![⟨47,53⟩,⟨77,98⟩,⟨15,17⟩,⟨3,6⟩,⟨319,478⟩]
private def b60760 : Box := ![⟨47,53⟩,⟨77,98⟩,⟨18,20⟩,⟨3,6⟩,⟨319,478⟩]
private def b60767 : Box := ![⟨54,62⟩,⟨63,104⟩,⟨15,20⟩,⟨3,6⟩,⟨239,478⟩]
private def b60768 : Box := ![⟨54,62⟩,⟨63,104⟩,⟨15,20⟩,⟨3,6⟩,⟨272,346⟩]
private def b60777 : Box := ![⟨54,62⟩,⟨63,104⟩,⟨15,20⟩,⟨3,6⟩,⟨347,478⟩]
private def b60778 : Box := ![⟨54,62⟩,⟨63,78⟩,⟨15,20⟩,⟨3,6⟩,⟨347,478⟩]
private def b60779 : Box := ![⟨54,62⟩,⟨63,78⟩,⟨15,17⟩,⟨3,6⟩,⟨347,478⟩]
private def b60780 : Box := ![⟨54,57⟩,⟨63,78⟩,⟨15,17⟩,⟨3,6⟩,⟨347,478⟩]
private def b60783 : Box := ![⟨58,62⟩,⟨63,78⟩,⟨15,17⟩,⟨3,6⟩,⟨347,478⟩]
private def b60792 : Box := ![⟨54,62⟩,⟨63,78⟩,⟨18,20⟩,⟨3,6⟩,⟨347,478⟩]
private def b60795 : Box := ![⟨54,62⟩,⟨79,104⟩,⟨15,20⟩,⟨3,6⟩,⟨347,478⟩]
private def b60802 : Box := ![⟨47,62⟩,⟨63,120⟩,⟨21,30⟩,⟨3,6⟩,⟨239,478⟩]
private def b60803 : Box := ![⟨47,53⟩,⟨63,120⟩,⟨21,30⟩,⟨3,6⟩,⟨280,478⟩]
private def b60804 : Box := ![⟨47,53⟩,⟨63,114⟩,⟨21,30⟩,⟨3,4⟩,⟨281,478⟩]
private def b60805 : Box := ![⟨47,53⟩,⟨63,114⟩,⟨21,30⟩,⟨5,6⟩,⟨281,478⟩]
private def b60816 : Box := ![⟨54,62⟩,⟨63,120⟩,⟨21,30⟩,⟨3,6⟩,⟨280,478⟩]
private def b60817 : Box := ![⟨47,62⟩,⟨63,126⟩,⟨15,30⟩,⟨7,67⟩,⟨239,478⟩]
private def b60818 : Box := ![⟨47,62⟩,⟨127,1920000000000000011376⟩,⟨15,30⟩,⟨3,565934718100890211106⟩,⟨239,478⟩]
private theorem e60703 : Deny 5 13 b60703 := by
    apply closeAction rule_sound _ _ 64 [0x5e1]
    decide +kernel
private theorem e60711 : Deny 5 13 b60711 := by
    apply closeAction rule_sound _ _ 64 [0x30c90c9]
    decide +kernel
private theorem e60716 : Deny 5 13 b60716 := by
    apply closeAction rule_sound _ _ 64 [0x1f083107e032442b85ca]
    decide +kernel
private theorem e60710 : Deny 5 13 b60710 :=
    branchAction rule_sound _ _ 1
      0x9 b60710 b60711 b60716 (by decide +kernel) e60711 e60716
private theorem e60725 : Deny 5 13 b60725 := by
    apply closeAction rule_sound _ _ 64 [0x17e375f8dc40e1107e03849849]
    decide +kernel
private theorem e60709 : Deny 5 13 b60709 :=
    branchAction rule_sound _ _ 3
      0x8844 b60709 b60710 b60725 (by decide +kernel) e60710 e60725
private theorem e60734 : Deny 5 13 b60734 := by
    apply closeAction rule_sound _ _ 64 [0x30f8243e09]
    decide +kernel
private theorem e60740 : Deny 5 13 b60740 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e60741 : Deny 5 13 b60741 := by
    apply closeAction rule_sound _ _ 64 [0x7df7d70c90c928b10b]
    decide +kernel
private theorem e60739 : Deny 5 13 b60739 :=
    branchAction rule_sound _ _ 1
      0xa b60739 b60740 b60741 (by decide +kernel) e60740 e60741
private theorem e60733 : Deny 5 13 b60733 :=
    branchAction rule_sound _ _ 1
      0x9 b60733 b60734 b60739 (by decide +kernel) e60734 e60739
private theorem e60753 : Deny 5 13 b60753 := by
    apply closeAction rule_sound _ _ 64 [0x3e038470f88470e1261]
    decide +kernel
private theorem e60760 : Deny 5 13 b60760 := by
    apply closeAction rule_sound _ _ 64 [0x1fe03e032211f85ca]
    decide +kernel
private theorem e60752 : Deny 5 13 b60752 :=
    branchAction rule_sound _ _ 1
      0x9 b60752 b60753 b60760 (by decide +kernel) e60753 e60760
private theorem e60732 : Deny 5 13 b60732 :=
    branchAction rule_sound _ _ 1
      0x8 b60732 b60733 b60752 (by decide +kernel) e60733 e60752
private theorem e60708 : Deny 5 13 b60708 :=
    branchAction rule_sound _ _ 2
      0x2e1 b60708 b60709 b60732 (by decide +kernel) e60709 e60732
private theorem e60768 : Deny 5 13 b60768 := by
    apply closeAction rule_sound _ _ 64 [0x20820f8dc31c7248844]
    decide +kernel
private theorem e60780 : Deny 5 13 b60780 := by
    apply closeAction rule_sound _ _ 64 [0x30c7]
    decide +kernel
private theorem e60783 : Deny 5 13 b60783 := by
    apply closeAction rule_sound _ _ 64 [0x7f81020c4238103109e172842b8]
    decide +kernel
private theorem e60779 : Deny 5 13 b60779 :=
    branchAction rule_sound _ _ 1
      0x7 b60779 b60780 b60783 (by decide +kernel) e60780 e60783
private theorem e60792 : Deny 5 13 b60792 := by
    apply closeAction rule_sound _ _ 64 [0x7d72b8]
    decide +kernel
private theorem e60778 : Deny 5 13 b60778 :=
    branchAction rule_sound _ _ 1
      0x9 b60778 b60779 b60792 (by decide +kernel) e60779 e60792
private theorem e60795 : Deny 5 13 b60795 := by
    apply closeAction rule_sound _ _ 64 [0x825f8dc3849847844278]
    decide +kernel
private theorem e60777 : Deny 5 13 b60777 :=
    branchAction rule_sound _ _ 1
      0x8 b60777 b60778 b60795 (by decide +kernel) e60778 e60795
private theorem e60767 : Deny 5 13 b60767 :=
    branchAction rule_sound _ _ 2
      0x2f8 b60767 b60768 b60777 (by decide +kernel) e60768 e60777
private theorem e60707 : Deny 5 13 b60707 :=
    branchAction rule_sound _ _ 2
      0x1e1 b60707 b60708 b60767 (by decide +kernel) e60708 e60767
private theorem e60804 : Deny 5 13 b60804 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e60805 : Deny 5 13 b60805 := by
    apply closeAction rule_sound _ _ 64 [0x7f8ddfe1fe1f5c31ca247238]
    decide +kernel
private theorem e60803 : Deny 5 13 b60803 :=
    branchAction rule_sound _ _ 3
      0xae21 b60803 b60804 b60805 (by decide +kernel) e60804 e60805
private theorem e60816 : Deny 5 13 b60816 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e60802 : Deny 5 13 b60802 :=
    branchAction rule_sound _ _ 2
      0x1f8 b60802 b60803 b60816 (by decide +kernel) e60803 e60816
private theorem e60706 : Deny 5 13 b60706 :=
    branchAction rule_sound _ _ 2
      0x261 b60706 b60707 b60802 (by decide +kernel) e60707 e60802
private theorem e60817 : Deny 5 13 b60817 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e60705 : Deny 5 13 b60705 :=
    branchAction rule_sound _ _ 2
      0x2a3 b60705 b60706 b60817 (by decide +kernel) e60706 e60817
private theorem e60818 : Deny 5 13 b60818 := by
    apply closeAction rule_sound _ _ 64 [0x27eb8c4238]
    decide +kernel
private theorem e60704 : Deny 5 13 b60704 :=
    branchAction rule_sound _ _ 1
      0x8 b60704 b60705 b60818 (by decide +kernel) e60705 e60818
private theorem e60702 : Deny 5 13 b60702 :=
    branchAction rule_sound _ _ 2
      0x2a3 b60702 b60703 b60704 (by decide +kernel) e60703 e60704
theorem deny5_13 : Deny 5 13 ![⟨47,62⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨1,565934718100890211112⟩,⟨239,478⟩] := by
  exact e60702
end OMA.Blocks5_13_245212.S60702
