import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S33476
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b33476 : Box := ![⟨42,46⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨1,502335381913959616722⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨42,46⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨1,502335381913959616722⟩,⟨479,999999999999999999⟩] := by
  have e33476 : Deny 5 13 b33476 := by
    apply closeAction rule_sound _ _ 64 [0x7eb8cb8c80c31c38c9ac3087da32237eb8cbae32632237eb8cb8dfae32e37eb8cb1e37eb8cb8c98c27eb8c98cbe23238,0xe232388c7e02082083e07e23238ae3263202082083e232388c9e2b0eb0e32232078c9ac20831e326b0831c3087ae3263,0x20820820820f81f88c9e232388c9]
    decide +kernel
  exact e33476
end OMA.Blocks5_13_245212.S33476
