import OddPrimeBound245212
import LargeChecker245212

/-! The large-prime exclusions cover every possible support of an odd
A245212 solution on at most four different primes. -/
namespace OMA.Large245212
open OMA.Smooth245212 Finset
open scoped ArithmeticFunction.sigma
abbrev cutoff : ℕ := 1000000000000000000
abbrev Certs := ∀ q : ℕ,q=7 ∨ q=11 ∨ q=13 → Deny cutoff q start

private theorem four {p e : Fin 4 → ℕ} (cert : Certs) (hp : ∀ i,Nat.Prime (p i))
    (ord : StrictMono p) (odd : 3≤p 0) (positive : ∀ i,0<e i)
    (eq : OeisA245212.a (total p e)=(σ 1 (total p e):ℤ)) : p 3<cutoff := by
  by_contra! large
  have norm := normalized_of_eq p hp ord.injective _ eq
  have cap := OMA.OddFaces245212.cap_needed p e (fun i => (hp i).one_lt) 0 (positive 0) norm
  obtain ⟨a,b,c⟩ := OMA.OddFaces245212.small_bases hp ord odd
    ((by decide : 257≤cutoff).trans large) cap
  let q := p 2
  let r := p 3
  let f (i : Fin 3) := e i.castSucc
  have qq : q=7 ∨ q=11 ∨ q=13 := c
  have pp (i : Fin 3) : p i.castSucc=bases q i := by fin_cases i <;> simp [bases,q,a,b]
  have score : prefProd X q f*X r (some (e 3))+prefProd Y q f*Y r (some (e 3))=2 := by
    unfold normalized at norm
    rw [Fin.prod_univ_castSucc (fun i => X (p i) (some (e i))),
      Fin.prod_univ_castSucc (fun i => Y (p i) (some (e i)))] at norm
    simpa only [pp,prefProd,f,r,show Fin.last 3=(3:Fin 4) by decide] using norm
  have fact : total p e=prev q f*r^(e 3) := by
    simp [total,prev,bases,Fin.prod_univ_four,Fin.prod_univ_three,f,r,q,a,b,mul_assoc]
  have cop (i : Fin 4) (hi : i<3) : (p i).Coprime r :=
    (Nat.coprime_primes (hp i) (hp 3)).mpr (ord hi).ne
  have cm : (prev q f).Coprime r := by
    simp only [prev,total,Fin.prod_univ_three,bases,f,Matrix.cons_val_zero,Matrix.cons_val_one,
      Matrix.cons_val_two]
    have r3 : (3:ℕ).Coprime r := a ▸ cop 0 (by decide)
    have r5 : (5:ℕ).Coprime r := b ▸ cop 1 (by decide)
    exact Nat.coprime_mul_iff_left.mpr ⟨Nat.coprime_mul_iff_left.mpr
      ⟨r3.pow_left _,r5.pow_left _⟩,(cop 2 (by decide)).pow_left _⟩
  exact cert q qq f (fun i => by simp [start,Band.Contains,f]; exact positive _)
    r (e 3) (hp 3) (positive 3) large cm score (fact ▸ eq)

private theorem ordered {k : ℕ} (cert : Certs) (few : k≤4) (p e : Fin k → ℕ)
    (hp : ∀ i,Nat.Prime (p i)) (ord : StrictMono p) (odd : ∀ i,3≤p i)
    (positive : ∀ i,0<e i) (eq : OeisA245212.a (total p e)=(σ 1 (total p e):ℤ)) (i : Fin k) :
    p i<cutoff := by
  have norm := normalized_of_eq p hp ord.injective _ eq
  have cap := OMA.OddFaces245212.cap_needed p e (fun j => (hp j).one_lt) i (positive i) norm
  have tiny (u : Fin k → ℕ) (hu : ∀ j,1<u j) (bounds : ∀ j,u j≤p j)
      (small : (∏ j,OMA.OddFaces245212.limitX (u j))<2) : False := by
    have b := prod_le_prod (s:=Finset.univ) (f:=fun j => OMA.OddFaces245212.limitX (p j))
      (fun j _ => x_nonneg ((hu j).trans_le (bounds j)) none)
      (fun j _ => OMA.OddFaces245212.cap_anti (hu j) (bounds j))
    exact (cap.trans b).not_gt small
  interval_cases k
  · exact Fin.elim0 i
  · exact (tiny ![3] (by decide) (by intro j; fin_cases j; exact odd _) (by decide +kernel)).elim
  · by_contra! big
    have last : cutoff≤p 1 := big.trans (ord.monotone (Fin.le_last i))
    exact tiny ![3,cutoff] (by decide) (by intro j; fin_cases j; exact odd _; exact last) (by decide +kernel)
  · by_contra! big
    have last : cutoff≤p 2 := big.trans (ord.monotone (Fin.le_last i))
    have five : 5≤p 1 := by
      have a := odd 0; have b := ord (by decide : (0:Fin 3)<1)
      have neq : p 1≠4 := fun h => (by decide : ¬Nat.Prime 4) (h ▸ hp 1)
      omega
    exact tiny ![3,5,cutoff] (by decide) (by intro j; fin_cases j; exact odd _; exact five; exact last)
      (by decide +kernel)
  · exact (ord.monotone (Fin.le_last i)).trans_lt (four cert hp ord (odd 0) positive eq)

theorem from_certs (cert : Certs) {n : ℕ} (odd : Odd n) (few : n.primeFactors.card≤4)
    (eq : OeisA245212.a n=(σ 1 n:ℤ)) : ∀ p∈n.primeFactors,p<cutoff := by
  let S := n.primeFactors
  let p := S.orderEmbOfFin rfl
  let e (i : Fin S.card) := n.factorization (p i)
  have mem (i) : p i∈n.primeFactors := orderEmbOfFin_mem S rfl i
  have hp (i) := Nat.prime_of_mem_primeFactors (mem i)
  have op (i) : 3≤p i := by
    have h := (hp i).two_le
    have di := Nat.dvd_of_mem_primeFactors (mem i)
    have non : ¬2∣n := fun d => (Nat.not_even_iff_odd.mpr odd) (even_iff_two_dvd.mpr d)
    by_contra! lt
    have same : p i=2 := by omega
    exact non (same ▸ di)
  have ep (i) : 0<e i := (hp i).factorization_pos_of_dvd odd.pos.ne' (Nat.dvd_of_mem_primeFactors (mem i))
  have repr : total p e=n := by
    unfold total e
    exact (Fintype.prod_equiv (S.orderIsoOfFin rfl).toEquiv _
      (fun j : S => j.val^(n.factorization j.val)) (fun _ => rfl)).trans
      (Nat.prod_primeFactors_coe_pow_factorization odd.pos.ne').symm
  intro q hq
  have image : q∈Set.range p := by rw [show Set.range p=(S:Set ℕ) from range_orderEmbOfFin S rfl]; exact hq
  obtain ⟨i,rfl⟩ := image
  exact ordered cert few p e hp p.strictMono op ep (by rw [repr]; exact eq) i
end OMA.Large245212
