import FastReplay245212
import SparseDigit245212
import FastRound245212
import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S23220
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b23220 : Box := ![⟨23,30⟩,⟨15,30⟩,⟨15,1920000000000000011376⟩,⟨1,994807017543859655055⟩,⟨103,206⟩]
private def b23221 : Box := ![⟨23,30⟩,⟨15,20⟩,⟨15,1920000000000000011376⟩,⟨1,994807017543859655047⟩,⟨103,199⟩]
private def b23222 : Box := ![⟨23,30⟩,⟨15,20⟩,⟨15,30⟩,⟨1,994807017543859655044⟩,⟨103,199⟩]
private def b23223 : Box := ![⟨23,26⟩,⟨15,20⟩,⟨15,30⟩,⟨1,32⟩,⟨103,199⟩]
private def b23224 : Box := ![⟨23,26⟩,⟨15,20⟩,⟨15,30⟩,⟨1,31⟩,⟨103,135⟩]
private def b23225 : Box := ![⟨23,26⟩,⟨15,20⟩,⟨15,30⟩,⟨1,2⟩,⟨103,131⟩]
private def b23234 : Box := ![⟨23,26⟩,⟨15,20⟩,⟨15,30⟩,⟨3,31⟩,⟨103,131⟩]
private def b23241 : Box := ![⟨23,26⟩,⟨15,20⟩,⟨15,30⟩,⟨1,31⟩,⟨136,199⟩]
private def b23248 : Box := ![⟨27,30⟩,⟨15,20⟩,⟨15,30⟩,⟨1,32⟩,⟨103,199⟩]
private def b23249 : Box := ![⟨27,30⟩,⟨15,20⟩,⟨15,30⟩,⟨1,32⟩,⟨103,135⟩]
private def b23262 : Box := ![⟨27,30⟩,⟨15,20⟩,⟨15,30⟩,⟨1,32⟩,⟨136,199⟩]
private def b23269 : Box := ![⟨23,30⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨1,994807017543859655044⟩,⟨103,199⟩]
private def b23270 : Box := ![⟨23,30⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨1,2⟩,⟨103,199⟩]
private def b23277 : Box := ![⟨23,30⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655044⟩,⟨103,199⟩]
private def b23278 : Box := ![⟨23,26⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655044⟩,⟨103,199⟩]
private def b23279 : Box := ![⟨23,26⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655043⟩,⟨103,135⟩]
private def b23294 : Box := ![⟨23,26⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655043⟩,⟨136,199⟩]
private def b23295 : Box := ![⟨23,26⟩,⟨15,17⟩,⟨31,1920000000000000011376⟩,⟨3,936740088105726877821⟩,⟨137,199⟩]
private def b23306 : Box := ![⟨23,26⟩,⟨18,20⟩,⟨31,1920000000000000011376⟩,⟨3,936740088105726877821⟩,⟨137,199⟩]
private def b23321 : Box := ![⟨27,30⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655044⟩,⟨103,199⟩]
private def b23322 : Box := ![⟨27,30⟩,⟨15,17⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655044⟩,⟨123,199⟩]
private def b23323 : Box := ![⟨27,30⟩,⟨15,17⟩,⟨31,62⟩,⟨3,951409395973154368078⟩,⟨127,199⟩]
private def b23338 : Box := ![⟨27,30⟩,⟨15,17⟩,⟨63,1920000000000000011376⟩,⟨3,951409395973154368078⟩,⟨127,199⟩]
private def b23339 : Box := ![⟨27,30⟩,⟨18,20⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655044⟩,⟨123,199⟩]
private def b23340 : Box := ![⟨23,30⟩,⟨21,30⟩,⟨15,1920000000000000011376⟩,⟨1,994807017543859655047⟩,⟨103,199⟩]
private def b23341 : Box := ![⟨23,30⟩,⟨21,30⟩,⟨15,30⟩,⟨1,994807017543859655047⟩,⟨103,199⟩]
private def b23342 : Box := ![⟨23,26⟩,⟨21,30⟩,⟨15,30⟩,⟨1,36⟩,⟨103,199⟩]
private def b23343 : Box := ![⟨23,26⟩,⟨21,30⟩,⟨15,30⟩,⟨1,35⟩,⟨103,135⟩]
private def b23344 : Box := ![⟨23,26⟩,⟨21,30⟩,⟨15,30⟩,⟨1,2⟩,⟨103,131⟩]
private def b23357 : Box := ![⟨23,26⟩,⟨21,30⟩,⟨15,30⟩,⟨3,35⟩,⟨103,131⟩]
private def b23368 : Box := ![⟨23,26⟩,⟨21,30⟩,⟨15,30⟩,⟨1,35⟩,⟨136,199⟩]
private def b23369 : Box := ![⟨23,26⟩,⟨21,30⟩,⟨15,30⟩,⟨1,2⟩,⟨137,199⟩]
private def b23370 : Box := ![⟨23,26⟩,⟨21,30⟩,⟨15,30⟩,⟨1,1⟩,⟨137,199⟩]
private def b23371 : Box := ![⟨23,26⟩,⟨21,30⟩,⟨15,30⟩,⟨2,2⟩,⟨137,199⟩]
private def b23386 : Box := ![⟨23,26⟩,⟨21,30⟩,⟨15,30⟩,⟨3,33⟩,⟨137,199⟩]
private def b23401 : Box := ![⟨27,30⟩,⟨21,30⟩,⟨15,30⟩,⟨1,36⟩,⟨103,199⟩]
private def b23408 : Box := ![⟨23,30⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨1,994807017543859655047⟩,⟨103,199⟩]
theorem deny5_11 : Deny 5 11 ![⟨23,30⟩,⟨15,30⟩,⟨15,1920000000000000011376⟩,⟨1,994807017543859655055⟩,⟨103,206⟩] := by
  have e23225 : Deny 5 11 b23225 := by
    apply closeAction rule_sound _ _ 64 [0x30f61c3087d885ca]
    decide +kernel
  have e23234 : Deny 5 11 b23234 := by
    apply closeAction rule_sound _ _ 64 [0xc31c30c78c8]
    decide +kernel
  have e23224 : Deny 5 11 b23224 :=
    branchAction rule_sound _ _ 2
      0x284 b23224 b23225 b23234 (by decide +kernel) e23225 e23234
  have e23241 : Deny 5 11 b23241 := by
    apply closeAction rule_sound _ _ 64 [0x30f78c70c40f8df68c41f8df68c88c4]
    decide +kernel
  have e23223 : Deny 5 11 b23223 :=
    branchAction rule_sound _ _ 2
      0x2e3 b23223 b23224 b23241 (by decide +kernel) e23224 e23241
  have e23249 : Deny 5 11 b23249 := by
    apply closeAction rule_sound _ _ 64 [0x83109e370c31e32170c31c8284]
    decide +kernel
  have e23262 : Deny 5 11 b23262 := by
    apply closeAction rule_sound _ _ 64 [0xc38c70c3dc78c88c4]
    decide +kernel
  have e23248 : Deny 5 11 b23248 :=
    branchAction rule_sound _ _ 1
      0xb b23248 b23249 b23262 (by decide +kernel) e23249 e23262
  have e23222 : Deny 5 11 b23222 :=
    branchAction rule_sound _ _ 2
      0x1e3 b23222 b23223 b23248 (by decide +kernel) e23223 e23248
  have e23270 : Deny 5 11 b23270 := by
    apply closeAction rule_sound _ _ 64 [0x3e03888e03b621d72a2]
    decide +kernel
  have e23279 : Deny 5 11 b23279 := by
    apply closeAction rule_sound _ _ 64 [0x83887e3709cbe2107e37bc3e370c70c38c71e3263204]
    decide +kernel
  have e23295 : Deny 5 11 b23295 := by
    apply closeAction rule_sound _ _ 64 [0x72f72f8c9bc30c70c40f8dc41f81e3263]
    decide +kernel
  have e23306 : Deny 5 11 b23306 := by
    apply closeAction rule_sound _ _ 64 [0x2082708e2f8c98c41f8bc2be31038c42780c31c78c9]
    decide +kernel
  have e23294 : Deny 5 11 b23294 :=
    branchAction rule_sound _ _ 3
      0x88c4 b23294 b23295 b23306 (by decide +kernel) e23295 e23306
  have e23278 : Deny 5 11 b23278 :=
    branchAction rule_sound _ _ 2
      0x2e3 b23278 b23279 b23294 (by decide +kernel) e23279 e23294
  have e23323 : Deny 5 11 b23323 := by
    apply closeAction rule_sound _ _ 64 [0x2b2210be37bc38c90c31e32231020f8dc3888887dc42e3]
    decide +kernel
  have e23338 : Deny 5 11 b23338 := by
    apply closeAction rule_sound _ _ 64 [0x538def]
    decide +kernel
  have e23322 : Deny 5 11 b23322 :=
    branchAction rule_sound _ _ 3
      0x98c4 b23322 b23323 b23338 (by decide +kernel) e23323 e23338
  have e23339 : Deny 5 11 b23339 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e23321 : Deny 5 11 b23321 :=
    branchAction rule_sound _ _ 2
      0x238 b23321 b23322 b23339 (by decide +kernel) e23322 e23339
  have e23277 : Deny 5 11 b23277 :=
    branchAction rule_sound _ _ 1
      0x7 b23277 b23278 b23321 (by decide +kernel) e23278 e23321
  have e23269 : Deny 5 11 b23269 :=
    branchAction rule_sound _ _ 1
      0xa b23269 b23270 b23277 (by decide +kernel) e23270 e23277
  have e23221 : Deny 5 11 b23221 :=
    branchAction rule_sound _ _ 2
      0x263 b23221 b23222 b23269 (by decide +kernel) e23222 e23269
  have e23344 : Deny 5 11 b23344 := by
    apply closeAction rule_sound _ _ 64 [0x820c7109e020c7e032485ca]
    decide +kernel
  have e23357 : Deny 5 11 b23357 := by
    apply closeAction rule_sound _ _ 64 [0x20831c4278dc20c41f8dc38c98c8]
    decide +kernel
  have e23343 : Deny 5 11 b23343 :=
    branchAction rule_sound _ _ 2
      0x284 b23343 b23344 b23357 (by decide +kernel) e23344 e23357
  have e23370 : Deny 5 11 b23370 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
  have e23371 : Deny 5 11 b23371 := by
    apply closeAction rule_sound _ _ 64 [0x20f80c81f80f80c7243e031c3248]
    decide +kernel
  have e23369 : Deny 5 11 b23369 :=
    branchAction rule_sound _ _ 1
      0xa b23369 b23370 b23371 (by decide +kernel) e23370 e23371
  have e23386 : Deny 5 11 b23386 := by
    apply closeAction rule_sound _ _ 64 [0x2083207e370f8dc31e3243e370e31c38c98c8]
    decide +kernel
  have e23368 : Deny 5 11 b23368 :=
    branchAction rule_sound _ _ 3
      0xa8c4 b23368 b23369 b23386 (by decide +kernel) e23369 e23386
  have e23342 : Deny 5 11 b23342 :=
    branchAction rule_sound _ _ 2
      0x2e3 b23342 b23343 b23368 (by decide +kernel) e23343 e23368
  have e23401 : Deny 5 11 b23401 := by
    apply closeAction rule_sound _ _ 64 [0x17e375f8dc38c98c88c45f710b]
    decide +kernel
  have e23341 : Deny 5 11 b23341 :=
    branchAction rule_sound _ _ 2
      0x1e3 b23341 b23342 b23401 (by decide +kernel) e23342 e23401
  have e23408 : Deny 5 11 b23408 := by
    apply closeAction rule_sound _ _ 64 [0x25f8de20af5f8dc3e370c8209887de2107e37]
    decide +kernel
  have e23340 : Deny 5 11 b23340 :=
    branchAction rule_sound _ _ 1
      0x9 b23340 b23341 b23408 (by decide +kernel) e23341 e23408
  have e23220 : Deny 5 11 b23220 :=
    branchAction rule_sound _ _ 3
      0x88c4 b23220 b23221 b23340 (by decide +kernel) e23221 e23340
  exact e23220
end OMA.Blocks5_11_245212.S23220
