import QuickPrefix245212
import SparseDigit245212

/-! Replay unchanged certificates with a quicker proof of prefix (op 3)
leaves. If the new arithmetic test is inconclusive, the previous rule
still processes that instruction. -/
namespace OMA.PrefixRule245212
open OMA.Box245212 OMA.SparseEngine245212

def withPrefix (test : ℕ→ℕ→Box→Bool) (fallback : Advance) (p q op : ℕ) (s : Stack) :=
  if op=3 then match s with
    | [] => none
    | b::rest => if test p q b then some rest else fallback p q op s
  else fallback p q op s

theorem prefix_sound {test : ℕ→ℕ→Box→Bool}
    (good : ∀ {p q b}, test p q b=true → Deny p q b)
    {fallback : Advance} (ok : AdvanceSound fallback) : AdvanceSound (withPrefix test fallback) := by
  intro p q op s t check yes
  unfold withPrefix at check
  split_ifs at check with special
  · cases s with
    | nil => cases check
    | cons b rest =>
      dsimp only at check
      split_ifs at check with done
      · cases Option.some.inj check
        intro x hx
        exact (List.mem_cons.mp hx).elim (fun e=>e ▸ good done) (yes x)
      · exact ok p q op _ t check yes
  · exact ok p q op s t check yes

def base := FastRound245212.withSingles (FastRound245212.withRounds SparseDigit245212.act)
theorem base_sound : AdvanceSound base :=
  FastRound245212.withSingles_sound (FastRound245212.withRounds_sound SparseDigit245212.act_sound)
def quickRule := withPrefix QuickPrefix245212.quickBlock base
theorem quickRule_sound : AdvanceSound quickRule :=
  prefix_sound QuickPrefix245212.prefix_ok base_sound

end OMA.PrefixRule245212
