import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S43639
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b43639 : Box := ![⟨95,190⟩,⟨21,30⟩,⟨7,14⟩,⟨1,385519287833827895492⟩,⟨239,999999999999999999⟩]
private def b43640 : Box := ![⟨95,190⟩,⟨21,30⟩,⟨8,14⟩,⟨1,2⟩,⟨239,1255⟩]
private def b43641 : Box := ![⟨95,190⟩,⟨21,30⟩,⟨8,14⟩,⟨3,63⟩,⟨239,1255⟩]
private def b43642 : Box := ![⟨95,190⟩,⟨21,30⟩,⟨8,10⟩,⟨3,56⟩,⟨239,1253⟩]
private def b43643 : Box := ![⟨95,190⟩,⟨21,24⟩,⟨8,10⟩,⟨3,55⟩,⟨239,349⟩]
private def b43644 : Box := ![⟨95,190⟩,⟨25,30⟩,⟨8,10⟩,⟨3,55⟩,⟨239,349⟩]
private def b43645 : Box := ![⟨95,126⟩,⟨25,30⟩,⟨8,10⟩,⟨4,54⟩,⟨239,348⟩]
private def b43646 : Box := ![⟨127,190⟩,⟨25,30⟩,⟨8,10⟩,⟨4,54⟩,⟨239,348⟩]
private def b43647 : Box := ![⟨127,190⟩,⟨25,30⟩,⟨8,8⟩,⟨9,54⟩,⟨239,347⟩]
private def b43648 : Box := ![⟨127,190⟩,⟨25,30⟩,⟨9,10⟩,⟨9,54⟩,⟨239,347⟩]
private def b43649 : Box := ![⟨127,190⟩,⟨25,27⟩,⟨9,10⟩,⟨9,54⟩,⟨239,347⟩]
private def b43652 : Box := ![⟨127,190⟩,⟨28,30⟩,⟨9,10⟩,⟨9,54⟩,⟨239,347⟩]
private def b43653 : Box := ![⟨127,190⟩,⟨28,30⟩,⟨9,10⟩,⟨9,54⟩,⟨239,283⟩]
private def b43660 : Box := ![⟨127,190⟩,⟨28,30⟩,⟨9,10⟩,⟨9,54⟩,⟨284,347⟩]
private def b43667 : Box := ![⟨95,190⟩,⟨21,30⟩,⟨11,14⟩,⟨3,56⟩,⟨239,1253⟩]
private def b43668 : Box := ![⟨95,190⟩,⟨21,30⟩,⟨11,14⟩,⟨3,56⟩,⟨239,401⟩]
private def b43669 : Box := ![⟨95,190⟩,⟨21,24⟩,⟨11,14⟩,⟨3,56⟩,⟨239,401⟩]
private def b43670 : Box := ![⟨95,126⟩,⟨21,24⟩,⟨11,14⟩,⟨3,54⟩,⟨239,359⟩]
private def b43671 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨11,14⟩,⟨3,54⟩,⟨239,359⟩]
private def b43672 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨11,14⟩,⟨9,54⟩,⟨239,287⟩]
private def b43677 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨11,14⟩,⟨9,54⟩,⟨288,359⟩]
private def b43684 : Box := ![⟨95,190⟩,⟨25,30⟩,⟨11,14⟩,⟨3,56⟩,⟨239,401⟩]
private def b43685 : Box := ![⟨95,126⟩,⟨25,30⟩,⟨11,14⟩,⟨3,56⟩,⟨239,401⟩]
private def b43686 : Box := ![⟨95,126⟩,⟨25,30⟩,⟨11,14⟩,⟨3,43⟩,⟨239,299⟩]
private def b43687 : Box := ![⟨95,126⟩,⟨25,27⟩,⟨11,14⟩,⟨3,43⟩,⟨239,293⟩]
private def b43694 : Box := ![⟨95,126⟩,⟨28,30⟩,⟨11,14⟩,⟨3,43⟩,⟨239,293⟩]
private def b43701 : Box := ![⟨95,126⟩,⟨25,30⟩,⟨11,14⟩,⟨3,43⟩,⟨300,401⟩]
private def b43712 : Box := ![⟨127,190⟩,⟨25,30⟩,⟨11,14⟩,⟨3,56⟩,⟨239,401⟩]
private def b43713 : Box := ![⟨127,190⟩,⟨25,30⟩,⟨11,14⟩,⟨8,56⟩,⟨239,299⟩]
private def b43714 : Box := ![⟨127,190⟩,⟨25,27⟩,⟨11,14⟩,⟨8,56⟩,⟨239,293⟩]
private def b43715 : Box := ![⟨127,190⟩,⟨25,27⟩,⟨11,12⟩,⟨9,55⟩,⟨239,293⟩]
private def b43722 : Box := ![⟨127,190⟩,⟨25,27⟩,⟨13,14⟩,⟨9,55⟩,⟨239,293⟩]
private def b43729 : Box := ![⟨127,190⟩,⟨28,30⟩,⟨11,14⟩,⟨8,56⟩,⟨239,293⟩]
private def b43738 : Box := ![⟨127,190⟩,⟨25,30⟩,⟨11,14⟩,⟨8,56⟩,⟨300,401⟩]
private def b43739 : Box := ![⟨127,190⟩,⟨25,27⟩,⟨11,14⟩,⟨8,54⟩,⟨307,401⟩]
private def b43740 : Box := ![⟨127,190⟩,⟨25,27⟩,⟨11,12⟩,⟨8,53⟩,⟨307,401⟩]
private def b43747 : Box := ![⟨127,190⟩,⟨25,27⟩,⟨13,14⟩,⟨8,53⟩,⟨307,401⟩]
private def b43758 : Box := ![⟨127,190⟩,⟨28,30⟩,⟨11,14⟩,⟨8,54⟩,⟨307,401⟩]
private def b43759 : Box := ![⟨127,190⟩,⟨28,30⟩,⟨11,12⟩,⟨8,54⟩,⟨307,401⟩]
private def b43770 : Box := ![⟨127,190⟩,⟨28,30⟩,⟨13,14⟩,⟨8,54⟩,⟨307,401⟩]
private def b43771 : Box := ![⟨127,190⟩,⟨28,30⟩,⟨13,13⟩,⟨8,54⟩,⟨307,401⟩]
private def b43782 : Box := ![⟨127,190⟩,⟨28,30⟩,⟨14,14⟩,⟨8,54⟩,⟨307,401⟩]
private def b43783 : Box := ![⟨95,190⟩,⟨21,30⟩,⟨11,14⟩,⟨3,56⟩,⟨402,1252⟩]
private def b43784 : Box := ![⟨95,190⟩,⟨21,24⟩,⟨11,14⟩,⟨3,52⟩,⟨402,1251⟩]
private def b43785 : Box := ![⟨95,190⟩,⟨25,30⟩,⟨11,14⟩,⟨3,52⟩,⟨402,1251⟩]
private def b43786 : Box := ![⟨95,190⟩,⟨25,30⟩,⟨11,14⟩,⟨3,6⟩,⟨402,1250⟩]
private def b43787 : Box := ![⟨95,190⟩,⟨25,30⟩,⟨11,14⟩,⟨7,52⟩,⟨402,1250⟩]
private def b43788 : Box := ![⟨95,126⟩,⟨25,30⟩,⟨11,14⟩,⟨7,52⟩,⟨402,1250⟩]
private def b43791 : Box := ![⟨127,190⟩,⟨25,30⟩,⟨11,14⟩,⟨7,52⟩,⟨402,1250⟩]
private def b43792 : Box := ![⟨127,190⟩,⟨25,30⟩,⟨11,14⟩,⟨7,52⟩,⟨402,608⟩]
private def b43793 : Box := ![⟨127,190⟩,⟨25,27⟩,⟨11,14⟩,⟨7,51⟩,⟨402,608⟩]
private def b43802 : Box := ![⟨127,190⟩,⟨28,30⟩,⟨11,14⟩,⟨7,51⟩,⟨402,608⟩]
private def b43803 : Box := ![⟨127,190⟩,⟨28,30⟩,⟨11,12⟩,⟨7,51⟩,⟨402,608⟩]
private def b43814 : Box := ![⟨127,190⟩,⟨28,30⟩,⟨13,14⟩,⟨7,51⟩,⟨402,608⟩]
private def b43821 : Box := ![⟨127,190⟩,⟨25,30⟩,⟨11,14⟩,⟨7,52⟩,⟨609,1250⟩]
private def b43822 : Box := ![⟨127,190⟩,⟨25,27⟩,⟨12,14⟩,⟨7,48⟩,⟨609,1248⟩]
private def b43823 : Box := ![⟨127,190⟩,⟨28,30⟩,⟨12,14⟩,⟨7,48⟩,⟨609,1248⟩]
private def b43824 : Box := ![⟨127,190⟩,⟨28,30⟩,⟨12,12⟩,⟨7,48⟩,⟨609,1248⟩]
private def b43825 : Box := ![⟨127,190⟩,⟨28,30⟩,⟨13,14⟩,⟨7,48⟩,⟨609,1248⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨21,30⟩,⟨7,14⟩,⟨1,385519287833827895492⟩,⟨239,999999999999999999⟩] := by
  have e43640 : Deny 5 13 b43640 := by
    apply closeAction rule_sound _ _ 64 [0x29e6960]
    decide +kernel
  have e43643 : Deny 5 13 b43643 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e43645 : Deny 5 13 b43645 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e43647 : Deny 5 13 b43647 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e43649 : Deny 5 13 b43649 := by
    apply closeAction rule_sound _ _ 64 [0x190a78042b89e3]
    decide +kernel
  have e43653 : Deny 5 13 b43653 := by
    apply closeAction rule_sound _ _ 64 [0x190e70f81c22602a7]
    decide +kernel
  have e43660 : Deny 5 13 b43660 := by
    apply closeAction rule_sound _ _ 64 [0x30880899c21e78c4]
    decide +kernel
  have e43652 : Deny 5 13 b43652 :=
    branchAction rule_sound _ _ 1
      0xb b43652 b43653 b43660 (by decide +kernel) e43653 e43660
  have e43648 : Deny 5 13 b43648 :=
    branchAction rule_sound _ _ 1
      0x8 b43648 b43649 b43652 (by decide +kernel) e43649 e43652
  have e43646 : Deny 5 13 b43646 :=
    branchAction rule_sound _ _ 3
      0x99c4 b43646 b43647 b43648 (by decide +kernel) e43647 e43648
  have e43644 : Deny 5 13 b43644 :=
    branchAction rule_sound _ _ 4
      0x1f89e3 b43644 b43645 b43646 (by decide +kernel) e43645 e43646
  have e43642 : Deny 5 13 b43642 :=
    branchAction rule_sound _ _ 3
      0x8e23 b43642 b43643 b43644 (by decide +kernel) e43643 e43644
  have e43670 : Deny 5 13 b43670 := by
    apply closeAction rule_sound _ _ 64 [0x19e37da3]
    decide +kernel
  have e43672 : Deny 5 13 b43672 := by
    apply closeAction rule_sound _ _ 64 [0x197c227680a9c4]
    decide +kernel
  have e43677 : Deny 5 13 b43677 := by
    apply closeAction rule_sound _ _ 64 [0x199c3e368c79c21c4088e368c4]
    decide +kernel
  have e43671 : Deny 5 13 b43671 :=
    branchAction rule_sound _ _ 2
      0x2e7 b43671 b43672 b43677 (by decide +kernel) e43672 e43677
  have e43669 : Deny 5 13 b43669 :=
    branchAction rule_sound _ _ 3
      0x7e23 b43669 b43670 b43671 (by decide +kernel) e43670 e43671
  have e43687 : Deny 5 13 b43687 := by
    apply closeAction rule_sound _ _ 64 [0xc3e379e32670f8df68c70f8df6223]
    decide +kernel
  have e43694 : Deny 5 13 b43694 := by
    apply closeAction rule_sound _ _ 64 [0xc32430f8dc98c9]
    decide +kernel
  have e43686 : Deny 5 13 b43686 :=
    branchAction rule_sound _ _ 2
      0x204 b43686 b43687 b43694 (by decide +kernel) e43687 e43694
  have e43701 : Deny 5 13 b43701 := by
    apply closeAction rule_sound _ _ 64 [0xc3e379e32670f8df68c70f8df621f089e37d888c4]
    decide +kernel
  have e43685 : Deny 5 13 b43685 :=
    branchAction rule_sound _ _ 2
      0x2e3 b43685 b43686 b43701 (by decide +kernel) e43686 e43701
  have e43715 : Deny 5 13 b43715 := by
    apply closeAction rule_sound _ _ 64 [0x6439c3e070f880880a9e3]
    decide +kernel
  have e43722 : Deny 5 13 b43722 := by
    apply closeAction rule_sound _ _ 64 [0x1f65f29f289]
    decide +kernel
  have e43714 : Deny 5 13 b43714 :=
    branchAction rule_sound _ _ 3
      0x99e3 b43714 b43715 b43722 (by decide +kernel) e43715 e43722
  have e43729 : Deny 5 13 b43729 := by
    apply closeAction rule_sound _ _ 64 [0x820e32389c3e270e31e31e78c9]
    decide +kernel
  have e43713 : Deny 5 13 b43713 :=
    branchAction rule_sound _ _ 2
      0x204 b43713 b43714 b43729 (by decide +kernel) e43714 e43729
  have e43740 : Deny 5 13 b43740 := by
    apply closeAction rule_sound _ _ 64 [0x199c3e231c2227119e378c41f89e3]
    decide +kernel
  have e43747 : Deny 5 13 b43747 := by
    apply closeAction rule_sound _ _ 64 [0x7d96597ca80a29f2a78c9]
    decide +kernel
  have e43739 : Deny 5 13 b43739 :=
    branchAction rule_sound _ _ 2
      0x263 b43739 b43740 b43747 (by decide +kernel) e43740 e43747
  have e43759 : Deny 5 13 b43759 := by
    apply closeAction rule_sound _ _ 64 [0x643e270c70e720a9c39c3e231e31e3]
    decide +kernel
  have e43771 : Deny 5 13 b43771 := by
    apply closeAction rule_sound _ _ 64 [0x65909f1f87c780a10ae1f2a3]
    decide +kernel
  have e43782 : Deny 5 13 b43782 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
  have e43770 : Deny 5 13 b43770 :=
    branchAction rule_sound _ _ 1
      0x9 b43770 b43771 b43782 (by decide +kernel) e43771 e43782
  have e43758 : Deny 5 13 b43758 :=
    branchAction rule_sound _ _ 1
      0x9 b43758 b43759 b43770 (by decide +kernel) e43759 e43770
  have e43738 : Deny 5 13 b43738 :=
    branchAction rule_sound _ _ 3
      0x88c4 b43738 b43739 b43758 (by decide +kernel) e43739 e43758
  have e43712 : Deny 5 13 b43712 :=
    branchAction rule_sound _ _ 2
      0x2e7 b43712 b43713 b43738 (by decide +kernel) e43713 e43738
  have e43684 : Deny 5 13 b43684 :=
    branchAction rule_sound _ _ 1
      0x7 b43684 b43685 b43712 (by decide +kernel) e43685 e43712
  have e43668 : Deny 5 13 b43668 :=
    branchAction rule_sound _ _ 1
      0x8 b43668 b43669 b43684 (by decide +kernel) e43669 e43684
  have e43784 : Deny 5 13 b43784 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e43786 : Deny 5 13 b43786 := by
    apply closeAction rule_sound _ _ 64 [0x37da0]
    decide +kernel
  have e43788 : Deny 5 13 b43788 := by
    apply closeAction rule_sound _ _ 64 [0x7c2278da3]
    decide +kernel
  have e43793 : Deny 5 13 b43793 := by
    apply closeAction rule_sound _ _ 64 [0x1f0e71021f88c9678de3202278da7]
    decide +kernel
  have e43803 : Deny 5 13 b43803 := by
    apply closeAction rule_sound _ _ 64 [0x6439c3e070f82389ca9c3dc4087e378c7e27]
    decide +kernel
  have e43814 : Deny 5 13 b43814 := by
    apply closeAction rule_sound _ _ 64 [0x7c3e270e31e70f89e31c9]
    decide +kernel
  have e43802 : Deny 5 13 b43802 :=
    branchAction rule_sound _ _ 1
      0x9 b43802 b43803 b43814 (by decide +kernel) e43803 e43814
  have e43792 : Deny 5 13 b43792 :=
    branchAction rule_sound _ _ 2
      0x223 b43792 b43793 b43802 (by decide +kernel) e43793 e43802
  have e43822 : Deny 5 13 b43822 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e43824 : Deny 5 13 b43824 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e43825 : Deny 5 13 b43825 := by
    apply closeAction rule_sound _ _ 64 [0x197c3e27802238809e272a77c22788c7]
    decide +kernel
  have e43823 : Deny 5 13 b43823 :=
    branchAction rule_sound _ _ 1
      0x9 b43823 b43824 b43825 (by decide +kernel) e43824 e43825
  have e43821 : Deny 5 13 b43821 :=
    branchAction rule_sound _ _ 4
      0x238da3 b43821 b43822 b43823 (by decide +kernel) e43822 e43823
  have e43791 : Deny 5 13 b43791 :=
    branchAction rule_sound _ _ 1
      0xb b43791 b43792 b43821 (by decide +kernel) e43792 e43821
  have e43787 : Deny 5 13 b43787 :=
    branchAction rule_sound _ _ 1
      0x7 b43787 b43788 b43791 (by decide +kernel) e43788 e43791
  have e43785 : Deny 5 13 b43785 :=
    branchAction rule_sound _ _ 2
      0x2b8 b43785 b43786 b43787 (by decide +kernel) e43786 e43787
  have e43783 : Deny 5 13 b43783 :=
    branchAction rule_sound _ _ 3
      0x8e23 b43783 b43784 b43785 (by decide +kernel) e43784 e43785
  have e43667 : Deny 5 13 b43667 :=
    branchAction rule_sound _ _ 2
      0x2f8 b43667 b43668 b43783 (by decide +kernel) e43668 e43783
  have e43641 : Deny 5 13 b43641 :=
    branchAction rule_sound _ _ 3
      0x9e23 b43641 b43642 b43667 (by decide +kernel) e43642 e43667
  have e43639 : Deny 5 13 b43639 :=
    branchAction rule_sound _ _ 4
      0x2b8da3 b43639 b43640 b43641 (by decide +kernel) e43640 e43641
  exact e43639
end OMA.Blocks5_13_245212.S43639
