import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S65761
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b65761 : Box := ![⟨95,190⟩,⟨31,41⟩,⟨15,30⟩,⟨1,68⟩,⟨361,722⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨31,41⟩,⟨15,30⟩,⟨1,68⟩,⟨361,722⟩] := by
  have e65761 : Deny 5 13 b65761 := by
    apply closeAction rule_sound _ _ 64 [0x83109e03e03207289e1f0972385c70f80c90c80c3e3620724a7d72b87c20c9e032030c81d728a2442c81e02602972a3,0x1f7d72b80827e70f80f89c81e026023809f]
    decide +kernel
  exact e65761
end OMA.Blocks5_13_245212.S65761
