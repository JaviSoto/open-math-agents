import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S40136
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b40136 : Box := ![⟨63,94⟩,⟨21,30⟩,⟨15,30⟩,⟨3,50⟩,⟨165,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨21,30⟩,⟨15,30⟩,⟨3,50⟩,⟨165,233⟩] := by
  have e40136 : Deny 5 13 b40136 := by
    apply closeAction rule_sound _ _ 64 [0xd840c3243d870c4087e37d8810be0a8c97c30f8dc9087088d840c3243e361c31021f8df620be0a7f8de32768c78c88c4,0x1c810b24729f0c31c30c71ca0c38c70dfe37da31f78c722311f5f8dc32430c71c30c70c3d871c82842df0dfe37d87088,0xc3e361c72045f8dd7e370c91d7e370c80c90c31c72042c30f8dc90f8df61c31021f8df62040c32432030f8dc90f8df6,0x2c42385f8dc31c30c72430c70c3e371c92045f8dc3e370c7243e370c70c31c92042c97c20c42780c31c72972830c80c9,0x7d7e37117e370c80c31c3207097e375f8dc32091c4]
    decide +kernel
  exact e40136
end OMA.Blocks5_13_245212.S40136
