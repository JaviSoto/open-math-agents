import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S35591
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b35591 : Box := ![⟨47,94⟩,⟨15,30⟩,⟨7,14⟩,⟨3,49⟩,⟨59,77⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,94⟩,⟨15,30⟩,⟨7,14⟩,⟨3,49⟩,⟨59,77⟩] := by
  have e35591 : Deny 5 13 b35591 := by
    apply closeAction rule_sound _ _ 64 [0xf8de02602a325f0e3108e038c90c38c70f88c98c80c31c32430f8dc90f8df61f820a0c3e378c80f8de32632631e3204,0xc31c3de0243df6808103e37803de6808dc39e02430c91e010b808283e038c90e32430e3243e232632039c31c3e37808,0xe370f8dc38c70e32030e32038c98c78c40820c4238dc3247dc42e32020a6804238dc38090f70c80c91c40820c91f710b,0x842f80c32030c91c40832770f70c91c42c8283e378c40e3108e038c90c38c88c80c32032430c820a8c98c70820c9107,0x820c91f710be03e371038042380c70e026020a8c97c20c41f8dc3e370e31e3223109e02083204278dc20c4238dc3247,0x82083e370c8247108e370820c9107e378c4083109e370c38c88c78c4238083e202770832370c91c4]
    decide +kernel
  exact e35591
end OMA.Blocks5_13_245212.S35591
