import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S16314
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b16314 : Box := ![⟨47,94⟩,⟨11,14⟩,⟨9,1920000000000000011376⟩,⟨1,1495788262370540860443⟩,⟨111,768⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,94⟩,⟨11,14⟩,⟨9,1920000000000000011376⟩,⟨1,1495788262370540860443⟩,⟨111,768⟩] := by
  have e16314 : Deny 5 13 b16314 := by
    apply closeAction rule_sound _ _ 64 [0xbdd8c9778df6be22a31c42dd75528a7778c90888c4777da3107e37da325cbddbe3278df68c70a22822368c4087e37da3,0x72f709bdde37daf8c9088da311cbdc26f755dc40ef8841f888a778df68c88c972f709]
    decide +kernel
  exact e16314
end OMA.Blocks5_13_245212.S16314
