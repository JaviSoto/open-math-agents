import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S45574
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b45574 : Box := ![⟨95,190⟩,⟨15,20⟩,⟨15,30⟩,⟨1,900178041543026711627⟩,⟨239,999999999999999999⟩]
private def b45575 : Box := ![⟨95,190⟩,⟨15,17⟩,⟨15,30⟩,⟨1,67⟩,⟨239,552⟩]
private def b45576 : Box := ![⟨95,190⟩,⟨18,20⟩,⟨15,30⟩,⟨1,67⟩,⟨239,552⟩]
private def b45577 : Box := ![⟨95,190⟩,⟨18,20⟩,⟨15,30⟩,⟨1,2⟩,⟨239,551⟩]
private def b45578 : Box := ![⟨95,190⟩,⟨18,20⟩,⟨15,30⟩,⟨3,61⟩,⟨239,551⟩]
private def b45579 : Box := ![⟨95,126⟩,⟨18,20⟩,⟨15,30⟩,⟨3,61⟩,⟨239,551⟩]
private def b45580 : Box := ![⟨95,126⟩,⟨18,18⟩,⟨20,30⟩,⟨3,48⟩,⟨239,315⟩]
private def b45581 : Box := ![⟨95,126⟩,⟨19,20⟩,⟨20,30⟩,⟨3,48⟩,⟨239,315⟩]
private def b45582 : Box := ![⟨95,126⟩,⟨19,20⟩,⟨20,24⟩,⟨3,48⟩,⟨239,313⟩]
private def b45587 : Box := ![⟨95,126⟩,⟨19,20⟩,⟨25,30⟩,⟨3,48⟩,⟨239,313⟩]
private def b45596 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨15,30⟩,⟨3,61⟩,⟨239,551⟩]
private def b45597 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨15,20⟩,⟨3,61⟩,⟨239,551⟩]
private def b45598 : Box := ![⟨127,190⟩,⟨18,18⟩,⟨15,20⟩,⟨7,56⟩,⟨239,320⟩]
private def b45599 : Box := ![⟨127,190⟩,⟨19,20⟩,⟨15,20⟩,⟨7,56⟩,⟨239,320⟩]
private def b45600 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨15,20⟩,⟨8,56⟩,⟨239,317⟩]
private def b45605 : Box := ![⟨153,190⟩,⟨19,20⟩,⟨15,20⟩,⟨8,56⟩,⟨239,317⟩]
private def b45616 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨21,30⟩,⟨3,61⟩,⟨239,551⟩]
private def b45617 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨21,30⟩,⟨3,61⟩,⟨239,333⟩]
private def b45618 : Box := ![⟨127,152⟩,⟨18,20⟩,⟨21,30⟩,⟨3,61⟩,⟨239,331⟩]
private def b45619 : Box := ![⟨127,152⟩,⟨18,18⟩,⟨21,30⟩,⟨3,53⟩,⟨239,331⟩]
private def b45622 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨21,30⟩,⟨3,53⟩,⟨239,331⟩]
private def b45623 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨21,30⟩,⟨3,53⟩,⟨239,277⟩]
private def b45624 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨21,24⟩,⟨3,53⟩,⟨239,277⟩]
private def b45629 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨25,30⟩,⟨3,53⟩,⟨239,277⟩]
private def b45630 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨25,30⟩,⟨3,6⟩,⟨239,277⟩]
private def b45633 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨25,30⟩,⟨7,53⟩,⟨239,277⟩]
private def b45642 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨21,30⟩,⟨3,53⟩,⟨278,331⟩]
private def b45643 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨21,24⟩,⟨3,52⟩,⟨281,331⟩]
private def b45648 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨25,30⟩,⟨3,52⟩,⟨281,331⟩]
private def b45649 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨25,30⟩,⟨3,6⟩,⟨281,331⟩]
private def b45652 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨25,30⟩,⟨7,52⟩,⟨281,331⟩]
private def b45661 : Box := ![⟨153,190⟩,⟨18,20⟩,⟨21,30⟩,⟨3,61⟩,⟨239,331⟩]
private def b45662 : Box := ![⟨153,190⟩,⟨18,18⟩,⟨21,30⟩,⟨8,61⟩,⟨239,331⟩]
private def b45671 : Box := ![⟨153,190⟩,⟨19,20⟩,⟨21,30⟩,⟨8,61⟩,⟨239,331⟩]
private def b45672 : Box := ![⟨153,190⟩,⟨19,20⟩,⟨21,30⟩,⟨8,61⟩,⟨239,277⟩]
private def b45673 : Box := ![⟨153,190⟩,⟨19,20⟩,⟨21,24⟩,⟨9,61⟩,⟨239,277⟩]
private def b45680 : Box := ![⟨153,190⟩,⟨19,20⟩,⟨25,30⟩,⟨9,61⟩,⟨239,277⟩]
private def b45687 : Box := ![⟨153,190⟩,⟨19,20⟩,⟨21,30⟩,⟨8,61⟩,⟨278,331⟩]
private def b45688 : Box := ![⟨153,190⟩,⟨19,20⟩,⟨21,24⟩,⟨8,59⟩,⟨281,331⟩]
private def b45695 : Box := ![⟨153,190⟩,⟨19,20⟩,⟨25,30⟩,⟨8,59⟩,⟨281,331⟩]
private def b45704 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨21,30⟩,⟨3,61⟩,⟨334,551⟩]
private def b45705 : Box := ![⟨127,190⟩,⟨18,18⟩,⟨21,30⟩,⟨3,57⟩,⟨334,551⟩]
private def b45706 : Box := ![⟨127,190⟩,⟨19,20⟩,⟨21,30⟩,⟨3,57⟩,⟨334,551⟩]
private def b45707 : Box := ![⟨127,190⟩,⟨19,20⟩,⟨21,30⟩,⟨3,6⟩,⟨334,551⟩]
private def b45708 : Box := ![⟨127,190⟩,⟨19,20⟩,⟨21,30⟩,⟨7,57⟩,⟨334,551⟩]
private def b45709 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨21,30⟩,⟨7,57⟩,⟨334,551⟩]
private def b45714 : Box := ![⟨153,190⟩,⟨19,20⟩,⟨21,30⟩,⟨7,57⟩,⟨334,551⟩]
private def b45715 : Box := ![⟨153,190⟩,⟨19,20⟩,⟨21,30⟩,⟨8,57⟩,⟨334,415⟩]
private def b45716 : Box := ![⟨153,190⟩,⟨19,20⟩,⟨21,24⟩,⟨8,57⟩,⟨337,409⟩]
private def b45721 : Box := ![⟨153,190⟩,⟨19,20⟩,⟨25,30⟩,⟨8,57⟩,⟨337,409⟩]
private def b45728 : Box := ![⟨153,190⟩,⟨19,20⟩,⟨21,30⟩,⟨8,57⟩,⟨416,551⟩]
private theorem e45575 : Deny 5 13 b45575 := by
    apply closeAction rule_sound _ _ 64 [0x778df6d23]
    decide +kernel
private theorem e45577 : Deny 5 13 b45577 := by
    apply closeAction rule_sound _ _ 64 [0x29a0]
    decide +kernel
private theorem e45580 : Deny 5 13 b45580 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e45582 : Deny 5 13 b45582 := by
    apply closeAction rule_sound _ _ 64 [0x30881021f8de3]
    decide +kernel
private theorem e45587 : Deny 5 13 b45587 := by
    apply closeAction rule_sound _ _ 64 [0xc3e37203e378c70c4088e378c7]
    decide +kernel
private theorem e45581 : Deny 5 13 b45581 :=
    branchAction rule_sound _ _ 2
      0x244 b45581 b45582 b45587 (by decide +kernel) e45582 e45587
private theorem e45579 : Deny 5 13 b45579 :=
    branchAction rule_sound _ _ 4
      0x238da3 b45579 b45580 b45581 (by decide +kernel) e45580 e45581
private theorem e45598 : Deny 5 13 b45598 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e45600 : Deny 5 13 b45600 := by
    apply closeAction rule_sound _ _ 64 [0xc2202278da3]
    decide +kernel
private theorem e45605 : Deny 5 13 b45605 := by
    apply closeAction rule_sound _ _ 64 [0x190e70f81c3e272599e01021f89e02782a7]
    decide +kernel
private theorem e45599 : Deny 5 13 b45599 :=
    branchAction rule_sound _ _ 3
      0x79c4 b45599 b45600 b45605 (by decide +kernel) e45600 e45605
private theorem e45597 : Deny 5 13 b45597 :=
    branchAction rule_sound _ _ 4
      0x2389e3 b45597 b45598 b45599 (by decide +kernel) e45598 e45599
private theorem e45619 : Deny 5 13 b45619 := by
    apply closeAction rule_sound _ _ 64 [0xe3119e37da3107e37da7]
    decide +kernel
private theorem e45624 : Deny 5 13 b45624 := by
    apply closeAction rule_sound _ _ 64 [0xc3e089c38c79e3]
    decide +kernel
private theorem e45630 : Deny 5 13 b45630 := by
    apply closeAction rule_sound _ _ 64 [0xc3e368089e0]
    decide +kernel
private theorem e45633 : Deny 5 13 b45633 := by
    apply closeAction rule_sound _ _ 64 [0x1d0f8dc3203e03e081ca]
    decide +kernel
private theorem e45629 : Deny 5 13 b45629 :=
    branchAction rule_sound _ _ 1
      0xa b45629 b45630 b45633 (by decide +kernel) e45630 e45633
private theorem e45623 : Deny 5 13 b45623 :=
    branchAction rule_sound _ _ 1
      0x9 b45623 b45624 b45629 (by decide +kernel) e45624 e45629
private theorem e45643 : Deny 5 13 b45643 := by
    apply closeAction rule_sound _ _ 64 [0x39d9e37da31c4088e379e3]
    decide +kernel
private theorem e45649 : Deny 5 13 b45649 := by
    apply closeAction rule_sound _ _ 64 [0x31022389e0]
    decide +kernel
private theorem e45652 : Deny 5 13 b45652 := by
    apply closeAction rule_sound _ _ 64 [0x1d0c3e362030881ca]
    decide +kernel
private theorem e45648 : Deny 5 13 b45648 :=
    branchAction rule_sound _ _ 1
      0xa b45648 b45649 b45652 (by decide +kernel) e45649 e45652
private theorem e45642 : Deny 5 13 b45642 :=
    branchAction rule_sound _ _ 3
      0x98c4 b45642 b45643 b45648 (by decide +kernel) e45643 e45648
private theorem e45622 : Deny 5 13 b45622 :=
    branchAction rule_sound _ _ 1
      0xb b45622 b45623 b45642 (by decide +kernel) e45623 e45642
private theorem e45618 : Deny 5 13 b45618 :=
    branchAction rule_sound _ _ 2
      0x223 b45618 b45619 b45622 (by decide +kernel) e45619 e45622
private theorem e45662 : Deny 5 13 b45662 := by
    apply closeAction rule_sound _ _ 64 [0x7670c40f89e3109e231c40e7119e37da3107e278c42789e3]
    decide +kernel
private theorem e45673 : Deny 5 13 b45673 := by
    apply closeAction rule_sound _ _ 64 [0x838c42389c3e370e78c88c79e3]
    decide +kernel
private theorem e45680 : Deny 5 13 b45680 := by
    apply closeAction rule_sound _ _ 64 [0x20820e7248107e37]
    decide +kernel
private theorem e45672 : Deny 5 13 b45672 :=
    branchAction rule_sound _ _ 2
      0x267 b45672 b45673 b45680 (by decide +kernel) e45673 e45680
private theorem e45688 : Deny 5 13 b45688 := by
    apply closeAction rule_sound _ _ 64 [0xf80f82270c3e37d888c79e3]
    decide +kernel
private theorem e45695 : Deny 5 13 b45695 := by
    apply closeAction rule_sound _ _ 64 [0x1d9dd743e0380880a9ca8c7]
    decide +kernel
private theorem e45687 : Deny 5 13 b45687 :=
    branchAction rule_sound _ _ 3
      0x98c4 b45687 b45688 b45695 (by decide +kernel) e45688 e45695
private theorem e45671 : Deny 5 13 b45671 :=
    branchAction rule_sound _ _ 1
      0xb b45671 b45672 b45687 (by decide +kernel) e45672 e45687
private theorem e45661 : Deny 5 13 b45661 :=
    branchAction rule_sound _ _ 2
      0x227 b45661 b45662 b45671 (by decide +kernel) e45662 e45671
private theorem e45617 : Deny 5 13 b45617 :=
    branchAction rule_sound _ _ 2
      0x1c4 b45617 b45618 b45661 (by decide +kernel) e45618 e45661
private theorem e45705 : Deny 5 13 b45705 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e45707 : Deny 5 13 b45707 := by
    apply closeAction rule_sound _ _ 64 [0x29a0]
    decide +kernel
private theorem e45709 : Deny 5 13 b45709 := by
    apply closeAction rule_sound _ _ 64 [0xc2204778df68c41f8da3]
    decide +kernel
private theorem e45716 : Deny 5 13 b45716 := by
    apply closeAction rule_sound _ _ 64 [0xe70f8df68c71022389e3]
    decide +kernel
private theorem e45721 : Deny 5 13 b45721 := by
    apply closeAction rule_sound _ _ 64 [0x1d9c3e039e325de37d888c7]
    decide +kernel
private theorem e45715 : Deny 5 13 b45715 :=
    branchAction rule_sound _ _ 2
      0x244 b45715 b45716 b45721 (by decide +kernel) e45716 e45721
private theorem e45728 : Deny 5 13 b45728 := by
    apply closeAction rule_sound _ _ 64 [0x1d0f89e32670f8da31c2238da3]
    decide +kernel
private theorem e45714 : Deny 5 13 b45714 :=
    branchAction rule_sound _ _ 2
      0x2e7 b45714 b45715 b45728 (by decide +kernel) e45715 e45728
private theorem e45708 : Deny 5 13 b45708 :=
    branchAction rule_sound _ _ 1
      0x7 b45708 b45709 b45714 (by decide +kernel) e45709 e45714
private theorem e45706 : Deny 5 13 b45706 :=
    branchAction rule_sound _ _ 1
      0xa b45706 b45707 b45708 (by decide +kernel) e45707 e45708
private theorem e45704 : Deny 5 13 b45704 :=
    branchAction rule_sound _ _ 2
      0x223 b45704 b45705 b45706 (by decide +kernel) e45705 e45706
private theorem e45616 : Deny 5 13 b45616 :=
    branchAction rule_sound _ _ 1
      0xb b45616 b45617 b45704 (by decide +kernel) e45617 e45704
private theorem e45596 : Deny 5 13 b45596 :=
    branchAction rule_sound _ _ 1
      0x9 b45596 b45597 b45616 (by decide +kernel) e45597 e45616
private theorem e45578 : Deny 5 13 b45578 :=
    branchAction rule_sound _ _ 1
      0x7 b45578 b45579 b45596 (by decide +kernel) e45579 e45596
private theorem e45576 : Deny 5 13 b45576 :=
    branchAction rule_sound _ _ 3
      0xae23 b45576 b45577 b45578 (by decide +kernel) e45577 e45578
private theorem e45574 : Deny 5 13 b45574 :=
    branchAction rule_sound _ _ 3
      0x8e23 b45574 b45575 b45576 (by decide +kernel) e45575 e45576
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨15,20⟩,⟨15,30⟩,⟨1,900178041543026711627⟩,⟨239,999999999999999999⟩] := by
  exact e45574
end OMA.Blocks5_13_245212.S45574
