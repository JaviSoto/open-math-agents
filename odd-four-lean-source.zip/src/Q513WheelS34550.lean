import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S34550
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b34550 : Box := ![⟨47,94⟩,⟨33,1920000000000000011376⟩,⟨3,6⟩,⟨1,1090612244897959190168⟩,⟨119,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,94⟩,⟨33,1920000000000000011376⟩,⟨3,6⟩,⟨1,1090612244897959190168⟩,⟨119,999999999999999999⟩] := by
  have e34550 : Deny 5 13 b34550 := by
    apply closeAction rule_sound _ _ 64 [0x6ab8c8adbadbe37da32388c80a12b68c78c42db6db4cae042b829329be37d496f8df68c88c40841f8da32234e12b8da3,0xe2321aae31021f8df6d631d3e37db5d212b68daadbae322b6db4db4cae211e12a12a321aac46eb8c4238d6325384a6ab,0x1aadbae321bac30f88c711be378c41f88c86f8de32022446b8df6d63107]
    decide +kernel
  exact e34550
end OMA.Blocks5_13_245212.S34550
