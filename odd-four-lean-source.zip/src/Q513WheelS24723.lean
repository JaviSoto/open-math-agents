import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S24723
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b24723 : Box := ![⟨38,46⟩,⟨42,62⟩,⟨15,30⟩,⟨3,6⟩,⟨127,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨38,46⟩,⟨42,62⟩,⟨15,30⟩,⟨3,6⟩,⟨127,233⟩] := by
  have e24723 : Deny 5 13 b24723 := by
    apply closeAction rule_sound _ _ 64 [0x2442c30c70c3e371c9117dc31c30c72442c80c31c37f8df61f72440f70c70c31c910b0c3e372440f8df6107e081c910b,0x1c30c72445f8dc20c727710b7c3e031c32030f81c91020c42380f80c72442ca5ca2075f8dc31c30c80c7244097e370c7,0x10b7d70f8243e361ca117e3610ae080dfe3725fe37d87102238d872445f8dc47d75c31c710ae172842385f8dc3e370c8,0x2030c81c30c72442c3088087df61030f71c3dc80c21f72442f82070c3e090f6203e37d8711f5c31ca5ca0c3203e371c9,0x1c31c9117083108e0324710be170c70c3e362070c3e082445c30c81c42c82972830c80c3e37d88e070c21f82440f8dc3,0x1f083108e03e032075c3]
    decide +kernel
  exact e24723
end OMA.Blocks5_13_245212.S24723
