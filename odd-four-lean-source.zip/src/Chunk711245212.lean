import FastReplay245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks7_11_245212
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def b0 : Box := ![⟨2,5824⟩,⟨1,5824⟩,⟨1,5824⟩,⟨1,5824⟩,⟨12,26⟩]
private def b1 : Box := ![⟨5,5824⟩,⟨1,2⟩,⟨1,5824⟩,⟨1,5824⟩,⟨13,23⟩]
private def b2 : Box := ![⟨5,5824⟩,⟨3,5824⟩,⟨1,5824⟩,⟨1,5824⟩,⟨13,23⟩]
private def b3 : Box := ![⟨6,12⟩,⟨3,5824⟩,⟨1,5824⟩,⟨1,5824⟩,⟨13,23⟩]
private def b6 : Box := ![⟨13,5824⟩,⟨3,5824⟩,⟨1,5824⟩,⟨1,5824⟩,⟨13,23⟩]
private def b7 : Box := ![⟨13,5824⟩,⟨3,6⟩,⟨2,5824⟩,⟨1,5824⟩,⟨13,23⟩]
private def b8 : Box := ![⟨16,32⟩,⟨3,6⟩,⟨4,5824⟩,⟨4,5824⟩,⟨13,16⟩]
private def b11 : Box := ![⟨33,5824⟩,⟨3,6⟩,⟨4,5824⟩,⟨4,5824⟩,⟨13,16⟩]
private def b12 : Box := ![⟨33,5824⟩,⟨3,4⟩,⟨5,5824⟩,⟨4,5824⟩,⟨13,13⟩]
private def b29 : Box := ![⟨33,5824⟩,⟨5,6⟩,⟨5,5824⟩,⟨4,5824⟩,⟨13,13⟩]
private def b30 : Box := ![⟨33,5824⟩,⟨5,6⟩,⟨5,5824⟩,⟨4,8⟩,⟨13,13⟩]
private def b47 : Box := ![⟨33,5824⟩,⟨5,6⟩,⟨5,5824⟩,⟨9,5824⟩,⟨13,13⟩]
private def b48 : Box := ![⟨33,5824⟩,⟨5,6⟩,⟨5,10⟩,⟨9,5824⟩,⟨13,13⟩]
private def b59 : Box := ![⟨33,5824⟩,⟨5,6⟩,⟨11,5824⟩,⟨9,5824⟩,⟨13,13⟩]
private def b60 : Box := ![⟨33,66⟩,⟨5,6⟩,⟨11,5824⟩,⟨9,5824⟩,⟨13,13⟩]
private def b111 : Box := ![⟨67,5824⟩,⟨5,6⟩,⟨11,5824⟩,⟨9,5824⟩,⟨13,13⟩]
private def b184 : Box := ![⟨13,5824⟩,⟨7,5824⟩,⟨2,5824⟩,⟨1,5824⟩,⟨13,23⟩]
private def b185 : Box := ![⟨13,5824⟩,⟨7,5824⟩,⟨2,5824⟩,⟨1,2⟩,⟨13,23⟩]
private def b214 : Box := ![⟨13,5824⟩,⟨7,5824⟩,⟨2,5824⟩,⟨3,5824⟩,⟨13,23⟩]
private def b215 : Box := ![⟨13,26⟩,⟨7,5824⟩,⟨2,5824⟩,⟨3,5824⟩,⟨13,23⟩]
private def b216 : Box := ![⟨13,26⟩,⟨7,5824⟩,⟨3,6⟩,⟨3,5824⟩,⟨13,18⟩]
private def b245 : Box := ![⟨13,26⟩,⟨7,5824⟩,⟨7,5824⟩,⟨3,5824⟩,⟨13,18⟩]
private def b246 : Box := ![⟨13,26⟩,⟨7,5824⟩,⟨7,5824⟩,⟨3,6⟩,⟨13,17⟩]
private def b247 : Box := ![⟨13,17⟩,⟨12,5824⟩,⟨7,4769⟩,⟨3,6⟩,⟨13,15⟩]
private def b250 : Box := ![⟨18,26⟩,⟨12,5824⟩,⟨7,4769⟩,⟨3,6⟩,⟨13,15⟩]
private def b251 : Box := ![⟨18,26⟩,⟨12,24⟩,⟨8,4768⟩,⟨3,6⟩,⟨13,13⟩]
private def b268 : Box := ![⟨18,26⟩,⟨25,5824⟩,⟨8,4768⟩,⟨3,6⟩,⟨13,13⟩]
private def b269 : Box := ![⟨18,26⟩,⟨25,5824⟩,⟨8,16⟩,⟨3,6⟩,⟨13,13⟩]
private def b282 : Box := ![⟨18,26⟩,⟨25,5824⟩,⟨17,4768⟩,⟨3,6⟩,⟨13,13⟩]
private def b283 : Box := ![⟨18,26⟩,⟨25,5824⟩,⟨17,4768⟩,⟨3,4⟩,⟨13,13⟩]
private def b298 : Box := ![⟨18,26⟩,⟨25,5824⟩,⟨17,4768⟩,⟨5,6⟩,⟨13,13⟩]
private def b299 : Box := ![⟨18,21⟩,⟨25,5824⟩,⟨17,4768⟩,⟨5,6⟩,⟨13,13⟩]
private def b316 : Box := ![⟨22,26⟩,⟨25,5824⟩,⟨17,4768⟩,⟨5,6⟩,⟨13,13⟩]
private def b317 : Box := ![⟨22,26⟩,⟨25,50⟩,⟨17,4768⟩,⟨5,6⟩,⟨13,13⟩]
private def b404 : Box := ![⟨22,26⟩,⟨51,5824⟩,⟨17,4768⟩,⟨5,6⟩,⟨13,13⟩]
private def b419 : Box := ![⟨13,26⟩,⟨7,5824⟩,⟨7,5824⟩,⟨7,5824⟩,⟨13,17⟩]
private def b420 : Box := ![⟨13,26⟩,⟨7,14⟩,⟨7,5824⟩,⟨7,5824⟩,⟨13,17⟩]
private def b421 : Box := ![⟨13,17⟩,⟨7,14⟩,⟨7,5824⟩,⟨7,5483⟩,⟨13,15⟩]
private def b424 : Box := ![⟨18,26⟩,⟨7,14⟩,⟨7,5824⟩,⟨7,5483⟩,⟨13,15⟩]
private def b425 : Box := ![⟨18,26⟩,⟨7,14⟩,⟨7,14⟩,⟨7,5483⟩,⟨13,13⟩]
private def b430 : Box := ![⟨18,26⟩,⟨7,14⟩,⟨15,5824⟩,⟨7,5483⟩,⟨13,13⟩]
private def b431 : Box := ![⟨18,26⟩,⟨7,14⟩,⟨15,5824⟩,⟨7,14⟩,⟨13,13⟩]
private def b466 : Box := ![⟨18,26⟩,⟨7,14⟩,⟨15,5824⟩,⟨15,5483⟩,⟨13,13⟩]
private def b467 : Box := ![⟨18,26⟩,⟨7,9⟩,⟨15,5824⟩,⟨15,5483⟩,⟨13,13⟩]
private def b488 : Box := ![⟨18,26⟩,⟨10,14⟩,⟨15,5824⟩,⟨15,5483⟩,⟨13,13⟩]
private def b565 : Box := ![⟨13,26⟩,⟨15,5824⟩,⟨7,5824⟩,⟨7,5824⟩,⟨13,17⟩]
private def b566 : Box := ![⟨13,26⟩,⟨15,5824⟩,⟨7,5824⟩,⟨7,5824⟩,⟨13,14⟩]
private def b567 : Box := ![⟨13,17⟩,⟨15,5824⟩,⟨7,5824⟩,⟨7,5824⟩,⟨13,13⟩]
private def b568 : Box := ![⟨13,17⟩,⟨15,5824⟩,⟨7,14⟩,⟨7,5824⟩,⟨13,13⟩]
private def b603 : Box := ![⟨13,17⟩,⟨15,5824⟩,⟨15,5824⟩,⟨7,5824⟩,⟨13,13⟩]
private def b604 : Box := ![⟨13,17⟩,⟨15,5824⟩,⟨15,5824⟩,⟨7,14⟩,⟨13,13⟩]
private def b693 : Box := ![⟨13,17⟩,⟨15,5824⟩,⟨15,5824⟩,⟨15,5824⟩,⟨13,13⟩]
private def b694 : Box := ![⟨13,17⟩,⟨15,30⟩,⟨15,5824⟩,⟨15,5824⟩,⟨13,13⟩]
private def b695 : Box := ![⟨13,14⟩,⟨15,30⟩,⟨15,5824⟩,⟨15,5491⟩,⟨13,13⟩]
private def b708 : Box := ![⟨15,17⟩,⟨15,30⟩,⟨15,5824⟩,⟨15,5491⟩,⟨13,13⟩]
private def b709 : Box := ![⟨15,17⟩,⟨15,30⟩,⟨15,30⟩,⟨15,5491⟩,⟨13,13⟩]
private def b730 : Box := ![⟨15,17⟩,⟨15,30⟩,⟨31,5824⟩,⟨15,5491⟩,⟨13,13⟩]
private def b809 : Box := ![⟨13,17⟩,⟨31,5824⟩,⟨15,5824⟩,⟨15,5824⟩,⟨13,13⟩]
private def b810 : Box := ![⟨13,14⟩,⟨31,5824⟩,⟨15,5824⟩,⟨15,5824⟩,⟨13,13⟩]
private def b839 : Box := ![⟨15,17⟩,⟨31,5824⟩,⟨15,5824⟩,⟨15,5824⟩,⟨13,13⟩]
private def b840 : Box := ![⟨15,17⟩,⟨31,5824⟩,⟨15,30⟩,⟨15,5824⟩,⟨13,13⟩]
private def b925 : Box := ![⟨15,17⟩,⟨31,5824⟩,⟨31,5824⟩,⟨15,5824⟩,⟨13,13⟩]
private def b988 : Box := ![⟨18,26⟩,⟨15,5824⟩,⟨7,5824⟩,⟨7,5824⟩,⟨13,13⟩]
private def b989 : Box := ![⟨18,26⟩,⟨15,5824⟩,⟨7,14⟩,⟨7,5824⟩,⟨13,13⟩]
private def b990 : Box := ![⟨18,26⟩,⟨15,5824⟩,⟨7,14⟩,⟨7,14⟩,⟨13,13⟩]
private def b1079 : Box := ![⟨18,26⟩,⟨15,5824⟩,⟨7,14⟩,⟨15,4463⟩,⟨13,13⟩]
private def b1080 : Box := ![⟨18,26⟩,⟨15,30⟩,⟨7,14⟩,⟨15,4463⟩,⟨13,13⟩]
private def b1119 : Box := ![⟨18,26⟩,⟨31,5824⟩,⟨7,14⟩,⟨15,4463⟩,⟨13,13⟩]
private def b1214 : Box := ![⟨18,26⟩,⟨15,5824⟩,⟨15,5824⟩,⟨7,5824⟩,⟨13,13⟩]
private def b1215 : Box := ![⟨18,26⟩,⟨15,5824⟩,⟨15,5824⟩,⟨7,14⟩,⟨13,13⟩]
private def b1216 : Box := ![⟨18,26⟩,⟨15,30⟩,⟨15,4777⟩,⟨7,14⟩,⟨13,13⟩]
private def b1217 : Box := ![⟨18,21⟩,⟨15,30⟩,⟨15,56⟩,⟨7,14⟩,⟨13,13⟩]
private def b1218 : Box := ![⟨18,21⟩,⟨15,20⟩,⟨15,54⟩,⟨7,14⟩,⟨13,13⟩]
private def b1237 : Box := ![⟨18,21⟩,⟨21,30⟩,⟨15,54⟩,⟨7,14⟩,⟨13,13⟩]
private def b1322 : Box := ![⟨22,26⟩,⟨15,30⟩,⟨15,56⟩,⟨7,14⟩,⟨13,13⟩]
private def b1323 : Box := ![⟨22,26⟩,⟨15,20⟩,⟨15,56⟩,⟨7,14⟩,⟨13,13⟩]
private def b1380 : Box := ![⟨22,26⟩,⟨21,30⟩,⟨15,56⟩,⟨7,14⟩,⟨13,13⟩]
private def b1439 : Box := ![⟨18,26⟩,⟨31,5824⟩,⟨15,4777⟩,⟨7,14⟩,⟨13,13⟩]
private def b1440 : Box := ![⟨18,21⟩,⟨31,5824⟩,⟨15,4777⟩,⟨7,14⟩,⟨13,13⟩]
private def b1441 : Box := ![⟨18,21⟩,⟨31,5824⟩,⟨15,30⟩,⟨7,14⟩,⟨13,13⟩]
private def b1442 : Box := ![⟨18,21⟩,⟨31,73⟩,⟨15,30⟩,⟨7,9⟩,⟨13,13⟩]
private def b1497 : Box := ![⟨18,21⟩,⟨31,73⟩,⟨15,30⟩,⟨10,14⟩,⟨13,13⟩]
private def b1554 : Box := ![⟨18,21⟩,⟨31,5824⟩,⟨31,4775⟩,⟨7,14⟩,⟨13,13⟩]
private def b1597 : Box := ![⟨22,26⟩,⟨31,5824⟩,⟨15,4777⟩,⟨7,14⟩,⟨13,13⟩]
private def b1632 : Box := ![⟨18,26⟩,⟨15,5824⟩,⟨15,5824⟩,⟨15,5824⟩,⟨13,13⟩]
private def b1633 : Box := ![⟨18,26⟩,⟨15,30⟩,⟨15,5824⟩,⟨15,5824⟩,⟨13,13⟩]
private def b1634 : Box := ![⟨18,21⟩,⟨15,30⟩,⟨15,5824⟩,⟨15,5495⟩,⟨13,13⟩]
private def b1635 : Box := ![⟨18,21⟩,⟨15,30⟩,⟨15,30⟩,⟨15,5493⟩,⟨13,13⟩]
private def b1684 : Box := ![⟨18,21⟩,⟨15,30⟩,⟨31,5824⟩,⟨15,5493⟩,⟨13,13⟩]
private def b1731 : Box := ![⟨22,26⟩,⟨15,30⟩,⟨15,5824⟩,⟨15,5495⟩,⟨13,13⟩]
private def b1752 : Box := ![⟨18,26⟩,⟨31,5824⟩,⟨15,5824⟩,⟨15,5824⟩,⟨13,13⟩]
private def b1773 : Box := ![⟨13,26⟩,⟨15,5824⟩,⟨7,5824⟩,⟨7,5824⟩,⟨15,17⟩]
private def b1804 : Box := ![⟨27,5824⟩,⟨7,5824⟩,⟨2,5824⟩,⟨3,5824⟩,⟨13,23⟩]
private def b1805 : Box := ![⟨27,5824⟩,⟨7,5824⟩,⟨2,5824⟩,⟨3,5824⟩,⟨13,16⟩]
private def b1806 : Box := ![⟨27,5824⟩,⟨7,5824⟩,⟨2,4⟩,⟨3,5824⟩,⟨13,13⟩]
private def b1807 : Box := ![⟨27,5824⟩,⟨7,5824⟩,⟨2,4⟩,⟨3,6⟩,⟨13,13⟩]
private def b1814 : Box := ![⟨27,5824⟩,⟨7,5824⟩,⟨2,4⟩,⟨7,5824⟩,⟨13,13⟩]
private def b1815 : Box := ![⟨27,5824⟩,⟨7,14⟩,⟨2,4⟩,⟨7,5824⟩,⟨13,13⟩]
private def b1838 : Box := ![⟨27,5824⟩,⟨15,5824⟩,⟨2,4⟩,⟨7,5824⟩,⟨13,13⟩]
private def b1839 : Box := ![⟨27,54⟩,⟨15,5824⟩,⟨2,4⟩,⟨7,5824⟩,⟨13,13⟩]
private def b1904 : Box := ![⟨55,5824⟩,⟨15,5824⟩,⟨2,4⟩,⟨7,5824⟩,⟨13,13⟩]
private def b1993 : Box := ![⟨27,5824⟩,⟨7,5824⟩,⟨5,5824⟩,⟨3,5824⟩,⟨13,13⟩]
private def b1994 : Box := ![⟨27,5824⟩,⟨7,5824⟩,⟨5,5824⟩,⟨3,6⟩,⟨13,13⟩]
private def b1995 : Box := ![⟨27,5824⟩,⟨7,14⟩,⟨5,5824⟩,⟨3,6⟩,⟨13,13⟩]
private def b1996 : Box := ![⟨27,54⟩,⟨7,14⟩,⟨5,2699⟩,⟨3,6⟩,⟨13,13⟩]
private def b1997 : Box := ![⟨27,54⟩,⟨7,9⟩,⟨9,47⟩,⟨3,6⟩,⟨13,13⟩]
private def b2004 : Box := ![⟨27,54⟩,⟨10,14⟩,⟨9,47⟩,⟨3,6⟩,⟨13,13⟩]
private def b2005 : Box := ![⟨27,54⟩,⟨10,14⟩,⟨9,47⟩,⟨3,4⟩,⟨13,13⟩]
private def b2028 : Box := ![⟨27,54⟩,⟨10,14⟩,⟨9,47⟩,⟨5,6⟩,⟨13,13⟩]
private def b2029 : Box := ![⟨27,36⟩,⟨10,14⟩,⟨9,47⟩,⟨5,6⟩,⟨13,13⟩]
private def b2048 : Box := ![⟨37,54⟩,⟨10,14⟩,⟨9,47⟩,⟨5,6⟩,⟨13,13⟩]
private def b2129 : Box := ![⟨55,5824⟩,⟨7,14⟩,⟨5,2699⟩,⟨3,6⟩,⟨13,13⟩]
private def b2130 : Box := ![⟨55,5824⟩,⟨7,14⟩,⟨5,10⟩,⟨3,6⟩,⟨13,13⟩]
private def b2135 : Box := ![⟨55,5824⟩,⟨7,14⟩,⟨11,2699⟩,⟨3,6⟩,⟨13,13⟩]
private def b2136 : Box := ![⟨55,5824⟩,⟨7,9⟩,⟨11,2699⟩,⟨3,6⟩,⟨13,13⟩]
private def b2179 : Box := ![⟨55,5824⟩,⟨10,14⟩,⟨11,2699⟩,⟨3,6⟩,⟨13,13⟩]
private def b2180 : Box := ![⟨55,5824⟩,⟨10,14⟩,⟨11,2699⟩,⟨3,4⟩,⟨13,13⟩]
private def b2235 : Box := ![⟨55,5824⟩,⟨10,14⟩,⟨11,2699⟩,⟨5,6⟩,⟨13,13⟩]
private def b2294 : Box := ![⟨27,5824⟩,⟨15,5824⟩,⟨5,5824⟩,⟨3,6⟩,⟨13,13⟩]
private def b2295 : Box := ![⟨27,54⟩,⟨15,5824⟩,⟨5,5824⟩,⟨3,6⟩,⟨13,13⟩]
private def b2296 : Box := ![⟨27,54⟩,⟨15,5824⟩,⟨5,10⟩,⟨3,6⟩,⟨13,13⟩]
private def b2297 : Box := ![⟨27,54⟩,⟨15,56⟩,⟨5,10⟩,⟨3,4⟩,⟨13,13⟩]
private def b2326 : Box := ![⟨27,54⟩,⟨15,56⟩,⟨5,10⟩,⟨5,6⟩,⟨13,13⟩]
private def b2419 : Box := ![⟨27,54⟩,⟨15,5824⟩,⟨11,4782⟩,⟨3,6⟩,⟨13,13⟩]
private def b2420 : Box := ![⟨27,54⟩,⟨15,30⟩,⟨11,4782⟩,⟨3,6⟩,⟨13,13⟩]
private def b2421 : Box := ![⟨27,54⟩,⟨15,30⟩,⟨11,60⟩,⟨3,4⟩,⟨13,13⟩]
private def b2512 : Box := ![⟨27,54⟩,⟨15,30⟩,⟨11,60⟩,⟨5,6⟩,⟨13,13⟩]
private def b2513 : Box := ![⟨27,36⟩,⟨15,30⟩,⟨11,60⟩,⟨5,6⟩,⟨13,13⟩]
private def b2514 : Box := ![⟨27,36⟩,⟨15,30⟩,⟨11,18⟩,⟨5,6⟩,⟨13,13⟩]
private def b2553 : Box := ![⟨27,36⟩,⟨15,30⟩,⟨19,52⟩,⟨5,6⟩,⟨13,13⟩]
private def b2642 : Box := ![⟨37,54⟩,⟨15,30⟩,⟨11,60⟩,⟨5,6⟩,⟨13,13⟩]
private def b2701 : Box := ![⟨27,54⟩,⟨31,5824⟩,⟨11,4782⟩,⟨3,6⟩,⟨13,13⟩]
private def b2702 : Box := ![⟨27,54⟩,⟨31,5824⟩,⟨11,4782⟩,⟨3,4⟩,⟨13,13⟩]
private def b2703 : Box := ![⟨27,36⟩,⟨31,5824⟩,⟨11,4779⟩,⟨3,4⟩,⟨13,13⟩]
private def b2764 : Box := ![⟨37,54⟩,⟨31,5824⟩,⟨11,4779⟩,⟨3,4⟩,⟨13,13⟩]
private def b2801 : Box := ![⟨27,54⟩,⟨31,5824⟩,⟨11,4782⟩,⟨5,6⟩,⟨13,13⟩]
private def b2850 : Box := ![⟨55,5824⟩,⟨15,5824⟩,⟨5,5824⟩,⟨3,6⟩,⟨13,13⟩]
private def b2851 : Box := ![⟨55,5824⟩,⟨15,5824⟩,⟨5,10⟩,⟨3,6⟩,⟨13,13⟩]
private def b2934 : Box := ![⟨55,5824⟩,⟨15,5824⟩,⟨11,5824⟩,⟨3,6⟩,⟨13,13⟩]
private def b3027 : Box := ![⟨27,5824⟩,⟨7,5824⟩,⟨5,5824⟩,⟨7,5824⟩,⟨13,13⟩]
private def b3028 : Box := ![⟨27,5824⟩,⟨7,14⟩,⟨5,5824⟩,⟨7,5824⟩,⟨13,13⟩]
private def b3029 : Box := ![⟨27,54⟩,⟨7,14⟩,⟨5,5824⟩,⟨7,5824⟩,⟨13,13⟩]
private def b3030 : Box := ![⟨27,54⟩,⟨7,14⟩,⟨5,10⟩,⟨7,5495⟩,⟨13,13⟩]
private def b3103 : Box := ![⟨27,54⟩,⟨7,14⟩,⟨11,5824⟩,⟨7,5495⟩,⟨13,13⟩]
private def b3104 : Box := ![⟨27,54⟩,⟨7,14⟩,⟨11,5824⟩,⟨7,14⟩,⟨13,13⟩]
private def b3105 : Box := ![⟨27,54⟩,⟨7,9⟩,⟨11,56⟩,⟨7,14⟩,⟨13,13⟩]
private def b3106 : Box := ![⟨27,36⟩,⟨7,9⟩,⟨11,52⟩,⟨7,14⟩,⟨13,13⟩]
private def b3127 : Box := ![⟨37,54⟩,⟨7,9⟩,⟨11,52⟩,⟨7,14⟩,⟨13,13⟩]
private def b3128 : Box := ![⟨37,54⟩,⟨7,9⟩,⟨11,18⟩,⟨7,14⟩,⟨13,13⟩]
private def b3147 : Box := ![⟨37,54⟩,⟨7,9⟩,⟨19,52⟩,⟨7,14⟩,⟨13,13⟩]
private def b3230 : Box := ![⟨27,54⟩,⟨10,14⟩,⟨11,56⟩,⟨7,14⟩,⟨13,13⟩]
private def b3231 : Box := ![⟨27,36⟩,⟨10,14⟩,⟨11,56⟩,⟨7,14⟩,⟨13,13⟩]
private def b3306 : Box := ![⟨37,54⟩,⟨10,14⟩,⟨11,56⟩,⟨7,14⟩,⟨13,13⟩]
private def b3375 : Box := ![⟨27,54⟩,⟨7,14⟩,⟨11,5824⟩,⟨15,5495⟩,⟨13,13⟩]
private def b3376 : Box := ![⟨27,54⟩,⟨7,9⟩,⟨11,5824⟩,⟨15,5495⟩,⟨13,13⟩]
private def b3465 : Box := ![⟨27,54⟩,⟨10,14⟩,⟨11,5824⟩,⟨15,5495⟩,⟨13,13⟩]
private def b3498 : Box := ![⟨55,5824⟩,⟨7,14⟩,⟨5,5824⟩,⟨7,5824⟩,⟨13,13⟩]
private def b3499 : Box := ![⟨55,5824⟩,⟨7,14⟩,⟨5,10⟩,⟨7,5824⟩,⟨13,13⟩]
private def b3500 : Box := ![⟨55,5824⟩,⟨7,14⟩,⟨5,10⟩,⟨7,14⟩,⟨13,13⟩]
private def b3543 : Box := ![⟨55,5824⟩,⟨7,14⟩,⟨5,10⟩,⟨15,2526⟩,⟨13,13⟩]
private def b3604 : Box := ![⟨55,5824⟩,⟨7,14⟩,⟨11,5824⟩,⟨7,5824⟩,⟨13,13⟩]
private def b3605 : Box := ![⟨55,5824⟩,⟨7,14⟩,⟨11,5824⟩,⟨7,14⟩,⟨13,13⟩]
private def b3606 : Box := ![⟨55,5824⟩,⟨7,9⟩,⟨11,2708⟩,⟨7,14⟩,⟨13,13⟩]
private def b3697 : Box := ![⟨55,5824⟩,⟨10,14⟩,⟨11,2708⟩,⟨7,14⟩,⟨13,13⟩]
private def b3716 : Box := ![⟨55,5824⟩,⟨7,14⟩,⟨11,5824⟩,⟨15,5824⟩,⟨13,13⟩]
private def b3729 : Box := ![⟨27,5824⟩,⟨15,5824⟩,⟨5,5824⟩,⟨7,5824⟩,⟨13,13⟩]
private def b3730 : Box := ![⟨27,54⟩,⟨15,5824⟩,⟨5,5824⟩,⟨7,5824⟩,⟨13,13⟩]
private def b3731 : Box := ![⟨27,54⟩,⟨15,5824⟩,⟨5,10⟩,⟨7,5824⟩,⟨13,13⟩]
private def b3732 : Box := ![⟨27,54⟩,⟨15,5824⟩,⟨5,10⟩,⟨7,14⟩,⟨13,13⟩]
private def b3733 : Box := ![⟨27,36⟩,⟨15,67⟩,⟨5,10⟩,⟨7,14⟩,⟨13,13⟩]
private def b3828 : Box := ![⟨37,54⟩,⟨15,67⟩,⟨5,10⟩,⟨7,14⟩,⟨13,13⟩]
private def b3829 : Box := ![⟨37,54⟩,⟨15,24⟩,⟨5,10⟩,⟨7,14⟩,⟨13,13⟩]
private def b3878 : Box := ![⟨37,54⟩,⟨25,67⟩,⟨5,10⟩,⟨7,14⟩,⟨13,13⟩]
private def b3939 : Box := ![⟨27,54⟩,⟨15,5824⟩,⟨5,10⟩,⟨15,4472⟩,⟨13,13⟩]
private def b4010 : Box := ![⟨27,54⟩,⟨15,5824⟩,⟨11,5824⟩,⟨7,5824⟩,⟨13,13⟩]
private def b4101 : Box := ![⟨55,5824⟩,⟨15,5824⟩,⟨5,5824⟩,⟨7,5824⟩,⟨13,13⟩]
private def b4148 : Box := ![⟨27,5824⟩,⟨7,5824⟩,⟨2,5824⟩,⟨3,5824⟩,⟨17,23⟩]
private def b4149 : Box := ![⟨27,5824⟩,⟨7,14⟩,⟨4,5824⟩,⟨3,5824⟩,⟨17,23⟩]
private def b4150 : Box := ![⟨29,58⟩,⟨7,14⟩,⟨8,5824⟩,⟨5,5824⟩,⟨17,20⟩]
private def b4167 : Box := ![⟨59,5824⟩,⟨7,14⟩,⟨8,5824⟩,⟨5,5824⟩,⟨17,20⟩]
private def b4168 : Box := ![⟨59,5824⟩,⟨7,14⟩,⟨8,16⟩,⟨5,5824⟩,⟨17,19⟩]
private def b4197 : Box := ![⟨59,5824⟩,⟨7,14⟩,⟨17,5824⟩,⟨5,5824⟩,⟨17,19⟩]
private def b4198 : Box := ![⟨59,5824⟩,⟨7,14⟩,⟨17,5824⟩,⟨5,10⟩,⟨17,19⟩]
private def b4213 : Box := ![⟨59,5824⟩,⟨7,14⟩,⟨17,5824⟩,⟨11,5824⟩,⟨17,19⟩]
private def b4214 : Box := ![⟨59,5824⟩,⟨7,9⟩,⟨17,5824⟩,⟨11,5824⟩,⟨17,19⟩]
private def b4235 : Box := ![⟨59,5824⟩,⟨10,14⟩,⟨17,5824⟩,⟨11,5824⟩,⟨17,19⟩]
private def b4236 : Box := ![⟨59,117⟩,⟨10,14⟩,⟨17,5824⟩,⟨11,5824⟩,⟨17,19⟩]
private def b4237 : Box := ![⟨59,117⟩,⟨10,14⟩,⟨17,5824⟩,⟨11,4995⟩,⟨17,17⟩]
private def b4238 : Box := ![⟨59,117⟩,⟨10,14⟩,⟨17,34⟩,⟨11,4995⟩,⟨17,17⟩]
private def b4291 : Box := ![⟨59,117⟩,⟨10,14⟩,⟨35,5824⟩,⟨11,4995⟩,⟨17,17⟩]
private def b4368 : Box := ![⟨59,117⟩,⟨10,14⟩,⟨17,5824⟩,⟨11,4995⟩,⟨18,19⟩]
private def b4371 : Box := ![⟨118,5824⟩,⟨10,14⟩,⟨17,5824⟩,⟨11,5824⟩,⟨17,19⟩]
private def b4372 : Box := ![⟨118,5824⟩,⟨10,14⟩,⟨17,5824⟩,⟨11,5824⟩,⟨17,17⟩]
private def b4373 : Box := ![⟨118,5824⟩,⟨10,14⟩,⟨17,34⟩,⟨11,5824⟩,⟨17,17⟩]
private def b4374 : Box := ![⟨118,5824⟩,⟨10,14⟩,⟨17,34⟩,⟨11,22⟩,⟨17,17⟩]
private def b4431 : Box := ![⟨118,5824⟩,⟨10,14⟩,⟨17,34⟩,⟨23,2305⟩,⟨17,17⟩]
private def b4482 : Box := ![⟨118,5824⟩,⟨10,14⟩,⟨35,5824⟩,⟨11,5824⟩,⟨17,17⟩]
private def b4563 : Box := ![⟨118,5824⟩,⟨10,14⟩,⟨17,5824⟩,⟨11,5824⟩,⟨18,19⟩]
private def b4578 : Box := ![⟨27,5824⟩,⟨15,5824⟩,⟨4,5824⟩,⟨3,5824⟩,⟨17,23⟩]
private def b4579 : Box := ![⟨27,5824⟩,⟨15,5824⟩,⟨4,8⟩,⟨3,5824⟩,⟨17,23⟩]
private def b4580 : Box := ![⟨29,58⟩,⟨15,5824⟩,⟨4,8⟩,⟨5,5824⟩,⟨17,20⟩]
private def b4593 : Box := ![⟨59,5824⟩,⟨15,5824⟩,⟨4,8⟩,⟨5,5824⟩,⟨17,20⟩]
private def b4682 : Box := ![⟨27,5824⟩,⟨15,5824⟩,⟨9,5824⟩,⟨3,5824⟩,⟨17,23⟩]
private def b4683 : Box := ![⟨27,54⟩,⟨15,5824⟩,⟨9,5824⟩,⟨3,5824⟩,⟨17,23⟩]
private def b4684 : Box := ![⟨27,54⟩,⟨15,5824⟩,⟨9,5824⟩,⟨4,8⟩,⟨17,21⟩]
private def b4721 : Box := ![⟨27,54⟩,⟨15,5824⟩,⟨9,5824⟩,⟨9,5824⟩,⟨17,21⟩]
private def b4722 : Box := ![⟨27,54⟩,⟨15,30⟩,⟨9,5824⟩,⟨9,5824⟩,⟨17,19⟩]
private def b4815 : Box := ![⟨27,54⟩,⟨31,5824⟩,⟨9,5824⟩,⟨9,5824⟩,⟨17,19⟩]
private def b4816 : Box := ![⟨27,54⟩,⟨31,5824⟩,⟨9,18⟩,⟨9,5824⟩,⟨17,19⟩]
private def b4817 : Box := ![⟨27,36⟩,⟨31,5824⟩,⟨9,18⟩,⟨9,4051⟩,⟨17,19⟩]
private def b4832 : Box := ![⟨37,54⟩,⟨31,5824⟩,⟨9,18⟩,⟨9,4051⟩,⟨17,19⟩]
private def b4833 : Box := ![⟨37,54⟩,⟨31,5824⟩,⟨9,18⟩,⟨9,4051⟩,⟨17,17⟩]
private def b4922 : Box := ![⟨37,54⟩,⟨31,5824⟩,⟨9,18⟩,⟨9,4051⟩,⟨18,19⟩]
private def b4933 : Box := ![⟨27,54⟩,⟨31,5824⟩,⟨19,5824⟩,⟨9,5824⟩,⟨17,19⟩]
private def b4934 : Box := ![⟨27,36⟩,⟨31,5824⟩,⟨19,5824⟩,⟨9,5824⟩,⟨17,19⟩]
private def b4935 : Box := ![⟨27,36⟩,⟨31,5824⟩,⟨19,5824⟩,⟨9,5824⟩,⟨17,17⟩]
private def b4936 : Box := ![⟨27,36⟩,⟨31,5824⟩,⟨19,5824⟩,⟨9,18⟩,⟨17,17⟩]
private def b4959 : Box := ![⟨27,36⟩,⟨31,5824⟩,⟨19,5824⟩,⟨19,5824⟩,⟨17,17⟩]
private def b5052 : Box := ![⟨27,36⟩,⟨31,5824⟩,⟨19,5824⟩,⟨9,5824⟩,⟨18,19⟩]
private def b5065 : Box := ![⟨37,54⟩,⟨31,5824⟩,⟨19,5824⟩,⟨9,5824⟩,⟨17,19⟩]
private def b5066 : Box := ![⟨37,54⟩,⟨31,5824⟩,⟨19,5824⟩,⟨9,5824⟩,⟨17,17⟩]
private def b5067 : Box := ![⟨37,54⟩,⟨31,5824⟩,⟨19,5824⟩,⟨9,18⟩,⟨17,17⟩]
private def b5068 : Box := ![⟨37,54⟩,⟨31,62⟩,⟨19,4797⟩,⟨9,18⟩,⟨17,17⟩]
private def b5069 : Box := ![⟨37,43⟩,⟨31,62⟩,⟨19,102⟩,⟨9,18⟩,⟨17,17⟩]
private def b5128 : Box := ![⟨44,54⟩,⟨31,62⟩,⟨19,102⟩,⟨9,18⟩,⟨17,17⟩]
private def b5129 : Box := ![⟨44,54⟩,⟨31,62⟩,⟨19,32⟩,⟨9,18⟩,⟨17,17⟩]
private def b5182 : Box := ![⟨44,54⟩,⟨31,62⟩,⟨33,102⟩,⟨9,18⟩,⟨17,17⟩]
private def b5183 : Box := ![⟨44,54⟩,⟨31,62⟩,⟨33,102⟩,⟨9,12⟩,⟨17,17⟩]
private def b5184 : Box := ![⟨44,54⟩,⟨31,41⟩,⟨33,95⟩,⟨9,12⟩,⟨17,17⟩]
private def b5227 : Box := ![⟨44,54⟩,⟨42,62⟩,⟨33,95⟩,⟨9,12⟩,⟨17,17⟩]
private def b5312 : Box := ![⟨44,54⟩,⟨31,62⟩,⟨33,102⟩,⟨13,18⟩,⟨17,17⟩]
private def b5313 : Box := ![⟨37,54⟩,⟨63,5824⟩,⟨19,4797⟩,⟨9,18⟩,⟨17,17⟩]
private def b5314 : Box := ![⟨37,54⟩,⟨63,5824⟩,⟨19,38⟩,⟨9,18⟩,⟨17,17⟩]
private def b5315 : Box := ![⟨37,43⟩,⟨63,110⟩,⟨19,38⟩,⟨9,18⟩,⟨17,17⟩]
private def b5348 : Box := ![⟨44,54⟩,⟨63,110⟩,⟨19,38⟩,⟨9,18⟩,⟨17,17⟩]
private def b5413 : Box := ![⟨37,54⟩,⟨63,5824⟩,⟨39,4797⟩,⟨9,18⟩,⟨17,17⟩]
private def b5470 : Box := ![⟨37,54⟩,⟨31,5824⟩,⟨19,5824⟩,⟨19,5824⟩,⟨17,17⟩]
private def b5475 : Box := ![⟨37,54⟩,⟨31,5824⟩,⟨19,5824⟩,⟨9,5824⟩,⟨18,19⟩]
private def b5502 : Box := ![⟨55,5824⟩,⟨15,5824⟩,⟨9,5824⟩,⟨3,5824⟩,⟨17,23⟩]
private def b5503 : Box := ![⟨55,5824⟩,⟨15,5824⟩,⟨9,5824⟩,⟨3,5824⟩,⟨17,19⟩]
private def b5504 : Box := ![⟨55,5824⟩,⟨15,5824⟩,⟨9,5824⟩,⟨3,6⟩,⟨17,19⟩]
private def b5591 : Box := ![⟨55,5824⟩,⟨15,5824⟩,⟨9,5824⟩,⟨7,5824⟩,⟨17,19⟩]
private def b5592 : Box := ![⟨55,5824⟩,⟨15,30⟩,⟨9,5824⟩,⟨7,5824⟩,⟨17,19⟩]
private def b5593 : Box := ![⟨55,5824⟩,⟨15,30⟩,⟨9,18⟩,⟨7,5824⟩,⟨17,19⟩]
private def b5594 : Box := ![⟨55,109⟩,⟨15,30⟩,⟨9,18⟩,⟨7,2302⟩,⟨17,19⟩]
private def b5595 : Box := ![⟨55,109⟩,⟨15,30⟩,⟨9,18⟩,⟨8,15⟩,⟨17,18⟩]
private def b5646 : Box := ![⟨55,109⟩,⟨15,30⟩,⟨9,18⟩,⟨16,83⟩,⟨17,18⟩]
private def b5647 : Box := ![⟨55,109⟩,⟨15,20⟩,⟨9,18⟩,⟨16,83⟩,⟨17,17⟩]
private def b5664 : Box := ![⟨55,109⟩,⟨21,30⟩,⟨9,18⟩,⟨16,83⟩,⟨17,17⟩]
private def b5665 : Box := ![⟨55,109⟩,⟨21,30⟩,⟨9,12⟩,⟨16,83⟩,⟨17,17⟩]
private def b5666 : Box := ![⟨55,73⟩,⟨21,30⟩,⟨9,12⟩,⟨16,78⟩,⟨17,17⟩]
private def b5683 : Box := ![⟨74,109⟩,⟨21,30⟩,⟨9,12⟩,⟨16,78⟩,⟨17,17⟩]
private def b5762 : Box := ![⟨55,109⟩,⟨21,30⟩,⟨13,18⟩,⟨16,83⟩,⟨17,17⟩]
private def b5763 : Box := ![⟨110,5824⟩,⟨15,30⟩,⟨9,18⟩,⟨7,2302⟩,⟨17,19⟩]
private def b5764 : Box := ![⟨110,5824⟩,⟨15,30⟩,⟨9,18⟩,⟨7,14⟩,⟨17,19⟩]
private def b5799 : Box := ![⟨110,5824⟩,⟨15,30⟩,⟨9,18⟩,⟨15,2302⟩,⟨17,19⟩]
private def b5800 : Box := ![⟨110,5824⟩,⟨15,30⟩,⟨9,18⟩,⟨15,2302⟩,⟨17,17⟩]
private def b5801 : Box := ![⟨110,5824⟩,⟨15,20⟩,⟨9,18⟩,⟨15,2302⟩,⟨17,17⟩]
private def b5854 : Box := ![⟨110,5824⟩,⟨21,30⟩,⟨9,18⟩,⟨15,2302⟩,⟨17,17⟩]
private def b5935 : Box := ![⟨110,5824⟩,⟨15,30⟩,⟨9,18⟩,⟨15,2302⟩,⟨18,19⟩]
private def b5954 : Box := ![⟨55,5824⟩,⟨15,30⟩,⟨19,5824⟩,⟨7,5824⟩,⟨17,19⟩]
private def b5955 : Box := ![⟨55,109⟩,⟨15,30⟩,⟨19,5824⟩,⟨7,5824⟩,⟨17,19⟩]
private def b5956 : Box := ![⟨55,109⟩,⟨15,30⟩,⟨19,5824⟩,⟨7,14⟩,⟨17,19⟩]
private def b5957 : Box := ![⟨55,109⟩,⟨15,30⟩,⟨19,97⟩,⟨7,14⟩,⟨17,17⟩]
private def b5958 : Box := ![⟨55,109⟩,⟨15,20⟩,⟨19,96⟩,⟨7,14⟩,⟨17,17⟩]
private def b5959 : Box := ![⟨55,73⟩,⟨15,20⟩,⟨19,88⟩,⟨7,14⟩,⟨17,17⟩]
private def b5984 : Box := ![⟨74,109⟩,⟨15,20⟩,⟨19,88⟩,⟨7,14⟩,⟨17,17⟩]
private def b6061 : Box := ![⟨55,109⟩,⟨21,30⟩,⟨19,96⟩,⟨7,14⟩,⟨17,17⟩]
private def b6062 : Box := ![⟨55,73⟩,⟨21,30⟩,⟨19,96⟩,⟨7,14⟩,⟨17,17⟩]
private def b6137 : Box := ![⟨74,109⟩,⟨21,30⟩,⟨19,96⟩,⟨7,14⟩,⟨17,17⟩]
private def b6138 : Box := ![⟨74,109⟩,⟨21,30⟩,⟨19,32⟩,⟨7,14⟩,⟨17,17⟩]
private def b6221 : Box := ![⟨74,109⟩,⟨21,30⟩,⟨33,96⟩,⟨7,14⟩,⟨17,17⟩]
private def b6222 : Box := ![⟨74,109⟩,⟨21,30⟩,⟨33,96⟩,⟨7,9⟩,⟨17,17⟩]
private def b6223 : Box := ![⟨74,109⟩,⟨21,24⟩,⟨33,90⟩,⟨7,9⟩,⟨17,17⟩]
private def b6318 : Box := ![⟨74,109⟩,⟨25,30⟩,⟨33,90⟩,⟨7,9⟩,⟨17,17⟩]
private def b6319 : Box := ![⟨74,109⟩,⟨21,30⟩,⟨33,96⟩,⟨10,14⟩,⟨17,17⟩]
private def b6320 : Box := ![⟨55,109⟩,⟨15,30⟩,⟨19,97⟩,⟨7,14⟩,⟨18,19⟩]
private def b6323 : Box := ![⟨55,109⟩,⟨15,30⟩,⟨19,5824⟩,⟨15,5003⟩,⟨17,19⟩]
private def b6378 : Box := ![⟨110,5824⟩,⟨15,30⟩,⟨19,5824⟩,⟨7,5824⟩,⟨17,19⟩]
private def b6379 : Box := ![⟨110,5824⟩,⟨15,30⟩,⟨19,5824⟩,⟨7,14⟩,⟨17,19⟩]
private def b6380 : Box := ![⟨110,5824⟩,⟨15,30⟩,⟨19,2723⟩,⟨7,14⟩,⟨17,17⟩]
private def b6381 : Box := ![⟨110,5824⟩,⟨15,20⟩,⟨19,2723⟩,⟨7,14⟩,⟨17,17⟩]
private def b6462 : Box := ![⟨110,5824⟩,⟨21,30⟩,⟨19,2723⟩,⟨7,14⟩,⟨17,17⟩]
private def b6539 : Box := ![⟨110,5824⟩,⟨15,30⟩,⟨19,2723⟩,⟨7,14⟩,⟨18,19⟩]
private def b6568 : Box := ![⟨110,5824⟩,⟨15,30⟩,⟨19,5824⟩,⟨15,5824⟩,⟨17,19⟩]
private def b6639 : Box := ![⟨55,5824⟩,⟨31,5824⟩,⟨9,5824⟩,⟨7,5824⟩,⟨17,19⟩]
private def b6640 : Box := ![⟨55,5824⟩,⟨31,5824⟩,⟨9,18⟩,⟨7,5824⟩,⟨17,19⟩]
private def b6641 : Box := ![⟨55,109⟩,⟨31,5824⟩,⟨9,18⟩,⟨7,5824⟩,⟨17,19⟩]
private def b6642 : Box := ![⟨55,109⟩,⟨31,5824⟩,⟨9,18⟩,⟨7,14⟩,⟨17,19⟩]
private def b6643 : Box := ![⟨55,109⟩,⟨31,111⟩,⟨9,18⟩,⟨7,14⟩,⟨17,17⟩]
private def b6644 : Box := ![⟨55,109⟩,⟨31,110⟩,⟨9,12⟩,⟨7,14⟩,⟨17,17⟩]
private def b6645 : Box := ![⟨55,73⟩,⟨31,103⟩,⟨9,12⟩,⟨7,14⟩,⟨17,17⟩]
private def b6700 : Box := ![⟨74,109⟩,⟨31,103⟩,⟨9,12⟩,⟨7,14⟩,⟨17,17⟩]
private def b6701 : Box := ![⟨74,109⟩,⟨31,103⟩,⟨9,12⟩,⟨7,9⟩,⟨17,17⟩]
private def b6704 : Box := ![⟨74,109⟩,⟨31,103⟩,⟨9,12⟩,⟨10,14⟩,⟨17,17⟩]
private def b6705 : Box := ![⟨74,109⟩,⟨31,47⟩,⟨9,12⟩,⟨10,14⟩,⟨17,17⟩]
private def b6786 : Box := ![⟨74,109⟩,⟨48,103⟩,⟨9,12⟩,⟨10,14⟩,⟨17,17⟩]
private def b6811 : Box := ![⟨55,109⟩,⟨31,110⟩,⟨13,18⟩,⟨7,14⟩,⟨17,17⟩]
private def b6812 : Box := ![⟨55,73⟩,⟨31,110⟩,⟨13,18⟩,⟨7,14⟩,⟨17,17⟩]
private def b6813 : Box := ![⟨55,73⟩,⟨31,90⟩,⟨13,18⟩,⟨7,9⟩,⟨17,17⟩]
private def b6814 : Box := ![⟨55,73⟩,⟨35,49⟩,⟨13,18⟩,⟨7,9⟩,⟨17,17⟩]
private def b6833 : Box := ![⟨55,73⟩,⟨50,82⟩,⟨13,18⟩,⟨7,9⟩,⟨17,17⟩]
private def b6834 : Box := ![⟨55,62⟩,⟨50,82⟩,⟨13,18⟩,⟨7,9⟩,⟨17,17⟩]
private def b6853 : Box := ![⟨63,73⟩,⟨50,82⟩,⟨13,18⟩,⟨7,9⟩,⟨17,17⟩]
private def b6940 : Box := ![⟨55,73⟩,⟨31,90⟩,⟨13,18⟩,⟨10,14⟩,⟨17,17⟩]
private def b6941 : Box := ![⟨74,109⟩,⟨31,110⟩,⟨13,18⟩,⟨7,14⟩,⟨17,17⟩]
private def b6942 : Box := ![⟨74,109⟩,⟨31,48⟩,⟨13,18⟩,⟨7,14⟩,⟨17,17⟩]
private def b6943 : Box := ![⟨74,109⟩,⟨31,48⟩,⟨13,18⟩,⟨7,9⟩,⟨17,17⟩]
private def b6944 : Box := ![⟨74,88⟩,⟨31,48⟩,⟨13,18⟩,⟨7,9⟩,⟨17,17⟩]
private def b6991 : Box := ![⟨89,109⟩,⟨31,48⟩,⟨13,18⟩,⟨7,9⟩,⟨17,17⟩]
private def b7070 : Box := ![⟨74,109⟩,⟨31,48⟩,⟨13,18⟩,⟨10,14⟩,⟨17,17⟩]
private def b7071 : Box := ![⟨74,109⟩,⟨49,110⟩,⟨13,18⟩,⟨7,14⟩,⟨17,17⟩]
private def b7094 : Box := ![⟨55,109⟩,⟨31,111⟩,⟨9,18⟩,⟨7,14⟩,⟨18,19⟩]
private def b7097 : Box := ![⟨55,109⟩,⟨31,5824⟩,⟨9,18⟩,⟨15,4073⟩,⟨17,19⟩]
private def b7098 : Box := ![⟨55,109⟩,⟨31,5824⟩,⟨9,18⟩,⟨15,4073⟩,⟨17,17⟩]
private def b7099 : Box := ![⟨55,109⟩,⟨31,62⟩,⟨9,18⟩,⟨15,4073⟩,⟨17,17⟩]
private def b7100 : Box := ![⟨55,109⟩,⟨31,62⟩,⟨9,12⟩,⟨15,105⟩,⟨17,17⟩]
private def b7101 : Box := ![⟨55,73⟩,⟨31,62⟩,⟨9,12⟩,⟨15,100⟩,⟨17,17⟩]
private def b7174 : Box := ![⟨74,109⟩,⟨31,62⟩,⟨9,12⟩,⟨15,100⟩,⟨17,17⟩]
private def b7263 : Box := ![⟨55,109⟩,⟨31,62⟩,⟨13,18⟩,⟨15,105⟩,⟨17,17⟩]
private def b7264 : Box := ![⟨55,109⟩,⟨63,5824⟩,⟨9,18⟩,⟨15,4073⟩,⟨17,17⟩]
private def b7341 : Box := ![⟨55,109⟩,⟨31,5824⟩,⟨9,18⟩,⟨15,4073⟩,⟨18,19⟩]
private def b7382 : Box := ![⟨110,5824⟩,⟨31,5824⟩,⟨9,18⟩,⟨7,5824⟩,⟨17,19⟩]
private def b7383 : Box := ![⟨110,5824⟩,⟨31,5824⟩,⟨9,18⟩,⟨7,14⟩,⟨17,19⟩]
private def b7384 : Box := ![⟨110,5824⟩,⟨31,3345⟩,⟨9,18⟩,⟨7,14⟩,⟨17,17⟩]
private def b7385 : Box := ![⟨110,5824⟩,⟨31,62⟩,⟨9,18⟩,⟨7,14⟩,⟨17,17⟩]
private def b7386 : Box := ![⟨110,197⟩,⟨31,62⟩,⟨9,12⟩,⟨7,14⟩,⟨17,17⟩]
private def b7453 : Box := ![⟨110,197⟩,⟨31,62⟩,⟨13,18⟩,⟨7,14⟩,⟨17,17⟩]
private def b7520 : Box := ![⟨110,5824⟩,⟨63,3344⟩,⟨9,18⟩,⟨7,14⟩,⟨17,17⟩]
private def b7521 : Box := ![⟨110,5824⟩,⟨31,3345⟩,⟨9,18⟩,⟨7,14⟩,⟨18,19⟩]
private def b7538 : Box := ![⟨110,5824⟩,⟨31,5824⟩,⟨9,18⟩,⟨15,5824⟩,⟨17,19⟩]
private def b7539 : Box := ![⟨110,5824⟩,⟨31,5824⟩,⟨9,18⟩,⟨15,5824⟩,⟨17,17⟩]
private def b7570 : Box := ![⟨110,5824⟩,⟨31,5824⟩,⟨9,18⟩,⟨15,5824⟩,⟨18,19⟩]
private def b7645 : Box := ![⟨55,5824⟩,⟨31,5824⟩,⟨19,5824⟩,⟨7,5824⟩,⟨17,19⟩]
private def b7646 : Box := ![⟨55,109⟩,⟨31,5824⟩,⟨19,5824⟩,⟨7,5824⟩,⟨17,19⟩]
private def b7647 : Box := ![⟨55,109⟩,⟨31,5824⟩,⟨19,5824⟩,⟨7,14⟩,⟨17,19⟩]
private def b7648 : Box := ![⟨55,109⟩,⟨31,5824⟩,⟨19,4818⟩,⟨7,14⟩,⟨17,17⟩]
private def b7649 : Box := ![⟨55,109⟩,⟨31,62⟩,⟨19,4818⟩,⟨7,14⟩,⟨17,17⟩]
private def b7650 : Box := ![⟨55,73⟩,⟨31,62⟩,⟨19,123⟩,⟨7,14⟩,⟨17,17⟩]
private def b7727 : Box := ![⟨74,109⟩,⟨31,62⟩,⟨19,123⟩,⟨7,14⟩,⟨17,17⟩]
private def b7796 : Box := ![⟨55,109⟩,⟨63,5824⟩,⟨19,4818⟩,⟨7,14⟩,⟨17,17⟩]
private def b7829 : Box := ![⟨55,109⟩,⟨31,5824⟩,⟨19,4818⟩,⟨7,14⟩,⟨18,19⟩]
private def b7888 : Box := ![⟨55,109⟩,⟨31,5824⟩,⟨19,5824⟩,⟨15,5824⟩,⟨17,19⟩]
private def b7889 : Box := ![⟨110,5824⟩,⟨31,5824⟩,⟨19,5824⟩,⟨7,5824⟩,⟨17,19⟩]
private def b7954 : Box := ![⟨55,5824⟩,⟨15,5824⟩,⟨9,5824⟩,⟨3,5824⟩,⟨20,23⟩]
theorem deny7_11 : Deny 7 11 ![⟨2,5824⟩,⟨1,5824⟩,⟨1,5824⟩,⟨1,5824⟩,⟨12,26⟩] := by
  have e1 : Deny 7 11 b1 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x6]
    decide +kernel
  have e3 : Deny 7 11 b3 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x79e1c6]
    decide +kernel
  have e8 : Deny 7 11 b8 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1c7231c68c4]
    decide +kernel
  have e12 : Deny 7 11 b12 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x7599d96708c71a31c68c95660a21c688a08875c8c71a31c6]
    decide +kernel
  have e30 : Deny 7 11 b30 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x5665555471a0255b018871a222688756688a995b15b222068871a2]
    decide +kernel
  have e48 : Deny 7 11 b48 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x199d90c69e02a78c76678c99c36632068c71a3]
    decide +kernel
  have e60 : Deny 7 11 b60 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x8c875d8c81a31e32427621dd25d88754388756229524288788a75db221c68880c31890c61dd20625d7622068871a22a3,0x1d71d8c97622a31dd0c68c90c6]
    decide +kernel
  have e111 : Deny 7 11 b111 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x5425602a02550950c91d528988788a7555621c688a8888877430a02431a680a0c61e02830c61c680975d1c680880988a,0x1d0826678c98c89dd6420e02602838c78c97596676471a02831a31c68c98c88c78c9095988982]
    decide +kernel
  have e59 : Deny 7 11 b59 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x7 b59 b60 b111 (by decide +kernel) e60 e111
  have e47 : Deny 7 11 b47 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x9 b47 b48 b59 (by decide +kernel) e48 e59
  have e29 : Deny 7 11 b29 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b29 b30 b47 (by decide +kernel) e30 e47
  have e11 : Deny 7 11 b11 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 3
      0x8184 b11 b12 b29 (by decide +kernel) e12 e29
  have e7 : Deny 7 11 b7 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x1c6 b7 b8 b11 (by decide +kernel) e8 e11
  have e185 : Deny 7 11 b185 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x175e21c61174e54e11e12578885e21d72939428471a1255995b018871a21c688810b1845a21168841c68841c6]
    decide +kernel
  have e216 : Deny 7 11 b216 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1aada0c31a12431a11e12a321aac31a32231c30a11c684a0c28c70a31c68c869a8c71a32461028c41c68c4]
    decide +kernel
  have e247 : Deny 7 11 b247 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x165a21c6884]
    decide +kernel
  have e251 : Deny 7 11 b251 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x30e22031a21c31a22830871890c68880a21c28871a2]
    decide +kernel
  have e269 : Deny 7 11 b269 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0xc31a11c284a0c68490c62028471828471a1]
    decide +kernel
  have e283 : Deny 7 11 b283 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x5960a12428471aa849a965a21c68885968871a21e2]
    decide +kernel
  have e299 : Deny 7 11 b299 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x165831a1242aa1282aa11ea849a965968871a22028871a2222]
    decide +kernel
  have e317 : Deny 7 11 b317 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x2221c20831c90832432030c62061c30c808724a0831c32030c824308708818a2030c90c80c3188242283088188187262,0x160820c78880832431870c324288788888a8885820c70c90c32468880a22a2]
    decide +kernel
  have e404 : Deny 7 11 b404 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x160820ea84a8495838495831a126a84aaa11ea849]
    decide +kernel
  have e316 : Deny 7 11 b316 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x8 b316 b317 b404 (by decide +kernel) e317 e404
  have e298 : Deny 7 11 b298 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x7 b298 b299 b316 (by decide +kernel) e299 e316
  have e282 : Deny 7 11 b282 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b282 b283 b298 (by decide +kernel) e283 e298
  have e268 : Deny 7 11 b268 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x9 b268 b269 b282 (by decide +kernel) e269 e282
  have e250 : Deny 7 11 b250 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 4
      0x206884 b250 b251 b268 (by decide +kernel) e251 e268
  have e246 : Deny 7 11 b246 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 3
      0x71a2 b246 b247 b250 (by decide +kernel) e247 e250
  have e421 : Deny 7 11 b421 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1c7231c68c4]
    decide +kernel
  have e425 : Deny 7 11 b425 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x30c68c81828c71a3]
    decide +kernel
  have e431 : Deny 7 11 b431 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x20e22032430c90c688888a0c32431a22a21c30872430a22028871a22830a22028871a22028871a2]
    decide +kernel
  have e467 : Deny 7 11 b467 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x7030a22031a22828870a220688a0c28c70a32068c971c8c81a31e3]
    decide +kernel
  have e488 : Deny 7 11 b488 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x8c70c318718a8c88c972f72325c8c77232030c90e22030a22222830a220688771c8871a22222830c68c70a32068c98c7,0x27232020830e22222a21c20e21c30e21e22830c90c688a88788888a0838c90e31c30c90c72830c6]
    decide +kernel
  have e466 : Deny 7 11 b466 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x8 b466 b467 b488 (by decide +kernel) e467 e488
  have e430 : Deny 7 11 b430 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b430 b431 b466 (by decide +kernel) e431 e466
  have e424 : Deny 7 11 b424 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x244 b424 b425 b430 (by decide +kernel) e425 e430
  have e420 : Deny 7 11 b420 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 3
      0x71a3 b420 b421 b424 (by decide +kernel) e421 e424
  have e568 : Deny 7 11 b568 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1aada0c31a11c32030871a12612831878c86ab6a32232430870a11c684a0c31a32028c71a321aadaae31c68c71a3]
    decide +kernel
  have e604 : Deny 7 11 b604 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x2028490a12831880a11c684a0c28471a12428471a12565a22868870c38880870c21c90c688a0a22028870a21c68881a2,0x2565a12621d60960c82560e22160882621d688a8885968881a21e221688a0832038490c31880a12468470c32421c80c3,0x165a1]
    decide +kernel
  have e695 : Deny 7 11 b695 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1c7af88a72f72f8c81a31ef7a325c7231c68c81a3]
    decide +kernel
  have e709 : Deny 7 11 b709 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x7838c80c31a32232431a31c30c624318808718a0c28c71a3223]
    decide +kernel
  have e730 : Deny 7 11 b730 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x2068c78c87830c90c318918788878388a0c97831a22861c308788888a79e8881a21c30a21c31a22828880a21c688888a,0x9e09c0e32430c92878c88c971e7031a228688888a79c7232468c88c98c771cbe22830c772322325c723]
    decide +kernel
  have e708 : Deny 7 11 b708 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x9 b708 b709 b730 (by decide +kernel) e709 e730
  have e694 : Deny 7 11 b694 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x1e3 b694 b695 b708 (by decide +kernel) e695 e708
  have e810 : Deny 7 11 b810 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1e59e79684a0a11c684a84979e1c688888a79aada8c88c979e8471a129e7871a32068c9]
    decide +kernel
  have e840 : Deny 7 11 b840 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x2211e12827838498470c38490c61e12a125e0c32030c62072830c70c21ca24879e7881a12831a125e7881881a11e12a3,0x279a79a84984a8c98c778209e6892a31c30e31e322325e68318a0c68c81a32631e321e0820e12430c9]
    decide +kernel
  have e925 : Deny 7 11 b925 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x78209e0960c920a1c988a7827820c988a0e22030c824788a88879e5a229e58318908818a26229e7a228688888788888a,0x1e0967967960e12612a12612a1247]
    decide +kernel
  have e839 : Deny 7 11 b839 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x9 b839 b840 b925 (by decide +kernel) e840 e925
  have e809 : Deny 7 11 b809 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x7 b809 b810 b839 (by decide +kernel) e810 e839
  have e693 : Deny 7 11 b693 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x8 b693 b694 b809 (by decide +kernel) e694 e809
  have e603 : Deny 7 11 b603 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b603 b604 b693 (by decide +kernel) e604 e693
  have e567 : Deny 7 11 b567 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x9 b567 b568 b603 (by decide +kernel) e568 e603
  have e990 : Deny 7 11 b990 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1c80c28471a12a12430c80c21c62830871891880c38490c80c31881a11c30c620284784a0c28471a12430871881a11e1,0x20820c884a0e12611c30c90c72020c80c384784a0e12430c68498470c32431872212830c80e12838490e11c30c6]
    decide +kernel
  have e1080 : Deny 7 11 b1080 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x20e31c20c90c72830e31c30c72a32030e31c30c72838c88c90c31a31c30871a32030871a32631e3]
    decide +kernel
  have e1119 : Deny 7 11 b1119 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0xc78490c38470e12612830c90c318928884784a69a0e321a0c68c88c78c80c32038490e12832030c620684784a8c98c7,0x6826838c88c78c808208324a2020e124384a0c884784a8c90826830e32632231e320208384984a0832430c9288083203,0x2]
    decide +kernel
  have e1079 : Deny 7 11 b1079 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x8 b1079 b1080 b1119 (by decide +kernel) e1080 e1119
  have e989 : Deny 7 11 b989 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x2a3 b989 b990 b1079 (by decide +kernel) e990 e1079
  have e1218 : Deny 7 11 b1218 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0xc32430c62622032430a22068870c28880a21c688a1a2]
    decide +kernel
  have e1237 : Deny 7 11 b1237 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x2430871a22a22221c30c90c80c31881872420c70c90c32428871a22830c90a22a22030c90881890c21c28881a21c688a,0x820831ca2420c90831c32622a22020838888870c31e22830c70c21ca2430e21c3]
    decide +kernel
  have e1217 : Deny 7 11 b1217 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x222 b1217 b1218 b1237 (by decide +kernel) e1218 e1237
  have e1323 : Deny 7 11 b1323 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0xc988a0c32430c988a8888870c32030c81c90832430c988a0c32431a22a22030c90a22831a22221c30c62031872622a2,0x20820c988a888082]
    decide +kernel
  have e1380 : Deny 7 11 b1380 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x2072420820c988a8880820e22032622820e22832430c91a22a22221c20c90c324a0c32430c92880c324318a0c81c988a,0x82083243]
    decide +kernel
  have e1322 : Deny 7 11 b1322 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x8 b1322 b1323 b1380 (by decide +kernel) e1323 e1380
  have e1216 : Deny 7 11 b1216 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x1e2 b1216 b1217 b1322 (by decide +kernel) e1217 e1322
  have e1442 : Deny 7 11 b1442 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0xc90c85832431882880c38490c684a0c32422888490832038490c32028498475961c684a0c68490c31880871881a11e1,0x960831a11e1261282]
    decide +kernel
  have e1497 : Deny 7 11 b1497 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x84a0832430c928884908208320384984784a0831c20c72030c70c318720a2020c70e12430e12612830c90c6288849847,0x82083849]
    decide +kernel
  have e1441 : Deny 7 11 b1441 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x2a1 b1441 b1442 b1497 (by decide +kernel) e1442 e1497
  have e1554 : Deny 7 11 b1554 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x9688a0820825838881c25832072622a22221d609688a8885960e22160c68881c30c61c95a22a220788a888]
    decide +kernel
  have e1440 : Deny 7 11 b1440 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x262 b1440 b1441 b1554 (by decide +kernel) e1441 e1554
  have e1597 : Deny 7 11 b1597 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x820820820c728884908208320a20208384984a0832430c928884984784a849]
    decide +kernel
  have e1439 : Deny 7 11 b1439 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x7 b1439 b1440 b1597 (by decide +kernel) e1440 e1597
  have e1215 : Deny 7 11 b1215 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x222 b1215 b1216 b1439 (by decide +kernel) e1216 e1439
  have e1635 : Deny 7 11 b1635 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x9e0e32030e32232631c20c32097820c72832030c82472820e32038c90c38c80e32631c30c80c90c31881872a3223]
    decide +kernel
  have e1684 : Deny 7 11 b1684 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x8209c8c88c98c78c80820820c788888a8870820838880e22a22222820c90c31c32622030e21c308788888a88788888a,0x2]
    decide +kernel
  have e1634 : Deny 7 11 b1634 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x263 b1634 b1635 b1684 (by decide +kernel) e1635 e1684
  have e1731 : Deny 7 11 b1731 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x20820838c98c70820c82420c80c91ca8c88c9]
    decide +kernel
  have e1633 : Deny 7 11 b1633 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x1e3 b1633 b1634 b1731 (by decide +kernel) e1634 e1731
  have e1752 : Deny 7 11 b1752 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x820820820832020c90c82892211e12a3247]
    decide +kernel
  have e1632 : Deny 7 11 b1632 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x8 b1632 b1633 b1752 (by decide +kernel) e1633 e1752
  have e1214 : Deny 7 11 b1214 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b1214 b1215 b1632 (by decide +kernel) e1215 e1632
  have e988 : Deny 7 11 b988 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x9 b988 b989 b1214 (by decide +kernel) e989 e1214
  have e566 : Deny 7 11 b566 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x1c4 b566 b567 b988 (by decide +kernel) e567 e988
  have e1773 : Deny 7 11 b1773 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x796a965a21c68885aa5aa8871a21c688a79aadaae32468c96ab6ab1c68c71a325e7a31c68c879e1c61c6087184]
    decide +kernel
  have e565 : Deny 7 11 b565 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xb b565 b566 b1773 (by decide +kernel) e566 e1773
  have e419 : Deny 7 11 b419 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x8 b419 b420 b565 (by decide +kernel) e420 e565
  have e245 : Deny 7 11 b245 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x284 b245 b246 b419 (by decide +kernel) e246 e419
  have e215 : Deny 7 11 b215 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x246 b215 b216 b245 (by decide +kernel) e216 e245
  have e1807 : Deny 7 11 b1807 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x130a58084e584a9428471a1]
    decide +kernel
  have e1815 : Deny 7 11 b1815 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x199d90e70c61e02996631c68c8659c231c68c98c76670c68c71a32029e580a0c68c71a3]
    decide +kernel
  have e1839 : Deny 7 11 b1839 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0xc68c71a321b8c90c68c78c86d384a0e11c30c72030c62211d34e11c28471a12828490c31880871880a11c684a0a3263,0x9b8c96e321b84a69b69a8c81a31c28c98c86c31a11db84984a8c76c3]
    decide +kernel
  have e1904 : Deny 7 11 b1904 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1c20e02030c70c81d30c68080c21c61e029b0e02031a02831871a021b6c71a026022129b4e129b9e321b6e31c68c7189,0x1c26d98c88c909b9e026780a6d96c380829b66321b0c82a31e321b8c98c78c84d39602020826d32872211d384a4e1261,0x26e3]
    decide +kernel
  have e1838 : Deny 7 11 b1838 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x7 b1838 b1839 b1904 (by decide +kernel) e1839 e1904
  have e1814 : Deny 7 11 b1814 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x8 b1814 b1815 b1838 (by decide +kernel) e1815 e1838
  have e1806 : Deny 7 11 b1806 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b1806 b1807 b1814 (by decide +kernel) e1807 e1814
  have e1997 : Deny 7 11 b1997 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x5428870a22028871a2]
    decide +kernel
  have e2005 : Deny 7 11 b2005 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x832558880c32428888870c22021c90a22028871828871a2]
    decide +kernel
  have e2029 : Deny 7 11 b2029 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x30c68880c688a0c28880a22a21c30871890a22028871a2]
    decide +kernel
  have e2048 : Deny 7 11 b2048 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x820e22221c20c90c68880c288888788a0c31c308718a2420c68880e21c288a0c62468888870c31c32431880c22061c9,0x8208388888a8870820c92820c90c324a1c95420c90c324688a8870c31c9888]
    decide +kernel
  have e2028 : Deny 7 11 b2028 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x7 b2028 b2029 b2048 (by decide +kernel) e2029 e2048
  have e2004 : Deny 7 11 b2004 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b2004 b2005 b2028 (by decide +kernel) e2005 e2028
  have e1996 : Deny 7 11 b1996 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 3
      0x81a2 b1996 b1997 b2004 (by decide +kernel) e1997 e2004
  have e2130 : Deny 7 11 b2130 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x30a02428081a0]
    decide +kernel
  have e2136 : Deny 7 11 b2136 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x159955660952152878095622150952152951c95622221c30a020280a0a02431870a02068098875665558871a21e22a2]
    decide +kernel
  have e2180 : Deny 7 11 b2180 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x18725588888a5425432485432431881c956221556220688a8870831c38080c31870881c30871a02428080a02a02621e2,0x566095888555995548]
    decide +kernel
  have e2235 : Deny 7 11 b2235 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0xc928254324a1c98888870820e02a024208320a0832030c70c82891c208380880a0831c30c61ca1c30c7809808809887,0x15982095095]
    decide +kernel
  have e2179 : Deny 7 11 b2179 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b2179 b2180 b2235 (by decide +kernel) e2180 e2235
  have e2135 : Deny 7 11 b2135 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x8 b2135 b2136 b2179 (by decide +kernel) e2136 e2179
  have e2129 : Deny 7 11 b2129 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x9 b2129 b2130 b2135 (by decide +kernel) e2130 e2135
  have e1995 : Deny 7 11 b1995 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x1e2 b1995 b1996 b2129 (by decide +kernel) e1996 e2129
  have e2297 : Deny 7 11 b2297 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x130938498474c31c84e12430c81828471a11c284a4c31870c62021c62028471a1]
    decide +kernel
  have e2326 : Deny 7 11 b2326 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x8498470c31c30c72430c62480c31890c62072130d32480c68471a12430c80e11c30a11e12431a11c30c62021c6206847,0x24c24e12a11e12420c70932831c920208384784a0831c30c72880832038470c32031a11e12830c70c6288]
    decide +kernel
  have e2296 : Deny 7 11 b2296 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x2a1 b2296 b2297 b2326 (by decide +kernel) e2297 e2326
  have e2421 : Deny 7 11 b2421 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0xc31c82570c21c31881891d75c718a5c30c61c80c21c624318708a2095d70c68870a22068875c28880a21c68881a21e2,0x5d70825c32098878885c20c90c32472095d70e22032570a22068878885c30871882621d788a8885c20c7]
    decide +kernel
  have e2514 : Deny 7 11 b2514 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x831c30c72030c70c82430c70c21ca0c80c318808a1891c30c80c22090c61c8]
    decide +kernel
  have e2553 : Deny 7 11 b2553 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x8870825e22a21c208388888a0830a22222a21e22030c70c31c82420e21c30a21e22830c68870a22a22030c6209887888,0x825c25ca1c82420820c988788a0820c90c32621e22a22020832430c91ca0831c30c61ca209]
    decide +kernel
  have e2513 : Deny 7 11 b2513 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x262 b2513 b2514 b2553 (by decide +kernel) e2514 e2553
  have e2642 : Deny 7 11 b2642 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x170820820831ca2098878880970820c72820c31ca2091c20831c80831c30c72090972820c70c31ca2030c8247209]
    decide +kernel
  have e2512 : Deny 7 11 b2512 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x7 b2512 b2513 b2642 (by decide +kernel) e2513 e2642
  have e2420 : Deny 7 11 b2420 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x2a2 b2420 b2421 b2512 (by decide +kernel) e2421 e2512
  have e2703 : Deny 7 11 b2703 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x8470c88491d75832431881872095968871a22a21e22175c38490c62028478490a12970c68470a12570871881a11e1262,0x965ea849aa22825aa88aaa21ea5d6096887888096083]
    decide +kernel
  have e2764 : Deny 7 11 b2764 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x25e22025c25c38498475c32431c88498475d74e12575e12468475d71c62212575e124684784a849]
    decide +kernel
  have e2702 : Deny 7 11 b2702 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x1e2 b2702 b2703 b2764 (by decide +kernel) e2703 e2764
  have e2801 : Deny 7 11 b2801 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x832020838490c884a84784908208384784984a0820c70c31c92880832030e12611c30c68490c684784a849847849887,0x2082]
    decide +kernel
  have e2701 : Deny 7 11 b2701 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b2701 b2702 b2801 (by decide +kernel) e2702 e2801
  have e2419 : Deny 7 11 b2419 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x8 b2419 b2420 b2701 (by decide +kernel) e2420 e2701
  have e2295 : Deny 7 11 b2295 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x262 b2295 b2296 b2419 (by decide +kernel) e2296 e2419
  have e2851 : Deny 7 11 b2851 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x2470c68088090820e02602020c74c90c31c32481d39421c21c680a0c28090c61c28081a02130a02021c68091a02a0221,0x130820932820c31ca2091c20e02020c81c30c70e02202602130e02130a02202530c80c6]
    decide +kernel
  have e2934 : Deny 7 11 b2934 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x5d70c31c95d72061d75c718824a1c20820e02602202570820c91c85c32431c30c90c72091d75c71a02a020988788a888,0x970825d384984a8478498871820a25e68091a65c25e22825e22a21e22025c25d30c82475c3809808809282]
    decide +kernel
  have e2850 : Deny 7 11 b2850 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x9 b2850 b2851 b2934 (by decide +kernel) e2851 e2934
  have e2294 : Deny 7 11 b2294 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x7 b2294 b2295 b2850 (by decide +kernel) e2295 e2850
  have e1994 : Deny 7 11 b1994 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x8 b1994 b1995 b2294 (by decide +kernel) e1995 e2294
  have e3030 : Deny 7 11 b3030 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x2030c62070c220318718918a0c38c70c68c90c220318718a1a31c30e31c31a32030870882830a32068c90c68c71a3223,0x838c80c38c88c70832432030c81ca0c38c80e31c30c62031872a32430c6]
    decide +kernel
  have e3106 : Deny 7 11 b3106 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x30c90c31a22221c30a220288788a0c62428880c22068871a2]
    decide +kernel
  have e3128 : Deny 7 11 b3128 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x30c70c90c31891c31880c318908708818a]
    decide +kernel
  have e3147 : Deny 7 11 b3147 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x2020838888875430a22221e22820c80c70c22031872890c38870e22030a220688a0c22022898875428870a21c688888a,0x820c72420830e21e22222820c80c320a2621c20832622838870c90c324288a1a21e2]
    decide +kernel
  have e3127 : Deny 7 11 b3127 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x9 b3127 b3128 b3147 (by decide +kernel) e3128 e3147
  have e3105 : Deny 7 11 b3105 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x1e2 b3105 b3106 b3127 (by decide +kernel) e3106 e3127
  have e3231 : Deny 7 11 b3231 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x820e22222a21c30c72430e21c32622030e21c30c688788a0c90c688888788a0c32432030c62070c32431880c61ca262,0x8208388a8870c98880820e21e22832430e21c30e21e22832622221c2]
    decide +kernel
  have e3306 : Deny 7 11 b3306 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x820e21e22830c70c31ca2622221e22820832480832430c92070832420c70c31ca0c92020c70c31ca0c90c3189207289,0x820820831ca262202]
    decide +kernel
  have e3230 : Deny 7 11 b3230 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x7 b3230 b3231 b3306 (by decide +kernel) e3231 e3306
  have e3104 : Deny 7 11 b3104 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x222 b3104 b3105 b3230 (by decide +kernel) e3105 e3230
  have e3376 : Deny 7 11 b3376 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0xc31ca25d0e21c325d0a21c688a8880838880c90c31a22032622831a22221e22830c68c90c68c80c28c81a31e32631e3,0x2222820e324274324a0e32631dd0e32438c78c88c909c0c38c78c98c871c0e326325c0c68c98c88c70820e21e22820c7,0x82762]
    decide +kernel
  have e3465 : Deny 7 11 b3465 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x820820e32632231e32420820832622221e22820e32430e32632030e32438c88c78c98c7]
    decide +kernel
  have e3375 : Deny 7 11 b3375 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x8 b3375 b3376 b3465 (by decide +kernel) e3376 e3465
  have e3103 : Deny 7 11 b3103 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b3103 b3104 b3375 (by decide +kernel) e3104 e3375
  have e3029 : Deny 7 11 b3029 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x263 b3029 b3030 b3103 (by decide +kernel) e3030 e3103
  have e3500 : Deny 7 11 b3500 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x820c78090831c38098080831c30c70e02a02430c680980880a0c31c31a02031a02a02430c70e02828080c68091a0220]
    decide +kernel
  have e3543 : Deny 7 11 b3543 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x2231e32631d99d90820e020380a80980a6430c680980a8c86430c92838c88c76439e02999e32196632068c78c98c78c8,0x29c208208324a8c88c70990e02a321908324a0e3]
    decide +kernel
  have e3499 : Deny 7 11 b3499 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x2a3 b3499 b3500 b3543 (by decide +kernel) e3500 e3543
  have e3606 : Deny 7 11 b3606 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1c30c72891c20e02838090c32478080820e02202820c80c31882870c38080c680a0c78090c28090871a02202a02621e2,0x29820820831c988888709556609528726221508208320a1c95550c954a0c61c988888788a082083]
    decide +kernel
  have e3697 : Deny 7 11 b3697 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x29820820820831c30c72891e0220289887]
    decide +kernel
  have e3605 : Deny 7 11 b3605 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x222 b3605 b3606 b3697 (by decide +kernel) e3606 e3697
  have e3716 : Deny 7 11 b3716 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x8208209d0e32632231e32631c8]
    decide +kernel
  have e3604 : Deny 7 11 b3604 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b3604 b3605 b3716 (by decide +kernel) e3605 e3716
  have e3498 : Deny 7 11 b3498 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x9 b3498 b3499 b3604 (by decide +kernel) e3499 e3604
  have e3028 : Deny 7 11 b3028 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x7 b3028 b3029 b3498 (by decide +kernel) e3029 e3498
  have e3733 : Deny 7 11 b3733 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x2432030c62070c32431880c61ca2020e11c38490c31892030a12431888470c28490c620284784a0c31880871881a1261,0x20820c724808320208384784a0c88498470820c72030e11c32212420e11c384a0c80c38470a128318884984784a083]
    decide +kernel
  have e3829 : Deny 7 11 b3829 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x820892020832481c20820c72890c32480c32430c92072820c90c80c32070c31890c6203187289]
    decide +kernel
  have e3878 : Deny 7 11 b3878 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1e12820820c724808208384784a8490832488470930e11d384a8490932830c74ca24808384a0e12430c624884784a849,0x20820820831ca221261]
    decide +kernel
  have e3828 : Deny 7 11 b3828 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x8 b3828 b3829 b3878 (by decide +kernel) e3829 e3878
  have e3732 : Deny 7 11 b3732 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x1e1 b3732 b3733 b3828 (by decide +kernel) e3733 e3828
  have e3939 : Deny 7 11 b3939 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x2211e12a32631c26c26c320a0e31e32232420820c92a31c20e32438c78c809b8c90db24a0e31c30c68c78c88c98c78c8,0x209a09a0e32231e32020826c92880820e11e12420e1261283]
    decide +kernel
  have e3731 : Deny 7 11 b3731 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x2a3 b3731 b3732 b3939 (by decide +kernel) e3732 e3939
  have e4010 : Deny 7 11 b4010 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x28824208208208388788a8880c320988788a8887c20832090832030c824729f0832030c82430c80c91ca20988788888a,0x820827e32232631e32020820820820831c884a84984784a8498870827c20820c8247]
    decide +kernel
  have e3730 : Deny 7 11 b3730 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x9 b3730 b3731 b4010 (by decide +kernel) e3731 e4010
  have e4101 : Deny 7 11 b4101 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x20820820820c81e02a02020820e02202420c32091e02820838098080c32070c38080c320780a80880980884a246]
    decide +kernel
  have e3729 : Deny 7 11 b3729 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x7 b3729 b3730 b4101 (by decide +kernel) e3730 e4101
  have e3027 : Deny 7 11 b3027 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x8 b3027 b3028 b3729 (by decide +kernel) e3028 e3729
  have e1993 : Deny 7 11 b1993 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b1993 b1994 b3027 (by decide +kernel) e1994 e3027
  have e1805 : Deny 7 11 b1805 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x244 b1805 b1806 b1993 (by decide +kernel) e1806 e1993
  have e4150 : Deny 7 11 b4150 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x71d0a21c688a75c8c71a325c72f8c71a31c28c80a31c68c4]
    decide +kernel
  have e4168 : Deny 7 11 b4168 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0xc28089c31871a02999d98c71a78c96676631c69e32278c76676678c71a78c96676678c81a78c89c46428c71a31071a3,0x199d9]
    decide +kernel
  have e4198 : Deny 7 11 b4198 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x5665555602068099a21d59a22959a222611556c8871a21071a2]
    decide +kernel
  have e4214 : Deny 7 11 b4214 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x755995b15b222068870a22222999d96632068c70a32068c911d7632068c41c6]
    decide +kernel
  have e4238 : Deny 7 11 b4238 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x8c80c31a31c28c81a31e325d0c22030881890c61ca0887431890c61dd20625d74818718a75d8c71a321d7632068c71a3,0x7590c31870c21c624a0c6]
    decide +kernel
  have e4291 : Deny 7 11 b4291 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x88788a7550c62422021c628975d8871a22221d588a55d8871a221d0c28870880a21c688a75d1c62428870a220688788a,0x1d75588a75588a8887550c320954308824729d74718825d5430e21c3242888]
    decide +kernel
  have e4237 : Deny 7 11 b4237 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x9 b4237 b4238 b4291 (by decide +kernel) e4238 e4291
  have e4368 : Deny 7 11 b4368 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x71cbe31c68c4]
    decide +kernel
  have e4236 : Deny 7 11 b4236 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x2e3 b4236 b4237 b4368 (by decide +kernel) e4237 e4368
  have e4374 : Deny 7 11 b4374 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0xc70a02202a025d0c680a76780975d1c61c68080c28080c22070a02828090a020680a0c28080a02428081a78090a0220,0x7420e022029d0c31c30c61c8287743]
    decide +kernel
  have e4431 : Deny 7 11 b4431 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0xe02278099c20c80c320a0c32030882891dd0c69e02670c61c680880a8c97596598081a780a6598c81a31c68c98c88c7,0x999e322775908380a64380a]
    decide +kernel
  have e4373 : Deny 7 11 b4373 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x2a3 b4373 b4374 b4431 (by decide +kernel) e4374 e4431
  have e4482 : Deny 7 11 b4482 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x959a02202559a02950952150c95481c954a1d580880988a55d5558091a680a5551c680875d2061e025588a88888788a,0x75599509d5550e026026680a8087550825432481c929d5550c624318724a207809555]
    decide +kernel
  have e4372 : Deny 7 11 b4372 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x9 b4372 b4373 b4482 (by decide +kernel) e4373 e4482
  have e4563 : Deny 7 11 b4563 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1d5660a21c28881a22999d96632068c70a32068c9184]
    decide +kernel
  have e4371 : Deny 7 11 b4371 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xb b4371 b4372 b4563 (by decide +kernel) e4372 e4563
  have e4235 : Deny 7 11 b4235 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x7 b4235 b4236 b4371 (by decide +kernel) e4236 e4371
  have e4213 : Deny 7 11 b4213 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x8 b4213 b4214 b4235 (by decide +kernel) e4214 e4235
  have e4197 : Deny 7 11 b4197 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b4197 b4198 b4213 (by decide +kernel) e4198 e4213
  have e4167 : Deny 7 11 b4167 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x244 b4167 b4168 b4197 (by decide +kernel) e4168 e4197
  have e4149 : Deny 7 11 b4149 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x1c6 b4149 b4150 b4167 (by decide +kernel) e4150 e4167
  have e4580 : Deny 7 11 b4580 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1b6ab8c7adb8c86e325aadaae31c68c70a31c68c4]
    decide +kernel
  have e4593 : Deny 7 11 b4593 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x8c88c76db8081a780a6676598c71a78c79e32199d96708c71a31c69e326711b6e31c68c41c68c84e58440a11071a1284,0xae31c68c46db4e12828496db1c621b6e11c68471a128b8c76d39538471a12846db8c71a31071896676d99d96632468c7,0x1b4e129b6e32468c811b4db4e029b6db8091a02868084d31c680980884a2daada]
    decide +kernel
  have e4579 : Deny 7 11 b4579 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x1c6 b4579 b4580 b4593 (by decide +kernel) e4580 e4593
  have e4684 : Deny 7 11 b4684 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0xaa126a5e22165aa849a965a22168871a22221d75aa5aa8871a21c688a2d70a11c68495c28871a22168968871a21c6884,0x5aa5aa887184597]
    decide +kernel
  have e4722 : Deny 7 11 b4722 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x20688a2df7e31c68c972f7e325cbdf8c98c772f7e325cbdc8c91a31e321f88a7e325c7231c68c771c8c71a32068c71a3,0xbdc8c972321f88a8c77e326321f7d77df8871a222229f7c81897df8881a21df7e21c68881a229f7e22068877df8871a2,0x1f7e31c68c47c272f8c77e325cbdf72321c8c78c98c87e229c]
    decide +kernel
  have e4817 : Deny 7 11 b4817 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x69fae129aadaae31c6ae326b7df8c71a32046ab6ab8c71a31071a3]
    decide +kernel
  have e4833 : Deny 7 11 b4833 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1a32231db08729b6e31c68c96c28c71a32028c71a326321f7df8471a129f0a12428471a125f7c71887df8471a11c684a,0x7e12a31daada8c86df0e12438470c318721f6e12428471a12868476e126129a69a8471a12a31e325f6c36a31c3087283,0x2adf8c87e129aadf8c8]
    decide +kernel
  have e4922 : Deny 7 11 b4922 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1f6ab6ab8c71a325aadaae31c68c70a31c68c4]
    decide +kernel
  have e4832 : Deny 7 11 b4832 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xb b4832 b4833 b4922 (by decide +kernel) e4833 e4922
  have e4816 : Deny 7 11 b4816 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x1e3 b4816 b4817 b4832 (by decide +kernel) e4817 e4832
  have e4936 : Deny 7 11 b4936 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x16a9f8885aa5a2222296a965a21c68885a22a21df7e11c68497c28871a2222]
    decide +kernel
  have e4959 : Deny 7 11 b4959 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x84a8c78c979c7e229c7e22a31df8c98c87e229e71f88a71c8c81a31de8c91a321e7a21c688a8c77de7a31c68c78c98c8,0x1a11e125f79688a8877de78818726222228709aae325f8c87e129a7a129a7a12a31daae325e69a1c68c91a321e7a11c6,0x7967e125f88888a7967de7aa84a]
    decide +kernel
  have e4935 : Deny 7 11 b4935 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b4935 b4936 b4959 (by decide +kernel) e4936 e4959
  have e5052 : Deny 7 11 b5052 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1e5aa7a221e8871a229e8c97a3206787184]
    decide +kernel
  have e4934 : Deny 7 11 b4934 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xb b4934 b4935 b5052 (by decide +kernel) e4935 e5052
  have e5069 : Deny 7 11 b5069 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x8825f7e220688788888a7d65a220688a8877d67df2062565881877df1c620629f7c818725f7e21c688888a7df206262,0x7df59f5828881a229f0a22a221f08a]
    decide +kernel
  have e5129 : Deny 7 11 b5129 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x7df5ca7d70c62570891875d71c620a25f7d72831877d72821c97df1c620a7df2062477d729f7c81897df2061c620a]
    decide +kernel
  have e5184 : Deny 7 11 b5184 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x7d788a7d72897df5e229f5ca25f0a229f7c81891a21df5e22828880a21c688888a7df5ca08708818a2621e2]
    decide +kernel
  have e5227 : Deny 7 11 b5227 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x2622a221f0c324a0c82621e222229f7d729f5ca25f58a7d72891df5ca7d72887d72832090c31887df2062461c8289887,0x9f5ca25f09688709f5e22a221f5ca7d728825f0c326229f0c3]
    decide +kernel
  have e5183 : Deny 7 11 b5183 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x222 b5183 b5184 b5227 (by decide +kernel) e5184 e5227
  have e5312 : Deny 7 11 b5312 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1f]
    decide +kernel
  have e5182 : Deny 7 11 b5182 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b5182 b5183 b5312 (by decide +kernel) e5183 e5312
  have e5128 : Deny 7 11 b5128 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x9 b5128 b5129 b5182 (by decide +kernel) e5129 e5182
  have e5068 : Deny 7 11 b5068 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x1e2 b5068 b5069 b5128 (by decide +kernel) e5069 e5128
  have e5315 : Deny 7 11 b5315 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1f7df0c320284984a7c22887c284a0881a11df7e11c684984a7df8491a11df7e11c68491a12a1]
    decide +kernel
  have e5348 : Deny 7 11 b5348 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x2211df5e129f5ca21f5e12832211e12612a11df5df5c284984a7c284a84784984a7df5e12828470a124684a84784984a,0x1f7d784a7c27d72887c20e126129f0c321724a]
    decide +kernel
  have e5314 : Deny 7 11 b5314 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x1e1 b5314 b5315 b5348 (by decide +kernel) e5315 e5348
  have e5413 : Deny 7 11 b5413 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x7d60c928824722128988788888a7d6a967d67d684a5a11e12567d629f58a2161c92212a12567d684a84988788888a887,0x7d6a8259f082582]
    decide +kernel
  have e5313 : Deny 7 11 b5313 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x9 b5313 b5314 b5413 (by decide +kernel) e5314 e5413
  have e5067 : Deny 7 11 b5067 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x222 b5067 b5068 b5313 (by decide +kernel) e5068 e5313
  have e5470 : Deny 7 11 b5470 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x27e325f8c8]
    decide +kernel
  have e5066 : Deny 7 11 b5066 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b5066 b5067 b5470 (by decide +kernel) e5067 e5470
  have e5475 : Deny 7 11 b5475 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1f79f88a1df8c97e321f5aa5a222229f7e11c68495968871a21df7e21c68881a2284]
    decide +kernel
  have e5065 : Deny 7 11 b5065 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xb b5065 b5066 b5475 (by decide +kernel) e5066 e5475
  have e4933 : Deny 7 11 b4933 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x7 b4933 b4934 b5065 (by decide +kernel) e4934 e5065
  have e4815 : Deny 7 11 b4815 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x9 b4815 b4816 b4933 (by decide +kernel) e4816 e4933
  have e4721 : Deny 7 11 b4721 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x204 b4721 b4722 b4815 (by decide +kernel) e4722 e4815
  have e4683 : Deny 7 11 b4683 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x286 b4683 b4684 b4721 (by decide +kernel) e4684 e4721
  have e5504 : Deny 7 11 b5504 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x9978875665555471a02468878882d78845665668871a21081a22978178081a69602665d55621c68881828871a21c6888,0x9538471844d35c28090a02068084d31c69602468082d310280420684a4d30880871881a10a11c68478495660a21c6115,0x174d78085e11e12578881170978478495e220b5ca5e21d3]
    decide +kernel
  have e5595 : Deny 7 11 b5595 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1f0c31c30c72030870882830870881890c22021c61df7c71882830c61c22430871880871897df1c61df7c7188184]
    decide +kernel
  have e5647 : Deny 7 11 b5647 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1f6430c61ca0a32431a31c28c81a325f7e32068c71a3]
    decide +kernel
  have e5666 : Deny 7 11 b5666 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x30e31c30c61ca0c68c70c28c71a321b6e31c68c91a3]
    decide +kernel
  have e5683 : Deny 7 11 b5683 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1ca8c78c86d90c31872828c71a322325b0c31c80c31c30c720a0c31c30872870c31c30872830871871886c22021c624a,0x26c20c720a0c38c70c31ca8c76430c72830e31c30c6]
    decide +kernel
  have e5665 : Deny 7 11 b5665 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x1e3 b5665 b5666 b5683 (by decide +kernel) e5666 e5683
  have e5762 : Deny 7 11 b5762 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1f]
    decide +kernel
  have e5664 : Deny 7 11 b5664 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x9 b5664 b5665 b5762 (by decide +kernel) e5665 e5762
  have e5646 : Deny 7 11 b5646 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x204 b5646 b5647 b5664 (by decide +kernel) e5647 e5664
  have e5594 : Deny 7 11 b5594 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 3
      0xa1a3 b5594 b5595 b5646 (by decide +kernel) e5595 e5646
  have e5764 : Deny 7 11 b5764 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0xe02430a02602838080a02830a68081a02429a022029f0e02438080c280880a0a02429e58081a78098047e79a01081a0,0x7c2]
    decide +kernel
  have e5801 : Deny 7 11 b5801 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x6676426678089e02990c32031ca8c76676592868c78c96676631d98c98c80c31a02031c280a0a02428081a02a31e3263,0x6677c265f80a8c97e31e321f80a8c7]
    decide +kernel
  have e5854 : Deny 7 11 b5854 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x7c380980a80880a0838080c32070c31a02202a021b0c31a025b6e024680880a0c29e02670c22461c680880980a8c78c9,0xa77e31d99c20990820c81ca8c78c86d90836678089e02602990c32430c62472a31e32232420831c20c7]
    decide +kernel
  have e5800 : Deny 7 11 b5800 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x8 b5800 b5801 b5854 (by decide +kernel) e5801 e5854
  have e5935 : Deny 7 11 b5935 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x6676678c76678c89df8c76676598c71a31c68c96676598c81a31c68c88c4]
    decide +kernel
  have e5799 : Deny 7 11 b5799 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xb b5799 b5800 b5935 (by decide +kernel) e5800 e5935
  have e5763 : Deny 7 11 b5763 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b5763 b5764 b5799 (by decide +kernel) e5764 e5799
  have e5593 : Deny 7 11 b5593 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x1e3 b5593 b5594 b5763 (by decide +kernel) e5594 e5763
  have e5959 : Deny 7 11 b5959 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x7df0a229f7c81897df8881a21e229f7e22868877df1c625f7e21c68881a2]
    decide +kernel
  have e5984 : Deny 7 11 b5984 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x5550e21d508725588a5622221d508725588a1a21d588888a7c30c90c62030c90881c228308908808718908708818a189,0x7d55430c70c31872831882550c31c22822091d5289]
    decide +kernel
  have e5958 : Deny 7 11 b5958 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x1e2 b5958 b5959 b5984 (by decide +kernel) e5959 e5984
  have e6062 : Deny 7 11 b6062 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x5e22828888870c32572822021c90a22828871a222229f5c30c92170c62075ca0c22021c62570881877df1c6206286262,0x1f5c25e22820c75ca2430e21c308724288a8880c38870c9]
    decide +kernel
  have e6138 : Deny 7 11 b6138 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1891c20830c72880c32090c32030c62091d708808718a0c31890c62030881871890c31880c22061c308808718918720a,0x7d75c32570c91d70c95c32472172895d70c90c62175c8187]
    decide +kernel
  have e6223 : Deny 7 11 b6223 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x5ca2420831c95438875421c988a88888755756220688788a0952832550c92020c75ca0c90c31891881d508718a2621e2,0x5425420831ca2485425ca2550830c72892075d50c21c92175551c6207289095888082]
    decide +kernel
  have e6318 : Deny 7 11 b6318 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x17]
    decide +kernel
  have e6222 : Deny 7 11 b6222 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x222 b6222 b6223 b6318 (by decide +kernel) e6223 e6318
  have e6319 : Deny 7 11 b6319 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1f]
    decide +kernel
  have e6221 : Deny 7 11 b6221 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b6221 b6222 b6319 (by decide +kernel) e6222 e6319
  have e6137 : Deny 7 11 b6137 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x9 b6137 b6138 b6221 (by decide +kernel) e6138 e6221
  have e6061 : Deny 7 11 b6061 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x7 b6061 b6062 b6137 (by decide +kernel) e6062 e6137
  have e5957 : Deny 7 11 b5957 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x222 b5957 b5958 b6061 (by decide +kernel) e5958 e6061
  have e6320 : Deny 7 11 b6320 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x7df887184]
    decide +kernel
  have e5956 : Deny 7 11 b5956 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x2e2 b5956 b5957 b6320 (by decide +kernel) e5957 e6320
  have e6323 : Deny 7 11 b6323 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1dc8c81a31c68c88c47dd7dd7e229d7e22a21e222228275c7622a31dd8c98c87e22a31df75f8c98c87ca7e31e326320b,0x1f75f7e21c688a75d8c71a325cbdd8c9723]
    decide +kernel
  have e5955 : Deny 7 11 b5955 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x2a3 b5955 b5956 b6323 (by decide +kernel) e5956 e6323
  have e6381 : Deny 7 11 b6381 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x2831882475428095668089955481871a02830a02428081a02550d580880956029508954a1c28090a02069a02202a0262,0x1598256221588a8877c209580a8080c39a02202660950c95432472830c75551c62880c31c3087]
    decide +kernel
  have e6462 : Deny 7 11 b6462 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0xc91c85c30872091e02a02170825e02a022025780a0c31c30c70c318780a8080c31a02202570a020680a80880980a809,0x159a20975622222a21c67d70820820838090c72882470970e6808809997543255]
    decide +kernel
  have e6380 : Deny 7 11 b6380 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x8 b6380 b6381 b6462 (by decide +kernel) e6381 e6462
  have e6539 : Deny 7 11 b6539 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x5667d55d59889955481871895558871a21d588888a8877df8081a02559955622068871a2204]
    decide +kernel
  have e6379 : Deny 7 11 b6379 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x2e2 b6379 b6380 b6539 (by decide +kernel) e6380 e6539
  have e6568 : Deny 7 11 b6568 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x2599dd9e31d99e32678c89df7596632068c97706708c81a31c68c87c28081a02868c78c92040820a709f80a8c78c920b,0x7e27e22867e31df8c97557e680955d56680a9a026688888a75f55f74818975d8881a21e22222a31d99df9e31d99e3]
    decide +kernel
  have e6378 : Deny 7 11 b6378 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b6378 b6379 b6568 (by decide +kernel) e6379 e6568
  have e5954 : Deny 7 11 b5954 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x7 b5954 b5955 b6378 (by decide +kernel) e5955 e6378
  have e5592 : Deny 7 11 b5592 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x9 b5592 b5593 b5954 (by decide +kernel) e5593 e5954
  have e6645 : Deny 7 11 b6645 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0xe12611df0c97c224721f0a125f4c91880a11e12830880a11c68477c22421c22021c62030880a12428470a11c68491a1,0x7c20c80e12a125f]
    decide +kernel
  have e6701 : Deny 7 11 b6701 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x134c81a1]
    decide +kernel
  have e6705 : Deny 7 11 b6705 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0xc81c30880c22061ca2030c80c32074c22021ca0c22021c62074c32031890c22474c31884c94c7283089087188087189,0x27c32480c32074df4c92130c81ca0c3203]
    decide +kernel
  have e6786 : Deny 7 11 b6786 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x4d309f0c92211d384a4df0c90c81d32888474d3847849]
    decide +kernel
  have e6704 : Deny 7 11 b6704 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x8 b6704 b6705 b6786 (by decide +kernel) e6705 e6786
  have e6700 : Deny 7 11 b6700 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b6700 b6701 b6704 (by decide +kernel) e6701 e6704
  have e6644 : Deny 7 11 b6644 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x1e1 b6644 b6645 b6700 (by decide +kernel) e6645 e6700
  have e6814 : Deny 7 11 b6814 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0xc320318a0c22062430881870c21c62021c6]
    decide +kernel
  have e6834 : Deny 7 11 b6834 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0xc320284a0c68490c22028491a11c30890871881a1]
    decide +kernel
  have e6853 : Deny 7 11 b6853 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x18a1c80c38470a12430871880a11c684a0838470c84c284708884a4e12430a11c284a0a12611c30c808a4c9087206849,0x820c80e12612820e12430c80a12612a11c20832480c324308920a0c3243203088089]
    decide +kernel
  have e6833 : Deny 7 11 b6833 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x7 b6833 b6834 b6853 (by decide +kernel) e6834 e6853
  have e6813 : Deny 7 11 b6813 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 3
      0x81a1 b6813 b6814 b6833 (by decide +kernel) e6814 e6833
  have e6940 : Deny 7 11 b6940 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1f]
    decide +kernel
  have e6812 : Deny 7 11 b6812 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x2a1 b6812 b6813 b6940 (by decide +kernel) e6813 e6940
  have e6944 : Deny 7 11 b6944 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x24ca0832430c92880932434c92830c90c62881d308808718a0c32030881871884c3088087188189]
    decide +kernel
  have e6991 : Deny 7 11 b6991 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x5c22481ca0820c92832020c90c324a0c81d70890880872884c20c31ca2132530c84c91d32830c80c62430880891c6209,0x208208324a2074c30c70c9213]
    decide +kernel
  have e6943 : Deny 7 11 b6943 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x7 b6943 b6944 b6991 (by decide +kernel) e6944 e6991
  have e7070 : Deny 7 11 b7070 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1f]
    decide +kernel
  have e6942 : Deny 7 11 b6942 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b6942 b6943 b7070 (by decide +kernel) e6943 e7070
  have e7071 : Deny 7 11 b7071 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1f4c24c209324a0834c92881c84e129384984784a]
    decide +kernel
  have e6941 : Deny 7 11 b6941 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x8 b6941 b6942 b7071 (by decide +kernel) e6942 e7071
  have e6811 : Deny 7 11 b6811 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x7 b6811 b6812 b6941 (by decide +kernel) e6812 e6941
  have e6643 : Deny 7 11 b6643 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x261 b6643 b6644 b6811 (by decide +kernel) e6644 e6811
  have e7094 : Deny 7 11 b7094 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x7df847184]
    decide +kernel
  have e6642 : Deny 7 11 b6642 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x2e1 b6642 b6643 b7094 (by decide +kernel) e6643 e7094
  have e7101 : Deny 7 11 b7101 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0xc92831c829b0c31870c21c620a1db0c225b6c91876db1c620a6db1c61c96c30c61db6c718829b6c81876db1c62482a3,0x1b6c27c324a7db25f0c92877db25f]
    decide +kernel
  have e7174 : Deny 7 11 b7174 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0xc31891c30c62430891c828725b0827c324a0c720a6c30c70c31c82876c30c90c31891c30c624318720a6db2861c920a,0x1b09b0827db25f0c928720a1db4c20c90c324720a6c20c9]
    decide +kernel
  have e7100 : Deny 7 11 b7100 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x1e3 b7100 b7101 b7174 (by decide +kernel) e7101 e7174
  have e7263 : Deny 7 11 b7263 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1f]
    decide +kernel
  have e7099 : Deny 7 11 b7099 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x263 b7099 b7100 b7263 (by decide +kernel) e7100 e7263
  have e7264 : Deny 7 11 b7264 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x84a6db7c384984a6df0a12612a11e12a11db6c30c80c684984a6c30a12612a11e129b6db8471a128684784984a8c78c9,0x28427e12a11c66c209b6c24e126129b0830c884984a84784a84784984a0ab6e321b09b7c384984a847]
    decide +kernel
  have e7098 : Deny 7 11 b7098 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x8 b7098 b7099 b7264 (by decide +kernel) e7099 e7264
  have e7341 : Deny 7 11 b7341 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x6ab6ab8c8ae326b8c7adf8c87e12a31db6db8471a129b6ab6ab8c71a31c68c78c97db6e31c68c96df8c71a31c68c88c4,0x6df84a7da6eb84aae325f]
    decide +kernel
  have e7097 : Deny 7 11 b7097 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xb b7097 b7098 b7341 (by decide +kernel) e7098 e7341
  have e6641 : Deny 7 11 b6641 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x2a3 b6641 b6642 b7097 (by decide +kernel) e6642 e7097
  have e7386 : Deny 7 11 b7386 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x80980880a08380a0e02430c62470c31870a02602130a020680a8098084c34e025380a0d32532870a02028091a02202a0,0x20932874e02427c38097c32478087c38097c32477c3]
    decide +kernel
  have e7453 : Deny 7 11 b7453 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0xd78080e58090c224780880a0838090930c82832470831c30a02202838098084c38084c22074e024280880a80980880a,0x7c24e024208208324a1e0202083203247]
    decide +kernel
  have e7385 : Deny 7 11 b7385 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x260 b7385 b7386 b7453 (by decide +kernel) e7386 e7453
  have e7520 : Deny 7 11 b7520 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x13]
    decide +kernel
  have e7384 : Deny 7 11 b7384 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x221 b7384 b7385 b7520 (by decide +kernel) e7385 e7520
  have e7521 : Deny 7 11 b7521 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x137d30a02202937e02068097df2061c28081a0204]
    decide +kernel
  have e7383 : Deny 7 11 b7383 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x2e1 b7383 b7384 b7521 (by decide +kernel) e7384 e7521
  have e7539 : Deny 7 11 b7539 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x826e76c209b0820e02602026c30c72890c32481e02a026020a8c78c98c8]
    decide +kernel
  have e7570 : Deny 7 11 b7570 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x8c725b6677db6677e31e32232631e321f9e580a9df8c76e76db4c28080871a029b6c71a021b6c718718a1a31e3263204,0x9b7e12a31db4db4e580a6d39602a026022129b4db4ca21b4e12a11d36db1c62136e11c684784984a]
    decide +kernel
  have e7538 : Deny 7 11 b7538 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xb b7538 b7539 b7570 (by decide +kernel) e7539 e7570
  have e7382 : Deny 7 11 b7382 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b7382 b7383 b7538 (by decide +kernel) e7383 e7538
  have e6640 : Deny 7 11 b6640 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x7 b6640 b6641 b7382 (by decide +kernel) e6641 e7382
  have e7650 : Deny 7 11 b7650 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x832172895c32472172895d70c95c31891d70c62575c81872172891d75c32570c62475c22421c85ca2575ca18720a262,0x27e221788a7d75c25ca2570972891d7]
    decide +kernel
  have e7727 : Deny 7 11 b7727 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x5c20970972891c85ca2475c20970972891c85ca2575c25ca2570832172891d70832172895c30c85ca2472172891c8289,0x5e25e22867c2]
    decide +kernel
  have e7649 : Deny 7 11 b7649 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x1e2 b7649 b7650 b7727 (by decide +kernel) e7650 e7727
  have e7796 : Deny 7 11 b7796 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x827d75c209784a8478495e129709784a0838470c85e12a11e125784a84784984a847849]
    decide +kernel
  have e7648 : Deny 7 11 b7648 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x8 b7648 b7649 b7796 (by decide +kernel) e7649 e7796
  have e7829 : Deny 7 11 b7829 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x5d78471a124684a7df8471a11e125f5e229f5ca7df20625f7c81877df1c62062577df8881a21d77e21c68881a21e2204,0x175977ea847aa126a5df5a229f2621e221788a8877d7]
    decide +kernel
  have e7647 : Deny 7 11 b7647 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x2e2 b7647 b7648 b7829 (by decide +kernel) e7648 e7829
  have e7888 : Deny 7 11 b7888 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1f]
    decide +kernel
  have e7646 : Deny 7 11 b7646 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b7646 b7647 b7888 (by decide +kernel) e7647 e7888
  have e7889 : Deny 7 11 b7889 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x29755f25f8878885e22a21df5d74e02575e02468085e02975c71878095d71c680880a8098881020825e02a02622062ca,0x1f5c24d74e580980884a09f8474e12574e12612a11e12425e2]
    decide +kernel
  have e7645 : Deny 7 11 b7645 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x7 b7645 b7646 b7889 (by decide +kernel) e7646 e7889
  have e6639 : Deny 7 11 b6639 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x9 b6639 b6640 b7645 (by decide +kernel) e6640 e7645
  have e5591 : Deny 7 11 b5591 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x8 b5591 b5592 b6639 (by decide +kernel) e5592 e6639
  have e5503 : Deny 7 11 b5503 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b5503 b5504 b5591 (by decide +kernel) e5504 e5591
  have e7954 : Deny 7 11 b7954 := by
    apply OMA.FastReplay245212.certify _ _ 64 [0x1f5d39578471a12559978871a22175a21c688729f6db8c91a325b6e31c68c71a325f7e31c621f7c7187184]
    decide +kernel
  have e5502 : Deny 7 11 b5502 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xb b5502 b5503 b7954 (by decide +kernel) e5503 e7954
  have e4682 : Deny 7 11 b4682 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x7 b4682 b4683 b5502 (by decide +kernel) e4683 e5502
  have e4578 : Deny 7 11 b4578 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x9 b4578 b4579 b4682 (by decide +kernel) e4579 e4682
  have e4148 : Deny 7 11 b4148 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x206 b4148 b4149 b4578 (by decide +kernel) e4149 e4578
  have e1804 : Deny 7 11 b1804 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xb b1804 b1805 b4148 (by decide +kernel) e1805 e4148
  have e214 : Deny 7 11 b214 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0x7 b214 b215 b1804 (by decide +kernel) e215 e1804
  have e184 : Deny 7 11 b184 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 1
      0xa b184 b185 b214 (by decide +kernel) e185 e214
  have e6 : Deny 7 11 b6 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x206 b6 b7 b184 (by decide +kernel) e7 e184
  have e2 : Deny 7 11 b2 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 2
      0x1c6 b2 b3 b6 (by decide +kernel) e3 e6
  have e0 : Deny 7 11 b0 :=
    branch (fun _ _ _ _ f c=>fastDigit_sound f c) leaf_sound _ _ 3
      0x8184 b0 b1 b2 (by decide +kernel) e1 e2
  exact e0
end OMA.Blocks7_11_245212
