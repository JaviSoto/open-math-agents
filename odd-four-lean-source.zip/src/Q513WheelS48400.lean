import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S48400
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b48400 : Box := ![⟨383,1920000000000000011376⟩,⟨18,20⟩,⟨63,1920000000000000011376⟩,⟨1,1141211589113257249985⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨383,1920000000000000011376⟩,⟨18,20⟩,⟨63,1920000000000000011376⟩,⟨1,1141211589113257249985⟩,⟨479,999999999999999999⟩] := by
  have e48400 : Deny 5 13 b48400 := by
    apply closeAction rule_sound _ _ 64 [0x74b8dd2e37678cb8dd9e32e37678cb8dd9e32e37678cb8dd9e32e37678cb8dd9e32f88c98c7e159a02a32389e31e3278,0xe231f89e32788c2082082083e232788c7e232788c7e232788c7e1d76775d7512d12c227680a44b44b2b61d12ca8dd2e3,0x8208208209d9e32788c9]
    decide +kernel
  exact e48400
end OMA.Blocks5_13_245212.S48400
