import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S46851
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b46851 : Box := ![⟨191,1920000000000000011376⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨1,1285697329376854607056⟩,⟨239,478⟩]
theorem deny5_13 : Deny 5 13 ![⟨191,1920000000000000011376⟩,⟨15,20⟩,⟨31,1920000000000000011376⟩,⟨1,1285697329376854607056⟩,⟨239,478⟩] := by
  have e46851 : Deny 5 13 b46851 := by
    apply closeAction rule_sound _ _ 64 [0x88ae159a22a323875d88a54a8c754a6677678c79dd9dd55d54ae20255e3680829d9e32631e31d59a02a32632159a22a3,0x15e378c29dd9dd0a6778748e1598a1f898ae159a02a31e31e3278578de3755766809]
    decide +kernel
  exact e46851
end OMA.Blocks5_13_245212.S46851
