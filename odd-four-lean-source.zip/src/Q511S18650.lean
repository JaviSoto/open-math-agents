import FastReplay245212
import SparseDigit245212
import FastRound245212
import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S18650
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b18650 : Box := ![⟨47,1920000000000000011376⟩,⟨10,14⟩,⟨7,14⟩,⟨1,1450666666666666675297⟩,⟨103,999999999999999999⟩]
private def b18651 : Box := ![⟨47,94⟩,⟨10,14⟩,⟨7,14⟩,⟨1,455859649122807020277⟩,⟨103,999999999999999999⟩]
private def b18652 : Box := ![⟨47,94⟩,⟨10,14⟩,⟨7,14⟩,⟨1,45⟩,⟨103,206⟩]
private def b18653 : Box := ![⟨47,94⟩,⟨10,11⟩,⟨7,14⟩,⟨1,37⟩,⟨103,199⟩]
private def b18654 : Box := ![⟨47,94⟩,⟨10,11⟩,⟨7,9⟩,⟨1,36⟩,⟨103,199⟩]
private def b18661 : Box := ![⟨47,94⟩,⟨10,11⟩,⟨10,14⟩,⟨1,36⟩,⟨103,199⟩]
private def b18662 : Box := ![⟨47,62⟩,⟨10,11⟩,⟨10,14⟩,⟨1,36⟩,⟨103,199⟩]
private def b18665 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨10,14⟩,⟨1,36⟩,⟨103,199⟩]
private def b18666 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨10,14⟩,⟨2,36⟩,⟨103,135⟩]
private def b18677 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨10,14⟩,⟨2,36⟩,⟨136,199⟩]
private def b18684 : Box := ![⟨47,94⟩,⟨12,14⟩,⟨7,14⟩,⟨1,37⟩,⟨103,199⟩]
private def b18685 : Box := ![⟨47,94⟩,⟨12,14⟩,⟨7,9⟩,⟨1,37⟩,⟨103,199⟩]
private def b18696 : Box := ![⟨47,94⟩,⟨12,14⟩,⟨10,14⟩,⟨1,37⟩,⟨103,199⟩]
private def b18711 : Box := ![⟨47,94⟩,⟨10,14⟩,⟨7,14⟩,⟨1,45⟩,⟨207,999999999999999999⟩]
private def b18712 : Box := ![⟨47,94⟩,⟨10,11⟩,⟨7,14⟩,⟨1,39⟩,⟨207,999999999999999999⟩]
private def b18719 : Box := ![⟨47,94⟩,⟨12,14⟩,⟨7,14⟩,⟨1,39⟩,⟨207,999999999999999999⟩]
private def b18720 : Box := ![⟨47,94⟩,⟨12,14⟩,⟨7,9⟩,⟨1,39⟩,⟨207,999999999999999999⟩]
private def b18729 : Box := ![⟨47,94⟩,⟨12,14⟩,⟨10,14⟩,⟨1,39⟩,⟨207,999999999999999999⟩]
private def b18730 : Box := ![⟨47,62⟩,⟨12,14⟩,⟨10,14⟩,⟨1,39⟩,⟨207,999999999999999999⟩]
private def b18735 : Box := ![⟨63,94⟩,⟨12,14⟩,⟨10,14⟩,⟨1,39⟩,⟨207,999999999999999999⟩]
private def b18736 : Box := ![⟨63,94⟩,⟨12,14⟩,⟨10,14⟩,⟨1,39⟩,⟨207,414⟩]
private def b18749 : Box := ![⟨63,94⟩,⟨12,14⟩,⟨10,14⟩,⟨1,39⟩,⟨415,999999999999999999⟩]
private def b18760 : Box := ![⟨95,1920000000000000011376⟩,⟨10,14⟩,⟨7,14⟩,⟨1,455859649122807020277⟩,⟨103,999999999999999999⟩]
private def b18761 : Box := ![⟨95,1920000000000000011376⟩,⟨10,14⟩,⟨7,14⟩,⟨1,455859649122807020277⟩,⟨103,206⟩]
private def b18762 : Box := ![⟨95,1920000000000000011376⟩,⟨10,14⟩,⟨7,14⟩,⟨1,2⟩,⟨103,199⟩]
private def b18763 : Box := ![⟨95,1920000000000000011376⟩,⟨10,14⟩,⟨7,14⟩,⟨3,455859649122807020269⟩,⟨103,199⟩]
private def b18764 : Box := ![⟨95,1920000000000000011376⟩,⟨10,14⟩,⟨7,14⟩,⟨3,6⟩,⟨103,199⟩]
private def b18765 : Box := ![⟨95,1920000000000000011376⟩,⟨10,14⟩,⟨7,14⟩,⟨7,455859649122807020269⟩,⟨103,199⟩]
private def b18766 : Box := ![⟨95,1920000000000000011376⟩,⟨10,11⟩,⟨7,14⟩,⟨7,455859649122807020269⟩,⟨103,199⟩]
private def b18767 : Box := ![⟨95,1920000000000000011376⟩,⟨10,11⟩,⟨7,9⟩,⟨7,455859649122807020268⟩,⟨103,199⟩]
private def b18774 : Box := ![⟨95,1920000000000000011376⟩,⟨10,11⟩,⟨10,14⟩,⟨7,455859649122807020268⟩,⟨103,199⟩]
private def b18785 : Box := ![⟨95,1920000000000000011376⟩,⟨12,14⟩,⟨7,14⟩,⟨7,455859649122807020269⟩,⟨103,199⟩]
private def b18796 : Box := ![⟨95,1920000000000000011376⟩,⟨10,14⟩,⟨7,14⟩,⟨1,455859649122807020277⟩,⟨207,999999999999999999⟩]
private def b18797 : Box := ![⟨95,1920000000000000011376⟩,⟨10,11⟩,⟨7,14⟩,⟨1,396097560975609758472⟩,⟨207,999999999999999999⟩]
private def b18798 : Box := ![⟨95,1920000000000000011376⟩,⟨10,11⟩,⟨7,14⟩,⟨1,2⟩,⟨207,999999999999999999⟩]
private def b18799 : Box := ![⟨95,1920000000000000011376⟩,⟨10,11⟩,⟨7,14⟩,⟨3,396097560975609758472⟩,⟨207,999999999999999999⟩]
private def b18800 : Box := ![⟨95,1920000000000000011376⟩,⟨10,11⟩,⟨7,9⟩,⟨3,396097560975609758472⟩,⟨207,999999999999999999⟩]
private def b18809 : Box := ![⟨95,1920000000000000011376⟩,⟨10,11⟩,⟨10,14⟩,⟨3,396097560975609758472⟩,⟨207,999999999999999999⟩]
private def b18810 : Box := ![⟨95,190⟩,⟨10,11⟩,⟨10,14⟩,⟨3,396097560975609758472⟩,⟨207,999999999999999999⟩]
private def b18811 : Box := ![⟨95,190⟩,⟨10,11⟩,⟨10,14⟩,⟨3,58⟩,⟨207,414⟩]
private def b18822 : Box := ![⟨95,190⟩,⟨10,11⟩,⟨10,14⟩,⟨3,58⟩,⟨415,999999999999999999⟩]
private def b18823 : Box := ![⟨95,126⟩,⟨10,11⟩,⟨10,14⟩,⟨3,51⟩,⟨415,999999999999999999⟩]
private def b18828 : Box := ![⟨127,190⟩,⟨10,11⟩,⟨10,14⟩,⟨3,51⟩,⟨415,999999999999999999⟩]
private def b18839 : Box := ![⟨191,1920000000000000011376⟩,⟨10,11⟩,⟨10,14⟩,⟨3,396097560975609758472⟩,⟨207,999999999999999999⟩]
private def b18840 : Box := ![⟨191,1920000000000000011376⟩,⟨10,11⟩,⟨10,14⟩,⟨3,396097560975609758472⟩,⟨207,414⟩]
private def b18843 : Box := ![⟨191,1920000000000000011376⟩,⟨10,11⟩,⟨10,14⟩,⟨3,396097560975609758472⟩,⟨415,999999999999999999⟩]
private def b18844 : Box := ![⟨191,382⟩,⟨10,11⟩,⟨10,14⟩,⟨3,350188679245283020967⟩,⟨415,999999999999999999⟩]
private def b18845 : Box := ![⟨191,382⟩,⟨10,11⟩,⟨10,14⟩,⟨4,86⟩,⟨415,830⟩]
private def b18846 : Box := ![⟨191,382⟩,⟨10,11⟩,⟨10,14⟩,⟨4,86⟩,⟨831,999999999999999999⟩]
private def b18847 : Box := ![⟨191,382⟩,⟨10,11⟩,⟨10,14⟩,⟨4,77⟩,⟨831,1662⟩]
private def b18848 : Box := ![⟨191,382⟩,⟨10,11⟩,⟨10,14⟩,⟨4,77⟩,⟨1663,999999999999999999⟩]
private def b18849 : Box := ![⟨191,382⟩,⟨10,11⟩,⟨10,14⟩,⟨4,70⟩,⟨1663,3326⟩]
private def b18850 : Box := ![⟨191,382⟩,⟨10,11⟩,⟨10,14⟩,⟨4,70⟩,⟨3327,999999999999999999⟩]
private def b18851 : Box := ![⟨191,382⟩,⟨10,11⟩,⟨10,14⟩,⟨4,64⟩,⟨3327,6654⟩]
private def b18852 : Box := ![⟨191,382⟩,⟨10,11⟩,⟨10,14⟩,⟨4,64⟩,⟨6655,999999999999999999⟩]
private def b18853 : Box := ![⟨191,382⟩,⟨10,10⟩,⟨10,14⟩,⟨4,59⟩,⟨6655,999999999999999999⟩]
private def b18854 : Box := ![⟨191,382⟩,⟨11,11⟩,⟨10,14⟩,⟨4,59⟩,⟨6655,999999999999999999⟩]
private def b18855 : Box := ![⟨191,382⟩,⟨11,11⟩,⟨10,14⟩,⟨4,59⟩,⟨6655,13310⟩]
private def b18856 : Box := ![⟨191,382⟩,⟨11,11⟩,⟨10,14⟩,⟨4,59⟩,⟨13311,999999999999999999⟩]
private def b18857 : Box := ![⟨191,382⟩,⟨11,11⟩,⟨10,14⟩,⟨4,55⟩,⟨13311,26622⟩]
private def b18858 : Box := ![⟨191,382⟩,⟨11,11⟩,⟨10,14⟩,⟨4,55⟩,⟨26623,999999999999999999⟩]
private def b18859 : Box := ![⟨191,382⟩,⟨11,11⟩,⟨10,14⟩,⟨4,51⟩,⟨26623,53246⟩]
private def b18860 : Box := ![⟨191,382⟩,⟨11,11⟩,⟨10,14⟩,⟨4,51⟩,⟨53247,999999999999999999⟩]
private def b18861 : Box := ![⟨191,382⟩,⟨11,11⟩,⟨10,14⟩,⟨4,48⟩,⟨53247,106494⟩]
private def b18862 : Box := ![⟨191,382⟩,⟨11,11⟩,⟨10,14⟩,⟨4,48⟩,⟨106495,999999999999999999⟩]
private def b18863 : Box := ![⟨191,382⟩,⟨11,11⟩,⟨10,14⟩,⟨4,45⟩,⟨106495,212990⟩]
private def b18864 : Box := ![⟨191,382⟩,⟨11,11⟩,⟨10,14⟩,⟨4,45⟩,⟨212991,999999999999999999⟩]
private def b18865 : Box := ![⟨191,382⟩,⟨11,11⟩,⟨10,14⟩,⟨4,42⟩,⟨212991,425982⟩]
private def b18866 : Box := ![⟨191,382⟩,⟨11,11⟩,⟨10,14⟩,⟨4,42⟩,⟨425983,999999999999999999⟩]
private def b18867 : Box := ![⟨191,382⟩,⟨11,11⟩,⟨10,14⟩,⟨4,40⟩,⟨425983,851966⟩]
private def b18868 : Box := ![⟨191,382⟩,⟨11,11⟩,⟨10,14⟩,⟨4,40⟩,⟨851967,999999999999999999⟩]
private def b18869 : Box := ![⟨191,382⟩,⟨11,11⟩,⟨10,14⟩,⟨4,7⟩,⟨851967,999999999999999999⟩]
private def b18870 : Box := ![⟨191,320⟩,⟨11,11⟩,⟨11,14⟩,⟨4,7⟩,⟨851967,1703934⟩]
private def b18871 : Box := ![⟨191,320⟩,⟨11,11⟩,⟨11,14⟩,⟨4,7⟩,⟨1703935,999999999999999999⟩]
private def b18872 : Box := ![⟨191,320⟩,⟨11,11⟩,⟨11,14⟩,⟨4,7⟩,⟨1703935,3407870⟩]
private def b18873 : Box := ![⟨191,320⟩,⟨11,11⟩,⟨11,14⟩,⟨4,7⟩,⟨3407871,999999999999999999⟩]
private def b18874 : Box := ![⟨191,320⟩,⟨11,11⟩,⟨11,14⟩,⟨4,7⟩,⟨3407871,6815742⟩]
private def b18875 : Box := ![⟨191,320⟩,⟨11,11⟩,⟨11,14⟩,⟨4,7⟩,⟨6815743,999999999999999999⟩]
private def b18890 : Box := ![⟨191,382⟩,⟨11,11⟩,⟨10,14⟩,⟨8,38⟩,⟨851967,999999999999999999⟩]
private def b18891 : Box := ![⟨383,1920000000000000011376⟩,⟨10,11⟩,⟨10,14⟩,⟨3,350188679245283020967⟩,⟨415,999999999999999999⟩]
private def b18892 : Box := ![⟨383,1920000000000000011376⟩,⟨10,11⟩,⟨10,14⟩,⟨8,350188679245283020967⟩,⟨415,830⟩]
private def b18893 : Box := ![⟨383,1920000000000000011376⟩,⟨10,11⟩,⟨10,14⟩,⟨8,350188679245283020967⟩,⟨831,999999999999999999⟩]
private def b18894 : Box := ![⟨383,1920000000000000011376⟩,⟨10,11⟩,⟨10,14⟩,⟨8,314069298952457697289⟩,⟨831,1662⟩]
private def b18895 : Box := ![⟨383,1920000000000000011376⟩,⟨10,11⟩,⟨10,14⟩,⟨8,314069298952457697289⟩,⟨1663,999999999999999999⟩]
private def b18896 : Box := ![⟨383,1920000000000000011376⟩,⟨10,11⟩,⟨10,14⟩,⟨8,284704163623082543708⟩,⟨1663,3326⟩]
private def b18897 : Box := ![⟨383,1920000000000000011376⟩,⟨10,11⟩,⟨10,14⟩,⟨8,284704163623082543708⟩,⟨3327,999999999999999999⟩]
private def b18898 : Box := ![⟨383,1920000000000000011376⟩,⟨10,11⟩,⟨10,14⟩,⟨8,260360721442885773103⟩,⟨3327,6654⟩]
private def b18899 : Box := ![⟨383,1920000000000000011376⟩,⟨10,11⟩,⟨10,14⟩,⟨8,260360721442885773103⟩,⟨6655,999999999999999999⟩]
private def b18900 : Box := ![⟨383,1920000000000000011376⟩,⟨10,11⟩,⟨10,14⟩,⟨8,239852307692307693745⟩,⟨6655,13310⟩]
private def b18901 : Box := ![⟨383,1920000000000000011376⟩,⟨10,11⟩,⟨10,14⟩,⟨8,239852307692307693745⟩,⟨13311,999999999999999999⟩]
private def b18902 : Box := ![⟨383,1920000000000000011376⟩,⟨10,11⟩,⟨10,11⟩,⟨8,222338847689674844458⟩,⟨13311,999999999999999999⟩]
private def b18909 : Box := ![⟨383,1920000000000000011376⟩,⟨10,11⟩,⟨12,14⟩,⟨8,222338847689674844458⟩,⟨13311,999999999999999999⟩]
private def b18910 : Box := ![⟨383,1920000000000000011376⟩,⟨10,10⟩,⟨12,14⟩,⟨8,222338847689674844458⟩,⟨13311,999999999999999999⟩]
private def b18911 : Box := ![⟨383,1920000000000000011376⟩,⟨10,10⟩,⟨12,14⟩,⟨8,222338847689674844458⟩,⟨13311,26622⟩]
private def b18912 : Box := ![⟨383,1920000000000000011376⟩,⟨10,10⟩,⟨12,14⟩,⟨8,222338847689674844458⟩,⟨26623,999999999999999999⟩]
private def b18913 : Box := ![⟨383,766⟩,⟨10,10⟩,⟨12,14⟩,⟨8,207208931419457736489⟩,⟨26623,999999999999999999⟩]
private def b18920 : Box := ![⟨767,1920000000000000011376⟩,⟨10,10⟩,⟨12,14⟩,⟨8,207208931419457736489⟩,⟨26623,999999999999999999⟩]
private def b18929 : Box := ![⟨383,1920000000000000011376⟩,⟨11,11⟩,⟨12,14⟩,⟨8,222338847689674844458⟩,⟨13311,999999999999999999⟩]
private def b18930 : Box := ![⟨95,1920000000000000011376⟩,⟨12,14⟩,⟨7,14⟩,⟨1,396097560975609758472⟩,⟨207,999999999999999999⟩]
private def b18931 : Box := ![⟨95,1920000000000000011376⟩,⟨12,14⟩,⟨7,9⟩,⟨1,396097560975609758472⟩,⟨207,999999999999999999⟩]
private def b18932 : Box := ![⟨95,1920000000000000011376⟩,⟨12,14⟩,⟨7,9⟩,⟨1,2⟩,⟨207,999999999999999999⟩]
private def b18933 : Box := ![⟨95,1920000000000000011376⟩,⟨12,14⟩,⟨7,9⟩,⟨3,396097560975609758470⟩,⟨207,999999999999999999⟩]
private def b18934 : Box := ![⟨95,190⟩,⟨12,14⟩,⟨7,9⟩,⟨3,396097560975609758470⟩,⟨207,999999999999999999⟩]
private def b18935 : Box := ![⟨95,190⟩,⟨12,14⟩,⟨7,9⟩,⟨3,57⟩,⟨207,414⟩]
private def b18944 : Box := ![⟨95,190⟩,⟨12,14⟩,⟨7,9⟩,⟨3,57⟩,⟨415,999999999999999999⟩]
private def b18945 : Box := ![⟨95,190⟩,⟨12,12⟩,⟨7,9⟩,⟨3,50⟩,⟨415,999999999999999999⟩]
private def b18948 : Box := ![⟨95,190⟩,⟨13,14⟩,⟨7,9⟩,⟨3,50⟩,⟨415,999999999999999999⟩]
private def b18949 : Box := ![⟨95,126⟩,⟨13,14⟩,⟨7,9⟩,⟨3,50⟩,⟨415,999999999999999999⟩]
private def b18952 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨7,9⟩,⟨3,50⟩,⟨415,999999999999999999⟩]
private def b18953 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨7,9⟩,⟨3,50⟩,⟨415,830⟩]
private def b18954 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨7,9⟩,⟨3,50⟩,⟨831,999999999999999999⟩]
private def b18955 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨7,7⟩,⟨3,45⟩,⟨831,999999999999999999⟩]
private def b18956 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,45⟩,⟨831,999999999999999999⟩]
private def b18957 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,45⟩,⟨831,1662⟩]
private def b18958 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,45⟩,⟨1663,999999999999999999⟩]
private def b18959 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,41⟩,⟨1663,3326⟩]
private def b18960 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,41⟩,⟨3327,999999999999999999⟩]
private def b18961 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,37⟩,⟨3327,6654⟩]
private def b18962 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,37⟩,⟨6655,999999999999999999⟩]
private def b18963 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,34⟩,⟨6655,13310⟩]
private def b18964 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,34⟩,⟨13311,999999999999999999⟩]
private def b18965 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,32⟩,⟨13311,26622⟩]
private def b18966 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,32⟩,⟨26623,999999999999999999⟩]
private def b18967 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,29⟩,⟨26623,53246⟩]
private def b18968 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,29⟩,⟨53247,999999999999999999⟩]
private def b18969 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,28⟩,⟨53247,106494⟩]
private def b18970 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,28⟩,⟨106495,999999999999999999⟩]
private def b18971 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,26⟩,⟨106495,212990⟩]
private def b18972 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,26⟩,⟨212991,999999999999999999⟩]
private def b18973 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,24⟩,⟨212991,425982⟩]
private def b18974 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,24⟩,⟨425983,999999999999999999⟩]
private def b18975 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,23⟩,⟨425983,851966⟩]
private def b18976 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,23⟩,⟨851967,999999999999999999⟩]
private def b18977 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,22⟩,⟨851967,1703934⟩]
private def b18978 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,22⟩,⟨1703935,999999999999999999⟩]
private def b18979 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,21⟩,⟨1703935,3407870⟩]
private def b18980 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,21⟩,⟨3407871,999999999999999999⟩]
private def b18981 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,20⟩,⟨3407871,6815742⟩]
private def b18982 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,20⟩,⟨6815743,999999999999999999⟩]
private def b18983 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,19⟩,⟨6815743,13631486⟩]
private def b18984 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,19⟩,⟨13631487,999999999999999999⟩]
private def b18985 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,18⟩,⟨13631487,27262974⟩]
private def b18986 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,18⟩,⟨27262975,999999999999999999⟩]
private def b18987 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,5⟩,⟨27262975,999999999999999999⟩]
private def b18988 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,5⟩,⟨27262975,54525950⟩]
private def b18989 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,5⟩,⟨54525951,999999999999999999⟩]
private def b18990 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,5⟩,⟨54525951,109051902⟩]
private def b18991 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,5⟩,⟨109051903,999999999999999999⟩]
private def b18992 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,5⟩,⟨109051903,218103806⟩]
private def b18993 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,5⟩,⟨218103807,999999999999999999⟩]
private def b18994 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,5⟩,⟨218103807,436207614⟩]
private def b18995 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,5⟩,⟨436207615,999999999999999999⟩]
private def b18996 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,5⟩,⟨436207615,872415230⟩]
private def b18997 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,5⟩,⟨872415231,999999999999999999⟩]
private def b18998 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,5⟩,⟨872415231,1744830461⟩]
private def b18999 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,5⟩,⟨1744830462,999999999999999999⟩]
private def b19000 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,5⟩,⟨1744830462,3489660918⟩]
private def b19001 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨3,5⟩,⟨3489660919,999999999999999999⟩]
private def b19016 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨8,9⟩,⟨6,17⟩,⟨27262975,999999999999999999⟩]
private def b19017 : Box := ![⟨191,1920000000000000011376⟩,⟨12,14⟩,⟨7,9⟩,⟨3,396097560975609758470⟩,⟨207,999999999999999999⟩]
private def b19018 : Box := ![⟨191,1920000000000000011376⟩,⟨12,14⟩,⟨7,9⟩,⟨3,396097560975609758470⟩,⟨207,414⟩]
private def b19021 : Box := ![⟨191,1920000000000000011376⟩,⟨12,14⟩,⟨7,9⟩,⟨3,396097560975609758470⟩,⟨415,999999999999999999⟩]
private def b19022 : Box := ![⟨191,382⟩,⟨12,14⟩,⟨7,9⟩,⟨3,350188679245283020965⟩,⟨415,999999999999999999⟩]
private def b19023 : Box := ![⟨191,382⟩,⟨12,14⟩,⟨7,9⟩,⟨4,85⟩,⟨415,830⟩]
private def b19024 : Box := ![⟨191,382⟩,⟨12,14⟩,⟨7,9⟩,⟨4,85⟩,⟨831,999999999999999999⟩]
private def b19025 : Box := ![⟨191,382⟩,⟨12,14⟩,⟨7,9⟩,⟨4,76⟩,⟨831,1662⟩]
private def b19026 : Box := ![⟨191,382⟩,⟨12,14⟩,⟨7,9⟩,⟨4,76⟩,⟨1663,999999999999999999⟩]
private def b19027 : Box := ![⟨191,382⟩,⟨12,14⟩,⟨7,9⟩,⟨4,69⟩,⟨1663,3326⟩]
private def b19028 : Box := ![⟨191,382⟩,⟨12,14⟩,⟨7,9⟩,⟨4,69⟩,⟨3327,999999999999999999⟩]
private def b19029 : Box := ![⟨191,382⟩,⟨12,14⟩,⟨7,9⟩,⟨4,63⟩,⟨3327,6654⟩]
private def b19030 : Box := ![⟨191,382⟩,⟨12,14⟩,⟨7,9⟩,⟨4,63⟩,⟨6655,999999999999999999⟩]
private def b19031 : Box := ![⟨191,382⟩,⟨12,14⟩,⟨7,9⟩,⟨4,58⟩,⟨6655,13310⟩]
private def b19032 : Box := ![⟨191,382⟩,⟨12,14⟩,⟨7,9⟩,⟨4,58⟩,⟨13311,999999999999999999⟩]
private def b19033 : Box := ![⟨191,382⟩,⟨12,14⟩,⟨7,9⟩,⟨4,54⟩,⟨13311,26622⟩]
private def b19034 : Box := ![⟨191,382⟩,⟨12,14⟩,⟨7,9⟩,⟨4,54⟩,⟨26623,999999999999999999⟩]
private def b19035 : Box := ![⟨191,382⟩,⟨12,14⟩,⟨7,9⟩,⟨4,50⟩,⟨26623,53246⟩]
private def b19036 : Box := ![⟨191,382⟩,⟨12,14⟩,⟨7,9⟩,⟨4,50⟩,⟨53247,999999999999999999⟩]
private def b19051 : Box := ![⟨383,1920000000000000011376⟩,⟨12,14⟩,⟨7,9⟩,⟨3,350188679245283020965⟩,⟨415,999999999999999999⟩]
private def b19052 : Box := ![⟨383,1920000000000000011376⟩,⟨12,14⟩,⟨7,9⟩,⟨8,350188679245283020965⟩,⟨415,830⟩]
private def b19053 : Box := ![⟨383,1920000000000000011376⟩,⟨12,14⟩,⟨7,9⟩,⟨8,350188679245283020965⟩,⟨831,999999999999999999⟩]
private def b19054 : Box := ![⟨383,1920000000000000011376⟩,⟨12,14⟩,⟨7,9⟩,⟨8,314069298952457697288⟩,⟨831,1662⟩]
private def b19055 : Box := ![⟨383,1920000000000000011376⟩,⟨12,14⟩,⟨7,9⟩,⟨8,314069298952457697288⟩,⟨1663,999999999999999999⟩]
private def b19056 : Box := ![⟨383,1920000000000000011376⟩,⟨12,14⟩,⟨7,9⟩,⟨8,284704163623082543707⟩,⟨1663,3326⟩]
private def b19057 : Box := ![⟨383,1920000000000000011376⟩,⟨12,14⟩,⟨7,9⟩,⟨8,284704163623082543707⟩,⟨3327,999999999999999999⟩]
private def b19058 : Box := ![⟨383,1920000000000000011376⟩,⟨12,14⟩,⟨7,9⟩,⟨8,260360721442885773102⟩,⟨3327,6654⟩]
private def b19059 : Box := ![⟨383,1920000000000000011376⟩,⟨12,14⟩,⟨7,9⟩,⟨8,260360721442885773102⟩,⟨6655,999999999999999999⟩]
private def b19060 : Box := ![⟨383,1920000000000000011376⟩,⟨12,14⟩,⟨7,9⟩,⟨8,239852307692307693744⟩,⟨6655,13310⟩]
private def b19061 : Box := ![⟨383,1920000000000000011376⟩,⟨12,14⟩,⟨7,9⟩,⟨8,239852307692307693744⟩,⟨13311,999999999999999999⟩]
private def b19062 : Box := ![⟨383,1920000000000000011376⟩,⟨12,12⟩,⟨7,9⟩,⟨8,222338847689674844458⟩,⟨13311,999999999999999999⟩]
private def b19071 : Box := ![⟨383,1920000000000000011376⟩,⟨13,14⟩,⟨7,9⟩,⟨8,222338847689674844458⟩,⟨13311,999999999999999999⟩]
private def b19080 : Box := ![⟨95,1920000000000000011376⟩,⟨12,14⟩,⟨10,14⟩,⟨1,396097560975609758472⟩,⟨207,999999999999999999⟩]
private def b19081 : Box := ![⟨95,190⟩,⟨12,14⟩,⟨10,14⟩,⟨1,396097560975609758472⟩,⟨207,999999999999999999⟩]
private def b19082 : Box := ![⟨95,190⟩,⟨12,14⟩,⟨10,14⟩,⟨1,59⟩,⟨207,414⟩]
private def b19089 : Box := ![⟨95,190⟩,⟨12,14⟩,⟨10,14⟩,⟨1,59⟩,⟨415,999999999999999999⟩]
private def b19090 : Box := ![⟨95,126⟩,⟨12,14⟩,⟨10,14⟩,⟨1,52⟩,⟨415,999999999999999999⟩]
private def b19101 : Box := ![⟨127,190⟩,⟨12,14⟩,⟨10,14⟩,⟨1,52⟩,⟨415,999999999999999999⟩]
private def b19102 : Box := ![⟨127,190⟩,⟨12,12⟩,⟨10,14⟩,⟨2,52⟩,⟨415,999999999999999999⟩]
private def b19111 : Box := ![⟨127,190⟩,⟨13,14⟩,⟨10,14⟩,⟨2,52⟩,⟨415,999999999999999999⟩]
private def b19118 : Box := ![⟨191,1920000000000000011376⟩,⟨12,14⟩,⟨10,14⟩,⟨1,396097560975609758472⟩,⟨207,999999999999999999⟩]
theorem deny5_11 : Deny 5 11 ![⟨47,1920000000000000011376⟩,⟨10,14⟩,⟨7,14⟩,⟨1,1450666666666666675297⟩,⟨103,999999999999999999⟩] := by
  have e18654 : Deny 5 11 b18654 := by
    apply closeAction rule_sound _ _ 64 [0xc3e080f8df68c70a02b8de3]
    decide +kernel
  have e18662 : Deny 5 11 b18662 := by
    apply closeAction rule_sound _ _ 64 [0xc40f8de3107e23]
    decide +kernel
  have e18666 : Deny 5 11 b18666 := by
    apply closeAction rule_sound _ _ 64 [0x20e3108e03e038c98c70c39e0260284]
    decide +kernel
  have e18677 : Deny 5 11 b18677 := by
    apply closeAction rule_sound _ _ 64 [0x30e72270c3e278c98c78c4]
    decide +kernel
  have e18665 : Deny 5 11 b18665 :=
    branchAction rule_sound _ _ 2
      0x2e7 b18665 b18666 b18677 (by decide +kernel) e18666 e18677
  have e18661 : Deny 5 11 b18661 :=
    branchAction rule_sound _ _ 1
      0x7 b18661 b18662 b18665 (by decide +kernel) e18662 e18665
  have e18653 : Deny 5 11 b18653 :=
    branchAction rule_sound _ _ 2
      0x263 b18653 b18654 b18661 (by decide +kernel) e18654 e18661
  have e18685 : Deny 5 11 b18685 := by
    apply closeAction rule_sound _ _ 64 [0x3e038c80e78c80c3e232231c3e202a3]
    decide +kernel
  have e18696 : Deny 5 11 b18696 := by
    apply closeAction rule_sound _ _ 64 [0x83804278de3103e379c38c78c42380f89a02830e31c38c88c7]
    decide +kernel
  have e18684 : Deny 5 11 b18684 :=
    branchAction rule_sound _ _ 1
      0x9 b18684 b18685 b18696 (by decide +kernel) e18685 e18696
  have e18652 : Deny 5 11 b18652 :=
    branchAction rule_sound _ _ 3
      0x88c4 b18652 b18653 b18684 (by decide +kernel) e18653 e18684
  have e18712 : Deny 5 11 b18712 := by
    apply closeAction rule_sound _ _ 64 [0xc3e379e32630f8df68c8e278c21f8da3]
    decide +kernel
  have e18720 : Deny 5 11 b18720 := by
    apply closeAction rule_sound _ _ 64 [0xf80f8203e37d88e03e37da31f88c280ae23]
    decide +kernel
  have e18730 : Deny 5 11 b18730 := by
    apply closeAction rule_sound _ _ 64 [0xf80f88c7e230f8df68c8e23]
    decide +kernel
  have e18736 : Deny 5 11 b18736 := by
    apply closeAction rule_sound _ _ 64 [0x20f89e32780f80e32631c39c38c72039a02a3]
    decide +kernel
  have e18749 : Deny 5 11 b18749 := by
    apply closeAction rule_sound _ _ 64 [0xc38c70c3e232631c3e278c3e37da31f8223]
    decide +kernel
  have e18735 : Deny 5 11 b18735 :=
    branchAction rule_sound _ _ 1
      0xb b18735 b18736 b18749 (by decide +kernel) e18736 e18749
  have e18729 : Deny 5 11 b18729 :=
    branchAction rule_sound _ _ 1
      0x7 b18729 b18730 b18735 (by decide +kernel) e18730 e18735
  have e18719 : Deny 5 11 b18719 :=
    branchAction rule_sound _ _ 1
      0x9 b18719 b18720 b18729 (by decide +kernel) e18720 e18729
  have e18711 : Deny 5 11 b18711 :=
    branchAction rule_sound _ _ 2
      0x223 b18711 b18712 b18719 (by decide +kernel) e18712 e18719
  have e18651 : Deny 5 11 b18651 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18651 b18652 b18711 (by decide +kernel) e18652 e18711
  have e18762 : Deny 5 11 b18762 := by
    apply closeAction rule_sound _ _ 64 [0x11]
    decide +kernel
  have e18764 : Deny 5 11 b18764 := by
    apply closeAction rule_sound _ _ 64 [0x11]
    decide +kernel
  have e18767 : Deny 5 11 b18767 := by
    apply closeAction rule_sound _ _ 64 [0x19e276676670f88c78c79e31e3]
    decide +kernel
  have e18774 : Deny 5 11 b18774 := by
    apply closeAction rule_sound _ _ 64 [0x999c20f89e3108e03e371038c42389e32631e78c41f8]
    decide +kernel
  have e18766 : Deny 5 11 b18766 :=
    branchAction rule_sound _ _ 2
      0x263 b18766 b18767 b18774 (by decide +kernel) e18767 e18774
  have e18785 : Deny 5 11 b18785 := by
    apply closeAction rule_sound _ _ 64 [0x826678c46670f80e32231e3107e278c78c4278]
    decide +kernel
  have e18765 : Deny 5 11 b18765 :=
    branchAction rule_sound _ _ 1
      0x8 b18765 b18766 b18785 (by decide +kernel) e18766 e18785
  have e18763 : Deny 5 11 b18763 :=
    branchAction rule_sound _ _ 1
      0xa b18763 b18764 b18765 (by decide +kernel) e18764 e18765
  have e18761 : Deny 5 11 b18761 :=
    branchAction rule_sound _ _ 3
      0xa8c4 b18761 b18762 b18763 (by decide +kernel) e18762 e18763
  have e18798 : Deny 5 11 b18798 := by
    apply closeAction rule_sound _ _ 64 [0x11e369e0]
    decide +kernel
  have e18800 : Deny 5 11 b18800 := by
    apply closeAction rule_sound _ _ 64 [0x199d91e76429e010ae231e344ae23]
    decide +kernel
  have e18811 : Deny 5 11 b18811 := by
    apply closeAction rule_sound _ _ 64 [0x6599c42e70f80f89c80d9e378c8e278c98c79e3]
    decide +kernel
  have e18823 : Deny 5 11 b18823 := by
    apply closeAction rule_sound _ _ 64 [0x3e03e278c9e278c2238da3]
    decide +kernel
  have e18828 : Deny 5 11 b18828 := by
    apply closeAction rule_sound _ _ 64 [0xc3e231c22636678cb088da36678cb]
    decide +kernel
  have e18822 : Deny 5 11 b18822 :=
    branchAction rule_sound _ _ 2
      0x1e3 b18822 b18823 b18828 (by decide +kernel) e18823 e18828
  have e18810 : Deny 5 11 b18810 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18810 b18811 b18822 (by decide +kernel) e18811 e18822
  have e18840 : Deny 5 11 b18840 := by
    apply closeAction rule_sound _ _ 64 [0x6678d91f89e3]
    decide +kernel
  have e18845 : Deny 5 11 b18845 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18847 : Deny 5 11 b18847 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18849 : Deny 5 11 b18849 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18851 : Deny 5 11 b18851 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18853 : Deny 5 11 b18853 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e18855 : Deny 5 11 b18855 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18857 : Deny 5 11 b18857 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18859 : Deny 5 11 b18859 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18861 : Deny 5 11 b18861 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18863 : Deny 5 11 b18863 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18865 : Deny 5 11 b18865 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18867 : Deny 5 11 b18867 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18870 : Deny 5 11 b18870 := by
    apply closeAction rule_sound _ _ 64 [0x11]
    decide +kernel
  have e18872 : Deny 5 11 b18872 := by
    apply closeAction rule_sound _ _ 64 [0x11]
    decide +kernel
  have e18874 : Deny 5 11 b18874 := by
    apply closeAction rule_sound _ _ 64 [0x11]
    decide +kernel
  have e18875 : Deny 5 11 b18875 := by
    apply closeAction rule_sound _ _ 64 [0x6420c708980a44b44b44b44b]
    decide +kernel
  have e18873 : Deny 5 11 b18873 :=
    branchAction rule_sound _ _ 1
      0xb b18873 b18874 b18875 (by decide +kernel) e18874 e18875
  have e18871 : Deny 5 11 b18871 :=
    branchAction rule_sound _ _ 1
      0xb b18871 b18872 b18873 (by decide +kernel) e18872 e18873
  have e18869 : Deny 5 11 b18869 :=
    branchAction rule_sound _ _ 3
      0xbda0 b18869 b18870 b18871 (by decide +kernel) e18870 e18871
  have e18890 : Deny 5 11 b18890 := by
    apply closeAction rule_sound _ _ 64 [0x19]
    decide +kernel
  have e18868 : Deny 5 11 b18868 :=
    branchAction rule_sound _ _ 2
      0x2a3 b18868 b18869 b18890 (by decide +kernel) e18869 e18890
  have e18866 : Deny 5 11 b18866 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18866 b18867 b18868 (by decide +kernel) e18867 e18868
  have e18864 : Deny 5 11 b18864 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18864 b18865 b18866 (by decide +kernel) e18865 e18866
  have e18862 : Deny 5 11 b18862 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18862 b18863 b18864 (by decide +kernel) e18863 e18864
  have e18860 : Deny 5 11 b18860 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18860 b18861 b18862 (by decide +kernel) e18861 e18862
  have e18858 : Deny 5 11 b18858 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18858 b18859 b18860 (by decide +kernel) e18859 e18860
  have e18856 : Deny 5 11 b18856 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18856 b18857 b18858 (by decide +kernel) e18857 e18858
  have e18854 : Deny 5 11 b18854 :=
    branchAction rule_sound _ _ 1
      0xb b18854 b18855 b18856 (by decide +kernel) e18855 e18856
  have e18852 : Deny 5 11 b18852 :=
    branchAction rule_sound _ _ 2
      0x223 b18852 b18853 b18854 (by decide +kernel) e18853 e18854
  have e18850 : Deny 5 11 b18850 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18850 b18851 b18852 (by decide +kernel) e18851 e18852
  have e18848 : Deny 5 11 b18848 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18848 b18849 b18850 (by decide +kernel) e18849 e18850
  have e18846 : Deny 5 11 b18846 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18846 b18847 b18848 (by decide +kernel) e18847 e18848
  have e18844 : Deny 5 11 b18844 :=
    branchAction rule_sound _ _ 3
      0xb9e3 b18844 b18845 b18846 (by decide +kernel) e18845 e18846
  have e18892 : Deny 5 11 b18892 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18894 : Deny 5 11 b18894 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18896 : Deny 5 11 b18896 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18898 : Deny 5 11 b18898 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18900 : Deny 5 11 b18900 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18902 : Deny 5 11 b18902 := by
    apply closeAction rule_sound _ _ 64 [0x20999e31f48c9088]
    decide +kernel
  have e18911 : Deny 5 11 b18911 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18913 : Deny 5 11 b18913 := by
    apply closeAction rule_sound _ _ 64 [0x6676670878c70899e3]
    decide +kernel
  have e18920 : Deny 5 11 b18920 := by
    apply closeAction rule_sound _ _ 64 [0x20999e31f89d99e31f48c99d99e31e7]
    decide +kernel
  have e18912 : Deny 5 11 b18912 :=
    branchAction rule_sound _ _ 2
      0x1e3 b18912 b18913 b18920 (by decide +kernel) e18913 e18920
  have e18910 : Deny 5 11 b18910 :=
    branchAction rule_sound _ _ 1
      0xb b18910 b18911 b18912 (by decide +kernel) e18911 e18912
  have e18929 : Deny 5 11 b18929 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e18909 : Deny 5 11 b18909 :=
    branchAction rule_sound _ _ 1
      0x8 b18909 b18910 b18929 (by decide +kernel) e18910 e18929
  have e18901 : Deny 5 11 b18901 :=
    branchAction rule_sound _ _ 2
      0x263 b18901 b18902 b18909 (by decide +kernel) e18902 e18909
  have e18899 : Deny 5 11 b18899 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18899 b18900 b18901 (by decide +kernel) e18900 e18901
  have e18897 : Deny 5 11 b18897 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18897 b18898 b18899 (by decide +kernel) e18898 e18899
  have e18895 : Deny 5 11 b18895 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18895 b18896 b18897 (by decide +kernel) e18896 e18897
  have e18893 : Deny 5 11 b18893 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18893 b18894 b18895 (by decide +kernel) e18894 e18895
  have e18891 : Deny 5 11 b18891 :=
    branchAction rule_sound _ _ 2
      0x2e7 b18891 b18892 b18893 (by decide +kernel) e18892 e18893
  have e18843 : Deny 5 11 b18843 :=
    branchAction rule_sound _ _ 2
      0x1e3 b18843 b18844 b18891 (by decide +kernel) e18844 e18891
  have e18839 : Deny 5 11 b18839 :=
    branchAction rule_sound _ _ 1
      0xb b18839 b18840 b18843 (by decide +kernel) e18840 e18843
  have e18809 : Deny 5 11 b18809 :=
    branchAction rule_sound _ _ 1
      0x7 b18809 b18810 b18839 (by decide +kernel) e18810 e18839
  have e18799 : Deny 5 11 b18799 :=
    branchAction rule_sound _ _ 1
      0x9 b18799 b18800 b18809 (by decide +kernel) e18800 e18809
  have e18797 : Deny 5 11 b18797 :=
    branchAction rule_sound _ _ 1
      0xa b18797 b18798 b18799 (by decide +kernel) e18798 e18799
  have e18932 : Deny 5 11 b18932 := by
    apply closeAction rule_sound _ _ 64 [0x4789e0]
    decide +kernel
  have e18935 : Deny 5 11 b18935 := by
    apply closeAction rule_sound _ _ 64 [0x199d96430f8da022028a8c79e3]
    decide +kernel
  have e18945 : Deny 5 11 b18945 := by
    apply closeAction rule_sound _ _ 64 [0x199e3087e36]
    decide +kernel
  have e18949 : Deny 5 11 b18949 := by
    apply closeAction rule_sound _ _ 64 [0xf89e30f8da78c8e23]
    decide +kernel
  have e18953 : Deny 5 11 b18953 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18955 : Deny 5 11 b18955 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e18957 : Deny 5 11 b18957 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18959 : Deny 5 11 b18959 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18961 : Deny 5 11 b18961 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18963 : Deny 5 11 b18963 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18965 : Deny 5 11 b18965 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18967 : Deny 5 11 b18967 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18969 : Deny 5 11 b18969 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18971 : Deny 5 11 b18971 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18973 : Deny 5 11 b18973 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18975 : Deny 5 11 b18975 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18977 : Deny 5 11 b18977 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18979 : Deny 5 11 b18979 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18981 : Deny 5 11 b18981 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18983 : Deny 5 11 b18983 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18985 : Deny 5 11 b18985 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e18988 : Deny 5 11 b18988 := by
    apply closeAction rule_sound _ _ 64 [0x199e0]
    decide +kernel
  have e18990 : Deny 5 11 b18990 := by
    apply closeAction rule_sound _ _ 64 [0x199e0]
    decide +kernel
  have e18992 : Deny 5 11 b18992 := by
    apply closeAction rule_sound _ _ 64 [0x199e0]
    decide +kernel
  have e18994 : Deny 5 11 b18994 := by
    apply closeAction rule_sound _ _ 64 [0x199e0]
    decide +kernel
  have e18996 : Deny 5 11 b18996 := by
    apply closeAction rule_sound _ _ 64 [0x199e0]
    decide +kernel
  have e18998 : Deny 5 11 b18998 := by
    apply closeAction rule_sound _ _ 64 [0x199e0]
    decide +kernel
  have e19000 : Deny 5 11 b19000 := by
    apply closeAction rule_sound _ _ 64 [0x199e0]
    decide +kernel
  have e19001 : Deny 5 11 b19001 := by
    apply closeAction rule_sound _ _ 64 [0x64308880a66780b66780b66780b66780b66780b]
    decide +kernel
  have e18999 : Deny 5 11 b18999 :=
    branchAction rule_sound _ _ 1
      0xb b18999 b19000 b19001 (by decide +kernel) e19000 e19001
  have e18997 : Deny 5 11 b18997 :=
    branchAction rule_sound _ _ 1
      0xb b18997 b18998 b18999 (by decide +kernel) e18998 e18999
  have e18995 : Deny 5 11 b18995 :=
    branchAction rule_sound _ _ 1
      0xb b18995 b18996 b18997 (by decide +kernel) e18996 e18997
  have e18993 : Deny 5 11 b18993 :=
    branchAction rule_sound _ _ 1
      0xb b18993 b18994 b18995 (by decide +kernel) e18994 e18995
  have e18991 : Deny 5 11 b18991 :=
    branchAction rule_sound _ _ 1
      0xb b18991 b18992 b18993 (by decide +kernel) e18992 e18993
  have e18989 : Deny 5 11 b18989 :=
    branchAction rule_sound _ _ 1
      0xb b18989 b18990 b18991 (by decide +kernel) e18990 e18991
  have e18987 : Deny 5 11 b18987 :=
    branchAction rule_sound _ _ 1
      0xb b18987 b18988 b18989 (by decide +kernel) e18988 e18989
  have e19016 : Deny 5 11 b19016 := by
    apply closeAction rule_sound _ _ 64 [0x19]
    decide +kernel
  have e18986 : Deny 5 11 b18986 :=
    branchAction rule_sound _ _ 2
      0x2a3 b18986 b18987 b19016 (by decide +kernel) e18987 e19016
  have e18984 : Deny 5 11 b18984 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18984 b18985 b18986 (by decide +kernel) e18985 e18986
  have e18982 : Deny 5 11 b18982 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18982 b18983 b18984 (by decide +kernel) e18983 e18984
  have e18980 : Deny 5 11 b18980 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18980 b18981 b18982 (by decide +kernel) e18981 e18982
  have e18978 : Deny 5 11 b18978 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18978 b18979 b18980 (by decide +kernel) e18979 e18980
  have e18976 : Deny 5 11 b18976 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18976 b18977 b18978 (by decide +kernel) e18977 e18978
  have e18974 : Deny 5 11 b18974 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18974 b18975 b18976 (by decide +kernel) e18975 e18976
  have e18972 : Deny 5 11 b18972 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18972 b18973 b18974 (by decide +kernel) e18973 e18974
  have e18970 : Deny 5 11 b18970 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18970 b18971 b18972 (by decide +kernel) e18971 e18972
  have e18968 : Deny 5 11 b18968 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18968 b18969 b18970 (by decide +kernel) e18969 e18970
  have e18966 : Deny 5 11 b18966 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18966 b18967 b18968 (by decide +kernel) e18967 e18968
  have e18964 : Deny 5 11 b18964 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18964 b18965 b18966 (by decide +kernel) e18965 e18966
  have e18962 : Deny 5 11 b18962 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18962 b18963 b18964 (by decide +kernel) e18963 e18964
  have e18960 : Deny 5 11 b18960 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18960 b18961 b18962 (by decide +kernel) e18961 e18962
  have e18958 : Deny 5 11 b18958 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18958 b18959 b18960 (by decide +kernel) e18959 e18960
  have e18956 : Deny 5 11 b18956 :=
    branchAction rule_sound _ _ 1
      0xb b18956 b18957 b18958 (by decide +kernel) e18957 e18958
  have e18954 : Deny 5 11 b18954 :=
    branchAction rule_sound _ _ 2
      0x263 b18954 b18955 b18956 (by decide +kernel) e18955 e18956
  have e18952 : Deny 5 11 b18952 :=
    branchAction rule_sound _ _ 1
      0xb b18952 b18953 b18954 (by decide +kernel) e18953 e18954
  have e18948 : Deny 5 11 b18948 :=
    branchAction rule_sound _ _ 1
      0x7 b18948 b18949 b18952 (by decide +kernel) e18949 e18952
  have e18944 : Deny 5 11 b18944 :=
    branchAction rule_sound _ _ 2
      0x223 b18944 b18945 b18948 (by decide +kernel) e18945 e18948
  have e18934 : Deny 5 11 b18934 :=
    branchAction rule_sound _ _ 2
      0x2e3 b18934 b18935 b18944 (by decide +kernel) e18935 e18944
  have e19018 : Deny 5 11 b19018 := by
    apply closeAction rule_sound _ _ 64 [0x6788d92389e3]
    decide +kernel
  have e19023 : Deny 5 11 b19023 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e19025 : Deny 5 11 b19025 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e19027 : Deny 5 11 b19027 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e19029 : Deny 5 11 b19029 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e19031 : Deny 5 11 b19031 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e19033 : Deny 5 11 b19033 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e19035 : Deny 5 11 b19035 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e19036 : Deny 5 11 b19036 := by
    apply closeAction rule_sound _ _ 64 [0x6420839c21f480980808908880a8d99e32e3]
    decide +kernel
  have e19034 : Deny 5 11 b19034 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19034 b19035 b19036 (by decide +kernel) e19035 e19036
  have e19032 : Deny 5 11 b19032 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19032 b19033 b19034 (by decide +kernel) e19033 e19034
  have e19030 : Deny 5 11 b19030 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19030 b19031 b19032 (by decide +kernel) e19031 e19032
  have e19028 : Deny 5 11 b19028 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19028 b19029 b19030 (by decide +kernel) e19029 e19030
  have e19026 : Deny 5 11 b19026 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19026 b19027 b19028 (by decide +kernel) e19027 e19028
  have e19024 : Deny 5 11 b19024 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19024 b19025 b19026 (by decide +kernel) e19025 e19026
  have e19022 : Deny 5 11 b19022 :=
    branchAction rule_sound _ _ 3
      0xb9e3 b19022 b19023 b19024 (by decide +kernel) e19023 e19024
  have e19052 : Deny 5 11 b19052 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e19054 : Deny 5 11 b19054 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e19056 : Deny 5 11 b19056 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e19058 : Deny 5 11 b19058 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e19060 : Deny 5 11 b19060 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e19062 : Deny 5 11 b19062 := by
    apply closeAction rule_sound _ _ 64 [0x20999e31f89d99e31f4242263]
    decide +kernel
  have e19071 : Deny 5 11 b19071 := by
    apply closeAction rule_sound _ _ 64 [0x20826678c7e276678c7d088c9]
    decide +kernel
  have e19061 : Deny 5 11 b19061 :=
    branchAction rule_sound _ _ 2
      0x223 b19061 b19062 b19071 (by decide +kernel) e19062 e19071
  have e19059 : Deny 5 11 b19059 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19059 b19060 b19061 (by decide +kernel) e19060 e19061
  have e19057 : Deny 5 11 b19057 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19057 b19058 b19059 (by decide +kernel) e19058 e19059
  have e19055 : Deny 5 11 b19055 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19055 b19056 b19057 (by decide +kernel) e19056 e19057
  have e19053 : Deny 5 11 b19053 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19053 b19054 b19055 (by decide +kernel) e19054 e19055
  have e19051 : Deny 5 11 b19051 :=
    branchAction rule_sound _ _ 2
      0x2e7 b19051 b19052 b19053 (by decide +kernel) e19052 e19053
  have e19021 : Deny 5 11 b19021 :=
    branchAction rule_sound _ _ 2
      0x1e3 b19021 b19022 b19051 (by decide +kernel) e19022 e19051
  have e19017 : Deny 5 11 b19017 :=
    branchAction rule_sound _ _ 1
      0xb b19017 b19018 b19021 (by decide +kernel) e19018 e19021
  have e18933 : Deny 5 11 b18933 :=
    branchAction rule_sound _ _ 1
      0x7 b18933 b18934 b19017 (by decide +kernel) e18934 e19017
  have e18931 : Deny 5 11 b18931 :=
    branchAction rule_sound _ _ 2
      0x2a3 b18931 b18932 b18933 (by decide +kernel) e18932 e18933
  have e19082 : Deny 5 11 b19082 := by
    apply closeAction rule_sound _ _ 64 [0x20820f89e32631e78c42389e3]
    decide +kernel
  have e19090 : Deny 5 11 b19090 := by
    apply closeAction rule_sound _ _ 64 [0x83e231f80f80f88c7e278c90c3e278c9223]
    decide +kernel
  have e19102 : Deny 5 11 b19102 := by
    apply closeAction rule_sound _ _ 64 [0x83e231f80e70f88c78c98d9e278cb]
    decide +kernel
  have e19111 : Deny 5 11 b19111 := by
    apply closeAction rule_sound _ _ 64 [0x20820f82388c7e23278]
    decide +kernel
  have e19101 : Deny 5 11 b19101 :=
    branchAction rule_sound _ _ 2
      0x227 b19101 b19102 b19111 (by decide +kernel) e19102 e19111
  have e19089 : Deny 5 11 b19089 :=
    branchAction rule_sound _ _ 2
      0x1e3 b19089 b19090 b19101 (by decide +kernel) e19090 e19101
  have e19081 : Deny 5 11 b19081 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19081 b19082 b19089 (by decide +kernel) e19082 e19089
  have e19118 : Deny 5 11 b19118 := by
    apply closeAction rule_sound _ _ 64 [0x82082083e232788c7e232788c8e278c7e27]
    decide +kernel
  have e19080 : Deny 5 11 b19080 :=
    branchAction rule_sound _ _ 1
      0x7 b19080 b19081 b19118 (by decide +kernel) e19081 e19118
  have e18930 : Deny 5 11 b18930 :=
    branchAction rule_sound _ _ 1
      0x9 b18930 b18931 b19080 (by decide +kernel) e18931 e19080
  have e18796 : Deny 5 11 b18796 :=
    branchAction rule_sound _ _ 2
      0x223 b18796 b18797 b18930 (by decide +kernel) e18797 e18930
  have e18760 : Deny 5 11 b18760 :=
    branchAction rule_sound _ _ 1
      0xb b18760 b18761 b18796 (by decide +kernel) e18761 e18796
  have e18650 : Deny 5 11 b18650 :=
    branchAction rule_sound _ _ 2
      0x1e3 b18650 b18651 b18760 (by decide +kernel) e18651 e18760
  exact e18650
end OMA.Blocks5_11_245212.S18650
