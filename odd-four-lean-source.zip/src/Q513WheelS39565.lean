import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S39565
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b39565 : Box := ![⟨63,94⟩,⟨18,20⟩,⟨31,62⟩,⟨3,963047619047619053363⟩,⟨167,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨18,20⟩,⟨31,62⟩,⟨3,963047619047619053363⟩,⟨167,233⟩] := by
  have e39565 : Deny 5 13 b39565 := by
    apply closeAction rule_sound _ _ 64 [0xdf6203dc32030f720910b0c3e37244088e070c2204087e092830f8da21c3e37d8854a0a21f688a2c4778df6108e231e3,0xc90c3e081c30f8dc91021f82092955435482552952092842dd0c21c4088e0a778df68c9738df68c7df68c47430c90f8,0x8c98c4742083209e020c80c70c31c91020c41f80f80c724b1c3e040c41f80c90c3e371c40f8dc42781c8578dc40c4238,0xf8df61c3e372422040f8dc32031c30c72442c70dde37d871021f8d882952830f8dc80f78c90c4778df6108e378c7088,0x755e370c80c90c3dc8244095e370c7203e370c82442c3]
    decide +kernel
  exact e39565
end OMA.Blocks5_13_245212.S39565
