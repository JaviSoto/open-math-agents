import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S45923
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b45923 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨31,62⟩,⟨3,76⟩,⟨239,478⟩]
private def b45924 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨31,62⟩,⟨3,76⟩,⟨239,318⟩]
private def b45925 : Box := ![⟨127,152⟩,⟨18,20⟩,⟨31,62⟩,⟨3,76⟩,⟨239,317⟩]
private def b45926 : Box := ![⟨127,152⟩,⟨18,20⟩,⟨31,41⟩,⟨3,68⟩,⟨239,317⟩]
private def b45927 : Box := ![⟨127,152⟩,⟨18,18⟩,⟨31,41⟩,⟨3,58⟩,⟨239,317⟩]
private def b45928 : Box := ![⟨127,152⟩,⟨18,18⟩,⟨31,41⟩,⟨3,58⟩,⟨239,272⟩]
private def b45939 : Box := ![⟨127,152⟩,⟨18,18⟩,⟨31,41⟩,⟨3,58⟩,⟨273,317⟩]
private def b45944 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨31,41⟩,⟨3,58⟩,⟨239,317⟩]
private def b45945 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨31,41⟩,⟨3,58⟩,⟨239,272⟩]
private def b45952 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨31,41⟩,⟨3,58⟩,⟨273,317⟩]
private def b45953 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨31,41⟩,⟨3,6⟩,⟨277,317⟩]
private def b45958 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨31,41⟩,⟨7,57⟩,⟨277,317⟩]
private def b45959 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨31,41⟩,⟨7,13⟩,⟨277,317⟩]
private def b45960 : Box := ![⟨127,138⟩,⟨19,20⟩,⟨31,41⟩,⟨7,13⟩,⟨277,317⟩]
private def b45967 : Box := ![⟨139,152⟩,⟨19,20⟩,⟨31,41⟩,⟨7,13⟩,⟨277,317⟩]
private def b45972 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨31,41⟩,⟨14,57⟩,⟨277,317⟩]
private def b45973 : Box := ![⟨127,152⟩,⟨18,20⟩,⟨42,62⟩,⟨3,68⟩,⟨239,317⟩]
private def b45974 : Box := ![⟨127,152⟩,⟨18,20⟩,⟨42,62⟩,⟨3,6⟩,⟨239,317⟩]
private def b45975 : Box := ![⟨127,152⟩,⟨18,20⟩,⟨42,62⟩,⟨7,68⟩,⟨239,317⟩]
private def b45986 : Box := ![⟨153,190⟩,⟨18,20⟩,⟨31,62⟩,⟨3,76⟩,⟨239,317⟩]
private def b45987 : Box := ![⟨153,190⟩,⟨18,20⟩,⟨31,62⟩,⟨3,6⟩,⟨239,317⟩]
private def b45988 : Box := ![⟨153,190⟩,⟨18,20⟩,⟨31,62⟩,⟨7,76⟩,⟨239,317⟩]
private def b45989 : Box := ![⟨153,190⟩,⟨18,20⟩,⟨31,62⟩,⟨7,13⟩,⟨243,317⟩]
private def b45990 : Box := ![⟨153,190⟩,⟨18,20⟩,⟨31,41⟩,⟨7,13⟩,⟨251,317⟩]
private def b45991 : Box := ![⟨153,190⟩,⟨18,18⟩,⟨31,41⟩,⟨7,13⟩,⟨251,317⟩]
private def b45992 : Box := ![⟨153,190⟩,⟨18,18⟩,⟨31,41⟩,⟨7,13⟩,⟨251,280⟩]
private def b45999 : Box := ![⟨153,190⟩,⟨18,18⟩,⟨31,41⟩,⟨7,13⟩,⟨281,317⟩]
private def b46008 : Box := ![⟨153,190⟩,⟨19,20⟩,⟨31,41⟩,⟨7,13⟩,⟨251,317⟩]
private def b46015 : Box := ![⟨153,190⟩,⟨18,20⟩,⟨42,62⟩,⟨7,13⟩,⟨251,317⟩]
private def b46020 : Box := ![⟨153,190⟩,⟨18,20⟩,⟨31,62⟩,⟨14,76⟩,⟨243,317⟩]
private def b46021 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨31,62⟩,⟨3,76⟩,⟨319,478⟩]
private def b46022 : Box := ![⟨127,152⟩,⟨18,20⟩,⟨31,62⟩,⟨3,72⟩,⟨319,478⟩]
private def b46023 : Box := ![⟨127,152⟩,⟨18,20⟩,⟨31,41⟩,⟨3,65⟩,⟨319,478⟩]
private def b46024 : Box := ![⟨127,152⟩,⟨18,18⟩,⟨31,41⟩,⟨3,55⟩,⟨319,478⟩]
private def b46025 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨31,41⟩,⟨3,55⟩,⟨319,478⟩]
private def b46026 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨31,41⟩,⟨3,55⟩,⟨319,382⟩]
private def b46027 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨31,41⟩,⟨3,6⟩,⟨331,379⟩]
private def b46034 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨31,41⟩,⟨7,55⟩,⟨331,379⟩]
private def b46035 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨31,41⟩,⟨7,13⟩,⟨331,379⟩]
private def b46036 : Box := ![⟨127,138⟩,⟨19,20⟩,⟨31,41⟩,⟨7,13⟩,⟨331,379⟩]
private def b46041 : Box := ![⟨139,152⟩,⟨19,20⟩,⟨31,41⟩,⟨7,13⟩,⟨331,379⟩]
private def b46048 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨31,41⟩,⟨14,55⟩,⟨331,379⟩]
private def b46049 : Box := ![⟨127,152⟩,⟨19,20⟩,⟨31,41⟩,⟨3,55⟩,⟨383,478⟩]
private def b46050 : Box := ![⟨127,138⟩,⟨19,20⟩,⟨31,41⟩,⟨3,54⟩,⟨383,467⟩]
private def b46055 : Box := ![⟨139,152⟩,⟨19,20⟩,⟨31,41⟩,⟨3,54⟩,⟨383,467⟩]
private def b46062 : Box := ![⟨127,152⟩,⟨18,20⟩,⟨42,62⟩,⟨3,65⟩,⟨319,478⟩]
private def b46063 : Box := ![⟨127,152⟩,⟨18,20⟩,⟨42,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b46064 : Box := ![⟨127,152⟩,⟨18,20⟩,⟨42,62⟩,⟨7,65⟩,⟨319,478⟩]
private def b46075 : Box := ![⟨153,190⟩,⟨18,20⟩,⟨31,62⟩,⟨3,72⟩,⟨319,478⟩]
private def b46076 : Box := ![⟨153,190⟩,⟨18,20⟩,⟨31,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b46077 : Box := ![⟨153,190⟩,⟨18,20⟩,⟨31,62⟩,⟨7,72⟩,⟨319,478⟩]
private def b46078 : Box := ![⟨153,190⟩,⟨18,20⟩,⟨31,62⟩,⟨7,13⟩,⟨319,478⟩]
private def b46079 : Box := ![⟨153,190⟩,⟨18,20⟩,⟨31,41⟩,⟨7,13⟩,⟨319,478⟩]
private def b46080 : Box := ![⟨153,190⟩,⟨18,18⟩,⟨31,41⟩,⟨7,13⟩,⟨319,478⟩]
private def b46087 : Box := ![⟨153,190⟩,⟨19,20⟩,⟨31,41⟩,⟨7,13⟩,⟨319,478⟩]
private def b46088 : Box := ![⟨153,190⟩,⟨19,20⟩,⟨31,41⟩,⟨7,13⟩,⟨319,382⟩]
private def b46089 : Box := ![⟨153,169⟩,⟨19,20⟩,⟨31,41⟩,⟨7,13⟩,⟨331,379⟩]
private def b46098 : Box := ![⟨170,190⟩,⟨19,20⟩,⟨31,41⟩,⟨7,13⟩,⟨331,379⟩]
private def b46103 : Box := ![⟨153,190⟩,⟨19,20⟩,⟨31,41⟩,⟨7,13⟩,⟨383,478⟩]
private def b46104 : Box := ![⟨153,190⟩,⟨19,20⟩,⟨31,41⟩,⟨7,9⟩,⟨383,467⟩]
private def b46115 : Box := ![⟨153,190⟩,⟨19,20⟩,⟨31,41⟩,⟨10,13⟩,⟨383,467⟩]
private def b46116 : Box := ![⟨153,190⟩,⟨18,20⟩,⟨42,62⟩,⟨7,13⟩,⟨319,478⟩]
private def b46123 : Box := ![⟨153,190⟩,⟨18,20⟩,⟨31,62⟩,⟨14,72⟩,⟨319,478⟩]
private theorem e45928 : Deny 5 13 b45928 := by
    apply closeAction rule_sound _ _ 64 [0x743e032430f8247295284]
    decide +kernel
private theorem e45939 : Deny 5 13 b45939 := by
    apply closeAction rule_sound _ _ 64 [0x3778de325de37da31f78c4]
    decide +kernel
private theorem e45927 : Deny 5 13 b45927 :=
    branchAction rule_sound _ _ 1
      0xb b45927 b45928 b45939 (by decide +kernel) e45928 e45939
private theorem e45945 : Deny 5 13 b45945 := by
    apply closeAction rule_sound _ _ 64 [0x15dd5e370f8de70c7209dc4]
    decide +kernel
private theorem e45953 : Deny 5 13 b45953 := by
    apply closeAction rule_sound _ _ 64 [0x5550e0249]
    decide +kernel
private theorem e45960 : Deny 5 13 b45960 := by
    apply closeAction rule_sound _ _ 64 [0x20c80f80f8209]
    decide +kernel
private theorem e45967 : Deny 5 13 b45967 := by
    apply closeAction rule_sound _ _ 64 [0x20f8dc3248]
    decide +kernel
private theorem e45959 : Deny 5 13 b45959 :=
    branchAction rule_sound _ _ 1
      0x7 b45959 b45960 b45967 (by decide +kernel) e45960 e45967
private theorem e45972 : Deny 5 13 b45972 := by
    apply closeAction rule_sound _ _ 64 [0x1d]
    decide +kernel
private theorem e45958 : Deny 5 13 b45958 :=
    branchAction rule_sound _ _ 1
      0xa b45958 b45959 b45972 (by decide +kernel) e45959 e45972
private theorem e45952 : Deny 5 13 b45952 :=
    branchAction rule_sound _ _ 3
      0xa8c4 b45952 b45953 b45958 (by decide +kernel) e45953 e45958
private theorem e45944 : Deny 5 13 b45944 :=
    branchAction rule_sound _ _ 1
      0xb b45944 b45945 b45952 (by decide +kernel) e45945 e45952
private theorem e45926 : Deny 5 13 b45926 :=
    branchAction rule_sound _ _ 2
      0x223 b45926 b45927 b45944 (by decide +kernel) e45927 e45944
private theorem e45974 : Deny 5 13 b45974 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
private theorem e45975 : Deny 5 13 b45975 := by
    apply closeAction rule_sound _ _ 64 [0x1d55d7552842b854a2442b8]
    decide +kernel
private theorem e45973 : Deny 5 13 b45973 :=
    branchAction rule_sound _ _ 1
      0xa b45973 b45974 b45975 (by decide +kernel) e45974 e45975
private theorem e45925 : Deny 5 13 b45925 :=
    branchAction rule_sound _ _ 2
      0x263 b45925 b45926 b45973 (by decide +kernel) e45926 e45973
private theorem e45987 : Deny 5 13 b45987 := by
    apply closeAction rule_sound _ _ 64 [0x566]
    decide +kernel
private theorem e45992 : Deny 5 13 b45992 := by
    apply closeAction rule_sound _ _ 64 [0x91278de70f80c71c4]
    decide +kernel
private theorem e45999 : Deny 5 13 b45999 := by
    apply closeAction rule_sound _ _ 64 [0x1d5438090f880956680a80a]
    decide +kernel
private theorem e45991 : Deny 5 13 b45991 :=
    branchAction rule_sound _ _ 1
      0xb b45991 b45992 b45999 (by decide +kernel) e45992 e45999
private theorem e46008 : Deny 5 13 b46008 := by
    apply closeAction rule_sound _ _ 64 [0x20820c82441f8]
    decide +kernel
private theorem e45990 : Deny 5 13 b45990 :=
    branchAction rule_sound _ _ 1
      0x8 b45990 b45991 b46008 (by decide +kernel) e45991 e46008
private theorem e46015 : Deny 5 13 b46015 := by
    apply closeAction rule_sound _ _ 64 [0x2755284238]
    decide +kernel
private theorem e45989 : Deny 5 13 b45989 :=
    branchAction rule_sound _ _ 2
      0x244 b45989 b45990 b46015 (by decide +kernel) e45990 e46015
private theorem e46020 : Deny 5 13 b46020 := by
    apply closeAction rule_sound _ _ 64 [0x1d]
    decide +kernel
private theorem e45988 : Deny 5 13 b45988 :=
    branchAction rule_sound _ _ 2
      0x2b8 b45988 b45989 b46020 (by decide +kernel) e45989 e46020
private theorem e45986 : Deny 5 13 b45986 :=
    branchAction rule_sound _ _ 1
      0xa b45986 b45987 b45988 (by decide +kernel) e45987 e45988
private theorem e45924 : Deny 5 13 b45924 :=
    branchAction rule_sound _ _ 2
      0x1c4 b45924 b45925 b45986 (by decide +kernel) e45925 e45986
private theorem e46024 : Deny 5 13 b46024 := by
    apply closeAction rule_sound _ _ 64 [0x778df6]
    decide +kernel
private theorem e46027 : Deny 5 13 b46027 := by
    apply closeAction rule_sound _ _ 64 [0x5439c3e371c2209]
    decide +kernel
private theorem e46036 : Deny 5 13 b46036 := by
    apply closeAction rule_sound _ _ 64 [0x3e03243e37d88]
    decide +kernel
private theorem e46041 : Deny 5 13 b46041 := by
    apply closeAction rule_sound _ _ 64 [0x20c80c3e37209]
    decide +kernel
private theorem e46035 : Deny 5 13 b46035 :=
    branchAction rule_sound _ _ 1
      0x7 b46035 b46036 b46041 (by decide +kernel) e46036 e46041
private theorem e46048 : Deny 5 13 b46048 := by
    apply closeAction rule_sound _ _ 64 [0x1d]
    decide +kernel
private theorem e46034 : Deny 5 13 b46034 :=
    branchAction rule_sound _ _ 1
      0xa b46034 b46035 b46048 (by decide +kernel) e46035 e46048
private theorem e46026 : Deny 5 13 b46026 :=
    branchAction rule_sound _ _ 2
      0x284 b46026 b46027 b46034 (by decide +kernel) e46027 e46034
private theorem e46050 : Deny 5 13 b46050 := by
    apply closeAction rule_sound _ _ 64 [0xc221de378c9de3]
    decide +kernel
private theorem e46055 : Deny 5 13 b46055 := by
    apply closeAction rule_sound _ _ 64 [0xc3e378c80c22378c9]
    decide +kernel
private theorem e46049 : Deny 5 13 b46049 :=
    branchAction rule_sound _ _ 3
      0x78c4 b46049 b46050 b46055 (by decide +kernel) e46050 e46055
private theorem e46025 : Deny 5 13 b46025 :=
    branchAction rule_sound _ _ 1
      0xb b46025 b46026 b46049 (by decide +kernel) e46026 e46049
private theorem e46023 : Deny 5 13 b46023 :=
    branchAction rule_sound _ _ 2
      0x223 b46023 b46024 b46025 (by decide +kernel) e46024 e46025
private theorem e46063 : Deny 5 13 b46063 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
private theorem e46064 : Deny 5 13 b46064 := by
    apply closeAction rule_sound _ _ 64 [0x75577874874854a24a]
    decide +kernel
private theorem e46062 : Deny 5 13 b46062 :=
    branchAction rule_sound _ _ 1
      0xa b46062 b46063 b46064 (by decide +kernel) e46063 e46064
private theorem e46022 : Deny 5 13 b46022 :=
    branchAction rule_sound _ _ 2
      0x263 b46022 b46023 b46062 (by decide +kernel) e46023 e46062
private theorem e46076 : Deny 5 13 b46076 := by
    apply closeAction rule_sound _ _ 64 [0x566]
    decide +kernel
private theorem e46080 : Deny 5 13 b46080 := by
    apply closeAction rule_sound _ _ 64 [0x1d0c29e0266804087e368042b8]
    decide +kernel
private theorem e46089 : Deny 5 13 b46089 := by
    apply closeAction rule_sound _ _ 64 [0x20f8dc31c42380f8dc3209]
    decide +kernel
private theorem e46098 : Deny 5 13 b46098 := by
    apply closeAction rule_sound _ _ 64 [0x209d9c42389c4278]
    decide +kernel
private theorem e46088 : Deny 5 13 b46088 :=
    branchAction rule_sound _ _ 2
      0x1c4 b46088 b46089 b46098 (by decide +kernel) e46089 e46098
private theorem e46104 : Deny 5 13 b46104 := by
    apply closeAction rule_sound _ _ 64 [0x83107e030f88098080c3e37da0220260]
    decide +kernel
private theorem e46115 : Deny 5 13 b46115 := by
    apply closeAction rule_sound _ _ 64 [0x1d]
    decide +kernel
private theorem e46103 : Deny 5 13 b46103 :=
    branchAction rule_sound _ _ 2
      0x284 b46103 b46104 b46115 (by decide +kernel) e46104 e46115
private theorem e46087 : Deny 5 13 b46087 :=
    branchAction rule_sound _ _ 1
      0xb b46087 b46088 b46103 (by decide +kernel) e46088 e46103
private theorem e46079 : Deny 5 13 b46079 :=
    branchAction rule_sound _ _ 1
      0x8 b46079 b46080 b46087 (by decide +kernel) e46080 e46087
private theorem e46116 : Deny 5 13 b46116 := by
    apply closeAction rule_sound _ _ 64 [0x55de1d215289]
    decide +kernel
private theorem e46078 : Deny 5 13 b46078 :=
    branchAction rule_sound _ _ 1
      0x9 b46078 b46079 b46116 (by decide +kernel) e46079 e46116
private theorem e46123 : Deny 5 13 b46123 := by
    apply closeAction rule_sound _ _ 64 [0x1d]
    decide +kernel
private theorem e46077 : Deny 5 13 b46077 :=
    branchAction rule_sound _ _ 1
      0xa b46077 b46078 b46123 (by decide +kernel) e46078 e46123
private theorem e46075 : Deny 5 13 b46075 :=
    branchAction rule_sound _ _ 1
      0xa b46075 b46076 b46077 (by decide +kernel) e46076 e46077
private theorem e46021 : Deny 5 13 b46021 :=
    branchAction rule_sound _ _ 2
      0x1e3 b46021 b46022 b46075 (by decide +kernel) e46022 e46075
private theorem e45923 : Deny 5 13 b45923 :=
    branchAction rule_sound _ _ 1
      0xb b45923 b45924 b46021 (by decide +kernel) e45924 e46021
theorem deny5_13 : Deny 5 13 ![⟨127,190⟩,⟨18,20⟩,⟨31,62⟩,⟨3,76⟩,⟨239,478⟩] := by
  exact e45923
end OMA.Blocks5_13_245212.S45923
