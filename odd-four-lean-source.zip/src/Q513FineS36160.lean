import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S36160
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b36160 : Box := ![⟨47,94⟩,⟨15,30⟩,⟨15,1920000000000000011376⟩,⟨1,2⟩,⟨59,113⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,94⟩,⟨15,30⟩,⟨15,1920000000000000011376⟩,⟨1,2⟩,⟨59,113⟩] := by
  have e36160 : Deny 5 13 b36160 := by
    apply closeAction rule_sound _ _ 64 [0x2071020e02420c75480c31c91c42d72882575550f8da2107e221c30f8244087e09578da2215e3688a8888878842e2222,0x809088578d87df62042c9557088e221d7e095421f8da2236117e36d6210ae368871155d50e02552038090c3e090f61c2,0x5d55d50a0109e362172822045d55c92045cb5c95ca5c70d5203e36]
    decide +kernel
  exact e36160
end OMA.Blocks5_13_245212.S36160
