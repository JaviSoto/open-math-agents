import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S20196
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b20196 : Box := ![⟨23,30⟩,⟨63,1920000000000000011376⟩,⟨15,1920000000000000011376⟩,⟨3,1920000000000000011376⟩,⟨59,73⟩]
theorem deny5_13 : Deny 5 13 ![⟨23,30⟩,⟨63,1920000000000000011376⟩,⟨15,1920000000000000011376⟩,⟨3,1920000000000000011376⟩,⟨59,73⟩] := by
  have e20196 : Deny 5 13 b20196 := by
    apply closeAction rule_sound _ _ 64 [0x8491025b70e12478442d60f8de12612a11c30eb8490f8df6ae11e12440960e12611f70aba8322126110b84a8c78c88c9,0xe32232430c80eb0f822124a8c88c78c98c4082083849847849dc42f85b8de10f8dc3847849dd60c32212430f8df6847,0x22127710b2881f7082083209e020c4238dc3e2b0c8849288dc20f8ae1238dda0f8dc3ae11e110ae2b8c9ac3e370e3203,0x20968888841f8dd2e37ac20aba83e370c7221109e370820abaa1278dc2788e020f8dc32070c3209102083]
    decide +kernel
  exact e20196
end OMA.Blocks5_13_245212.S20196
