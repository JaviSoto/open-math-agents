import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S3670
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b3670 : Box := ![⟨11,22⟩,⟨7,14⟩,⟨2,1920000000000000011376⟩,⟨1,1920000000000000011376⟩,⟨29,154⟩]
theorem deny5_13 : Deny 5 13 ![⟨11,22⟩,⟨7,14⟩,⟨2,1920000000000000011376⟩,⟨1,1920000000000000011376⟩,⟨29,154⟩] := by
  have e3670 : Deny 5 13 b3670 := by
    apply closeAction rule_sound _ _ 64 [0x8c710b0c22021c22368821f8df688a0c2204087e37da325cbdcbe325ce37da32421c2236087e37da3236d631f8df68c4,0x88a0dce37da31f78c98c872f72f8c90c3e371e325cc9c28288a102238df68c70f8de2283e37da325cbc4709e37da3237,0xe370af72f8c9bc30e31e32631c30e21e22830e3243de31e325cbdcbe326f0c322325c72f88a723243e37da22a31c3e37,0x72f8c9df68c472f709bdcbc38c98c972f72f8c9df68c810b0c4088e37da324288a738df68c7088087df68c40820c8109,0x72f]
    decide +kernel
  exact e3670
end OMA.Blocks5_13_245212.S3670
