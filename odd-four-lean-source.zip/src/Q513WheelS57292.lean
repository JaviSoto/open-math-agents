import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S57292
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b57292 : Box := ![⟨63,94⟩,⟨31,62⟩,⟨15,30⟩,⟨1,61⟩,⟨239,478⟩]
private def b57293 : Box := ![⟨63,94⟩,⟨31,62⟩,⟨15,30⟩,⟨1,2⟩,⟨239,478⟩]
private def b57294 : Box := ![⟨63,94⟩,⟨31,62⟩,⟨15,30⟩,⟨3,54⟩,⟨239,478⟩]
private def b57295 : Box := ![⟨63,94⟩,⟨31,62⟩,⟨15,30⟩,⟨3,6⟩,⟨239,478⟩]
private def b57296 : Box := ![⟨63,94⟩,⟨31,41⟩,⟨15,30⟩,⟨3,6⟩,⟨239,478⟩]
private def b57297 : Box := ![⟨63,75⟩,⟨31,41⟩,⟨15,30⟩,⟨3,6⟩,⟨239,478⟩]
private def b57298 : Box := ![⟨63,75⟩,⟨31,41⟩,⟨15,20⟩,⟨3,6⟩,⟨239,478⟩]
private def b57299 : Box := ![⟨63,75⟩,⟨31,41⟩,⟨15,20⟩,⟨3,6⟩,⟨239,318⟩]
private def b57300 : Box := ![⟨63,75⟩,⟨31,35⟩,⟨15,20⟩,⟨3,6⟩,⟨239,317⟩]
private def b57301 : Box := ![⟨63,75⟩,⟨31,35⟩,⟨15,17⟩,⟨3,6⟩,⟨239,317⟩]
private def b57306 : Box := ![⟨63,75⟩,⟨31,35⟩,⟨18,20⟩,⟨3,6⟩,⟨239,317⟩]
private def b57313 : Box := ![⟨63,75⟩,⟨36,41⟩,⟨15,20⟩,⟨3,6⟩,⟨239,317⟩]
private def b57314 : Box := ![⟨63,75⟩,⟨36,41⟩,⟨15,17⟩,⟨3,6⟩,⟨239,317⟩]
private def b57319 : Box := ![⟨63,75⟩,⟨36,41⟩,⟨18,20⟩,⟨3,6⟩,⟨239,317⟩]
private def b57326 : Box := ![⟨63,75⟩,⟨31,41⟩,⟨15,20⟩,⟨3,6⟩,⟨319,478⟩]
private def b57327 : Box := ![⟨63,75⟩,⟨31,35⟩,⟨15,20⟩,⟨3,6⟩,⟨319,478⟩]
private def b57332 : Box := ![⟨63,75⟩,⟨36,41⟩,⟨15,20⟩,⟨3,6⟩,⟨319,478⟩]
private def b57333 : Box := ![⟨63,75⟩,⟨36,41⟩,⟨15,17⟩,⟨3,6⟩,⟨319,478⟩]
private def b57338 : Box := ![⟨63,75⟩,⟨36,41⟩,⟨18,20⟩,⟨3,6⟩,⟨319,478⟩]
private def b57345 : Box := ![⟨63,75⟩,⟨31,41⟩,⟨21,30⟩,⟨3,6⟩,⟨239,478⟩]
private def b57346 : Box := ![⟨63,75⟩,⟨31,41⟩,⟨21,30⟩,⟨3,4⟩,⟨239,478⟩]
private def b57347 : Box := ![⟨63,75⟩,⟨31,41⟩,⟨21,30⟩,⟨5,6⟩,⟨239,478⟩]
private def b57348 : Box := ![⟨63,75⟩,⟨31,41⟩,⟨21,30⟩,⟨5,5⟩,⟨239,478⟩]
private def b57349 : Box := ![⟨63,75⟩,⟨31,41⟩,⟨21,30⟩,⟨5,5⟩,⟨239,318⟩]
private def b57350 : Box := ![⟨63,75⟩,⟨31,41⟩,⟨21,30⟩,⟨5,5⟩,⟨319,478⟩]
private def b57361 : Box := ![⟨63,75⟩,⟨31,41⟩,⟨21,30⟩,⟨6,6⟩,⟨239,478⟩]
private def b57362 : Box := ![⟨76,94⟩,⟨31,41⟩,⟨15,30⟩,⟨3,6⟩,⟨239,478⟩]
private def b57363 : Box := ![⟨76,94⟩,⟨31,41⟩,⟨15,20⟩,⟨3,6⟩,⟨239,478⟩]
private def b57364 : Box := ![⟨76,94⟩,⟨31,41⟩,⟨15,20⟩,⟨3,6⟩,⟨239,318⟩]
private def b57365 : Box := ![⟨76,94⟩,⟨31,35⟩,⟨15,20⟩,⟨3,6⟩,⟨239,317⟩]
private def b57376 : Box := ![⟨76,94⟩,⟨36,41⟩,⟨15,20⟩,⟨3,6⟩,⟨239,317⟩]
private def b57383 : Box := ![⟨76,94⟩,⟨31,41⟩,⟨15,20⟩,⟨3,6⟩,⟨319,478⟩]
private def b57384 : Box := ![⟨76,94⟩,⟨31,35⟩,⟨15,20⟩,⟨3,6⟩,⟨319,478⟩]
private def b57385 : Box := ![⟨76,94⟩,⟨31,35⟩,⟨15,17⟩,⟨3,6⟩,⟨319,478⟩]
private def b57390 : Box := ![⟨76,94⟩,⟨31,35⟩,⟨18,20⟩,⟨3,6⟩,⟨319,478⟩]
private def b57399 : Box := ![⟨76,94⟩,⟨36,41⟩,⟨15,20⟩,⟨3,6⟩,⟨319,478⟩]
private def b57410 : Box := ![⟨76,94⟩,⟨31,41⟩,⟨21,30⟩,⟨3,6⟩,⟨239,478⟩]
private def b57421 : Box := ![⟨63,94⟩,⟨42,62⟩,⟨15,30⟩,⟨3,6⟩,⟨239,478⟩]
private def b57422 : Box := ![⟨63,75⟩,⟨42,62⟩,⟨15,30⟩,⟨3,6⟩,⟨239,478⟩]
private def b57423 : Box := ![⟨63,75⟩,⟨42,62⟩,⟨15,20⟩,⟨3,6⟩,⟨239,478⟩]
private def b57424 : Box := ![⟨63,75⟩,⟨42,62⟩,⟨15,20⟩,⟨3,6⟩,⟨239,318⟩]
private def b57435 : Box := ![⟨63,75⟩,⟨42,62⟩,⟨15,20⟩,⟨3,6⟩,⟨319,478⟩]
private def b57436 : Box := ![⟨63,75⟩,⟨42,50⟩,⟨15,20⟩,⟨3,6⟩,⟨319,478⟩]
private def b57437 : Box := ![⟨63,75⟩,⟨42,50⟩,⟨15,17⟩,⟨3,6⟩,⟨319,478⟩]
private def b57446 : Box := ![⟨63,75⟩,⟨42,50⟩,⟨18,20⟩,⟨3,6⟩,⟨319,478⟩]
private def b57453 : Box := ![⟨63,75⟩,⟨51,62⟩,⟨15,20⟩,⟨3,6⟩,⟨319,478⟩]
private def b57464 : Box := ![⟨63,75⟩,⟨42,62⟩,⟨21,30⟩,⟨3,6⟩,⟨239,478⟩]
private def b57467 : Box := ![⟨76,94⟩,⟨42,62⟩,⟨15,30⟩,⟨3,6⟩,⟨239,478⟩]
private def b57468 : Box := ![⟨76,94⟩,⟨42,62⟩,⟨15,20⟩,⟨3,6⟩,⟨364,478⟩]
private def b57479 : Box := ![⟨76,94⟩,⟨42,62⟩,⟨21,30⟩,⟨3,6⟩,⟨364,478⟩]
private def b57480 : Box := ![⟨63,94⟩,⟨31,62⟩,⟨15,30⟩,⟨7,54⟩,⟨239,478⟩]
private theorem e57293 : Deny 5 13 b57293 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e57301 : Deny 5 13 b57301 := by
    apply closeAction rule_sound _ _ 64 [0x30f8dc80f8dc7]
    decide +kernel
private theorem e57306 : Deny 5 13 b57306 := by
    apply closeAction rule_sound _ _ 64 [0x1f5c324a5ca]
    decide +kernel
private theorem e57300 : Deny 5 13 b57300 :=
    branchAction rule_sound _ _ 1
      0x9 b57300 b57301 b57306 (by decide +kernel) e57301 e57306
private theorem e57314 : Deny 5 13 b57314 := by
    apply closeAction rule_sound _ _ 64 [0x30c70c9]
    decide +kernel
private theorem e57319 : Deny 5 13 b57319 := by
    apply closeAction rule_sound _ _ 64 [0x1f5c324a5ca]
    decide +kernel
private theorem e57313 : Deny 5 13 b57313 :=
    branchAction rule_sound _ _ 1
      0x9 b57313 b57314 b57319 (by decide +kernel) e57314 e57319
private theorem e57299 : Deny 5 13 b57299 :=
    branchAction rule_sound _ _ 2
      0x204 b57299 b57300 b57313 (by decide +kernel) e57300 e57313
private theorem e57327 : Deny 5 13 b57327 := by
    apply closeAction rule_sound _ _ 64 [0x1f5cad84087e36]
    decide +kernel
private theorem e57333 : Deny 5 13 b57333 := by
    apply closeAction rule_sound _ _ 64 [0xc3e371c3e09]
    decide +kernel
private theorem e57338 : Deny 5 13 b57338 := by
    apply closeAction rule_sound _ _ 64 [0x7df7cb10b5ca]
    decide +kernel
private theorem e57332 : Deny 5 13 b57332 :=
    branchAction rule_sound _ _ 1
      0x9 b57332 b57333 b57338 (by decide +kernel) e57333 e57338
private theorem e57326 : Deny 5 13 b57326 :=
    branchAction rule_sound _ _ 1
      0x8 b57326 b57327 b57332 (by decide +kernel) e57327 e57332
private theorem e57298 : Deny 5 13 b57298 :=
    branchAction rule_sound _ _ 1
      0xb b57298 b57299 b57326 (by decide +kernel) e57299 e57326
private theorem e57346 : Deny 5 13 b57346 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e57349 : Deny 5 13 b57349 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e57350 : Deny 5 13 b57350 := by
    apply closeAction rule_sound _ _ 64 [0x5df5d70c87c92042c8]
    decide +kernel
private theorem e57348 : Deny 5 13 b57348 :=
    branchAction rule_sound _ _ 1
      0xb b57348 b57349 b57350 (by decide +kernel) e57349 e57350
private theorem e57361 : Deny 5 13 b57361 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e57347 : Deny 5 13 b57347 :=
    branchAction rule_sound _ _ 1
      0xa b57347 b57348 b57361 (by decide +kernel) e57348 e57361
private theorem e57345 : Deny 5 13 b57345 :=
    branchAction rule_sound _ _ 1
      0xa b57345 b57346 b57347 (by decide +kernel) e57346 e57347
private theorem e57297 : Deny 5 13 b57297 :=
    branchAction rule_sound _ _ 1
      0x9 b57297 b57298 b57345 (by decide +kernel) e57298 e57345
private theorem e57365 : Deny 5 13 b57365 := by
    apply closeAction rule_sound _ _ 64 [0x17e370f80c81c3e031c3249]
    decide +kernel
private theorem e57376 : Deny 5 13 b57376 := by
    apply closeAction rule_sound _ _ 64 [0x2097e370c81c4278]
    decide +kernel
private theorem e57364 : Deny 5 13 b57364 :=
    branchAction rule_sound _ _ 2
      0x204 b57364 b57365 b57376 (by decide +kernel) e57365 e57376
private theorem e57385 : Deny 5 13 b57385 := by
    apply closeAction rule_sound _ _ 64 [0x30f81c3e09]
    decide +kernel
private theorem e57390 : Deny 5 13 b57390 := by
    apply closeAction rule_sound _ _ 64 [0x7c20c87c710b5ca]
    decide +kernel
private theorem e57384 : Deny 5 13 b57384 :=
    branchAction rule_sound _ _ 1
      0x9 b57384 b57385 b57390 (by decide +kernel) e57385 e57390
private theorem e57399 : Deny 5 13 b57399 := by
    apply closeAction rule_sound _ _ 64 [0x1fe172b80f80c8e030c81c9]
    decide +kernel
private theorem e57383 : Deny 5 13 b57383 :=
    branchAction rule_sound _ _ 1
      0x8 b57383 b57384 b57399 (by decide +kernel) e57384 e57399
private theorem e57363 : Deny 5 13 b57363 :=
    branchAction rule_sound _ _ 1
      0xb b57363 b57364 b57383 (by decide +kernel) e57364 e57383
private theorem e57410 : Deny 5 13 b57410 := by
    apply closeAction rule_sound _ _ 64 [0x17e377f87f87f80c8247e172b8238]
    decide +kernel
private theorem e57362 : Deny 5 13 b57362 :=
    branchAction rule_sound _ _ 1
      0x9 b57362 b57363 b57410 (by decide +kernel) e57363 e57410
private theorem e57296 : Deny 5 13 b57296 :=
    branchAction rule_sound _ _ 1
      0x7 b57296 b57297 b57362 (by decide +kernel) e57297 e57362
private theorem e57424 : Deny 5 13 b57424 := by
    apply closeAction rule_sound _ _ 64 [0x5f8dd7e370832380f80c81c9204]
    decide +kernel
private theorem e57437 : Deny 5 13 b57437 := by
    apply closeAction rule_sound _ _ 64 [0xf80c9e032030f8207]
    decide +kernel
private theorem e57446 : Deny 5 13 b57446 := by
    apply closeAction rule_sound _ _ 64 [0x7f87f80c81f85ca]
    decide +kernel
private theorem e57436 : Deny 5 13 b57436 :=
    branchAction rule_sound _ _ 1
      0x9 b57436 b57437 b57446 (by decide +kernel) e57437 e57446
private theorem e57453 : Deny 5 13 b57453 := by
    apply closeAction rule_sound _ _ 64 [0x824f7109e375f8dc40c42780c81c9]
    decide +kernel
private theorem e57435 : Deny 5 13 b57435 :=
    branchAction rule_sound _ _ 1
      0x8 b57435 b57436 b57453 (by decide +kernel) e57436 e57453
private theorem e57423 : Deny 5 13 b57423 :=
    branchAction rule_sound _ _ 1
      0xb b57423 b57424 b57435 (by decide +kernel) e57424 e57435
private theorem e57464 : Deny 5 13 b57464 := by
    apply closeAction rule_sound _ _ 64 [0x7f81172b8]
    decide +kernel
private theorem e57422 : Deny 5 13 b57422 :=
    branchAction rule_sound _ _ 1
      0x9 b57422 b57423 b57464 (by decide +kernel) e57423 e57464
private theorem e57468 : Deny 5 13 b57468 := by
    apply closeAction rule_sound _ _ 64 [0x820820f8dc31c81c9204]
    decide +kernel
private theorem e57479 : Deny 5 13 b57479 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e57467 : Deny 5 13 b57467 :=
    branchAction rule_sound _ _ 2
      0x278 b57467 b57468 b57479 (by decide +kernel) e57468 e57479
private theorem e57421 : Deny 5 13 b57421 :=
    branchAction rule_sound _ _ 1
      0x7 b57421 b57422 b57467 (by decide +kernel) e57422 e57467
private theorem e57295 : Deny 5 13 b57295 :=
    branchAction rule_sound _ _ 1
      0x8 b57295 b57296 b57421 (by decide +kernel) e57296 e57421
private theorem e57480 : Deny 5 13 b57480 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e57294 : Deny 5 13 b57294 :=
    branchAction rule_sound _ _ 1
      0xa b57294 b57295 b57480 (by decide +kernel) e57295 e57480
private theorem e57292 : Deny 5 13 b57292 :=
    branchAction rule_sound _ _ 2
      0x2a3 b57292 b57293 b57294 (by decide +kernel) e57293 e57294
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨31,62⟩,⟨15,30⟩,⟨1,61⟩,⟨239,478⟩] := by
  exact e57292
end OMA.Blocks5_13_245212.S57292
