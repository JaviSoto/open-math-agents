import FastReplay245212
import SparseDigit245212
import FastRound245212
import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S23047
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b23047 : Box := ![⟨23,46⟩,⟨15,30⟩,⟨7,14⟩,⟨1,994807017543859655059⟩,⟨103,999999999999999999⟩]
private def b23048 : Box := ![⟨23,30⟩,⟨15,30⟩,⟨7,14⟩,⟨1,39⟩,⟨103,999999999999999999⟩]
private def b23049 : Box := ![⟨23,30⟩,⟨15,30⟩,⟨7,14⟩,⟨1,35⟩,⟨103,202⟩]
private def b23050 : Box := ![⟨23,30⟩,⟨15,20⟩,⟨7,14⟩,⟨1,28⟩,⟨103,199⟩]
private def b23059 : Box := ![⟨23,30⟩,⟨21,30⟩,⟨7,14⟩,⟨1,28⟩,⟨103,199⟩]
private def b23072 : Box := ![⟨23,30⟩,⟨15,30⟩,⟨7,14⟩,⟨1,35⟩,⟨203,4666⟩]
private def b23085 : Box := ![⟨31,46⟩,⟨15,30⟩,⟨7,14⟩,⟨1,39⟩,⟨103,999999999999999999⟩]
private def b23086 : Box := ![⟨31,46⟩,⟨15,30⟩,⟨7,14⟩,⟨1,39⟩,⟨103,206⟩]
private def b23087 : Box := ![⟨31,46⟩,⟨15,20⟩,⟨7,14⟩,⟨1,31⟩,⟨103,199⟩]
private def b23088 : Box := ![⟨31,46⟩,⟨15,20⟩,⟨7,9⟩,⟨1,28⟩,⟨103,199⟩]
private def b23093 : Box := ![⟨31,46⟩,⟨15,20⟩,⟨10,14⟩,⟨1,28⟩,⟨103,199⟩]
private def b23094 : Box := ![⟨31,37⟩,⟨15,20⟩,⟨10,14⟩,⟨1,28⟩,⟨103,199⟩]
private def b23099 : Box := ![⟨38,46⟩,⟨15,20⟩,⟨10,14⟩,⟨1,28⟩,⟨103,199⟩]
private def b23112 : Box := ![⟨31,46⟩,⟨21,30⟩,⟨7,14⟩,⟨1,31⟩,⟨103,199⟩]
private def b23113 : Box := ![⟨31,46⟩,⟨21,30⟩,⟨7,9⟩,⟨1,31⟩,⟨103,199⟩]
private def b23124 : Box := ![⟨31,46⟩,⟨21,30⟩,⟨10,14⟩,⟨1,31⟩,⟨103,199⟩]
private def b23125 : Box := ![⟨31,37⟩,⟨21,30⟩,⟨10,14⟩,⟨1,31⟩,⟨103,199⟩]
private def b23126 : Box := ![⟨31,37⟩,⟨21,30⟩,⟨10,14⟩,⟨1,29⟩,⟨103,135⟩]
private def b23131 : Box := ![⟨31,37⟩,⟨21,30⟩,⟨10,14⟩,⟨1,29⟩,⟨136,199⟩]
private def b23142 : Box := ![⟨38,46⟩,⟨21,30⟩,⟨10,14⟩,⟨1,31⟩,⟨103,199⟩]
private def b23143 : Box := ![⟨31,46⟩,⟨15,30⟩,⟨7,14⟩,⟨1,39⟩,⟨207,999999999999999999⟩]
private def b23144 : Box := ![⟨31,46⟩,⟨15,20⟩,⟨7,14⟩,⟨1,34⟩,⟨207,999999999999999999⟩]
private def b23145 : Box := ![⟨31,46⟩,⟨15,20⟩,⟨7,9⟩,⟨1,31⟩,⟨207,999999999999999999⟩]
private def b23150 : Box := ![⟨31,46⟩,⟨15,20⟩,⟨10,14⟩,⟨1,31⟩,⟨207,999999999999999999⟩]
private def b23151 : Box := ![⟨31,37⟩,⟨15,20⟩,⟨10,14⟩,⟨1,31⟩,⟨207,999999999999999999⟩]
private def b23156 : Box := ![⟨38,46⟩,⟨15,20⟩,⟨10,14⟩,⟨1,31⟩,⟨207,999999999999999999⟩]
private def b23171 : Box := ![⟨31,46⟩,⟨21,30⟩,⟨7,14⟩,⟨1,34⟩,⟨207,999999999999999999⟩]
private def b23172 : Box := ![⟨31,46⟩,⟨21,30⟩,⟨7,9⟩,⟨1,34⟩,⟨207,999999999999999999⟩]
private def b23183 : Box := ![⟨31,46⟩,⟨21,30⟩,⟨10,14⟩,⟨1,34⟩,⟨207,999999999999999999⟩]
private def b23184 : Box := ![⟨31,37⟩,⟨21,30⟩,⟨10,14⟩,⟨1,34⟩,⟨207,999999999999999999⟩]
private def b23185 : Box := ![⟨31,37⟩,⟨21,30⟩,⟨10,14⟩,⟨1,32⟩,⟨207,414⟩]
private def b23194 : Box := ![⟨31,37⟩,⟨21,30⟩,⟨10,14⟩,⟨1,32⟩,⟨415,999999999999999999⟩]
private def b23203 : Box := ![⟨38,46⟩,⟨21,30⟩,⟨10,14⟩,⟨1,34⟩,⟨207,999999999999999999⟩]
theorem deny5_11 : Deny 5 11 ![⟨23,46⟩,⟨15,30⟩,⟨7,14⟩,⟨1,994807017543859655059⟩,⟨103,999999999999999999⟩] := by
  have e23050 : Deny 5 11 b23050 := by
    apply closeAction rule_sound _ _ 64 [0x30f8de31c3e378c90c21f8de3263]
    decide +kernel
  have e23059 : Deny 5 11 b23059 := by
    apply closeAction rule_sound _ _ 64 [0x30e31c30e31e31c30f8de31c3e378c88c9]
    decide +kernel
  have e23049 : Deny 5 11 b23049 :=
    branchAction rule_sound _ _ 3
      0x88c4 b23049 b23050 b23059 (by decide +kernel) e23050 e23059
  have e23072 : Deny 5 11 b23072 := by
    apply closeAction rule_sound _ _ 64 [0x3e03e378c9e03e368c8e230f88c3e37db58c7e37da31f80f7d44087e37da3238da3]
    decide +kernel
  have e23048 : Deny 5 11 b23048 :=
    branchAction rule_sound _ _ 3
      0xbe23 b23048 b23049 b23072 (by decide +kernel) e23049 e23072
  have e23088 : Deny 5 11 b23088 := by
    apply closeAction rule_sound _ _ 64 [0xc38c80e3263]
    decide +kernel
  have e23094 : Deny 5 11 b23094 := by
    apply closeAction rule_sound _ _ 64 [0xc38c80e31e3]
    decide +kernel
  have e23099 : Deny 5 11 b23099 := by
    apply closeAction rule_sound _ _ 64 [0x17e370c9dc30e3263223117e370f70c923710b]
    decide +kernel
  have e23093 : Deny 5 11 b23093 :=
    branchAction rule_sound _ _ 1
      0x7 b23093 b23094 b23099 (by decide +kernel) e23094 e23099
  have e23087 : Deny 5 11 b23087 :=
    branchAction rule_sound _ _ 2
      0x263 b23087 b23088 b23093 (by decide +kernel) e23088 e23093
  have e23113 : Deny 5 11 b23113 := by
    apply closeAction rule_sound _ _ 64 [0x4f8dc3238dc38c90c38c90e32231e3]
    decide +kernel
  have e23126 : Deny 5 11 b23126 := by
    apply closeAction rule_sound _ _ 64 [0x25c3248dc4]
    decide +kernel
  have e23131 : Deny 5 11 b23131 := by
    apply closeAction rule_sound _ _ 64 [0x20f8dc38c78c85c30c824a8c4]
    decide +kernel
  have e23125 : Deny 5 11 b23125 :=
    branchAction rule_sound _ _ 2
      0x2e3 b23125 b23126 b23131 (by decide +kernel) e23126 e23131
  have e23142 : Deny 5 11 b23142 := by
    apply closeAction rule_sound _ _ 64 [0x17e37]
    decide +kernel
  have e23124 : Deny 5 11 b23124 :=
    branchAction rule_sound _ _ 1
      0x7 b23124 b23125 b23142 (by decide +kernel) e23125 e23142
  have e23112 : Deny 5 11 b23112 :=
    branchAction rule_sound _ _ 1
      0x9 b23112 b23113 b23124 (by decide +kernel) e23113 e23124
  have e23086 : Deny 5 11 b23086 :=
    branchAction rule_sound _ _ 3
      0x88c4 b23086 b23087 b23112 (by decide +kernel) e23087 e23112
  have e23145 : Deny 5 11 b23145 := by
    apply closeAction rule_sound _ _ 64 [0x3e03e37da32388c3e37db58c7e23]
    decide +kernel
  have e23151 : Deny 5 11 b23151 := by
    apply closeAction rule_sound _ _ 64 [0xc3e378c7e230f8df68c8e23]
    decide +kernel
  have e23156 : Deny 5 11 b23156 := by
    apply closeAction rule_sound _ _ 64 [0x30f88c90f88c3e378c9e232230c38c90c38c98c88cb]
    decide +kernel
  have e23150 : Deny 5 11 b23150 :=
    branchAction rule_sound _ _ 1
      0x7 b23150 b23151 b23156 (by decide +kernel) e23151 e23156
  have e23144 : Deny 5 11 b23144 :=
    branchAction rule_sound _ _ 2
      0x263 b23144 b23145 b23150 (by decide +kernel) e23145 e23150
  have e23172 : Deny 5 11 b23172 := by
    apply closeAction rule_sound _ _ 64 [0xc38c70f88c90f80f8de32788c3e378c8e231e3]
    decide +kernel
  have e23185 : Deny 5 11 b23185 := by
    apply closeAction rule_sound _ _ 64 [0x20f88c9e031c30e31e3223]
    decide +kernel
  have e23194 : Deny 5 11 b23194 := by
    apply closeAction rule_sound _ _ 64 [0xf80e32431c30f8da31e3223]
    decide +kernel
  have e23184 : Deny 5 11 b23184 :=
    branchAction rule_sound _ _ 2
      0x2e3 b23184 b23185 b23194 (by decide +kernel) e23185 e23194
  have e23203 : Deny 5 11 b23203 := by
    apply closeAction rule_sound _ _ 64 [0x2083e07e232780c38c78c88c25f8dc38c98c88cb]
    decide +kernel
  have e23183 : Deny 5 11 b23183 :=
    branchAction rule_sound _ _ 1
      0x7 b23183 b23184 b23203 (by decide +kernel) e23184 e23203
  have e23171 : Deny 5 11 b23171 :=
    branchAction rule_sound _ _ 1
      0x9 b23171 b23172 b23183 (by decide +kernel) e23172 e23183
  have e23143 : Deny 5 11 b23143 :=
    branchAction rule_sound _ _ 2
      0x223 b23143 b23144 b23171 (by decide +kernel) e23144 e23171
  have e23085 : Deny 5 11 b23085 :=
    branchAction rule_sound _ _ 1
      0xb b23085 b23086 b23143 (by decide +kernel) e23086 e23143
  have e23047 : Deny 5 11 b23047 :=
    branchAction rule_sound _ _ 2
      0x1e3 b23047 b23048 b23085 (by decide +kernel) e23048 e23085
  exact e23047
end OMA.Blocks5_11_245212.S23047
