import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S28911
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b28911 : Box := ![⟨31,37⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨1,1301352063213345047248⟩,⟨479,999999999999999999⟩]
private def b28912 : Box := ![⟨31,37⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨1,2⟩,⟨479,999999999999999999⟩]
private def b28913 : Box := ![⟨31,37⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨3,502335381913959616720⟩,⟨479,999999999999999999⟩]
private def b28914 : Box := ![⟨31,33⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨3,502335381913959616720⟩,⟨479,999999999999999999⟩]
private def b28923 : Box := ![⟨34,37⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨3,502335381913959616720⟩,⟨479,999999999999999999⟩]
private def b28924 : Box := ![⟨34,37⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨3,502335381913959616720⟩,⟨479,958⟩]
private def b28939 : Box := ![⟨34,37⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨3,502335381913959616720⟩,⟨959,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨31,37⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨1,1301352063213345047248⟩,⟨479,999999999999999999⟩] := by
  have e28912 : Deny 5 13 b28912 := by
    apply closeAction rule_sound _ _ 64 [0x5b8da1]
    decide +kernel
  have e28914 : Deny 5 13 b28914 := by
    apply closeAction rule_sound _ _ 64 [0x6ab7ab8c8ade8c85b8df6d612a30aa84ae35]
    decide +kernel
  have e28924 : Deny 5 13 b28924 := by
    apply closeAction rule_sound _ _ 64 [0x1aadeae322b79f7dfe36847e211dfe212612a3216aa12a3]
    decide +kernel
  have e28939 : Deny 5 13 b28939 := by
    apply closeAction rule_sound _ _ 64 [0x8c88daada22b8cb6ab8daae3238d631d2e21292e2b84aae326b79f7f8db5847e368421f8da12b88d6e36aa12b8da3223,0x6ab8c8e2b8daae3238adaae3223278adaae322b8c9adaae32021eb6a32358daae32dae358c9da36ab8cb8daae32dae36,0x8da2eb6ab8c88da2dae36d476b8d6b8c9adee368c8da36ab8cb8daae32dee23212e21292e36ae128708209aae3238ae3,0x22b8cb08209aae3238ae36ab8c8e2b8daae3238ada8c8ae3278ae36ab8c8e1ae358c9089ae326b6ab8c88da2eb6ab8c8,0x7ab8cb8deae32e37ab8cb8deae32e37ab8cb8deae32f68deae32e37ab8cb8deae32e37ab8cb8deae32eb8c88daadeae3,0x1e12a378b8de2e378b8de2daac2235ae326378b8de2e378b8de2e378b8de2e378b8de2e378b8de2e37ab8cb8deae32e3,0x8c80878c8ae322b8c98daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32eb69e0c226b088ac2235ae1242,0x78b8de2e3207ae320208209aae3238adaae3235ac227526b6ab8c8adaae32358c9adaae3207adaadaada68b8da2e378b,0x209aadaade6ab088ae32768c88de2e3]
    decide +kernel
  have e28923 : Deny 5 13 b28923 :=
    branchAction rule_sound _ _ 1
      0xb b28923 b28924 b28939 (by decide +kernel) e28924 e28939
  have e28913 : Deny 5 13 b28913 :=
    branchAction rule_sound _ _ 1
      0x7 b28913 b28914 b28923 (by decide +kernel) e28914 e28923
  have e28911 : Deny 5 13 b28911 :=
    branchAction rule_sound _ _ 2
      0x2a3 b28911 b28912 b28913 (by decide +kernel) e28912 e28913
  exact e28911
end OMA.Blocks5_13_245212.S28911
