import Engine245212
import SingletonCaps245212

namespace OMA.Box245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def words5_31 : List ℕ := [
0x4]
theorem deny5_31 : Deny 5 31 ![⟨2,7952⟩,⟨1,7952⟩,⟨1,7952⟩,⟨1,7952⟩,⟨32,32⟩] := by
  apply trace_sound singletonCaps (fun _ _ _ _ fit c=>singletonCaps_sound fit c) _ _ words5_31
  decide +kernel
end OMA.Box245212
