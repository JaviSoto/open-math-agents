import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S54690
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b54690 : Box := ![⟨58,62⟩,⟨63,84⟩,⟨12,14⟩,⟨3,41⟩,⟨479,958⟩]
private def b54691 : Box := ![⟨58,62⟩,⟨63,84⟩,⟨12,14⟩,⟨3,41⟩,⟨479,638⟩]
private def b54692 : Box := ![⟨58,62⟩,⟨63,72⟩,⟨12,14⟩,⟨3,41⟩,⟨479,638⟩]
private def b54693 : Box := ![⟨58,62⟩,⟨63,72⟩,⟨12,12⟩,⟨3,38⟩,⟨479,638⟩]
private def b54694 : Box := ![⟨58,62⟩,⟨63,72⟩,⟨13,14⟩,⟨3,38⟩,⟨479,638⟩]
private def b54695 : Box := ![⟨58,62⟩,⟨73,84⟩,⟨12,14⟩,⟨3,41⟩,⟨479,638⟩]
private def b54696 : Box := ![⟨58,62⟩,⟨73,78⟩,⟨12,14⟩,⟨3,41⟩,⟨479,638⟩]
private def b54697 : Box := ![⟨58,62⟩,⟨79,84⟩,⟨12,14⟩,⟨3,41⟩,⟨479,638⟩]
private def b54698 : Box := ![⟨58,62⟩,⟨63,84⟩,⟨12,14⟩,⟨3,41⟩,⟨639,958⟩]
private def b54699 : Box := ![⟨58,62⟩,⟨63,84⟩,⟨12,12⟩,⟨3,39⟩,⟨639,958⟩]
private def b54700 : Box := ![⟨58,62⟩,⟨63,84⟩,⟨13,14⟩,⟨3,39⟩,⟨639,958⟩]
private def b54701 : Box := ![⟨58,62⟩,⟨63,72⟩,⟨13,14⟩,⟨3,39⟩,⟨639,958⟩]
private def b54702 : Box := ![⟨58,62⟩,⟨73,84⟩,⟨13,14⟩,⟨3,39⟩,⟨639,958⟩]
private def b54703 : Box := ![⟨58,59⟩,⟨73,84⟩,⟨13,14⟩,⟨3,39⟩,⟨639,958⟩]
private def b54704 : Box := ![⟨60,62⟩,⟨73,84⟩,⟨13,14⟩,⟨3,39⟩,⟨639,958⟩]
private theorem e54693 : Deny 5 13 b54693 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e54694 : Deny 5 13 b54694 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e54692 : Deny 5 13 b54692 :=
    branchAction rule_sound _ _ 2
      0x263 b54692 b54693 b54694 (by decide +kernel) e54693 e54694
private theorem e54696 : Deny 5 13 b54696 := by
    apply closeAction rule_sound _ _ 64 [0xe3]
    decide +kernel
private theorem e54697 : Deny 5 13 b54697 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e54695 : Deny 5 13 b54695 :=
    branchAction rule_sound _ _ 1
      0x8 b54695 b54696 b54697 (by decide +kernel) e54696 e54697
private theorem e54691 : Deny 5 13 b54691 :=
    branchAction rule_sound _ _ 1
      0x8 b54691 b54692 b54695 (by decide +kernel) e54692 e54695
private theorem e54699 : Deny 5 13 b54699 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e54701 : Deny 5 13 b54701 := by
    apply closeAction rule_sound _ _ 64 [0xf8de3]
    decide +kernel
private theorem e54703 : Deny 5 13 b54703 := by
    apply closeAction rule_sound _ _ 64 [0x3e37]
    decide +kernel
private theorem e54704 : Deny 5 13 b54704 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e54702 : Deny 5 13 b54702 :=
    branchAction rule_sound _ _ 1
      0x7 b54702 b54703 b54704 (by decide +kernel) e54703 e54704
private theorem e54700 : Deny 5 13 b54700 :=
    branchAction rule_sound _ _ 1
      0x8 b54700 b54701 b54702 (by decide +kernel) e54701 e54702
private theorem e54698 : Deny 5 13 b54698 :=
    branchAction rule_sound _ _ 2
      0x263 b54698 b54699 b54700 (by decide +kernel) e54699 e54700
private theorem e54690 : Deny 5 13 b54690 :=
    branchAction rule_sound _ _ 1
      0xb b54690 b54691 b54698 (by decide +kernel) e54691 e54698
theorem deny5_13 : Deny 5 13 ![⟨58,62⟩,⟨63,84⟩,⟨12,14⟩,⟨3,41⟩,⟨479,958⟩] := by
  exact e54690
end OMA.Blocks5_13_245212.S54690
