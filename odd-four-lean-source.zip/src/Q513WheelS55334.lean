import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S55334
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b55334 : Box := ![⟨63,94⟩,⟨63,126⟩,⟨7,9⟩,⟨1,502335381913959616708⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨63,126⟩,⟨7,9⟩,⟨1,502335381913959616708⟩,⟨479,999999999999999999⟩] := by
  have e55334 : Deny 5 13 b55334 := by
    apply closeAction rule_sound _ _ 64 [0x2386f8df5278d636db6d34c3e211c22784f8d88e3584784a84a29328be1bac3e2320226b088087e358c74cae23089e23,0x1b6db6db4ca84a28b2d3e212b86eb0f88c8ac22388c7e030870881021f8de3]
    decide +kernel
  exact e55334
end OMA.Blocks5_13_245212.S55334
