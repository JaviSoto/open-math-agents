import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S32777
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b32777 : Box := ![⟨38,41⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨1,502335381913959616722⟩,⟨479,999999999999999999⟩]
private def b32778 : Box := ![⟨38,41⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨1,502335381913959616721⟩,⟨479,958⟩]
private def b32793 : Box := ![⟨38,41⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨1,502335381913959616721⟩,⟨959,999999999999999999⟩]
private def b32794 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨31,62⟩,⟨1,451586424625098660967⟩,⟨959,999999999999999999⟩]
private def b32795 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨31,41⟩,⟨1,97⟩,⟨959,999999999999999999⟩]
private def b32928 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨42,62⟩,⟨1,97⟩,⟨959,999999999999999999⟩]
private def b32929 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨42,62⟩,⟨1,97⟩,⟨959,1918⟩]
private def b32938 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨42,62⟩,⟨1,97⟩,⟨1919,999999999999999999⟩]
private def b32939 : Box := ![⟨38,41⟩,⟨127,169⟩,⟨42,62⟩,⟨1,88⟩,⟨1919,999999999999999999⟩]
private def b33028 : Box := ![⟨38,41⟩,⟨170,254⟩,⟨42,62⟩,⟨1,88⟩,⟨1919,999999999999999999⟩]
private def b33267 : Box := ![⟨38,41⟩,⟨255,1920000000000000011376⟩,⟨31,62⟩,⟨1,451586424625098660967⟩,⟨959,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨38,41⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨1,502335381913959616722⟩,⟨479,999999999999999999⟩] := by
  have e32778 : Deny 5 13 b32778 := by
    apply closeAction rule_sound _ _ 64 [0xab0ab5b8ddf58a58a1e32235b72dfae3263223]
    decide +kernel
  have e32795 : Deny 5 13 b32795 := by
    apply closeAction rule_sound _ _ 64 [0x8cb8dfae32deae37f8d6b8c9e070c3e232022237eb8cb7f8df6d477f8df58c9da37eb8cb0878c84b8dab84a8dfae32e3,0x2e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cbdf61e36ab8cbac3e2b088e2b8c21f88c8ae32637eb,0xae12daae12daae12daae12daae12daaea84b2a36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae3,0x7ab8cb8deae32e37ab8cb8deae32e37ab8cb8deae32da683ac320226129aae12daae12daae12daae12daae12daae12da,0x20838c80eb088ac91eb08326b0e3203ac22361e3223]
    decide +kernel
  have e32929 : Deny 5 13 b32929 := by
    apply closeAction rule_sound _ _ 64 [0x1fadf7d62a12962a3223]
    decide +kernel
  have e32939 : Deny 5 13 b32939 := by
    apply closeAction rule_sound _ _ 64 [0xf8ae32388c90f88c2278df68c779f2962962b88c21f8da322379f2962962a32df6b8df61f8ae37f8df6ae32388c91e3,0x5b8dc38c91e32232c20c38c81c30f81e32637eb8cbac30f81c30878c98c88dfadf7d628a8c8ae32e3243e038c80f8ae3,0x82083e232388c9e231f8083e232780f80e32038c91e3223082]
    decide +kernel
  have e33028 : Deny 5 13 b33028 := by
    apply closeAction rule_sound _ _ 64 [0xae32e37ab8cb8deae32e37ab8cb8deae32e37ab8cb7b8df6d478deae32e37ab8cb8deae32e37ab8cb8deae32eb8c91eb,0x8c826b0c22422368c88deae32e37ab8cb8deae32e37ab8cb8deae32e37ab8cb8deae32e37ab8cb8deae32e37ab8cb8de,0x8c9e030f88c9ac3e2b8c22788c88deac30f8ae326322b8cb7ab8deae32f88c91e322379f2ab8cb0820c98c80c38c9ac3,0x8cb8deae32e37ab8cb8deae32e37ab8cb8deae32e37ab8cb8deae32e37ab8cb1eb0820f88c9e378c8e230f8ac3e23238,0x2e37ab8cb8deae32e37ab8cb8deae32e37ab8cb8deae32e37ab8cb8deae32e37ab8cb8deae32e37ab8cb8deae32e37ab,0xac98de2deacb7ab2e37ab2deacb8deacb7ab2e37ab2e37ab8cb7ab2e37ab8cb8deae32deacb8deae32e37ab8cb8deae3,0x7ab8cb8deae32e37ab8cb8deae32e37ab8cb8deae32e37ab8cb8c7e23238ae32780820c38c98c86830c8ac308821e2ca,0x8c82637ab8cb8deae32e37ab8cb8deae32e37ab8cb8deae32e37ab8cb8deae32e37ab8cb8deae32e37ab8cb8deae32e3,0x820820e3203ac3]
    decide +kernel
  have e32938 : Deny 5 13 b32938 :=
    branchAction rule_sound _ _ 2
      0x223 b32938 b32939 b33028 (by decide +kernel) e32939 e33028
  have e32928 : Deny 5 13 b32928 :=
    branchAction rule_sound _ _ 1
      0xb b32928 b32929 b32938 (by decide +kernel) e32929 e32938
  have e32794 : Deny 5 13 b32794 :=
    branchAction rule_sound _ _ 2
      0x263 b32794 b32795 b32928 (by decide +kernel) e32795 e32928
  have e33267 : Deny 5 13 b33267 := by
    apply closeAction rule_sound _ _ 64 [0x6ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32eb8c88c2688e2b8cbae326b,0x2daae12daae12daaea84b6abaa12daaea84b48b48b48b48b48b48b84a8daae32e36ab8cb8daae32e36ab8cb8daae32e3,0x8daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cb1eb69aada083089087da11da2522d22d22c2aa884a84a21aae1,0x6ab8cb8c78daae32f8ae32631f8ae323808209aae326b8c808208226b6ab8c8d6b26b6ab8c81eb6ab8c8ae32636ab8cb,0x78b48b84a8de2e378b8de2e378b8de2e378b8de2e378b8de2e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32e3,0xc80abaa12d22d22d22d22e12822486ab84b6ab84b6ab84b6ab84b6ab84b6ab84b6ab84b6ab84b6ab84b6ab84b78b78b,0x8208269aada6ab]
    decide +kernel
  have e32793 : Deny 5 13 b32793 :=
    branchAction rule_sound _ _ 2
      0x223 b32793 b32794 b33267 (by decide +kernel) e32794 e33267
  have e32777 : Deny 5 13 b32777 :=
    branchAction rule_sound _ _ 2
      0x2e3 b32777 b32778 b32793 (by decide +kernel) e32778 e32793
  exact e32777
end OMA.Blocks5_13_245212.S32777
