import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S22896
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b22896 : Box := ![⟨23,46⟩,⟨15,30⟩,⟨7,1920000000000000011376⟩,⟨1,1680544217687074839929⟩,⟨119,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨23,46⟩,⟨15,30⟩,⟨7,1920000000000000011376⟩,⟨1,1680544217687074839929⟩,⟨119,999999999999999999⟩] := by
  have e22896 : Deny 5 13 b22896 := by
    apply closeAction rule_sound _ _ 64 [0xdfe378c77f8de321fe378c97f8df68c7088df68c4087e368c972f72f8c9df68c4087e37da3217e37db588a8c21f8da3,0x102238df688788a8c972f70972325f88a7ef88a50a7f8df68c98c872f7c21f8be326f7f8df68c9738df68c8da31e310b,0x29729fe37da223611f5c38842380e21d70f820988a5ca0c3e37da2203e37243e37da21e222210b0c3e37242e37da21e2,0x7f8de325fe37da3237d84087e37da325cbe31021f8df68c8db58c7da372f709bdfbe325429f7d70f8da2203e36887da2,0x72f709bdfbe325429fde30dfde325fdf68c710b]
    decide +kernel
  exact e22896
end OMA.Blocks5_13_245212.S22896
