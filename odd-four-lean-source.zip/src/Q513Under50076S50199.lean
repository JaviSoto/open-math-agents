import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S50199
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b50199 : Box := ![⟨170,190⟩,⟨23,24⟩,⟨31,41⟩,⟨1,53⟩,⟨1919,999999999999999999⟩]
private def b50200 : Box := ![⟨170,190⟩,⟨23,24⟩,⟨31,35⟩,⟨1,53⟩,⟨1919,999999999999999999⟩]
private def b50201 : Box := ![⟨170,179⟩,⟨23,24⟩,⟨31,35⟩,⟨2,51⟩,⟨1919,999999999999999999⟩]
private def b50202 : Box := ![⟨180,190⟩,⟨23,24⟩,⟨31,35⟩,⟨2,51⟩,⟨1919,999999999999999999⟩]
private def b50203 : Box := ![⟨180,190⟩,⟨23,23⟩,⟨31,35⟩,⟨2,51⟩,⟨1967,999999999999999999⟩]
private def b50204 : Box := ![⟨180,190⟩,⟨24,24⟩,⟨31,35⟩,⟨2,51⟩,⟨1967,999999999999999999⟩]
private def b50205 : Box := ![⟨170,190⟩,⟨23,24⟩,⟨36,41⟩,⟨1,53⟩,⟨1919,999999999999999999⟩]
private def b50206 : Box := ![⟨170,190⟩,⟨23,23⟩,⟨36,41⟩,⟨1,53⟩,⟨3387,999999999999999999⟩]
private def b50207 : Box := ![⟨170,179⟩,⟨23,23⟩,⟨36,41⟩,⟨1,49⟩,⟨3389,999999999999999999⟩]
private def b50208 : Box := ![⟨180,190⟩,⟨23,23⟩,⟨36,41⟩,⟨1,49⟩,⟨3389,999999999999999999⟩]
private def b50209 : Box := ![⟨170,190⟩,⟨24,24⟩,⟨36,41⟩,⟨1,53⟩,⟨3387,999999999999999999⟩]
private theorem e50201 : Deny 5 13 b50201 := by
    apply closeAction rule_sound _ _ 64 [0xe3]
    decide +kernel
private theorem e50203 : Deny 5 13 b50203 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e50204 : Deny 5 13 b50204 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e50202 : Deny 5 13 b50202 :=
    branchAction rule_sound _ _ 2
      0x238 b50202 b50203 b50204 (by decide +kernel) e50203 e50204
private theorem e50200 : Deny 5 13 b50200 :=
    branchAction rule_sound _ _ 3
      0x79e3 b50200 b50201 b50202 (by decide +kernel) e50201 e50202
private theorem e50207 : Deny 5 13 b50207 := by
    apply closeAction rule_sound _ _ 64 [0x3e23]
    decide +kernel
private theorem e50208 : Deny 5 13 b50208 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e50206 : Deny 5 13 b50206 :=
    branchAction rule_sound _ _ 3
      0x7e23 b50206 b50207 b50208 (by decide +kernel) e50207 e50208
private theorem e50209 : Deny 5 13 b50209 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e50205 : Deny 5 13 b50205 :=
    branchAction rule_sound _ _ 2
      0x238 b50205 b50206 b50209 (by decide +kernel) e50206 e50209
private theorem e50199 : Deny 5 13 b50199 :=
    branchAction rule_sound _ _ 1
      0x9 b50199 b50200 b50205 (by decide +kernel) e50200 e50205
theorem deny5_13 : Deny 5 13 ![⟨170,190⟩,⟨23,24⟩,⟨31,41⟩,⟨1,53⟩,⟨1919,999999999999999999⟩] := by
  exact e50199
end OMA.Blocks5_13_245212.S50199
