import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S27567
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b27567 : Box := ![⟨31,37⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨1,565934718100890211109⟩,⟨239,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨31,37⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨1,565934718100890211109⟩,⟨239,999999999999999999⟩] := by
  have e27567 : Deny 5 13 b27567 := by
    apply closeAction rule_sound _ _ 64 [0x8c77c21f8ae326b8c82d22ab7c30f8dc80f8de1242849087844088e2129fe37d632788dee37db58c7e368c88c284ae23,0xdf6d631eb087e36ae32368daadf69aac42eb7e321fe35ae326b8c78c47cb6ab11e6896897f8da1284087e36ae3108e2b,0x1aadf7c21f8]
    decide +kernel
  exact e27567
end OMA.Blocks5_13_245212.S27567
