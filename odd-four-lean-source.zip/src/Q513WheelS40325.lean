import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S40325
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b40325 : Box := ![⟨47,62⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨3,1017986577181208059759⟩,⟨127,164⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,62⟩,⟨21,30⟩,⟨31,1920000000000000011376⟩,⟨3,1017986577181208059759⟩,⟨127,164⟩] := by
  have e40325 : Deny 5 13 b40325 := by
    apply closeAction rule_sound _ _ 64 [0xc32432430f7da22221e22042c3088087d82237d840c38870c3e37277da21c30881021f8df688810be221e22a3263204,0x72325f88a7ef88a50a7c3dc32430c98870c3dc72430f8de21c3e37243e37da21f6888117e37883e370c7887dc3dc31c9,0x283da22037f8df68880f8dc9da21e22045f8dd7e370c7257e370c90e22030e22032621e22042e21ca8c909cbe3107e2f,0x9fbe21f77d7e375f8dd7e370e22221d7e370c70c82440970c827710b8887d70c388788888a5ca7c30e21e2297]
    decide +kernel
  exact e40325
end OMA.Blocks5_13_245212.S40325
