import FastReplay245212

/-! Four-prime exclusion on an initial range, by the checked finite trace. -/
namespace OMA.Box245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def words7_13 : List ℕ := [
0x21b6e31c68c71895d39428471a12559978871a22045d68871a210718a7dd74818875d8c71a31c62067de1c61c6089184,
0x1f6d395f8471a129f9df8c71a3]
theorem deny7_13 : Deny 7 13 ![⟨2,4704⟩,⟨1,4704⟩,⟨1,4704⟩,⟨1,4704⟩,⟨14,19⟩] := by
  apply OMA.FastReplay245212.certify _ _ 64 words7_13
  decide +kernel
end OMA.Box245212
