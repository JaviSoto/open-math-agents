import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S53872
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b53872 : Box := ![⟨63,94⟩,⟨31,62⟩,⟨7,9⟩,⟨1,53⟩,⟨239,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨31,62⟩,⟨7,9⟩,⟨1,53⟩,⟨239,999999999999999999⟩] := by
  have e53872 : Deny 5 13 b53872 := by
    apply closeAction rule_sound _ _ 64 [0xda32388db6d30c42380c74ca4c928a4ca0c3e378c76f8de32632042c3089087102238de31d32822788dbe37da3238d63,0x6db6d30f8203e0710b1132b810ae0a4ca6f8de325be37]
    decide +kernel
  exact e53872
end OMA.Blocks5_13_245212.S53872
