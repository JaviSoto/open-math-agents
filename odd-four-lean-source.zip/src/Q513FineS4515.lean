import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S4515
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b4515 : Box := ![⟨15,22⟩,⟨15,1920000000000000011376⟩,⟨5,1920000000000000011376⟩,⟨1,2⟩,⟨29,47⟩]
theorem deny5_13 : Deny 5 13 ![⟨15,22⟩,⟨15,1920000000000000011376⟩,⟨5,1920000000000000011376⟩,⟨1,2⟩,⟨29,47⟩] := by
  have e4515 : Deny 5 13 b4515 := by
    apply closeAction rule_sound _ _ 64 [0x5838880f8243e368888870f6102238db588a0c3e36203e352421f7243087088087df688810b102e37db58841f8da2222,0x1c22021f6d6127788888710b0c3e212611021f8df68490c3da22021c22021f7db51020e2107e03e031c90c38870c9888,0xd62236d621c40aa5aa8885820e1278083107e032480f80c80c80e12611c35c9087088087da12a1262216a96aa22160c2,0x5aa5aa8885830f8203e080f8db58470f8db58491021f8de1262216a96aa222a5b8df6]
    decide +kernel
  exact e4515
end OMA.Blocks5_13_245212.S4515
