import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S50079
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b50079 : Box := ![⟨127,152⟩,⟨23,24⟩,⟨31,41⟩,⟨1,53⟩,⟨959,1918⟩]
private def b50080 : Box := ![⟨127,152⟩,⟨23,24⟩,⟨31,41⟩,⟨1,2⟩,⟨959,1918⟩]
private def b50081 : Box := ![⟨127,152⟩,⟨23,24⟩,⟨31,41⟩,⟨3,48⟩,⟨959,1918⟩]
private def b50082 : Box := ![⟨127,138⟩,⟨23,24⟩,⟨31,41⟩,⟨3,48⟩,⟨959,1918⟩]
private def b50083 : Box := ![⟨127,138⟩,⟨23,24⟩,⟨31,35⟩,⟨3,45⟩,⟨959,1918⟩]
private def b50084 : Box := ![⟨127,138⟩,⟨23,23⟩,⟨31,35⟩,⟨3,43⟩,⟨959,1918⟩]
private def b50085 : Box := ![⟨127,138⟩,⟨24,24⟩,⟨31,35⟩,⟨3,43⟩,⟨959,1918⟩]
private def b50086 : Box := ![⟨127,138⟩,⟨23,24⟩,⟨36,41⟩,⟨3,45⟩,⟨959,1918⟩]
private def b50087 : Box := ![⟨127,138⟩,⟨23,23⟩,⟨36,41⟩,⟨3,45⟩,⟨959,1918⟩]
private def b50088 : Box := ![⟨127,138⟩,⟨24,24⟩,⟨36,41⟩,⟨3,45⟩,⟨959,1918⟩]
private def b50089 : Box := ![⟨139,152⟩,⟨23,24⟩,⟨31,41⟩,⟨3,48⟩,⟨959,1918⟩]
private def b50090 : Box := ![⟨139,152⟩,⟨23,24⟩,⟨31,35⟩,⟨3,48⟩,⟨959,1918⟩]
private def b50091 : Box := ![⟨139,152⟩,⟨23,23⟩,⟨31,35⟩,⟨3,45⟩,⟨959,1918⟩]
private def b50092 : Box := ![⟨139,152⟩,⟨24,24⟩,⟨31,35⟩,⟨3,45⟩,⟨959,1918⟩]
private def b50093 : Box := ![⟨139,152⟩,⟨23,24⟩,⟨36,41⟩,⟨3,48⟩,⟨959,1918⟩]
private def b50094 : Box := ![⟨139,152⟩,⟨23,23⟩,⟨36,41⟩,⟨3,48⟩,⟨959,1918⟩]
private def b50095 : Box := ![⟨139,152⟩,⟨24,24⟩,⟨36,41⟩,⟨3,48⟩,⟨959,1918⟩]
private theorem e50080 : Deny 5 13 b50080 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
private theorem e50084 : Deny 5 13 b50084 := by
    apply closeAction rule_sound _ _ 64 [0x3e37]
    decide +kernel
private theorem e50085 : Deny 5 13 b50085 := by
    apply closeAction rule_sound _ _ 64 [0x3]
    decide +kernel
private theorem e50083 : Deny 5 13 b50083 :=
    branchAction rule_sound _ _ 2
      0x223 b50083 b50084 b50085 (by decide +kernel) e50084 e50085
private theorem e50087 : Deny 5 13 b50087 := by
    apply closeAction rule_sound _ _ 64 [0xf8]
    decide +kernel
private theorem e50088 : Deny 5 13 b50088 := by
    apply closeAction rule_sound _ _ 64 [0xf8]
    decide +kernel
private theorem e50086 : Deny 5 13 b50086 :=
    branchAction rule_sound _ _ 1
      0x8 b50086 b50087 b50088 (by decide +kernel) e50087 e50088
private theorem e50082 : Deny 5 13 b50082 :=
    branchAction rule_sound _ _ 2
      0x263 b50082 b50083 b50086 (by decide +kernel) e50083 e50086
private theorem e50091 : Deny 5 13 b50091 := by
    apply closeAction rule_sound _ _ 64 [0xf8]
    decide +kernel
private theorem e50092 : Deny 5 13 b50092 := by
    apply closeAction rule_sound _ _ 64 [0xf8]
    decide +kernel
private theorem e50090 : Deny 5 13 b50090 :=
    branchAction rule_sound _ _ 2
      0x223 b50090 b50091 b50092 (by decide +kernel) e50091 e50092
private theorem e50094 : Deny 5 13 b50094 := by
    apply closeAction rule_sound _ _ 64 [0xe3]
    decide +kernel
private theorem e50095 : Deny 5 13 b50095 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e50093 : Deny 5 13 b50093 :=
    branchAction rule_sound _ _ 1
      0x8 b50093 b50094 b50095 (by decide +kernel) e50094 e50095
private theorem e50089 : Deny 5 13 b50089 :=
    branchAction rule_sound _ _ 1
      0x9 b50089 b50090 b50093 (by decide +kernel) e50090 e50093
private theorem e50081 : Deny 5 13 b50081 :=
    branchAction rule_sound _ _ 1
      0x7 b50081 b50082 b50089 (by decide +kernel) e50082 e50089
private theorem e50079 : Deny 5 13 b50079 :=
    branchAction rule_sound _ _ 2
      0x2a3 b50079 b50080 b50081 (by decide +kernel) e50080 e50081
theorem deny5_13 : Deny 5 13 ![⟨127,152⟩,⟨23,24⟩,⟨31,41⟩,⟨1,53⟩,⟨959,1918⟩] := by
  exact e50079
end OMA.Blocks5_13_245212.S50079
