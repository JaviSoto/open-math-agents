import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S4651
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b4651 : Box := ![⟨11,22⟩,⟨7,14⟩,⟨3,1920000000000000011376⟩,⟨1,1920000000000000011376⟩,⟨29,47⟩]
private def b4652 : Box := ![⟨11,22⟩,⟨7,14⟩,⟨3,6⟩,⟨1,1369661835748792278678⟩,⟨29,47⟩]
private def b4659 : Box := ![⟨11,22⟩,⟨7,14⟩,⟨7,1920000000000000011376⟩,⟨1,1369661835748792278678⟩,⟨29,47⟩]
private def b4660 : Box := ![⟨11,14⟩,⟨7,14⟩,⟨7,1920000000000000011376⟩,⟨1,1369661835748792278678⟩,⟨29,47⟩]
private def b4755 : Box := ![⟨15,22⟩,⟨7,14⟩,⟨7,1920000000000000011376⟩,⟨1,1369661835748792278678⟩,⟨29,47⟩]
private def b4756 : Box := ![⟨15,22⟩,⟨7,14⟩,⟨7,1920000000000000011376⟩,⟨1,2⟩,⟨29,47⟩]
private def b4793 : Box := ![⟨15,22⟩,⟨7,14⟩,⟨7,1920000000000000011376⟩,⟨3,1369661835748792278678⟩,⟨29,47⟩]
private def b4794 : Box := ![⟨15,22⟩,⟨7,9⟩,⟨7,1920000000000000011376⟩,⟨3,1369661835748792278678⟩,⟨29,47⟩]
private def b4929 : Box := ![⟨15,22⟩,⟨10,14⟩,⟨7,1920000000000000011376⟩,⟨3,1369661835748792278678⟩,⟨29,47⟩]
theorem deny5_11 : Deny 5 11 ![⟨11,22⟩,⟨7,14⟩,⟨3,1920000000000000011376⟩,⟨1,1920000000000000011376⟩,⟨29,47⟩] := by
  have e4652 : Deny 5 11 b4652 := by
    apply closeAction rule_sound _ _ 64 [0xc3e378c90f8df68c80a31f8de3]
    decide +kernel
  have e4660 : Deny 5 11 b4660 := by
    apply closeAction rule_sound _ _ 64 [0x2021f788a0c3e37d87de32442dcbdc25c8c90e229cbc4709e37da31c3e37be2283e37da3244738df68c4238df68c8de3,0xbe2703be22af888dc30e32232420c4278ddc72f88abc38c91dcbdc25c8c90f888a8c80ef88a0c3e37da32232631c30a2,0xbc30f8dc78c92dcbdcbe326f738df68c9e37da32038c4088e368c972f11cdf6d6f8c4278df61f60f8df6d622b7da3102,0x1cbdcbe3243102238da324288a8c472f72f8c9]
    decide +kernel
  have e4756 : Deny 5 11 b4756 := by
    apply closeAction rule_sound _ _ 64 [0xe37da2202e37db5887d840e20c9dc38870c3de21e22030f7d882430c9d83e36888df688710b0c2236884087e37da2222,0x30c90f8de21c3e37243]
    decide +kernel
  have e4794 : Deny 5 11 b4794 := by
    apply closeAction rule_sound _ _ 64 [0xc38870e2222282bdc0e22af8c90e325cc9c29c88a0f8be2283e37da326320308888a8c70c3df68c80f7da31e32442e3,0x72f10bbdc8c90f8be22838c4087e37da324288a102238df68c70c22021f8df68c9da31020831c9dc20ef887dc38c98c8,0xe3773270a7222888c70ef88a0c322324b72f703e222b88c90efb222a3103e37da3109e362030f8df6887884088e2229c,0xddc1e3109e1cbdc26f0dc1e326321cc9c29c88a738df68c88c70ef88a0dce37d888c98c40820f77078c98c423809c109,0x83]
    decide +kernel
  have e4929 : Deny 5 11 b4929 := by
    apply closeAction rule_sound _ _ 64 [0x203103e37da3108e378c78c98c40af882083887884238dc3e37883887dc32072770b8dc32770e32030e32231e326310b,0x8c4082be2108e37bdc0e22a325cc9c29c88a8c72c3e222a32030f88c70f88c88c90c3e090f8df688888a8c70c38c90e3,0x108e371038841f80c90c388888888a538def0f8dc38c78c972f72f8c9bc38c91e3102be20af0c92772dcbdcbe325c8c9,0x2083884278dc209c109e370e32632380e22a31e3108e020c4278de30e31f80f80e31e32232420e2]
    decide +kernel
  have e4793 : Deny 5 11 b4793 :=
    branchAction rule_sound _ _ 1
      0x8 b4793 b4794 b4929 (by decide +kernel) e4794 e4929
  have e4755 : Deny 5 11 b4755 :=
    branchAction rule_sound _ _ 1
      0xa b4755 b4756 b4793 (by decide +kernel) e4756 e4793
  have e4659 : Deny 5 11 b4659 :=
    branchAction rule_sound _ _ 1
      0x7 b4659 b4660 b4755 (by decide +kernel) e4660 e4755
  have e4651 : Deny 5 11 b4651 :=
    branchAction rule_sound _ _ 2
      0x263 b4651 b4652 b4659 (by decide +kernel) e4652 e4659
  exact e4651
end OMA.Blocks5_11_245212.S4651
