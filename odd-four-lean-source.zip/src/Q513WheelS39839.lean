import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S39839
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b39839 : Box := ![⟨47,62⟩,⟨21,30⟩,⟨15,30⟩,⟨3,50⟩,⟨127,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,62⟩,⟨21,30⟩,⟨15,30⟩,⟨3,50⟩,⟨127,233⟩] := by
  have e39839 : Deny 5 13 b39839 := by
    apply closeAction rule_sound _ _ 64 [0xc32430f724810b0c3e372447f8df6108e07243087088df61030c70dfe37d87dc80c22372442c3088e37d87d8810b2a3,0x7c20c8e03e031c32082972842df5c3e3620a5ca0c21f8df62047d70c80c3e090f8d8720a5ca10b1c30f8df6203df61c4,0xe37d8811f5c320320a5ca0c3e37243e37d872042c3087102238dc90c21c4088e37d87088d847d70c82972830c70c8204,0x1f7c30f8243e361ca5ca0c4087]
    decide +kernel
  exact e39839
end OMA.Blocks5_13_245212.S39839
