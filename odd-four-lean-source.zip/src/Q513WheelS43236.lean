import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S43236
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b43236 : Box := ![⟨95,1920000000000000011376⟩,⟨15,20⟩,⟨7,14⟩,⟨3,435973154362416109995⟩,⟨127,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,1920000000000000011376⟩,⟨15,20⟩,⟨7,14⟩,⟨3,435973154362416109995⟩,⟨127,233⟩] := by
  have e43236 : Deny 5 13 b43236 := by
    apply closeAction rule_sound _ _ 64 [0xf8df62231c42d99c31022788c70899c4087e232599c39c4088e231d9e379e32422271021f8da3238da31c29e69602a3,0xc3e20260283da0299e37da78081020c41f80e02030e02678099e010b80a9c3088df68c40e70e31c39d9e378c78c910b,0x199d99e31e76438040a0108e369e0299e37da7227678df68c78c4659]
    decide +kernel
  exact e43236
end OMA.Blocks5_13_245212.S43236
