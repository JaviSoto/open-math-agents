import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S5053
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b5053 : Box := ![⟨11,22⟩,⟨15,1920000000000000011376⟩,⟨3,6⟩,⟨1,1920000000000000011376⟩,⟨29,47⟩]
theorem deny5_11 : Deny 5 11 ![⟨11,22⟩,⟨15,1920000000000000011376⟩,⟨3,6⟩,⟨1,1920000000000000011376⟩,⟨29,47⟩] := by
  have e5053 : Deny 5 11 b5053 := by
    apply closeAction rule_sound _ _ 64 [0xdc26886a320384a8c76ab6886a320384a6ab6ab8c86b8df6d632078c910b0f8da1283103e37db5107e368c80a12a31e3,0xe37db584784a6ab6ab8c80eb103e23108e2321aada22b11ae37d6b8c4238d631daada22b6ab8c8087e358c98c4083847,0x1e32442c30e32038c70c3e378c80f8df6d631e32631020c8dc38c70c38c80e31e32442e32030f88470f8de1243e36203,0xf8de12612a321aadaae320311ae37d63109e23202ae12a31e32631020e11f7083849dc20612770f8dc3263203ae12a3,0xe03e370e11e12b72370ab8c46ab8c42380f80e326320384a8c76ab6ab8c8ac30e31c30878c98c40838c70c38c78c92c3,0x2ae10820e3207]
    decide +kernel
  exact e5053
end OMA.Blocks5_11_245212.S5053
