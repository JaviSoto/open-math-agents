import HeightLog245212
import HeightPeel245212
import OddAbundancy245212
import BoxKernel245212

/-! The ten integer boxes which suffice for the registered four-prime child. -/
namespace OMA.Box245212
open Finset OMA.Smooth245212 OMA.Height245212 OMA.OddFaces245212
open scoped ArithmeticFunction.sigma

theorem maxExponent {B : ℕ} (p e : Fin 4 → ℕ) (prime : ∀ i,(p i).Prime)
    (odd : ∀ i,3≤p i) (pos : ∀ i,0<e i) (inj : Function.Injective p) (bp : ∀ i,p i≤B)
    (sol : OeisA245212.a (total p e)=(σ 1 (total p e):ℤ)) (i : Fin 4) :
    e i ≤ OMA.HeightLog245212.ceiling 4 B := by
  have mem (j : Fin 4) : e j≤univ.sup e := le_sup (f:=e) (mem_univ j)
  exact (mem i).trans (OMA.HeightLog245212.four ((pos i).trans_le (mem i))
    (max_power p e prime odd pos inj bp sol))

def topR (p q : ℕ) :=
  let m := 4*(p-1)*(q-1)
  if 3*p*q < m then min 999999999999999999 (m/(m-3*p*q)) else 999999999999999999

def families : Finset (ℕ×ℕ) :=
  {(5,7),(5,11),(5,13),(5,17),(5,19),(5,23),(5,29),(5,31),(7,11),(7,13)}

def rootBox (p q : ℕ) : Box :=
  let r := topR p q
  let h := OMA.HeightLog245212.ceiling 4 r
  ![⟨2,h⟩,⟨1,h⟩,⟨1,h⟩,⟨1,h⟩,⟨q+1,r⟩]

private theorem ratio {p : ℕ} (hp : 1<p) : limitX p=(p:ℚ)/((p:ℚ)-1) := by
  have hh : (1:ℚ)<p := by exact_mod_cast hp
  simp only [limitX,X,Y,sub_zero]; field_simp [sub_ne_zero.mpr hh.ne']; ring

theorem cap_integer {p q : ℕ} {v : Values} (c : Candidate p q v) :
    4*(p-1)*(q-1)*(v 4-1)≤3*p*q*v 4 := by
  have gd (i) := (c.prime i).one_lt
  have h := cap_needed _ _ gd 0 (c.pos 0) c.score
  simp only [Fin.prod_univ_four,bases,Matrix.cons_val_zero,
    Matrix.cons_val_one,Matrix.cons_val_two,Matrix.cons_val_three] at h
  have hp : 1<p := gd 1
  have hq : 1<q := gd 2
  have hr : 1<v 4 := gd 3
  have pp : (1:ℚ)<p := by exact_mod_cast hp
  have pq : (1:ℚ)<q := by exact_mod_cast hq
  have pr : (1:ℚ)<v 4 := by exact_mod_cast hr
  change 2≤limitX 3*limitX p*limitX q*limitX (v 4) at h
  rw [ratio (by decide : 1<3),ratio hp,ratio hq,ratio hr] at h
  norm_num at h
  field_simp at h
  have hd : 0<((p:ℚ)-1)*((q:ℚ)-1)*((v 4:ℚ)-1) :=
    mul_pos (mul_pos (by linarith) (by linarith)) (by linarith)
  have hh := (le_div_iff₀ hd).mp h
  rw [←Nat.cast_le (α:=ℚ)]
  push_cast [Nat.cast_sub hp.le,Nat.cast_sub hq.le,Nat.cast_sub hr.le]
  linarith only [hh]

theorem last_bound {p q : ℕ} {v : Values} (c : Candidate p q v) (cut : v 4≤999999999999999999) :
    v 4≤topR p q := by
  dsimp only [topR]
  split_ifs with lt
  · refine le_min cut ((Nat.le_div_iff_mul_le (Nat.sub_pos_of_lt lt)).mpr ?_)
    let m := 4*(p-1)*(q-1)
    let a := 3*p*q
    have al : a ≤ m := lt.le
    have r1 : 1≤v 4 := (c.prime 3).pos
    have hh := cap_integer c
    change m*(v 4-1)≤a*v 4 at hh
    have prod1 := congrArg (fun x:ℕ=>m*x) (Nat.sub_add_cancel r1)
    have prod2 := congrArg (fun x:ℕ=>x*(v 4)) (Nat.sub_add_cancel al)
    change v 4*(m-a) ≤ m
    nlinarith only [hh,prod1,prod2]
  · exact cut

theorem family_cover : ∀ p∈({5,7}:Finset ℕ), ∀ q∈Icc (p+1) 31,
    q.Prime → q<topR p q → (p,q)∈families := by decide +kernel

theorem exclude_bounded
    (proofs : ∀ pq∈families,Deny pq.1 pq.2 (rootBox pq.1 pq.2)) :
    ∀ p∈({5,7}:Finset ℕ), ∀ q∈Icc (p+1) 31, ∀ r∈Icc (q+1) 999999999999999999,
    q.Prime → r.Prime → ∀ k e f g : ℕ, 2≤k → 0<e → 0<f → 0<g →
    let n := 3^k*p^e*q^f*r^g
    OeisA245212.a n ≠ (σ 1 n : ℤ) := by
  intro p ps q qs r rs hq hr k e f g hk he hf hg n sol
  let v : Values := ![k,e,f,g,r]
  have hp : p.Prime := by simp only [mem_insert,mem_singleton] at ps; rcases ps with rfl|rfl <;> decide
  have pp : 3<p := by simp only [mem_insert,mem_singleton] at ps; omega
  obtain ⟨pq,qmax⟩ := mem_Icc.mp qs
  obtain ⟨qr,rmax⟩ := mem_Icc.mp rs
  have c : Candidate p q v := by
    constructor
    · intro i; fin_cases i <;> simp [bases,v,hp,hq,hr,Nat.prime_three]
    · apply Fin.strictMono_iff_lt_succ.mpr
      intro i; fin_cases i <;> simp [bases,v] <;> omega
    · intro i; fin_cases i <;> simp [exponents,v] <;> omega
    · exact hk
    · simpa [total,bases,exponents,v,Fin.prod_univ_four,n] using sol
  have rb : r≤topR p q := last_bound (v:=v) c rmax
  have mem := family_cover p ps q qs hq (by omega)
  have exp (i : Fin 4) : exponents v i ≤ OMA.HeightLog245212.ceiling 4 (topR p q) :=
    maxExponent _ _ c.prime (fun i=>c.ordered.monotone (Fin.zero_le i)) c.pos c.ordered.injective
      (fun i=>(c.ordered.monotone (Fin.le_last i)).trans rb) c.eqn i
  apply proofs (p,q) mem v _ c
  intro i; fin_cases i
  · exact ⟨hk,exp 0⟩
  · exact ⟨he,exp 1⟩
  · exact ⟨hf,exp 2⟩
  · exact ⟨hg,exp 3⟩
  · exact ⟨qr,rb⟩

end OMA.Box245212
