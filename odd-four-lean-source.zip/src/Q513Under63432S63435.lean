import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S63435
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b63435 : Box := ![⟨153,190⟩,⟨36,38⟩,⟨12,12⟩,⟨8,47⟩,⟨959,1918⟩]
private def b63436 : Box := ![⟨153,169⟩,⟨36,38⟩,⟨12,12⟩,⟨9,46⟩,⟨959,1918⟩]
private def b63437 : Box := ![⟨170,190⟩,⟨36,38⟩,⟨12,12⟩,⟨9,46⟩,⟨959,1918⟩]
private theorem e63436 : Deny 5 13 b63436 := by
    apply closeAction rule_sound _ _ 64 [0xe3]
    decide +kernel
private theorem e63437 : Deny 5 13 b63437 := by
    apply closeAction rule_sound _ _ 64 [0x3e27]
    decide +kernel
private theorem e63435 : Deny 5 13 b63435 :=
    branchAction rule_sound _ _ 3
      0x79e3 b63435 b63436 b63437 (by decide +kernel) e63436 e63437
theorem deny5_13 : Deny 5 13 ![⟨153,190⟩,⟨36,38⟩,⟨12,12⟩,⟨8,47⟩,⟨959,1918⟩] := by
  exact e63435
end OMA.Blocks5_13_245212.S63435
