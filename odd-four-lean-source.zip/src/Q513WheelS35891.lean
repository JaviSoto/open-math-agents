import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S35891
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b35891 : Box := ![⟨47,62⟩,⟨21,30⟩,⟨7,14⟩,⟨3,46⟩,⟨79,113⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,62⟩,⟨21,30⟩,⟨7,14⟩,⟨3,46⟩,⟨79,113⟩] := by
  have e35891 : Deny 5 13 b35891 := by
    apply closeAction rule_sound _ _ 64 [0x20324729f0c38c78c90c32030f8dc91ca8c810b0c3e378c8088df68c40c3de3203e378c90c3e37da32378c810be23263,0xc38c88c90c32030f8dc824a0c3de3203e378c98c70c3e37da321fe37da31f78c88c47c30e3223243e370c80c32090c3,0x1f]
    decide +kernel
  exact e35891
end OMA.Blocks5_13_245212.S35891
