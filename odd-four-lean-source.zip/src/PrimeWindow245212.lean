import DigitBox245212

/-! Tightening the last prime after the four exponents have been cut.
    The fractional-linear top-digit expressions attain their extrema
    at one of the two endpoints of the exponent interval. -/
namespace OMA.DigitBox245212
open OMA.Box245212 OMA.Moving245212

private theorem extreme (x y z k : ℚ) {E : Range} {d : ℕ} (fit : E.has d) :
    let F (a : ℕ) := z*den x y a+k*num x y a
    F d≤F E.lo ∨ F d≤F E.hi := by
  have dl : (E.lo:ℚ)≤d := by exact_mod_cast fit.1
  have dh : (d:ℚ)≤E.hi := by exact_mod_cast fit.2
  by_cases sign : 0≤z*(2-x)+k*x
  · right; unfold den num
    nlinarith only [mul_nonneg (sub_nonneg.mpr dh) sign]
  · left; unfold den num
    nlinarith only [mul_nonneg (sub_nonneg.mpr dl) (neg_nonneg.mpr (le_of_not_ge sign))]

private def ceilQ (x y : ℚ) (d : ℕ) := ⌈num x y d/den x y d⌉₊

private def lowPrime (x y : ℚ) (E R : Range) : Range :=
  if den x y E.lo≤0 ∧ den x y E.hi≤0 then ⟨1,0⟩
  else if 0<den x y E.lo ∧ 0<den x y E.hi then
    ⟨max R.lo (min (ceilQ x y E.lo) (ceilQ x y E.hi)),R.hi⟩ else R

private def highPrime (x y : ℚ) (E R : Range) : Range :=
  if 0<den x y E.lo ∧ 0<den x y E.hi then
    ⟨R.lo,min R.hi (max (ceilQ x y E.lo) (ceilQ x y E.hi))⟩ else R

private theorem low_ok {x y : ℚ} {E R : Range} {d r : ℕ} (ed : E.has d) (rr : R.has r)
    (pos : 0<den x y d) (low : num x y d≤r*den x y d) : (lowPrime x y E R).has r := by
  unfold lowPrime
  split_ifs with neg both
  · have ex := extreme x y 1 0 ed
    simp only [one_mul,zero_mul,add_zero] at ex
    rcases ex with e|e <;> linarith [neg.1,neg.2]
  · refine ⟨max_le rr.1 ?_,rr.2⟩
    have one (s : ℕ) (ps : 0<den x y s) (e : r*den x y d + (-1)*num x y d≤r*den x y s+(-1)*num x y s) :
        ceilQ x y s≤r := by
      apply Nat.ceil_le.mpr
      apply (div_le_iff₀ ps).mpr
      linarith only [low,e]
    rcases extreme x y r (-1) ed with e|e
    · exact (min_le_left ..).trans (one _ both.1 e)
    · exact (min_le_right ..).trans (one _ both.2 e)
  · exact rr

private theorem high_ok {x y : ℚ} {E R : Range} {d r : ℕ} (rp : 0<r) (ed : E.has d) (rr : R.has r)
    (up : ((r:ℚ)-1)*den x y d<num x y d) : (highPrime x y E R).has r := by
  unfold highPrime
  split_ifs with both
  · refine ⟨rr.1,le_min rr.2 ?_⟩
    have one (s : ℕ) (ps : 0<den x y s)
        (e : (1-(r:ℚ))*den x y d+1*num x y d≤(1-r)*den x y s+1*num x y s) :
        r≤ceilQ x y s := by
      have lt : ((r-1:ℕ):ℚ)<num x y s/den x y s := by
        rw [Nat.cast_sub rp,Nat.cast_one,lt_div_iff₀ ps]
        linarith only [up,e]
      have h := Nat.lt_ceil.mpr lt
      change r≤⌈num x y s/den x y s⌉₊
      omega
    rcases extreme x y (1-r) 1 ed with e|e
    · exact (one _ both.1 e).trans (le_max_left ..)
    · exact (one _ both.2 e).trans (le_max_right ..)
  · exact rr

/-- Cofactor bounds come from the original box, as in the reference
    computation. The mask returned by digit supplies the new exponents. -/
def primeWindow (p q : ℕ) (original rounded : Box245212.Box) : Option Box245212.Box :=
  let E := rounded 3
  let R := lowPrime (co xl p q original 3) (co yl p q original 3) E (rounded 4)
  let R := highPrime (co xu p q original 3) (co yu p q original 3) E R
  if R.lo≤R.hi then some (clip rounded 4 R) else none

theorem primeWindow_sound {p q : ℕ} {v : Values} {b b' : Box245212.Box}
    (c : Candidate p q v) (fit : Fits b v) (newFit : Fits b' v) (start : ∀ i,1<(baseBox p q b i).lo) :
    ∃ out,primeWindow p q b b'=some out ∧ Fits out v := by
  have hr : Nat.Prime (v 4) := c.prime 3
  have ⟨one,lo,hi⟩ := facts c fit start 3 (v 4) (v 4) hr.pos (by rfl) (by rfl)
  change 0<den _ _ (v 3) at one
  change num _ _ (v 3)≤_*den _ _ (v 3) at lo
  change _*den _ _ (v 3)<num _ _ (v 3) at hi
  have R1 := low_ok (newFit 3) (newFit 4) one lo
  have R2 := high_ok hr.pos (newFit 3) R1 hi
  exact ⟨_,if_pos (R2.1.trans R2.2),clip_fits newFit R2⟩

end OMA.DigitBox245212
