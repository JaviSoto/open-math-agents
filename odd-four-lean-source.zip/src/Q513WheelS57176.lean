import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S57176
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b57176 : Box := ![⟨47,62⟩,⟨31,62⟩,⟨15,30⟩,⟨1,54⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,62⟩,⟨31,62⟩,⟨15,30⟩,⟨1,54⟩,⟨479,999999999999999999⟩] := by
  have e57176 : Deny 5 13 b57176 := by
    apply closeAction rule_sound _ _ 64 [0xdf61f8d9f5c3257e070c3e37243e37d88e021f824a2f80f8088087e362382972b88dfe37db58c7e2325f5cae37da3223,0x7d7e365cbe362b82b88d72b88c88df7d728a5ca8cb7df7cb5cae0ae235cae231df7c3e03e07e03e085cae0ae1fe37278,0xc70c3e078c88df7d728a5ca8cb0c3e231c3e232232430f88c90f8df68c88df7d728a5ca8cb0f88c3e378c7e232631df,0x838c9]
    decide +kernel
  exact e57176
end OMA.Blocks5_13_245212.S57176
