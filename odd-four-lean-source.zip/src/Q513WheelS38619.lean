import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S38619
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b38619 : Box := ![⟨47,94⟩,⟨15,30⟩,⟨7,14⟩,⟨1,1031836734693877557186⟩,⟨119,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,94⟩,⟨15,30⟩,⟨7,14⟩,⟨1,1031836734693877557186⟩,⟨119,999999999999999999⟩] := by
  have e38619 : Deny 5 13 b38619 := by
    apply closeAction rule_sound _ _ 64 [0x1c2237102278de32430f8de325fe37da321fe37da31f78c4084238df68c7e230c22021c2237db58c4087e37db48c8e23,0xc40f8df68c4238de325f7c2278de3109e37da31e32170f8df68095f8df61c220a10b0c3e378c70c21f8de3203e37da3,0x1f78c88c40f8dc38c70c38c78c80c31c30f8dc720a10b8c90c38c80e3243103e378c4238de32631c30f8de3203e378c9,0x244df68c4238df68c77f8df68c8de3103dc38c70c38c78c88c409f0e3263203e370c7dc30c720a10b0c3de31c30f8de3,0x8c97f8df68c77f8df68c8df68c40c38c70c3e378c78c80c3e070c4087e3621728a0c3e378c7102238de32442c30f8de3,0xc3e37]
    decide +kernel
  exact e38619
end OMA.Blocks5_13_245212.S38619
