import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S39742
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b39742 : Box := ![⟨63,94⟩,⟨18,20⟩,⟨63,1920000000000000011376⟩,⟨3,963047619047619053363⟩,⟨167,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨18,20⟩,⟨63,1920000000000000011376⟩,⟨3,963047619047619053363⟩,⟨167,233⟩] := by
  have e39742 : Deny 5 13 b39742 := by
    apply closeAction rule_sound _ _ 64 [0xdc8778def8c78c9738df68c88c98c472f709bdd0f80e2203778def888e2f8877428842b8def88888a8c910b8c756c88a,0x107e082a3263263102bdd095e37083888887887e15e371038841f80c3e221e21e22222a32442dcbdc26f76f0c3e07778,0xbdcbe326f76f742578dc3887108e03dc3e37da22030888871020c80f8dc32221e210b8870f8bc3e090f888711de37da2,0x1c]
    decide +kernel
  exact e39742
end OMA.Blocks5_13_245212.S39742
