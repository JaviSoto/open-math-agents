import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S1351
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b1351 : Box := ![⟨11,22⟩,⟨7,1920000000000000011376⟩,⟨1,2⟩,⟨1,1920000000000000011376⟩,⟨17,23⟩]
theorem deny5_13 : Deny 5 13 ![⟨11,22⟩,⟨7,1920000000000000011376⟩,⟨1,2⟩,⟨1,1920000000000000011376⟩,⟨17,23⟩] := by
  have e1351 : Deny 5 13 b1351 := by
    apply closeAction rule_sound _ _ 64 [0xab6ab8c80e321ac5a2b16a129ae37d612a31c3e2b84a0f8df58c81358c42788c70c21e1087e37da1283e37db58c8de3,0xe110ae370eb8c78c86ab6ab8c80c3e378c78c86ab6ab8c8ac46b7d63108e358c70f8de12a32430e31c3e37d6326320b,0x20ab847deb68384a8c86ab6ab8c8d631c3087d632350f7d612b6d63112e37ac2]
    decide +kernel
  exact e1351
end OMA.Blocks5_13_245212.S1351
