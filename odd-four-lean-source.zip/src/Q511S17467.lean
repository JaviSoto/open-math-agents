import FastReplay245212
import SparseDigit245212
import FastRound245212
import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S17467
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b17467 : Box := ![⟨95,1920000000000000011376⟩,⟨7,9⟩,⟨15,1920000000000000011376⟩,⟨1,1450666666666666675295⟩,⟨103,206⟩]
private def b17468 : Box := ![⟨95,1920000000000000011376⟩,⟨7,7⟩,⟨15,1920000000000000011376⟩,⟨1,1450666666666666675287⟩,⟨103,199⟩]
private def b17469 : Box := ![⟨95,1920000000000000011376⟩,⟨7,7⟩,⟨15,30⟩,⟨1,1450666666666666675287⟩,⟨103,199⟩]
private def b17470 : Box := ![⟨95,1920000000000000011376⟩,⟨7,7⟩,⟨15,30⟩,⟨1,2⟩,⟨103,199⟩]
private def b17471 : Box := ![⟨95,1920000000000000011376⟩,⟨7,7⟩,⟨15,30⟩,⟨3,455859649122807020275⟩,⟨103,199⟩]
private def b17472 : Box := ![⟨95,1920000000000000011376⟩,⟨7,7⟩,⟨15,30⟩,⟨3,6⟩,⟨103,199⟩]
private def b17473 : Box := ![⟨95,1920000000000000011376⟩,⟨7,7⟩,⟨15,30⟩,⟨7,455859649122807020275⟩,⟨103,199⟩]
private def b17474 : Box := ![⟨95,190⟩,⟨7,7⟩,⟨15,30⟩,⟨7,455859649122807020275⟩,⟨103,199⟩]
private def b17489 : Box := ![⟨191,1920000000000000011376⟩,⟨7,7⟩,⟨15,30⟩,⟨7,455859649122807020275⟩,⟨103,199⟩]
private def b17494 : Box := ![⟨95,1920000000000000011376⟩,⟨7,7⟩,⟨31,1920000000000000011376⟩,⟨1,1450666666666666675287⟩,⟨103,199⟩]
private def b17495 : Box := ![⟨95,190⟩,⟨7,7⟩,⟨31,1920000000000000011376⟩,⟨1,1450666666666666675287⟩,⟨103,199⟩]
private def b17496 : Box := ![⟨95,190⟩,⟨7,7⟩,⟨31,1920000000000000011376⟩,⟨1,2⟩,⟨103,199⟩]
private def b17497 : Box := ![⟨95,190⟩,⟨7,7⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655077⟩,⟨103,199⟩]
private def b17498 : Box := ![⟨95,190⟩,⟨7,7⟩,⟨31,1920000000000000011376⟩,⟨3,6⟩,⟨103,199⟩]
private def b17499 : Box := ![⟨95,190⟩,⟨7,7⟩,⟨31,1920000000000000011376⟩,⟨7,994807017543859655077⟩,⟨103,199⟩]
private def b17500 : Box := ![⟨95,190⟩,⟨7,7⟩,⟨31,1920000000000000011376⟩,⟨7,994807017543859655077⟩,⟨103,135⟩]
private def b17513 : Box := ![⟨95,190⟩,⟨7,7⟩,⟨31,1920000000000000011376⟩,⟨7,994807017543859655077⟩,⟨136,199⟩]
private def b17528 : Box := ![⟨191,1920000000000000011376⟩,⟨7,7⟩,⟨31,1920000000000000011376⟩,⟨1,1450666666666666675287⟩,⟨103,199⟩]
private def b17529 : Box := ![⟨191,1920000000000000011376⟩,⟨7,7⟩,⟨31,1920000000000000011376⟩,⟨1,2⟩,⟨103,199⟩]
private def b17530 : Box := ![⟨191,1920000000000000011376⟩,⟨7,7⟩,⟨31,1920000000000000011376⟩,⟨3,1450666666666666675287⟩,⟨103,199⟩]
private def b17531 : Box := ![⟨191,1920000000000000011376⟩,⟨7,7⟩,⟨31,1920000000000000011376⟩,⟨3,6⟩,⟨112,199⟩]
private def b17532 : Box := ![⟨191,1920000000000000011376⟩,⟨7,7⟩,⟨31,1920000000000000011376⟩,⟨7,1450666666666666675287⟩,⟨112,199⟩]
private def b17547 : Box := ![⟨95,1920000000000000011376⟩,⟨8,9⟩,⟨15,1920000000000000011376⟩,⟨1,1450666666666666675287⟩,⟨103,199⟩]
private def b17548 : Box := ![⟨95,1920000000000000011376⟩,⟨8,9⟩,⟨15,30⟩,⟨1,1450666666666666675287⟩,⟨103,199⟩]
private def b17549 : Box := ![⟨95,1920000000000000011376⟩,⟨8,9⟩,⟨15,30⟩,⟨1,2⟩,⟨103,199⟩]
private def b17550 : Box := ![⟨95,1920000000000000011376⟩,⟨8,9⟩,⟨15,30⟩,⟨3,455859649122807020276⟩,⟨103,199⟩]
private def b17551 : Box := ![⟨95,190⟩,⟨8,9⟩,⟨15,30⟩,⟨3,455859649122807020276⟩,⟨103,199⟩]
private def b17552 : Box := ![⟨95,190⟩,⟨8,9⟩,⟨15,30⟩,⟨3,67⟩,⟨103,135⟩]
private def b17553 : Box := ![⟨95,190⟩,⟨8,9⟩,⟨15,20⟩,⟨3,67⟩,⟨103,131⟩]
private def b17562 : Box := ![⟨95,190⟩,⟨8,9⟩,⟨21,30⟩,⟨3,67⟩,⟨103,131⟩]
private def b17569 : Box := ![⟨95,190⟩,⟨8,9⟩,⟨15,30⟩,⟨3,67⟩,⟨136,199⟩]
private def b17570 : Box := ![⟨95,190⟩,⟨8,9⟩,⟨15,20⟩,⟨3,63⟩,⟨137,199⟩]
private def b17585 : Box := ![⟨95,190⟩,⟨8,9⟩,⟨21,30⟩,⟨3,63⟩,⟨137,199⟩]
private def b17586 : Box := ![⟨95,126⟩,⟨8,9⟩,⟨21,30⟩,⟨3,63⟩,⟨137,199⟩]
private def b17587 : Box := ![⟨95,126⟩,⟨8,8⟩,⟨21,30⟩,⟨3,48⟩,⟨137,199⟩]
private def b17588 : Box := ![⟨95,126⟩,⟨8,8⟩,⟨21,30⟩,⟨3,48⟩,⟨137,162⟩]
private def b17603 : Box := ![⟨95,126⟩,⟨8,8⟩,⟨21,30⟩,⟨3,48⟩,⟨163,199⟩]
private def b17614 : Box := ![⟨95,126⟩,⟨9,9⟩,⟨21,30⟩,⟨3,48⟩,⟨137,199⟩]
private def b17617 : Box := ![⟨127,190⟩,⟨8,9⟩,⟨21,30⟩,⟨3,63⟩,⟨137,199⟩]
private def b17618 : Box := ![⟨191,1920000000000000011376⟩,⟨8,9⟩,⟨15,30⟩,⟨3,455859649122807020276⟩,⟨103,199⟩]
private def b17623 : Box := ![⟨95,1920000000000000011376⟩,⟨8,9⟩,⟨31,1920000000000000011376⟩,⟨1,1450666666666666675287⟩,⟨103,199⟩]
private def b17624 : Box := ![⟨95,1920000000000000011376⟩,⟨8,9⟩,⟨31,62⟩,⟨1,1450666666666666675287⟩,⟨103,199⟩]
private def b17625 : Box := ![⟨95,190⟩,⟨8,9⟩,⟨31,62⟩,⟨1,455859649122807020293⟩,⟨103,199⟩]
private def b17626 : Box := ![⟨95,190⟩,⟨8,9⟩,⟨31,62⟩,⟨1,2⟩,⟨103,199⟩]
private def b17627 : Box := ![⟨95,190⟩,⟨8,9⟩,⟨31,62⟩,⟨3,84⟩,⟨103,199⟩]
private def b17642 : Box := ![⟨191,1920000000000000011376⟩,⟨8,9⟩,⟨31,62⟩,⟨1,455859649122807020293⟩,⟨103,199⟩]
private def b17643 : Box := ![⟨95,1920000000000000011376⟩,⟨8,9⟩,⟨63,1920000000000000011376⟩,⟨1,1450666666666666675287⟩,⟨103,199⟩]
theorem deny5_11 : Deny 5 11 ![⟨95,1920000000000000011376⟩,⟨7,9⟩,⟨15,1920000000000000011376⟩,⟨1,1450666666666666675295⟩,⟨103,206⟩] := by
  have e17470 : Deny 5 11 b17470 := by
    apply closeAction rule_sound _ _ 64 [0x60]
    decide +kernel
  have e17472 : Deny 5 11 b17472 := by
    apply closeAction rule_sound _ _ 64 [0x29a0]
    decide +kernel
  have e17474 : Deny 5 11 b17474 := by
    apply closeAction rule_sound _ _ 64 [0x767777da31030e325dde32442f88c711d6678c99c4087e23109e23]
    decide +kernel
  have e17489 : Deny 5 11 b17489 := by
    apply closeAction rule_sound _ _ 64 [0x199d96672f89e31e7]
    decide +kernel
  have e17473 : Deny 5 11 b17473 :=
    branchAction rule_sound _ _ 1
      0x7 b17473 b17474 b17489 (by decide +kernel) e17474 e17489
  have e17471 : Deny 5 11 b17471 :=
    branchAction rule_sound _ _ 1
      0xa b17471 b17472 b17473 (by decide +kernel) e17472 e17473
  have e17469 : Deny 5 11 b17469 :=
    branchAction rule_sound _ _ 2
      0x2a3 b17469 b17470 b17471 (by decide +kernel) e17470 e17471
  have e17496 : Deny 5 11 b17496 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
  have e17498 : Deny 5 11 b17498 := by
    apply closeAction rule_sound _ _ 64 [0x562]
    decide +kernel
  have e17500 : Deny 5 11 b17500 := by
    apply closeAction rule_sound _ _ 64 [0x20af7552a32631f875d54a2a3244]
    decide +kernel
  have e17513 : Deny 5 11 b17513 := by
    apply closeAction rule_sound _ _ 64 [0x72f74974956229d7552b8284778df68c41f88c98c4]
    decide +kernel
  have e17499 : Deny 5 11 b17499 :=
    branchAction rule_sound _ _ 1
      0xb b17499 b17500 b17513 (by decide +kernel) e17500 e17513
  have e17497 : Deny 5 11 b17497 :=
    branchAction rule_sound _ _ 1
      0xa b17497 b17498 b17499 (by decide +kernel) e17498 e17499
  have e17495 : Deny 5 11 b17495 :=
    branchAction rule_sound _ _ 2
      0x2a3 b17495 b17496 b17497 (by decide +kernel) e17496 e17497
  have e17529 : Deny 5 11 b17529 := by
    apply closeAction rule_sound _ _ 64 [0x159a2]
    decide +kernel
  have e17531 : Deny 5 11 b17531 := by
    apply closeAction rule_sound _ _ 64 [0x566884]
    decide +kernel
  have e17532 : Deny 5 11 b17532 := by
    apply closeAction rule_sound _ _ 64 [0x827552a3263107e23102649e278c4763107e159e680a8c42788c4]
    decide +kernel
  have e17530 : Deny 5 11 b17530 :=
    branchAction rule_sound _ _ 2
      0x2b8 b17530 b17531 b17532 (by decide +kernel) e17531 e17532
  have e17528 : Deny 5 11 b17528 :=
    branchAction rule_sound _ _ 1
      0xa b17528 b17529 b17530 (by decide +kernel) e17529 e17530
  have e17494 : Deny 5 11 b17494 :=
    branchAction rule_sound _ _ 1
      0x7 b17494 b17495 b17528 (by decide +kernel) e17495 e17528
  have e17468 : Deny 5 11 b17468 :=
    branchAction rule_sound _ _ 1
      0x9 b17468 b17469 b17494 (by decide +kernel) e17469 e17494
  have e17549 : Deny 5 11 b17549 := by
    apply closeAction rule_sound _ _ 64 [0x5679a0]
    decide +kernel
  have e17553 : Deny 5 11 b17553 := by
    apply closeAction rule_sound _ _ 64 [0x826678c42789c3e039e32631c89e3]
    decide +kernel
  have e17562 : Deny 5 11 b17562 := by
    apply closeAction rule_sound _ _ 64 [0x829d5e370f89c91e0108e37]
    decide +kernel
  have e17552 : Deny 5 11 b17552 :=
    branchAction rule_sound _ _ 2
      0x244 b17552 b17553 b17562 (by decide +kernel) e17553 e17562
  have e17570 : Deny 5 11 b17570 := by
    apply closeAction rule_sound _ _ 64 [0x20e7804278de78c40f80e78c98c41f87599c4678de3107e23243e369e02889e3]
    decide +kernel
  have e17588 : Deny 5 11 b17588 := by
    apply closeAction rule_sound _ _ 64 [0x75d7550e0243e202602a028a543e278099a0284]
    decide +kernel
  have e17603 : Deny 5 11 b17603 := by
    apply closeAction rule_sound _ _ 64 [0x1d7430f81c2809e3680a295e37da02a3]
    decide +kernel
  have e17587 : Deny 5 11 b17587 :=
    branchAction rule_sound _ _ 1
      0xb b17587 b17588 b17603 (by decide +kernel) e17588 e17603
  have e17614 : Deny 5 11 b17614 := by
    apply closeAction rule_sound _ _ 64 [0x20f89e0109e37]
    decide +kernel
  have e17586 : Deny 5 11 b17586 :=
    branchAction rule_sound _ _ 2
      0x223 b17586 b17587 b17614 (by decide +kernel) e17587 e17614
  have e17617 : Deny 5 11 b17617 := by
    apply closeAction rule_sound _ _ 64 [0x767]
    decide +kernel
  have e17585 : Deny 5 11 b17585 :=
    branchAction rule_sound _ _ 1
      0x7 b17585 b17586 b17617 (by decide +kernel) e17586 e17617
  have e17569 : Deny 5 11 b17569 :=
    branchAction rule_sound _ _ 3
      0x98c4 b17569 b17570 b17585 (by decide +kernel) e17570 e17585
  have e17551 : Deny 5 11 b17551 :=
    branchAction rule_sound _ _ 2
      0x2e3 b17551 b17552 b17569 (by decide +kernel) e17552 e17569
  have e17618 : Deny 5 11 b17618 := by
    apply closeAction rule_sound _ _ 64 [0x26678d91f89e3109e27]
    decide +kernel
  have e17550 : Deny 5 11 b17550 :=
    branchAction rule_sound _ _ 1
      0x7 b17550 b17551 b17618 (by decide +kernel) e17551 e17618
  have e17548 : Deny 5 11 b17548 :=
    branchAction rule_sound _ _ 2
      0x2a3 b17548 b17549 b17550 (by decide +kernel) e17549 e17550
  have e17626 : Deny 5 11 b17626 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
  have e17627 : Deny 5 11 b17627 := by
    apply closeAction rule_sound _ _ 64 [0x95e3775575d54a28910ae152a31e3238]
    decide +kernel
  have e17625 : Deny 5 11 b17625 :=
    branchAction rule_sound _ _ 2
      0x2a3 b17625 b17626 b17627 (by decide +kernel) e17626 e17627
  have e17642 : Deny 5 11 b17642 := by
    apply closeAction rule_sound _ _ 64 [0x11e37]
    decide +kernel
  have e17624 : Deny 5 11 b17624 :=
    branchAction rule_sound _ _ 2
      0x1e3 b17624 b17625 b17642 (by decide +kernel) e17625 e17642
  have e17643 : Deny 5 11 b17643 := by
    apply closeAction rule_sound _ _ 64 [0x15e37]
    decide +kernel
  have e17623 : Deny 5 11 b17623 :=
    branchAction rule_sound _ _ 1
      0x9 b17623 b17624 b17643 (by decide +kernel) e17624 e17643
  have e17547 : Deny 5 11 b17547 :=
    branchAction rule_sound _ _ 1
      0x9 b17547 b17548 b17623 (by decide +kernel) e17548 e17623
  have e17467 : Deny 5 11 b17467 :=
    branchAction rule_sound _ _ 3
      0x88c4 b17467 b17468 b17547 (by decide +kernel) e17468 e17547
  exact e17467
end OMA.Blocks5_11_245212.S17467
