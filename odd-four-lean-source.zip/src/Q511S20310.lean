import FastReplay245212
import SparseDigit245212
import FastRound245212
import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S20310
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b20310 : Box := ![⟨23,46⟩,⟨15,1920000000000000011376⟩,⟨3,6⟩,⟨1,788099173553719012974⟩,⟨103,999999999999999999⟩]
private def b20311 : Box := ![⟨23,46⟩,⟨15,30⟩,⟨3,6⟩,⟨1,669192982456140354876⟩,⟨103,999999999999999999⟩]
private def b20312 : Box := ![⟨23,30⟩,⟨15,30⟩,⟨4,6⟩,⟨1,35⟩,⟨103,406⟩]
private def b20315 : Box := ![⟨31,46⟩,⟨15,30⟩,⟨4,6⟩,⟨1,35⟩,⟨103,406⟩]
private def b20316 : Box := ![⟨31,46⟩,⟨15,20⟩,⟨4,6⟩,⟨1,27⟩,⟨103,403⟩]
private def b20319 : Box := ![⟨31,46⟩,⟨21,30⟩,⟨4,6⟩,⟨1,27⟩,⟨103,403⟩]
private def b20320 : Box := ![⟨31,46⟩,⟨21,30⟩,⟨4,6⟩,⟨1,27⟩,⟨103,164⟩]
private def b20331 : Box := ![⟨31,46⟩,⟨21,30⟩,⟨4,6⟩,⟨1,27⟩,⟨165,402⟩]
private def b20338 : Box := ![⟨23,46⟩,⟨31,1920000000000000011376⟩,⟨3,6⟩,⟨1,669192982456140354876⟩,⟨103,999999999999999999⟩]
private def b20339 : Box := ![⟨23,46⟩,⟨31,1920000000000000011376⟩,⟨3,4⟩,⟨1,669192982456140354876⟩,⟨103,999999999999999999⟩]
private def b20340 : Box := ![⟨23,30⟩,⟨31,1920000000000000011376⟩,⟨3,4⟩,⟨1,669192982456140354875⟩,⟨103,999999999999999999⟩]
private def b20355 : Box := ![⟨31,46⟩,⟨31,1920000000000000011376⟩,⟨3,4⟩,⟨1,669192982456140354875⟩,⟨103,999999999999999999⟩]
private def b20356 : Box := ![⟨31,46⟩,⟨31,1920000000000000011376⟩,⟨3,4⟩,⟨1,2⟩,⟨103,1530775⟩]
private def b20357 : Box := ![⟨31,46⟩,⟨31,1920000000000000011376⟩,⟨3,4⟩,⟨3,669192982456140354875⟩,⟨103,1530775⟩]
private def b20358 : Box := ![⟨31,46⟩,⟨31,1920000000000000011376⟩,⟨3,4⟩,⟨3,669192982456140354869⟩,⟨103,205⟩]
private def b20359 : Box := ![⟨31,46⟩,⟨31,62⟩,⟨3,4⟩,⟨3,669192982456140354868⟩,⟨103,199⟩]
private def b20360 : Box := ![⟨31,46⟩,⟨31,62⟩,⟨3,3⟩,⟨3,37⟩,⟨103,199⟩]
private def b20361 : Box := ![⟨31,46⟩,⟨31,62⟩,⟨4,4⟩,⟨3,37⟩,⟨103,199⟩]
private def b20376 : Box := ![⟨31,46⟩,⟨63,1920000000000000011376⟩,⟨3,4⟩,⟨3,669192982456140354868⟩,⟨103,199⟩]
private def b20377 : Box := ![⟨31,46⟩,⟨63,1920000000000000011376⟩,⟨3,4⟩,⟨3,6⟩,⟨103,199⟩]
private def b20378 : Box := ![⟨31,46⟩,⟨63,1920000000000000011376⟩,⟨3,4⟩,⟨7,669192982456140354868⟩,⟨103,199⟩]
private def b20379 : Box := ![⟨31,46⟩,⟨63,1920000000000000011376⟩,⟨3,3⟩,⟨7,669192982456140354868⟩,⟨103,199⟩]
private def b20386 : Box := ![⟨31,46⟩,⟨63,1920000000000000011376⟩,⟨4,4⟩,⟨7,669192982456140354868⟩,⟨103,199⟩]
private def b20387 : Box := ![⟨31,37⟩,⟨63,1920000000000000011376⟩,⟨4,4⟩,⟨7,669192982456140354868⟩,⟨103,199⟩]
private def b20388 : Box := ![⟨31,37⟩,⟨63,1920000000000000011376⟩,⟨4,4⟩,⟨7,669192982456140354865⟩,⟨103,135⟩]
private def b20395 : Box := ![⟨31,37⟩,⟨63,1920000000000000011376⟩,⟨4,4⟩,⟨7,669192982456140354865⟩,⟨136,199⟩]
private def b20404 : Box := ![⟨38,46⟩,⟨63,1920000000000000011376⟩,⟨4,4⟩,⟨7,669192982456140354868⟩,⟨103,199⟩]
private def b20407 : Box := ![⟨31,46⟩,⟨31,1920000000000000011376⟩,⟨3,4⟩,⟨3,669192982456140354869⟩,⟨206,11855⟩]
private def b20408 : Box := ![⟨31,46⟩,⟨41,1920000000000000011376⟩,⟨3,3⟩,⟨3,582054933875890135720⟩,⟨206,9585⟩]
private def b20409 : Box := ![⟨31,46⟩,⟨41,1920000000000000011376⟩,⟨4,4⟩,⟨3,582054933875890135720⟩,⟨206,9585⟩]
private def b20410 : Box := ![⟨31,46⟩,⟨41,82⟩,⟨4,4⟩,⟨3,582054933875890135720⟩,⟨206,8538⟩]
private def b20415 : Box := ![⟨31,46⟩,⟨83,1920000000000000011376⟩,⟨4,4⟩,⟨3,582054933875890135720⟩,⟨206,8538⟩]
private def b20426 : Box := ![⟨23,46⟩,⟨31,1920000000000000011376⟩,⟨5,6⟩,⟨1,669192982456140354876⟩,⟨103,999999999999999999⟩]
private def b20427 : Box := ![⟨23,30⟩,⟨31,1920000000000000011376⟩,⟨5,6⟩,⟨1,669192982456140354876⟩,⟨103,999999999999999999⟩]
private def b20428 : Box := ![⟨23,30⟩,⟨31,1920000000000000011376⟩,⟨5,6⟩,⟨1,669192982456140354873⟩,⟨103,206⟩]
private def b20429 : Box := ![⟨23,30⟩,⟨31,1920000000000000011376⟩,⟨5,6⟩,⟨1,2⟩,⟨103,199⟩]
private def b20430 : Box := ![⟨23,30⟩,⟨31,1920000000000000011376⟩,⟨5,6⟩,⟨3,669192982456140354865⟩,⟨103,199⟩]
private def b20431 : Box := ![⟨23,30⟩,⟨31,62⟩,⟨5,6⟩,⟨3,669192982456140354865⟩,⟨103,199⟩]
private def b20442 : Box := ![⟨23,30⟩,⟨63,1920000000000000011376⟩,⟨5,6⟩,⟨3,669192982456140354865⟩,⟨103,199⟩]
private def b20443 : Box := ![⟨23,30⟩,⟨63,1920000000000000011376⟩,⟨5,6⟩,⟨3,6⟩,⟨103,199⟩]
private def b20444 : Box := ![⟨23,30⟩,⟨63,1920000000000000011376⟩,⟨5,6⟩,⟨7,669192982456140354865⟩,⟨103,199⟩]
private def b20445 : Box := ![⟨23,26⟩,⟨63,1920000000000000011376⟩,⟨5,6⟩,⟨7,669192982456140354865⟩,⟨103,199⟩]
private def b20446 : Box := ![⟨23,26⟩,⟨63,1920000000000000011376⟩,⟨5,6⟩,⟨7,669192982456140354864⟩,⟨103,135⟩]
private def b20455 : Box := ![⟨23,26⟩,⟨63,1920000000000000011376⟩,⟨5,6⟩,⟨7,669192982456140354864⟩,⟨136,199⟩]
private def b20464 : Box := ![⟨27,30⟩,⟨63,1920000000000000011376⟩,⟨5,6⟩,⟨7,669192982456140354865⟩,⟨103,199⟩]
private def b20465 : Box := ![⟨27,30⟩,⟨63,1920000000000000011376⟩,⟨5,6⟩,⟨7,669192982456140354865⟩,⟨110,141⟩]
private def b20472 : Box := ![⟨27,30⟩,⟨63,1920000000000000011376⟩,⟨5,6⟩,⟨7,669192982456140354865⟩,⟨142,199⟩]
private def b20481 : Box := ![⟨23,30⟩,⟨31,1920000000000000011376⟩,⟨5,6⟩,⟨1,669192982456140354873⟩,⟨207,999999999999999999⟩]
private def b20482 : Box := ![⟨23,30⟩,⟨39,1920000000000000011376⟩,⟨5,6⟩,⟨1,2⟩,⟨207,999999999999999999⟩]
private def b20483 : Box := ![⟨23,30⟩,⟨39,1920000000000000011376⟩,⟨5,6⟩,⟨3,581463414634146344935⟩,⟨207,999999999999999999⟩]
private def b20484 : Box := ![⟨23,30⟩,⟨40,80⟩,⟨5,6⟩,⟨3,581463414634146344935⟩,⟨207,999999999999999999⟩]
private def b20491 : Box := ![⟨23,30⟩,⟨81,1920000000000000011376⟩,⟨5,6⟩,⟨3,581463414634146344935⟩,⟨207,999999999999999999⟩]
private def b20492 : Box := ![⟨23,30⟩,⟨81,1920000000000000011376⟩,⟨5,6⟩,⟨3,6⟩,⟨207,999999999999999999⟩]
private def b20493 : Box := ![⟨23,30⟩,⟨81,1920000000000000011376⟩,⟨5,6⟩,⟨7,581463414634146344935⟩,⟨207,999999999999999999⟩]
private def b20494 : Box := ![⟨23,30⟩,⟨81,1920000000000000011376⟩,⟨5,6⟩,⟨7,581463414634146344935⟩,⟨207,414⟩]
private def b20503 : Box := ![⟨23,30⟩,⟨81,1920000000000000011376⟩,⟨5,6⟩,⟨7,581463414634146344935⟩,⟨415,999999999999999999⟩]
private def b20504 : Box := ![⟨23,26⟩,⟨81,1920000000000000011376⟩,⟨5,6⟩,⟨7,514070080862533695791⟩,⟨415,999999999999999999⟩]
private def b20505 : Box := ![⟨27,30⟩,⟨81,1920000000000000011376⟩,⟨5,6⟩,⟨7,514070080862533695791⟩,⟨415,999999999999999999⟩]
private def b20506 : Box := ![⟨27,30⟩,⟨81,1920000000000000011376⟩,⟨5,5⟩,⟨7,514070080862533695791⟩,⟨415,999999999999999999⟩]
private def b20507 : Box := ![⟨27,30⟩,⟨81,1920000000000000011376⟩,⟨6,6⟩,⟨7,514070080862533695791⟩,⟨415,999999999999999999⟩]
private def b20508 : Box := ![⟨27,30⟩,⟨81,162⟩,⟨6,6⟩,⟨7,514070080862533695791⟩,⟨415,999999999999999999⟩]
private def b20511 : Box := ![⟨27,30⟩,⟨163,1920000000000000011376⟩,⟨6,6⟩,⟨7,514070080862533695791⟩,⟨415,999999999999999999⟩]
private def b20512 : Box := ![⟨27,30⟩,⟨163,1920000000000000011376⟩,⟨6,6⟩,⟨7,514070080862533695791⟩,⟨415,830⟩]
private def b20513 : Box := ![⟨27,30⟩,⟨163,1920000000000000011376⟩,⟨6,6⟩,⟨7,514070080862533695791⟩,⟨831,999999999999999999⟩]
private def b20528 : Box := ![⟨31,46⟩,⟨31,1920000000000000011376⟩,⟨5,6⟩,⟨1,669192982456140354876⟩,⟨103,999999999999999999⟩]
private def b20529 : Box := ![⟨31,46⟩,⟨31,1920000000000000011376⟩,⟨5,6⟩,⟨1,669192982456140354876⟩,⟨103,206⟩]
private def b20530 : Box := ![⟨31,46⟩,⟨31,62⟩,⟨5,6⟩,⟨1,669192982456140354869⟩,⟨103,199⟩]
private def b20531 : Box := ![⟨31,37⟩,⟨31,62⟩,⟨5,6⟩,⟨1,38⟩,⟨103,199⟩]
private def b20532 : Box := ![⟨31,37⟩,⟨31,62⟩,⟨5,6⟩,⟨1,2⟩,⟨103,199⟩]
private def b20539 : Box := ![⟨31,37⟩,⟨31,62⟩,⟨5,6⟩,⟨3,36⟩,⟨103,199⟩]
private def b20540 : Box := ![⟨31,37⟩,⟨31,62⟩,⟨5,6⟩,⟨3,36⟩,⟨103,135⟩]
private def b20549 : Box := ![⟨31,37⟩,⟨31,62⟩,⟨5,6⟩,⟨3,36⟩,⟨136,199⟩]
private def b20560 : Box := ![⟨38,46⟩,⟨31,62⟩,⟨5,6⟩,⟨1,38⟩,⟨103,199⟩]
private def b20561 : Box := ![⟨38,46⟩,⟨31,62⟩,⟨5,6⟩,⟨1,2⟩,⟨103,199⟩]
private def b20562 : Box := ![⟨38,46⟩,⟨31,62⟩,⟨5,6⟩,⟨3,38⟩,⟨103,199⟩]
private def b20577 : Box := ![⟨31,46⟩,⟨63,1920000000000000011376⟩,⟨5,6⟩,⟨1,669192982456140354869⟩,⟨103,199⟩]
private def b20590 : Box := ![⟨31,46⟩,⟨31,1920000000000000011376⟩,⟨5,6⟩,⟨1,669192982456140354876⟩,⟨207,999999999999999999⟩]
private def b20591 : Box := ![⟨31,46⟩,⟨31,62⟩,⟨5,6⟩,⟨1,581463414634146344938⟩,⟨207,999999999999999999⟩]
private def b20592 : Box := ![⟨31,37⟩,⟨31,62⟩,⟨5,6⟩,⟨1,40⟩,⟨207,999999999999999999⟩]
private def b20593 : Box := ![⟨31,37⟩,⟨31,62⟩,⟨5,6⟩,⟨1,38⟩,⟨207,352⟩]
private def b20606 : Box := ![⟨31,37⟩,⟨31,62⟩,⟨5,6⟩,⟨1,38⟩,⟨353,1168⟩]
private def b20615 : Box := ![⟨38,46⟩,⟨31,62⟩,⟨5,6⟩,⟨1,40⟩,⟨207,999999999999999999⟩]
private def b20616 : Box := ![⟨38,46⟩,⟨31,62⟩,⟨5,6⟩,⟨1,40⟩,⟨207,414⟩]
private def b20617 : Box := ![⟨38,46⟩,⟨31,62⟩,⟨5,6⟩,⟨1,2⟩,⟨207,414⟩]
private def b20618 : Box := ![⟨38,46⟩,⟨31,62⟩,⟨5,6⟩,⟨3,33⟩,⟨207,414⟩]
private def b20619 : Box := ![⟨38,46⟩,⟨31,41⟩,⟨5,6⟩,⟨3,33⟩,⟨207,414⟩]
private def b20622 : Box := ![⟨38,46⟩,⟨42,62⟩,⟨5,6⟩,⟨3,33⟩,⟨207,414⟩]
private def b20623 : Box := ![⟨38,46⟩,⟨42,62⟩,⟨5,6⟩,⟨3,33⟩,⟨207,276⟩]
private def b20632 : Box := ![⟨38,46⟩,⟨42,62⟩,⟨5,6⟩,⟨3,33⟩,⟨277,414⟩]
private def b20643 : Box := ![⟨38,46⟩,⟨31,62⟩,⟨5,6⟩,⟨1,40⟩,⟨415,999999999999999999⟩]
private def b20644 : Box := ![⟨38,46⟩,⟨31,41⟩,⟨5,6⟩,⟨1,35⟩,⟨415,999999999999999999⟩]
private def b20647 : Box := ![⟨38,46⟩,⟨42,62⟩,⟨5,6⟩,⟨1,35⟩,⟨415,999999999999999999⟩]
private def b20660 : Box := ![⟨31,46⟩,⟨63,1920000000000000011376⟩,⟨5,6⟩,⟨1,581463414634146344938⟩,⟨207,999999999999999999⟩]
private def b20661 : Box := ![⟨31,37⟩,⟨63,1920000000000000011376⟩,⟨5,6⟩,⟨1,581463414634146344938⟩,⟨207,999999999999999999⟩]
private def b20662 : Box := ![⟨31,37⟩,⟨63,1920000000000000011376⟩,⟨5,6⟩,⟨1,581463414634146344936⟩,⟨207,414⟩]
private def b20663 : Box := ![⟨31,37⟩,⟨63,1920000000000000011376⟩,⟨5,6⟩,⟨1,2⟩,⟨207,414⟩]
private def b20664 : Box := ![⟨31,37⟩,⟨63,1920000000000000011376⟩,⟨5,6⟩,⟨3,581463414634146344930⟩,⟨207,414⟩]
private def b20665 : Box := ![⟨31,37⟩,⟨63,1920000000000000011376⟩,⟨5,6⟩,⟨3,6⟩,⟨207,414⟩]
private def b20666 : Box := ![⟨31,37⟩,⟨63,1920000000000000011376⟩,⟨5,6⟩,⟨7,581463414634146344930⟩,⟨207,414⟩]
private def b20667 : Box := ![⟨31,37⟩,⟨63,126⟩,⟨5,6⟩,⟨7,581463414634146344930⟩,⟨207,414⟩]
private def b20668 : Box := ![⟨31,33⟩,⟨63,126⟩,⟨5,6⟩,⟨7,51⟩,⟨207,414⟩]
private def b20679 : Box := ![⟨34,37⟩,⟨63,126⟩,⟨5,6⟩,⟨7,51⟩,⟨207,414⟩]
private def b20686 : Box := ![⟨31,37⟩,⟨127,1920000000000000011376⟩,⟨5,6⟩,⟨7,581463414634146344930⟩,⟨207,414⟩]
private def b20689 : Box := ![⟨31,37⟩,⟨63,1920000000000000011376⟩,⟨5,6⟩,⟨1,581463414634146344936⟩,⟨415,999999999999999999⟩]
private def b20690 : Box := ![⟨31,37⟩,⟨63,126⟩,⟨5,6⟩,⟨1,514070080862533695793⟩,⟨415,999999999999999999⟩]
private def b20691 : Box := ![⟨31,33⟩,⟨63,126⟩,⟨5,6⟩,⟨1,51⟩,⟨415,999999999999999999⟩]
private def b20698 : Box := ![⟨34,37⟩,⟨63,126⟩,⟨5,6⟩,⟨1,51⟩,⟨415,999999999999999999⟩]
private def b20713 : Box := ![⟨31,37⟩,⟨127,1920000000000000011376⟩,⟨5,6⟩,⟨1,514070080862533695793⟩,⟨415,999999999999999999⟩]
private def b20714 : Box := ![⟨31,33⟩,⟨127,1920000000000000011376⟩,⟨5,6⟩,⟨3,514070080862533695793⟩,⟨415,999999999999999999⟩]
private def b20715 : Box := ![⟨31,33⟩,⟨127,1920000000000000011376⟩,⟨5,5⟩,⟨3,514070080862533695792⟩,⟨415,999999999999999999⟩]
private def b20718 : Box := ![⟨31,33⟩,⟨127,1920000000000000011376⟩,⟨6,6⟩,⟨3,514070080862533695792⟩,⟨415,999999999999999999⟩]
private def b20719 : Box := ![⟨31,33⟩,⟨127,254⟩,⟨6,6⟩,⟨3,514070080862533695792⟩,⟨568,999999999999999999⟩]
private def b20720 : Box := ![⟨31,33⟩,⟨127,254⟩,⟨6,6⟩,⟨4,80⟩,⟨608,1216⟩]
private def b20721 : Box := ![⟨31,33⟩,⟨127,254⟩,⟨6,6⟩,⟨4,80⟩,⟨1217,999999999999999999⟩]
private def b20722 : Box := ![⟨31,33⟩,⟨127,254⟩,⟨6,6⟩,⟨4,72⟩,⟨1217,2434⟩]
private def b20723 : Box := ![⟨31,33⟩,⟨127,254⟩,⟨6,6⟩,⟨4,72⟩,⟨2435,999999999999999999⟩]
private def b20724 : Box := ![⟨31,33⟩,⟨127,254⟩,⟨6,6⟩,⟨4,65⟩,⟨2435,4870⟩]
private def b20725 : Box := ![⟨31,33⟩,⟨127,254⟩,⟨6,6⟩,⟨4,65⟩,⟨4871,999999999999999999⟩]
private def b20726 : Box := ![⟨31,31⟩,⟨127,254⟩,⟨6,6⟩,⟨4,60⟩,⟨4871,999999999999999999⟩]
private def b20727 : Box := ![⟨32,33⟩,⟨127,254⟩,⟨6,6⟩,⟨4,60⟩,⟨4871,999999999999999999⟩]
private def b20728 : Box := ![⟨32,33⟩,⟨127,254⟩,⟨6,6⟩,⟨4,60⟩,⟨4871,9742⟩]
private def b20729 : Box := ![⟨32,33⟩,⟨127,254⟩,⟨6,6⟩,⟨4,60⟩,⟨9743,999999999999999999⟩]
private def b20730 : Box := ![⟨32,33⟩,⟨127,254⟩,⟨6,6⟩,⟨4,55⟩,⟨9743,19486⟩]
private def b20731 : Box := ![⟨32,33⟩,⟨127,254⟩,⟨6,6⟩,⟨4,55⟩,⟨19487,999999999999999999⟩]
private def b20732 : Box := ![⟨32,33⟩,⟨127,254⟩,⟨6,6⟩,⟨4,51⟩,⟨19487,38974⟩]
private def b20733 : Box := ![⟨32,33⟩,⟨127,254⟩,⟨6,6⟩,⟨4,51⟩,⟨38975,999999999999999999⟩]
private def b20748 : Box := ![⟨31,33⟩,⟨255,1920000000000000011376⟩,⟨6,6⟩,⟨3,514070080862533695792⟩,⟨568,999999999999999999⟩]
private def b20755 : Box := ![⟨34,37⟩,⟨127,1920000000000000011376⟩,⟨5,6⟩,⟨3,514070080862533695793⟩,⟨415,999999999999999999⟩]
private def b20756 : Box := ![⟨34,37⟩,⟨127,1920000000000000011376⟩,⟨5,5⟩,⟨3,514070080862533695793⟩,⟨415,999999999999999999⟩]
private def b20757 : Box := ![⟨34,37⟩,⟨127,1920000000000000011376⟩,⟨5,5⟩,⟨3,6⟩,⟨415,999999999999999999⟩]
private def b20758 : Box := ![⟨34,37⟩,⟨127,1920000000000000011376⟩,⟨5,5⟩,⟨7,514070080862533695792⟩,⟨415,999999999999999999⟩]
private def b20759 : Box := ![⟨34,37⟩,⟨127,1920000000000000011376⟩,⟨5,5⟩,⟨7,514070080862533695792⟩,⟨415,830⟩]
private def b20762 : Box := ![⟨34,37⟩,⟨127,1920000000000000011376⟩,⟨5,5⟩,⟨7,514070080862533695792⟩,⟨831,999999999999999999⟩]
private def b20763 : Box := ![⟨34,37⟩,⟨127,254⟩,⟨5,5⟩,⟨7,461047542304593072858⟩,⟨831,999999999999999999⟩]
private def b20766 : Box := ![⟨34,37⟩,⟨255,1920000000000000011376⟩,⟨5,5⟩,⟨7,461047542304593072858⟩,⟨831,999999999999999999⟩]
private def b20767 : Box := ![⟨34,37⟩,⟨255,1920000000000000011376⟩,⟨5,5⟩,⟨8,461047542304593072858⟩,⟨831,1662⟩]
private def b20768 : Box := ![⟨34,37⟩,⟨255,1920000000000000011376⟩,⟨5,5⟩,⟨8,461047542304593072858⟩,⟨1663,999999999999999999⟩]
private def b20769 : Box := ![⟨34,37⟩,⟨255,1920000000000000011376⟩,⟨5,5⟩,⟨8,417940102264426591247⟩,⟨1663,3326⟩]
private def b20770 : Box := ![⟨34,37⟩,⟨255,1920000000000000011376⟩,⟨5,5⟩,⟨8,417940102264426591247⟩,⟨3327,999999999999999999⟩]
private def b20771 : Box := ![⟨34,37⟩,⟨255,1920000000000000011376⟩,⟨5,5⟩,⟨8,382204408817635272823⟩,⟨3327,6654⟩]
private def b20772 : Box := ![⟨34,37⟩,⟨255,1920000000000000011376⟩,⟨5,5⟩,⟨8,382204408817635272823⟩,⟨6655,999999999999999999⟩]
private def b20773 : Box := ![⟨34,37⟩,⟨255,1920000000000000011376⟩,⟨5,5⟩,⟨8,352098461538461540564⟩,⟨6655,13310⟩]
private def b20774 : Box := ![⟨34,37⟩,⟨255,1920000000000000011376⟩,⟨5,5⟩,⟨8,352098461538461540564⟩,⟨13311,999999999999999999⟩]
private def b20789 : Box := ![⟨34,37⟩,⟨127,1920000000000000011376⟩,⟨6,6⟩,⟨3,514070080862533695793⟩,⟨415,999999999999999999⟩]
private def b20790 : Box := ![⟨38,46⟩,⟨63,1920000000000000011376⟩,⟨5,6⟩,⟨1,581463414634146344938⟩,⟨207,999999999999999999⟩]
private def b20791 : Box := ![⟨38,46⟩,⟨63,1920000000000000011376⟩,⟨5,6⟩,⟨1,581463414634146344938⟩,⟨207,414⟩]
private def b20800 : Box := ![⟨38,46⟩,⟨63,1920000000000000011376⟩,⟨5,6⟩,⟨1,581463414634146344938⟩,⟨415,999999999999999999⟩]
private def b20801 : Box := ![⟨38,46⟩,⟨63,126⟩,⟨5,6⟩,⟨1,514070080862533695794⟩,⟨415,999999999999999999⟩]
private def b20802 : Box := ![⟨38,46⟩,⟨63,126⟩,⟨5,5⟩,⟨1,53⟩,⟨415,999999999999999999⟩]
private def b20803 : Box := ![⟨38,46⟩,⟨63,126⟩,⟨5,5⟩,⟨1,52⟩,⟨415,830⟩]
private def b20814 : Box := ![⟨38,46⟩,⟨63,126⟩,⟨5,5⟩,⟨1,52⟩,⟨831,999999999999999999⟩]
private def b20815 : Box := ![⟨38,41⟩,⟨63,126⟩,⟨5,5⟩,⟨1,47⟩,⟨831,999999999999999999⟩]
private def b20822 : Box := ![⟨42,46⟩,⟨63,126⟩,⟨5,5⟩,⟨1,47⟩,⟨831,999999999999999999⟩]
private def b20835 : Box := ![⟨38,46⟩,⟨63,126⟩,⟨6,6⟩,⟨1,53⟩,⟨415,999999999999999999⟩]
private def b20840 : Box := ![⟨38,46⟩,⟨127,1920000000000000011376⟩,⟨5,6⟩,⟨1,514070080862533695794⟩,⟨415,999999999999999999⟩]
private def b20841 : Box := ![⟨38,46⟩,⟨127,1920000000000000011376⟩,⟨5,5⟩,⟨3,514070080862533695794⟩,⟨839,999999999999999999⟩]
private def b20842 : Box := ![⟨38,41⟩,⟨127,1920000000000000011376⟩,⟨5,5⟩,⟨3,460305711987127919082⟩,⟨839,999999999999999999⟩]
private def b20843 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨3,460305711987127919081⟩,⟨839,999999999999999999⟩]
private def b20844 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨4,77⟩,⟨898,1796⟩]
private def b20845 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨4,77⟩,⟨1797,999999999999999999⟩]
private def b20846 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨4,69⟩,⟨1797,3594⟩]
private def b20847 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨4,69⟩,⟨3595,999999999999999999⟩]
private def b20848 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨4,63⟩,⟨3595,7190⟩]
private def b20849 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨4,63⟩,⟨7191,999999999999999999⟩]
private def b20850 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨4,58⟩,⟨7191,14382⟩]
private def b20851 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨4,58⟩,⟨14383,999999999999999999⟩]
private def b20852 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨4,54⟩,⟨14383,28766⟩]
private def b20853 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨4,54⟩,⟨28767,999999999999999999⟩]
private def b20854 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨4,50⟩,⟨28767,57534⟩]
private def b20855 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨4,50⟩,⟨57535,999999999999999999⟩]
private def b20856 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨4,47⟩,⟨57535,115070⟩]
private def b20857 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨4,47⟩,⟨115071,999999999999999999⟩]
private def b20858 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨4,44⟩,⟨115071,230142⟩]
private def b20859 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨4,44⟩,⟨230143,999999999999999999⟩]
private def b20860 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨4,42⟩,⟨230143,460286⟩]
private def b20861 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨4,42⟩,⟨460287,999999999999999999⟩]
private def b20862 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨4,39⟩,⟨460287,920574⟩]
private def b20863 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨4,39⟩,⟨920575,999999999999999999⟩]
private def b20864 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨4,37⟩,⟨920575,1841150⟩]
private def b20865 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨4,37⟩,⟨1841151,999999999999999999⟩]
private def b20866 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨4,7⟩,⟨1841151,999999999999999999⟩]
private def b20867 : Box := ![⟨38,41⟩,⟨127,222⟩,⟨5,5⟩,⟨4,7⟩,⟨1841151,3682302⟩]
private def b20868 : Box := ![⟨38,41⟩,⟨127,222⟩,⟨5,5⟩,⟨4,7⟩,⟨3682303,999999999999999999⟩]
private def b20869 : Box := ![⟨38,41⟩,⟨127,222⟩,⟨5,5⟩,⟨4,7⟩,⟨3682303,7364606⟩]
private def b20870 : Box := ![⟨38,41⟩,⟨127,222⟩,⟨5,5⟩,⟨4,7⟩,⟨7364607,999999999999999999⟩]
private def b20885 : Box := ![⟨38,41⟩,⟨127,254⟩,⟨5,5⟩,⟨8,36⟩,⟨1841151,999999999999999999⟩]
private def b20886 : Box := ![⟨38,41⟩,⟨255,1920000000000000011376⟩,⟨5,5⟩,⟨3,460305711987127919081⟩,⟨839,999999999999999999⟩]
private def b20887 : Box := ![⟨42,46⟩,⟨127,1920000000000000011376⟩,⟨5,5⟩,⟨3,460305711987127919082⟩,⟨839,999999999999999999⟩]
private def b20888 : Box := ![⟨38,46⟩,⟨127,1920000000000000011376⟩,⟨6,6⟩,⟨3,514070080862533695794⟩,⟨839,999999999999999999⟩]
theorem deny5_11 : Deny 5 11 ![⟨23,46⟩,⟨15,1920000000000000011376⟩,⟨3,6⟩,⟨1,788099173553719012974⟩,⟨103,999999999999999999⟩] := by
  have e20312 : Deny 5 11 b20312 := by
    apply closeAction rule_sound _ _ 64 [0xf51021f8df6d63]
    decide +kernel
  have e20316 : Deny 5 11 b20316 := by
    apply closeAction rule_sound _ _ 64 [0xc40f8de3108e37da3]
    decide +kernel
  have e20320 : Deny 5 11 b20320 := by
    apply closeAction rule_sound _ _ 64 [0xc32430f8de32231c31021f8de3244]
    decide +kernel
  have e20331 : Deny 5 11 b20331 := by
    apply closeAction rule_sound _ _ 64 [0xc3e378c9e03d84088e37d631f8da3]
    decide +kernel
  have e20319 : Deny 5 11 b20319 :=
    branchAction rule_sound _ _ 2
      0x2f8 b20319 b20320 b20331 (by decide +kernel) e20320 e20331
  have e20315 : Deny 5 11 b20315 :=
    branchAction rule_sound _ _ 3
      0x8e23 b20315 b20316 b20319 (by decide +kernel) e20316 e20319
  have e20311 : Deny 5 11 b20311 :=
    branchAction rule_sound _ _ 4
      0x1f8da3 b20311 b20312 b20315 (by decide +kernel) e20312 e20315
  have e20340 : Deny 5 11 b20340 := by
    apply closeAction rule_sound _ _ 64 [0x6ab6ab8c8ac36b8df58c71021f8d632350a12922b58c4089e37d63]
    decide +kernel
  have e20356 : Deny 5 11 b20356 := by
    apply closeAction rule_sound _ _ 64 [0x4f8da1]
    decide +kernel
  have e20360 : Deny 5 11 b20360 := by
    apply closeAction rule_sound _ _ 64 [0x6f8df5]
    decide +kernel
  have e20361 : Deny 5 11 b20361 := by
    apply closeAction rule_sound _ _ 64 [0x1b0f8103e042380f88470f820a0c3e378c7103e378c42388c7]
    decide +kernel
  have e20359 : Deny 5 11 b20359 :=
    branchAction rule_sound _ _ 2
      0x263 b20359 b20360 b20361 (by decide +kernel) e20360 e20361
  have e20377 : Deny 5 11 b20377 := by
    apply closeAction rule_sound _ _ 64 [0x2aeaa21]
    decide +kernel
  have e20379 : Deny 5 11 b20379 := by
    apply closeAction rule_sound _ _ 64 [0x1a6a321be2129b84ae23]
    decide +kernel
  have e20388 : Deny 5 11 b20388 := by
    apply closeAction rule_sound _ _ 64 [0x2adb6ab0eb8c88c7ae3204]
    decide +kernel
  have e20395 : Deny 5 11 b20395 := by
    apply closeAction rule_sound _ _ 64 [0x6ab688adaadb087e2322b8c88c4]
    decide +kernel
  have e20387 : Deny 5 11 b20387 :=
    branchAction rule_sound _ _ 2
      0x2e3 b20387 b20388 b20395 (by decide +kernel) e20388 e20395
  have e20404 : Deny 5 11 b20404 := by
    apply closeAction rule_sound _ _ 64 [0x9b8c4238]
    decide +kernel
  have e20386 : Deny 5 11 b20386 :=
    branchAction rule_sound _ _ 1
      0x7 b20386 b20387 b20404 (by decide +kernel) e20387 e20404
  have e20378 : Deny 5 11 b20378 :=
    branchAction rule_sound _ _ 1
      0x9 b20378 b20379 b20386 (by decide +kernel) e20379 e20386
  have e20376 : Deny 5 11 b20376 :=
    branchAction rule_sound _ _ 1
      0xa b20376 b20377 b20378 (by decide +kernel) e20377 e20378
  have e20358 : Deny 5 11 b20358 :=
    branchAction rule_sound _ _ 3
      0x88c4 b20358 b20359 b20376 (by decide +kernel) e20359 e20376
  have e20408 : Deny 5 11 b20408 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e20410 : Deny 5 11 b20410 := by
    apply closeAction rule_sound _ _ 64 [0x1b6f8df58442b8d631021f8d63]
    decide +kernel
  have e20415 : Deny 5 11 b20415 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3688e2b6f88c86ab8daae3238d631d22b8]
    decide +kernel
  have e20409 : Deny 5 11 b20409 :=
    branchAction rule_sound _ _ 2
      0x238 b20409 b20410 b20415 (by decide +kernel) e20410 e20415
  have e20407 : Deny 5 11 b20407 :=
    branchAction rule_sound _ _ 4
      0x278d63 b20407 b20408 b20409 (by decide +kernel) e20408 e20409
  have e20357 : Deny 5 11 b20357 :=
    branchAction rule_sound _ _ 3
      0xbe23 b20357 b20358 b20407 (by decide +kernel) e20358 e20407
  have e20355 : Deny 5 11 b20355 :=
    branchAction rule_sound _ _ 2
      0x2b8 b20355 b20356 b20357 (by decide +kernel) e20356 e20357
  have e20339 : Deny 5 11 b20339 :=
    branchAction rule_sound _ _ 2
      0x1e3 b20339 b20340 b20355 (by decide +kernel) e20340 e20355
  have e20429 : Deny 5 11 b20429 := by
    apply closeAction rule_sound _ _ 64 [0x3e37da1]
    decide +kernel
  have e20431 : Deny 5 11 b20431 := by
    apply closeAction rule_sound _ _ 64 [0x30f88c90f88c80c3e37ae32440f8de3108e231e3]
    decide +kernel
  have e20443 : Deny 5 11 b20443 := by
    apply closeAction rule_sound _ _ 64 [0x12]
    decide +kernel
  have e20446 : Deny 5 11 b20446 := by
    apply closeAction rule_sound _ _ 64 [0x9aae3109e2b6ab0f80f8ac98c8ae3204]
    decide +kernel
  have e20455 : Deny 5 11 b20455 := by
    apply closeAction rule_sound _ _ 64 [0x6ab688adaac3ac4089e2322b8c88c4]
    decide +kernel
  have e20445 : Deny 5 11 b20445 :=
    branchAction rule_sound _ _ 2
      0x2e3 b20445 b20446 b20455 (by decide +kernel) e20446 e20455
  have e20465 : Deny 5 11 b20465 := by
    apply closeAction rule_sound _ _ 64 [0x209aae31038c4238ae326b8c88c4]
    decide +kernel
  have e20472 : Deny 5 11 b20472 := by
    apply closeAction rule_sound _ _ 64 [0x1aae311a238adaac3e03e09ae322b8c88c4]
    decide +kernel
  have e20464 : Deny 5 11 b20464 :=
    branchAction rule_sound _ _ 2
      0x2f8 b20464 b20465 b20472 (by decide +kernel) e20465 e20472
  have e20444 : Deny 5 11 b20444 :=
    branchAction rule_sound _ _ 1
      0x7 b20444 b20445 b20464 (by decide +kernel) e20445 e20464
  have e20442 : Deny 5 11 b20442 :=
    branchAction rule_sound _ _ 1
      0xa b20442 b20443 b20444 (by decide +kernel) e20443 e20444
  have e20430 : Deny 5 11 b20430 :=
    branchAction rule_sound _ _ 1
      0x8 b20430 b20431 b20442 (by decide +kernel) e20431 e20442
  have e20428 : Deny 5 11 b20428 :=
    branchAction rule_sound _ _ 3
      0xa8c4 b20428 b20429 b20430 (by decide +kernel) e20429 e20430
  have e20482 : Deny 5 11 b20482 := by
    apply closeAction rule_sound _ _ 64 [0x4b8df6d61]
    decide +kernel
  have e20484 : Deny 5 11 b20484 := by
    apply closeAction rule_sound _ _ 64 [0x3ac3e378c8d422758c4087e23]
    decide +kernel
  have e20492 : Deny 5 11 b20492 := by
    apply closeAction rule_sound _ _ 64 [0x12e21]
    decide +kernel
  have e20494 : Deny 5 11 b20494 := by
    apply closeAction rule_sound _ _ 64 [0x6ab69aacb8daae310b6ab8c7ae3223]
    decide +kernel
  have e20504 : Deny 5 11 b20504 := by
    apply closeAction rule_sound _ _ 64 [0x1ae37db5]
    decide +kernel
  have e20506 : Deny 5 11 b20506 := by
    apply closeAction rule_sound _ _ 64 [0x6b8df5]
    decide +kernel
  have e20508 : Deny 5 11 b20508 := by
    apply closeAction rule_sound _ _ 64 [0x1a0ab84ae23]
    decide +kernel
  have e20512 : Deny 5 11 b20512 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e20513 : Deny 5 11 b20513 := by
    apply closeAction rule_sound _ _ 64 [0x26ab8c8e2b6ab8c80878da2eb6b8d6b8c8ac21f58daae32e3]
    decide +kernel
  have e20511 : Deny 5 11 b20511 :=
    branchAction rule_sound _ _ 1
      0xb b20511 b20512 b20513 (by decide +kernel) e20512 e20513
  have e20507 : Deny 5 11 b20507 :=
    branchAction rule_sound _ _ 1
      0x8 b20507 b20508 b20511 (by decide +kernel) e20508 e20511
  have e20505 : Deny 5 11 b20505 :=
    branchAction rule_sound _ _ 1
      0x9 b20505 b20506 b20507 (by decide +kernel) e20506 e20507
  have e20503 : Deny 5 11 b20503 :=
    branchAction rule_sound _ _ 2
      0x1e3 b20503 b20504 b20505 (by decide +kernel) e20504 e20505
  have e20493 : Deny 5 11 b20493 :=
    branchAction rule_sound _ _ 1
      0xb b20493 b20494 b20503 (by decide +kernel) e20494 e20503
  have e20491 : Deny 5 11 b20491 :=
    branchAction rule_sound _ _ 1
      0xa b20491 b20492 b20493 (by decide +kernel) e20492 e20493
  have e20483 : Deny 5 11 b20483 :=
    branchAction rule_sound _ _ 2
      0x235 b20483 b20484 b20491 (by decide +kernel) e20484 e20491
  have e20481 : Deny 5 11 b20481 :=
    branchAction rule_sound _ _ 3
      0xad63 b20481 b20482 b20483 (by decide +kernel) e20482 e20483
  have e20427 : Deny 5 11 b20427 :=
    branchAction rule_sound _ _ 2
      0x2e3 b20427 b20428 b20481 (by decide +kernel) e20428 e20481
  have e20532 : Deny 5 11 b20532 := by
    apply closeAction rule_sound _ _ 64 [0x30f88470f82132a1]
    decide +kernel
  have e20540 : Deny 5 11 b20540 := by
    apply closeAction rule_sound _ _ 64 [0x20f8dc38c72430e31e3204]
    decide +kernel
  have e20549 : Deny 5 11 b20549 := by
    apply closeAction rule_sound _ _ 64 [0x3e370c90f80c98c70c38c78c88c4]
    decide +kernel
  have e20539 : Deny 5 11 b20539 :=
    branchAction rule_sound _ _ 1
      0xb b20539 b20540 b20549 (by decide +kernel) e20540 e20549
  have e20531 : Deny 5 11 b20531 :=
    branchAction rule_sound _ _ 2
      0x2a3 b20531 b20532 b20539 (by decide +kernel) e20532 e20539
  have e20561 : Deny 5 11 b20561 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
  have e20562 : Deny 5 11 b20562 := by
    apply closeAction rule_sound _ _ 64 [0x20831c4278dc3e370e3263223102083248dc42f8]
    decide +kernel
  have e20560 : Deny 5 11 b20560 :=
    branchAction rule_sound _ _ 1
      0xa b20560 b20561 b20562 (by decide +kernel) e20561 e20562
  have e20530 : Deny 5 11 b20530 :=
    branchAction rule_sound _ _ 2
      0x1e3 b20530 b20531 b20560 (by decide +kernel) e20531 e20560
  have e20577 : Deny 5 11 b20577 := by
    apply closeAction rule_sound _ _ 64 [0x12e37082082ac38c88c9ae3107e2b8c423848a8c7]
    decide +kernel
  have e20529 : Deny 5 11 b20529 :=
    branchAction rule_sound _ _ 3
      0x88c4 b20529 b20530 b20577 (by decide +kernel) e20530 e20577
  have e20593 : Deny 5 11 b20593 := by
    apply closeAction rule_sound _ _ 64 [0xc3e232430898c70f884a0c2278de3223]
    decide +kernel
  have e20606 : Deny 5 11 b20606 := by
    apply closeAction rule_sound _ _ 64 [0xf80f8df58c7e03e37d6320284ae02278d63]
    decide +kernel
  have e20592 : Deny 5 11 b20592 :=
    branchAction rule_sound _ _ 3
      0xbe23 b20592 b20593 b20606 (by decide +kernel) e20593 e20606
  have e20617 : Deny 5 11 b20617 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
  have e20619 : Deny 5 11 b20619 := by
    apply closeAction rule_sound _ _ 64 [0x30f8263]
    decide +kernel
  have e20623 : Deny 5 11 b20623 := by
    apply closeAction rule_sound _ _ 64 [0x9b083108e031ca244]
    decide +kernel
  have e20632 : Deny 5 11 b20632 := by
    apply closeAction rule_sound _ _ 64 [0x83de3107e1b0f80c80c72a3263]
    decide +kernel
  have e20622 : Deny 5 11 b20622 :=
    branchAction rule_sound _ _ 1
      0xb b20622 b20623 b20632 (by decide +kernel) e20623 e20632
  have e20618 : Deny 5 11 b20618 :=
    branchAction rule_sound _ _ 1
      0x8 b20618 b20619 b20622 (by decide +kernel) e20619 e20622
  have e20616 : Deny 5 11 b20616 :=
    branchAction rule_sound _ _ 2
      0x2a3 b20616 b20617 b20618 (by decide +kernel) e20617 e20618
  have e20644 : Deny 5 11 b20644 := by
    apply closeAction rule_sound _ _ 64 [0x3e23089e23]
    decide +kernel
  have e20647 : Deny 5 11 b20647 := by
    apply closeAction rule_sound _ _ 64 [0xf80f88c8e038c70f80f88c80f8df58c7e234cae09]
    decide +kernel
  have e20643 : Deny 5 11 b20643 :=
    branchAction rule_sound _ _ 2
      0x223 b20643 b20644 b20647 (by decide +kernel) e20644 e20647
  have e20615 : Deny 5 11 b20615 :=
    branchAction rule_sound _ _ 1
      0xb b20615 b20616 b20643 (by decide +kernel) e20616 e20643
  have e20591 : Deny 5 11 b20591 :=
    branchAction rule_sound _ _ 2
      0x1e3 b20591 b20592 b20615 (by decide +kernel) e20592 e20615
  have e20663 : Deny 5 11 b20663 := by
    apply closeAction rule_sound _ _ 64 [0x12]
    decide +kernel
  have e20665 : Deny 5 11 b20665 := by
    apply closeAction rule_sound _ _ 64 [0x61]
    decide +kernel
  have e20668 : Deny 5 11 b20668 := by
    apply closeAction rule_sound _ _ 64 [0x6ab0c22632236ab0f8dc3e2b2632042e3]
    decide +kernel
  have e20679 : Deny 5 11 b20679 := by
    apply closeAction rule_sound _ _ 64 [0x83e236ab8c7e2b0e3209]
    decide +kernel
  have e20667 : Deny 5 11 b20667 :=
    branchAction rule_sound _ _ 2
      0x1e3 b20667 b20668 b20679 (by decide +kernel) e20668 e20679
  have e20686 : Deny 5 11 b20686 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3688e2b]
    decide +kernel
  have e20666 : Deny 5 11 b20666 :=
    branchAction rule_sound _ _ 1
      0x8 b20666 b20667 b20686 (by decide +kernel) e20667 e20686
  have e20664 : Deny 5 11 b20664 :=
    branchAction rule_sound _ _ 1
      0xa b20664 b20665 b20666 (by decide +kernel) e20665 e20666
  have e20662 : Deny 5 11 b20662 :=
    branchAction rule_sound _ _ 2
      0x2a3 b20662 b20663 b20664 (by decide +kernel) e20663 e20664
  have e20691 : Deny 5 11 b20691 := by
    apply closeAction rule_sound _ _ 64 [0x1a0f884ae2b0f8ae3238ae3089e23]
    decide +kernel
  have e20698 : Deny 5 11 b20698 := by
    apply closeAction rule_sound _ _ 64 [0xf88c3e231f8ac38c80c3e358c86870a12b8ae348ae37d49]
    decide +kernel
  have e20690 : Deny 5 11 b20690 :=
    branchAction rule_sound _ _ 2
      0x1e3 b20690 b20691 b20698 (by decide +kernel) e20691 e20698
  have e20715 : Deny 5 11 b20715 := by
    apply closeAction rule_sound _ _ 64 [0x6ab8daae3238]
    decide +kernel
  have e20720 : Deny 5 11 b20720 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e20722 : Deny 5 11 b20722 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e20724 : Deny 5 11 b20724 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e20726 : Deny 5 11 b20726 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e20728 : Deny 5 11 b20728 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e20730 : Deny 5 11 b20730 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e20732 : Deny 5 11 b20732 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e20733 : Deny 5 11 b20733 := by
    apply closeAction rule_sound _ _ 64 [0x68308784a8daae32e36ab8cb8daae32e36ab8cb8daae32e3]
    decide +kernel
  have e20731 : Deny 5 11 b20731 :=
    branchAction rule_sound _ _ 2
      0x2e3 b20731 b20732 b20733 (by decide +kernel) e20732 e20733
  have e20729 : Deny 5 11 b20729 :=
    branchAction rule_sound _ _ 2
      0x2e3 b20729 b20730 b20731 (by decide +kernel) e20730 e20731
  have e20727 : Deny 5 11 b20727 :=
    branchAction rule_sound _ _ 1
      0xb b20727 b20728 b20729 (by decide +kernel) e20728 e20729
  have e20725 : Deny 5 11 b20725 :=
    branchAction rule_sound _ _ 2
      0x1e3 b20725 b20726 b20727 (by decide +kernel) e20726 e20727
  have e20723 : Deny 5 11 b20723 :=
    branchAction rule_sound _ _ 2
      0x2e3 b20723 b20724 b20725 (by decide +kernel) e20724 e20725
  have e20721 : Deny 5 11 b20721 :=
    branchAction rule_sound _ _ 2
      0x2e3 b20721 b20722 b20723 (by decide +kernel) e20722 e20723
  have e20719 : Deny 5 11 b20719 :=
    branchAction rule_sound _ _ 4
      0x2f8ae3 b20719 b20720 b20721 (by decide +kernel) e20720 e20721
  have e20748 : Deny 5 11 b20748 := by
    apply closeAction rule_sound _ _ 64 [0x209ae2b0f88c81f8ae3238ae3]
    decide +kernel
  have e20718 : Deny 5 11 b20718 :=
    branchAction rule_sound _ _ 2
      0x238 b20718 b20719 b20748 (by decide +kernel) e20719 e20748
  have e20714 : Deny 5 11 b20714 :=
    branchAction rule_sound _ _ 2
      0x263 b20714 b20715 b20718 (by decide +kernel) e20715 e20718
  have e20757 : Deny 5 11 b20757 := by
    apply closeAction rule_sound _ _ 64 [0x4b8ae1]
    decide +kernel
  have e20759 : Deny 5 11 b20759 := by
    apply closeAction rule_sound _ _ 64 [0x6ab688ae3]
    decide +kernel
  have e20763 : Deny 5 11 b20763 := by
    apply closeAction rule_sound _ _ 64 [0x1aae36ab8c7e23]
    decide +kernel
  have e20767 : Deny 5 11 b20767 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e20769 : Deny 5 11 b20769 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e20771 : Deny 5 11 b20771 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e20773 : Deny 5 11 b20773 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e20774 : Deny 5 11 b20774 := by
    apply closeAction rule_sound _ _ 64 [0x26ab8c8adaac30878c8ae32358daae32daae3087e351e3]
    decide +kernel
  have e20772 : Deny 5 11 b20772 :=
    branchAction rule_sound _ _ 2
      0x2e3 b20772 b20773 b20774 (by decide +kernel) e20773 e20774
  have e20770 : Deny 5 11 b20770 :=
    branchAction rule_sound _ _ 2
      0x2e3 b20770 b20771 b20772 (by decide +kernel) e20771 e20772
  have e20768 : Deny 5 11 b20768 :=
    branchAction rule_sound _ _ 2
      0x2e3 b20768 b20769 b20770 (by decide +kernel) e20769 e20770
  have e20766 : Deny 5 11 b20766 :=
    branchAction rule_sound _ _ 2
      0x2eb b20766 b20767 b20768 (by decide +kernel) e20767 e20768
  have e20762 : Deny 5 11 b20762 :=
    branchAction rule_sound _ _ 2
      0x223 b20762 b20763 b20766 (by decide +kernel) e20763 e20766
  have e20758 : Deny 5 11 b20758 :=
    branchAction rule_sound _ _ 1
      0xb b20758 b20759 b20762 (by decide +kernel) e20759 e20762
  have e20756 : Deny 5 11 b20756 :=
    branchAction rule_sound _ _ 2
      0x2a3 b20756 b20757 b20758 (by decide +kernel) e20757 e20758
  have e20789 : Deny 5 11 b20789 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e20755 : Deny 5 11 b20755 :=
    branchAction rule_sound _ _ 1
      0x9 b20755 b20756 b20789 (by decide +kernel) e20756 e20789
  have e20713 : Deny 5 11 b20713 :=
    branchAction rule_sound _ _ 2
      0x1eb b20713 b20714 b20755 (by decide +kernel) e20714 e20755
  have e20689 : Deny 5 11 b20689 :=
    branchAction rule_sound _ _ 2
      0x223 b20689 b20690 b20713 (by decide +kernel) e20690 e20713
  have e20661 : Deny 5 11 b20661 :=
    branchAction rule_sound _ _ 2
      0x2e3 b20661 b20662 b20689 (by decide +kernel) e20662 e20689
  have e20791 : Deny 5 11 b20791 := by
    apply closeAction rule_sound _ _ 64 [0x820820e3108e2b8c41f8ae3278ae3223]
    decide +kernel
  have e20803 : Deny 5 11 b20803 := by
    apply closeAction rule_sound _ _ 64 [0x6c3e2b84ae1b68384a8c76eb84aac7ae3]
    decide +kernel
  have e20815 : Deny 5 11 b20815 := by
    apply closeAction rule_sound _ _ 64 [0x30f88c80f8de3212e37d612a3]
    decide +kernel
  have e20822 : Deny 5 11 b20822 := by
    apply closeAction rule_sound _ _ 64 [0x83e232380e31e36eb8cb8dbae32f8ac30f88c78c8]
    decide +kernel
  have e20814 : Deny 5 11 b20814 :=
    branchAction rule_sound _ _ 2
      0x1e3 b20814 b20815 b20822 (by decide +kernel) e20815 e20822
  have e20802 : Deny 5 11 b20802 :=
    branchAction rule_sound _ _ 2
      0x2e3 b20802 b20803 b20814 (by decide +kernel) e20803 e20814
  have e20835 : Deny 5 11 b20835 := by
    apply closeAction rule_sound _ _ 64 [0x820f88c8e231f8]
    decide +kernel
  have e20801 : Deny 5 11 b20801 :=
    branchAction rule_sound _ _ 2
      0x263 b20801 b20802 b20835 (by decide +kernel) e20802 e20835
  have e20844 : Deny 5 11 b20844 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e20846 : Deny 5 11 b20846 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e20848 : Deny 5 11 b20848 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e20850 : Deny 5 11 b20850 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e20852 : Deny 5 11 b20852 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e20854 : Deny 5 11 b20854 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e20856 : Deny 5 11 b20856 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e20858 : Deny 5 11 b20858 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e20860 : Deny 5 11 b20860 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e20862 : Deny 5 11 b20862 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e20864 : Deny 5 11 b20864 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e20867 : Deny 5 11 b20867 := by
    apply closeAction rule_sound _ _ 64 [0x12]
    decide +kernel
  have e20869 : Deny 5 11 b20869 := by
    apply closeAction rule_sound _ _ 64 [0x12]
    decide +kernel
  have e20870 : Deny 5 11 b20870 := by
    apply closeAction rule_sound _ _ 64 [0x68308784a48b48b48b48b48b]
    decide +kernel
  have e20868 : Deny 5 11 b20868 :=
    branchAction rule_sound _ _ 1
      0xb b20868 b20869 b20870 (by decide +kernel) e20869 e20870
  have e20866 : Deny 5 11 b20866 :=
    branchAction rule_sound _ _ 2
      0x2e1 b20866 b20867 b20868 (by decide +kernel) e20867 e20868
  have e20885 : Deny 5 11 b20885 := by
    apply closeAction rule_sound _ _ 64 [0x1a]
    decide +kernel
  have e20865 : Deny 5 11 b20865 :=
    branchAction rule_sound _ _ 2
      0x2a3 b20865 b20866 b20885 (by decide +kernel) e20866 e20885
  have e20863 : Deny 5 11 b20863 :=
    branchAction rule_sound _ _ 2
      0x2e3 b20863 b20864 b20865 (by decide +kernel) e20864 e20865
  have e20861 : Deny 5 11 b20861 :=
    branchAction rule_sound _ _ 2
      0x2e3 b20861 b20862 b20863 (by decide +kernel) e20862 e20863
  have e20859 : Deny 5 11 b20859 :=
    branchAction rule_sound _ _ 2
      0x2e3 b20859 b20860 b20861 (by decide +kernel) e20860 e20861
  have e20857 : Deny 5 11 b20857 :=
    branchAction rule_sound _ _ 2
      0x2e3 b20857 b20858 b20859 (by decide +kernel) e20858 e20859
  have e20855 : Deny 5 11 b20855 :=
    branchAction rule_sound _ _ 2
      0x2e3 b20855 b20856 b20857 (by decide +kernel) e20856 e20857
  have e20853 : Deny 5 11 b20853 :=
    branchAction rule_sound _ _ 2
      0x2e3 b20853 b20854 b20855 (by decide +kernel) e20854 e20855
  have e20851 : Deny 5 11 b20851 :=
    branchAction rule_sound _ _ 2
      0x2e3 b20851 b20852 b20853 (by decide +kernel) e20852 e20853
  have e20849 : Deny 5 11 b20849 :=
    branchAction rule_sound _ _ 2
      0x2e3 b20849 b20850 b20851 (by decide +kernel) e20850 e20851
  have e20847 : Deny 5 11 b20847 :=
    branchAction rule_sound _ _ 2
      0x2e3 b20847 b20848 b20849 (by decide +kernel) e20848 e20849
  have e20845 : Deny 5 11 b20845 :=
    branchAction rule_sound _ _ 2
      0x2e3 b20845 b20846 b20847 (by decide +kernel) e20846 e20847
  have e20843 : Deny 5 11 b20843 :=
    branchAction rule_sound _ _ 4
      0x2f8ae3 b20843 b20844 b20845 (by decide +kernel) e20844 e20845
  have e20886 : Deny 5 11 b20886 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e20842 : Deny 5 11 b20842 :=
    branchAction rule_sound _ _ 2
      0x223 b20842 b20843 b20886 (by decide +kernel) e20843 e20886
  have e20887 : Deny 5 11 b20887 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e20841 : Deny 5 11 b20841 :=
    branchAction rule_sound _ _ 2
      0x1e3 b20841 b20842 b20887 (by decide +kernel) e20842 e20887
  have e20888 : Deny 5 11 b20888 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e20840 : Deny 5 11 b20840 :=
    branchAction rule_sound _ _ 3
      0x9e2b b20840 b20841 b20888 (by decide +kernel) e20841 e20888
  have e20800 : Deny 5 11 b20800 :=
    branchAction rule_sound _ _ 2
      0x223 b20800 b20801 b20840 (by decide +kernel) e20801 e20840
  have e20790 : Deny 5 11 b20790 :=
    branchAction rule_sound _ _ 1
      0xb b20790 b20791 b20800 (by decide +kernel) e20791 e20800
  have e20660 : Deny 5 11 b20660 :=
    branchAction rule_sound _ _ 1
      0x7 b20660 b20661 b20790 (by decide +kernel) e20661 e20790
  have e20590 : Deny 5 11 b20590 :=
    branchAction rule_sound _ _ 2
      0x223 b20590 b20591 b20660 (by decide +kernel) e20591 e20660
  have e20528 : Deny 5 11 b20528 :=
    branchAction rule_sound _ _ 1
      0xb b20528 b20529 b20590 (by decide +kernel) e20529 e20590
  have e20426 : Deny 5 11 b20426 :=
    branchAction rule_sound _ _ 1
      0x7 b20426 b20427 b20528 (by decide +kernel) e20427 e20528
  have e20338 : Deny 5 11 b20338 :=
    branchAction rule_sound _ _ 1
      0x9 b20338 b20339 b20426 (by decide +kernel) e20339 e20426
  have e20310 : Deny 5 11 b20310 :=
    branchAction rule_sound _ _ 2
      0x223 b20310 b20311 b20338 (by decide +kernel) e20311 e20338
  exact e20310
end OMA.Blocks5_11_245212.S20310
