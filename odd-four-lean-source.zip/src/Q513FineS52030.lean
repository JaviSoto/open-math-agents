import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S52030
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b52030 : Box := ![⟨191,1920000000000000011376⟩,⟨25,30⟩,⟨15,30⟩,⟨3,342194907813871819447⟩,⟨479,999999999999999999⟩]
private def b52031 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨15,30⟩,⟨3,342194907813871819447⟩,⟨479,999999999999999999⟩]
private def b52032 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨15,30⟩,⟨3,97⟩,⟨479,958⟩]
private def b52033 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨15,30⟩,⟨3,97⟩,⟨959,999999999999999999⟩]
private def b52034 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨15,20⟩,⟨3,87⟩,⟨959,999999999999999999⟩]
private def b52035 : Box := ![⟨191,382⟩,⟨25,27⟩,⟨15,20⟩,⟨3,83⟩,⟨959,999999999999999999⟩]
private def b52180 : Box := ![⟨191,382⟩,⟨28,30⟩,⟨15,20⟩,⟨3,83⟩,⟨959,999999999999999999⟩]
private def b52359 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨21,30⟩,⟨3,87⟩,⟨959,999999999999999999⟩]
private def b52382 : Box := ![⟨383,1920000000000000011376⟩,⟨25,30⟩,⟨15,30⟩,⟨3,342194907813871819447⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨191,1920000000000000011376⟩,⟨25,30⟩,⟨15,30⟩,⟨3,342194907813871819447⟩,⟨479,999999999999999999⟩] := by
  have e52032 : Deny 5 13 b52032 := by
    apply closeAction rule_sound _ _ 64 [0x1f9e3]
    decide +kernel
  have e52035 : Deny 5 13 b52035 := by
    apply closeAction rule_sound _ _ 64 [0x9e32e36678cb8d99e32e70c3e362231e37e78cb8df9e32d99c21f89e37e78cbe086678dfe369e31f88c98df9e32e31e3,0x80b2999e32e36678cb8d99e32e36678cb8d99e32e36678cb8d99e32e36678cb8d99e32e36678cb8d99e32e36678cb8d9,0x9e32e36678cb8d99e32e36678cb8d99e32e36678cb8d99e32e36678cb8d99e32e76420c80c966780b66780b66780b667,0x44b44b44b44b80a66780b66780b66780b6679a02c29e69602d12d12d12d12ca8d99e32e36678cb8d99e32e36678cb8d9,0x196599d96512d12d92512d12d12d12d12cad8744b]
    decide +kernel
  have e52180 : Deny 5 13 b52180 := by
    apply closeAction rule_sound _ _ 64 [0x8d99e32e36678cb8d99e32e36678cb8d99e32e36678cb8d99e32e36678cb8d99e32e70c38c70f82631e32637e78cb8c7,0x66780b66780b66780b66780b66780b6679a02c180b2a36678cb8d99e32e36678cb8d99e32e36678cb8d99e32e36678cb,0x6590c38090e02429a580b44b44b44b44b44b80a66780b66780b66780b6679a02c29e69602d12d12d12ca66780b66780b,0x9e32e36678cb8d99e32e36678cb8d99e32e36678cb8d99e32e36678cb8d99e32e36678cbe232789c2083e232388c7e19,0x2d12d12d12d12d12d12e028744b44b44b44b44b80a66780b66780b66780b0a79a580b44b44b44b44b44b2a36678cb8d9,0x996599d9651]
    decide +kernel
  have e52034 : Deny 5 13 b52034 :=
    branchAction rule_sound _ _ 2
      0x223 b52034 b52035 b52180 (by decide +kernel) e52035 e52180
  have e52359 : Deny 5 13 b52359 := by
    apply closeAction rule_sound _ _ 64 [0x820820820f82388c9e231f8083e232789c3e03e232631c88df9e32f88c9e231e3238]
    decide +kernel
  have e52033 : Deny 5 13 b52033 :=
    branchAction rule_sound _ _ 2
      0x263 b52033 b52034 b52359 (by decide +kernel) e52034 e52359
  have e52031 : Deny 5 13 b52031 :=
    branchAction rule_sound _ _ 2
      0x2e3 b52031 b52032 b52033 (by decide +kernel) e52032 e52033
  have e52382 : Deny 5 13 b52382 := by
    apply closeAction rule_sound _ _ 64 [0x6678cb8d99e32e31e36678cb8d99e32e36678cb9e31e36678cb8d99e32e36678cb8d99e32e36678cb8c98c8e278c9e27,0x820826678c79d99d99d96590e02912e02912ca8c78d99e32e3]
    decide +kernel
  have e52030 : Deny 5 13 b52030 :=
    branchAction rule_sound _ _ 1
      0x7 b52030 b52031 b52382 (by decide +kernel) e52031 e52382
  exact e52030
end OMA.Blocks5_13_245212.S52030
