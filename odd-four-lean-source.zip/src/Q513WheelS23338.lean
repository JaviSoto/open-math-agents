import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S23338
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b23338 : Box := ![⟨31,46⟩,⟨63,1920000000000000011376⟩,⟨7,14⟩,⟨1,648707482993197282786⟩,⟨219,1312⟩]
theorem deny5_13 : Deny 5 13 ![⟨31,46⟩,⟨63,1920000000000000011376⟩,⟨7,14⟩,⟨1,648707482993197282786⟩,⟨219,1312⟩] := by
  have e23338 : Deny 5 13 b23338 := by
    apply closeAction rule_sound _ _ 64 [0x841f8de3203089ac2237d44087e37d6325a7f8dab2ab102238df6d631f8da321aae311aae3108e36d631c2aa884ada3,0xae322b7c3ac4088e090896b8df6d478c469f0f8ac92ab0eb0e322321f0f88c96b8df5ae326b1e310bac37f8de3202244,0x6ab6ab6ab69aada0f80f8ac70f8ae11f82b82382b88c8ae36ab8c9e2b8c8e36]
    decide +kernel
  exact e23338
end OMA.Blocks5_13_245212.S23338
