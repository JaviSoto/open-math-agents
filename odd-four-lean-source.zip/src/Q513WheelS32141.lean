import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S32141
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b32141 : Box := ![⟨38,41⟩,⟨102,126⟩,⟨127,1920000000000000011376⟩,⟨3,652387096774193552298⟩,⟨1919,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨38,41⟩,⟨102,126⟩,⟨127,1920000000000000011376⟩,⟨3,652387096774193552298⟩,⟨1919,999999999999999999⟩] := by
  have e32141 : Deny 5 13 b32141 := by
    apply closeAction rule_sound _ _ 64 [0x2e37af8cb8debe32e37af8cb8debe32e37af8cb8debe32e37af8cb8debe32e37af8cb8debe32e322379f88abe32e3247,0xbe32e32477820832497af0c22090af88bda221ebe22debe22debe22debe22debe22debe22debed88b58b08788a8debe3,0x7af8cb8debe32e37af8cb8debe32f88c8e2f083e232380f80f88c88c90c3e2f203e2f8debe32388c98c88d6e377af8c8,0xbe378b8c98de2c7e2f8c98c8e2f0827af79e0c3da22222942d42ca8c98debe32e37af8cb8debe32e37af8cb8debe32e3,0x208209ebde]
    decide +kernel
  exact e32141
end OMA.Blocks5_13_245212.S32141
