import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S27912
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b27912 : Box := ![⟨38,46⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨1,565934718100890211109⟩,⟨479,999999999999999999⟩]
private def b27913 : Box := ![⟨38,46⟩,⟨63,126⟩,⟨15,30⟩,⟨1,502335381913959616709⟩,⟨479,999999999999999999⟩]
private def b28022 : Box := ![⟨38,46⟩,⟨127,1920000000000000011376⟩,⟨15,30⟩,⟨1,502335381913959616709⟩,⟨479,999999999999999999⟩]
private def b28023 : Box := ![⟨38,46⟩,⟨127,1920000000000000011376⟩,⟨15,20⟩,⟨1,502335381913959616709⟩,⟨479,999999999999999999⟩]
private def b28106 : Box := ![⟨38,46⟩,⟨127,1920000000000000011376⟩,⟨21,30⟩,⟨1,502335381913959616709⟩,⟨479,999999999999999999⟩]
private def b28107 : Box := ![⟨38,41⟩,⟨127,1920000000000000011376⟩,⟨21,30⟩,⟨1,502335381913959616709⟩,⟨479,999999999999999999⟩]
private def b28200 : Box := ![⟨42,46⟩,⟨127,1920000000000000011376⟩,⟨21,30⟩,⟨1,502335381913959616709⟩,⟨479,999999999999999999⟩]
private def b28201 : Box := ![⟨42,46⟩,⟨127,1920000000000000011376⟩,⟨21,30⟩,⟨1,502335381913959616709⟩,⟨479,958⟩]
private def b28204 : Box := ![⟨42,46⟩,⟨127,1920000000000000011376⟩,⟨21,30⟩,⟨1,502335381913959616709⟩,⟨959,999999999999999999⟩]
private def b28205 : Box := ![⟨42,46⟩,⟨127,254⟩,⟨21,30⟩,⟨1,451586424625098660956⟩,⟨959,999999999999999999⟩]
private def b28366 : Box := ![⟨42,46⟩,⟨255,1920000000000000011376⟩,⟨21,30⟩,⟨1,451586424625098660956⟩,⟨959,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨38,46⟩,⟨63,1920000000000000011376⟩,⟨15,30⟩,⟨1,565934718100890211109⟩,⟨479,999999999999999999⟩] := by
  have e27913 : Deny 5 13 b27913 := by
    apply closeAction rule_sound _ _ 64 [0xe361f8d8a7f8df61f82212972a32df0f8df684a7f8dc77f8deb8c9e237f8df68c8e37d631dfae37f8df68c8e37d63263,0x8c88df7d70d7e362211c3e36844088e368475ca84a7d70c3e080f88495ca84784a84b7d7e212b87f8df6847e2125f5d7,0xe23087e37da32021e37df0c3e080f88490f8da11d72821e12a12972a32dfae37f8df6ae32388c90c22022388c21f8df6,0xc3e2b8c90f8da32021e37eb0c3e2b8c98c8ae32c3088]
    decide +kernel
  have e28023 : Deny 5 13 b28023 := by
    apply closeAction rule_sound _ _ 64 [0x6ab8cb8daae32e36ab8cb8daae32e36ab8cbadf7f8d6b8c9e232236ab7eb8c8ae32daae37f8dab8c8e231d2e2b84aae3,0x2e36ab8cb8daae32e36ab8cb089087ae32026ab8c8089087d6b089d4709aae32021c22421c2275ac21f58c98daae32e3,0x820891eb6ab8c8adaae322b6ab0c21eb0888c88daae32e36ab8cb8daae3]
    decide +kernel
  have e28107 : Deny 5 13 b28107 := by
    apply closeAction rule_sound _ _ 64 [0xd632636ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32df7f8db5ae31f88c88daadfae32232d2e21292e2baa12a3,0x2d22c21c227684a8daae32e36ab8cb8daae32e36ab8cb8daae32c21e32236ab8cb0826ab8c8d49adaae32021c226b087,0x20821c22761eb6ab8c8adaae322b6ab8c8adaae322b6ab8c8ada6ab0c226b0882122d22d22d2]
    decide +kernel
  have e28201 : Deny 5 13 b28201 := by
    apply closeAction rule_sound _ _ 64 [0xab7eb8c8ae3]
    decide +kernel
  have e28205 : Deny 5 13 b28205 := by
    apply closeAction rule_sound _ _ 64 [0x6ab8cb8daae32e36ab8cbac3089088087da32358dfae32eb087d632637eb8cb8dfae32e37eb8cb8dfae32e37eb8cbae3,0x48b2a36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32e3,0x1c2236ae32358c769aac30c708908721aae12daae12daae12daae12daae12daae12daae12daae12daaea84b0abaa884b,0x223203ac38c80c98dfae32c21c98dfae32e32237eb8cb0830891eb0c21e3203089087ac22232636ab8cb8daae32eb0c2,0x82083e232381f88c8e020838c81eb0838c80c22478df2e322326b083e231f80c7ac30e3]
    decide +kernel
  have e28366 : Deny 5 13 b28366 := by
    apply closeAction rule_sound _ _ 64 [0xd636ab8cb8daae32f58daae32c226b8c8d6b8daae32f51e32636ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32eb,0x8cb8daae32e36ab8cb8daae32eb8c80820826ab8c8e2b6ab8c8d6326b6ab8c81c9adaae322b6ab0c22421e32236ab8cb,0x6ab8cb8daae32eb8c81c269aada0820eb8498476ab84948b48b48b48b48b84a2122d22d22e12a36ab8cb8daae32e36ab,0x9a6ab69aadaac30c920848b48b48b48b48b48b48b84a2122d22d22d22d22e12a36ab8cb8daae32e36ab8cb8daae32e3,0x2]
    decide +kernel
  have e28204 : Deny 5 13 b28204 :=
    branchAction rule_sound _ _ 2
      0x223 b28204 b28205 b28366 (by decide +kernel) e28205 e28366
  have e28200 : Deny 5 13 b28200 :=
    branchAction rule_sound _ _ 1
      0xb b28200 b28201 b28204 (by decide +kernel) e28201 e28204
  have e28106 : Deny 5 13 b28106 :=
    branchAction rule_sound _ _ 1
      0x7 b28106 b28107 b28200 (by decide +kernel) e28107 e28200
  have e28022 : Deny 5 13 b28022 :=
    branchAction rule_sound _ _ 1
      0x9 b28022 b28023 b28106 (by decide +kernel) e28023 e28106
  have e27912 : Deny 5 13 b27912 :=
    branchAction rule_sound _ _ 2
      0x223 b27912 b27913 b28022 (by decide +kernel) e27913 e28022
  exact e27912
end OMA.Blocks5_13_245212.S27912
