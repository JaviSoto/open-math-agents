import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S62750
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b62750 : Box := ![⟨95,190⟩,⟨31,62⟩,⟨7,9⟩,⟨1,70⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨31,62⟩,⟨7,9⟩,⟨1,70⟩,⟨479,999999999999999999⟩] := by
  have e62750 : Deny 5 13 b62750 := by
    apply closeAction rule_sound _ _ 64 [0x25b6db4c3087e08e13e09e0ae0ae0a4ca0c2202244087e378c8e234cae368c76e7678df68c7088e278c21f8df6d23223,0x8db6db4c3e031f84f880980880a80a29329b9db0f80f81c3e202139602b829be372788c79e32132a32db0a580ae37d63,0xe02e021b2539602a02a78cb0f80f8de31f8088e230c38c70e76f8de31f88c82d32b88c22788c76db9cbe278c21f88c8,0x83e232389c30f82231c30f88c80f88c79e321b9e3087e372636dbe1b]
    decide +kernel
  exact e62750
end OMA.Blocks5_13_245212.S62750
