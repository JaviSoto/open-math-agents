import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S18499
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b18499 : Box := ![⟨23,30⟩,⟨31,1920000000000000011376⟩,⟨7,14⟩,⟨3,760851063829787238582⟩,⟨59,77⟩]
theorem deny5_13 : Deny 5 13 ![⟨23,30⟩,⟨31,1920000000000000011376⟩,⟨7,14⟩,⟨3,760851063829787238582⟩,⟨59,77⟩] := by
  have e18499 : Deny 5 13 b18499 := by
    apply closeAction rule_sound _ _ 64 [0x1f88c80c3e37da11c3e37db58470f8df6238d4a8c70c3e378c80f8de3243102278de3203d44087e37db58c7de3263204,0xf8dc427820a0c3e378c80f8df58c90c4088e37db51e3103dc38c80e32430f78c80f78c91c42c30f8de32440f8df68c4,0x1c30e322326311fdc3dc38c88c910b7c3e070f88c98c80c3203243087de12440f70c80e12430f784784910b0c3e37204,0x8c8ae32442eb8c86ab688adaadae378c8da311aada0c225ae37db584784a8c8ac42eb8c88c78c90f8aeaa2129f0c38c8,0x8c8ac38c8ae32631c42e32231daae311a238adaac3e03ac78c8ac30eb8c78c8682ae12ab8c98c40ab8420c7ac8ddaac3,0x8c8ac38c8ae325aac30f8ae326322b0eb0f8de32378c86828442b8deb8c98c78c40820c8ae12770ab0f8deb0c8237083,0x102082ac3207108e37083ae1107e37ac3e370e31e3223263108e1aae311aae3108e2b083ac4278deb0eb0e322321aac3,0x2ae3]
    decide +kernel
  exact e18499
end OMA.Blocks5_13_245212.S18499
