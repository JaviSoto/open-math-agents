import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S45305
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b45305 : Box := ![⟨191,1920000000000000011376⟩,⟨15,20⟩,⟨15,1920000000000000011376⟩,⟨1,1453959731543624169717⟩,⟨127,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨191,1920000000000000011376⟩,⟨15,20⟩,⟨15,1920000000000000011376⟩,⟨1,1453959731543624169717⟩,⟨127,233⟩] := by
  have e45305 : Deny 5 13 b45305 := by
    apply closeAction rule_sound _ _ 64 [0x108e199d99d90820992789e0260108e0466780427875d6678099e0109e04748e199e026022780a8c79e31e78c956688a,0x10b887888887e370a7767578de311d7552a02a3108e1d9e32631d52a31e32631020a6804578de6804238de6809dc42e3,0x2082578ddd54a54a115de2]
    decide +kernel
  exact e45305
end OMA.Blocks5_13_245212.S45305
