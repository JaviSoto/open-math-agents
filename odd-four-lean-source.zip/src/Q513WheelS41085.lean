import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S41085
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b41085 : Box := ![⟨47,94⟩,⟨21,30⟩,⟨15,30⟩,⟨1,900178041543026711610⟩,⟨239,999999999999999999⟩]
private def b41086 : Box := ![⟨47,62⟩,⟨21,30⟩,⟨15,30⟩,⟨1,51⟩,⟨239,1749⟩]
private def b41097 : Box := ![⟨63,94⟩,⟨21,30⟩,⟨15,30⟩,⟨1,51⟩,⟨239,1749⟩]
private def b41098 : Box := ![⟨63,94⟩,⟨21,30⟩,⟨15,30⟩,⟨1,45⟩,⟨239,420⟩]
private def b41099 : Box := ![⟨63,94⟩,⟨21,30⟩,⟨15,30⟩,⟨1,2⟩,⟨239,420⟩]
private def b41100 : Box := ![⟨63,94⟩,⟨21,30⟩,⟨15,30⟩,⟨3,44⟩,⟨239,420⟩]
private def b41101 : Box := ![⟨63,94⟩,⟨21,24⟩,⟨15,30⟩,⟨3,44⟩,⟨239,420⟩]
private def b41102 : Box := ![⟨63,75⟩,⟨21,24⟩,⟨17,30⟩,⟨3,43⟩,⟨239,389⟩]
private def b41103 : Box := ![⟨76,94⟩,⟨21,24⟩,⟨17,30⟩,⟨3,43⟩,⟨239,389⟩]
private def b41104 : Box := ![⟨76,94⟩,⟨21,24⟩,⟨17,21⟩,⟨3,43⟩,⟨239,389⟩]
private def b41105 : Box := ![⟨76,94⟩,⟨21,24⟩,⟨22,30⟩,⟨3,43⟩,⟨239,389⟩]
private def b41106 : Box := ![⟨76,94⟩,⟨21,24⟩,⟨22,30⟩,⟨3,43⟩,⟨239,296⟩]
private def b41107 : Box := ![⟨76,94⟩,⟨21,22⟩,⟨22,30⟩,⟨3,43⟩,⟨239,293⟩]
private def b41112 : Box := ![⟨76,94⟩,⟨23,24⟩,⟨22,30⟩,⟨3,43⟩,⟨239,293⟩]
private def b41121 : Box := ![⟨76,94⟩,⟨21,24⟩,⟨22,30⟩,⟨3,43⟩,⟨297,389⟩]
private def b41128 : Box := ![⟨63,94⟩,⟨25,30⟩,⟨15,30⟩,⟨3,44⟩,⟨239,420⟩]
private def b41129 : Box := ![⟨63,94⟩,⟨25,30⟩,⟨15,30⟩,⟨3,6⟩,⟨239,420⟩]
private def b41130 : Box := ![⟨63,75⟩,⟨25,30⟩,⟨15,30⟩,⟨3,6⟩,⟨239,420⟩]
private def b41131 : Box := ![⟨63,75⟩,⟨25,30⟩,⟨17,21⟩,⟨3,6⟩,⟨239,420⟩]
private def b41138 : Box := ![⟨63,75⟩,⟨25,30⟩,⟨22,30⟩,⟨3,6⟩,⟨239,420⟩]
private def b41139 : Box := ![⟨63,75⟩,⟨25,30⟩,⟨22,30⟩,⟨3,6⟩,⟨239,304⟩]
private def b41140 : Box := ![⟨63,75⟩,⟨25,27⟩,⟨22,30⟩,⟨3,6⟩,⟨239,293⟩]
private def b41147 : Box := ![⟨63,75⟩,⟨28,30⟩,⟨22,30⟩,⟨3,6⟩,⟨239,293⟩]
private def b41148 : Box := ![⟨63,75⟩,⟨28,30⟩,⟨22,30⟩,⟨3,4⟩,⟨239,293⟩]
private def b41149 : Box := ![⟨63,75⟩,⟨28,30⟩,⟨22,30⟩,⟨5,6⟩,⟨239,293⟩]
private def b41160 : Box := ![⟨63,75⟩,⟨25,30⟩,⟨22,30⟩,⟨3,6⟩,⟨305,420⟩]
private def b41161 : Box := ![⟨63,75⟩,⟨25,27⟩,⟨22,30⟩,⟨3,6⟩,⟨307,419⟩]
private def b41162 : Box := ![⟨63,75⟩,⟨28,30⟩,⟨22,30⟩,⟨3,6⟩,⟨307,419⟩]
private def b41163 : Box := ![⟨63,75⟩,⟨28,30⟩,⟨22,30⟩,⟨3,4⟩,⟨307,419⟩]
private def b41164 : Box := ![⟨63,75⟩,⟨28,30⟩,⟨22,30⟩,⟨5,6⟩,⟨307,419⟩]
private def b41175 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨15,30⟩,⟨3,6⟩,⟨239,420⟩]
private def b41176 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨15,20⟩,⟨3,6⟩,⟨239,420⟩]
private def b41177 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨15,20⟩,⟨3,6⟩,⟨239,304⟩]
private def b41178 : Box := ![⟨76,94⟩,⟨25,27⟩,⟨15,20⟩,⟨3,6⟩,⟨239,293⟩]
private def b41183 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨15,20⟩,⟨3,6⟩,⟨239,293⟩]
private def b41190 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨15,20⟩,⟨3,6⟩,⟨305,420⟩]
private def b41201 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨21,30⟩,⟨3,6⟩,⟨239,420⟩]
private def b41202 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨21,30⟩,⟨3,6⟩,⟨239,304⟩]
private def b41203 : Box := ![⟨76,94⟩,⟨25,27⟩,⟨21,30⟩,⟨3,6⟩,⟨239,293⟩]
private def b41214 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨21,30⟩,⟨3,6⟩,⟨239,293⟩]
private def b41225 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨21,30⟩,⟨3,6⟩,⟨305,420⟩]
private def b41226 : Box := ![⟨76,94⟩,⟨25,27⟩,⟨21,30⟩,⟨3,6⟩,⟨307,419⟩]
private def b41237 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨21,30⟩,⟨3,6⟩,⟨307,419⟩]
private def b41238 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨21,30⟩,⟨3,4⟩,⟨307,419⟩]
private def b41239 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨21,30⟩,⟨5,6⟩,⟨307,419⟩]
private def b41240 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨21,30⟩,⟨5,5⟩,⟨307,419⟩]
private def b41241 : Box := ![⟨76,84⟩,⟨28,30⟩,⟨21,30⟩,⟨5,5⟩,⟨307,419⟩]
private def b41248 : Box := ![⟨85,94⟩,⟨28,30⟩,⟨21,30⟩,⟨5,5⟩,⟨307,419⟩]
private def b41253 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨21,30⟩,⟨6,6⟩,⟨307,419⟩]
private def b41254 : Box := ![⟨63,94⟩,⟨25,30⟩,⟨15,30⟩,⟨7,44⟩,⟨239,420⟩]
private def b41255 : Box := ![⟨63,94⟩,⟨21,30⟩,⟨15,30⟩,⟨1,45⟩,⟨421,1744⟩]
private def b41256 : Box := ![⟨63,94⟩,⟨21,24⟩,⟨17,30⟩,⟨1,41⟩,⟨421,1740⟩]
private def b41257 : Box := ![⟨63,94⟩,⟨25,30⟩,⟨17,30⟩,⟨1,41⟩,⟨421,1740⟩]
private def b41258 : Box := ![⟨63,94⟩,⟨25,30⟩,⟨17,30⟩,⟨1,2⟩,⟨421,1740⟩]
private def b41259 : Box := ![⟨63,94⟩,⟨25,30⟩,⟨17,30⟩,⟨3,41⟩,⟨421,1740⟩]
private def b41260 : Box := ![⟨63,94⟩,⟨25,30⟩,⟨17,30⟩,⟨3,6⟩,⟨421,1740⟩]
private def b41261 : Box := ![⟨63,75⟩,⟨25,30⟩,⟨18,30⟩,⟨3,6⟩,⟨421,1538⟩]
private def b41266 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨18,30⟩,⟨3,6⟩,⟨421,1538⟩]
private def b41267 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨18,30⟩,⟨3,6⟩,⟨421,661⟩]
private def b41268 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨18,30⟩,⟨3,4⟩,⟨421,661⟩]
private def b41269 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨19,30⟩,⟨3,3⟩,⟨421,661⟩]
private def b41270 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨19,30⟩,⟨4,4⟩,⟨421,661⟩]
private def b41271 : Box := ![⟨76,94⟩,⟨25,27⟩,⟨19,30⟩,⟨4,4⟩,⟨421,661⟩]
private def b41278 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨19,30⟩,⟨4,4⟩,⟨421,661⟩]
private def b41279 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨19,23⟩,⟨4,4⟩,⟨421,661⟩]
private def b41282 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨24,30⟩,⟨4,4⟩,⟨421,661⟩]
private def b41293 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨18,30⟩,⟨5,6⟩,⟨421,661⟩]
private def b41294 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨18,30⟩,⟨3,6⟩,⟨662,1536⟩]
private def b41295 : Box := ![⟨76,94⟩,⟨25,27⟩,⟨22,30⟩,⟨3,6⟩,⟨662,1534⟩]
private def b41296 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨22,30⟩,⟨3,6⟩,⟨662,1534⟩]
private def b41307 : Box := ![⟨63,94⟩,⟨25,30⟩,⟨17,30⟩,⟨7,41⟩,⟨421,1740⟩]
private theorem e41086 : Deny 5 13 b41086 := by
    apply closeAction rule_sound _ _ 64 [0xdfe378c97f8df68c7088087102238df6d63]
    decide +kernel
private theorem e41099 : Deny 5 13 b41099 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e41102 : Deny 5 13 b41102 := by
    apply closeAction rule_sound _ _ 64 [0x1fe37da3]
    decide +kernel
private theorem e41104 : Deny 5 13 b41104 := by
    apply closeAction rule_sound _ _ 64 [0x1fe37da3]
    decide +kernel
private theorem e41107 : Deny 5 13 b41107 := by
    apply closeAction rule_sound _ _ 64 [0x37f8de3244778df68c41f8de3]
    decide +kernel
private theorem e41112 : Deny 5 13 b41112 := by
    apply closeAction rule_sound _ _ 64 [0x7c30f824311fe37109e361ca]
    decide +kernel
private theorem e41106 : Deny 5 13 b41106 :=
    branchAction rule_sound _ _ 2
      0x204 b41106 b41107 b41112 (by decide +kernel) e41107 e41112
private theorem e41121 : Deny 5 13 b41121 := by
    apply closeAction rule_sound _ _ 64 [0x37f8de325de37da31c4088e378c4]
    decide +kernel
private theorem e41105 : Deny 5 13 b41105 :=
    branchAction rule_sound _ _ 1
      0xb b41105 b41106 b41121 (by decide +kernel) e41106 e41121
private theorem e41103 : Deny 5 13 b41103 :=
    branchAction rule_sound _ _ 1
      0x9 b41103 b41104 b41105 (by decide +kernel) e41104 e41105
private theorem e41101 : Deny 5 13 b41101 :=
    branchAction rule_sound _ _ 4
      0x1f8da3 b41101 b41102 b41103 (by decide +kernel) e41102 e41103
private theorem e41131 : Deny 5 13 b41131 := by
    apply closeAction rule_sound _ _ 64 [0x37f8dc9087102238]
    decide +kernel
private theorem e41140 : Deny 5 13 b41140 := by
    apply closeAction rule_sound _ _ 64 [0x30f8df6203e37243e37d87]
    decide +kernel
private theorem e41148 : Deny 5 13 b41148 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e41149 : Deny 5 13 b41149 := by
    apply closeAction rule_sound _ _ 64 [0x7c3e040c41f80c90c3e091ca]
    decide +kernel
private theorem e41147 : Deny 5 13 b41147 :=
    branchAction rule_sound _ _ 1
      0xa b41147 b41148 b41149 (by decide +kernel) e41148 e41149
private theorem e41139 : Deny 5 13 b41139 :=
    branchAction rule_sound _ _ 2
      0x204 b41139 b41140 b41147 (by decide +kernel) e41140 e41147
private theorem e41161 : Deny 5 13 b41161 := by
    apply closeAction rule_sound _ _ 64 [0x7f8df6]
    decide +kernel
private theorem e41163 : Deny 5 13 b41163 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e41164 : Deny 5 13 b41164 := by
    apply closeAction rule_sound _ _ 64 [0x1f7c30c70f8243e361ca10b]
    decide +kernel
private theorem e41162 : Deny 5 13 b41162 :=
    branchAction rule_sound _ _ 1
      0xa b41162 b41163 b41164 (by decide +kernel) e41163 e41164
private theorem e41160 : Deny 5 13 b41160 :=
    branchAction rule_sound _ _ 2
      0x204 b41160 b41161 b41162 (by decide +kernel) e41161 e41162
private theorem e41138 : Deny 5 13 b41138 :=
    branchAction rule_sound _ _ 1
      0xb b41138 b41139 b41160 (by decide +kernel) e41139 e41160
private theorem e41130 : Deny 5 13 b41130 :=
    branchAction rule_sound _ _ 2
      0x276 b41130 b41131 b41138 (by decide +kernel) e41131 e41138
private theorem e41178 : Deny 5 13 b41178 := by
    apply closeAction rule_sound _ _ 64 [0xc3e37243e37d87]
    decide +kernel
private theorem e41183 : Deny 5 13 b41183 := by
    apply closeAction rule_sound _ _ 64 [0xc31c30f81c9]
    decide +kernel
private theorem e41177 : Deny 5 13 b41177 :=
    branchAction rule_sound _ _ 2
      0x204 b41177 b41178 b41183 (by decide +kernel) e41178 e41183
private theorem e41190 : Deny 5 13 b41190 := by
    apply closeAction rule_sound _ _ 64 [0x30f8dc90f8df61c3e362031021f8df6204]
    decide +kernel
private theorem e41176 : Deny 5 13 b41176 :=
    branchAction rule_sound _ _ 1
      0xb b41176 b41177 b41190 (by decide +kernel) e41177 e41190
private theorem e41203 : Deny 5 13 b41203 := by
    apply closeAction rule_sound _ _ 64 [0xf80c70c80c31c3207]
    decide +kernel
private theorem e41214 : Deny 5 13 b41214 := by
    apply closeAction rule_sound _ _ 64 [0x17e377c20c9e0320ae17287]
    decide +kernel
private theorem e41202 : Deny 5 13 b41202 :=
    branchAction rule_sound _ _ 2
      0x204 b41202 b41203 b41214 (by decide +kernel) e41203 e41214
private theorem e41226 : Deny 5 13 b41226 := by
    apply closeAction rule_sound _ _ 64 [0xc31c3e362030f8dc911fe37d84238d87]
    decide +kernel
private theorem e41238 : Deny 5 13 b41238 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e41241 : Deny 5 13 b41241 := by
    apply closeAction rule_sound _ _ 64 [0x7c30c70c810b]
    decide +kernel
private theorem e41248 : Deny 5 13 b41248 := by
    apply closeAction rule_sound _ _ 64 [0x1fe03e03209]
    decide +kernel
private theorem e41240 : Deny 5 13 b41240 :=
    branchAction rule_sound _ _ 1
      0x7 b41240 b41241 b41248 (by decide +kernel) e41241 e41248
private theorem e41253 : Deny 5 13 b41253 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e41239 : Deny 5 13 b41239 :=
    branchAction rule_sound _ _ 1
      0xa b41239 b41240 b41253 (by decide +kernel) e41240 e41253
private theorem e41237 : Deny 5 13 b41237 :=
    branchAction rule_sound _ _ 1
      0xa b41237 b41238 b41239 (by decide +kernel) e41238 e41239
private theorem e41225 : Deny 5 13 b41225 :=
    branchAction rule_sound _ _ 2
      0x204 b41225 b41226 b41237 (by decide +kernel) e41226 e41237
private theorem e41201 : Deny 5 13 b41201 :=
    branchAction rule_sound _ _ 1
      0xb b41201 b41202 b41225 (by decide +kernel) e41202 e41225
private theorem e41175 : Deny 5 13 b41175 :=
    branchAction rule_sound _ _ 1
      0x9 b41175 b41176 b41201 (by decide +kernel) e41176 e41201
private theorem e41129 : Deny 5 13 b41129 :=
    branchAction rule_sound _ _ 1
      0x7 b41129 b41130 b41175 (by decide +kernel) e41130 e41175
private theorem e41254 : Deny 5 13 b41254 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e41128 : Deny 5 13 b41128 :=
    branchAction rule_sound _ _ 1
      0xa b41128 b41129 b41254 (by decide +kernel) e41129 e41254
private theorem e41100 : Deny 5 13 b41100 :=
    branchAction rule_sound _ _ 1
      0x8 b41100 b41101 b41128 (by decide +kernel) e41101 e41128
private theorem e41098 : Deny 5 13 b41098 :=
    branchAction rule_sound _ _ 2
      0x2a3 b41098 b41099 b41100 (by decide +kernel) e41099 e41100
private theorem e41256 : Deny 5 13 b41256 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e41258 : Deny 5 13 b41258 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e41261 : Deny 5 13 b41261 := by
    apply closeAction rule_sound _ _ 64 [0x1f5ca102238df6]
    decide +kernel
private theorem e41269 : Deny 5 13 b41269 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e41271 : Deny 5 13 b41271 := by
    apply closeAction rule_sound _ _ 64 [0x3e03e09088087e36]
    decide +kernel
private theorem e41279 : Deny 5 13 b41279 := by
    apply closeAction rule_sound _ _ 64 [0x5c2238]
    decide +kernel
private theorem e41282 : Deny 5 13 b41282 := by
    apply closeAction rule_sound _ _ 64 [0xf80c80c90c3e070f8247]
    decide +kernel
private theorem e41278 : Deny 5 13 b41278 :=
    branchAction rule_sound _ _ 1
      0x9 b41278 b41279 b41282 (by decide +kernel) e41279 e41282
private theorem e41270 : Deny 5 13 b41270 :=
    branchAction rule_sound _ _ 1
      0x8 b41270 b41271 b41278 (by decide +kernel) e41271 e41278
private theorem e41268 : Deny 5 13 b41268 :=
    branchAction rule_sound _ _ 2
      0x2b6 b41268 b41269 b41270 (by decide +kernel) e41269 e41270
private theorem e41293 : Deny 5 13 b41293 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e41267 : Deny 5 13 b41267 :=
    branchAction rule_sound _ _ 1
      0xa b41267 b41268 b41293 (by decide +kernel) e41268 e41293
private theorem e41295 : Deny 5 13 b41295 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e41296 : Deny 5 13 b41296 := by
    apply closeAction rule_sound _ _ 64 [0x7c3e03e09e03e362380f8d875cae362b8]
    decide +kernel
private theorem e41294 : Deny 5 13 b41294 :=
    branchAction rule_sound _ _ 3
      0x8e36 b41294 b41295 b41296 (by decide +kernel) e41295 e41296
private theorem e41266 : Deny 5 13 b41266 :=
    branchAction rule_sound _ _ 2
      0x2f8 b41266 b41267 b41294 (by decide +kernel) e41267 e41294
private theorem e41260 : Deny 5 13 b41260 :=
    branchAction rule_sound _ _ 3
      0x7e36 b41260 b41261 b41266 (by decide +kernel) e41261 e41266
private theorem e41307 : Deny 5 13 b41307 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e41259 : Deny 5 13 b41259 :=
    branchAction rule_sound _ _ 1
      0xa b41259 b41260 b41307 (by decide +kernel) e41260 e41307
private theorem e41257 : Deny 5 13 b41257 :=
    branchAction rule_sound _ _ 1
      0xa b41257 b41258 b41259 (by decide +kernel) e41258 e41259
private theorem e41255 : Deny 5 13 b41255 :=
    branchAction rule_sound _ _ 4
      0x238da3 b41255 b41256 b41257 (by decide +kernel) e41256 e41257
private theorem e41097 : Deny 5 13 b41097 :=
    branchAction rule_sound _ _ 3
      0xbe23 b41097 b41098 b41255 (by decide +kernel) e41098 e41255
private theorem e41085 : Deny 5 13 b41085 :=
    branchAction rule_sound _ _ 3
      0x7e23 b41085 b41086 b41097 (by decide +kernel) e41086 e41097
theorem deny5_13 : Deny 5 13 ![⟨47,94⟩,⟨21,30⟩,⟨15,30⟩,⟨1,900178041543026711610⟩,⟨239,999999999999999999⟩] := by
  exact e41085
end OMA.Blocks5_13_245212.S41085
