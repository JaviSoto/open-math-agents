import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S19633
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b19633 : Box := ![⟨23,26⟩,⟨31,62⟩,⟨15,30⟩,⟨3,55⟩,⟨59,73⟩]
theorem deny5_13 : Deny 5 13 ![⟨23,26⟩,⟨31,62⟩,⟨15,30⟩,⟨3,55⟩,⟨59,73⟩] := by
  have e19633 : Deny 5 13 b19633 := by
    apply closeAction rule_sound _ _ 64 [0xde1243e37d882872442c30f8dc90f8df62021f7d840f70c90c80c3dc90f8df62371c30f7d880b8df6d47dc910be082a3,0xdf6203e37db51c91160f8dc3209dc20c90c32085830f7209287083109e370c32480c38490c32482830c90c3e092030f8,0x278dc32370f70e32438c81c30e32030f78c88c78c910b8c85832432430f7208583243e090c4087e37d88dc70c3dc90f8,0x83248dc3dc32770f70e32632078c910b0c38c90e321e0f8d8a0f8df68c8de31c30f8df68c80b8df6d631e32631020c4,0xe3223203e370e31c38c90c38c88c81c3dc38c90c38c98c80c3de3243103e378c4278de32231e32631020820c7207dc2,0x83109e370f7]
    decide +kernel
  exact e19633
end OMA.Blocks5_13_245212.S19633
