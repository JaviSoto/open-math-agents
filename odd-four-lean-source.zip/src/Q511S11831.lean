import FastReplay245212
import SparseDigit245212
import FastRound245212
import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S11831
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b11831 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨15,30⟩,⟨1,864390243902439029553⟩,⟨207,999999999999999999⟩]
private def b11832 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨15,30⟩,⟨1,46⟩,⟨207,414⟩]
private def b11833 : Box := ![⟨18,19⟩,⟨31,62⟩,⟨15,30⟩,⟨1,39⟩,⟨207,414⟩]
private def b11834 : Box := ![⟨18,19⟩,⟨31,41⟩,⟨15,30⟩,⟨1,39⟩,⟨207,414⟩]
private def b11839 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨15,30⟩,⟨1,39⟩,⟨207,414⟩]
private def b11840 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨15,20⟩,⟨1,39⟩,⟨207,414⟩]
private def b11845 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨21,30⟩,⟨1,39⟩,⟨207,414⟩]
private def b11846 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨21,30⟩,⟨1,2⟩,⟨207,414⟩]
private def b11847 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨21,30⟩,⟨3,39⟩,⟨207,414⟩]
private def b11848 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨21,30⟩,⟨3,39⟩,⟨207,276⟩]
private def b11857 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨21,30⟩,⟨3,39⟩,⟨277,414⟩]
private def b11866 : Box := ![⟨20,22⟩,⟨31,62⟩,⟨15,30⟩,⟨1,39⟩,⟨207,414⟩]
private def b11867 : Box := ![⟨20,22⟩,⟨31,41⟩,⟨15,30⟩,⟨1,39⟩,⟨207,414⟩]
private def b11868 : Box := ![⟨20,22⟩,⟨31,41⟩,⟨15,20⟩,⟨1,33⟩,⟨207,414⟩]
private def b11871 : Box := ![⟨20,22⟩,⟨31,41⟩,⟨21,30⟩,⟨1,33⟩,⟨207,414⟩]
private def b11872 : Box := ![⟨20,22⟩,⟨31,41⟩,⟨21,30⟩,⟨1,33⟩,⟨207,276⟩]
private def b11873 : Box := ![⟨20,22⟩,⟨31,41⟩,⟨21,30⟩,⟨1,2⟩,⟨211,271⟩]
private def b11882 : Box := ![⟨20,22⟩,⟨31,41⟩,⟨21,30⟩,⟨3,33⟩,⟨211,271⟩]
private def b11891 : Box := ![⟨20,22⟩,⟨31,41⟩,⟨21,30⟩,⟨1,33⟩,⟨277,414⟩]
private def b11900 : Box := ![⟨20,22⟩,⟨42,62⟩,⟨15,30⟩,⟨1,39⟩,⟨207,414⟩]
private def b11901 : Box := ![⟨20,22⟩,⟨42,62⟩,⟨15,20⟩,⟨1,39⟩,⟨207,414⟩]
private def b11902 : Box := ![⟨20,22⟩,⟨42,62⟩,⟨15,20⟩,⟨1,35⟩,⟨207,276⟩]
private def b11903 : Box := ![⟨20,22⟩,⟨42,62⟩,⟨15,20⟩,⟨1,2⟩,⟨211,271⟩]
private def b11908 : Box := ![⟨20,22⟩,⟨42,62⟩,⟨15,20⟩,⟨3,35⟩,⟨211,271⟩]
private def b11919 : Box := ![⟨20,22⟩,⟨42,62⟩,⟨15,20⟩,⟨1,35⟩,⟨277,414⟩]
private def b11930 : Box := ![⟨20,22⟩,⟨42,62⟩,⟨21,30⟩,⟨1,39⟩,⟨207,414⟩]
private def b11931 : Box := ![⟨20,22⟩,⟨42,62⟩,⟨21,30⟩,⟨1,39⟩,⟨207,276⟩]
private def b11942 : Box := ![⟨20,22⟩,⟨42,62⟩,⟨21,30⟩,⟨1,39⟩,⟨277,414⟩]
private def b11955 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨15,30⟩,⟨1,46⟩,⟨415,999999999999999999⟩]
private def b11956 : Box := ![⟨18,19⟩,⟨31,62⟩,⟨15,30⟩,⟨1,41⟩,⟨415,999999999999999999⟩]
private def b11961 : Box := ![⟨20,22⟩,⟨31,62⟩,⟨15,30⟩,⟨1,41⟩,⟨415,999999999999999999⟩]
private def b11962 : Box := ![⟨20,22⟩,⟨31,41⟩,⟨15,30⟩,⟨1,41⟩,⟨415,999999999999999999⟩]
private def b11969 : Box := ![⟨20,22⟩,⟨42,62⟩,⟨15,30⟩,⟨1,41⟩,⟨415,999999999999999999⟩]
private def b11970 : Box := ![⟨20,22⟩,⟨42,62⟩,⟨15,20⟩,⟨1,41⟩,⟨415,999999999999999999⟩]
private def b11985 : Box := ![⟨20,22⟩,⟨42,62⟩,⟨21,30⟩,⟨1,41⟩,⟨415,999999999999999999⟩]
private def b11986 : Box := ![⟨20,22⟩,⟨42,62⟩,⟨21,30⟩,⟨1,41⟩,⟨415,830⟩]
private def b11999 : Box := ![⟨20,22⟩,⟨42,62⟩,⟨21,30⟩,⟨1,41⟩,⟨831,999999999999999999⟩]
theorem deny5_11 : Deny 5 11 ![⟨18,22⟩,⟨31,62⟩,⟨15,30⟩,⟨1,864390243902439029553⟩,⟨207,999999999999999999⟩] := by
  have e11834 : Deny 5 11 b11834 := by
    apply closeAction rule_sound _ _ 64 [0x3087d84088e37da3]
    decide +kernel
  have e11840 : Deny 5 11 b11840 := by
    apply closeAction rule_sound _ _ 64 [0xc21c40f8df68c4238de3]
    decide +kernel
  have e11846 : Deny 5 11 b11846 := by
    apply closeAction rule_sound _ _ 64 [0x16]
    decide +kernel
  have e11848 : Deny 5 11 b11848 := by
    apply closeAction rule_sound _ _ 64 [0xf8dc38c70e32430f8df61e3204]
    decide +kernel
  have e11857 : Deny 5 11 b11857 := by
    apply closeAction rule_sound _ _ 64 [0x30f88c90f8df61c31021f8da3223]
    decide +kernel
  have e11847 : Deny 5 11 b11847 :=
    branchAction rule_sound _ _ 1
      0xb b11847 b11848 b11857 (by decide +kernel) e11848 e11857
  have e11845 : Deny 5 11 b11845 :=
    branchAction rule_sound _ _ 1
      0xa b11845 b11846 b11847 (by decide +kernel) e11846 e11847
  have e11839 : Deny 5 11 b11839 :=
    branchAction rule_sound _ _ 1
      0x9 b11839 b11840 b11845 (by decide +kernel) e11840 e11845
  have e11833 : Deny 5 11 b11833 :=
    branchAction rule_sound _ _ 1
      0x8 b11833 b11834 b11839 (by decide +kernel) e11834 e11839
  have e11868 : Deny 5 11 b11868 := by
    apply closeAction rule_sound _ _ 64 [0x30f8de3263]
    decide +kernel
  have e11873 : Deny 5 11 b11873 := by
    apply closeAction rule_sound _ _ 64 [0x160c90c858a587]
    decide +kernel
  have e11882 : Deny 5 11 b11882 := by
    apply closeAction rule_sound _ _ 64 [0x20c41f8dc38c80c38c88c7]
    decide +kernel
  have e11872 : Deny 5 11 b11872 :=
    branchAction rule_sound _ _ 2
      0x284 b11872 b11873 b11882 (by decide +kernel) e11873 e11882
  have e11891 : Deny 5 11 b11891 := by
    apply closeAction rule_sound _ _ 64 [0x30e32438c80c4088e371e3]
    decide +kernel
  have e11871 : Deny 5 11 b11871 :=
    branchAction rule_sound _ _ 1
      0xb b11871 b11872 b11891 (by decide +kernel) e11872 e11891
  have e11867 : Deny 5 11 b11867 :=
    branchAction rule_sound _ _ 2
      0x263 b11867 b11868 b11871 (by decide +kernel) e11868 e11871
  have e11903 : Deny 5 11 b11903 := by
    apply closeAction rule_sound _ _ 64 [0x30e1243e37da11e1]
    decide +kernel
  have e11908 : Deny 5 11 b11908 := by
    apply closeAction rule_sound _ _ 64 [0x83109e370f8dc38c98c80c38c88c7]
    decide +kernel
  have e11902 : Deny 5 11 b11902 :=
    branchAction rule_sound _ _ 2
      0x284 b11902 b11903 b11908 (by decide +kernel) e11903 e11908
  have e11919 : Deny 5 11 b11919 := by
    apply closeAction rule_sound _ _ 64 [0x3dc38c90c38c98c80c3e37da32371e3]
    decide +kernel
  have e11901 : Deny 5 11 b11901 :=
    branchAction rule_sound _ _ 2
      0x2e3 b11901 b11902 b11919 (by decide +kernel) e11902 e11919
  have e11931 : Deny 5 11 b11931 := by
    apply closeAction rule_sound _ _ 64 [0x20838c81c2587587284]
    decide +kernel
  have e11942 : Deny 5 11 b11942 := by
    apply closeAction rule_sound _ _ 64 [0x16e375b70e3263203e370f88c9e038c858a1e3]
    decide +kernel
  have e11930 : Deny 5 11 b11930 :=
    branchAction rule_sound _ _ 1
      0xb b11930 b11931 b11942 (by decide +kernel) e11931 e11942
  have e11900 : Deny 5 11 b11900 :=
    branchAction rule_sound _ _ 1
      0x9 b11900 b11901 b11930 (by decide +kernel) e11901 e11930
  have e11866 : Deny 5 11 b11866 :=
    branchAction rule_sound _ _ 1
      0x8 b11866 b11867 b11900 (by decide +kernel) e11867 e11900
  have e11832 : Deny 5 11 b11832 :=
    branchAction rule_sound _ _ 2
      0x1e3 b11832 b11833 b11866 (by decide +kernel) e11833 e11866
  have e11956 : Deny 5 11 b11956 := by
    apply closeAction rule_sound _ _ 64 [0xc21f88c2238df6d63]
    decide +kernel
  have e11962 : Deny 5 11 b11962 := by
    apply closeAction rule_sound _ _ 64 [0xc3e37d87e03e37da32388c21f8da3]
    decide +kernel
  have e11970 : Deny 5 11 b11970 := by
    apply closeAction rule_sound _ _ 64 [0x30f8de3243e37da32230c38c90c3e378c98c88cb0f8df6d631e3]
    decide +kernel
  have e11986 : Deny 5 11 b11986 := by
    apply closeAction rule_sound _ _ 64 [0x16e370e32430c78c80c3e378c90f8df68c81e3]
    decide +kernel
  have e11999 : Deny 5 11 b11999 := by
    apply closeAction rule_sound _ _ 64 [0x831c38c90c3e368c78c80f88c2238db51e3]
    decide +kernel
  have e11985 : Deny 5 11 b11985 :=
    branchAction rule_sound _ _ 1
      0xb b11985 b11986 b11999 (by decide +kernel) e11986 e11999
  have e11969 : Deny 5 11 b11969 :=
    branchAction rule_sound _ _ 1
      0x9 b11969 b11970 b11985 (by decide +kernel) e11970 e11985
  have e11961 : Deny 5 11 b11961 :=
    branchAction rule_sound _ _ 1
      0x8 b11961 b11962 b11969 (by decide +kernel) e11962 e11969
  have e11955 : Deny 5 11 b11955 :=
    branchAction rule_sound _ _ 2
      0x1e3 b11955 b11956 b11961 (by decide +kernel) e11956 e11961
  have e11831 : Deny 5 11 b11831 :=
    branchAction rule_sound _ _ 2
      0x2e3 b11831 b11832 b11955 (by decide +kernel) e11832 e11955
  exact e11831
end OMA.Blocks5_11_245212.S11831
