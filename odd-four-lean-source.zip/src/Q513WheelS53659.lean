import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S53659
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b53659 : Box := ![⟨63,94⟩,⟨63,1920000000000000011376⟩,⟨7,14⟩,⟨1,640000000000000003833⟩,⟨127,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨63,1920000000000000011376⟩,⟨7,14⟩,⟨1,640000000000000003833⟩,⟨127,233⟩] := by
  have e53659 : Deny 5 13 b53659 := by
    apply closeAction rule_sound _ _ 64 [0x4f8dc20832442384ca4f710b1c4238ddb6c20f80e11e11c30c72040820c72042e12a110ae132a32631c42e322325384a,0xe370c92072934c31d32472842e321b6db4ca087088103e0321b0f884a8470c21c88442f884a84a4ca8c98c78c44f8dc2,0xe2b8498442b8adb6c20c42780f80f824828a4ca6db0f80f82430f8dc920a2930c74c92a31e311b0820c9238083109e03,0x824f8dc32072212611e1108e370ab8c46eb8c4238adb6c20824c31c91c42384c984a29329be23113e370f8103ae1107,0x2082]
    decide +kernel
  exact e53659
end OMA.Blocks5_13_245212.S53659
