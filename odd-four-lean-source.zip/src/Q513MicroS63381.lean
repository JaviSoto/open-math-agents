import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S63381
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b63381 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨12,14⟩,⟨1,51⟩,⟨959,999999999999999999⟩]
private def b63382 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨12,14⟩,⟨2,51⟩,⟨959,1918⟩]
private def b63383 : Box := ![⟨153,190⟩,⟨31,32⟩,⟨12,14⟩,⟨9,46⟩,⟨959,1918⟩]
private def b63388 : Box := ![⟨153,190⟩,⟨33,35⟩,⟨12,14⟩,⟨9,46⟩,⟨959,1918⟩]
private def b63397 : Box := ![⟨153,190⟩,⟨31,35⟩,⟨12,14⟩,⟨2,51⟩,⟨1919,999999999999999999⟩]
private theorem e63383 : Deny 5 13 b63383 := by
    apply closeAction rule_sound _ _ 64 [0x39c3e231c2263]
    decide +kernel
private theorem e63388 : Deny 5 13 b63388 := by
    apply closeAction rule_sound _ _ 64 [0x3e270f88c7e032039c3e231f88c9]
    decide +kernel
private theorem e63382 : Deny 5 13 b63382 :=
    branchAction rule_sound _ _ 3
      0x89e3 b63382 b63383 b63388 (by decide +kernel) e63383 e63388
private theorem e63397 : Deny 5 13 b63397 := by
    apply closeAction rule_sound _ _ 64 [0xc38c70f8203e278c21f8202263]
    decide +kernel
private theorem e63381 : Deny 5 13 b63381 :=
    branchAction rule_sound _ _ 2
      0x2e7 b63381 b63382 b63397 (by decide +kernel) e63382 e63397
theorem deny5_13 : Deny 5 13 ![⟨153,190⟩,⟨31,35⟩,⟨12,14⟩,⟨1,51⟩,⟨959,999999999999999999⟩] := by
  exact e63381
end OMA.Blocks5_13_245212.S63381
