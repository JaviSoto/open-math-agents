import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S46224
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b46224 : Box := ![⟨95,190⟩,⟨18,20⟩,⟨31,62⟩,⟨1,799016681299385430601⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨18,20⟩,⟨31,62⟩,⟨1,799016681299385430601⟩,⟨479,999999999999999999⟩] := by
  have e46224 : Deny 5 13 b46224 := by
    apply closeAction rule_sound _ _ 64 [0x9c39c38c7778df62231c42c222325d7550c3e090881021f82762b6295d8a088da31cbe1d54a1021f8df68c7e2354ae23,0x75d55554324957820954b54828a54a75d0c3e070f88090a024a295e37da680a0888dd743e03e202038099a02959a028a,0x1d7550c3e090f8d87088087e09578d87e0ae36295e36282238da3]
    decide +kernel
  exact e46224
end OMA.Blocks5_13_245212.S46224
