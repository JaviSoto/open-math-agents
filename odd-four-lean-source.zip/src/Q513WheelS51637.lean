import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S51637
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b51637 : Box := ![⟨191,382⟩,⟨21,22⟩,⟨21,30⟩,⟨3,85⟩,⟨959,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨191,382⟩,⟨21,22⟩,⟨21,30⟩,⟨3,85⟩,⟨959,999999999999999999⟩] := by
  have e51637 : Deny 5 13 b51637 := by
    apply closeAction rule_sound _ _ 64 [0xe09e039c22789c9e0ae27742278da31f8088e237596670f81e70c22381e02a78c99e32f8667087e278c9e278d12b88c7,0x9e32e36678cb8d99e32e36678cb8d99e32e36678cb8d99e32e36678cbda36678cbda36678cb8d99e32e36678cb9d975d,0x80b0a79a02c29e680b0602e02a36678cb8d99e32e36678cb8d99e32e36678cb8d99e32e36678cb8d99e32e36678cb8d9,0x65908380908880a9c30c90881d99c21e70879e02599e02d99e02d99e6]
    decide +kernel
  exact e51637
end OMA.Blocks5_13_245212.S51637
