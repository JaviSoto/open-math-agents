import FastReplay245212
import SparseDigit245212
import FastRound245212
import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S9450
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b9450 : Box := ![⟨15,22⟩,⟨31,1920000000000000011376⟩,⟨7,14⟩,⟨1,1664000000000000009895⟩,⟨103,999999999999999999⟩]
private def b9451 : Box := ![⟨15,17⟩,⟨31,1920000000000000011376⟩,⟨7,14⟩,⟨1,669192982456140354875⟩,⟨103,999999999999999999⟩]
private def b9452 : Box := ![⟨15,17⟩,⟨34,1920000000000000011376⟩,⟨7,14⟩,⟨1,2⟩,⟨103,245⟩]
private def b9453 : Box := ![⟨15,17⟩,⟨34,1920000000000000011376⟩,⟨7,14⟩,⟨3,669192982456140354874⟩,⟨103,245⟩]
private def b9454 : Box := ![⟨15,17⟩,⟨35,1920000000000000011376⟩,⟨7,14⟩,⟨3,6⟩,⟨103,245⟩]
private def b9455 : Box := ![⟨15,17⟩,⟨35,1920000000000000011376⟩,⟨7,14⟩,⟨7,669192982456140354866⟩,⟨103,245⟩]
private def b9456 : Box := ![⟨15,17⟩,⟨35,70⟩,⟨7,14⟩,⟨7,669192982456140354866⟩,⟨103,245⟩]
private def b9465 : Box := ![⟨15,17⟩,⟨71,1920000000000000011376⟩,⟨7,14⟩,⟨7,669192982456140354866⟩,⟨103,245⟩]
private def b9466 : Box := ![⟨15,17⟩,⟨71,1920000000000000011376⟩,⟨7,9⟩,⟨7,669192982456140354866⟩,⟨103,245⟩]
private def b9469 : Box := ![⟨15,17⟩,⟨71,1920000000000000011376⟩,⟨10,14⟩,⟨7,669192982456140354866⟩,⟨103,245⟩]
private def b9470 : Box := ![⟨15,17⟩,⟨71,1920000000000000011376⟩,⟨10,14⟩,⟨7,669192982456140354866⟩,⟨103,145⟩]
private def b9471 : Box := ![⟨15,15⟩,⟨71,1920000000000000011376⟩,⟨10,14⟩,⟨7,669192982456140354866⟩,⟨103,139⟩]
private def b9474 : Box := ![⟨16,17⟩,⟨71,1920000000000000011376⟩,⟨10,14⟩,⟨7,669192982456140354866⟩,⟨103,139⟩]
private def b9487 : Box := ![⟨15,17⟩,⟨71,1920000000000000011376⟩,⟨10,14⟩,⟨7,669192982456140354866⟩,⟨146,245⟩]
private def b9494 : Box := ![⟨18,22⟩,⟨31,1920000000000000011376⟩,⟨7,14⟩,⟨1,669192982456140354875⟩,⟨103,999999999999999999⟩]
private def b9495 : Box := ![⟨18,22⟩,⟨31,1920000000000000011376⟩,⟨7,14⟩,⟨1,669192982456140354875⟩,⟨103,206⟩]
private def b9496 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨7,14⟩,⟨1,669192982456140354867⟩,⟨103,199⟩]
private def b9497 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨7,9⟩,⟨1,37⟩,⟨103,199⟩]
private def b9508 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨10,14⟩,⟨1,37⟩,⟨103,199⟩]
private def b9509 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨10,14⟩,⟨1,2⟩,⟨103,199⟩]
private def b9516 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨10,14⟩,⟨3,37⟩,⟨103,199⟩]
private def b9517 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨10,14⟩,⟨3,37⟩,⟨103,135⟩]
private def b9518 : Box := ![⟨18,19⟩,⟨31,62⟩,⟨10,14⟩,⟨3,37⟩,⟨103,131⟩]
private def b9527 : Box := ![⟨20,22⟩,⟨31,62⟩,⟨10,14⟩,⟨3,37⟩,⟨103,131⟩]
private def b9540 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨10,14⟩,⟨3,37⟩,⟨136,199⟩]
private def b9541 : Box := ![⟨18,19⟩,⟨31,62⟩,⟨10,14⟩,⟨3,35⟩,⟨137,199⟩]
private def b9546 : Box := ![⟨20,22⟩,⟨31,62⟩,⟨10,14⟩,⟨3,35⟩,⟨137,199⟩]
private def b9559 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨7,14⟩,⟨1,669192982456140354867⟩,⟨103,199⟩]
private def b9560 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨7,14⟩,⟨1,2⟩,⟨103,199⟩]
private def b9561 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨7,14⟩,⟨3,669192982456140354867⟩,⟨103,199⟩]
private def b9562 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨7,14⟩,⟨3,6⟩,⟨103,199⟩]
private def b9563 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨7,14⟩,⟨7,669192982456140354867⟩,⟨103,199⟩]
private def b9564 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨7,669192982456140354867⟩,⟨103,199⟩]
private def b9565 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨7,669192982456140354864⟩,⟨103,135⟩]
private def b9566 : Box := ![⟨18,19⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨7,669192982456140354864⟩,⟨103,131⟩]
private def b9573 : Box := ![⟨20,22⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨7,669192982456140354864⟩,⟨103,131⟩]
private def b9584 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨7,669192982456140354864⟩,⟨136,199⟩]
private def b9585 : Box := ![⟨18,19⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨7,630132158590308373799⟩,⟨137,199⟩]
private def b9590 : Box := ![⟨20,22⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨7,630132158590308373799⟩,⟨137,199⟩]
private def b9603 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨7,669192982456140354867⟩,⟨103,199⟩]
private def b9604 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨7,669192982456140354867⟩,⟨103,135⟩]
private def b9617 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨7,669192982456140354867⟩,⟨136,199⟩]
private def b9618 : Box := ![⟨18,19⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨7,630132158590308373801⟩,⟨137,199⟩]
private def b9619 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨10,14⟩,⟨7,630132158590308373800⟩,⟨137,199⟩]
private def b9620 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨10,11⟩,⟨7,55⟩,⟨137,199⟩]
private def b9623 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨12,14⟩,⟨7,55⟩,⟨137,199⟩]
private def b9624 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨12,14⟩,⟨7,55⟩,⟨137,162⟩]
private def b9631 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨12,14⟩,⟨7,55⟩,⟨163,199⟩]
private def b9640 : Box := ![⟨18,19⟩,⟨127,1920000000000000011376⟩,⟨10,14⟩,⟨7,630132158590308373800⟩,⟨137,199⟩]
private def b9643 : Box := ![⟨20,22⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨7,630132158590308373801⟩,⟨137,199⟩]
private def b9656 : Box := ![⟨18,22⟩,⟨31,1920000000000000011376⟩,⟨7,14⟩,⟨1,669192982456140354875⟩,⟨207,999999999999999999⟩]
private def b9657 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨7,14⟩,⟨1,581463414634146344937⟩,⟨207,999999999999999999⟩]
private def b9670 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨7,14⟩,⟨1,581463414634146344937⟩,⟨207,999999999999999999⟩]
private def b9671 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨7,14⟩,⟨1,2⟩,⟨207,999999999999999999⟩]
private def b9672 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨7,14⟩,⟨3,581463414634146344937⟩,⟨207,999999999999999999⟩]
private def b9673 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨7,9⟩,⟨3,581463414634146344937⟩,⟨207,999999999999999999⟩]
private def b9686 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨3,581463414634146344937⟩,⟨207,999999999999999999⟩]
private def b9687 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨3,581463414634146344937⟩,⟨207,414⟩]
private def b9688 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨3,6⟩,⟨207,414⟩]
private def b9689 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨7,581463414634146344930⟩,⟨207,414⟩]
private def b9690 : Box := ![⟨18,19⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨7,581463414634146344930⟩,⟨207,414⟩]
private def b9701 : Box := ![⟨20,22⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨7,581463414634146344930⟩,⟨207,414⟩]
private def b9702 : Box := ![⟨20,22⟩,⟨63,126⟩,⟨10,14⟩,⟨7,581463414634146344930⟩,⟨207,414⟩]
private def b9703 : Box := ![⟨20,22⟩,⟨63,126⟩,⟨10,11⟩,⟨7,52⟩,⟨207,414⟩]
private def b9714 : Box := ![⟨20,22⟩,⟨63,126⟩,⟨12,14⟩,⟨7,52⟩,⟨207,414⟩]
private def b9715 : Box := ![⟨20,22⟩,⟨63,126⟩,⟨12,14⟩,⟨7,52⟩,⟨207,276⟩]
private def b9726 : Box := ![⟨20,22⟩,⟨63,126⟩,⟨12,14⟩,⟨7,52⟩,⟨277,414⟩]
private def b9741 : Box := ![⟨20,22⟩,⟨127,1920000000000000011376⟩,⟨10,14⟩,⟨7,581463414634146344930⟩,⟨207,414⟩]
private def b9744 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨3,581463414634146344937⟩,⟨415,999999999999999999⟩]
private def b9745 : Box := ![⟨18,19⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨3,514070080862533695793⟩,⟨415,999999999999999999⟩]
private def b9748 : Box := ![⟨20,22⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨3,514070080862533695793⟩,⟨415,999999999999999999⟩]
private def b9749 : Box := ![⟨20,22⟩,⟨63,126⟩,⟨10,14⟩,⟨3,514070080862533695793⟩,⟨415,999999999999999999⟩]
private def b9750 : Box := ![⟨20,22⟩,⟨63,126⟩,⟨10,11⟩,⟨3,51⟩,⟨415,999999999999999999⟩]
private def b9753 : Box := ![⟨20,22⟩,⟨63,126⟩,⟨12,14⟩,⟨3,51⟩,⟨415,999999999999999999⟩]
private def b9754 : Box := ![⟨20,22⟩,⟨63,126⟩,⟨12,14⟩,⟨3,51⟩,⟨415,830⟩]
private def b9767 : Box := ![⟨20,22⟩,⟨63,126⟩,⟨12,14⟩,⟨3,51⟩,⟨831,999999999999999999⟩]
private def b9776 : Box := ![⟨20,22⟩,⟨127,1920000000000000011376⟩,⟨10,14⟩,⟨3,514070080862533695793⟩,⟨415,999999999999999999⟩]
private def b9777 : Box := ![⟨20,22⟩,⟨127,1920000000000000011376⟩,⟨10,11⟩,⟨3,514070080862533695793⟩,⟨415,999999999999999999⟩]
private def b9778 : Box := ![⟨20,22⟩,⟨127,1920000000000000011376⟩,⟨10,11⟩,⟨3,6⟩,⟨415,999999999999999999⟩]
private def b9779 : Box := ![⟨20,22⟩,⟨127,1920000000000000011376⟩,⟨10,11⟩,⟨7,514070080862533695792⟩,⟨415,999999999999999999⟩]
private def b9780 : Box := ![⟨20,22⟩,⟨127,1920000000000000011376⟩,⟨10,11⟩,⟨7,14⟩,⟨415,999999999999999999⟩]
private def b9781 : Box := ![⟨20,22⟩,⟨127,1920000000000000011376⟩,⟨10,11⟩,⟨15,514070080862533695792⟩,⟨415,999999999999999999⟩]
private def b9782 : Box := ![⟨20,22⟩,⟨127,254⟩,⟨10,11⟩,⟨15,514070080862533695792⟩,⟨415,999999999999999999⟩]
private def b9783 : Box := ![⟨20,22⟩,⟨255,1920000000000000011376⟩,⟨10,11⟩,⟨15,514070080862533695792⟩,⟨415,999999999999999999⟩]
private def b9798 : Box := ![⟨20,22⟩,⟨127,1920000000000000011376⟩,⟨12,14⟩,⟨3,514070080862533695793⟩,⟨415,999999999999999999⟩]
private def b9799 : Box := ![⟨20,22⟩,⟨127,1920000000000000011376⟩,⟨12,14⟩,⟨3,514070080862533695793⟩,⟨415,830⟩]
private def b9802 : Box := ![⟨20,22⟩,⟨127,1920000000000000011376⟩,⟨12,14⟩,⟨3,514070080862533695793⟩,⟨831,999999999999999999⟩]
private def b9803 : Box := ![⟨20,20⟩,⟨127,1920000000000000011376⟩,⟨12,14⟩,⟨3,461047542304593072859⟩,⟨831,999999999999999999⟩]
private def b9808 : Box := ![⟨21,22⟩,⟨127,1920000000000000011376⟩,⟨12,14⟩,⟨3,461047542304593072859⟩,⟨831,999999999999999999⟩]
private def b9809 : Box := ![⟨21,22⟩,⟨127,254⟩,⟨12,14⟩,⟨3,461047542304593072859⟩,⟨831,999999999999999999⟩]
private def b9810 : Box := ![⟨21,22⟩,⟨127,254⟩,⟨12,14⟩,⟨4,77⟩,⟨831,1662⟩]
private def b9811 : Box := ![⟨21,22⟩,⟨127,254⟩,⟨12,14⟩,⟨4,77⟩,⟨1663,999999999999999999⟩]
private def b9812 : Box := ![⟨21,22⟩,⟨127,254⟩,⟨12,14⟩,⟨4,70⟩,⟨1663,3326⟩]
private def b9813 : Box := ![⟨21,22⟩,⟨127,254⟩,⟨12,14⟩,⟨4,70⟩,⟨3327,999999999999999999⟩]
private def b9814 : Box := ![⟨21,22⟩,⟨127,254⟩,⟨12,14⟩,⟨4,64⟩,⟨3327,6654⟩]
private def b9815 : Box := ![⟨21,22⟩,⟨127,254⟩,⟨12,14⟩,⟨4,64⟩,⟨6655,999999999999999999⟩]
private def b9816 : Box := ![⟨21,22⟩,⟨127,254⟩,⟨12,14⟩,⟨4,59⟩,⟨6655,13310⟩]
private def b9817 : Box := ![⟨21,22⟩,⟨127,254⟩,⟨12,14⟩,⟨4,59⟩,⟨13311,999999999999999999⟩]
private def b9818 : Box := ![⟨21,22⟩,⟨127,254⟩,⟨12,14⟩,⟨4,54⟩,⟨13311,26622⟩]
private def b9819 : Box := ![⟨21,22⟩,⟨127,254⟩,⟨12,14⟩,⟨4,54⟩,⟨26623,999999999999999999⟩]
private def b9820 : Box := ![⟨21,22⟩,⟨127,254⟩,⟨12,14⟩,⟨4,51⟩,⟨26623,53246⟩]
private def b9821 : Box := ![⟨21,22⟩,⟨127,254⟩,⟨12,14⟩,⟨4,51⟩,⟨53247,999999999999999999⟩]
private def b9822 : Box := ![⟨21,22⟩,⟨127,254⟩,⟨12,14⟩,⟨4,47⟩,⟨53247,106494⟩]
private def b9823 : Box := ![⟨21,22⟩,⟨127,254⟩,⟨12,14⟩,⟨4,47⟩,⟨106495,999999999999999999⟩]
private def b9824 : Box := ![⟨21,22⟩,⟨127,254⟩,⟨12,14⟩,⟨4,44⟩,⟨106495,212990⟩]
private def b9825 : Box := ![⟨21,22⟩,⟨127,254⟩,⟨12,14⟩,⟨4,44⟩,⟨212991,999999999999999999⟩]
private def b9826 : Box := ![⟨21,22⟩,⟨127,254⟩,⟨12,14⟩,⟨4,42⟩,⟨212991,425982⟩]
private def b9827 : Box := ![⟨21,22⟩,⟨127,254⟩,⟨12,14⟩,⟨4,42⟩,⟨425983,999999999999999999⟩]
private def b9842 : Box := ![⟨21,22⟩,⟨255,1920000000000000011376⟩,⟨12,14⟩,⟨3,461047542304593072859⟩,⟨831,999999999999999999⟩]
private def b9843 : Box := ![⟨21,22⟩,⟨255,1920000000000000011376⟩,⟨12,14⟩,⟨8,461047542304593072859⟩,⟨969,1938⟩]
private def b9844 : Box := ![⟨21,22⟩,⟨255,1920000000000000011376⟩,⟨12,14⟩,⟨8,461047542304593072859⟩,⟨1939,999999999999999999⟩]
private def b9845 : Box := ![⟨21,21⟩,⟨255,1920000000000000011376⟩,⟨12,14⟩,⟨8,409563350035790983119⟩,⟨1939,999999999999999999⟩]
private def b9846 : Box := ![⟨21,21⟩,⟨255,1920000000000000011376⟩,⟨12,14⟩,⟨8,409563350035790983119⟩,⟨1939,3878⟩]
private def b9847 : Box := ![⟨21,21⟩,⟨255,1920000000000000011376⟩,⟨12,14⟩,⟨8,409563350035790983119⟩,⟨3879,999999999999999999⟩]
private def b9848 : Box := ![⟨21,21⟩,⟨255,1920000000000000011376⟩,⟨12,14⟩,⟨8,375186885245901641585⟩,⟨3879,7758⟩]
private def b9849 : Box := ![⟨21,21⟩,⟨255,1920000000000000011376⟩,⟨12,14⟩,⟨8,375186885245901641585⟩,⟨7759,999999999999999999⟩]
private def b9864 : Box := ![⟨22,22⟩,⟨255,1920000000000000011376⟩,⟨12,14⟩,⟨8,409563350035790983119⟩,⟨1939,999999999999999999⟩]
theorem deny5_11 : Deny 5 11 ![⟨15,22⟩,⟨31,1920000000000000011376⟩,⟨7,14⟩,⟨1,1664000000000000009895⟩,⟨103,999999999999999999⟩] := by
  have e9452 : Deny 5 11 b9452 := by
    apply closeAction rule_sound _ _ 64 [0xa1]
    decide +kernel
  have e9454 : Deny 5 11 b9454 := by
    apply closeAction rule_sound _ _ 64 [0xf8df6d61]
    decide +kernel
  have e9456 : Deny 5 11 b9456 := by
    apply closeAction rule_sound _ _ 64 [0xc3e37db58c86b8df6d476b8df58c98c4087e36d63]
    decide +kernel
  have e9466 : Deny 5 11 b9466 := by
    apply closeAction rule_sound _ _ 64 [0x1aac46ab8c4238d63]
    decide +kernel
  have e9471 : Deny 5 11 b9471 := by
    apply closeAction rule_sound _ _ 64 [0x1aac46ab8c4238d63]
    decide +kernel
  have e9474 : Deny 5 11 b9474 := by
    apply closeAction rule_sound _ _ 64 [0x69aac42eb6ab683e03e211c3e2b8492a322b8c8]
    decide +kernel
  have e9470 : Deny 5 11 b9470 :=
    branchAction rule_sound _ _ 2
      0x1c4 b9470 b9471 b9474 (by decide +kernel) e9471 e9474
  have e9487 : Deny 5 11 b9487 := by
    apply closeAction rule_sound _ _ 64 [0x6ab6ab8c46b8df6d6b8c4238db5ae32021f58c4]
    decide +kernel
  have e9469 : Deny 5 11 b9469 :=
    branchAction rule_sound _ _ 1
      0xb b9469 b9470 b9487 (by decide +kernel) e9470 e9487
  have e9465 : Deny 5 11 b9465 :=
    branchAction rule_sound _ _ 1
      0x9 b9465 b9466 b9469 (by decide +kernel) e9466 e9469
  have e9455 : Deny 5 11 b9455 :=
    branchAction rule_sound _ _ 1
      0x8 b9455 b9456 b9465 (by decide +kernel) e9456 e9465
  have e9453 : Deny 5 11 b9453 :=
    branchAction rule_sound _ _ 3
      0xad63 b9453 b9454 b9455 (by decide +kernel) e9454 e9455
  have e9451 : Deny 5 11 b9451 :=
    branchAction rule_sound _ _ 4
      0x2b8d63 b9451 b9452 b9453 (by decide +kernel) e9452 e9453
  have e9497 : Deny 5 11 b9497 := by
    apply closeAction rule_sound _ _ 64 [0x30f81c3e23243e36ae1283e378c8103e37db58c41f8de3]
    decide +kernel
  have e9509 : Deny 5 11 b9509 := by
    apply closeAction rule_sound _ _ 64 [0x30f8203e37849df6d611e1]
    decide +kernel
  have e9518 : Deny 5 11 b9518 := by
    apply closeAction rule_sound _ _ 64 [0x3ac38c80e32430f8de3263223]
    decide +kernel
  have e9527 : Deny 5 11 b9527 := by
    apply closeAction rule_sound _ _ 64 [0x20c4238dc31f8dc3e370c78c90c38c98c8]
    decide +kernel
  have e9517 : Deny 5 11 b9517 :=
    branchAction rule_sound _ _ 2
      0x1c4 b9517 b9518 b9527 (by decide +kernel) e9518 e9527
  have e9541 : Deny 5 11 b9541 := by
    apply closeAction rule_sound _ _ 64 [0x30f8df51c46b8df58c4278d63]
    decide +kernel
  have e9546 : Deny 5 11 b9546 := by
    apply closeAction rule_sound _ _ 64 [0xf8dc38c80e31c30f8dc78c90c3e378c98c8]
    decide +kernel
  have e9540 : Deny 5 11 b9540 :=
    branchAction rule_sound _ _ 3
      0x78c4 b9540 b9541 b9546 (by decide +kernel) e9541 e9546
  have e9516 : Deny 5 11 b9516 :=
    branchAction rule_sound _ _ 1
      0xb b9516 b9517 b9540 (by decide +kernel) e9517 e9540
  have e9508 : Deny 5 11 b9508 :=
    branchAction rule_sound _ _ 1
      0xa b9508 b9509 b9516 (by decide +kernel) e9509 e9516
  have e9496 : Deny 5 11 b9496 :=
    branchAction rule_sound _ _ 2
      0x263 b9496 b9497 b9508 (by decide +kernel) e9497 e9508
  have e9560 : Deny 5 11 b9560 := by
    apply closeAction rule_sound _ _ 64 [0x12]
    decide +kernel
  have e9562 : Deny 5 11 b9562 := by
    apply closeAction rule_sound _ _ 64 [0x12]
    decide +kernel
  have e9566 : Deny 5 11 b9566 := by
    apply closeAction rule_sound _ _ 64 [0x6ab688ada8c80f8dab84a]
    decide +kernel
  have e9573 : Deny 5 11 b9573 := by
    apply closeAction rule_sound _ _ 64 [0x9a278adaada0eb0c8ae12a322b8c8]
    decide +kernel
  have e9565 : Deny 5 11 b9565 :=
    branchAction rule_sound _ _ 2
      0x1c4 b9565 b9566 b9573 (by decide +kernel) e9566 e9573
  have e9585 : Deny 5 11 b9585 := by
    apply closeAction rule_sound _ _ 64 [0x1aadaac4087e36d6b8c8d63]
    decide +kernel
  have e9590 : Deny 5 11 b9590 := by
    apply closeAction rule_sound _ _ 64 [0x6ab688adaada0c3e211dae37d6b8492a322b8c8]
    decide +kernel
  have e9584 : Deny 5 11 b9584 :=
    branchAction rule_sound _ _ 3
      0x78c4 b9584 b9585 b9590 (by decide +kernel) e9585 e9590
  have e9564 : Deny 5 11 b9564 :=
    branchAction rule_sound _ _ 2
      0x2e3 b9564 b9565 b9584 (by decide +kernel) e9565 e9584
  have e9604 : Deny 5 11 b9604 := by
    apply closeAction rule_sound _ _ 64 [0x20ab0820c78c42386ab0e322b8c9ae32231c4]
    decide +kernel
  have e9620 : Deny 5 11 b9620 := by
    apply closeAction rule_sound _ _ 64 [0x6ab0f88c8ae3]
    decide +kernel
  have e9624 : Deny 5 11 b9624 := by
    apply closeAction rule_sound _ _ 64 [0x26ab8c41f8ac3e370eb1e3204]
    decide +kernel
  have e9631 : Deny 5 11 b9631 := by
    apply closeAction rule_sound _ _ 64 [0x831da26b0c3e371e3223]
    decide +kernel
  have e9623 : Deny 5 11 b9623 :=
    branchAction rule_sound _ _ 1
      0xb b9623 b9624 b9631 (by decide +kernel) e9624 e9631
  have e9619 : Deny 5 11 b9619 :=
    branchAction rule_sound _ _ 2
      0x263 b9619 b9620 b9623 (by decide +kernel) e9620 e9623
  have e9640 : Deny 5 11 b9640 := by
    apply closeAction rule_sound _ _ 64 [0x1aada22b]
    decide +kernel
  have e9618 : Deny 5 11 b9618 :=
    branchAction rule_sound _ _ 2
      0x223 b9618 b9619 b9640 (by decide +kernel) e9619 e9640
  have e9643 : Deny 5 11 b9643 := by
    apply closeAction rule_sound _ _ 64 [0xab0820e3223107e1ae2b8c40f80e31e3108e2b8c98c8]
    decide +kernel
  have e9617 : Deny 5 11 b9617 :=
    branchAction rule_sound _ _ 3
      0x78c4 b9617 b9618 b9643 (by decide +kernel) e9618 e9643
  have e9603 : Deny 5 11 b9603 :=
    branchAction rule_sound _ _ 1
      0xb b9603 b9604 b9617 (by decide +kernel) e9604 e9617
  have e9563 : Deny 5 11 b9563 :=
    branchAction rule_sound _ _ 1
      0x9 b9563 b9564 b9603 (by decide +kernel) e9564 e9603
  have e9561 : Deny 5 11 b9561 :=
    branchAction rule_sound _ _ 1
      0xa b9561 b9562 b9563 (by decide +kernel) e9562 e9563
  have e9559 : Deny 5 11 b9559 :=
    branchAction rule_sound _ _ 1
      0xa b9559 b9560 b9561 (by decide +kernel) e9560 e9561
  have e9495 : Deny 5 11 b9495 :=
    branchAction rule_sound _ _ 3
      0x88c4 b9495 b9496 b9559 (by decide +kernel) e9496 e9559
  have e9657 : Deny 5 11 b9657 := by
    apply closeAction rule_sound _ _ 64 [0xf80f8ae3243e368c80f8df61c3e37da1283e37da32388c21f8da3]
    decide +kernel
  have e9671 : Deny 5 11 b9671 := by
    apply closeAction rule_sound _ _ 64 [0x4b8da1]
    decide +kernel
  have e9673 : Deny 5 11 b9673 := by
    apply closeAction rule_sound _ _ 64 [0x6ab688ada0ab8442b88c86ab8c4087e37db51e348ae23]
    decide +kernel
  have e9688 : Deny 5 11 b9688 := by
    apply closeAction rule_sound _ _ 64 [0x3aeaa21]
    decide +kernel
  have e9690 : Deny 5 11 b9690 := by
    apply closeAction rule_sound _ _ 64 [0x1aada22b0daae326b0f8df68c811ae37db5107e368c8]
    decide +kernel
  have e9703 : Deny 5 11 b9703 := by
    apply closeAction rule_sound _ _ 64 [0x1aac3e232021e36ab0c21e32042e3]
    decide +kernel
  have e9715 : Deny 5 11 b9715 := by
    apply closeAction rule_sound _ _ 64 [0x20831e323809aae3109e2b0e32078c4]
    decide +kernel
  have e9726 : Deny 5 11 b9726 := by
    apply closeAction rule_sound _ _ 64 [0x268384a8c41f8ac30e326321a0e12ab0f88c81e3]
    decide +kernel
  have e9714 : Deny 5 11 b9714 :=
    branchAction rule_sound _ _ 1
      0xb b9714 b9715 b9726 (by decide +kernel) e9715 e9726
  have e9702 : Deny 5 11 b9702 :=
    branchAction rule_sound _ _ 2
      0x263 b9702 b9703 b9714 (by decide +kernel) e9703 e9714
  have e9741 : Deny 5 11 b9741 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3688e2b]
    decide +kernel
  have e9701 : Deny 5 11 b9701 :=
    branchAction rule_sound _ _ 1
      0x8 b9701 b9702 b9741 (by decide +kernel) e9702 e9741
  have e9689 : Deny 5 11 b9689 :=
    branchAction rule_sound _ _ 1
      0x7 b9689 b9690 b9701 (by decide +kernel) e9690 e9701
  have e9687 : Deny 5 11 b9687 :=
    branchAction rule_sound _ _ 2
      0x2a3 b9687 b9688 b9689 (by decide +kernel) e9688 e9689
  have e9745 : Deny 5 11 b9745 := by
    apply closeAction rule_sound _ _ 64 [0x6ab8daae3278db5]
    decide +kernel
  have e9750 : Deny 5 11 b9750 := by
    apply closeAction rule_sound _ _ 64 [0x1aae36b8df5ae3238d63]
    decide +kernel
  have e9754 : Deny 5 11 b9754 := by
    apply closeAction rule_sound _ _ 64 [0x1aac30f8ae326322b0c3e2b263203d6b102278d6b8c7ae3]
    decide +kernel
  have e9767 : Deny 5 11 b9767 := by
    apply closeAction rule_sound _ _ 64 [0x30f8d470f88c80f8d632421e3]
    decide +kernel
  have e9753 : Deny 5 11 b9753 :=
    branchAction rule_sound _ _ 1
      0xb b9753 b9754 b9767 (by decide +kernel) e9754 e9767
  have e9749 : Deny 5 11 b9749 :=
    branchAction rule_sound _ _ 2
      0x263 b9749 b9750 b9753 (by decide +kernel) e9750 e9753
  have e9778 : Deny 5 11 b9778 := by
    apply closeAction rule_sound _ _ 64 [0x4b8ae1]
    decide +kernel
  have e9780 : Deny 5 11 b9780 := by
    apply closeAction rule_sound _ _ 64 [0x12e21]
    decide +kernel
  have e9782 : Deny 5 11 b9782 := by
    apply closeAction rule_sound _ _ 64 [0x1ae23]
    decide +kernel
  have e9783 : Deny 5 11 b9783 := by
    apply closeAction rule_sound _ _ 64 [0x26ab8c8e1ae3526b6a321ae37d478daae32c21e36ab8cb]
    decide +kernel
  have e9781 : Deny 5 11 b9781 :=
    branchAction rule_sound _ _ 1
      0x8 b9781 b9782 b9783 (by decide +kernel) e9782 e9783
  have e9779 : Deny 5 11 b9779 :=
    branchAction rule_sound _ _ 1
      0xa b9779 b9780 b9781 (by decide +kernel) e9780 e9781
  have e9777 : Deny 5 11 b9777 :=
    branchAction rule_sound _ _ 2
      0x2a3 b9777 b9778 b9779 (by decide +kernel) e9778 e9779
  have e9799 : Deny 5 11 b9799 := by
    apply closeAction rule_sound _ _ 64 [0x6ab688ae3]
    decide +kernel
  have e9803 : Deny 5 11 b9803 := by
    apply closeAction rule_sound _ _ 64 [0x69aae3238ae36ab8c8e35]
    decide +kernel
  have e9810 : Deny 5 11 b9810 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e9812 : Deny 5 11 b9812 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e9814 : Deny 5 11 b9814 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e9816 : Deny 5 11 b9816 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e9818 : Deny 5 11 b9818 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e9820 : Deny 5 11 b9820 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e9822 : Deny 5 11 b9822 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e9824 : Deny 5 11 b9824 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e9826 : Deny 5 11 b9826 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e9827 : Deny 5 11 b9827 := by
    apply closeAction rule_sound _ _ 64 [0x6820c808708984a8daae32e36ab8cb8daae32e3]
    decide +kernel
  have e9825 : Deny 5 11 b9825 :=
    branchAction rule_sound _ _ 2
      0x2e3 b9825 b9826 b9827 (by decide +kernel) e9826 e9827
  have e9823 : Deny 5 11 b9823 :=
    branchAction rule_sound _ _ 2
      0x2e3 b9823 b9824 b9825 (by decide +kernel) e9824 e9825
  have e9821 : Deny 5 11 b9821 :=
    branchAction rule_sound _ _ 2
      0x2e3 b9821 b9822 b9823 (by decide +kernel) e9822 e9823
  have e9819 : Deny 5 11 b9819 :=
    branchAction rule_sound _ _ 2
      0x2e3 b9819 b9820 b9821 (by decide +kernel) e9820 e9821
  have e9817 : Deny 5 11 b9817 :=
    branchAction rule_sound _ _ 2
      0x2e3 b9817 b9818 b9819 (by decide +kernel) e9818 e9819
  have e9815 : Deny 5 11 b9815 :=
    branchAction rule_sound _ _ 2
      0x2e3 b9815 b9816 b9817 (by decide +kernel) e9816 e9817
  have e9813 : Deny 5 11 b9813 :=
    branchAction rule_sound _ _ 2
      0x2e3 b9813 b9814 b9815 (by decide +kernel) e9814 e9815
  have e9811 : Deny 5 11 b9811 :=
    branchAction rule_sound _ _ 2
      0x2e3 b9811 b9812 b9813 (by decide +kernel) e9812 e9813
  have e9809 : Deny 5 11 b9809 :=
    branchAction rule_sound _ _ 3
      0xbae3 b9809 b9810 b9811 (by decide +kernel) e9810 e9811
  have e9843 : Deny 5 11 b9843 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e9846 : Deny 5 11 b9846 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e9848 : Deny 5 11 b9848 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e9849 : Deny 5 11 b9849 := by
    apply closeAction rule_sound _ _ 64 [0x9aac20898c8ae32026ab8c8d632636ab8cb8daae32e3]
    decide +kernel
  have e9847 : Deny 5 11 b9847 :=
    branchAction rule_sound _ _ 2
      0x2e3 b9847 b9848 b9849 (by decide +kernel) e9848 e9849
  have e9845 : Deny 5 11 b9845 :=
    branchAction rule_sound _ _ 1
      0xb b9845 b9846 b9847 (by decide +kernel) e9846 e9847
  have e9864 : Deny 5 11 b9864 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e9844 : Deny 5 11 b9844 :=
    branchAction rule_sound _ _ 2
      0x1e3 b9844 b9845 b9864 (by decide +kernel) e9845 e9864
  have e9842 : Deny 5 11 b9842 :=
    branchAction rule_sound _ _ 3
      0xbe2b b9842 b9843 b9844 (by decide +kernel) e9843 e9844
  have e9808 : Deny 5 11 b9808 :=
    branchAction rule_sound _ _ 1
      0x8 b9808 b9809 b9842 (by decide +kernel) e9809 e9842
  have e9802 : Deny 5 11 b9802 :=
    branchAction rule_sound _ _ 2
      0x1e3 b9802 b9803 b9808 (by decide +kernel) e9803 e9808
  have e9798 : Deny 5 11 b9798 :=
    branchAction rule_sound _ _ 1
      0xb b9798 b9799 b9802 (by decide +kernel) e9799 e9802
  have e9776 : Deny 5 11 b9776 :=
    branchAction rule_sound _ _ 1
      0x9 b9776 b9777 b9798 (by decide +kernel) e9777 e9798
  have e9748 : Deny 5 11 b9748 :=
    branchAction rule_sound _ _ 1
      0x8 b9748 b9749 b9776 (by decide +kernel) e9749 e9776
  have e9744 : Deny 5 11 b9744 :=
    branchAction rule_sound _ _ 2
      0x1e3 b9744 b9745 b9748 (by decide +kernel) e9745 e9748
  have e9686 : Deny 5 11 b9686 :=
    branchAction rule_sound _ _ 1
      0xb b9686 b9687 b9744 (by decide +kernel) e9687 e9744
  have e9672 : Deny 5 11 b9672 :=
    branchAction rule_sound _ _ 1
      0x9 b9672 b9673 b9686 (by decide +kernel) e9673 e9686
  have e9670 : Deny 5 11 b9670 :=
    branchAction rule_sound _ _ 1
      0xa b9670 b9671 b9672 (by decide +kernel) e9671 e9672
  have e9656 : Deny 5 11 b9656 :=
    branchAction rule_sound _ _ 2
      0x223 b9656 b9657 b9670 (by decide +kernel) e9657 e9670
  have e9494 : Deny 5 11 b9494 :=
    branchAction rule_sound _ _ 1
      0xb b9494 b9495 b9656 (by decide +kernel) e9495 e9656
  have e9450 : Deny 5 11 b9450 :=
    branchAction rule_sound _ _ 2
      0x1e3 b9450 b9451 b9494 (by decide +kernel) e9451 e9494
  exact e9450
end OMA.Blocks5_11_245212.S9450
