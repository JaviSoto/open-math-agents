import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S9346
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b9346 : Box := ![⟨31,46⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨3,6⟩,⟨41,53⟩]
theorem deny5_13 : Deny 5 13 ![⟨31,46⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨3,6⟩,⟨41,53⟩] := by
  have e9346 : Deny 5 13 b9346 := by
    apply closeAction rule_sound _ _ 64 [0xc3203e37da22222830f8df62098878842c3087df61030f8d880c22221c308808788a88b0c21f8dc90f8df6887e22222,0xda2203df6887102238df68870820e21e22020c9e370f70c98870c388788888a0f70c70c82420c80e21c30f8df6887888,0x30f7da2203088df68871020832221c30c90c32621e22842c38840f7da2107e378880c3e371c3e37d882430f7]
    decide +kernel
  exact e9346
end OMA.Blocks5_13_245212.S9346
