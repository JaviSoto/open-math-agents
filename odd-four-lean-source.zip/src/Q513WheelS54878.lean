import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S54878
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b54878 : Box := ![⟨54,62⟩,⟨127,1920000000000000011376⟩,⟨10,14⟩,⟨2,502335381913959616705⟩,⟨479,958⟩]
theorem deny5_13 : Deny 5 13 ![⟨54,62⟩,⟨127,1920000000000000011376⟩,⟨10,14⟩,⟨2,502335381913959616705⟩,⟨479,958⟩] := by
  have e54878 : Deny 5 13 b54878 := by
    apply closeAction rule_sound _ _ 64 [0x2787c3e03ae11e1243e216b8de11f8ae1242083ae1261107e1a0e12ab849ae12eb8476dbe2b847ae12612a322b8c8ae3,0x1aadaada09b]
    decide +kernel
  exact e54878
end OMA.Blocks5_13_245212.S54878
