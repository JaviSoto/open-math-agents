import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S51170
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b51170 : Box := ![⟨95,126⟩,⟨25,30⟩,⟨31,62⟩,⟨1,76⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,126⟩,⟨25,30⟩,⟨31,62⟩,⟨1,76⟩,⟨479,999999999999999999⟩] := by
  have e51170 : Deny 5 13 b51170 := by
    apply closeAction rule_sound _ _ 64 [0xc3e07255e3620a2a32f88d52b88c78c98c88df0820820c81c727855f5420c7e032380f80c70f820724a2482952a32e3,0xe231e3243e1fe37da31f87f8de32788d52b88c88df7d50f80c70f820928a54a8cb0f80f88c9e03e368c7e022388df7d5,0xc3e088c90c3e080f88c3e378c8e232631c3e03e232780f8df68c7e2354ae362237df54a2952a32e31c20e32038c70c3,0xe032075ca28a54a8cb8c78c90820832231e32420f88c7e038c70c3e231e3263223578dd5e37578dc38c78c92232c20c8,0x82083e231f80f88c8e232788c7e231f80820f88c7e03e08e232780838c90e32030e3243e232231e37df083238083e09,0x2]
    decide +kernel
  exact e51170
end OMA.Blocks5_13_245212.S51170
