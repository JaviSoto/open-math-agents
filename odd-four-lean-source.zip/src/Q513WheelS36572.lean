import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S36572
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b36572 : Box := ![⟨63,94⟩,⟨15,20⟩,⟨15,30⟩,⟨3,52⟩,⟨79,93⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨15,20⟩,⟨15,30⟩,⟨3,52⟩,⟨79,93⟩] := by
  have e36572 : Deny 5 13 b36572 := by
    apply closeAction rule_sound _ _ 64 [0xc70e024a2c30f8dc92090c32430f72471020c4278dc3e032475430c724a2c30f8df61c80c3e37243e37d882472a3204,0x278dc3e0324710ae030e31e32030e32438c88c98c7578dc3e370c72430c7203dc31c30f71c91020c41f8dc3e031c90f7,0xf8dc31c4278dc3e370c90c82472b70820c7238dc20c7dc3dc38c78c98c40820c72772c30e3263223242748e231020c4,0x209fe370c82441f80820e02770f70c92040820e0248dcb277578dc4]
    decide +kernel
  exact e36572
end OMA.Blocks5_13_245212.S36572
