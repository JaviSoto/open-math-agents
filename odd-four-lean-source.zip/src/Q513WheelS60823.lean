import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S60823
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b60823 : Box := ![⟨47,62⟩,⟨63,126⟩,⟨15,20⟩,⟨1,65⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,62⟩,⟨63,126⟩,⟨15,20⟩,⟨1,65⟩,⟨479,999999999999999999⟩] := by
  have e60823 : Deny 5 13 b60823 := by
    apply closeAction rule_sound _ _ 64 [0x1dfae37f8df6ae32388c90c21c2238da3087e37da32237df5c3e21257e080c21f8088e21087e212612a12972a32e31e3,0x2972a32c30897f8df6ac78dfae32e37eb8cb0f8089e2b8c21f88c88dfadf0c2278ae12a322b8cb7eb8dfe37dab8c8e23,0xe378c7e232632237df0970e12611f85f8dc32380e12780c3e211e11e12570c31c95cb0f80f82432030f82381c92212a1,0x2972a32df7c3e03e08e03e09e0ae0ae235cae070f80f88c8e37da32388df7c30c80c227820a2972a32f88c3089e23088,0x8c70f88c9ac3087e2b8c22788c88dfadf7eb0f820a8c8ae32e31e32430e32030f8de31e32237df0f80c8e030c721728a,0x84784a8c8ae32c70838c80eb8c78dfae32e37eb8cb0c3e231eb2430e3203e232632237eb7c30eb84784a8c8ae32c30f8,0xf88c7e03e232788c8e020c70eb2637eb8cb8dfae32e37eb8cb8dfae32e37eb8cb8dfae32c30c70e32232237eb7c3e03,0x82]
    decide +kernel
  exact e60823
end OMA.Blocks5_13_245212.S60823
