import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S38775
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b38775 : Box := ![⟨47,94⟩,⟨15,20⟩,⟨15,30⟩,⟨1,1017986577181208059763⟩,⟨127,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,94⟩,⟨15,20⟩,⟨15,30⟩,⟨1,1017986577181208059763⟩,⟨127,233⟩] := by
  have e38775 : Deny 5 13 b38775 := by
    apply closeAction rule_sound _ _ 64 [0xe0a0c21c4088e378c9df68c710b0c3e378c70f8de325de37da3202204087e37da32040c21c22021c2238df68c41f8de3,0x1f8283e37d88de32430f8df68c9778df68c70888c40c38c90c3e378c98c70dde37da31f7d8810b0c3e37243e37d87088,0xdf61d72822040c32030c71d7283087df62042ca0c3e378c70f8df68c98c40c38c70c3de31e32442c30f8dc9103e37d84,0x778df6236778df68c7df68c40f70c80c38c78c70dde37da31f7223103e370c8dc30e31e31c30e31e32042c30f6203087,0xc3e378c9778df68c78c40c38c90c3e378c98c710b0c3e37243e37d87e0a0c28c7e378c9]
    decide +kernel
  exact e38775
end OMA.Blocks5_13_245212.S38775
