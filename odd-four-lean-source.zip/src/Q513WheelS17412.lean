import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S17412
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b17412 : Box := ![⟨23,30⟩,⟨15,30⟩,⟨15,1920000000000000011376⟩,⟨2,1210212765957446815716⟩,⟨78,113⟩]
theorem deny5_13 : Deny 5 13 ![⟨23,30⟩,⟨15,30⟩,⟨15,1920000000000000011376⟩,⟨2,1210212765957446815716⟩,⟨78,113⟩] := by
  have e17412 : Deny 5 13 b17412 := by
    apply closeAction rule_sound _ _ 64 [0x10b7c3e37d870f8df68c7088e37da325cbdc26f72f11cdf68c4278df68c90af88a087088e37da31dce37da3237db58c4,0x8c87ca0c3e371ef0f8de325c0f8df688a088e37da32231e32431021f8de229cbdcbe326f71f2821f8df68c90a22b78c8,0x703e37da2284088e37da325cbc4088e37da31c2be2282237da311cbdcbe326f7f8de31038c41f80e32430f88c70f88c9,0x1cbdc26f]
    decide +kernel
  exact e17412
end OMA.Blocks5_13_245212.S17412
