import FastReplay245212
import SparseDigit245212
import FastRound245212
import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S21044
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b21044 : Box := ![⟨47,1920000000000000011376⟩,⟨15,30⟩,⟨3,6⟩,⟨1,1125052631578947375120⟩,⟨103,999999999999999999⟩]
private def b21045 : Box := ![⟨47,1920000000000000011376⟩,⟨15,30⟩,⟨3,4⟩,⟨1,455859649122807020279⟩,⟨103,999999999999999999⟩]
private def b21046 : Box := ![⟨47,94⟩,⟨15,30⟩,⟨3,4⟩,⟨1,455859649122807020277⟩,⟨103,999999999999999999⟩]
private def b21047 : Box := ![⟨47,94⟩,⟨15,20⟩,⟨3,4⟩,⟨1,45⟩,⟨103,350⟩]
private def b21054 : Box := ![⟨47,94⟩,⟨21,30⟩,⟨3,4⟩,⟨1,45⟩,⟨103,350⟩]
private def b21055 : Box := ![⟨47,94⟩,⟨21,30⟩,⟨3,4⟩,⟨1,2⟩,⟨103,348⟩]
private def b21056 : Box := ![⟨47,94⟩,⟨21,30⟩,⟨3,4⟩,⟨3,38⟩,⟨103,348⟩]
private def b21057 : Box := ![⟨47,94⟩,⟨21,30⟩,⟨3,4⟩,⟨3,38⟩,⟨103,159⟩]
private def b21058 : Box := ![⟨47,62⟩,⟨21,30⟩,⟨3,4⟩,⟨3,38⟩,⟨103,157⟩]
private def b21063 : Box := ![⟨63,94⟩,⟨21,30⟩,⟨3,4⟩,⟨3,38⟩,⟨103,157⟩]
private def b21064 : Box := ![⟨63,94⟩,⟨21,30⟩,⟨3,3⟩,⟨3,38⟩,⟨103,157⟩]
private def b21069 : Box := ![⟨63,94⟩,⟨21,30⟩,⟨4,4⟩,⟨3,38⟩,⟨103,157⟩]
private def b21082 : Box := ![⟨47,94⟩,⟨21,30⟩,⟨3,4⟩,⟨3,38⟩,⟨160,348⟩]
private def b21083 : Box := ![⟨47,62⟩,⟨21,30⟩,⟨3,4⟩,⟨3,34⟩,⟨160,347⟩]
private def b21084 : Box := ![⟨63,94⟩,⟨21,30⟩,⟨3,4⟩,⟨3,34⟩,⟨160,347⟩]
private def b21099 : Box := ![⟨95,1920000000000000011376⟩,⟨15,30⟩,⟨3,4⟩,⟨1,455859649122807020277⟩,⟨103,999999999999999999⟩]
private def b21100 : Box := ![⟨95,1920000000000000011376⟩,⟨15,30⟩,⟨3,4⟩,⟨1,2⟩,⟨103,999999999999999999⟩]
private def b21101 : Box := ![⟨95,1920000000000000011376⟩,⟨15,30⟩,⟨3,4⟩,⟨3,455859649122807020277⟩,⟨103,999999999999999999⟩]
private def b21102 : Box := ![⟨95,1920000000000000011376⟩,⟨15,30⟩,⟨3,4⟩,⟨3,455859649122807020277⟩,⟨103,206⟩]
private def b21103 : Box := ![⟨95,1920000000000000011376⟩,⟨15,30⟩,⟨3,4⟩,⟨3,6⟩,⟨103,199⟩]
private def b21104 : Box := ![⟨95,1920000000000000011376⟩,⟨15,30⟩,⟨3,4⟩,⟨7,455859649122807020270⟩,⟨103,199⟩]
private def b21105 : Box := ![⟨95,1920000000000000011376⟩,⟨15,20⟩,⟨3,4⟩,⟨7,455859649122807020270⟩,⟨103,199⟩]
private def b21116 : Box := ![⟨95,1920000000000000011376⟩,⟨21,30⟩,⟨3,4⟩,⟨7,455859649122807020270⟩,⟨103,199⟩]
private def b21129 : Box := ![⟨95,1920000000000000011376⟩,⟨15,30⟩,⟨3,4⟩,⟨3,455859649122807020277⟩,⟨207,999999999999999999⟩]
private def b21130 : Box := ![⟨95,1920000000000000011376⟩,⟨15,20⟩,⟨3,4⟩,⟨3,396097560975609758473⟩,⟨207,999999999999999999⟩]
private def b21141 : Box := ![⟨95,1920000000000000011376⟩,⟨21,30⟩,⟨3,4⟩,⟨3,396097560975609758473⟩,⟨207,999999999999999999⟩]
private def b21142 : Box := ![⟨95,190⟩,⟨21,30⟩,⟨3,4⟩,⟨3,396097560975609758473⟩,⟨207,999999999999999999⟩]
private def b21143 : Box := ![⟨95,190⟩,⟨21,30⟩,⟨3,3⟩,⟨3,59⟩,⟨207,6674⟩]
private def b21144 : Box := ![⟨95,190⟩,⟨21,30⟩,⟨4,4⟩,⟨3,59⟩,⟨207,6674⟩]
private def b21145 : Box := ![⟨95,190⟩,⟨21,30⟩,⟨4,4⟩,⟨4,53⟩,⟨207,402⟩]
private def b21154 : Box := ![⟨95,190⟩,⟨21,30⟩,⟨4,4⟩,⟨4,53⟩,⟨403,6652⟩]
private def b21165 : Box := ![⟨191,1920000000000000011376⟩,⟨21,30⟩,⟨3,4⟩,⟨3,396097560975609758473⟩,⟨207,999999999999999999⟩]
private def b21166 : Box := ![⟨191,1920000000000000011376⟩,⟨21,30⟩,⟨3,3⟩,⟨3,396097560975609758473⟩,⟨207,999999999999999999⟩]
private def b21169 : Box := ![⟨191,1920000000000000011376⟩,⟨21,30⟩,⟨4,4⟩,⟨3,396097560975609758473⟩,⟨207,999999999999999999⟩]
private def b21170 : Box := ![⟨191,1920000000000000011376⟩,⟨21,30⟩,⟨4,4⟩,⟨3,396097560975609758473⟩,⟨216,432⟩]
private def b21173 : Box := ![⟨191,1920000000000000011376⟩,⟨21,30⟩,⟨4,4⟩,⟨3,396097560975609758473⟩,⟨433,999999999999999999⟩]
private def b21174 : Box := ![⟨191,1920000000000000011376⟩,⟨21,24⟩,⟨4,4⟩,⟨3,347689562890276540889⟩,⟨433,999999999999999999⟩]
private def b21175 : Box := ![⟨191,1920000000000000011376⟩,⟨21,24⟩,⟨4,4⟩,⟨3,6⟩,⟨433,999999999999999999⟩]
private def b21176 : Box := ![⟨191,1920000000000000011376⟩,⟨21,24⟩,⟨4,4⟩,⟨7,347689562890276540888⟩,⟨433,999999999999999999⟩]
private def b21177 : Box := ![⟨191,1920000000000000011376⟩,⟨21,24⟩,⟨4,4⟩,⟨7,14⟩,⟨433,999999999999999999⟩]
private def b21178 : Box := ![⟨191,1920000000000000011376⟩,⟨21,24⟩,⟨4,4⟩,⟨15,347689562890276540888⟩,⟨433,999999999999999999⟩]
private def b21179 : Box := ![⟨191,382⟩,⟨21,24⟩,⟨4,4⟩,⟨15,347689562890276540888⟩,⟨433,999999999999999999⟩]
private def b21180 : Box := ![⟨383,1920000000000000011376⟩,⟨21,24⟩,⟨4,4⟩,⟨15,347689562890276540888⟩,⟨433,999999999999999999⟩]
private def b21195 : Box := ![⟨191,1920000000000000011376⟩,⟨25,30⟩,⟨4,4⟩,⟨3,347689562890276540889⟩,⟨433,999999999999999999⟩]
private def b21196 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨3,347689562890276540889⟩,⟨441,999999999999999999⟩]
private def b21197 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,87⟩,⟨472,944⟩]
private def b21198 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,87⟩,⟨945,999999999999999999⟩]
private def b21199 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,77⟩,⟨945,1890⟩]
private def b21200 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,77⟩,⟨1891,999999999999999999⟩]
private def b21201 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,70⟩,⟨1891,3782⟩]
private def b21202 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,70⟩,⟨3783,999999999999999999⟩]
private def b21203 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,64⟩,⟨3783,7566⟩]
private def b21204 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,64⟩,⟨7567,999999999999999999⟩]
private def b21205 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,59⟩,⟨7567,15134⟩]
private def b21206 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,59⟩,⟨15135,999999999999999999⟩]
private def b21207 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,55⟩,⟨15135,30270⟩]
private def b21208 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,55⟩,⟨30271,999999999999999999⟩]
private def b21209 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,51⟩,⟨30271,60542⟩]
private def b21210 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,51⟩,⟨60543,999999999999999999⟩]
private def b21211 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,48⟩,⟨60543,121086⟩]
private def b21212 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,48⟩,⟨121087,999999999999999999⟩]
private def b21213 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,45⟩,⟨121087,242174⟩]
private def b21214 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,45⟩,⟨242175,999999999999999999⟩]
private def b21215 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,42⟩,⟨242175,484350⟩]
private def b21216 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,42⟩,⟨484351,999999999999999999⟩]
private def b21217 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,40⟩,⟨484351,968702⟩]
private def b21218 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,40⟩,⟨968703,999999999999999999⟩]
private def b21219 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,38⟩,⟨968703,1937406⟩]
private def b21220 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,38⟩,⟨1937407,999999999999999999⟩]
private def b21221 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨4,7⟩,⟨1937407,999999999999999999⟩]
private def b21222 : Box := ![⟨191,326⟩,⟨25,30⟩,⟨4,4⟩,⟨4,7⟩,⟨1937407,3874814⟩]
private def b21223 : Box := ![⟨191,326⟩,⟨25,30⟩,⟨4,4⟩,⟨4,7⟩,⟨3874815,999999999999999999⟩]
private def b21224 : Box := ![⟨191,326⟩,⟨25,30⟩,⟨4,4⟩,⟨4,7⟩,⟨3874815,7749630⟩]
private def b21225 : Box := ![⟨191,326⟩,⟨25,30⟩,⟨4,4⟩,⟨4,7⟩,⟨7749631,999999999999999999⟩]
private def b21226 : Box := ![⟨191,326⟩,⟨25,30⟩,⟨4,4⟩,⟨4,7⟩,⟨7749631,15499262⟩]
private def b21227 : Box := ![⟨191,326⟩,⟨25,30⟩,⟨4,4⟩,⟨4,7⟩,⟨15499263,999999999999999999⟩]
private def b21228 : Box := ![⟨191,326⟩,⟨25,30⟩,⟨4,4⟩,⟨4,7⟩,⟨15499263,30998526⟩]
private def b21229 : Box := ![⟨191,326⟩,⟨25,30⟩,⟨4,4⟩,⟨4,7⟩,⟨30998527,999999999999999999⟩]
private def b21244 : Box := ![⟨191,382⟩,⟨25,30⟩,⟨4,4⟩,⟨8,36⟩,⟨1937407,999999999999999999⟩]
private def b21245 : Box := ![⟨383,1920000000000000011376⟩,⟨25,30⟩,⟨4,4⟩,⟨3,347689562890276540889⟩,⟨441,999999999999999999⟩]
private def b21260 : Box := ![⟨47,1920000000000000011376⟩,⟨15,30⟩,⟨5,6⟩,⟨1,455859649122807020279⟩,⟨103,999999999999999999⟩]
private def b21261 : Box := ![⟨47,94⟩,⟨15,30⟩,⟨5,6⟩,⟨1,455859649122807020279⟩,⟨103,999999999999999999⟩]
private def b21262 : Box := ![⟨47,94⟩,⟨15,30⟩,⟨5,6⟩,⟨1,46⟩,⟨103,206⟩]
private def b21263 : Box := ![⟨47,94⟩,⟨15,20⟩,⟨5,6⟩,⟨1,39⟩,⟨103,199⟩]
private def b21264 : Box := ![⟨47,62⟩,⟨15,20⟩,⟨5,6⟩,⟨1,35⟩,⟨103,199⟩]
private def b21267 : Box := ![⟨63,94⟩,⟨15,20⟩,⟨5,6⟩,⟨1,35⟩,⟨103,199⟩]
private def b21282 : Box := ![⟨47,94⟩,⟨21,30⟩,⟨5,6⟩,⟨1,39⟩,⟨103,199⟩]
private def b21283 : Box := ![⟨47,62⟩,⟨21,30⟩,⟨5,6⟩,⟨1,39⟩,⟨103,199⟩]
private def b21284 : Box := ![⟨47,62⟩,⟨21,30⟩,⟨5,6⟩,⟨1,31⟩,⟨103,135⟩]
private def b21295 : Box := ![⟨47,62⟩,⟨21,30⟩,⟨5,6⟩,⟨1,31⟩,⟨136,199⟩]
private def b21308 : Box := ![⟨63,94⟩,⟨21,30⟩,⟨5,6⟩,⟨1,39⟩,⟨103,199⟩]
private def b21315 : Box := ![⟨47,94⟩,⟨15,30⟩,⟨5,6⟩,⟨1,46⟩,⟨207,999999999999999999⟩]
private def b21316 : Box := ![⟨47,94⟩,⟨15,20⟩,⟨5,6⟩,⟨1,40⟩,⟨207,999999999999999999⟩]
private def b21317 : Box := ![⟨47,94⟩,⟨15,20⟩,⟨5,6⟩,⟨1,2⟩,⟨207,1126⟩]
private def b21318 : Box := ![⟨47,94⟩,⟨15,20⟩,⟨5,6⟩,⟨3,37⟩,⟨207,1126⟩]
private def b21319 : Box := ![⟨47,62⟩,⟨15,20⟩,⟨5,6⟩,⟨3,31⟩,⟨207,1122⟩]
private def b21322 : Box := ![⟨63,94⟩,⟨15,20⟩,⟨5,6⟩,⟨3,31⟩,⟨207,1122⟩]
private def b21335 : Box := ![⟨47,94⟩,⟨21,30⟩,⟨5,6⟩,⟨1,40⟩,⟨207,999999999999999999⟩]
private def b21336 : Box := ![⟨47,62⟩,⟨21,30⟩,⟨5,6⟩,⟨1,40⟩,⟨207,999999999999999999⟩]
private def b21349 : Box := ![⟨63,94⟩,⟨21,30⟩,⟨5,6⟩,⟨1,40⟩,⟨207,999999999999999999⟩]
private def b21350 : Box := ![⟨63,94⟩,⟨21,30⟩,⟨5,6⟩,⟨1,40⟩,⟨207,414⟩]
private def b21365 : Box := ![⟨63,94⟩,⟨21,30⟩,⟨5,6⟩,⟨1,40⟩,⟨415,999999999999999999⟩]
private def b21366 : Box := ![⟨63,94⟩,⟨21,24⟩,⟨5,6⟩,⟨1,36⟩,⟨415,999999999999999999⟩]
private def b21373 : Box := ![⟨63,94⟩,⟨25,30⟩,⟨5,6⟩,⟨1,36⟩,⟨415,999999999999999999⟩]
private def b21382 : Box := ![⟨95,1920000000000000011376⟩,⟨15,30⟩,⟨5,6⟩,⟨1,455859649122807020279⟩,⟨103,999999999999999999⟩]
private def b21383 : Box := ![⟨95,1920000000000000011376⟩,⟨15,30⟩,⟨5,6⟩,⟨1,455859649122807020279⟩,⟨103,206⟩]
private def b21394 : Box := ![⟨95,1920000000000000011376⟩,⟨15,30⟩,⟨5,6⟩,⟨1,455859649122807020279⟩,⟨207,999999999999999999⟩]
private def b21395 : Box := ![⟨95,1920000000000000011376⟩,⟨15,20⟩,⟨5,6⟩,⟨1,396097560975609758474⟩,⟨207,999999999999999999⟩]
private def b21396 : Box := ![⟨95,190⟩,⟨15,20⟩,⟨5,6⟩,⟨1,396097560975609758471⟩,⟨207,999999999999999999⟩]
private def b21397 : Box := ![⟨95,190⟩,⟨15,20⟩,⟨5,6⟩,⟨2,57⟩,⟨207,414⟩]
private def b21410 : Box := ![⟨95,190⟩,⟨15,20⟩,⟨5,6⟩,⟨2,57⟩,⟨415,999999999999999999⟩]
private def b21411 : Box := ![⟨95,190⟩,⟨15,17⟩,⟨5,6⟩,⟨2,50⟩,⟨415,999999999999999999⟩]
private def b21414 : Box := ![⟨95,190⟩,⟨18,20⟩,⟨5,6⟩,⟨2,50⟩,⟨415,999999999999999999⟩]
private def b21415 : Box := ![⟨95,126⟩,⟨18,20⟩,⟨5,6⟩,⟨2,50⟩,⟨415,999999999999999999⟩]
private def b21418 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨5,6⟩,⟨2,50⟩,⟨415,999999999999999999⟩]
private def b21419 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨5,6⟩,⟨2,50⟩,⟨415,830⟩]
private def b21420 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨5,6⟩,⟨2,50⟩,⟨831,999999999999999999⟩]
private def b21421 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨5,6⟩,⟨2,45⟩,⟨831,1662⟩]
private def b21422 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨5,6⟩,⟨2,45⟩,⟨1663,999999999999999999⟩]
private def b21423 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨5,5⟩,⟨2,41⟩,⟨1663,999999999999999999⟩]
private def b21424 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,41⟩,⟨1663,999999999999999999⟩]
private def b21425 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,41⟩,⟨1663,3326⟩]
private def b21426 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,41⟩,⟨3327,999999999999999999⟩]
private def b21427 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,37⟩,⟨3327,6654⟩]
private def b21428 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,37⟩,⟨6655,999999999999999999⟩]
private def b21429 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,34⟩,⟨6655,13310⟩]
private def b21430 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,34⟩,⟨13311,999999999999999999⟩]
private def b21431 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,32⟩,⟨13311,26622⟩]
private def b21432 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,32⟩,⟨26623,999999999999999999⟩]
private def b21433 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,30⟩,⟨26623,53246⟩]
private def b21434 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,30⟩,⟨53247,999999999999999999⟩]
private def b21435 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,28⟩,⟨53247,106494⟩]
private def b21436 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,28⟩,⟨106495,999999999999999999⟩]
private def b21437 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,26⟩,⟨106495,212990⟩]
private def b21438 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,26⟩,⟨212991,999999999999999999⟩]
private def b21439 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,25⟩,⟨212991,425982⟩]
private def b21440 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,25⟩,⟨425983,999999999999999999⟩]
private def b21441 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,23⟩,⟨425983,851966⟩]
private def b21442 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,23⟩,⟨851967,999999999999999999⟩]
private def b21443 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,22⟩,⟨851967,1703934⟩]
private def b21444 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,22⟩,⟨1703935,999999999999999999⟩]
private def b21445 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,21⟩,⟨1703935,3407870⟩]
private def b21446 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,21⟩,⟨3407871,999999999999999999⟩]
private def b21447 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,20⟩,⟨3407871,6815742⟩]
private def b21448 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,20⟩,⟨6815743,999999999999999999⟩]
private def b21449 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,19⟩,⟨6815743,13631486⟩]
private def b21450 : Box := ![⟨127,190⟩,⟨18,20⟩,⟨6,6⟩,⟨2,19⟩,⟨13631487,999999999999999999⟩]
private def b21465 : Box := ![⟨191,1920000000000000011376⟩,⟨15,20⟩,⟨5,6⟩,⟨1,396097560975609758471⟩,⟨207,999999999999999999⟩]
private def b21466 : Box := ![⟨191,1920000000000000011376⟩,⟨15,20⟩,⟨5,6⟩,⟨3,396097560975609758471⟩,⟨207,414⟩]
private def b21469 : Box := ![⟨191,1920000000000000011376⟩,⟨15,20⟩,⟨5,6⟩,⟨3,396097560975609758471⟩,⟨415,999999999999999999⟩]
private def b21470 : Box := ![⟨191,1920000000000000011376⟩,⟨15,17⟩,⟨5,6⟩,⟨3,350188679245283020966⟩,⟨415,999999999999999999⟩]
private def b21471 : Box := ![⟨191,382⟩,⟨15,17⟩,⟨5,6⟩,⟨3,350188679245283020965⟩,⟨415,999999999999999999⟩]
private def b21472 : Box := ![⟨191,382⟩,⟨15,17⟩,⟨5,6⟩,⟨4,85⟩,⟨415,830⟩]
private def b21473 : Box := ![⟨191,382⟩,⟨15,17⟩,⟨5,6⟩,⟨4,85⟩,⟨831,999999999999999999⟩]
private def b21474 : Box := ![⟨191,382⟩,⟨15,17⟩,⟨5,5⟩,⟨4,76⟩,⟨831,999999999999999999⟩]
private def b21475 : Box := ![⟨191,382⟩,⟨15,17⟩,⟨6,6⟩,⟨4,76⟩,⟨831,999999999999999999⟩]
private def b21476 : Box := ![⟨191,382⟩,⟨15,17⟩,⟨6,6⟩,⟨4,76⟩,⟨831,1662⟩]
private def b21477 : Box := ![⟨191,382⟩,⟨15,17⟩,⟨6,6⟩,⟨4,76⟩,⟨1663,999999999999999999⟩]
private def b21478 : Box := ![⟨191,382⟩,⟨15,15⟩,⟨6,6⟩,⟨4,69⟩,⟨1663,999999999999999999⟩]
private def b21479 : Box := ![⟨191,382⟩,⟨16,17⟩,⟨6,6⟩,⟨4,69⟩,⟨1663,999999999999999999⟩]
private def b21480 : Box := ![⟨191,382⟩,⟨16,17⟩,⟨6,6⟩,⟨4,69⟩,⟨1663,3326⟩]
private def b21481 : Box := ![⟨191,382⟩,⟨16,17⟩,⟨6,6⟩,⟨4,69⟩,⟨3327,999999999999999999⟩]
private def b21482 : Box := ![⟨191,382⟩,⟨16,17⟩,⟨6,6⟩,⟨4,63⟩,⟨3327,6654⟩]
private def b21483 : Box := ![⟨191,382⟩,⟨16,17⟩,⟨6,6⟩,⟨4,63⟩,⟨6655,999999999999999999⟩]
private def b21484 : Box := ![⟨191,382⟩,⟨16,17⟩,⟨6,6⟩,⟨4,58⟩,⟨6655,13310⟩]
private def b21485 : Box := ![⟨191,382⟩,⟨16,17⟩,⟨6,6⟩,⟨4,58⟩,⟨13311,999999999999999999⟩]
private def b21486 : Box := ![⟨191,382⟩,⟨16,17⟩,⟨6,6⟩,⟨4,54⟩,⟨13311,26622⟩]
private def b21487 : Box := ![⟨191,382⟩,⟨16,17⟩,⟨6,6⟩,⟨4,54⟩,⟨26623,999999999999999999⟩]
private def b21488 : Box := ![⟨191,382⟩,⟨16,17⟩,⟨6,6⟩,⟨4,50⟩,⟨26623,53246⟩]
private def b21489 : Box := ![⟨191,382⟩,⟨16,17⟩,⟨6,6⟩,⟨4,50⟩,⟨53247,999999999999999999⟩]
private def b21490 : Box := ![⟨191,382⟩,⟨16,17⟩,⟨6,6⟩,⟨4,47⟩,⟨53247,106494⟩]
private def b21491 : Box := ![⟨191,382⟩,⟨16,17⟩,⟨6,6⟩,⟨4,47⟩,⟨106495,999999999999999999⟩]
private def b21492 : Box := ![⟨191,382⟩,⟨16,17⟩,⟨6,6⟩,⟨4,8⟩,⟨106495,999999999999999999⟩]
private def b21493 : Box := ![⟨191,349⟩,⟨16,17⟩,⟨6,6⟩,⟨4,8⟩,⟨106495,212990⟩]
private def b21494 : Box := ![⟨191,349⟩,⟨16,17⟩,⟨6,6⟩,⟨4,8⟩,⟨212991,999999999999999999⟩]
private def b21509 : Box := ![⟨191,382⟩,⟨16,17⟩,⟨6,6⟩,⟨9,44⟩,⟨106495,999999999999999999⟩]
private def b21510 : Box := ![⟨383,1920000000000000011376⟩,⟨15,17⟩,⟨5,6⟩,⟨3,350188679245283020965⟩,⟨415,999999999999999999⟩]
private def b21511 : Box := ![⟨383,1920000000000000011376⟩,⟨15,17⟩,⟨5,6⟩,⟨8,350188679245283020965⟩,⟨415,830⟩]
private def b21512 : Box := ![⟨383,1920000000000000011376⟩,⟨15,17⟩,⟨5,6⟩,⟨8,350188679245283020965⟩,⟨831,999999999999999999⟩]
private def b21513 : Box := ![⟨383,1920000000000000011376⟩,⟨15,17⟩,⟨5,6⟩,⟨8,314069298952457697288⟩,⟨831,1662⟩]
private def b21514 : Box := ![⟨383,1920000000000000011376⟩,⟨15,17⟩,⟨5,6⟩,⟨8,314069298952457697288⟩,⟨1663,999999999999999999⟩]
private def b21529 : Box := ![⟨191,1920000000000000011376⟩,⟨18,20⟩,⟨5,6⟩,⟨3,350188679245283020966⟩,⟨415,999999999999999999⟩]
private def b21530 : Box := ![⟨191,1920000000000000011376⟩,⟨18,20⟩,⟨5,5⟩,⟨3,350188679245283020966⟩,⟨415,999999999999999999⟩]
private def b21531 : Box := ![⟨191,382⟩,⟨18,20⟩,⟨5,5⟩,⟨3,350188679245283020965⟩,⟨415,999999999999999999⟩]
private def b21532 : Box := ![⟨191,382⟩,⟨18,20⟩,⟨5,5⟩,⟨4,85⟩,⟨425,850⟩]
private def b21533 : Box := ![⟨191,382⟩,⟨18,20⟩,⟨5,5⟩,⟨4,85⟩,⟨851,999999999999999999⟩]
private def b21534 : Box := ![⟨191,382⟩,⟨18,20⟩,⟨5,5⟩,⟨4,76⟩,⟨851,1702⟩]
private def b21535 : Box := ![⟨191,382⟩,⟨18,20⟩,⟨5,5⟩,⟨4,76⟩,⟨1703,999999999999999999⟩]
private def b21536 : Box := ![⟨191,382⟩,⟨18,18⟩,⟨5,5⟩,⟨4,69⟩,⟨1703,999999999999999999⟩]
private def b21537 : Box := ![⟨191,382⟩,⟨19,20⟩,⟨5,5⟩,⟨4,69⟩,⟨1703,999999999999999999⟩]
private def b21538 : Box := ![⟨191,382⟩,⟨19,20⟩,⟨5,5⟩,⟨4,69⟩,⟨1703,3406⟩]
private def b21539 : Box := ![⟨191,382⟩,⟨19,20⟩,⟨5,5⟩,⟨4,69⟩,⟨3407,999999999999999999⟩]
private def b21540 : Box := ![⟨191,382⟩,⟨19,20⟩,⟨5,5⟩,⟨4,63⟩,⟨3407,6814⟩]
private def b21541 : Box := ![⟨191,382⟩,⟨19,20⟩,⟨5,5⟩,⟨4,63⟩,⟨6815,999999999999999999⟩]
private def b21542 : Box := ![⟨191,382⟩,⟨19,20⟩,⟨5,5⟩,⟨4,58⟩,⟨6815,13630⟩]
private def b21543 : Box := ![⟨191,382⟩,⟨19,20⟩,⟨5,5⟩,⟨4,58⟩,⟨13631,999999999999999999⟩]
private def b21558 : Box := ![⟨383,1920000000000000011376⟩,⟨18,20⟩,⟨5,5⟩,⟨3,350188679245283020965⟩,⟨415,999999999999999999⟩]
private def b21565 : Box := ![⟨191,1920000000000000011376⟩,⟨18,20⟩,⟨6,6⟩,⟨3,350188679245283020966⟩,⟨415,999999999999999999⟩]
private def b21566 : Box := ![⟨95,1920000000000000011376⟩,⟨21,30⟩,⟨5,6⟩,⟨1,396097560975609758474⟩,⟨207,999999999999999999⟩]
private def b21567 : Box := ![⟨95,190⟩,⟨21,30⟩,⟨5,6⟩,⟨1,396097560975609758474⟩,⟨207,999999999999999999⟩]
private def b21568 : Box := ![⟨95,190⟩,⟨21,30⟩,⟨5,6⟩,⟨1,60⟩,⟨207,414⟩]
private def b21577 : Box := ![⟨95,190⟩,⟨21,30⟩,⟨5,6⟩,⟨1,60⟩,⟨415,999999999999999999⟩]
private def b21578 : Box := ![⟨95,190⟩,⟨21,24⟩,⟨5,6⟩,⟨1,53⟩,⟨415,999999999999999999⟩]
private def b21579 : Box := ![⟨95,126⟩,⟨21,24⟩,⟨5,6⟩,⟨1,52⟩,⟨415,999999999999999999⟩]
private def b21586 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨5,6⟩,⟨1,52⟩,⟨415,999999999999999999⟩]
private def b21587 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨5,5⟩,⟨2,52⟩,⟨488,999999999999999999⟩]
private def b21588 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨5,5⟩,⟨2,50⟩,⟨488,976⟩]
private def b21589 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨5,5⟩,⟨2,50⟩,⟨977,999999999999999999⟩]
private def b21590 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨5,5⟩,⟨2,45⟩,⟨977,1954⟩]
private def b21591 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨5,5⟩,⟨2,45⟩,⟨1955,999999999999999999⟩]
private def b21592 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨5,5⟩,⟨2,41⟩,⟨1955,3910⟩]
private def b21593 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨5,5⟩,⟨2,41⟩,⟨3911,999999999999999999⟩]
private def b21594 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨5,5⟩,⟨2,37⟩,⟨3911,7822⟩]
private def b21595 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨5,5⟩,⟨2,37⟩,⟨7823,999999999999999999⟩]
private def b21596 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨5,5⟩,⟨2,34⟩,⟨7823,15646⟩]
private def b21597 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨5,5⟩,⟨2,34⟩,⟨15647,999999999999999999⟩]
private def b21612 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨6,6⟩,⟨2,52⟩,⟨488,999999999999999999⟩]
private def b21613 : Box := ![⟨95,190⟩,⟨25,30⟩,⟨5,6⟩,⟨1,53⟩,⟨415,999999999999999999⟩]
private def b21620 : Box := ![⟨191,1920000000000000011376⟩,⟨21,30⟩,⟨5,6⟩,⟨1,396097560975609758474⟩,⟨207,999999999999999999⟩]
theorem deny5_11 : Deny 5 11 ![⟨47,1920000000000000011376⟩,⟨15,30⟩,⟨3,6⟩,⟨1,1125052631578947375120⟩,⟨103,999999999999999999⟩] := by
  have e21047 : Deny 5 11 b21047 := by
    apply closeAction rule_sound _ _ 64 [0xc3e379e32270f8df58c7102278de3]
    decide +kernel
  have e21055 : Deny 5 11 b21055 := by
    apply closeAction rule_sound _ _ 64 [0x4f8da0]
    decide +kernel
  have e21058 : Deny 5 11 b21058 := by
    apply closeAction rule_sound _ _ 64 [0x30f8de3202263]
    decide +kernel
  have e21064 : Deny 5 11 b21064 := by
    apply closeAction rule_sound _ _ 64 [0xdbe378c8102238de3]
    decide +kernel
  have e21069 : Deny 5 11 b21069 := by
    apply closeAction rule_sound _ _ 64 [0xf70e32039c3de31e3223113e370a70e31e322310b]
    decide +kernel
  have e21063 : Deny 5 11 b21063 :=
    branchAction rule_sound _ _ 1
      0x9 b21063 b21064 b21069 (by decide +kernel) e21064 e21069
  have e21057 : Deny 5 11 b21057 :=
    branchAction rule_sound _ _ 2
      0x1c4 b21057 b21058 b21063 (by decide +kernel) e21058 e21063
  have e21083 : Deny 5 11 b21083 := by
    apply closeAction rule_sound _ _ 64 [0x6f8df6d63]
    decide +kernel
  have e21084 : Deny 5 11 b21084 := by
    apply closeAction rule_sound _ _ 64 [0x30f8de3204088e231030e32039c4087e378c810b089]
    decide +kernel
  have e21082 : Deny 5 11 b21082 :=
    branchAction rule_sound _ _ 3
      0x7e23 b21082 b21083 b21084 (by decide +kernel) e21083 e21084
  have e21056 : Deny 5 11 b21056 :=
    branchAction rule_sound _ _ 1
      0xb b21056 b21057 b21082 (by decide +kernel) e21057 e21082
  have e21054 : Deny 5 11 b21054 :=
    branchAction rule_sound _ _ 3
      0xae23 b21054 b21055 b21056 (by decide +kernel) e21055 e21056
  have e21046 : Deny 5 11 b21046 :=
    branchAction rule_sound _ _ 3
      0x8e23 b21046 b21047 b21054 (by decide +kernel) e21047 e21054
  have e21100 : Deny 5 11 b21100 := by
    apply closeAction rule_sound _ _ 64 [0x11e20]
    decide +kernel
  have e21103 : Deny 5 11 b21103 := by
    apply closeAction rule_sound _ _ 64 [0x11]
    decide +kernel
  have e21105 : Deny 5 11 b21105 := by
    apply closeAction rule_sound _ _ 64 [0x19e192676670f8103e278c42388c7678df5d278c99e31e3]
    decide +kernel
  have e21116 : Deny 5 11 b21116 := by
    apply closeAction rule_sound _ _ 64 [0x199e31191f89db6676c3e278c42386f82631e78c88c7]
    decide +kernel
  have e21104 : Deny 5 11 b21104 :=
    branchAction rule_sound _ _ 1
      0x8 b21104 b21105 b21116 (by decide +kernel) e21105 e21116
  have e21102 : Deny 5 11 b21102 :=
    branchAction rule_sound _ _ 3
      0xa8c4 b21102 b21103 b21104 (by decide +kernel) e21103 e21104
  have e21130 : Deny 5 11 b21130 := by
    apply closeAction rule_sound _ _ 64 [0x6676479d98c70a780a44a8c2278d23]
    decide +kernel
  have e21143 : Deny 5 11 b21143 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e21145 : Deny 5 11 b21145 := by
    apply closeAction rule_sound _ _ 64 [0x1b6e78c42d99c38c40f8de78c42388c79e3227]
    decide +kernel
  have e21154 : Deny 5 11 b21154 := by
    apply closeAction rule_sound _ _ 64 [0x1b6f89e32389c21f88db9cbe199e31021f8d278c8e23]
    decide +kernel
  have e21144 : Deny 5 11 b21144 :=
    branchAction rule_sound _ _ 4
      0x2f89e3 b21144 b21145 b21154 (by decide +kernel) e21145 e21154
  have e21142 : Deny 5 11 b21142 :=
    branchAction rule_sound _ _ 3
      0x9e23 b21142 b21143 b21144 (by decide +kernel) e21143 e21144
  have e21166 : Deny 5 11 b21166 := by
    apply closeAction rule_sound _ _ 64 [0x199e36678c7e23]
    decide +kernel
  have e21170 : Deny 5 11 b21170 := by
    apply closeAction rule_sound _ _ 64 [0x991f89e3]
    decide +kernel
  have e21175 : Deny 5 11 b21175 := by
    apply closeAction rule_sound _ _ 64 [0x4789e0]
    decide +kernel
  have e21177 : Deny 5 11 b21177 := by
    apply closeAction rule_sound _ _ 64 [0x11e20]
    decide +kernel
  have e21179 : Deny 5 11 b21179 := by
    apply closeAction rule_sound _ _ 64 [0x19e23]
    decide +kernel
  have e21180 : Deny 5 11 b21180 := by
    apply closeAction rule_sound _ _ 64 [0x20999e31f89d99e31e32389e36678c7e19e232276788c78d99e32f8]
    decide +kernel
  have e21178 : Deny 5 11 b21178 :=
    branchAction rule_sound _ _ 1
      0x7 b21178 b21179 b21180 (by decide +kernel) e21179 e21180
  have e21176 : Deny 5 11 b21176 :=
    branchAction rule_sound _ _ 1
      0xa b21176 b21177 b21178 (by decide +kernel) e21177 e21178
  have e21174 : Deny 5 11 b21174 :=
    branchAction rule_sound _ _ 2
      0x2a3 b21174 b21175 b21176 (by decide +kernel) e21175 e21176
  have e21197 : Deny 5 11 b21197 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21199 : Deny 5 11 b21199 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21201 : Deny 5 11 b21201 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21203 : Deny 5 11 b21203 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21205 : Deny 5 11 b21205 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21207 : Deny 5 11 b21207 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21209 : Deny 5 11 b21209 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21211 : Deny 5 11 b21211 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21213 : Deny 5 11 b21213 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21215 : Deny 5 11 b21215 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21217 : Deny 5 11 b21217 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21219 : Deny 5 11 b21219 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21222 : Deny 5 11 b21222 := by
    apply closeAction rule_sound _ _ 64 [0x11]
    decide +kernel
  have e21224 : Deny 5 11 b21224 := by
    apply closeAction rule_sound _ _ 64 [0x11]
    decide +kernel
  have e21226 : Deny 5 11 b21226 := by
    apply closeAction rule_sound _ _ 64 [0x11]
    decide +kernel
  have e21228 : Deny 5 11 b21228 := by
    apply closeAction rule_sound _ _ 64 [0x11]
    decide +kernel
  have e21229 : Deny 5 11 b21229 := by
    apply closeAction rule_sound _ _ 64 [0x190e70c708808880a44b44b44b]
    decide +kernel
  have e21227 : Deny 5 11 b21227 :=
    branchAction rule_sound _ _ 1
      0xb b21227 b21228 b21229 (by decide +kernel) e21228 e21229
  have e21225 : Deny 5 11 b21225 :=
    branchAction rule_sound _ _ 1
      0xb b21225 b21226 b21227 (by decide +kernel) e21226 e21227
  have e21223 : Deny 5 11 b21223 :=
    branchAction rule_sound _ _ 1
      0xb b21223 b21224 b21225 (by decide +kernel) e21224 e21225
  have e21221 : Deny 5 11 b21221 :=
    branchAction rule_sound _ _ 2
      0x2e0 b21221 b21222 b21223 (by decide +kernel) e21222 e21223
  have e21244 : Deny 5 11 b21244 := by
    apply closeAction rule_sound _ _ 64 [0x19]
    decide +kernel
  have e21220 : Deny 5 11 b21220 :=
    branchAction rule_sound _ _ 2
      0x2a3 b21220 b21221 b21244 (by decide +kernel) e21221 e21244
  have e21218 : Deny 5 11 b21218 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21218 b21219 b21220 (by decide +kernel) e21219 e21220
  have e21216 : Deny 5 11 b21216 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21216 b21217 b21218 (by decide +kernel) e21217 e21218
  have e21214 : Deny 5 11 b21214 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21214 b21215 b21216 (by decide +kernel) e21215 e21216
  have e21212 : Deny 5 11 b21212 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21212 b21213 b21214 (by decide +kernel) e21213 e21214
  have e21210 : Deny 5 11 b21210 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21210 b21211 b21212 (by decide +kernel) e21211 e21212
  have e21208 : Deny 5 11 b21208 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21208 b21209 b21210 (by decide +kernel) e21209 e21210
  have e21206 : Deny 5 11 b21206 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21206 b21207 b21208 (by decide +kernel) e21207 e21208
  have e21204 : Deny 5 11 b21204 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21204 b21205 b21206 (by decide +kernel) e21205 e21206
  have e21202 : Deny 5 11 b21202 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21202 b21203 b21204 (by decide +kernel) e21203 e21204
  have e21200 : Deny 5 11 b21200 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21200 b21201 b21202 (by decide +kernel) e21201 e21202
  have e21198 : Deny 5 11 b21198 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21198 b21199 b21200 (by decide +kernel) e21199 e21200
  have e21196 : Deny 5 11 b21196 :=
    branchAction rule_sound _ _ 4
      0x2f89e3 b21196 b21197 b21198 (by decide +kernel) e21197 e21198
  have e21245 : Deny 5 11 b21245 := by
    apply closeAction rule_sound _ _ 64 [0x826789c2083e231f88c8e19e232236678cbe231f89e31e32389e3]
    decide +kernel
  have e21195 : Deny 5 11 b21195 :=
    branchAction rule_sound _ _ 2
      0x1f8 b21195 b21196 b21245 (by decide +kernel) e21196 e21245
  have e21173 : Deny 5 11 b21173 :=
    branchAction rule_sound _ _ 2
      0x223 b21173 b21174 b21195 (by decide +kernel) e21174 e21195
  have e21169 : Deny 5 11 b21169 :=
    branchAction rule_sound _ _ 2
      0x2f8 b21169 b21170 b21173 (by decide +kernel) e21170 e21173
  have e21165 : Deny 5 11 b21165 :=
    branchAction rule_sound _ _ 1
      0x9 b21165 b21166 b21169 (by decide +kernel) e21166 e21169
  have e21141 : Deny 5 11 b21141 :=
    branchAction rule_sound _ _ 1
      0x7 b21141 b21142 b21165 (by decide +kernel) e21142 e21165
  have e21129 : Deny 5 11 b21129 :=
    branchAction rule_sound _ _ 2
      0x223 b21129 b21130 b21141 (by decide +kernel) e21130 e21141
  have e21101 : Deny 5 11 b21101 :=
    branchAction rule_sound _ _ 1
      0xb b21101 b21102 b21129 (by decide +kernel) e21102 e21129
  have e21099 : Deny 5 11 b21099 :=
    branchAction rule_sound _ _ 1
      0xa b21099 b21100 b21101 (by decide +kernel) e21100 e21101
  have e21045 : Deny 5 11 b21045 :=
    branchAction rule_sound _ _ 2
      0x1e3 b21045 b21046 b21099 (by decide +kernel) e21046 e21099
  have e21264 : Deny 5 11 b21264 := by
    apply closeAction rule_sound _ _ 64 [0x30f8de3223]
    decide +kernel
  have e21267 : Deny 5 11 b21267 := by
    apply closeAction rule_sound _ _ 64 [0x3e370c90c3e232678c88c40a7103107e370f8dc38c99e32042e7]
    decide +kernel
  have e21263 : Deny 5 11 b21263 :=
    branchAction rule_sound _ _ 2
      0x1e3 b21263 b21264 b21267 (by decide +kernel) e21264 e21267
  have e21284 : Deny 5 11 b21284 := by
    apply closeAction rule_sound _ _ 64 [0x83e370e32232530c31c8284]
    decide +kernel
  have e21295 : Deny 5 11 b21295 := by
    apply closeAction rule_sound _ _ 64 [0x20c90c38c78c84c30c720a8c4]
    decide +kernel
  have e21283 : Deny 5 11 b21283 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21283 b21284 b21295 (by decide +kernel) e21284 e21295
  have e21308 : Deny 5 11 b21308 := by
    apply closeAction rule_sound _ _ 64 [0x13e370a7478dc3e278c98c78c8]
    decide +kernel
  have e21282 : Deny 5 11 b21282 :=
    branchAction rule_sound _ _ 1
      0x7 b21282 b21283 b21308 (by decide +kernel) e21283 e21308
  have e21262 : Deny 5 11 b21262 :=
    branchAction rule_sound _ _ 3
      0x88c4 b21262 b21263 b21282 (by decide +kernel) e21263 e21282
  have e21317 : Deny 5 11 b21317 := by
    apply closeAction rule_sound _ _ 64 [0xa0]
    decide +kernel
  have e21319 : Deny 5 11 b21319 := by
    apply closeAction rule_sound _ _ 64 [0xc4088e23]
    decide +kernel
  have e21322 : Deny 5 11 b21322 := by
    apply closeAction rule_sound _ _ 64 [0xf8089e022388c30f88c90c22788c82f8]
    decide +kernel
  have e21318 : Deny 5 11 b21318 :=
    branchAction rule_sound _ _ 3
      0x7e23 b21318 b21319 b21322 (by decide +kernel) e21319 e21322
  have e21316 : Deny 5 11 b21316 :=
    branchAction rule_sound _ _ 3
      0xae23 b21316 b21317 b21318 (by decide +kernel) e21317 e21318
  have e21336 : Deny 5 11 b21336 := by
    apply closeAction rule_sound _ _ 64 [0x36f8de3243e37da32230c32430f8de31e32232e3]
    decide +kernel
  have e21350 : Deny 5 11 b21350 := by
    apply closeAction rule_sound _ _ 64 [0x20c38c88c90838c99c3e03e232631c39e02a3223]
    decide +kernel
  have e21366 : Deny 5 11 b21366 := by
    apply closeAction rule_sound _ _ 64 [0xc3e37243e23089e231e3]
    decide +kernel
  have e21373 : Deny 5 11 b21373 := by
    apply closeAction rule_sound _ _ 64 [0x83e03e23223243e03e098c7]
    decide +kernel
  have e21365 : Deny 5 11 b21365 :=
    branchAction rule_sound _ _ 2
      0x223 b21365 b21366 b21373 (by decide +kernel) e21366 e21373
  have e21349 : Deny 5 11 b21349 :=
    branchAction rule_sound _ _ 1
      0xb b21349 b21350 b21365 (by decide +kernel) e21350 e21365
  have e21335 : Deny 5 11 b21335 :=
    branchAction rule_sound _ _ 1
      0x7 b21335 b21336 b21349 (by decide +kernel) e21336 e21349
  have e21315 : Deny 5 11 b21315 :=
    branchAction rule_sound _ _ 2
      0x223 b21315 b21316 b21335 (by decide +kernel) e21316 e21335
  have e21261 : Deny 5 11 b21261 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21261 b21262 b21315 (by decide +kernel) e21262 e21315
  have e21383 : Deny 5 11 b21383 := by
    apply closeAction rule_sound _ _ 64 [0x11e370a70999d99c38c78c79e3108e278c78c88c4]
    decide +kernel
  have e21397 : Deny 5 11 b21397 := by
    apply closeAction rule_sound _ _ 64 [0x6676420e02590f880a8080e580a80a8c79e3]
    decide +kernel
  have e21411 : Deny 5 11 b21411 := by
    apply closeAction rule_sound _ _ 64 [0x6678c3e369e31f8]
    decide +kernel
  have e21415 : Deny 5 11 b21415 := by
    apply closeAction rule_sound _ _ 64 [0x30f8de3263]
    decide +kernel
  have e21419 : Deny 5 11 b21419 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21421 : Deny 5 11 b21421 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21423 : Deny 5 11 b21423 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e21425 : Deny 5 11 b21425 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21427 : Deny 5 11 b21427 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21429 : Deny 5 11 b21429 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21431 : Deny 5 11 b21431 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21433 : Deny 5 11 b21433 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21435 : Deny 5 11 b21435 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21437 : Deny 5 11 b21437 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21439 : Deny 5 11 b21439 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21441 : Deny 5 11 b21441 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21443 : Deny 5 11 b21443 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21445 : Deny 5 11 b21445 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21447 : Deny 5 11 b21447 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21449 : Deny 5 11 b21449 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21450 : Deny 5 11 b21450 := by
    apply closeAction rule_sound _ _ 64 [0x20c89c38c78d99e32d99e32e36678cb6678cb8d99e32e3]
    decide +kernel
  have e21448 : Deny 5 11 b21448 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21448 b21449 b21450 (by decide +kernel) e21449 e21450
  have e21446 : Deny 5 11 b21446 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21446 b21447 b21448 (by decide +kernel) e21447 e21448
  have e21444 : Deny 5 11 b21444 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21444 b21445 b21446 (by decide +kernel) e21445 e21446
  have e21442 : Deny 5 11 b21442 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21442 b21443 b21444 (by decide +kernel) e21443 e21444
  have e21440 : Deny 5 11 b21440 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21440 b21441 b21442 (by decide +kernel) e21441 e21442
  have e21438 : Deny 5 11 b21438 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21438 b21439 b21440 (by decide +kernel) e21439 e21440
  have e21436 : Deny 5 11 b21436 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21436 b21437 b21438 (by decide +kernel) e21437 e21438
  have e21434 : Deny 5 11 b21434 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21434 b21435 b21436 (by decide +kernel) e21435 e21436
  have e21432 : Deny 5 11 b21432 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21432 b21433 b21434 (by decide +kernel) e21433 e21434
  have e21430 : Deny 5 11 b21430 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21430 b21431 b21432 (by decide +kernel) e21431 e21432
  have e21428 : Deny 5 11 b21428 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21428 b21429 b21430 (by decide +kernel) e21429 e21430
  have e21426 : Deny 5 11 b21426 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21426 b21427 b21428 (by decide +kernel) e21427 e21428
  have e21424 : Deny 5 11 b21424 :=
    branchAction rule_sound _ _ 1
      0xb b21424 b21425 b21426 (by decide +kernel) e21425 e21426
  have e21422 : Deny 5 11 b21422 :=
    branchAction rule_sound _ _ 2
      0x263 b21422 b21423 b21424 (by decide +kernel) e21423 e21424
  have e21420 : Deny 5 11 b21420 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21420 b21421 b21422 (by decide +kernel) e21421 e21422
  have e21418 : Deny 5 11 b21418 :=
    branchAction rule_sound _ _ 1
      0xb b21418 b21419 b21420 (by decide +kernel) e21419 e21420
  have e21414 : Deny 5 11 b21414 :=
    branchAction rule_sound _ _ 1
      0x7 b21414 b21415 b21418 (by decide +kernel) e21415 e21418
  have e21410 : Deny 5 11 b21410 :=
    branchAction rule_sound _ _ 2
      0x223 b21410 b21411 b21414 (by decide +kernel) e21411 e21414
  have e21396 : Deny 5 11 b21396 :=
    branchAction rule_sound _ _ 3
      0xb9e3 b21396 b21397 b21410 (by decide +kernel) e21397 e21410
  have e21466 : Deny 5 11 b21466 := by
    apply closeAction rule_sound _ _ 64 [0x6678d91f89e3]
    decide +kernel
  have e21472 : Deny 5 11 b21472 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21474 : Deny 5 11 b21474 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e21476 : Deny 5 11 b21476 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21478 : Deny 5 11 b21478 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e21480 : Deny 5 11 b21480 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21482 : Deny 5 11 b21482 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21484 : Deny 5 11 b21484 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21486 : Deny 5 11 b21486 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21488 : Deny 5 11 b21488 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21490 : Deny 5 11 b21490 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21493 : Deny 5 11 b21493 := by
    apply closeAction rule_sound _ _ 64 [0x11]
    decide +kernel
  have e21494 : Deny 5 11 b21494 := by
    apply closeAction rule_sound _ _ 64 [0x64380a44b44b44b44b44b44b]
    decide +kernel
  have e21492 : Deny 5 11 b21492 :=
    branchAction rule_sound _ _ 2
      0x2e0 b21492 b21493 b21494 (by decide +kernel) e21493 e21494
  have e21509 : Deny 5 11 b21509 := by
    apply closeAction rule_sound _ _ 64 [0x19]
    decide +kernel
  have e21491 : Deny 5 11 b21491 :=
    branchAction rule_sound _ _ 2
      0x2a3 b21491 b21492 b21509 (by decide +kernel) e21492 e21509
  have e21489 : Deny 5 11 b21489 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21489 b21490 b21491 (by decide +kernel) e21490 e21491
  have e21487 : Deny 5 11 b21487 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21487 b21488 b21489 (by decide +kernel) e21488 e21489
  have e21485 : Deny 5 11 b21485 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21485 b21486 b21487 (by decide +kernel) e21486 e21487
  have e21483 : Deny 5 11 b21483 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21483 b21484 b21485 (by decide +kernel) e21484 e21485
  have e21481 : Deny 5 11 b21481 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21481 b21482 b21483 (by decide +kernel) e21482 e21483
  have e21479 : Deny 5 11 b21479 :=
    branchAction rule_sound _ _ 1
      0xb b21479 b21480 b21481 (by decide +kernel) e21480 e21481
  have e21477 : Deny 5 11 b21477 :=
    branchAction rule_sound _ _ 2
      0x223 b21477 b21478 b21479 (by decide +kernel) e21478 e21479
  have e21475 : Deny 5 11 b21475 :=
    branchAction rule_sound _ _ 1
      0xb b21475 b21476 b21477 (by decide +kernel) e21476 e21477
  have e21473 : Deny 5 11 b21473 :=
    branchAction rule_sound _ _ 2
      0x263 b21473 b21474 b21475 (by decide +kernel) e21474 e21475
  have e21471 : Deny 5 11 b21471 :=
    branchAction rule_sound _ _ 3
      0xb9e3 b21471 b21472 b21473 (by decide +kernel) e21472 e21473
  have e21511 : Deny 5 11 b21511 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21513 : Deny 5 11 b21513 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21514 : Deny 5 11 b21514 := by
    apply closeAction rule_sound _ _ 64 [0x826678c7d086678c2238d098d99e32e36678cb8d99e32e3]
    decide +kernel
  have e21512 : Deny 5 11 b21512 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21512 b21513 b21514 (by decide +kernel) e21513 e21514
  have e21510 : Deny 5 11 b21510 :=
    branchAction rule_sound _ _ 2
      0x2e7 b21510 b21511 b21512 (by decide +kernel) e21511 e21512
  have e21470 : Deny 5 11 b21470 :=
    branchAction rule_sound _ _ 2
      0x1e3 b21470 b21471 b21510 (by decide +kernel) e21471 e21510
  have e21532 : Deny 5 11 b21532 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21534 : Deny 5 11 b21534 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21536 : Deny 5 11 b21536 := by
    apply closeAction rule_sound _ _ 64 [0xdf4]
    decide +kernel
  have e21538 : Deny 5 11 b21538 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21540 : Deny 5 11 b21540 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21542 : Deny 5 11 b21542 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21543 : Deny 5 11 b21543 := by
    apply closeAction rule_sound _ _ 64 [0x190831c222708780a8d99e32e36678cb8d99e32e3]
    decide +kernel
  have e21541 : Deny 5 11 b21541 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21541 b21542 b21543 (by decide +kernel) e21542 e21543
  have e21539 : Deny 5 11 b21539 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21539 b21540 b21541 (by decide +kernel) e21540 e21541
  have e21537 : Deny 5 11 b21537 :=
    branchAction rule_sound _ _ 1
      0xb b21537 b21538 b21539 (by decide +kernel) e21538 e21539
  have e21535 : Deny 5 11 b21535 :=
    branchAction rule_sound _ _ 2
      0x223 b21535 b21536 b21537 (by decide +kernel) e21536 e21537
  have e21533 : Deny 5 11 b21533 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21533 b21534 b21535 (by decide +kernel) e21534 e21535
  have e21531 : Deny 5 11 b21531 :=
    branchAction rule_sound _ _ 4
      0x2f89e3 b21531 b21532 b21533 (by decide +kernel) e21532 e21533
  have e21558 : Deny 5 11 b21558 := by
    apply closeAction rule_sound _ _ 64 [0x2099e276788c78c8e278c7e27]
    decide +kernel
  have e21530 : Deny 5 11 b21530 :=
    branchAction rule_sound _ _ 2
      0x1e3 b21530 b21531 b21558 (by decide +kernel) e21531 e21558
  have e21565 : Deny 5 11 b21565 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e21529 : Deny 5 11 b21529 :=
    branchAction rule_sound _ _ 1
      0x9 b21529 b21530 b21565 (by decide +kernel) e21530 e21565
  have e21469 : Deny 5 11 b21469 :=
    branchAction rule_sound _ _ 2
      0x223 b21469 b21470 b21529 (by decide +kernel) e21470 e21529
  have e21465 : Deny 5 11 b21465 :=
    branchAction rule_sound _ _ 2
      0x2e7 b21465 b21466 b21469 (by decide +kernel) e21466 e21469
  have e21395 : Deny 5 11 b21395 :=
    branchAction rule_sound _ _ 2
      0x1e3 b21395 b21396 b21465 (by decide +kernel) e21396 e21465
  have e21568 : Deny 5 11 b21568 := by
    apply closeAction rule_sound _ _ 64 [0x820820e3108e27263107e278c42389e3]
    decide +kernel
  have e21579 : Deny 5 11 b21579 := by
    apply closeAction rule_sound _ _ 64 [0x20f89e32380f89e30f89e32389e3263]
    decide +kernel
  have e21588 : Deny 5 11 b21588 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21590 : Deny 5 11 b21590 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21592 : Deny 5 11 b21592 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21594 : Deny 5 11 b21594 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21596 : Deny 5 11 b21596 := by
    apply closeAction rule_sound _ _ 64 [0x199e3]
    decide +kernel
  have e21597 : Deny 5 11 b21597 := by
    apply closeAction rule_sound _ _ 64 [0x20e31c39c21e32236678cb8d99e32e36678cb8d99e32e3]
    decide +kernel
  have e21595 : Deny 5 11 b21595 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21595 b21596 b21597 (by decide +kernel) e21596 e21597
  have e21593 : Deny 5 11 b21593 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21593 b21594 b21595 (by decide +kernel) e21594 e21595
  have e21591 : Deny 5 11 b21591 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21591 b21592 b21593 (by decide +kernel) e21592 e21593
  have e21589 : Deny 5 11 b21589 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21589 b21590 b21591 (by decide +kernel) e21590 e21591
  have e21587 : Deny 5 11 b21587 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21587 b21588 b21589 (by decide +kernel) e21588 e21589
  have e21612 : Deny 5 11 b21612 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e21586 : Deny 5 11 b21586 :=
    branchAction rule_sound _ _ 3
      0x9e27 b21586 b21587 b21612 (by decide +kernel) e21587 e21612
  have e21578 : Deny 5 11 b21578 :=
    branchAction rule_sound _ _ 2
      0x1e3 b21578 b21579 b21586 (by decide +kernel) e21579 e21586
  have e21613 : Deny 5 11 b21613 := by
    apply closeAction rule_sound _ _ 64 [0x82083e232388c9e231f8]
    decide +kernel
  have e21577 : Deny 5 11 b21577 :=
    branchAction rule_sound _ _ 2
      0x223 b21577 b21578 b21613 (by decide +kernel) e21578 e21613
  have e21567 : Deny 5 11 b21567 :=
    branchAction rule_sound _ _ 2
      0x2e3 b21567 b21568 b21577 (by decide +kernel) e21568 e21577
  have e21620 : Deny 5 11 b21620 := by
    apply closeAction rule_sound _ _ 64 [0x820820820f88c7e231f82388c9e278c78c8e27]
    decide +kernel
  have e21566 : Deny 5 11 b21566 :=
    branchAction rule_sound _ _ 1
      0x7 b21566 b21567 b21620 (by decide +kernel) e21567 e21620
  have e21394 : Deny 5 11 b21394 :=
    branchAction rule_sound _ _ 2
      0x223 b21394 b21395 b21566 (by decide +kernel) e21395 e21566
  have e21382 : Deny 5 11 b21382 :=
    branchAction rule_sound _ _ 1
      0xb b21382 b21383 b21394 (by decide +kernel) e21383 e21394
  have e21260 : Deny 5 11 b21260 :=
    branchAction rule_sound _ _ 1
      0x7 b21260 b21261 b21382 (by decide +kernel) e21261 e21382
  have e21044 : Deny 5 11 b21044 :=
    branchAction rule_sound _ _ 2
      0x263 b21044 b21045 b21260 (by decide +kernel) e21045 e21260
  exact e21044
end OMA.Blocks5_11_245212.S21044
