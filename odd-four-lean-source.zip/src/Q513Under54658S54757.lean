import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S54757
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b54757 : Box := ![⟨54,62⟩,⟨66,86⟩,⟨11,14⟩,⟨1,52⟩,⟨959,999999999999999999⟩]
private def b54758 : Box := ![⟨54,57⟩,⟨66,86⟩,⟨13,14⟩,⟨7,43⟩,⟨959,1071⟩]
private def b54759 : Box := ![⟨58,62⟩,⟨66,86⟩,⟨13,14⟩,⟨7,43⟩,⟨959,1071⟩]
private def b54760 : Box := ![⟨58,62⟩,⟨67,86⟩,⟨13,13⟩,⟨8,38⟩,⟨967,1068⟩]
private def b54761 : Box := ![⟨58,62⟩,⟨67,86⟩,⟨14,14⟩,⟨8,38⟩,⟨967,1068⟩]
private theorem e54758 : Deny 5 13 b54758 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e54760 : Deny 5 13 b54760 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e54761 : Deny 5 13 b54761 := by
    apply closeAction rule_sound _ _ 64 [0xc4]
    decide +kernel
private theorem e54759 : Deny 5 13 b54759 :=
    branchAction rule_sound _ _ 6
      0x278df58c4 b54759 b54760 b54761 (by decide +kernel) e54760 e54761
private theorem e54757 : Deny 5 13 b54757 :=
    branchAction rule_sound _ _ 5
      0x7e37da3 b54757 b54758 b54759 (by decide +kernel) e54758 e54759
theorem deny5_13 : Deny 5 13 ![⟨54,62⟩,⟨66,86⟩,⟨11,14⟩,⟨1,52⟩,⟨959,999999999999999999⟩] := by
  exact e54757
end OMA.Blocks5_13_245212.S54757
