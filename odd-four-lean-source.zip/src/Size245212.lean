import BoxKernel245212

/-! Small outward-rounded integer logarithms for comparing enormous products
without ever computing the enclosed powers themselves. -/
namespace OMA.Box245212
open Finset

-- Nat.log squares its base at each recursive step, so the kernel can
-- compute the exact bit bound in logarithmically many comparisons.
def sizeLo (n : ℕ) := Nat.log 2 (n^128)
def sizeHi (n : ℕ) := sizeLo n+1
def Enc (l h n : ℕ) := 2^l ≤ n^128 ∧ n^128 ≤ 2^h

theorem enc_range {r : Range} {n : ℕ} (pos : 0<r.lo) (inside : r.has n) :
    Enc (sizeLo r.lo) (sizeHi r.hi) n := by
  unfold sizeHi sizeLo
  simp only [←Nat.log2_eq_log_two]
  exact ⟨(Nat.log2_self_le (pow_ne_zero 128 pos.ne')).trans (Nat.pow_le_pow_left inside.1 128),
    (Nat.pow_le_pow_left inside.2 128).trans Nat.lt_log2_self.le⟩

theorem enc_one : Enc 0 0 1 := by simp [Enc]
theorem enc_mul {a b l h L H : ℕ} (x : Enc l h a) (y : Enc L H b) :
    Enc (l+L) (h+H) (a*b) := by
  unfold Enc; rw [pow_add,pow_add,mul_pow]
  exact ⟨Nat.mul_le_mul x.1 y.1,Nat.mul_le_mul x.2 y.2⟩

theorem enc_pow {a e l h : ℕ} {b : Range} (x : Enc l h a) (y : b.has e) :
    Enc (l*b.lo) (h*b.hi) (a^e) := by
  unfold Enc
  have swap : (a^e)^128=(a^128)^e := by rw [←pow_mul,←pow_mul,mul_comm e]
  rw [swap, pow_mul, pow_mul]
  exact ⟨(Nat.pow_le_pow_right (by positivity) y.1).trans (Nat.pow_le_pow_left x.1 e),
    (Nat.pow_le_pow_left x.2 e).trans (Nat.pow_le_pow_right (by positivity) y.2)⟩

theorem enc_prod {ι : Type*} [DecidableEq ι] (s : Finset ι) (l h a : ι→ℕ)
    (hs : ∀ i∈s,Enc (l i) (h i) (a i)) : Enc (∑ i∈s,l i) (∑ i∈s,h i) (∏ i∈s,a i) := by
  induction s using Finset.induction_on with
  | empty => simpa using enc_one
  | @insert i s hi ih =>
    simpa [hi] using enc_mul (hs i (mem_insert_self i s))
      (ih (fun j hj => hs j (mem_insert_of_mem hj)))

theorem enc_lt {a b l h L H : ℕ} (x : Enc l h a) (y : Enc L H b) (sep : h<L) : a<b := by
  by_contra! wrong
  have big := Nat.pow_lt_pow_right (by decide : 1 < 2) sep
  have sm := (y.1.trans (Nat.pow_le_pow_left wrong 128)).trans x.2
  exact big.not_ge sm

end OMA.Box245212
