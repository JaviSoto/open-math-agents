import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S21702
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b21702 : Box := ![⟨27,30⟩,⟨63,126⟩,⟨15,30⟩,⟨3,75⟩,⟨79,93⟩]
theorem deny5_13 : Deny 5 13 ![⟨27,30⟩,⟨63,126⟩,⟨15,30⟩,⟨3,75⟩,⟨79,93⟩] := by
  have e21702 : Deny 5 13 b21702 := by
    apply closeAction rule_sound _ _ 64 [0x2420c70c92025838491d6283087de1261284082aa8844278dea84258adc3248dcb8470c3ae12430f8ae12611e1261284,0xe370820c8ae1109e37ac3dc32370c3de3223263102083204278083108e370f8ac32092b72e32078c90820c9238dc20e1,0x20820832091c4238ddf]
    decide +kernel
  exact e21702
end OMA.Blocks5_13_245212.S21702
