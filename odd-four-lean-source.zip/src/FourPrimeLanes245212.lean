import FourRoot245212
import Quick517245212
import MiniChunk57245212
import Chunk519245212
import Fast523245212
import Fast529245212
import Cert531245212
import Chunk711245212
import CertFast713245212

/-! Assemble independently checked prime supports into the four-prime exclusion. -/
namespace OMA.FourPrimeLanes245212
open OMA.Box245212

private theorem cover {p q : ℕ} {b : Box} (d : Deny p q b)
    (inside : ∀ i, (b i).lo ≤ (rootBox p q i).lo ∧ (rootBox p q i).hi ≤ (b i).hi) :
    Deny p q (rootBox p q) := by
  intro v fits c
  apply d v _ c
  exact fun i => ⟨(inside i).1.trans (fits i).1,(fits i).2.trans (inside i).2⟩

theorem roots_of_two (q11 : Deny 5 11 (rootBox 5 11)) (q13 : Deny 5 13 (rootBox 5 13)) :
    ∀ pq∈families, Deny pq.1 pq.2 (rootBox pq.1 pq.2) := by
  intro pq mem
  simp only [families,Finset.mem_insert,Finset.mem_singleton] at mem
  rcases mem with h|h|h|h|h|h|h|h|h|h <;> subst pq
  · exact cover OMA.Blocks5_7_245212.deny5_7 (by decide +kernel)
  · exact q11
  · exact q13
  · exact cover OMA.Blocks5_17_245212.deny5_17 (by decide +kernel)
  · exact cover OMA.Blocks5_19_245212.deny5_19 (by decide +kernel)
  · exact cover deny5_23 (by decide +kernel)
  · exact cover deny5_29 (by decide +kernel)
  · exact cover deny5_31 (by decide +kernel)
  · exact cover OMA.Blocks7_11_245212.deny7_11 (by decide +kernel)
  · exact cover deny7_13 (by decide +kernel)

end OMA.FourPrimeLanes245212
