import Size245212
import PointGap245212
import SelectedPrime245212
import HeightSingleton245212

/-! Exact logarithmic comparisons and a divisibility veto for a four-prime
rounding box. The only powers actually evaluated by this test have exponent
128, even when the candidate exponents are much larger. -/
namespace OMA.Box245212
open Finset OMA.Height245212
noncomputable section

def denBits (p q : ℕ) (b : Box) (s : Finset (Fin 4)) (i : Fin 4) : ℕ :=
  sizeHi ((b i.castSucc).hi+1) + (if i∈s then 2 else (b i.castSucc).hi)*sizeHi (baseBox p q b i).hi
def powBits (p q : ℕ) (b : Box) (i : Fin 4) : ℕ :=
  (b i.castSucc).lo*sizeLo (baseBox p q b i).lo
def comparison (p q : ℕ) (b : Box) (s : Finset (Fin 4)) (i : Fin 4) :=
  sizeHi (4*(8+((baseBox p q b i).hi-1)))+∑ j∈univ.erase i,denBits p q b s j

private theorem enc_upper {n l h : ℕ} (en : Enc l h n) : Enc 0 h n :=
  ⟨(Nat.one_le_two_pow.trans en.1),en.2⟩

theorem denBits_body {p q : ℕ} {b : Box} {v : Values} (inside : Fits b v)
    (c : Candidate p q v) (s : Finset (Fin 4)) (i : Fin 4) :
    Enc 0 (denBits p q b s i) (localDen (bases p q v) (exponents v) s i) := by
  have hp := inside_primes (p:=p) (q:=q) inside i
  have he := inside i.castSucc
  have hpos := (c.prime i).one_lt
  have add := enc_range (r:=⟨1,(b i.castSucc).hi+1⟩) (n:=exponents v i+1)
    Nat.zero_lt_one ⟨Nat.succ_le_succ (Nat.zero_le _), Nat.add_le_add_right he.2 1⟩
  by_cases hi : i∈s
  · have ep := enc_range (r:=⟨1,(baseBox p q b i).hi⟩) (n:=bases p q v i-1) Nat.zero_lt_one
      ⟨show 1≤bases p q v i-1 by omega,(Nat.sub_le _ _).trans hp.2⟩
    have two := enc_pow ep (b:=⟨2,2⟩) (e:=2) ⟨le_rfl,le_rfl⟩
    simpa [denBits,localDen,den,hi,Nat.mul_comm 2] using enc_upper (enc_mul add two)
  · have ep := enc_range (r:=⟨1,(baseBox p q b i).hi⟩) (n:=bases p q v i)
      Nat.zero_lt_one ⟨hpos.le,hp.2⟩
    have power := enc_pow ep (b:=b i.castSucc) (e:=exponents v i) he
    simpa [denBits,localDen,hi,Nat.mul_comm (sizeHi _)] using enc_upper (enc_mul add power)

theorem comparison_sound {p q : ℕ} {b : Box} {v : Values} (inside : Fits b v)
    (c : Candidate p q v) (start : ∀ i,1<(baseBox p q b i).lo) (s : Finset (Fin 4)) (i : Fin 4)
    (cmp : comparison p q b s i < powBits p q b i) :
    4*(8+(bases p q v i-1))*(∏ j∈univ.erase i,localDen (bases p q v) (exponents v) s j) <
      bases p q v i^exponents v i := by
  have hp := inside_primes (p:=p) (q:=q) inside i
  have ep := enc_range (r:=baseBox p q b i) (by have := start i; omega) hp
  have pl := enc_pow ep (inside i.castSucc)
  have co := enc_range (r:=⟨1,4*(8+((baseBox p q b i).hi-1))⟩) (n:=4*(8+(bases p q v i-1)))
    Nat.zero_lt_one ⟨by change 1≤4*(8+_); omega, by have := hp.2; change 4*(8+_)≤4*(8+_); omega⟩
  have ds := enc_prod (univ.erase i) (fun _=>0) (denBits p q b s)
    (localDen (bases p q v) (exponents v) s) (fun j _ => denBits_body inside c s j)
  apply enc_lt (enc_mul co ds) pl
  simpa only [comparison,powBits,Nat.mul_comm ((b i.castSucc).lo)] using cmp

def noExp (b : Box) (t : Range) : Bool :=
  decide (∀ j : Fin 4,(b j.castSucc).hi+1<t.lo ∨
    t.lo=t.hi ∧ (b j.castSucc).hi+1<((b j.castSucc).lo/t.lo+1)*t.lo)

theorem exp_sound {b : Box} {v : Values} {t : Range} {P : ℕ} (fit : Fits b v) (pt : t.has P)
    (h : noExp b t=true) (i : Fin 4) : ¬P∣exponents v i+1 := by
  have hi := fit i.castSucc
  have eLo := hi.1
  have eHi := hi.2
  have pLo := pt.1
  have z := of_decide_eq_true h i
  dsimp only [exponents]
  intro d
  rcases z with lt|⟨eq,no⟩
  · exact (Nat.le_of_dvd (by omega) d).not_gt (show v i.castSucc+1<P by omega)
  · have same : P=t.lo := le_antisymm (pt.2.trans_eq eq.symm) pt.1
    subst P
    obtain ⟨w,d⟩ := d
    have pp : 0<t.lo := by by_contra! h; simp [show t.lo=0 by omega] at d
    have low : (b i.castSucc).lo/t.lo < w := (Nat.div_lt_iff_lt_mul pp).mpr (by
      rw [mul_comm]; omega)
    have bad := Nat.mul_le_mul_right t.lo (Nat.succ_le_of_lt low)
    rw [mul_comm w,←d] at bad
    exact (no.trans_le bad).not_ge (Nat.add_le_add_right eHi 1)

theorem yr_antitone {p P e E : ℕ} (hp : 1<p) (pp : p≤P) (ee : e≤E) : yr P E≤yr p e := by
  have a : (1:ℚ)<p := by exact_mod_cast hp
  have b : (p:ℚ)≤P := by exact_mod_cast pp
  have f : (e:ℚ)≤E := by exact_mod_cast ee
  unfold yr
  rw [div_le_div_iff₀ (mul_pos (by linarith) (by positivity)) (mul_pos (by linarith) (by positivity))]
  have l : (P:ℚ)*((p:ℚ)-1)≤(p:ℚ)*((P:ℚ)-1) := by nlinarith
  calc
    _ = ((P:ℚ)*((p:ℚ)-1))*(e+1) := by ring
    _ ≤ ((p:ℚ)*((P:ℚ)-1))*(E+1) := mul_le_mul l (by linarith) (by positivity) (mul_nonneg (by positivity) (by linarith))
    _ = _ := by ring

def upperY (p q : ℕ) (b : Box) (i : Fin 4) := yr (baseBox p q b i).lo (b i.castSucc).lo

def strictBits (p q : ℕ) (b : Box) (i : Fin 4) : Prop :=
  ((baseBox p q b i).hi-1)*(∏ j∈univ.erase i,(baseBox p q b j).lo) <
    ∏ j∈univ.erase i,((baseBox p q b j).lo-1)*((b j.castSucc).lo+1)
instance (p q : ℕ) (b : Box) (i : Fin 4) : Decidable (strictBits p q b i) :=
  inferInstanceAs (Decidable (_<_))

theorem strictBits_sound {p q : ℕ} {b : Box} (start : ∀ i,1<(baseBox p q b i).lo)
    {i : Fin 4} (real : (baseBox p q b i).lo≤(baseBox p q b i).hi) (strict : strictBits p q b i) :
    (((baseBox p q b i).hi:ℚ)-1)*(∏ j∈univ.erase i,upperY p q b j)<1 := by
  let base (j : Fin 4) := (baseBox p q b j).lo
  let d (j : Fin 4) := (base j-1)*((b j.castSucc).lo+1)
  have dp (j : Fin 4) : 0<d j := Nat.mul_pos (Nat.sub_pos_of_lt (start j)) (Nat.zero_lt_succ _)
  have denom : (0:ℚ)<∏ j∈univ.erase i,(d j:ℚ) := prod_pos (fun j _=>by exact_mod_cast dp j)
  have y (j : Fin 4) : upperY p q b j=(base j:ℚ)/(d j:ℚ) := by
    simp only [upperY,yr,d,base,Nat.cast_mul,Nat.cast_add,Nat.cast_one,Nat.cast_sub (start j).le]
  simp_rw [y]
  rw [prod_div_distrib,←mul_div_assoc,div_lt_iff₀ denom,one_mul]
  have c : (((baseBox p q b i).hi-1:ℕ):ℚ)=((baseBox p q b i).hi:ℚ)-1 := by
    rw [Nat.cast_sub ((start i).le.trans real),Nat.cast_one]
  rw [←c]
  exact_mod_cast strict

def roundLeaf (p q : ℕ) (b : Box) (s : Finset (Fin 4)) (t : Fin 4) : Bool :=
  decide ((∀ i,1<(baseBox p q b i).lo) ∧ t∈s ∧ (∀ i∈s,i≤t) ∧
    (∀ i∈s,comparison p q b s i < powBits p q b i) ∧
    (s={t} ∨ noExp b (baseBox p q b t)=true ∨ (∀ i∈s,strictBits p q b i)))

theorem round_sound {p q : ℕ} {b : Box} {s : Finset (Fin 4)} {t : Fin 4}
    (h : roundLeaf p q b s t=true) : Deny p q b := by
  obtain ⟨start,ht,high,cmp,why⟩ := of_decide_eq_true h
  intro v inside c
  have odd (i : Fin 4) : 3≤bases p q v i := c.ordered.monotone (Fin.zero_le i)
  have same := point_gap _ _ c.prime c.pos s c.score
    (fun i hi => comparison_sound inside c start s i (cmp i hi))
  rcases why with singleton|no|strict
  · subst s
    exact singleton_ne _ _ c.prime odd c.ordered.injective c.eqn t (same.trans c.score.symm)
  · obtain ⟨j,dj⟩ := selected_divides _ _ c.prime c.ordered s t ht
      (fun j hj => c.ordered.monotone (high j hj)) (odd t) same
    exact exp_sound inside (inside_primes inside t) no j dj
  · have nonneg (i : Fin 4) : 0≤yr (bases p q v i) (exponents v i) := by
      have a : (1:ℚ)<bases p q v i := by exact_mod_cast (c.prime i).one_lt
      unfold yr
      exact div_nonneg (by positivity) (mul_nonneg (by linarith) (by positivity))
    have le (i : Fin 4) : yr (bases p q v i) (exponents v i)≤upperY p q b i :=
      yr_antitone (start i) (inside_primes inside i).1 (inside i.castSucc).1
    have neg := strict_prod _ _ (fun i=>(c.prime i).one_lt) c.pos s ⟨t,ht⟩ (by
      intro i hi
      have bounds := inside_primes (p:=p) (q:=q) inside i
      apply lt_of_le_of_lt _ (strictBits_sound start (bounds.1.trans bounds.2) (strict i hi))
      have lp : (bases p q v i:ℚ) ≤ (baseBox p q b i).hi := by exact_mod_cast (inside_primes inside i).2
      have gpN : 1≤(baseBox p q b i).hi := (c.prime i).one_lt.le.trans (inside_primes inside i).2
      have gp : (1:ℚ)≤(baseBox p q b i).hi := by exact_mod_cast gpN
      exact mul_le_mul (by linarith) (prod_le_prod (fun j _ => nonneg j) (fun j _ => le j))
        (prod_nonneg (fun j _=> nonneg j)) (by linarith))
    exact (same.trans c.score.symm).not_lt neg

end
end OMA.Box245212
