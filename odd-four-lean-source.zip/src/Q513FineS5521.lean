import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S5521
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b5521 : Box := ![⟨15,22⟩,⟨31,1920000000000000011376⟩,⟨11,1920000000000000011376⟩,⟨3,1920000000000000011376⟩,⟨29,35⟩]
theorem deny5_13 : Deny 5 13 ![⟨15,22⟩,⟨31,1920000000000000011376⟩,⟨11,1920000000000000011376⟩,⟨3,1920000000000000011376⟩,⟨29,35⟩] := by
  have e5521 : Deny 5 13 b5521 := by
    apply closeAction rule_sound _ _ 64 [0xdc2083262107e162a22020f80e12611c3e031c31c80838470e12430c92030f8de1243e37d8884784a84988888a887dc4,0x820820f8dc3248847849888de20820820e12441f8dc20838c98c41f8083109e370f8dc32472882622020abaa8849dd6]
    decide +kernel
  exact e5521
end OMA.Blocks5_13_245212.S5521
