import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S24953
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b24953 : Box := ![⟨31,37⟩,⟨31,41⟩,⟨31,1920000000000000011376⟩,⟨3,1017986577181208059764⟩,⟨127,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨31,37⟩,⟨31,41⟩,⟨31,1920000000000000011376⟩,⟨3,1017986577181208059764⟩,⟨127,233⟩] := by
  have e24953 : Deny 5 13 b24953 := by
    apply closeAction rule_sound _ _ 64 [0xdc32438880c3dc90f8de22221c30f8dc80f8df61c910b0dfe37da21c4087e37da222229f7f8df6d631f8de31e32442e3,0xbdc26f71f88a8c98c472f709bdc8c97e22842dcbc47c21f88c42788c88c77ef88a50a7c30f8dc97f8df6888087df6103,0x71cbc42ef7e325f8c972f11cbe3109e368c77e229fe37db588ada311cbe3709e2f7e325c]
    decide +kernel
  exact e24953
end OMA.Blocks5_13_245212.S24953
