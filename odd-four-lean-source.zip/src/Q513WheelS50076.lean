import FastReplay245212
import SparseDigit245212
import WheelRule245212

import Q513Under50076S50079
import Q513Under50076S50096
import Q513Under50076S50113
import Q513Under50076S50134
import Q513Under50076S50153
import Q513Under50076S50174
import Q513Under50076S50190
import Q513Under50076S50199
import Q513Under50076S50210

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S50076
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b50076 : Box := ![⟨127,190⟩,⟨23,24⟩,⟨31,62⟩,⟨1,67⟩,⟨959,999999999999999999⟩]
private def b50077 : Box := ![⟨127,152⟩,⟨23,24⟩,⟨31,62⟩,⟨1,67⟩,⟨959,999999999999999999⟩]
private def b50078 : Box := ![⟨127,152⟩,⟨23,24⟩,⟨31,41⟩,⟨1,61⟩,⟨959,999999999999999999⟩]
private def b50079 : Box := ![⟨127,152⟩,⟨23,24⟩,⟨31,41⟩,⟨1,53⟩,⟨959,1918⟩]
private def b50096 : Box := ![⟨127,152⟩,⟨23,24⟩,⟨31,41⟩,⟨1,53⟩,⟨1919,999999999999999999⟩]
private def b50109 : Box := ![⟨127,152⟩,⟨23,24⟩,⟨42,62⟩,⟨1,61⟩,⟨959,999999999999999999⟩]
private def b50110 : Box := ![⟨127,152⟩,⟨23,24⟩,⟨42,62⟩,⟨1,61⟩,⟨959,1918⟩]
private def b50111 : Box := ![⟨127,152⟩,⟨23,24⟩,⟨42,62⟩,⟨1,2⟩,⟨959,1918⟩]
private def b50112 : Box := ![⟨127,152⟩,⟨23,24⟩,⟨42,62⟩,⟨3,56⟩,⟨959,1918⟩]
private def b50113 : Box := ![⟨127,152⟩,⟨23,23⟩,⟨42,62⟩,⟨3,56⟩,⟨959,1918⟩]
private def b50132 : Box := ![⟨127,152⟩,⟨24,24⟩,⟨42,62⟩,⟨3,56⟩,⟨959,1918⟩]
private def b50133 : Box := ![⟨127,152⟩,⟨23,24⟩,⟨42,62⟩,⟨1,61⟩,⟨1919,999999999999999999⟩]
private def b50134 : Box := ![⟨127,138⟩,⟨23,24⟩,⟨42,62⟩,⟨1,55⟩,⟨1919,999999999999999999⟩]
private def b50153 : Box := ![⟨139,152⟩,⟨23,24⟩,⟨42,62⟩,⟨1,55⟩,⟨1919,999999999999999999⟩]
private def b50172 : Box := ![⟨153,190⟩,⟨23,24⟩,⟨31,62⟩,⟨1,67⟩,⟨959,999999999999999999⟩]
private def b50173 : Box := ![⟨153,190⟩,⟨23,24⟩,⟨31,41⟩,⟨1,67⟩,⟨959,999999999999999999⟩]
private def b50174 : Box := ![⟨153,190⟩,⟨23,24⟩,⟨31,41⟩,⟨1,59⟩,⟨959,1918⟩]
private def b50189 : Box := ![⟨153,190⟩,⟨23,24⟩,⟨31,41⟩,⟨1,59⟩,⟨1919,999999999999999999⟩]
private def b50190 : Box := ![⟨153,169⟩,⟨23,24⟩,⟨31,41⟩,⟨1,53⟩,⟨1919,999999999999999999⟩]
private def b50199 : Box := ![⟨170,190⟩,⟨23,24⟩,⟨31,41⟩,⟨1,53⟩,⟨1919,999999999999999999⟩]
private def b50210 : Box := ![⟨153,190⟩,⟨23,24⟩,⟨42,62⟩,⟨1,67⟩,⟨959,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨127,190⟩,⟨23,24⟩,⟨31,62⟩,⟨1,67⟩,⟨959,999999999999999999⟩] := by
  have e50079 : Deny 5 13 b50079 := OMA.Blocks5_13_245212.S50079.deny5_13
  have e50096 : Deny 5 13 b50096 := OMA.Blocks5_13_245212.S50096.deny5_13
  have e50078 : Deny 5 13 b50078 :=
    branchAction rule_sound _ _ 2
      0x2e3 b50078 b50079 b50096 (by decide +kernel) e50079 e50096
  have e50111 : Deny 5 13 b50111 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
  have e50113 : Deny 5 13 b50113 := OMA.Blocks5_13_245212.S50113.deny5_13
  have e50132 : Deny 5 13 b50132 := by
    apply closeAction rule_sound _ _ 64 [0x15e37]
    decide +kernel
  have e50112 : Deny 5 13 b50112 :=
    branchAction rule_sound _ _ 1
      0x8 b50112 b50113 b50132 (by decide +kernel) e50113 e50132
  have e50110 : Deny 5 13 b50110 :=
    branchAction rule_sound _ _ 2
      0x2a3 b50110 b50111 b50112 (by decide +kernel) e50111 e50112
  have e50134 : Deny 5 13 b50134 := OMA.Blocks5_13_245212.S50134.deny5_13
  have e50153 : Deny 5 13 b50153 := OMA.Blocks5_13_245212.S50153.deny5_13
  have e50133 : Deny 5 13 b50133 :=
    branchAction rule_sound _ _ 2
      0x1e3 b50133 b50134 b50153 (by decide +kernel) e50134 e50153
  have e50109 : Deny 5 13 b50109 :=
    branchAction rule_sound _ _ 1
      0xb b50109 b50110 b50133 (by decide +kernel) e50110 e50133
  have e50077 : Deny 5 13 b50077 :=
    branchAction rule_sound _ _ 2
      0x263 b50077 b50078 b50109 (by decide +kernel) e50078 e50109
  have e50174 : Deny 5 13 b50174 := OMA.Blocks5_13_245212.S50174.deny5_13
  have e50190 : Deny 5 13 b50190 := OMA.Blocks5_13_245212.S50190.deny5_13
  have e50199 : Deny 5 13 b50199 := OMA.Blocks5_13_245212.S50199.deny5_13
  have e50189 : Deny 5 13 b50189 :=
    branchAction rule_sound _ _ 2
      0x1e3 b50189 b50190 b50199 (by decide +kernel) e50190 e50199
  have e50173 : Deny 5 13 b50173 :=
    branchAction rule_sound _ _ 2
      0x2e3 b50173 b50174 b50189 (by decide +kernel) e50174 e50189
  have e50210 : Deny 5 13 b50210 := OMA.Blocks5_13_245212.S50210.deny5_13
  have e50172 : Deny 5 13 b50172 :=
    branchAction rule_sound _ _ 1
      0x9 b50172 b50173 b50210 (by decide +kernel) e50173 e50210
  have e50076 : Deny 5 13 b50076 :=
    branchAction rule_sound _ _ 1
      0x7 b50076 b50077 b50172 (by decide +kernel) e50077 e50172
  exact e50076
end OMA.Blocks5_13_245212.S50076
