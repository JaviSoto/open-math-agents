import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S20331
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b20331 : Box := ![⟨23,30⟩,⟨31,62⟩,⟨15,30⟩,⟨3,1129131513647642686635⟩,⟨79,113⟩]
theorem deny5_13 : Deny 5 13 ![⟨23,30⟩,⟨31,62⟩,⟨15,30⟩,⟨3,1129131513647642686635⟩,⟨79,113⟩] := by
  have e20331 : Deny 5 13 b20331 := by
    apply closeAction rule_sound _ _ 64 [0xc4088e37d882830f8de325ee37da31dee37da32371c42c30f78c90f8df68c81021f8de3244782238df68c4238de31e3,0xdc90f8df61c31021f8df623628be232030f8de325ee37d877b8df68c8087de3103dc38c80e32430e32232030f7203dc9,0xe37109e371c30f8dc90f8df61f72092842df0f8df61c21c2237da31030c70e32430f8dc78c87c3102238df61e32430f8,0x109e370c38c88c78c87c31c30e32470c38c70e3223223256e37103108e370c90c32032470c32030f8dc81c80c3243103,0x102238df61c3088d821f8df620a7c3e371c3e37d87103087e37da3108e378c98c47f8dc3e370c8e370e32477f8dc40e3,0x1e0e325f2830f88c80f8de32631df0f88c70dee37da3238df68c78c80c3e37203e37243]
    decide +kernel
  exact e20331
end OMA.Blocks5_13_245212.S20331
