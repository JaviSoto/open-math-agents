import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S31494
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b31494 : Box := ![⟨38,41⟩,⟨63,84⟩,⟨63,1920000000000000011376⟩,⟨1,718295185477505923801⟩,⟨959,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨38,41⟩,⟨63,84⟩,⟨63,1920000000000000011376⟩,⟨1,718295185477505923801⟩,⟨959,999999999999999999⟩] := by
  have e31494 : Deny 5 13 b31494 := by
    apply closeAction rule_sound _ _ 64 [0xe23254e36be229ce37d878c88dcbdebe326f8cb7dfe361f8087e368df2d6e222b88dfbdfe378c9e368c8e23256e222a3,0xe2f8dcbe3278be372f8c9e2f72f8c98c8e2f72f8c98dc2f8bdcbe325ce368c80870888dcbe32ef7b8be326372f8cbbdf,0xbe32f68debe32c21e37af8cb8debe32e37af8cb8debe32ef8c972f8debe3278d8708272f8c9e2f8dcbe3278be372f8c9,0x8debe32e37af8cb8debe32e37af8cb8debe32e37af8cb8debe32e37af8cb8debe32e37af8cb8debe32f68debe32f68de,0x8c90888c98de2e378b8de2de2e378b8de2e378b0c222f088d888de2e378b8debcb8debe32e37af8cb8debe32e37af8cb,0x8c98de2e378b087be326f8c88dcbe32e372f8cb8dcbe32e372f8cb8dcbe32e372f8cb8dcbe32ef09cbc38c9bc8bc3bc3,0xda378bda378bbe3276bc708272f8c9bdcbe324222f088d87bdcbe326f72f71cbc30882542ca8de2e378b8de2e378b088,0x8272f8c9bdcbc3bc38c90880888c9]
    decide +kernel
  exact e31494
end OMA.Blocks5_13_245212.S31494
