import FastReplay245212
import SparseDigit245212
import FastRound245212
import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S19130
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b19130 : Box := ![⟨47,94⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨1,1450666666666666675297⟩,⟨103,999999999999999999⟩]
private def b19131 : Box := ![⟨47,94⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨1,994807017543859655065⟩,⟨103,206⟩]
private def b19132 : Box := ![⟨47,94⟩,⟨10,14⟩,⟨15,30⟩,⟨1,994807017543859655057⟩,⟨103,199⟩]
private def b19133 : Box := ![⟨47,94⟩,⟨10,11⟩,⟨15,30⟩,⟨1,46⟩,⟨103,199⟩]
private def b19134 : Box := ![⟨47,62⟩,⟨10,11⟩,⟨15,30⟩,⟨1,45⟩,⟨103,199⟩]
private def b19135 : Box := ![⟨47,62⟩,⟨10,11⟩,⟨15,30⟩,⟨1,37⟩,⟨103,135⟩]
private def b19150 : Box := ![⟨47,62⟩,⟨10,11⟩,⟨15,30⟩,⟨1,37⟩,⟨136,199⟩]
private def b19151 : Box := ![⟨47,62⟩,⟨10,11⟩,⟨15,30⟩,⟨1,2⟩,⟨137,199⟩]
private def b19156 : Box := ![⟨47,62⟩,⟨10,11⟩,⟨15,30⟩,⟨3,35⟩,⟨137,199⟩]
private def b19167 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨15,30⟩,⟨1,45⟩,⟨103,199⟩]
private def b19168 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨15,30⟩,⟨1,2⟩,⟨103,199⟩]
private def b19173 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨15,30⟩,⟨3,45⟩,⟨103,199⟩]
private def b19174 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨15,30⟩,⟨3,45⟩,⟨119,149⟩]
private def b19181 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨15,30⟩,⟨3,45⟩,⟨150,199⟩]
private def b19182 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨15,20⟩,⟨3,41⟩,⟨151,199⟩]
private def b19191 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨21,30⟩,⟨3,41⟩,⟨151,199⟩]
private def b19198 : Box := ![⟨47,94⟩,⟨12,14⟩,⟨15,30⟩,⟨1,46⟩,⟨103,199⟩]
private def b19209 : Box := ![⟨47,94⟩,⟨10,14⟩,⟨31,1920000000000000011376⟩,⟨1,994807017543859655057⟩,⟨103,199⟩]
private def b19210 : Box := ![⟨47,94⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨1,994807017543859655057⟩,⟨103,199⟩]
private def b19211 : Box := ![⟨47,94⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨1,2⟩,⟨103,199⟩]
private def b19212 : Box := ![⟨47,94⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655056⟩,⟨103,199⟩]
private def b19213 : Box := ![⟨47,62⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655056⟩,⟨129,199⟩]
private def b19214 : Box := ![⟨47,62⟩,⟨10,11⟩,⟨31,62⟩,⟨3,945066666666666672296⟩,⟨131,199⟩]
private def b19215 : Box := ![⟨47,62⟩,⟨10,10⟩,⟨31,62⟩,⟨3,51⟩,⟨131,199⟩]
private def b19230 : Box := ![⟨47,62⟩,⟨11,11⟩,⟨31,62⟩,⟨3,51⟩,⟨131,199⟩]
private def b19231 : Box := ![⟨47,62⟩,⟨10,11⟩,⟨63,1920000000000000011376⟩,⟨3,945066666666666672296⟩,⟨131,199⟩]
private def b19232 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655056⟩,⟨129,199⟩]
private def b19233 : Box := ![⟨47,94⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨1,994807017543859655057⟩,⟨103,199⟩]
private def b19234 : Box := ![⟨47,94⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨1,994807017543859655065⟩,⟨207,999999999999999999⟩]
private def b19235 : Box := ![⟨47,94⟩,⟨10,14⟩,⟨15,30⟩,⟨1,864390243902439029553⟩,⟨207,999999999999999999⟩]
private def b19236 : Box := ![⟨47,94⟩,⟨10,11⟩,⟨15,30⟩,⟨1,46⟩,⟨207,999999999999999999⟩]
private def b19237 : Box := ![⟨47,62⟩,⟨10,11⟩,⟨15,30⟩,⟨1,45⟩,⟨207,999999999999999999⟩]
private def b19238 : Box := ![⟨47,62⟩,⟨10,11⟩,⟨15,30⟩,⟨1,39⟩,⟨207,315⟩]
private def b19251 : Box := ![⟨47,62⟩,⟨10,11⟩,⟨15,30⟩,⟨1,39⟩,⟨316,660⟩]
private def b19258 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨15,30⟩,⟨1,45⟩,⟨207,999999999999999999⟩]
private def b19259 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨15,30⟩,⟨1,45⟩,⟨207,414⟩]
private def b19260 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨15,20⟩,⟨1,39⟩,⟨207,414⟩]
private def b19261 : Box := ![⟨63,75⟩,⟨10,11⟩,⟨15,20⟩,⟨1,34⟩,⟨207,414⟩]
private def b19264 : Box := ![⟨76,94⟩,⟨10,11⟩,⟨15,20⟩,⟨1,34⟩,⟨207,414⟩]
private def b19265 : Box := ![⟨76,94⟩,⟨10,11⟩,⟨15,20⟩,⟨1,2⟩,⟨207,414⟩]
private def b19266 : Box := ![⟨76,94⟩,⟨10,11⟩,⟨15,20⟩,⟨3,34⟩,⟨207,414⟩]
private def b19281 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨21,30⟩,⟨1,39⟩,⟨207,414⟩]
private def b19282 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨21,30⟩,⟨1,2⟩,⟨207,414⟩]
private def b19283 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨21,30⟩,⟨3,39⟩,⟨207,414⟩]
private def b19284 : Box := ![⟨63,75⟩,⟨10,11⟩,⟨21,30⟩,⟨3,39⟩,⟨207,414⟩]
private def b19297 : Box := ![⟨76,94⟩,⟨10,11⟩,⟨21,30⟩,⟨3,39⟩,⟨207,414⟩]
private def b19302 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨15,30⟩,⟨1,45⟩,⟨415,999999999999999999⟩]
private def b19303 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨15,20⟩,⟨1,40⟩,⟨415,999999999999999999⟩]
private def b19308 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨21,30⟩,⟨1,40⟩,⟨415,999999999999999999⟩]
private def b19309 : Box := ![⟨63,75⟩,⟨10,11⟩,⟨21,30⟩,⟨1,40⟩,⟨415,999999999999999999⟩]
private def b19316 : Box := ![⟨76,94⟩,⟨10,11⟩,⟨21,30⟩,⟨1,40⟩,⟨415,999999999999999999⟩]
private def b19317 : Box := ![⟨76,94⟩,⟨10,11⟩,⟨21,30⟩,⟨1,40⟩,⟨415,830⟩]
private def b19326 : Box := ![⟨76,94⟩,⟨10,11⟩,⟨21,30⟩,⟨1,40⟩,⟨831,999999999999999999⟩]
private def b19333 : Box := ![⟨47,94⟩,⟨12,14⟩,⟨15,30⟩,⟨1,46⟩,⟨207,999999999999999999⟩]
private def b19334 : Box := ![⟨47,62⟩,⟨12,14⟩,⟨15,30⟩,⟨1,46⟩,⟨207,999999999999999999⟩]
private def b19335 : Box := ![⟨47,62⟩,⟨12,14⟩,⟨15,30⟩,⟨1,40⟩,⟨207,414⟩]
private def b19336 : Box := ![⟨47,62⟩,⟨12,14⟩,⟨15,20⟩,⟨1,33⟩,⟨207,414⟩]
private def b19341 : Box := ![⟨47,62⟩,⟨12,14⟩,⟨21,30⟩,⟨1,33⟩,⟨207,414⟩]
private def b19352 : Box := ![⟨47,62⟩,⟨12,14⟩,⟨15,30⟩,⟨1,40⟩,⟨415,999999999999999999⟩]
private def b19353 : Box := ![⟨47,62⟩,⟨12,14⟩,⟨15,20⟩,⟨1,35⟩,⟨415,999999999999999999⟩]
private def b19358 : Box := ![⟨47,62⟩,⟨12,14⟩,⟨21,30⟩,⟨1,35⟩,⟨415,999999999999999999⟩]
private def b19369 : Box := ![⟨63,94⟩,⟨12,14⟩,⟨15,30⟩,⟨1,46⟩,⟨207,999999999999999999⟩]
private def b19370 : Box := ![⟨63,94⟩,⟨12,14⟩,⟨15,30⟩,⟨1,46⟩,⟨207,414⟩]
private def b19379 : Box := ![⟨63,94⟩,⟨12,14⟩,⟨15,30⟩,⟨1,46⟩,⟨415,999999999999999999⟩]
private def b19380 : Box := ![⟨63,94⟩,⟨12,14⟩,⟨15,20⟩,⟨1,41⟩,⟨415,999999999999999999⟩]
private def b19393 : Box := ![⟨63,94⟩,⟨12,14⟩,⟨21,30⟩,⟨1,41⟩,⟨415,999999999999999999⟩]
private def b19400 : Box := ![⟨47,94⟩,⟨10,14⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029553⟩,⟨207,999999999999999999⟩]
private def b19401 : Box := ![⟨47,94⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029553⟩,⟨207,999999999999999999⟩]
private def b19402 : Box := ![⟨47,62⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029552⟩,⟨207,999999999999999999⟩]
private def b19403 : Box := ![⟨47,62⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029546⟩,⟨207,414⟩]
private def b19404 : Box := ![⟨47,62⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨1,2⟩,⟨207,414⟩]
private def b19405 : Box := ![⟨47,62⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨3,864390243902439029539⟩,⟨207,414⟩]
private def b19406 : Box := ![⟨47,62⟩,⟨10,11⟩,⟨31,62⟩,⟨3,864390243902439029539⟩,⟨207,414⟩]
private def b19407 : Box := ![⟨47,53⟩,⟨10,11⟩,⟨31,62⟩,⟨3,47⟩,⟨207,414⟩]
private def b19408 : Box := ![⟨47,53⟩,⟨10,11⟩,⟨31,62⟩,⟨3,45⟩,⟨207,276⟩]
private def b19419 : Box := ![⟨47,53⟩,⟨10,11⟩,⟨31,62⟩,⟨3,45⟩,⟨277,414⟩]
private def b19428 : Box := ![⟨54,62⟩,⟨10,11⟩,⟨31,62⟩,⟨3,47⟩,⟨207,414⟩]
private def b19429 : Box := ![⟨54,62⟩,⟨10,11⟩,⟨31,62⟩,⟨3,47⟩,⟨207,276⟩]
private def b19436 : Box := ![⟨54,62⟩,⟨10,11⟩,⟨31,62⟩,⟨3,47⟩,⟨277,414⟩]
private def b19447 : Box := ![⟨47,62⟩,⟨10,11⟩,⟨63,1920000000000000011376⟩,⟨3,864390243902439029539⟩,⟨207,414⟩]
private def b19452 : Box := ![⟨47,62⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029546⟩,⟨415,999999999999999999⟩]
private def b19453 : Box := ![⟨47,62⟩,⟨10,11⟩,⟨31,62⟩,⟨1,764204851752021567900⟩,⟨415,999999999999999999⟩]
private def b19454 : Box := ![⟨47,53⟩,⟨10,11⟩,⟨31,62⟩,⟨1,47⟩,⟨415,999999999999999999⟩]
private def b19463 : Box := ![⟨54,62⟩,⟨10,11⟩,⟨31,62⟩,⟨1,47⟩,⟨415,999999999999999999⟩]
private def b19464 : Box := ![⟨54,62⟩,⟨10,11⟩,⟨31,62⟩,⟨1,47⟩,⟨415,830⟩]
private def b19477 : Box := ![⟨54,62⟩,⟨10,11⟩,⟨31,62⟩,⟨1,47⟩,⟨831,999999999999999999⟩]
private def b19486 : Box := ![⟨47,62⟩,⟨10,11⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567900⟩,⟨415,999999999999999999⟩]
private def b19487 : Box := ![⟨47,53⟩,⟨10,11⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567900⟩,⟨415,999999999999999999⟩]
private def b19488 : Box := ![⟨47,53⟩,⟨10,11⟩,⟨63,1920000000000000011376⟩,⟨1,2⟩,⟨415,999999999999999999⟩]
private def b19489 : Box := ![⟨47,53⟩,⟨10,11⟩,⟨63,1920000000000000011376⟩,⟨3,764204851752021567898⟩,⟨415,999999999999999999⟩]
private def b19490 : Box := ![⟨47,53⟩,⟨10,11⟩,⟨63,1920000000000000011376⟩,⟨3,6⟩,⟨415,999999999999999999⟩]
private def b19491 : Box := ![⟨47,53⟩,⟨10,11⟩,⟨63,1920000000000000011376⟩,⟨7,764204851752021567898⟩,⟨415,999999999999999999⟩]
private def b19492 : Box := ![⟨47,53⟩,⟨10,11⟩,⟨63,1920000000000000011376⟩,⟨7,764204851752021567898⟩,⟨415,830⟩]
private def b19495 : Box := ![⟨47,53⟩,⟨10,11⟩,⟨63,1920000000000000011376⟩,⟨7,764204851752021567898⟩,⟨831,999999999999999999⟩]
private def b19496 : Box := ![⟨47,53⟩,⟨10,10⟩,⟨63,1920000000000000011376⟩,⟨7,685382755842062856624⟩,⟨831,999999999999999999⟩]
private def b19497 : Box := ![⟨47,53⟩,⟨11,11⟩,⟨63,1920000000000000011376⟩,⟨7,685382755842062856624⟩,⟨831,999999999999999999⟩]
private def b19498 : Box := ![⟨47,53⟩,⟨11,11⟩,⟨63,126⟩,⟨7,685382755842062856624⟩,⟨831,999999999999999999⟩]
private def b19501 : Box := ![⟨47,53⟩,⟨11,11⟩,⟨127,1920000000000000011376⟩,⟨7,685382755842062856624⟩,⟨831,999999999999999999⟩]
private def b19502 : Box := ![⟨47,53⟩,⟨11,11⟩,⟨127,1920000000000000011376⟩,⟨7,685382755842062856624⟩,⟨831,1662⟩]
private def b19503 : Box := ![⟨47,53⟩,⟨11,11⟩,⟨127,1920000000000000011376⟩,⟨7,685382755842062856624⟩,⟨1663,999999999999999999⟩]
private def b19504 : Box := ![⟨47,53⟩,⟨11,11⟩,⟨127,1920000000000000011376⟩,⟨7,621300219138056979599⟩,⟨1663,3326⟩]
private def b19505 : Box := ![⟨47,53⟩,⟨11,11⟩,⟨127,1920000000000000011376⟩,⟨7,621300219138056979599⟩,⟨3327,999999999999999999⟩]
private def b19506 : Box := ![⟨47,49⟩,⟨11,11⟩,⟨127,1920000000000000011376⟩,⟨7,568176352705410825031⟩,⟨3327,999999999999999999⟩]
private def b19507 : Box := ![⟨50,53⟩,⟨11,11⟩,⟨127,1920000000000000011376⟩,⟨7,568176352705410825031⟩,⟨3327,999999999999999999⟩]
private def b19508 : Box := ![⟨50,53⟩,⟨11,11⟩,⟨127,1920000000000000011376⟩,⟨7,568176352705410825031⟩,⟨3327,6654⟩]
private def b19509 : Box := ![⟨50,53⟩,⟨11,11⟩,⟨127,1920000000000000011376⟩,⟨7,568176352705410825031⟩,⟨6655,999999999999999999⟩]
private def b19510 : Box := ![⟨50,53⟩,⟨11,11⟩,⟨160,1920000000000000011376⟩,⟨7,523421538461538464659⟩,⟨6655,13310⟩]
private def b19511 : Box := ![⟨50,53⟩,⟨11,11⟩,⟨160,1920000000000000011376⟩,⟨7,523421538461538464659⟩,⟨13311,999999999999999999⟩]
private def b19512 : Box := ![⟨50,53⟩,⟨11,11⟩,⟨184,1920000000000000011376⟩,⟨7,485202509982886483212⟩,⟨13311,26622⟩]
private def b19513 : Box := ![⟨50,53⟩,⟨11,11⟩,⟨184,1920000000000000011376⟩,⟨7,485202509982886483212⟩,⟨26623,999999999999999999⟩]
private def b19528 : Box := ![⟨54,62⟩,⟨10,11⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567900⟩,⟨415,999999999999999999⟩]
private def b19529 : Box := ![⟨54,62⟩,⟨10,11⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567900⟩,⟨415,830⟩]
private def b19536 : Box := ![⟨54,62⟩,⟨10,11⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567900⟩,⟨831,999999999999999999⟩]
private def b19537 : Box := ![⟨54,62⟩,⟨10,10⟩,⟨63,1920000000000000011376⟩,⟨1,685382755842062856626⟩,⟨831,999999999999999999⟩]
private def b19540 : Box := ![⟨54,62⟩,⟨11,11⟩,⟨63,1920000000000000011376⟩,⟨1,685382755842062856626⟩,⟨831,999999999999999999⟩]
private def b19541 : Box := ![⟨54,62⟩,⟨11,11⟩,⟨63,126⟩,⟨1,685382755842062856626⟩,⟨831,999999999999999999⟩]
private def b19542 : Box := ![⟨54,62⟩,⟨11,11⟩,⟨63,126⟩,⟨2,65⟩,⟨831,1662⟩]
private def b19543 : Box := ![⟨54,62⟩,⟨11,11⟩,⟨63,126⟩,⟨2,65⟩,⟨1663,999999999999999999⟩]
private def b19544 : Box := ![⟨54,62⟩,⟨11,11⟩,⟨63,126⟩,⟨2,59⟩,⟨1663,3326⟩]
private def b19545 : Box := ![⟨54,62⟩,⟨11,11⟩,⟨63,126⟩,⟨2,59⟩,⟨3327,999999999999999999⟩]
private def b19546 : Box := ![⟨54,62⟩,⟨11,11⟩,⟨63,126⟩,⟨2,54⟩,⟨3327,6654⟩]
private def b19547 : Box := ![⟨54,62⟩,⟨11,11⟩,⟨63,126⟩,⟨2,54⟩,⟨6655,999999999999999999⟩]
private def b19562 : Box := ![⟨54,62⟩,⟨11,11⟩,⟨127,1920000000000000011376⟩,⟨1,685382755842062856626⟩,⟨831,999999999999999999⟩]
private def b19571 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029552⟩,⟨207,999999999999999999⟩]
private def b19572 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029552⟩,⟨207,414⟩]
private def b19573 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨31,62⟩,⟨1,864390243902439029546⟩,⟨207,414⟩]
private def b19574 : Box := ![⟨63,75⟩,⟨10,11⟩,⟨31,62⟩,⟨1,53⟩,⟨207,414⟩]
private def b19575 : Box := ![⟨63,75⟩,⟨10,11⟩,⟨31,62⟩,⟨1,2⟩,⟨207,414⟩]
private def b19576 : Box := ![⟨63,75⟩,⟨10,11⟩,⟨31,62⟩,⟨3,49⟩,⟨207,414⟩]
private def b19577 : Box := ![⟨63,75⟩,⟨10,10⟩,⟨31,62⟩,⟨3,49⟩,⟨235,414⟩]
private def b19592 : Box := ![⟨63,75⟩,⟨11,11⟩,⟨31,62⟩,⟨3,49⟩,⟨235,414⟩]
private def b19593 : Box := ![⟨76,94⟩,⟨10,11⟩,⟨31,62⟩,⟨1,53⟩,⟨207,414⟩]
private def b19594 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨63,1920000000000000011376⟩,⟨1,864390243902439029546⟩,⟨207,414⟩]
private def b19595 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029552⟩,⟨415,999999999999999999⟩]
private def b19596 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨31,62⟩,⟨1,764204851752021567906⟩,⟨415,999999999999999999⟩]
private def b19597 : Box := ![⟨63,75⟩,⟨10,11⟩,⟨31,62⟩,⟨1,53⟩,⟨415,999999999999999999⟩]
private def b19598 : Box := ![⟨63,75⟩,⟨10,11⟩,⟨31,62⟩,⟨1,49⟩,⟨415,830⟩]
private def b19613 : Box := ![⟨63,75⟩,⟨10,11⟩,⟨31,62⟩,⟨1,49⟩,⟨831,999999999999999999⟩]
private def b19628 : Box := ![⟨76,94⟩,⟨10,11⟩,⟨31,62⟩,⟨1,53⟩,⟨415,999999999999999999⟩]
private def b19629 : Box := ![⟨76,94⟩,⟨10,10⟩,⟨31,62⟩,⟨1,53⟩,⟨415,999999999999999999⟩]
private def b19630 : Box := ![⟨76,94⟩,⟨10,10⟩,⟨31,62⟩,⟨1,53⟩,⟨415,830⟩]
private def b19637 : Box := ![⟨76,94⟩,⟨10,10⟩,⟨31,62⟩,⟨1,53⟩,⟨831,999999999999999999⟩]
private def b19652 : Box := ![⟨76,94⟩,⟨11,11⟩,⟨31,62⟩,⟨1,53⟩,⟨415,999999999999999999⟩]
private def b19653 : Box := ![⟨63,94⟩,⟨10,11⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567906⟩,⟨415,999999999999999999⟩]
private def b19654 : Box := ![⟨63,94⟩,⟨10,10⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567906⟩,⟨415,999999999999999999⟩]
private def b19655 : Box := ![⟨63,75⟩,⟨10,10⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567906⟩,⟨415,999999999999999999⟩]
private def b19656 : Box := ![⟨63,75⟩,⟨10,10⟩,⟨63,1920000000000000011376⟩,⟨1,2⟩,⟨415,999999999999999999⟩]
private def b19657 : Box := ![⟨63,75⟩,⟨10,10⟩,⟨63,1920000000000000011376⟩,⟨3,764204851752021567902⟩,⟨415,999999999999999999⟩]
private def b19658 : Box := ![⟨63,75⟩,⟨10,10⟩,⟨63,1920000000000000011376⟩,⟨3,764204851752021567902⟩,⟨462,924⟩]
private def b19665 : Box := ![⟨63,75⟩,⟨10,10⟩,⟨63,1920000000000000011376⟩,⟨3,764204851752021567902⟩,⟨925,999999999999999999⟩]
private def b19666 : Box := ![⟨63,75⟩,⟨10,10⟩,⟨63,126⟩,⟨3,674512291831879464770⟩,⟨925,999999999999999999⟩]
private def b19667 : Box := ![⟨63,68⟩,⟨10,10⟩,⟨63,126⟩,⟨3,66⟩,⟨925,999999999999999999⟩]
private def b19670 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨63,126⟩,⟨3,66⟩,⟨925,999999999999999999⟩]
private def b19671 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨63,126⟩,⟨3,66⟩,⟨925,1850⟩]
private def b19676 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨63,126⟩,⟨3,66⟩,⟨1851,999999999999999999⟩]
private def b19677 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨63,84⟩,⟨3,60⟩,⟨1851,999999999999999999⟩]
private def b19680 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,60⟩,⟨1851,999999999999999999⟩]
private def b19681 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,60⟩,⟨1851,3702⟩]
private def b19682 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,60⟩,⟨3703,999999999999999999⟩]
private def b19683 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,55⟩,⟨3703,7406⟩]
private def b19684 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,55⟩,⟨7407,999999999999999999⟩]
private def b19685 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,50⟩,⟨7407,14814⟩]
private def b19686 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,50⟩,⟨14815,999999999999999999⟩]
private def b19687 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,47⟩,⟨14815,29630⟩]
private def b19688 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,47⟩,⟨29631,999999999999999999⟩]
private def b19689 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,44⟩,⟨29631,59262⟩]
private def b19690 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,44⟩,⟨59263,999999999999999999⟩]
private def b19691 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,41⟩,⟨59263,118526⟩]
private def b19692 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,41⟩,⟨118527,999999999999999999⟩]
private def b19693 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,38⟩,⟨118527,237054⟩]
private def b19694 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,38⟩,⟨237055,999999999999999999⟩]
private def b19695 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,36⟩,⟨237055,474110⟩]
private def b19696 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,36⟩,⟨474111,999999999999999999⟩]
private def b19697 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,34⟩,⟨474111,948222⟩]
private def b19698 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,34⟩,⟨948223,999999999999999999⟩]
private def b19699 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,32⟩,⟨948223,1896446⟩]
private def b19700 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,32⟩,⟨1896447,999999999999999999⟩]
private def b19701 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,31⟩,⟨1896447,3792894⟩]
private def b19702 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,31⟩,⟨3792895,999999999999999999⟩]
private def b19703 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,29⟩,⟨3792895,7585790⟩]
private def b19704 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,29⟩,⟨7585791,999999999999999999⟩]
private def b19705 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,28⟩,⟨7585791,15171582⟩]
private def b19706 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨85,126⟩,⟨3,28⟩,⟨15171583,999999999999999999⟩]
private def b19721 : Box := ![⟨63,75⟩,⟨10,10⟩,⟨127,1920000000000000011376⟩,⟨3,674512291831879464770⟩,⟨925,999999999999999999⟩]
private def b19722 : Box := ![⟨63,68⟩,⟨10,10⟩,⟨127,1920000000000000011376⟩,⟨4,674512291831879464770⟩,⟨950,999999999999999999⟩]
private def b19723 : Box := ![⟨63,68⟩,⟨10,10⟩,⟨127,1920000000000000011376⟩,⟨4,8⟩,⟨950,999999999999999999⟩]
private def b19724 : Box := ![⟨63,68⟩,⟨10,10⟩,⟨127,1920000000000000011376⟩,⟨9,671848341232227492159⟩,⟨950,999999999999999999⟩]
private def b19725 : Box := ![⟨63,68⟩,⟨10,10⟩,⟨127,1920000000000000011376⟩,⟨9,671848341232227492159⟩,⟨1068,2136⟩]
private def b19728 : Box := ![⟨63,68⟩,⟨10,10⟩,⟨127,1920000000000000011376⟩,⟨9,671848341232227492159⟩,⟨2137,999999999999999999⟩]
private def b19729 : Box := ![⟨63,68⟩,⟨10,10⟩,⟨127,254⟩,⟨9,601102473498233219133⟩,⟨2137,999999999999999999⟩]
private def b19744 : Box := ![⟨63,68⟩,⟨10,10⟩,⟨255,1920000000000000011376⟩,⟨9,601102473498233219133⟩,⟨2137,999999999999999999⟩]
private def b19745 : Box := ![⟨63,68⟩,⟨10,10⟩,⟨255,1920000000000000011376⟩,⟨12,601102473498233219133⟩,⟨2137,4274⟩]
private def b19746 : Box := ![⟨63,68⟩,⟨10,10⟩,⟨255,1920000000000000011376⟩,⟨12,601102473498233219133⟩,⟨4275,999999999999999999⟩]
private def b19747 : Box := ![⟨63,68⟩,⟨10,10⟩,⟨255,1920000000000000011376⟩,⟨12,551237848347375246321⟩,⟨4275,8550⟩]
private def b19748 : Box := ![⟨63,68⟩,⟨10,10⟩,⟨255,1920000000000000011376⟩,⟨12,551237848347375246321⟩,⟨8551,999999999999999999⟩]
private def b19749 : Box := ![⟨63,68⟩,⟨10,10⟩,⟨255,1920000000000000011376⟩,⟨12,509012567324955119733⟩,⟨8551,17102⟩]
private def b19750 : Box := ![⟨63,68⟩,⟨10,10⟩,⟨255,1920000000000000011376⟩,⟨12,509012567324955119733⟩,⟨17103,999999999999999999⟩]
private def b19751 : Box := ![⟨63,68⟩,⟨10,10⟩,⟨255,1920000000000000011376⟩,⟨12,472795997776542526444⟩,⟨17103,34206⟩]
private def b19752 : Box := ![⟨63,68⟩,⟨10,10⟩,⟨255,1920000000000000011376⟩,⟨12,472795997776542526444⟩,⟨34207,999999999999999999⟩]
private def b19767 : Box := ![⟨69,75⟩,⟨10,10⟩,⟨127,1920000000000000011376⟩,⟨4,674512291831879464770⟩,⟨950,999999999999999999⟩]
private def b19776 : Box := ![⟨76,94⟩,⟨10,10⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567906⟩,⟨415,999999999999999999⟩]
private def b19785 : Box := ![⟨63,94⟩,⟨11,11⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567906⟩,⟨415,999999999999999999⟩]
private def b19786 : Box := ![⟨47,94⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029553⟩,⟨207,999999999999999999⟩]
private def b19787 : Box := ![⟨47,62⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029553⟩,⟨223,999999999999999999⟩]
private def b19788 : Box := ![⟨47,62⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨1,852264529058116237549⟩,⟨223,446⟩]
private def b19797 : Box := ![⟨47,62⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨1,852264529058116237549⟩,⟨447,999999999999999999⟩]
private def b19798 : Box := ![⟨47,62⟩,⟨12,14⟩,⟨31,62⟩,⟨1,755381882770870341984⟩,⟨447,999999999999999999⟩]
private def b19799 : Box := ![⟨47,62⟩,⟨12,12⟩,⟨31,62⟩,⟨1,47⟩,⟨447,999999999999999999⟩]
private def b19810 : Box := ![⟨47,62⟩,⟨13,14⟩,⟨31,62⟩,⟨1,47⟩,⟨447,999999999999999999⟩]
private def b19819 : Box := ![⟨47,62⟩,⟨12,14⟩,⟨63,1920000000000000011376⟩,⟨1,755381882770870341984⟩,⟨447,999999999999999999⟩]
private def b19834 : Box := ![⟨63,94⟩,⟨12,14⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029553⟩,⟨223,999999999999999999⟩]
theorem deny5_11 : Deny 5 11 ![⟨47,94⟩,⟨10,14⟩,⟨15,1920000000000000011376⟩,⟨1,1450666666666666675297⟩,⟨103,999999999999999999⟩] := by
  have e19135 : Deny 5 11 b19135 := by
    apply closeAction rule_sound _ _ 64 [0x578dc40832041f8dc3e370e3223255543249284]
    decide +kernel
  have e19151 : Deny 5 11 b19151 := by
    apply closeAction rule_sound _ _ 64 [0x150c2209]
    decide +kernel
  have e19156 : Deny 5 11 b19156 := by
    apply closeAction rule_sound _ _ 64 [0x578dc38c80f80e32231c30f88c88c9]
    decide +kernel
  have e19150 : Deny 5 11 b19150 :=
    branchAction rule_sound _ _ 3
      0xa8c4 b19150 b19151 b19156 (by decide +kernel) e19151 e19156
  have e19134 : Deny 5 11 b19134 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19134 b19135 b19150 (by decide +kernel) e19135 e19150
  have e19168 : Deny 5 11 b19168 := by
    apply closeAction rule_sound _ _ 64 [0x15543809809]
    decide +kernel
  have e19174 : Deny 5 11 b19174 := by
    apply closeAction rule_sound _ _ 64 [0x820832072778c4]
    decide +kernel
  have e19182 : Deny 5 11 b19182 := by
    apply closeAction rule_sound _ _ 64 [0x83e370e32480f8dc32231e3]
    decide +kernel
  have e19191 : Deny 5 11 b19191 := by
    apply closeAction rule_sound _ _ 64 [0x2095e370c9207e37]
    decide +kernel
  have e19181 : Deny 5 11 b19181 :=
    branchAction rule_sound _ _ 3
      0x98c4 b19181 b19182 b19191 (by decide +kernel) e19182 e19191
  have e19173 : Deny 5 11 b19173 :=
    branchAction rule_sound _ _ 2
      0x2f8 b19173 b19174 b19181 (by decide +kernel) e19174 e19181
  have e19167 : Deny 5 11 b19167 :=
    branchAction rule_sound _ _ 1
      0xa b19167 b19168 b19173 (by decide +kernel) e19168 e19173
  have e19133 : Deny 5 11 b19133 :=
    branchAction rule_sound _ _ 2
      0x1e3 b19133 b19134 b19167 (by decide +kernel) e19134 e19167
  have e19198 : Deny 5 11 b19198 := by
    apply closeAction rule_sound _ _ 64 [0x578dc20e0108e37578dc40c4278dc38c88c78c9]
    decide +kernel
  have e19132 : Deny 5 11 b19132 :=
    branchAction rule_sound _ _ 2
      0x223 b19132 b19133 b19198 (by decide +kernel) e19133 e19198
  have e19211 : Deny 5 11 b19211 := by
    apply closeAction rule_sound _ _ 64 [0x562]
    decide +kernel
  have e19215 : Deny 5 11 b19215 := by
    apply closeAction rule_sound _ _ 64 [0x83109e370f8dc3bc70e32631e3102578dc32621f710b]
    decide +kernel
  have e19230 : Deny 5 11 b19230 := by
    apply closeAction rule_sound _ _ 64 [0x15e37]
    decide +kernel
  have e19214 : Deny 5 11 b19214 :=
    branchAction rule_sound _ _ 2
      0x223 b19214 b19215 b19230 (by decide +kernel) e19215 e19230
  have e19231 : Deny 5 11 b19231 := by
    apply closeAction rule_sound _ _ 64 [0x14e37]
    decide +kernel
  have e19213 : Deny 5 11 b19213 :=
    branchAction rule_sound _ _ 3
      0x98c4 b19213 b19214 b19231 (by decide +kernel) e19214 e19231
  have e19232 : Deny 5 11 b19232 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e19212 : Deny 5 11 b19212 :=
    branchAction rule_sound _ _ 2
      0x1f8 b19212 b19213 b19232 (by decide +kernel) e19213 e19232
  have e19210 : Deny 5 11 b19210 :=
    branchAction rule_sound _ _ 2
      0x2a3 b19210 b19211 b19212 (by decide +kernel) e19211 e19212
  have e19233 : Deny 5 11 b19233 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e19209 : Deny 5 11 b19209 :=
    branchAction rule_sound _ _ 1
      0x8 b19209 b19210 b19233 (by decide +kernel) e19210 e19233
  have e19131 : Deny 5 11 b19131 :=
    branchAction rule_sound _ _ 3
      0x98c4 b19131 b19132 b19209 (by decide +kernel) e19132 e19209
  have e19238 : Deny 5 11 b19238 := by
    apply closeAction rule_sound _ _ 64 [0x30f82030888c754a0c22378c98c4]
    decide +kernel
  have e19251 : Deny 5 11 b19251 := by
    apply closeAction rule_sound _ _ 64 [0xf80f8de324221de37da31f8da3]
    decide +kernel
  have e19237 : Deny 5 11 b19237 :=
    branchAction rule_sound _ _ 3
      0xbe23 b19237 b19238 b19251 (by decide +kernel) e19238 e19251
  have e19261 : Deny 5 11 b19261 := by
    apply closeAction rule_sound _ _ 64 [0xc3e37223]
    decide +kernel
  have e19265 : Deny 5 11 b19265 := by
    apply closeAction rule_sound _ _ 64 [0x5679a0]
    decide +kernel
  have e19266 : Deny 5 11 b19266 := by
    apply closeAction rule_sound _ _ 64 [0xf8dc38c90c3e378c9223083804278dc30e324810b]
    decide +kernel
  have e19264 : Deny 5 11 b19264 :=
    branchAction rule_sound _ _ 1
      0xa b19264 b19265 b19266 (by decide +kernel) e19265 e19266
  have e19260 : Deny 5 11 b19260 :=
    branchAction rule_sound _ _ 2
      0x1e3 b19260 b19261 b19264 (by decide +kernel) e19261 e19264
  have e19282 : Deny 5 11 b19282 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
  have e19284 : Deny 5 11 b19284 := by
    apply closeAction rule_sound _ _ 64 [0x15e370e32780c3e378c92230830e32632042e3]
    decide +kernel
  have e19297 : Deny 5 11 b19297 := by
    apply closeAction rule_sound _ _ 64 [0x20f80e31e3238]
    decide +kernel
  have e19283 : Deny 5 11 b19283 :=
    branchAction rule_sound _ _ 1
      0x7 b19283 b19284 b19297 (by decide +kernel) e19284 e19297
  have e19281 : Deny 5 11 b19281 :=
    branchAction rule_sound _ _ 1
      0xa b19281 b19282 b19283 (by decide +kernel) e19282 e19283
  have e19259 : Deny 5 11 b19259 :=
    branchAction rule_sound _ _ 2
      0x263 b19259 b19260 b19281 (by decide +kernel) e19260 e19281
  have e19303 : Deny 5 11 b19303 := by
    apply closeAction rule_sound _ _ 64 [0xf80f88c9e230f8df68c8e23]
    decide +kernel
  have e19309 : Deny 5 11 b19309 := by
    apply closeAction rule_sound _ _ 64 [0x3e03e232780f8df62388d5e0ae23]
    decide +kernel
  have e19317 : Deny 5 11 b19317 := by
    apply closeAction rule_sound _ _ 64 [0x838c9e030f88c72152a3]
    decide +kernel
  have e19326 : Deny 5 11 b19326 := by
    apply closeAction rule_sound _ _ 64 [0xc38c70f88c21f8df6223]
    decide +kernel
  have e19316 : Deny 5 11 b19316 :=
    branchAction rule_sound _ _ 1
      0xb b19316 b19317 b19326 (by decide +kernel) e19317 e19326
  have e19308 : Deny 5 11 b19308 :=
    branchAction rule_sound _ _ 1
      0x7 b19308 b19309 b19316 (by decide +kernel) e19309 e19316
  have e19302 : Deny 5 11 b19302 :=
    branchAction rule_sound _ _ 2
      0x263 b19302 b19303 b19308 (by decide +kernel) e19303 e19308
  have e19258 : Deny 5 11 b19258 :=
    branchAction rule_sound _ _ 1
      0xb b19258 b19259 b19302 (by decide +kernel) e19259 e19302
  have e19236 : Deny 5 11 b19236 :=
    branchAction rule_sound _ _ 2
      0x1e3 b19236 b19237 b19258 (by decide +kernel) e19237 e19258
  have e19336 : Deny 5 11 b19336 := by
    apply closeAction rule_sound _ _ 64 [0xc38c90e3223]
    decide +kernel
  have e19341 : Deny 5 11 b19341 := by
    apply closeAction rule_sound _ _ 64 [0x820f8277107e370f8dc38c78c854a]
    decide +kernel
  have e19335 : Deny 5 11 b19335 :=
    branchAction rule_sound _ _ 2
      0x263 b19335 b19336 b19341 (by decide +kernel) e19336 e19341
  have e19353 : Deny 5 11 b19353 := by
    apply closeAction rule_sound _ _ 64 [0xc38c90f8de3223]
    decide +kernel
  have e19358 : Deny 5 11 b19358 := by
    apply closeAction rule_sound _ _ 64 [0x83e232380c38c98c70c3e231c8]
    decide +kernel
  have e19352 : Deny 5 11 b19352 :=
    branchAction rule_sound _ _ 2
      0x263 b19352 b19353 b19358 (by decide +kernel) e19353 e19358
  have e19334 : Deny 5 11 b19334 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19334 b19335 b19352 (by decide +kernel) e19335 e19352
  have e19370 : Deny 5 11 b19370 := by
    apply closeAction rule_sound _ _ 64 [0x2083e20109e370f8dc38c9223263]
    decide +kernel
  have e19380 : Deny 5 11 b19380 := by
    apply closeAction rule_sound _ _ 64 [0x820f88c7e232780f80e32631c30e3263223]
    decide +kernel
  have e19393 : Deny 5 11 b19393 := by
    apply closeAction rule_sound _ _ 64 [0x2083e03e232788c7e23238]
    decide +kernel
  have e19379 : Deny 5 11 b19379 :=
    branchAction rule_sound _ _ 2
      0x263 b19379 b19380 b19393 (by decide +kernel) e19380 e19393
  have e19369 : Deny 5 11 b19369 :=
    branchAction rule_sound _ _ 1
      0xb b19369 b19370 b19379 (by decide +kernel) e19370 e19379
  have e19333 : Deny 5 11 b19333 :=
    branchAction rule_sound _ _ 1
      0x7 b19333 b19334 b19369 (by decide +kernel) e19334 e19369
  have e19235 : Deny 5 11 b19235 :=
    branchAction rule_sound _ _ 2
      0x223 b19235 b19236 b19333 (by decide +kernel) e19236 e19333
  have e19404 : Deny 5 11 b19404 := by
    apply closeAction rule_sound _ _ 64 [0x562]
    decide +kernel
  have e19408 : Deny 5 11 b19408 := by
    apply closeAction rule_sound _ _ 64 [0x20f8be2107e370e32430f8def8c70f8de3263204]
    decide +kernel
  have e19419 : Deny 5 11 b19419 := by
    apply closeAction rule_sound _ _ 64 [0x3e031c38c90f61021f8df6223]
    decide +kernel
  have e19407 : Deny 5 11 b19407 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19407 b19408 b19419 (by decide +kernel) e19408 e19419
  have e19429 : Deny 5 11 b19429 := by
    apply closeAction rule_sound _ _ 64 [0x2578dc38c70e32488c4]
    decide +kernel
  have e19436 : Deny 5 11 b19436 := by
    apply closeAction rule_sound _ _ 64 [0x838c42780f8bc38c90f88c70f88c9223]
    decide +kernel
  have e19428 : Deny 5 11 b19428 :=
    branchAction rule_sound _ _ 1
      0xb b19428 b19429 b19436 (by decide +kernel) e19429 e19436
  have e19406 : Deny 5 11 b19406 :=
    branchAction rule_sound _ _ 2
      0x1e3 b19406 b19407 b19428 (by decide +kernel) e19407 e19428
  have e19447 : Deny 5 11 b19447 := by
    apply closeAction rule_sound _ _ 64 [0x2707e2f76f8c9]
    decide +kernel
  have e19405 : Deny 5 11 b19405 :=
    branchAction rule_sound _ _ 1
      0x9 b19405 b19406 b19447 (by decide +kernel) e19406 e19447
  have e19403 : Deny 5 11 b19403 :=
    branchAction rule_sound _ _ 2
      0x2a3 b19403 b19404 b19405 (by decide +kernel) e19404 e19405
  have e19454 : Deny 5 11 b19454 := by
    apply closeAction rule_sound _ _ 64 [0x30f8df68c70f8de32552b88c2238da3]
    decide +kernel
  have e19464 : Deny 5 11 b19464 := by
    apply closeAction rule_sound _ _ 64 [0x20c9e370e31f80e325d0f8df688ae362152a3]
    decide +kernel
  have e19477 : Deny 5 11 b19477 := by
    apply closeAction rule_sound _ _ 64 [0x30f88c90f88c70f8de3242223]
    decide +kernel
  have e19463 : Deny 5 11 b19463 :=
    branchAction rule_sound _ _ 1
      0xb b19463 b19464 b19477 (by decide +kernel) e19464 e19477
  have e19453 : Deny 5 11 b19453 :=
    branchAction rule_sound _ _ 2
      0x1e3 b19453 b19454 b19463 (by decide +kernel) e19454 e19463
  have e19488 : Deny 5 11 b19488 := by
    apply closeAction rule_sound _ _ 64 [0x538be2]
    decide +kernel
  have e19490 : Deny 5 11 b19490 := by
    apply closeAction rule_sound _ _ 64 [0x14e22]
    decide +kernel
  have e19492 : Deny 5 11 b19492 := by
    apply closeAction rule_sound _ _ 64 [0x1cbddbe3263]
    decide +kernel
  have e19496 : Deny 5 11 b19496 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e19498 : Deny 5 11 b19498 := by
    apply closeAction rule_sound _ _ 64 [0x75de37daf8c7e23]
    decide +kernel
  have e19502 : Deny 5 11 b19502 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e19504 : Deny 5 11 b19504 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e19506 : Deny 5 11 b19506 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e19508 : Deny 5 11 b19508 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e19510 : Deny 5 11 b19510 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e19512 : Deny 5 11 b19512 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e19513 : Deny 5 11 b19513 := by
    apply closeAction rule_sound _ _ 64 [0x9cbc30878c9be324272f8c9daf087d87daf8dcbe32f6be3]
    decide +kernel
  have e19511 : Deny 5 11 b19511 :=
    branchAction rule_sound _ _ 3
      0xbda3 b19511 b19512 b19513 (by decide +kernel) e19512 e19513
  have e19509 : Deny 5 11 b19509 :=
    branchAction rule_sound _ _ 3
      0xbda3 b19509 b19510 b19511 (by decide +kernel) e19510 e19511
  have e19507 : Deny 5 11 b19507 :=
    branchAction rule_sound _ _ 1
      0xb b19507 b19508 b19509 (by decide +kernel) e19508 e19509
  have e19505 : Deny 5 11 b19505 :=
    branchAction rule_sound _ _ 2
      0x1e3 b19505 b19506 b19507 (by decide +kernel) e19506 e19507
  have e19503 : Deny 5 11 b19503 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19503 b19504 b19505 (by decide +kernel) e19504 e19505
  have e19501 : Deny 5 11 b19501 :=
    branchAction rule_sound _ _ 1
      0xb b19501 b19502 b19503 (by decide +kernel) e19502 e19503
  have e19497 : Deny 5 11 b19497 :=
    branchAction rule_sound _ _ 1
      0x9 b19497 b19498 b19501 (by decide +kernel) e19498 e19501
  have e19495 : Deny 5 11 b19495 :=
    branchAction rule_sound _ _ 2
      0x223 b19495 b19496 b19497 (by decide +kernel) e19496 e19497
  have e19491 : Deny 5 11 b19491 :=
    branchAction rule_sound _ _ 1
      0xb b19491 b19492 b19495 (by decide +kernel) e19492 e19495
  have e19489 : Deny 5 11 b19489 :=
    branchAction rule_sound _ _ 1
      0xa b19489 b19490 b19491 (by decide +kernel) e19490 e19491
  have e19487 : Deny 5 11 b19487 :=
    branchAction rule_sound _ _ 2
      0x2a3 b19487 b19488 b19489 (by decide +kernel) e19488 e19489
  have e19529 : Deny 5 11 b19529 := by
    apply closeAction rule_sound _ _ 64 [0x14e377388dc1f8bddbe3248be3]
    decide +kernel
  have e19537 : Deny 5 11 b19537 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe376f8c9e36]
    decide +kernel
  have e19542 : Deny 5 11 b19542 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e19544 : Deny 5 11 b19544 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e19546 : Deny 5 11 b19546 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e19547 : Deny 5 11 b19547 := by
    apply closeAction rule_sound _ _ 64 [0x830f68c78c90ef087d878ddbe32e376f8cb8ddbe32e3]
    decide +kernel
  have e19545 : Deny 5 11 b19545 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19545 b19546 b19547 (by decide +kernel) e19546 e19547
  have e19543 : Deny 5 11 b19543 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19543 b19544 b19545 (by decide +kernel) e19544 e19545
  have e19541 : Deny 5 11 b19541 :=
    branchAction rule_sound _ _ 3
      0xbbe3 b19541 b19542 b19543 (by decide +kernel) e19542 e19543
  have e19562 : Deny 5 11 b19562 := by
    apply closeAction rule_sound _ _ 64 [0x2082083e23247e2f8c9e2f8c7e2f]
    decide +kernel
  have e19540 : Deny 5 11 b19540 :=
    branchAction rule_sound _ _ 1
      0x9 b19540 b19541 b19562 (by decide +kernel) e19541 e19562
  have e19536 : Deny 5 11 b19536 :=
    branchAction rule_sound _ _ 2
      0x223 b19536 b19537 b19540 (by decide +kernel) e19537 e19540
  have e19528 : Deny 5 11 b19528 :=
    branchAction rule_sound _ _ 1
      0xb b19528 b19529 b19536 (by decide +kernel) e19529 e19536
  have e19486 : Deny 5 11 b19486 :=
    branchAction rule_sound _ _ 1
      0x7 b19486 b19487 b19528 (by decide +kernel) e19487 e19528
  have e19452 : Deny 5 11 b19452 :=
    branchAction rule_sound _ _ 2
      0x263 b19452 b19453 b19486 (by decide +kernel) e19453 e19486
  have e19402 : Deny 5 11 b19402 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19402 b19403 b19452 (by decide +kernel) e19403 e19452
  have e19575 : Deny 5 11 b19575 := by
    apply closeAction rule_sound _ _ 64 [0x15]
    decide +kernel
  have e19577 : Deny 5 11 b19577 := by
    apply closeAction rule_sound _ _ 64 [0x2578dc38c9107e370c38c78c98c40820c727710be23]
    decide +kernel
  have e19592 : Deny 5 11 b19592 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e19576 : Deny 5 11 b19576 :=
    branchAction rule_sound _ _ 2
      0x238 b19576 b19577 b19592 (by decide +kernel) e19577 e19592
  have e19574 : Deny 5 11 b19574 :=
    branchAction rule_sound _ _ 2
      0x2a3 b19574 b19575 b19576 (by decide +kernel) e19575 e19576
  have e19593 : Deny 5 11 b19593 := by
    apply closeAction rule_sound _ _ 64 [0x15e37]
    decide +kernel
  have e19573 : Deny 5 11 b19573 :=
    branchAction rule_sound _ _ 2
      0x1e3 b19573 b19574 b19593 (by decide +kernel) e19574 e19593
  have e19594 : Deny 5 11 b19594 := by
    apply closeAction rule_sound _ _ 64 [0x14e37]
    decide +kernel
  have e19572 : Deny 5 11 b19572 :=
    branchAction rule_sound _ _ 2
      0x263 b19572 b19573 b19594 (by decide +kernel) e19573 e19594
  have e19598 : Deny 5 11 b19598 := by
    apply closeAction rule_sound _ _ 64 [0x820e31f88c9e1d543e03e09e368872a32152a3]
    decide +kernel
  have e19613 : Deny 5 11 b19613 := by
    apply closeAction rule_sound _ _ 64 [0x20f80f88c9e231f80f80e31e32430f8df68c7e23778df68c7e36223]
    decide +kernel
  have e19597 : Deny 5 11 b19597 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19597 b19598 b19613 (by decide +kernel) e19598 e19613
  have e19630 : Deny 5 11 b19630 := by
    apply closeAction rule_sound _ _ 64 [0x15e377552952a3263]
    decide +kernel
  have e19637 : Deny 5 11 b19637 := by
    apply closeAction rule_sound _ _ 64 [0x83e232780f80f88c70f88c98c70c3e23243e231e3263]
    decide +kernel
  have e19629 : Deny 5 11 b19629 :=
    branchAction rule_sound _ _ 1
      0xb b19629 b19630 b19637 (by decide +kernel) e19630 e19637
  have e19652 : Deny 5 11 b19652 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e19628 : Deny 5 11 b19628 :=
    branchAction rule_sound _ _ 1
      0x8 b19628 b19629 b19652 (by decide +kernel) e19629 e19652
  have e19596 : Deny 5 11 b19596 :=
    branchAction rule_sound _ _ 2
      0x1e3 b19596 b19597 b19628 (by decide +kernel) e19597 e19628
  have e19656 : Deny 5 11 b19656 := by
    apply closeAction rule_sound _ _ 64 [0x538be2]
    decide +kernel
  have e19658 : Deny 5 11 b19658 := by
    apply closeAction rule_sound _ _ 64 [0xaf082be2107e378ddbe31f8be3263]
    decide +kernel
  have e19667 : Deny 5 11 b19667 := by
    apply closeAction rule_sound _ _ 64 [0x742bec88ae23]
    decide +kernel
  have e19671 : Deny 5 11 b19671 := by
    apply closeAction rule_sound _ _ 64 [0x76f0f80c78c9be3]
    decide +kernel
  have e19677 : Deny 5 11 b19677 := by
    apply closeAction rule_sound _ _ 64 [0xc3e361e3]
    decide +kernel
  have e19681 : Deny 5 11 b19681 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e19683 : Deny 5 11 b19683 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e19685 : Deny 5 11 b19685 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e19687 : Deny 5 11 b19687 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e19689 : Deny 5 11 b19689 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e19691 : Deny 5 11 b19691 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e19693 : Deny 5 11 b19693 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e19695 : Deny 5 11 b19695 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e19697 : Deny 5 11 b19697 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e19699 : Deny 5 11 b19699 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e19701 : Deny 5 11 b19701 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e19703 : Deny 5 11 b19703 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e19705 : Deny 5 11 b19705 := by
    apply closeAction rule_sound _ _ 64 [0x1dbe3]
    decide +kernel
  have e19706 : Deny 5 11 b19706 := by
    apply closeAction rule_sound _ _ 64 [0xef0e3243d878dd2e374b8ddbe32e376f8cb8ddbe32e3]
    decide +kernel
  have e19704 : Deny 5 11 b19704 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19704 b19705 b19706 (by decide +kernel) e19705 e19706
  have e19702 : Deny 5 11 b19702 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19702 b19703 b19704 (by decide +kernel) e19703 e19704
  have e19700 : Deny 5 11 b19700 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19700 b19701 b19702 (by decide +kernel) e19701 e19702
  have e19698 : Deny 5 11 b19698 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19698 b19699 b19700 (by decide +kernel) e19699 e19700
  have e19696 : Deny 5 11 b19696 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19696 b19697 b19698 (by decide +kernel) e19697 e19698
  have e19694 : Deny 5 11 b19694 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19694 b19695 b19696 (by decide +kernel) e19695 e19696
  have e19692 : Deny 5 11 b19692 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19692 b19693 b19694 (by decide +kernel) e19693 e19694
  have e19690 : Deny 5 11 b19690 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19690 b19691 b19692 (by decide +kernel) e19691 e19692
  have e19688 : Deny 5 11 b19688 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19688 b19689 b19690 (by decide +kernel) e19689 e19690
  have e19686 : Deny 5 11 b19686 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19686 b19687 b19688 (by decide +kernel) e19687 e19688
  have e19684 : Deny 5 11 b19684 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19684 b19685 b19686 (by decide +kernel) e19685 e19686
  have e19682 : Deny 5 11 b19682 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19682 b19683 b19684 (by decide +kernel) e19683 e19684
  have e19680 : Deny 5 11 b19680 :=
    branchAction rule_sound _ _ 1
      0xb b19680 b19681 b19682 (by decide +kernel) e19681 e19682
  have e19676 : Deny 5 11 b19676 :=
    branchAction rule_sound _ _ 2
      0x263 b19676 b19677 b19680 (by decide +kernel) e19677 e19680
  have e19670 : Deny 5 11 b19670 :=
    branchAction rule_sound _ _ 1
      0xb b19670 b19671 b19676 (by decide +kernel) e19671 e19676
  have e19666 : Deny 5 11 b19666 :=
    branchAction rule_sound _ _ 2
      0x1e3 b19666 b19667 b19670 (by decide +kernel) e19667 e19670
  have e19723 : Deny 5 11 b19723 := by
    apply closeAction rule_sound _ _ 64 [0x538be2]
    decide +kernel
  have e19725 : Deny 5 11 b19725 := by
    apply closeAction rule_sound _ _ 64 [0xaf8dc278be3]
    decide +kernel
  have e19729 : Deny 5 11 b19729 := by
    apply closeAction rule_sound _ _ 64 [0x30f61c21e374b8dd2dde2326374b778da31e3]
    decide +kernel
  have e19745 : Deny 5 11 b19745 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e19747 : Deny 5 11 b19747 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e19749 : Deny 5 11 b19749 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e19751 : Deny 5 11 b19751 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e19752 : Deny 5 11 b19752 := by
    apply closeAction rule_sound _ _ 64 [0x271c2ef8c909cbe326f72f8c9bc21f68c78dcbe32e3]
    decide +kernel
  have e19750 : Deny 5 11 b19750 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19750 b19751 b19752 (by decide +kernel) e19751 e19752
  have e19748 : Deny 5 11 b19748 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19748 b19749 b19750 (by decide +kernel) e19749 e19750
  have e19746 : Deny 5 11 b19746 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19746 b19747 b19748 (by decide +kernel) e19747 e19748
  have e19744 : Deny 5 11 b19744 :=
    branchAction rule_sound _ _ 2
      0x2ef b19744 b19745 b19746 (by decide +kernel) e19745 e19746
  have e19728 : Deny 5 11 b19728 :=
    branchAction rule_sound _ _ 2
      0x263 b19728 b19729 b19744 (by decide +kernel) e19729 e19744
  have e19724 : Deny 5 11 b19724 :=
    branchAction rule_sound _ _ 2
      0x2f8 b19724 b19725 b19728 (by decide +kernel) e19725 e19728
  have e19722 : Deny 5 11 b19722 :=
    branchAction rule_sound _ _ 2
      0x2a3 b19722 b19723 b19724 (by decide +kernel) e19723 e19724
  have e19767 : Deny 5 11 b19767 := by
    apply closeAction rule_sound _ _ 64 [0x82083e03e07e232788c7e2f8c9e23]
    decide +kernel
  have e19721 : Deny 5 11 b19721 :=
    branchAction rule_sound _ _ 3
      0x7e2f b19721 b19722 b19767 (by decide +kernel) e19722 e19767
  have e19665 : Deny 5 11 b19665 :=
    branchAction rule_sound _ _ 2
      0x263 b19665 b19666 b19721 (by decide +kernel) e19666 e19721
  have e19657 : Deny 5 11 b19657 :=
    branchAction rule_sound _ _ 2
      0x2f8 b19657 b19658 b19665 (by decide +kernel) e19658 e19665
  have e19655 : Deny 5 11 b19655 :=
    branchAction rule_sound _ _ 2
      0x2a3 b19655 b19656 b19657 (by decide +kernel) e19656 e19657
  have e19776 : Deny 5 11 b19776 := by
    apply closeAction rule_sound _ _ 64 [0x820820f88c7e232788c7e23278]
    decide +kernel
  have e19654 : Deny 5 11 b19654 :=
    branchAction rule_sound _ _ 1
      0x7 b19654 b19655 b19776 (by decide +kernel) e19655 e19776
  have e19785 : Deny 5 11 b19785 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e19653 : Deny 5 11 b19653 :=
    branchAction rule_sound _ _ 1
      0x8 b19653 b19654 b19785 (by decide +kernel) e19654 e19785
  have e19595 : Deny 5 11 b19595 :=
    branchAction rule_sound _ _ 2
      0x263 b19595 b19596 b19653 (by decide +kernel) e19596 e19653
  have e19571 : Deny 5 11 b19571 :=
    branchAction rule_sound _ _ 1
      0xb b19571 b19572 b19595 (by decide +kernel) e19572 e19595
  have e19401 : Deny 5 11 b19401 :=
    branchAction rule_sound _ _ 2
      0x1e3 b19401 b19402 b19571 (by decide +kernel) e19402 e19571
  have e19788 : Deny 5 11 b19788 := by
    apply closeAction rule_sound _ _ 64 [0x82082bc38c98c78c8e23263]
    decide +kernel
  have e19799 : Deny 5 11 b19799 := by
    apply closeAction rule_sound _ _ 64 [0x83e231f88c3e232780f80f88c70f88c98c7]
    decide +kernel
  have e19810 : Deny 5 11 b19810 := by
    apply closeAction rule_sound _ _ 64 [0x82083e231f80f88c98c8e231f8]
    decide +kernel
  have e19798 : Deny 5 11 b19798 :=
    branchAction rule_sound _ _ 2
      0x223 b19798 b19799 b19810 (by decide +kernel) e19799 e19810
  have e19819 : Deny 5 11 b19819 := by
    apply closeAction rule_sound _ _ 64 [0x820820f88c9e230f88c3e231f8bc3e232631f8be32631e3238]
    decide +kernel
  have e19797 : Deny 5 11 b19797 :=
    branchAction rule_sound _ _ 2
      0x263 b19797 b19798 b19819 (by decide +kernel) e19798 e19819
  have e19787 : Deny 5 11 b19787 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19787 b19788 b19797 (by decide +kernel) e19788 e19797
  have e19834 : Deny 5 11 b19834 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e19786 : Deny 5 11 b19786 :=
    branchAction rule_sound _ _ 2
      0x1f8 b19786 b19787 b19834 (by decide +kernel) e19787 e19834
  have e19400 : Deny 5 11 b19400 :=
    branchAction rule_sound _ _ 1
      0x8 b19400 b19401 b19786 (by decide +kernel) e19401 e19786
  have e19234 : Deny 5 11 b19234 :=
    branchAction rule_sound _ _ 2
      0x263 b19234 b19235 b19400 (by decide +kernel) e19235 e19400
  have e19130 : Deny 5 11 b19130 :=
    branchAction rule_sound _ _ 2
      0x2e3 b19130 b19131 b19234 (by decide +kernel) e19131 e19234
  exact e19130
end OMA.Blocks5_11_245212.S19130
