import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S65332
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b65332 : Box := ![⟨95,190⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨1,565934718100890211130⟩,⟨239,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨63,1920000000000000011376⟩,⟨10,14⟩,⟨1,565934718100890211130⟩,⟨239,999999999999999999⟩] := by
  have e65332 : Deny 5 13 b65332 := by
    apply closeAction rule_sound _ _ 64 [0x8c88db6d36d32b84c920a2932932a32e31e3223263082093e370820e31e32784ca8c88d3dcb8c78c8e232632e31e3238,0x2788c8e231f80820f88c7e03e038c78c88c2083e231f88c88cbe23278083e231f80c38c7243e038c70f88c3e378c7e09,0x20820820820f88c7e09e232388c7e23238082082083e232388c7e23]
    decide +kernel
  exact e65332
end OMA.Blocks5_13_245212.S65332
