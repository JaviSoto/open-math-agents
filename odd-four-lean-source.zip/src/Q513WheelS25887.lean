import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S25887
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b25887 : Box := ![⟨31,37⟩,⟨63,126⟩,⟨15,30⟩,⟨3,69⟩,⟨165,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨31,37⟩,⟨63,126⟩,⟨15,30⟩,⟨3,69⟩,⟨165,233⟩] := by
  have e25887 : Deny 5 13 b25887 := by
    apply closeAction rule_sound _ _ 64 [0xe378c97f8de321fe378c911ee37db5107e378c88c77eb0dfe378c87f8dc711fe378c4278de321f087e37db58c78c98c4,0x2781dfe2321fe378c96b8df6d631dfe37da12b78c479f7838c42781e325a7ca8c97ca0c2ae12611021f8dea84a10b0df,0x103e370c9108e030eb8498490c32038490f8de12611c30c80c3e372090c3e37243e37d88d8722110b84a7c3103e378c4,0xf7248103e370eb8490c324810b0c40f8de1109e378490c3e378470f8dc80a12768470c3e37243e37d88087d88117e37,0x1f0c3ae1243]
    decide +kernel
  exact e25887
end OMA.Blocks5_13_245212.S25887
