import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S55847
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b55847 : Box := ![⟨63,75⟩,⟨63,126⟩,⟨10,14⟩,⟨1,60⟩,⟨479,958⟩]
private def b55848 : Box := ![⟨63,75⟩,⟨63,126⟩,⟨10,14⟩,⟨1,2⟩,⟨479,958⟩]
private def b55849 : Box := ![⟨63,75⟩,⟨63,126⟩,⟨10,14⟩,⟨3,55⟩,⟨479,958⟩]
private def b55850 : Box := ![⟨63,75⟩,⟨63,126⟩,⟨10,11⟩,⟨3,55⟩,⟨479,958⟩]
private def b55851 : Box := ![⟨63,75⟩,⟨63,84⟩,⟨10,11⟩,⟨3,53⟩,⟨479,958⟩]
private def b55852 : Box := ![⟨63,68⟩,⟨63,84⟩,⟨10,11⟩,⟨3,42⟩,⟨479,958⟩]
private def b55857 : Box := ![⟨69,75⟩,⟨63,84⟩,⟨10,11⟩,⟨3,42⟩,⟨479,958⟩]
private def b55858 : Box := ![⟨69,75⟩,⟨63,84⟩,⟨10,11⟩,⟨3,42⟩,⟨479,638⟩]
private def b55865 : Box := ![⟨69,75⟩,⟨63,84⟩,⟨10,11⟩,⟨3,42⟩,⟨639,958⟩]
private def b55870 : Box := ![⟨63,75⟩,⟨85,126⟩,⟨10,11⟩,⟨3,53⟩,⟨479,958⟩]
private def b55871 : Box := ![⟨63,68⟩,⟨85,126⟩,⟨10,11⟩,⟨3,53⟩,⟨479,958⟩]
private def b55872 : Box := ![⟨63,68⟩,⟨85,126⟩,⟨10,11⟩,⟨3,52⟩,⟨479,638⟩]
private def b55883 : Box := ![⟨63,68⟩,⟨85,126⟩,⟨10,11⟩,⟨3,52⟩,⟨639,958⟩]
private def b55894 : Box := ![⟨69,75⟩,⟨85,126⟩,⟨10,11⟩,⟨3,53⟩,⟨479,958⟩]
private def b55895 : Box := ![⟨69,75⟩,⟨85,126⟩,⟨10,11⟩,⟨3,53⟩,⟨479,638⟩]
private def b55896 : Box := ![⟨69,75⟩,⟨85,101⟩,⟨10,11⟩,⟨3,53⟩,⟨479,638⟩]
private def b55903 : Box := ![⟨69,75⟩,⟨102,126⟩,⟨10,11⟩,⟨3,53⟩,⟨479,638⟩]
private def b55908 : Box := ![⟨69,75⟩,⟨85,126⟩,⟨10,11⟩,⟨3,53⟩,⟨639,958⟩]
private def b55909 : Box := ![⟨69,75⟩,⟨85,101⟩,⟨10,11⟩,⟨3,51⟩,⟨639,958⟩]
private def b55916 : Box := ![⟨69,75⟩,⟨102,126⟩,⟨10,11⟩,⟨3,51⟩,⟨639,958⟩]
private def b55921 : Box := ![⟨63,75⟩,⟨63,126⟩,⟨12,14⟩,⟨3,55⟩,⟨479,958⟩]
private def b55922 : Box := ![⟨63,75⟩,⟨63,84⟩,⟨12,14⟩,⟨3,55⟩,⟨479,958⟩]
private def b55923 : Box := ![⟨63,68⟩,⟨63,84⟩,⟨12,14⟩,⟨3,44⟩,⟨479,958⟩]
private def b55924 : Box := ![⟨63,68⟩,⟨63,84⟩,⟨12,14⟩,⟨3,42⟩,⟨479,638⟩]
private def b55933 : Box := ![⟨63,68⟩,⟨63,84⟩,⟨12,14⟩,⟨3,42⟩,⟨639,958⟩]
private def b55942 : Box := ![⟨69,75⟩,⟨63,84⟩,⟨12,14⟩,⟨3,44⟩,⟨479,958⟩]
private def b55943 : Box := ![⟨69,75⟩,⟨63,84⟩,⟨12,14⟩,⟨3,44⟩,⟨479,638⟩]
private def b55952 : Box := ![⟨69,75⟩,⟨63,84⟩,⟨12,14⟩,⟨3,44⟩,⟨639,958⟩]
private def b55963 : Box := ![⟨63,75⟩,⟨85,126⟩,⟨12,14⟩,⟨3,55⟩,⟨479,958⟩]
private def b55964 : Box := ![⟨63,68⟩,⟨85,126⟩,⟨12,14⟩,⟨3,55⟩,⟨479,958⟩]
private def b55965 : Box := ![⟨63,68⟩,⟨85,126⟩,⟨12,14⟩,⟨3,53⟩,⟨479,638⟩]
private def b55974 : Box := ![⟨63,68⟩,⟨85,126⟩,⟨12,14⟩,⟨3,53⟩,⟨639,958⟩]
private def b55975 : Box := ![⟨63,68⟩,⟨85,101⟩,⟨12,14⟩,⟨3,51⟩,⟨639,958⟩]
private def b55984 : Box := ![⟨63,68⟩,⟨102,126⟩,⟨12,14⟩,⟨3,51⟩,⟨639,958⟩]
private def b55989 : Box := ![⟨69,75⟩,⟨85,126⟩,⟨12,14⟩,⟨3,55⟩,⟨479,958⟩]
private theorem e55848 : Deny 5 13 b55848 := by
    apply closeAction rule_sound _ _ 64 [0x13]
    decide +kernel
private theorem e55852 : Deny 5 13 b55852 := by
    apply closeAction rule_sound _ _ 64 [0x3089102238de3]
    decide +kernel
private theorem e55858 : Deny 5 13 b55858 := by
    apply closeAction rule_sound _ _ 64 [0xc3e372430898c8]
    decide +kernel
private theorem e55865 : Deny 5 13 b55865 := by
    apply closeAction rule_sound _ _ 64 [0xc225be37da3223]
    decide +kernel
private theorem e55857 : Deny 5 13 b55857 :=
    branchAction rule_sound _ _ 1
      0xb b55857 b55858 b55865 (by decide +kernel) e55858 e55865
private theorem e55851 : Deny 5 13 b55851 :=
    branchAction rule_sound _ _ 2
      0x1e3 b55851 b55852 b55857 (by decide +kernel) e55852 e55857
private theorem e55872 : Deny 5 13 b55872 := by
    apply closeAction rule_sound _ _ 64 [0x1b0c3e211c3e378421f8de1243e212a12ab]
    decide +kernel
private theorem e55883 : Deny 5 13 b55883 := by
    apply closeAction rule_sound _ _ 64 [0x6db0f88421f884a6f8df584984a0f8df6ae12a3]
    decide +kernel
private theorem e55871 : Deny 5 13 b55871 :=
    branchAction rule_sound _ _ 2
      0x2e3 b55871 b55872 b55883 (by decide +kernel) e55872 e55883
private theorem e55896 : Deny 5 13 b55896 := by
    apply closeAction rule_sound _ _ 64 [0x4f8dc38c7e030eb1e3263]
    decide +kernel
private theorem e55903 : Deny 5 13 b55903 := by
    apply closeAction rule_sound _ _ 64 [0x83e370f8ae31e3109e2b]
    decide +kernel
private theorem e55895 : Deny 5 13 b55895 :=
    branchAction rule_sound _ _ 1
      0x8 b55895 b55896 b55903 (by decide +kernel) e55896 e55903
private theorem e55909 : Deny 5 13 b55909 := by
    apply closeAction rule_sound _ _ 64 [0x30e31c36b8dc7e23263]
    decide +kernel
private theorem e55916 : Deny 5 13 b55916 := by
    apply closeAction rule_sound _ _ 64 [0x1bac3e03ae326322b]
    decide +kernel
private theorem e55908 : Deny 5 13 b55908 :=
    branchAction rule_sound _ _ 2
      0x223 b55908 b55909 b55916 (by decide +kernel) e55909 e55916
private theorem e55894 : Deny 5 13 b55894 :=
    branchAction rule_sound _ _ 1
      0xb b55894 b55895 b55908 (by decide +kernel) e55895 e55908
private theorem e55870 : Deny 5 13 b55870 :=
    branchAction rule_sound _ _ 1
      0x7 b55870 b55871 b55894 (by decide +kernel) e55871 e55894
private theorem e55850 : Deny 5 13 b55850 :=
    branchAction rule_sound _ _ 2
      0x223 b55850 b55851 b55870 (by decide +kernel) e55851 e55870
private theorem e55924 : Deny 5 13 b55924 := by
    apply closeAction rule_sound _ _ 64 [0x3e370c70e32430c78c8]
    decide +kernel
private theorem e55933 : Deny 5 13 b55933 := by
    apply closeAction rule_sound _ _ 64 [0x30c70f82430f81e3223]
    decide +kernel
private theorem e55923 : Deny 5 13 b55923 :=
    branchAction rule_sound _ _ 2
      0x2e3 b55923 b55924 b55933 (by decide +kernel) e55924 e55933
private theorem e55943 : Deny 5 13 b55943 := by
    apply closeAction rule_sound _ _ 64 [0x83278dc20f82780c98c8]
    decide +kernel
private theorem e55952 : Deny 5 13 b55952 := by
    apply closeAction rule_sound _ _ 64 [0x831f8dc38c90c38c70e3263223]
    decide +kernel
private theorem e55942 : Deny 5 13 b55942 :=
    branchAction rule_sound _ _ 1
      0xb b55942 b55943 b55952 (by decide +kernel) e55943 e55952
private theorem e55922 : Deny 5 13 b55922 :=
    branchAction rule_sound _ _ 2
      0x1e3 b55922 b55923 b55942 (by decide +kernel) e55923 e55942
private theorem e55965 : Deny 5 13 b55965 := by
    apply closeAction rule_sound _ _ 64 [0xab082aa88441f8dc3e370eb8c78c98c8]
    decide +kernel
private theorem e55975 : Deny 5 13 b55975 := by
    apply closeAction rule_sound _ _ 64 [0x20f8ac7e37ac38c80c3ae31e3263]
    decide +kernel
private theorem e55984 : Deny 5 13 b55984 := by
    apply closeAction rule_sound _ _ 64 [0x820f8ac7e2b8c9e2b]
    decide +kernel
private theorem e55974 : Deny 5 13 b55974 :=
    branchAction rule_sound _ _ 2
      0x223 b55974 b55975 b55984 (by decide +kernel) e55975 e55984
private theorem e55964 : Deny 5 13 b55964 :=
    branchAction rule_sound _ _ 2
      0x2e3 b55964 b55965 b55974 (by decide +kernel) e55965 e55974
private theorem e55989 : Deny 5 13 b55989 := by
    apply closeAction rule_sound _ _ 64 [0x820831f7248e37]
    decide +kernel
private theorem e55963 : Deny 5 13 b55963 :=
    branchAction rule_sound _ _ 1
      0x7 b55963 b55964 b55989 (by decide +kernel) e55964 e55989
private theorem e55921 : Deny 5 13 b55921 :=
    branchAction rule_sound _ _ 1
      0x8 b55921 b55922 b55963 (by decide +kernel) e55922 e55963
private theorem e55849 : Deny 5 13 b55849 :=
    branchAction rule_sound _ _ 1
      0x9 b55849 b55850 b55921 (by decide +kernel) e55850 e55921
private theorem e55847 : Deny 5 13 b55847 :=
    branchAction rule_sound _ _ 2
      0x2a3 b55847 b55848 b55849 (by decide +kernel) e55848 e55849
theorem deny5_13 : Deny 5 13 ![⟨63,75⟩,⟨63,126⟩,⟨10,14⟩,⟨1,60⟩,⟨479,958⟩] := by
  exact e55847
end OMA.Blocks5_13_245212.S55847
