import FastReplay245212

/-! Four-prime exclusion on an initial range, by the checked finite trace. -/
namespace OMA.Box245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def words5_29 : List ℕ := [
0x7db4e129b6e78c81a321b6ab8c71a31c68c97d788a5d79a22068885d6aa21c68871a229f7c818819f7c71871828c9184]
theorem deny5_29 : Deny 5 29 ![⟨2,8400⟩,⟨1,8400⟩,⟨1,8400⟩,⟨1,8400⟩,⟨30,34⟩] := by
  apply OMA.FastReplay245212.certify _ _ 64 words5_29
  decide +kernel
end OMA.Box245212
