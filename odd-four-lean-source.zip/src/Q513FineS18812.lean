import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S18812
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b18812 : Box := ![⟨31,46⟩,⟨31,1920000000000000011376⟩,⟨7,14⟩,⟨1,2⟩,⟨59,113⟩]
theorem deny5_13 : Deny 5 13 ![⟨31,46⟩,⟨31,1920000000000000011376⟩,⟨7,14⟩,⟨1,2⟩,⟨59,113⟩] := by
  have e18812 : Deny 5 13 b18812 := by
    apply closeAction rule_sound _ _ 64 [0xe11f80c88498495ca0d3203088e211c44c30c88478442d30f8107e084c94ca8495c3e022421c2238df5849da11c42e1,0xc22211021f8da12761170c3e080890a11e12442d7db51175c2278257e361cbe36217e36d61297e37db5847d845d70f8,0x17]
    decide +kernel
  exact e18812
end OMA.Blocks5_13_245212.S18812
