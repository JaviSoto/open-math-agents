import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S54728
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b54728 : Box := ![⟨58,62⟩,⟨85,126⟩,⟨12,14⟩,⟨3,52⟩,⟨479,638⟩]
private def b54729 : Box := ![⟨58,62⟩,⟨85,101⟩,⟨12,14⟩,⟨3,52⟩,⟨479,638⟩]
private def b54730 : Box := ![⟨58,62⟩,⟨85,101⟩,⟨12,12⟩,⟨4,46⟩,⟨479,638⟩]
private def b54731 : Box := ![⟨58,62⟩,⟨85,101⟩,⟨13,14⟩,⟨4,46⟩,⟨479,638⟩]
private def b54732 : Box := ![⟨58,62⟩,⟨85,92⟩,⟨13,14⟩,⟨4,46⟩,⟨479,638⟩]
private def b54733 : Box := ![⟨58,62⟩,⟨93,101⟩,⟨13,14⟩,⟨4,46⟩,⟨479,638⟩]
private def b54734 : Box := ![⟨58,62⟩,⟨102,126⟩,⟨12,14⟩,⟨3,52⟩,⟨479,638⟩]
private def b54735 : Box := ![⟨58,62⟩,⟨102,126⟩,⟨12,12⟩,⟨8,52⟩,⟨479,638⟩]
private def b54736 : Box := ![⟨58,62⟩,⟨102,126⟩,⟨12,12⟩,⟨9,51⟩,⟨482,549⟩]
private def b54737 : Box := ![⟨58,62⟩,⟨102,126⟩,⟨12,12⟩,⟨9,51⟩,⟨550,638⟩]
private def b54738 : Box := ![⟨58,62⟩,⟨102,126⟩,⟨13,14⟩,⟨8,52⟩,⟨479,638⟩]
private def b54739 : Box := ![⟨58,62⟩,⟨102,112⟩,⟨13,14⟩,⟨8,8⟩,⟨632,638⟩]
private def b54740 : Box := ![⟨58,62⟩,⟨113,126⟩,⟨13,14⟩,⟨8,8⟩,⟨632,638⟩]
private theorem e54730 : Deny 5 13 b54730 := by
    apply closeAction rule_sound _ _ 64 [0xe3]
    decide +kernel
private theorem e54732 : Deny 5 13 b54732 := by
    apply closeAction rule_sound _ _ 64 [0xe3]
    decide +kernel
private theorem e54733 : Deny 5 13 b54733 := by
    apply closeAction rule_sound _ _ 64 [0x3e2b]
    decide +kernel
private theorem e54731 : Deny 5 13 b54731 :=
    branchAction rule_sound _ _ 1
      0x8 b54731 b54732 b54733 (by decide +kernel) e54732 e54733
private theorem e54729 : Deny 5 13 b54729 :=
    branchAction rule_sound _ _ 3
      0x9ae3 b54729 b54730 b54731 (by decide +kernel) e54730 e54731
private theorem e54736 : Deny 5 13 b54736 := by
    apply closeAction rule_sound _ _ 64 [0x1b]
    decide +kernel
private theorem e54737 : Deny 5 13 b54737 := by
    apply closeAction rule_sound _ _ 64 [0x1b]
    decide +kernel
private theorem e54735 : Deny 5 13 b54735 :=
    branchAction rule_sound _ _ 4
      0x2f8ae3 b54735 b54736 b54737 (by decide +kernel) e54736 e54737
private theorem e54739 : Deny 5 13 b54739 := by
    apply closeAction rule_sound _ _ 64 [0x4]
    decide +kernel
private theorem e54740 : Deny 5 13 b54740 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e54738 : Deny 5 13 b54738 :=
    branchAction rule_sound _ _ 3
      0x8e37 b54738 b54739 b54740 (by decide +kernel) e54739 e54740
private theorem e54734 : Deny 5 13 b54734 :=
    branchAction rule_sound _ _ 2
      0x26b b54734 b54735 b54738 (by decide +kernel) e54735 e54738
private theorem e54728 : Deny 5 13 b54728 :=
    branchAction rule_sound _ _ 1
      0x8 b54728 b54729 b54734 (by decide +kernel) e54729 e54734
theorem deny5_13 : Deny 5 13 ![⟨58,62⟩,⟨85,126⟩,⟨12,14⟩,⟨3,52⟩,⟨479,638⟩] := by
  exact e54728
end OMA.Blocks5_13_245212.S54728
