import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S51593
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b51593 : Box := ![⟨191,382⟩,⟨21,24⟩,⟨21,30⟩,⟨3,95⟩,⟨479,958⟩]
private def b51594 : Box := ![⟨191,254⟩,⟨21,24⟩,⟨21,30⟩,⟨12,90⟩,⟨479,958⟩]
private def b51595 : Box := ![⟨191,254⟩,⟨21,22⟩,⟨21,30⟩,⟨12,67⟩,⟨479,958⟩]
private def b51596 : Box := ![⟨191,254⟩,⟨21,22⟩,⟨21,30⟩,⟨13,22⟩,⟨479,958⟩]
private def b51597 : Box := ![⟨191,251⟩,⟨21,22⟩,⟨21,24⟩,⟨13,22⟩,⟨479,958⟩]
private def b51598 : Box := ![⟨191,237⟩,⟨21,22⟩,⟨21,24⟩,⟨15,22⟩,⟨479,638⟩]
private def b51599 : Box := ![⟨191,229⟩,⟨21,22⟩,⟨21,24⟩,⟨16,22⟩,⟨479,547⟩]
private def b51606 : Box := ![⟨191,229⟩,⟨21,22⟩,⟨21,24⟩,⟨16,22⟩,⟨548,638⟩]
private def b51611 : Box := ![⟨191,237⟩,⟨21,22⟩,⟨21,24⟩,⟨15,22⟩,⟨639,958⟩]
private def b51620 : Box := ![⟨191,251⟩,⟨21,22⟩,⟨25,30⟩,⟨13,22⟩,⟨479,958⟩]
private def b51629 : Box := ![⟨191,254⟩,⟨21,22⟩,⟨21,30⟩,⟨23,66⟩,⟨479,958⟩]
private def b51630 : Box := ![⟨191,254⟩,⟨23,24⟩,⟨21,30⟩,⟨12,67⟩,⟨479,958⟩]
private def b51635 : Box := ![⟨255,382⟩,⟨21,24⟩,⟨21,30⟩,⟨12,90⟩,⟨479,958⟩]
private theorem e51599 : Deny 5 13 b51599 := by
    apply closeAction rule_sound _ _ 64 [0x20e780427864380a9e0220]
    decide +kernel
private theorem e51606 : Deny 5 13 b51606 := by
    apply closeAction rule_sound _ _ 64 [0x199c30f8d881c4]
    decide +kernel
private theorem e51598 : Deny 5 13 b51598 :=
    branchAction rule_sound _ _ 3
      0xb9e0 b51598 b51599 b51606 (by decide +kernel) e51599 e51606
private theorem e51611 : Deny 5 13 b51611 := by
    apply closeAction rule_sound _ _ 64 [0x643e3680a6670c22079e010b]
    decide +kernel
private theorem e51597 : Deny 5 13 b51597 :=
    branchAction rule_sound _ _ 3
      0xb9e0 b51597 b51598 b51611 (by decide +kernel) e51598 e51611
private theorem e51620 : Deny 5 13 b51620 := by
    apply closeAction rule_sound _ _ 64 [0x1d083107e1d2380f89e02789e0278]
    decide +kernel
private theorem e51596 : Deny 5 13 b51596 :=
    branchAction rule_sound _ _ 2
      0x260 b51596 b51597 b51620 (by decide +kernel) e51597 e51620
private theorem e51629 : Deny 5 13 b51629 := by
    apply closeAction rule_sound _ _ 64 [0x19]
    decide +kernel
private theorem e51595 : Deny 5 13 b51595 :=
    branchAction rule_sound _ _ 3
      0xa9e3 b51595 b51596 b51629 (by decide +kernel) e51596 e51629
private theorem e51630 : Deny 5 13 b51630 := by
    apply closeAction rule_sound _ _ 64 [0x265f2b89e3278]
    decide +kernel
private theorem e51594 : Deny 5 13 b51594 :=
    branchAction rule_sound _ _ 2
      0x223 b51594 b51595 b51630 (by decide +kernel) e51595 e51630
private theorem e51635 : Deny 5 13 b51635 := by
    apply closeAction rule_sound _ _ 64 [0x19e27]
    decide +kernel
private theorem e51593 : Deny 5 13 b51593 :=
    branchAction rule_sound _ _ 3
      0x79e3 b51593 b51594 b51635 (by decide +kernel) e51594 e51635
theorem deny5_13 : Deny 5 13 ![⟨191,382⟩,⟨21,24⟩,⟨21,30⟩,⟨3,95⟩,⟨479,958⟩] := by
  exact e51593
end OMA.Blocks5_13_245212.S51593
