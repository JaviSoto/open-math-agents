import LargeChecker245212

/-! Exact large-prime arithmetic certificate from large_last_245212.py. -/
namespace OMA.Large245212
private def bp11x1 : B := ![⟨1,some 3⟩,⟨1,none⟩,⟨1,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x1 : Deny 1000000000000000000 11 bp11x1 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x2 : B := ![⟨4,none⟩,⟨1,none⟩,⟨1,none⟩]
private def bp11x3 : B := ![⟨4,none⟩,⟨1,some 3⟩,⟨1,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x3 : Deny 1000000000000000000 11 bp11x3 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x4 : B := ![⟨4,none⟩,⟨4,none⟩,⟨1,none⟩]
private def bp11x5 : B := ![⟨4,some 9⟩,⟨4,none⟩,⟨1,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x5 : Deny 1000000000000000000 11 bp11x5 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x6 : B := ![⟨10,none⟩,⟨4,none⟩,⟨1,none⟩]
private def bp11x7 : B := ![⟨10,none⟩,⟨4,some 9⟩,⟨1,none⟩]
private def bp11x8 : B := ![⟨10,none⟩,⟨4,some 9⟩,⟨1,some 3⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x8 : Deny 1000000000000000000 11 bp11x8 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x9 : B := ![⟨10,none⟩,⟨4,some 9⟩,⟨4,none⟩]
private def bp11x10 : B := ![⟨10,some 21⟩,⟨4,some 9⟩,⟨4,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x10 : Deny 1000000000000000000 11 bp11x10 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x11 : B := ![⟨22,none⟩,⟨4,some 9⟩,⟨4,none⟩]
private def bp11x12 : B := ![⟨22,none⟩,⟨4,some 5⟩,⟨4,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x12 : Deny 1000000000000000000 11 bp11x12 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x13 : B := ![⟨22,none⟩,⟨6,some 9⟩,⟨4,none⟩]
private def bp11x14 : B := ![⟨22,some 45⟩,⟨6,some 9⟩,⟨4,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x14 : Deny 1000000000000000000 11 bp11x14 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x15 : B := ![⟨46,none⟩,⟨6,some 9⟩,⟨4,none⟩]
private def bp11x16 : B := ![⟨46,none⟩,⟨6,some 9⟩,⟨4,some 9⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x16 : Deny 1000000000000000000 11 bp11x16 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x17 : B := ![⟨46,none⟩,⟨6,some 9⟩,⟨10,none⟩]
private def bp11x18 : B := ![⟨46,none⟩,⟨6,some 7⟩,⟨10,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x18 : Deny 1000000000000000000 11 bp11x18 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x19 : B := ![⟨46,none⟩,⟨8,some 9⟩,⟨10,none⟩]
private def bp11x20 : B := ![⟨46,some 93⟩,⟨8,some 9⟩,⟨10,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x20 : Deny 1000000000000000000 11 bp11x20 :=
  sound (by decide) (by decide) 34 590514221053394850353400759456333015599313720248625451997288488002920460418938415620307482459927140789456622855495223204430154740867859 (tail:=0) (by decide +kernel)
private def bp11x255 : B := ![⟨94,none⟩,⟨8,some 9⟩,⟨10,none⟩]
private def bp11x256 : B := ![⟨94,none⟩,⟨8,some 9⟩,⟨10,some 21⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x256 : Deny 1000000000000000000 11 bp11x256 :=
  sound (by decide) (by decide) 23 528931477418707132046490975764781599674238237483586898466727897239197922296765892203057 (tail:=0) (by decide +kernel)
private def bp11x409 : B := ![⟨94,none⟩,⟨8,some 9⟩,⟨22,none⟩]
private def bp11x410 : B := ![⟨94,some 189⟩,⟨8,some 9⟩,⟨22,none⟩]
private def bp11x411 : B := ![⟨94,some 189⟩,⟨8,some 9⟩,⟨22,some 45⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x411 : Deny 1000000000000000000 11 bp11x411 :=
  sound (by decide) (by decide) 15 1869735232198802082938548875880875120717975964498198496504279667474 (tail:=0) (by decide +kernel)
private def bp11x528 : B := ![⟨94,some 189⟩,⟨8,some 9⟩,⟨46,none⟩]
private def bp11x529 : B := ![⟨94,some 189⟩,⟨8,some 8⟩,⟨46,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x529 : Deny 1000000000000000000 11 bp11x529 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x530 : B := ![⟨94,some 189⟩,⟨9,some 9⟩,⟨46,none⟩]
private def bp11x531 : B := ![⟨94,some 125⟩,⟨9,some 9⟩,⟨46,none⟩]
private def bp11x532 : B := ![⟨94,some 125⟩,⟨9,some 9⟩,⟨46,some 93⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x532 : Deny 1000000000000000000 11 bp11x532 :=
  sound (by decide) (by decide) 13 23511067158702956213686046938924212229018455435964798899929935007025 (tail:=0) (by decide +kernel)
private def bp11x651 : B := ![⟨94,some 125⟩,⟨9,some 9⟩,⟨94,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x651 : Deny 1000000000000000000 11 bp11x651 :=
  sound (by decide) (by decide) 17 3685152689781072098845099520552357932883723470265088707815977631502808232037723850370254059730828413620271988529142107912780379590279418005654863912669414282590412616288029 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x531 : Deny 1000000000000000000 11 bp11x531 := by
  apply split bp11x531 2
  · rw [show leftB bp11x531 2=bp11x532 by funext i; fin_cases i <;> rfl]; exact p11x532
  · rw [show rightB bp11x531 2=bp11x651 by funext i; fin_cases i <;> rfl]; exact p11x651
private def bp11x946 : B := ![⟨126,some 189⟩,⟨9,some 9⟩,⟨46,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x946 : Deny 1000000000000000000 11 bp11x946 :=
  sound (by decide) (by decide) 14 22452908805652831217244866366257612055576554871320921547747308654089079 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x530 : Deny 1000000000000000000 11 bp11x530 := by
  apply split bp11x530 0
  · rw [show leftB bp11x530 0=bp11x531 by funext i; fin_cases i <;> rfl]; exact p11x531
  · rw [show rightB bp11x530 0=bp11x946 by funext i; fin_cases i <;> rfl]; exact p11x946
set_option maxRecDepth 100000 in
private theorem p11x528 : Deny 1000000000000000000 11 bp11x528 := by
  apply split bp11x528 1
  · rw [show leftB bp11x528 1=bp11x529 by funext i; fin_cases i <;> rfl]; exact p11x529
  · rw [show rightB bp11x528 1=bp11x530 by funext i; fin_cases i <;> rfl]; exact p11x530
set_option maxRecDepth 100000 in
private theorem p11x410 : Deny 1000000000000000000 11 bp11x410 := by
  apply split bp11x410 2
  · rw [show leftB bp11x410 2=bp11x411 by funext i; fin_cases i <;> rfl]; exact p11x411
  · rw [show rightB bp11x410 2=bp11x528 by funext i; fin_cases i <;> rfl]; exact p11x528
private def bp11x1073 : B := ![⟨190,none⟩,⟨8,some 9⟩,⟨22,none⟩]
private def bp11x1074 : B := ![⟨190,none⟩,⟨8,some 9⟩,⟨22,some 45⟩]
private def bp11x1075 : B := ![⟨190,none⟩,⟨8,some 8⟩,⟨22,some 45⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x1075 : Deny 1000000000000000000 11 bp11x1075 :=
  sound (by decide) (by decide) 27 79082437472250233787418226623214063064192996933616261965275255008297020464483218307623396965484611714293125293260320962514653523398454953160220368909307415737487166705558227633285763323988357425 (tail:=0) (by decide +kernel)
private def bp11x1410 : B := ![⟨190,none⟩,⟨9,some 9⟩,⟨22,some 45⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x1410 : Deny 1000000000000000000 11 bp11x1410 :=
  sound (by decide) (by decide) 15 10055134763896517629100562209906345918236022107747251573708068025237720761458995437357616090785227623380135272826077 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x1074 : Deny 1000000000000000000 11 bp11x1074 := by
  apply split bp11x1074 1
  · rw [show leftB bp11x1074 1=bp11x1075 by funext i; fin_cases i <;> rfl]; exact p11x1075
  · rw [show rightB bp11x1074 1=bp11x1410 by funext i; fin_cases i <;> rfl]; exact p11x1410
private def bp11x1613 : B := ![⟨190,none⟩,⟨8,some 9⟩,⟨46,none⟩]
private def bp11x1614 : B := ![⟨190,none⟩,⟨8,some 8⟩,⟨46,none⟩]
private def bp11x1615 : B := ![⟨190,some 381⟩,⟨8,some 8⟩,⟨46,none⟩]
private def bp11x1616 : B := ![⟨190,some 381⟩,⟨8,some 8⟩,⟨46,some 93⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x1616 : Deny 1000000000000000000 11 bp11x1616 :=
  sound (by decide) (by decide) 17 3929909293895106452447572185179583917521616813569803070344788874105954856606685678994558351651121 (tail:=0) (by decide +kernel)
private def bp11x1785 : B := ![⟨190,some 381⟩,⟨8,some 8⟩,⟨94,none⟩]
private def bp11x1786 : B := ![⟨190,some 253⟩,⟨8,some 8⟩,⟨94,none⟩]
private def bp11x1787 : B := ![⟨190,some 253⟩,⟨8,some 8⟩,⟨94,some 189⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x1787 : Deny 1000000000000000000 11 bp11x1787 :=
  sound (by decide) (by decide) 16 11600831060718497212740711590277777209485937363878772610058498353 (tail:=0) (by decide +kernel)
private def bp11x1900 : B := ![⟨190,some 253⟩,⟨8,some 8⟩,⟨190,none⟩]
private def bp11x1901 : B := ![⟨190,some 217⟩,⟨8,some 8⟩,⟨190,none⟩]
private def bp11x1902 : B := ![⟨190,some 217⟩,⟨8,some 8⟩,⟨190,some 381⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x1902 : Deny 1000000000000000000 11 bp11x1902 :=
  sound (by decide) (by decide) 15 4731972828327746564227249990644229733971514962225 (tail:=0) (by decide +kernel)
private def bp11x1989 : B := ![⟨190,some 217⟩,⟨8,some 8⟩,⟨382,none⟩]
private def bp11x1990 : B := ![⟨190,some 202⟩,⟨8,some 8⟩,⟨382,none⟩]
private def bp11x1991 : B := ![⟨190,some 202⟩,⟨8,some 8⟩,⟨382,some 765⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x1991 : Deny 1000000000000000000 11 bp11x1991 :=
  sound (by decide) (by decide) 15 3602889472815409 (tail:=0) (by decide +kernel)
private def bp11x2020 : B := ![⟨190,some 202⟩,⟨8,some 8⟩,⟨766,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x2020 : Deny 1000000000000000000 11 bp11x2020 :=
  sound (by decide) (by decide) 24 347761888013613884580462452651289712797579949742288571638596661846114825799107636973207780126561967879771385559774131800193657334899714516750544686486066078333607716177369999329777842401557967799539408014026282332402509 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x1990 : Deny 1000000000000000000 11 bp11x1990 := by
  apply split bp11x1990 2
  · rw [show leftB bp11x1990 2=bp11x1991 by funext i; fin_cases i <;> rfl]; exact p11x1991
  · rw [show rightB bp11x1990 2=bp11x2020 by funext i; fin_cases i <;> rfl]; exact p11x2020
private def bp11x2393 : B := ![⟨203,some 217⟩,⟨8,some 8⟩,⟨382,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x2393 : Deny 1000000000000000000 11 bp11x2393 :=
  sound (by decide) (by decide) 15 585962026121281524167905463760502811689631179183060527604933278213549245681535315161492961051143526713937015 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x1989 : Deny 1000000000000000000 11 bp11x1989 := by
  apply split bp11x1989 0
  · rw [show leftB bp11x1989 0=bp11x1990 by funext i; fin_cases i <;> rfl]; exact p11x1990
  · rw [show rightB bp11x1989 0=bp11x2393 by funext i; fin_cases i <;> rfl]; exact p11x2393
set_option maxRecDepth 100000 in
private theorem p11x1901 : Deny 1000000000000000000 11 bp11x1901 := by
  apply split bp11x1901 2
  · rw [show leftB bp11x1901 2=bp11x1902 by funext i; fin_cases i <;> rfl]; exact p11x1902
  · rw [show rightB bp11x1901 2=bp11x1989 by funext i; fin_cases i <;> rfl]; exact p11x1989
private def bp11x2584 : B := ![⟨218,some 253⟩,⟨8,some 8⟩,⟨190,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x2584 : Deny 1000000000000000000 11 bp11x2584 :=
  sound (by decide) (by decide) 15 10169642753245737654092468060374388198945652507470111559818166183616781883470749928106603861562839827022151343264486041753745410282382670339185783 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x1900 : Deny 1000000000000000000 11 bp11x1900 := by
  apply split bp11x1900 0
  · rw [show leftB bp11x1900 0=bp11x1901 by funext i; fin_cases i <;> rfl]; exact p11x1901
  · rw [show rightB bp11x1900 0=bp11x2584 by funext i; fin_cases i <;> rfl]; exact p11x2584
set_option maxRecDepth 100000 in
private theorem p11x1786 : Deny 1000000000000000000 11 bp11x1786 := by
  apply split bp11x1786 2
  · rw [show leftB bp11x1786 2=bp11x1787 by funext i; fin_cases i <;> rfl]; exact p11x1787
  · rw [show rightB bp11x1786 2=bp11x1900 by funext i; fin_cases i <;> rfl]; exact p11x1900
private def bp11x2835 : B := ![⟨254,some 381⟩,⟨8,some 8⟩,⟨94,none⟩]
private def bp11x2836 : B := ![⟨254,some 381⟩,⟨8,some 8⟩,⟨94,some 189⟩]
private def bp11x2837 : B := ![⟨254,some 304⟩,⟨8,some 8⟩,⟨94,some 189⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x2837 : Deny 1000000000000000000 11 bp11x2837 :=
  sound (by decide) (by decide) 14 295421859946075000306791633411036608368977694768648884760643196893228572783947435161911489393832191880565404723438516111250949110367362149115476825967944344148080024491086902980672201238119124862841143 (tail:=0) (by decide +kernel)
private def bp11x3180 : B := ![⟨305,some 381⟩,⟨8,some 8⟩,⟨94,some 189⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x3180 : Deny 1000000000000000000 11 bp11x3180 :=
  sound (by decide) (by decide) 13 535842308098824996506529648819155525606254393207 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x2836 : Deny 1000000000000000000 11 bp11x2836 := by
  apply split bp11x2836 0
  · rw [show leftB bp11x2836 0=bp11x2837 by funext i; fin_cases i <;> rfl]; exact p11x2837
  · rw [show rightB bp11x2836 0=bp11x3180 by funext i; fin_cases i <;> rfl]; exact p11x3180
private def bp11x3271 : B := ![⟨254,some 381⟩,⟨8,some 8⟩,⟨190,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x3271 : Deny 1000000000000000000 11 bp11x3271 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x2835 : Deny 1000000000000000000 11 bp11x2835 := by
  apply split bp11x2835 2
  · rw [show leftB bp11x2835 2=bp11x2836 by funext i; fin_cases i <;> rfl]; exact p11x2836
  · rw [show rightB bp11x2835 2=bp11x3271 by funext i; fin_cases i <;> rfl]; exact p11x3271
set_option maxRecDepth 100000 in
private theorem p11x1785 : Deny 1000000000000000000 11 bp11x1785 := by
  apply split bp11x1785 0
  · rw [show leftB bp11x1785 0=bp11x1786 by funext i; fin_cases i <;> rfl]; exact p11x1786
  · rw [show rightB bp11x1785 0=bp11x2835 by funext i; fin_cases i <;> rfl]; exact p11x2835
set_option maxRecDepth 100000 in
private theorem p11x1615 : Deny 1000000000000000000 11 bp11x1615 := by
  apply split bp11x1615 2
  · rw [show leftB bp11x1615 2=bp11x1616 by funext i; fin_cases i <;> rfl]; exact p11x1616
  · rw [show rightB bp11x1615 2=bp11x1785 by funext i; fin_cases i <;> rfl]; exact p11x1785
private def bp11x3272 : B := ![⟨382,none⟩,⟨8,some 8⟩,⟨46,none⟩]
private def bp11x3273 : B := ![⟨382,none⟩,⟨8,some 8⟩,⟨46,some 93⟩]
private def bp11x3274 : B := ![⟨382,some 765⟩,⟨8,some 8⟩,⟨46,some 93⟩]
private def bp11x3275 : B := ![⟨382,some 765⟩,⟨8,some 8⟩,⟨46,some 61⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x3275 : Deny 1000000000000000000 11 bp11x3275 :=
  sound (by decide) (by decide) 15 52840632880340824744094908798652058461360402316007500723276440996873857263311831329099876688559332651853520638331981 (tail:=0) (by decide +kernel)
private def bp11x3478 : B := ![⟨382,some 765⟩,⟨8,some 8⟩,⟨62,some 93⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x3478 : Deny 1000000000000000000 11 bp11x3478 :=
  sound (by decide) (by decide) 15 73140776920034053385304583223436848646812547451386038260732019937225794537295969850958285757859448076021898281459987677 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x3274 : Deny 1000000000000000000 11 bp11x3274 := by
  apply split bp11x3274 2
  · rw [show leftB bp11x3274 2=bp11x3275 by funext i; fin_cases i <;> rfl]; exact p11x3275
  · rw [show rightB bp11x3274 2=bp11x3478 by funext i; fin_cases i <;> rfl]; exact p11x3478
private def bp11x3687 : B := ![⟨766,none⟩,⟨8,some 8⟩,⟨46,some 93⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x3687 : Deny 1000000000000000000 11 bp11x3687 :=
  sound (by decide) (by decide) 17 8061492166666165955537016458051511080823510742256501222852471 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x3273 : Deny 1000000000000000000 11 bp11x3273 := by
  apply split bp11x3273 0
  · rw [show leftB bp11x3273 0=bp11x3274 by funext i; fin_cases i <;> rfl]; exact p11x3274
  · rw [show rightB bp11x3273 0=bp11x3687 by funext i; fin_cases i <;> rfl]; exact p11x3687
private def bp11x3800 : B := ![⟨382,none⟩,⟨8,some 8⟩,⟨94,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x3800 : Deny 1000000000000000000 11 bp11x3800 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x3272 : Deny 1000000000000000000 11 bp11x3272 := by
  apply split bp11x3272 2
  · rw [show leftB bp11x3272 2=bp11x3273 by funext i; fin_cases i <;> rfl]; exact p11x3273
  · rw [show rightB bp11x3272 2=bp11x3800 by funext i; fin_cases i <;> rfl]; exact p11x3800
set_option maxRecDepth 100000 in
private theorem p11x1614 : Deny 1000000000000000000 11 bp11x1614 := by
  apply split bp11x1614 0
  · rw [show leftB bp11x1614 0=bp11x1615 by funext i; fin_cases i <;> rfl]; exact p11x1615
  · rw [show rightB bp11x1614 0=bp11x3272 by funext i; fin_cases i <;> rfl]; exact p11x3272
private def bp11x3801 : B := ![⟨190,none⟩,⟨9,some 9⟩,⟨46,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x3801 : Deny 1000000000000000000 11 bp11x3801 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x1613 : Deny 1000000000000000000 11 bp11x1613 := by
  apply split bp11x1613 1
  · rw [show leftB bp11x1613 1=bp11x1614 by funext i; fin_cases i <;> rfl]; exact p11x1614
  · rw [show rightB bp11x1613 1=bp11x3801 by funext i; fin_cases i <;> rfl]; exact p11x3801
set_option maxRecDepth 100000 in
private theorem p11x1073 : Deny 1000000000000000000 11 bp11x1073 := by
  apply split bp11x1073 2
  · rw [show leftB bp11x1073 2=bp11x1074 by funext i; fin_cases i <;> rfl]; exact p11x1074
  · rw [show rightB bp11x1073 2=bp11x1613 by funext i; fin_cases i <;> rfl]; exact p11x1613
set_option maxRecDepth 100000 in
private theorem p11x409 : Deny 1000000000000000000 11 bp11x409 := by
  apply split bp11x409 0
  · rw [show leftB bp11x409 0=bp11x410 by funext i; fin_cases i <;> rfl]; exact p11x410
  · rw [show rightB bp11x409 0=bp11x1073 by funext i; fin_cases i <;> rfl]; exact p11x1073
set_option maxRecDepth 100000 in
private theorem p11x255 : Deny 1000000000000000000 11 bp11x255 := by
  apply split bp11x255 2
  · rw [show leftB bp11x255 2=bp11x256 by funext i; fin_cases i <;> rfl]; exact p11x256
  · rw [show rightB bp11x255 2=bp11x409 by funext i; fin_cases i <;> rfl]; exact p11x409
set_option maxRecDepth 100000 in
private theorem p11x19 : Deny 1000000000000000000 11 bp11x19 := by
  apply split bp11x19 0
  · rw [show leftB bp11x19 0=bp11x20 by funext i; fin_cases i <;> rfl]; exact p11x20
  · rw [show rightB bp11x19 0=bp11x255 by funext i; fin_cases i <;> rfl]; exact p11x255
set_option maxRecDepth 100000 in
private theorem p11x17 : Deny 1000000000000000000 11 bp11x17 := by
  apply split bp11x17 1
  · rw [show leftB bp11x17 1=bp11x18 by funext i; fin_cases i <;> rfl]; exact p11x18
  · rw [show rightB bp11x17 1=bp11x19 by funext i; fin_cases i <;> rfl]; exact p11x19
set_option maxRecDepth 100000 in
private theorem p11x15 : Deny 1000000000000000000 11 bp11x15 := by
  apply split bp11x15 2
  · rw [show leftB bp11x15 2=bp11x16 by funext i; fin_cases i <;> rfl]; exact p11x16
  · rw [show rightB bp11x15 2=bp11x17 by funext i; fin_cases i <;> rfl]; exact p11x17
set_option maxRecDepth 100000 in
private theorem p11x13 : Deny 1000000000000000000 11 bp11x13 := by
  apply split bp11x13 0
  · rw [show leftB bp11x13 0=bp11x14 by funext i; fin_cases i <;> rfl]; exact p11x14
  · rw [show rightB bp11x13 0=bp11x15 by funext i; fin_cases i <;> rfl]; exact p11x15
set_option maxRecDepth 100000 in
private theorem p11x11 : Deny 1000000000000000000 11 bp11x11 := by
  apply split bp11x11 1
  · rw [show leftB bp11x11 1=bp11x12 by funext i; fin_cases i <;> rfl]; exact p11x12
  · rw [show rightB bp11x11 1=bp11x13 by funext i; fin_cases i <;> rfl]; exact p11x13
set_option maxRecDepth 100000 in
private theorem p11x9 : Deny 1000000000000000000 11 bp11x9 := by
  apply split bp11x9 0
  · rw [show leftB bp11x9 0=bp11x10 by funext i; fin_cases i <;> rfl]; exact p11x10
  · rw [show rightB bp11x9 0=bp11x11 by funext i; fin_cases i <;> rfl]; exact p11x11
set_option maxRecDepth 100000 in
private theorem p11x7 : Deny 1000000000000000000 11 bp11x7 := by
  apply split bp11x7 2
  · rw [show leftB bp11x7 2=bp11x8 by funext i; fin_cases i <;> rfl]; exact p11x8
  · rw [show rightB bp11x7 2=bp11x9 by funext i; fin_cases i <;> rfl]; exact p11x9
private def bp11x3802 : B := ![⟨10,none⟩,⟨10,none⟩,⟨1,none⟩]
private def bp11x3803 : B := ![⟨10,none⟩,⟨10,none⟩,⟨1,some 3⟩]
private def bp11x3804 : B := ![⟨10,some 21⟩,⟨10,none⟩,⟨1,some 3⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x3804 : Deny 1000000000000000000 11 bp11x3804 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x3805 : B := ![⟨22,none⟩,⟨10,none⟩,⟨1,some 3⟩]
private def bp11x3806 : B := ![⟨22,none⟩,⟨10,none⟩,⟨1,some 1⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x3806 : Deny 1000000000000000000 11 bp11x3806 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x3807 : B := ![⟨22,none⟩,⟨10,none⟩,⟨2,some 3⟩]
private def bp11x3808 : B := ![⟨22,none⟩,⟨10,some 21⟩,⟨2,some 3⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x3808 : Deny 1000000000000000000 11 bp11x3808 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x3809 : B := ![⟨22,none⟩,⟨22,none⟩,⟨2,some 3⟩]
private def bp11x3810 : B := ![⟨22,some 45⟩,⟨22,none⟩,⟨2,some 3⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x3810 : Deny 1000000000000000000 11 bp11x3810 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x3811 : B := ![⟨46,none⟩,⟨22,none⟩,⟨2,some 3⟩]
private def bp11x3812 : B := ![⟨46,none⟩,⟨22,some 45⟩,⟨2,some 3⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x3812 : Deny 1000000000000000000 11 bp11x3812 :=
  sound (by decide) (by decide) 36 4957083405007185429246059275134652084707335269072407032165729510046558551398887082428580104001810436965092141373880888978124617934891381898053699743008150505006889570865 (tail:=0) (by decide +kernel)
private def bp11x4105 : B := ![⟨46,none⟩,⟨46,none⟩,⟨2,some 3⟩]
private def bp11x4106 : B := ![⟨46,some 93⟩,⟨46,none⟩,⟨2,some 3⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x4106 : Deny 1000000000000000000 11 bp11x4106 :=
  sound (by decide) (by decide) 34 138635488012695123965827078683038636078221499044925088392418374327362742977305674394503415745729545888437371527409559379471815117457265717852134929357932130601790027914764057635320832291 (tail:=0) (by decide +kernel)
private def bp11x4423 : B := ![⟨94,none⟩,⟨46,none⟩,⟨2,some 3⟩]
private def bp11x4424 : B := ![⟨94,none⟩,⟨46,none⟩,⟨2,some 2⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x4424 : Deny 1000000000000000000 11 bp11x4424 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x4425 : B := ![⟨94,none⟩,⟨46,none⟩,⟨3,some 3⟩]
private def bp11x4426 : B := ![⟨94,none⟩,⟨46,some 93⟩,⟨3,some 3⟩]
private def bp11x4427 : B := ![⟨94,some 189⟩,⟨46,some 93⟩,⟨3,some 3⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x4427 : Deny 1000000000000000000 11 bp11x4427 :=
  sound (by decide) (by decide) 16 22683904597651311561311584560455516134904338 (tail:=0) (by decide +kernel)
private def bp11x4504 : B := ![⟨190,none⟩,⟨46,some 93⟩,⟨3,some 3⟩]
private def bp11x4505 : B := ![⟨190,none⟩,⟨46,some 61⟩,⟨3,some 3⟩]
private def bp11x4506 : B := ![⟨190,some 381⟩,⟨46,some 61⟩,⟨3,some 3⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x4506 : Deny 1000000000000000000 11 bp11x4506 :=
  sound (by decide) (by decide) 15 80604345567243707425057 (tail:=0) (by decide +kernel)
private def bp11x4549 : B := ![⟨382,none⟩,⟨46,some 61⟩,⟨3,some 3⟩]
private def bp11x4550 : B := ![⟨382,some 765⟩,⟨46,some 61⟩,⟨3,some 3⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x4550 : Deny 1000000000000000000 11 bp11x4550 :=
  sound (by decide) (by decide) 14 8508835293029732603242130922662991734367900804674103422343794206234516602425270661412311827590 (tail:=0) (by decide +kernel)
private def bp11x4713 : B := ![⟨766,none⟩,⟨46,some 61⟩,⟨3,some 3⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x4713 : Deny 1000000000000000000 11 bp11x4713 :=
  sound (by decide) (by decide) 19 46718822049882655579393731929318470249205808304171956433402577698086781478657449168828135442703749292038425311160541705167980646 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x4549 : Deny 1000000000000000000 11 bp11x4549 := by
  apply split bp11x4549 0
  · rw [show leftB bp11x4549 0=bp11x4550 by funext i; fin_cases i <;> rfl]; exact p11x4550
  · rw [show rightB bp11x4549 0=bp11x4713 by funext i; fin_cases i <;> rfl]; exact p11x4713
set_option maxRecDepth 100000 in
private theorem p11x4505 : Deny 1000000000000000000 11 bp11x4505 := by
  apply split bp11x4505 0
  · rw [show leftB bp11x4505 0=bp11x4506 by funext i; fin_cases i <;> rfl]; exact p11x4506
  · rw [show rightB bp11x4505 0=bp11x4549 by funext i; fin_cases i <;> rfl]; exact p11x4549
private def bp11x4934 : B := ![⟨190,none⟩,⟨62,some 93⟩,⟨3,some 3⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x4934 : Deny 1000000000000000000 11 bp11x4934 :=
  sound (by decide) (by decide) 15 16801932314388466246827372050882383450440642298986552726271343737070318532068379143159958172836239264335571762318195016795361330770557533334392551214838248295755475535284325 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x4504 : Deny 1000000000000000000 11 bp11x4504 := by
  apply split bp11x4504 1
  · rw [show leftB bp11x4504 1=bp11x4505 by funext i; fin_cases i <;> rfl]; exact p11x4505
  · rw [show rightB bp11x4504 1=bp11x4934 by funext i; fin_cases i <;> rfl]; exact p11x4934
set_option maxRecDepth 100000 in
private theorem p11x4426 : Deny 1000000000000000000 11 bp11x4426 := by
  apply split bp11x4426 0
  · rw [show leftB bp11x4426 0=bp11x4427 by funext i; fin_cases i <;> rfl]; exact p11x4427
  · rw [show rightB bp11x4426 0=bp11x4504 by funext i; fin_cases i <;> rfl]; exact p11x4504
private def bp11x5231 : B := ![⟨94,none⟩,⟨94,none⟩,⟨3,some 3⟩]
private def bp11x5232 : B := ![⟨94,some 189⟩,⟨94,none⟩,⟨3,some 3⟩]
private def bp11x5233 : B := ![⟨94,some 189⟩,⟨94,some 189⟩,⟨3,some 3⟩]
private def bp11x5234 : B := ![⟨94,some 125⟩,⟨94,some 189⟩,⟨3,some 3⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x5234 : Deny 1000000000000000000 11 bp11x5234 :=
  sound (by decide) (by decide) 15 54249486449421387640856335336536325637546578450 (tail:=0) (by decide +kernel)
private def bp11x5317 : B := ![⟨126,some 189⟩,⟨94,some 189⟩,⟨3,some 3⟩]
private def bp11x5318 : B := ![⟨126,some 189⟩,⟨94,some 125⟩,⟨3,some 3⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x5318 : Deny 1000000000000000000 11 bp11x5318 :=
  sound (by decide) (by decide) 13 52259369276950654200116385486784145797496728061634955330209636717038168288405140504230913589836643089740145789620943963061653861439621 (tail:=0) (by decide +kernel)
private def bp11x5549 : B := ![⟨126,some 189⟩,⟨126,some 189⟩,⟨3,some 3⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x5549 : Deny 1000000000000000000 11 bp11x5549 :=
  sound (by decide) (by decide) 13 21895206596732403426009998727090493815331359240465597205849670848761433033602121988583459085427097 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x5317 : Deny 1000000000000000000 11 bp11x5317 := by
  apply split bp11x5317 1
  · rw [show leftB bp11x5317 1=bp11x5318 by funext i; fin_cases i <;> rfl]; exact p11x5318
  · rw [show rightB bp11x5317 1=bp11x5549 by funext i; fin_cases i <;> rfl]; exact p11x5549
set_option maxRecDepth 100000 in
private theorem p11x5233 : Deny 1000000000000000000 11 bp11x5233 := by
  apply split bp11x5233 0
  · rw [show leftB bp11x5233 0=bp11x5234 by funext i; fin_cases i <;> rfl]; exact p11x5234
  · rw [show rightB bp11x5233 0=bp11x5317 by funext i; fin_cases i <;> rfl]; exact p11x5317
private def bp11x5720 : B := ![⟨94,some 189⟩,⟨190,none⟩,⟨3,some 3⟩]
private def bp11x5721 : B := ![⟨94,some 125⟩,⟨190,none⟩,⟨3,some 3⟩]
private def bp11x5722 : B := ![⟨94,some 125⟩,⟨190,some 381⟩,⟨3,some 3⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x5722 : Deny 1000000000000000000 11 bp11x5722 :=
  sound (by decide) (by decide) 15 1965655855532773724890842721144759019030479481166699748751261397515576711964587142475492293699850467860876927288234733285417577501243349065 (tail:=0) (by decide +kernel)
private def bp11x5961 : B := ![⟨94,some 125⟩,⟨382,none⟩,⟨3,some 3⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x5961 : Deny 1000000000000000000 11 bp11x5961 :=
  sound (by decide) (by decide) 18 1631603016662170503656403377085179728684306693802328173345401481270370876183210470122588468357888470549873306406919055623309262151628606752872800665 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x5721 : Deny 1000000000000000000 11 bp11x5721 := by
  apply split bp11x5721 1
  · rw [show leftB bp11x5721 1=bp11x5722 by funext i; fin_cases i <;> rfl]; exact p11x5722
  · rw [show rightB bp11x5721 1=bp11x5961 by funext i; fin_cases i <;> rfl]; exact p11x5961
private def bp11x6218 : B := ![⟨126,some 189⟩,⟨190,none⟩,⟨3,some 3⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6218 : Deny 1000000000000000000 11 bp11x6218 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x5720 : Deny 1000000000000000000 11 bp11x5720 := by
  apply split bp11x5720 0
  · rw [show leftB bp11x5720 0=bp11x5721 by funext i; fin_cases i <;> rfl]; exact p11x5721
  · rw [show rightB bp11x5720 0=bp11x6218 by funext i; fin_cases i <;> rfl]; exact p11x6218
set_option maxRecDepth 100000 in
private theorem p11x5232 : Deny 1000000000000000000 11 bp11x5232 := by
  apply split bp11x5232 1
  · rw [show leftB bp11x5232 1=bp11x5233 by funext i; fin_cases i <;> rfl]; exact p11x5233
  · rw [show rightB bp11x5232 1=bp11x5720 by funext i; fin_cases i <;> rfl]; exact p11x5720
private def bp11x6219 : B := ![⟨190,none⟩,⟨94,none⟩,⟨3,some 3⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6219 : Deny 1000000000000000000 11 bp11x6219 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x5231 : Deny 1000000000000000000 11 bp11x5231 := by
  apply split bp11x5231 0
  · rw [show leftB bp11x5231 0=bp11x5232 by funext i; fin_cases i <;> rfl]; exact p11x5232
  · rw [show rightB bp11x5231 0=bp11x6219 by funext i; fin_cases i <;> rfl]; exact p11x6219
set_option maxRecDepth 100000 in
private theorem p11x4425 : Deny 1000000000000000000 11 bp11x4425 := by
  apply split bp11x4425 1
  · rw [show leftB bp11x4425 1=bp11x4426 by funext i; fin_cases i <;> rfl]; exact p11x4426
  · rw [show rightB bp11x4425 1=bp11x5231 by funext i; fin_cases i <;> rfl]; exact p11x5231
set_option maxRecDepth 100000 in
private theorem p11x4423 : Deny 1000000000000000000 11 bp11x4423 := by
  apply split bp11x4423 2
  · rw [show leftB bp11x4423 2=bp11x4424 by funext i; fin_cases i <;> rfl]; exact p11x4424
  · rw [show rightB bp11x4423 2=bp11x4425 by funext i; fin_cases i <;> rfl]; exact p11x4425
set_option maxRecDepth 100000 in
private theorem p11x4105 : Deny 1000000000000000000 11 bp11x4105 := by
  apply split bp11x4105 0
  · rw [show leftB bp11x4105 0=bp11x4106 by funext i; fin_cases i <;> rfl]; exact p11x4106
  · rw [show rightB bp11x4105 0=bp11x4423 by funext i; fin_cases i <;> rfl]; exact p11x4423
set_option maxRecDepth 100000 in
private theorem p11x3811 : Deny 1000000000000000000 11 bp11x3811 := by
  apply split bp11x3811 1
  · rw [show leftB bp11x3811 1=bp11x3812 by funext i; fin_cases i <;> rfl]; exact p11x3812
  · rw [show rightB bp11x3811 1=bp11x4105 by funext i; fin_cases i <;> rfl]; exact p11x4105
set_option maxRecDepth 100000 in
private theorem p11x3809 : Deny 1000000000000000000 11 bp11x3809 := by
  apply split bp11x3809 0
  · rw [show leftB bp11x3809 0=bp11x3810 by funext i; fin_cases i <;> rfl]; exact p11x3810
  · rw [show rightB bp11x3809 0=bp11x3811 by funext i; fin_cases i <;> rfl]; exact p11x3811
set_option maxRecDepth 100000 in
private theorem p11x3807 : Deny 1000000000000000000 11 bp11x3807 := by
  apply split bp11x3807 1
  · rw [show leftB bp11x3807 1=bp11x3808 by funext i; fin_cases i <;> rfl]; exact p11x3808
  · rw [show rightB bp11x3807 1=bp11x3809 by funext i; fin_cases i <;> rfl]; exact p11x3809
set_option maxRecDepth 100000 in
private theorem p11x3805 : Deny 1000000000000000000 11 bp11x3805 := by
  apply split bp11x3805 2
  · rw [show leftB bp11x3805 2=bp11x3806 by funext i; fin_cases i <;> rfl]; exact p11x3806
  · rw [show rightB bp11x3805 2=bp11x3807 by funext i; fin_cases i <;> rfl]; exact p11x3807
set_option maxRecDepth 100000 in
private theorem p11x3803 : Deny 1000000000000000000 11 bp11x3803 := by
  apply split bp11x3803 0
  · rw [show leftB bp11x3803 0=bp11x3804 by funext i; fin_cases i <;> rfl]; exact p11x3804
  · rw [show rightB bp11x3803 0=bp11x3805 by funext i; fin_cases i <;> rfl]; exact p11x3805
private def bp11x6220 : B := ![⟨10,none⟩,⟨10,none⟩,⟨4,none⟩]
private def bp11x6221 : B := ![⟨10,some 21⟩,⟨10,none⟩,⟨4,none⟩]
private def bp11x6222 : B := ![⟨10,some 13⟩,⟨10,none⟩,⟨4,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6222 : Deny 1000000000000000000 11 bp11x6222 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x6223 : B := ![⟨14,some 21⟩,⟨10,none⟩,⟨4,none⟩]
private def bp11x6224 : B := ![⟨14,some 21⟩,⟨10,some 21⟩,⟨4,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6224 : Deny 1000000000000000000 11 bp11x6224 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x6225 : B := ![⟨14,some 21⟩,⟨22,none⟩,⟨4,none⟩]
private def bp11x6226 : B := ![⟨14,some 21⟩,⟨22,none⟩,⟨4,some 9⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6226 : Deny 1000000000000000000 11 bp11x6226 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x6227 : B := ![⟨14,some 21⟩,⟨22,none⟩,⟨10,none⟩]
private def bp11x6228 : B := ![⟨14,some 21⟩,⟨22,some 45⟩,⟨10,none⟩]
private def bp11x6229 : B := ![⟨14,some 16⟩,⟨22,some 45⟩,⟨10,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6229 : Deny 1000000000000000000 11 bp11x6229 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x6230 : B := ![⟨17,some 21⟩,⟨22,some 45⟩,⟨10,none⟩]
private def bp11x6231 : B := ![⟨17,some 21⟩,⟨22,some 45⟩,⟨10,some 21⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6231 : Deny 1000000000000000000 11 bp11x6231 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x6232 : B := ![⟨17,some 21⟩,⟨22,some 45⟩,⟨22,none⟩]
private def bp11x6233 : B := ![⟨17,some 21⟩,⟨22,some 29⟩,⟨22,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6233 : Deny 1000000000000000000 11 bp11x6233 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x6234 : B := ![⟨17,some 21⟩,⟨30,some 45⟩,⟨22,none⟩]
private def bp11x6235 : B := ![⟨17,some 18⟩,⟨30,some 45⟩,⟨22,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6235 : Deny 1000000000000000000 11 bp11x6235 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x6236 : B := ![⟨19,some 21⟩,⟨30,some 45⟩,⟨22,none⟩]
private def bp11x6237 : B := ![⟨19,some 21⟩,⟨30,some 45⟩,⟨22,some 45⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6237 : Deny 1000000000000000000 11 bp11x6237 :=
  sound (by decide) (by decide) 14 57997804688188178 (tail:=0) (by decide +kernel)
private def bp11x6268 : B := ![⟨19,some 21⟩,⟨30,some 45⟩,⟨46,none⟩]
private def bp11x6269 : B := ![⟨19,some 21⟩,⟨30,some 36⟩,⟨46,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6269 : Deny 1000000000000000000 11 bp11x6269 :=
  sound (by decide) (by decide) 19 329341965465367740206442570876264259973972020557303322004735537 (tail:=0) (by decide +kernel)
private def bp11x6380 : B := ![⟨19,some 21⟩,⟨37,some 45⟩,⟨46,none⟩]
private def bp11x6381 : B := ![⟨19,some 19⟩,⟨37,some 45⟩,⟨46,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6381 : Deny 1000000000000000000 11 bp11x6381 :=
  sound (by decide) (by decide) 29 2154778733949626481558389342893172558441465929975808445179758641823609499976428648739535351979324195 (tail:=0) (by decide +kernel)
private def bp11x6554 : B := ![⟨20,some 21⟩,⟨37,some 45⟩,⟨46,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6554 : Deny 1000000000000000000 11 bp11x6554 :=
  sound (by decide) (by decide) 21 798079163313260433228081276080311121623945336110704679373816060316135724508558480819040910599069446742093744791910421804940977599156821822285873475784475 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x6380 : Deny 1000000000000000000 11 bp11x6380 := by
  apply split bp11x6380 0
  · rw [show leftB bp11x6380 0=bp11x6381 by funext i; fin_cases i <;> rfl]; exact p11x6381
  · rw [show rightB bp11x6380 0=bp11x6554 by funext i; fin_cases i <;> rfl]; exact p11x6554
set_option maxRecDepth 100000 in
private theorem p11x6268 : Deny 1000000000000000000 11 bp11x6268 := by
  apply split bp11x6268 1
  · rw [show leftB bp11x6268 1=bp11x6269 by funext i; fin_cases i <;> rfl]; exact p11x6269
  · rw [show rightB bp11x6268 1=bp11x6380 by funext i; fin_cases i <;> rfl]; exact p11x6380
set_option maxRecDepth 100000 in
private theorem p11x6236 : Deny 1000000000000000000 11 bp11x6236 := by
  apply split bp11x6236 2
  · rw [show leftB bp11x6236 2=bp11x6237 by funext i; fin_cases i <;> rfl]; exact p11x6237
  · rw [show rightB bp11x6236 2=bp11x6268 by funext i; fin_cases i <;> rfl]; exact p11x6268
set_option maxRecDepth 100000 in
private theorem p11x6234 : Deny 1000000000000000000 11 bp11x6234 := by
  apply split bp11x6234 0
  · rw [show leftB bp11x6234 0=bp11x6235 by funext i; fin_cases i <;> rfl]; exact p11x6235
  · rw [show rightB bp11x6234 0=bp11x6236 by funext i; fin_cases i <;> rfl]; exact p11x6236
set_option maxRecDepth 100000 in
private theorem p11x6232 : Deny 1000000000000000000 11 bp11x6232 := by
  apply split bp11x6232 1
  · rw [show leftB bp11x6232 1=bp11x6233 by funext i; fin_cases i <;> rfl]; exact p11x6233
  · rw [show rightB bp11x6232 1=bp11x6234 by funext i; fin_cases i <;> rfl]; exact p11x6234
set_option maxRecDepth 100000 in
private theorem p11x6230 : Deny 1000000000000000000 11 bp11x6230 := by
  apply split bp11x6230 2
  · rw [show leftB bp11x6230 2=bp11x6231 by funext i; fin_cases i <;> rfl]; exact p11x6231
  · rw [show rightB bp11x6230 2=bp11x6232 by funext i; fin_cases i <;> rfl]; exact p11x6232
set_option maxRecDepth 100000 in
private theorem p11x6228 : Deny 1000000000000000000 11 bp11x6228 := by
  apply split bp11x6228 0
  · rw [show leftB bp11x6228 0=bp11x6229 by funext i; fin_cases i <;> rfl]; exact p11x6229
  · rw [show rightB bp11x6228 0=bp11x6230 by funext i; fin_cases i <;> rfl]; exact p11x6230
private def bp11x6817 : B := ![⟨14,some 21⟩,⟨46,none⟩,⟨10,none⟩]
private def bp11x6818 : B := ![⟨14,some 16⟩,⟨46,none⟩,⟨10,none⟩]
private def bp11x6819 : B := ![⟨14,some 16⟩,⟨46,none⟩,⟨10,some 21⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6819 : Deny 1000000000000000000 11 bp11x6819 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x6820 : B := ![⟨14,some 16⟩,⟨46,none⟩,⟨22,none⟩]
private def bp11x6821 : B := ![⟨14,some 16⟩,⟨46,some 93⟩,⟨22,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6821 : Deny 1000000000000000000 11 bp11x6821 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x6822 : B := ![⟨14,some 16⟩,⟨94,none⟩,⟨22,none⟩]
private def bp11x6823 : B := ![⟨14,some 16⟩,⟨94,none⟩,⟨22,some 45⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6823 : Deny 1000000000000000000 11 bp11x6823 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x6824 : B := ![⟨14,some 16⟩,⟨94,none⟩,⟨46,none⟩]
private def bp11x6825 : B := ![⟨14,some 14⟩,⟨94,none⟩,⟨46,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6825 : Deny 1000000000000000000 11 bp11x6825 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x6826 : B := ![⟨15,some 16⟩,⟨94,none⟩,⟨46,none⟩]
private def bp11x6827 : B := ![⟨15,some 16⟩,⟨94,some 189⟩,⟨46,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6827 : Deny 1000000000000000000 11 bp11x6827 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x6828 : B := ![⟨15,some 16⟩,⟨190,none⟩,⟨46,none⟩]
private def bp11x6829 : B := ![⟨15,some 16⟩,⟨190,none⟩,⟨46,some 93⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6829 : Deny 1000000000000000000 11 bp11x6829 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x6830 : B := ![⟨15,some 16⟩,⟨190,none⟩,⟨94,none⟩]
private def bp11x6831 : B := ![⟨15,some 15⟩,⟨190,none⟩,⟨94,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6831 : Deny 1000000000000000000 11 bp11x6831 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x6832 : B := ![⟨16,some 16⟩,⟨190,none⟩,⟨94,none⟩]
private def bp11x6833 : B := ![⟨16,some 16⟩,⟨190,some 381⟩,⟨94,none⟩]
private def bp11x6834 : B := ![⟨16,some 16⟩,⟨190,some 381⟩,⟨94,some 189⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6834 : Deny 1000000000000000000 11 bp11x6834 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x6835 : B := ![⟨16,some 16⟩,⟨190,some 381⟩,⟨190,none⟩]
private def bp11x6836 : B := ![⟨16,some 16⟩,⟨190,some 253⟩,⟨190,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6836 : Deny 1000000000000000000 11 bp11x6836 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x6837 : B := ![⟨16,some 16⟩,⟨254,some 381⟩,⟨190,none⟩]
private def bp11x6838 : B := ![⟨16,some 16⟩,⟨254,some 381⟩,⟨190,some 381⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6838 : Deny 1000000000000000000 11 bp11x6838 :=
  sound (by decide) (by decide) 18 973412530210902291657266 (tail:=0) (by decide +kernel)
private def bp11x6881 : B := ![⟨16,some 16⟩,⟨254,some 381⟩,⟨382,none⟩]
private def bp11x6882 : B := ![⟨16,some 16⟩,⟨254,some 304⟩,⟨382,none⟩]
private def bp11x6883 : B := ![⟨16,some 16⟩,⟨254,some 304⟩,⟨382,some 765⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6883 : Deny 1000000000000000000 11 bp11x6883 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x6884 : B := ![⟨16,some 16⟩,⟨254,some 304⟩,⟨766,none⟩]
private def bp11x6885 : B := ![⟨16,some 16⟩,⟨254,some 276⟩,⟨766,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x6885 : Deny 1000000000000000000 11 bp11x6885 :=
  sound (by decide) (by decide) 27 866672730314442967711402656483581029001210096983802534391936092130317432522730330321597996057317424303016028269914483515758495803961367778314155250526723551942353699 (tail:=0) (by decide +kernel)
private def bp11x7166 : B := ![⟨16,some 16⟩,⟨277,some 304⟩,⟨766,none⟩]
private def bp11x7167 : B := ![⟨16,some 16⟩,⟨277,some 304⟩,⟨766,some 1533⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x7167 : Deny 1000000000000000000 11 bp11x7167 :=
  sound (by decide) (by decide) 17 9085507690941673478415403525201403264109829091501832771349733226440014844672682560536442958132341066778720538758539378580729107352754 (tail:=0) (by decide +kernel)
private def bp11x7396 : B := ![⟨16,some 16⟩,⟨277,some 304⟩,⟨1534,none⟩]
private def bp11x7397 : B := ![⟨16,some 16⟩,⟨277,some 289⟩,⟨1534,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x7397 : Deny 1000000000000000000 11 bp11x7397 :=
  sound (by decide) (by decide) 19 5366387757516594975331099915419691385594323561303551051992257316995906527274348583914694933004071480021577050816156599896498659673562082622988132594835807118080227733801358499999977674294155679879314056212698571579 (tail:=0) (by decide +kernel)
private def bp11x7764 : B := ![⟨16,some 16⟩,⟨290,some 304⟩,⟨1534,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x7764 : Deny 1000000000000000000 11 bp11x7764 :=
  sound (by decide) (by decide) 16 1251808232105483043382730895291 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x7396 : Deny 1000000000000000000 11 bp11x7396 := by
  apply split bp11x7396 1
  · rw [show leftB bp11x7396 1=bp11x7397 by funext i; fin_cases i <;> rfl]; exact p11x7397
  · rw [show rightB bp11x7396 1=bp11x7764 by funext i; fin_cases i <;> rfl]; exact p11x7764
set_option maxRecDepth 100000 in
private theorem p11x7166 : Deny 1000000000000000000 11 bp11x7166 := by
  apply split bp11x7166 2
  · rw [show leftB bp11x7166 2=bp11x7167 by funext i; fin_cases i <;> rfl]; exact p11x7167
  · rw [show rightB bp11x7166 2=bp11x7396 by funext i; fin_cases i <;> rfl]; exact p11x7396
set_option maxRecDepth 100000 in
private theorem p11x6884 : Deny 1000000000000000000 11 bp11x6884 := by
  apply split bp11x6884 1
  · rw [show leftB bp11x6884 1=bp11x6885 by funext i; fin_cases i <;> rfl]; exact p11x6885
  · rw [show rightB bp11x6884 1=bp11x7166 by funext i; fin_cases i <;> rfl]; exact p11x7166
set_option maxRecDepth 100000 in
private theorem p11x6882 : Deny 1000000000000000000 11 bp11x6882 := by
  apply split bp11x6882 2
  · rw [show leftB bp11x6882 2=bp11x6883 by funext i; fin_cases i <;> rfl]; exact p11x6883
  · rw [show rightB bp11x6882 2=bp11x6884 by funext i; fin_cases i <;> rfl]; exact p11x6884
private def bp11x7825 : B := ![⟨16,some 16⟩,⟨305,some 381⟩,⟨382,none⟩]
private def bp11x7826 : B := ![⟨16,some 16⟩,⟨305,some 381⟩,⟨382,some 765⟩]
private def bp11x7827 : B := ![⟨16,some 16⟩,⟨305,some 338⟩,⟨382,some 765⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x7827 : Deny 1000000000000000000 11 bp11x7827 :=
  sound (by decide) (by decide) 16 12377535383294614188460091052015888204969258727993222916093439085111609048357599815190507182010233857386697144904322669137209211805063740562103217620685817658762766349551843 (tail:=0) (by decide +kernel)
private def bp11x8122 : B := ![⟨16,some 16⟩,⟨339,some 381⟩,⟨382,some 765⟩]
private def bp11x8123 : B := ![⟨16,some 16⟩,⟨339,some 381⟩,⟨382,some 509⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x8123 : Deny 1000000000000000000 11 bp11x8123 :=
  sound (by decide) (by decide) 15 335005220031050766094196717281152408832948828656799644652367108324880530678130458629777064168775795206222010477068695817496631471314004688150553331798266919455156488869207480153722392624644860029538132242683077518 (tail:=0) (by decide +kernel)
private def bp11x8486 : B := ![⟨16,some 16⟩,⟨339,some 381⟩,⟨510,some 765⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x8486 : Deny 1000000000000000000 11 bp11x8486 :=
  sound (by decide) (by decide) 13 300038801186739962119401198 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x8122 : Deny 1000000000000000000 11 bp11x8122 := by
  apply split bp11x8122 2
  · rw [show leftB bp11x8122 2=bp11x8123 by funext i; fin_cases i <;> rfl]; exact p11x8123
  · rw [show rightB bp11x8122 2=bp11x8486 by funext i; fin_cases i <;> rfl]; exact p11x8486
set_option maxRecDepth 100000 in
private theorem p11x7826 : Deny 1000000000000000000 11 bp11x7826 := by
  apply split bp11x7826 1
  · rw [show leftB bp11x7826 1=bp11x7827 by funext i; fin_cases i <;> rfl]; exact p11x7827
  · rw [show rightB bp11x7826 1=bp11x8122 by funext i; fin_cases i <;> rfl]; exact p11x8122
private def bp11x8541 : B := ![⟨16,some 16⟩,⟨305,some 381⟩,⟨766,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x8541 : Deny 1000000000000000000 11 bp11x8541 :=
  sound (by decide) (by decide) 18 38316490722119787009443202930780944929573965153732757653164275033244850802719863501849683012222775372420582944494 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x7825 : Deny 1000000000000000000 11 bp11x7825 := by
  apply split bp11x7825 2
  · rw [show leftB bp11x7825 2=bp11x7826 by funext i; fin_cases i <;> rfl]; exact p11x7826
  · rw [show rightB bp11x7825 2=bp11x8541 by funext i; fin_cases i <;> rfl]; exact p11x8541
set_option maxRecDepth 100000 in
private theorem p11x6881 : Deny 1000000000000000000 11 bp11x6881 := by
  apply split bp11x6881 1
  · rw [show leftB bp11x6881 1=bp11x6882 by funext i; fin_cases i <;> rfl]; exact p11x6882
  · rw [show rightB bp11x6881 1=bp11x7825 by funext i; fin_cases i <;> rfl]; exact p11x7825
set_option maxRecDepth 100000 in
private theorem p11x6837 : Deny 1000000000000000000 11 bp11x6837 := by
  apply split bp11x6837 2
  · rw [show leftB bp11x6837 2=bp11x6838 by funext i; fin_cases i <;> rfl]; exact p11x6838
  · rw [show rightB bp11x6837 2=bp11x6881 by funext i; fin_cases i <;> rfl]; exact p11x6881
set_option maxRecDepth 100000 in
private theorem p11x6835 : Deny 1000000000000000000 11 bp11x6835 := by
  apply split bp11x6835 1
  · rw [show leftB bp11x6835 1=bp11x6836 by funext i; fin_cases i <;> rfl]; exact p11x6836
  · rw [show rightB bp11x6835 1=bp11x6837 by funext i; fin_cases i <;> rfl]; exact p11x6837
set_option maxRecDepth 100000 in
private theorem p11x6833 : Deny 1000000000000000000 11 bp11x6833 := by
  apply split bp11x6833 2
  · rw [show leftB bp11x6833 2=bp11x6834 by funext i; fin_cases i <;> rfl]; exact p11x6834
  · rw [show rightB bp11x6833 2=bp11x6835 by funext i; fin_cases i <;> rfl]; exact p11x6835
private def bp11x8742 : B := ![⟨16,some 16⟩,⟨382,none⟩,⟨94,none⟩]
private def bp11x8743 : B := ![⟨16,some 16⟩,⟨382,none⟩,⟨94,some 189⟩]
private def bp11x8744 : B := ![⟨16,some 16⟩,⟨382,some 765⟩,⟨94,some 189⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x8744 : Deny 1000000000000000000 11 bp11x8744 :=
  sound (by decide) (by decide) 19 119284432124611570049472388257852426467455777597858062879536779910143687456730554656709496941465264156586131013812223366704701979034210944705814697615687361315 (tail:=0) (by decide +kernel)
private def bp11x9015 : B := ![⟨16,some 16⟩,⟨766,none⟩,⟨94,some 189⟩]
private def bp11x9016 : B := ![⟨16,some 16⟩,⟨766,none⟩,⟨94,some 125⟩]
private def bp11x9017 : B := ![⟨16,some 16⟩,⟨766,some 1533⟩,⟨94,some 125⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x9017 : Deny 1000000000000000000 11 bp11x9017 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x9018 : B := ![⟨16,some 16⟩,⟨1534,none⟩,⟨94,some 125⟩]
private def bp11x9019 : B := ![⟨16,some 16⟩,⟨1534,none⟩,⟨94,some 107⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x9019 : Deny 1000000000000000000 11 bp11x9019 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x9020 : B := ![⟨16,some 16⟩,⟨1534,none⟩,⟨108,some 125⟩]
private def bp11x9021 : B := ![⟨16,some 16⟩,⟨1534,some 3069⟩,⟨108,some 125⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x9021 : Deny 1000000000000000000 11 bp11x9021 :=
  sound (by decide) (by decide) 18 6325586496565792763716863476530486417772199994582103663795493715108823660791293197527574293781814973412913759870568675 (tail:=0) (by decide +kernel)
private def bp11x9226 : B := ![⟨16,some 16⟩,⟨3070,none⟩,⟨108,some 125⟩]
private def bp11x9227 : B := ![⟨16,some 16⟩,⟨3070,none⟩,⟨108,some 115⟩]
private def bp11x9228 : B := ![⟨16,some 16⟩,⟨3070,some 6141⟩,⟨108,some 115⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x9228 : Deny 1000000000000000000 11 bp11x9228 :=
  sound (by decide) (by decide) 17 819211834946136347419021163932439194738176180735199431920419 (tail:=0) (by decide +kernel)
private def bp11x9335 : B := ![⟨16,some 16⟩,⟨6142,none⟩,⟨108,some 115⟩]
private def bp11x9336 : B := ![⟨16,some 16⟩,⟨6142,none⟩,⟨108,some 111⟩]
private def bp11x9337 : B := ![⟨16,some 16⟩,⟨6142,some 12285⟩,⟨108,some 111⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x9337 : Deny 1000000000000000000 11 bp11x9337 :=
  sound (by decide) (by decide) 16 14903791721441999979092151843 (tail:=0) (by decide +kernel)
private def bp11x9386 : B := ![⟨16,some 16⟩,⟨12286,none⟩,⟨108,some 111⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x9386 : Deny 1000000000000000000 11 bp11x9386 :=
  sound (by decide) (by decide) 26 10229493281215268689248421744396338743336336342372315961447962615650445200482906296216159252022904773423328608325751022977018209820198840340984115241376816351021645592780577373520475265167759630467925713803 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x9336 : Deny 1000000000000000000 11 bp11x9336 := by
  apply split bp11x9336 1
  · rw [show leftB bp11x9336 1=bp11x9337 by funext i; fin_cases i <;> rfl]; exact p11x9337
  · rw [show rightB bp11x9336 1=bp11x9386 by funext i; fin_cases i <;> rfl]; exact p11x9386
private def bp11x9737 : B := ![⟨16,some 16⟩,⟨6142,none⟩,⟨112,some 115⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x9737 : Deny 1000000000000000000 11 bp11x9737 :=
  sound (by decide) (by decide) 17 2452782475584914350 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x9335 : Deny 1000000000000000000 11 bp11x9335 := by
  apply split bp11x9335 2
  · rw [show leftB bp11x9335 2=bp11x9336 by funext i; fin_cases i <;> rfl]; exact p11x9336
  · rw [show rightB bp11x9335 2=bp11x9737 by funext i; fin_cases i <;> rfl]; exact p11x9737
set_option maxRecDepth 100000 in
private theorem p11x9227 : Deny 1000000000000000000 11 bp11x9227 := by
  apply split bp11x9227 1
  · rw [show leftB bp11x9227 1=bp11x9228 by funext i; fin_cases i <;> rfl]; exact p11x9228
  · rw [show rightB bp11x9227 1=bp11x9335 by funext i; fin_cases i <;> rfl]; exact p11x9335
private def bp11x9778 : B := ![⟨16,some 16⟩,⟨3070,none⟩,⟨116,some 125⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x9778 : Deny 1000000000000000000 11 bp11x9778 :=
  sound (by decide) (by decide) 17 12035323043620841000798962996817080246395630 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x9226 : Deny 1000000000000000000 11 bp11x9226 := by
  apply split bp11x9226 2
  · rw [show leftB bp11x9226 2=bp11x9227 by funext i; fin_cases i <;> rfl]; exact p11x9227
  · rw [show rightB bp11x9226 2=bp11x9778 by funext i; fin_cases i <;> rfl]; exact p11x9778
set_option maxRecDepth 100000 in
private theorem p11x9020 : Deny 1000000000000000000 11 bp11x9020 := by
  apply split bp11x9020 1
  · rw [show leftB bp11x9020 1=bp11x9021 by funext i; fin_cases i <;> rfl]; exact p11x9021
  · rw [show rightB bp11x9020 1=bp11x9226 by funext i; fin_cases i <;> rfl]; exact p11x9226
set_option maxRecDepth 100000 in
private theorem p11x9018 : Deny 1000000000000000000 11 bp11x9018 := by
  apply split bp11x9018 2
  · rw [show leftB bp11x9018 2=bp11x9019 by funext i; fin_cases i <;> rfl]; exact p11x9019
  · rw [show rightB bp11x9018 2=bp11x9020 by funext i; fin_cases i <;> rfl]; exact p11x9020
set_option maxRecDepth 100000 in
private theorem p11x9016 : Deny 1000000000000000000 11 bp11x9016 := by
  apply split bp11x9016 1
  · rw [show leftB bp11x9016 1=bp11x9017 by funext i; fin_cases i <;> rfl]; exact p11x9017
  · rw [show rightB bp11x9016 1=bp11x9018 by funext i; fin_cases i <;> rfl]; exact p11x9018
private def bp11x9861 : B := ![⟨16,some 16⟩,⟨766,none⟩,⟨126,some 189⟩]
private def bp11x9862 : B := ![⟨16,some 16⟩,⟨766,some 1533⟩,⟨126,some 189⟩]
private def bp11x9863 : B := ![⟨16,some 16⟩,⟨766,some 1533⟩,⟨126,some 151⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x9863 : Deny 1000000000000000000 11 bp11x9863 :=
  sound (by decide) (by decide) 17 53303480766825140543961220386909716456196790862019703499778564344223681161782974256473553136862369114538004034079261724631240774965811592837419504881296809109403685202367953978047686276076668473661751965319466126 (tail:=0) (by decide +kernel)
private def bp11x10224 : B := ![⟨16,some 16⟩,⟨766,some 1533⟩,⟨152,some 189⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x10224 : Deny 1000000000000000000 11 bp11x10224 :=
  sound (by decide) (by decide) 15 24623857524738824152287670917884268923573678433578174645369784549926159512419798832772080023331573299607403335398219166838751172375278 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x9862 : Deny 1000000000000000000 11 bp11x9862 := by
  apply split bp11x9862 2
  · rw [show leftB bp11x9862 2=bp11x9863 by funext i; fin_cases i <;> rfl]; exact p11x9863
  · rw [show rightB bp11x9862 2=bp11x10224 by funext i; fin_cases i <;> rfl]; exact p11x10224
private def bp11x10457 : B := ![⟨16,some 16⟩,⟨1534,none⟩,⟨126,some 189⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x10457 : Deny 1000000000000000000 11 bp11x10457 :=
  sound (by decide) (by decide) 18 1201691584558797574617280580887212699439810674401498312549628375431398603707 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x9861 : Deny 1000000000000000000 11 bp11x9861 := by
  apply split bp11x9861 1
  · rw [show leftB bp11x9861 1=bp11x9862 by funext i; fin_cases i <;> rfl]; exact p11x9862
  · rw [show rightB bp11x9861 1=bp11x10457 by funext i; fin_cases i <;> rfl]; exact p11x10457
set_option maxRecDepth 100000 in
private theorem p11x9015 : Deny 1000000000000000000 11 bp11x9015 := by
  apply split bp11x9015 2
  · rw [show leftB bp11x9015 2=bp11x9016 by funext i; fin_cases i <;> rfl]; exact p11x9016
  · rw [show rightB bp11x9015 2=bp11x9861 by funext i; fin_cases i <;> rfl]; exact p11x9861
set_option maxRecDepth 100000 in
private theorem p11x8743 : Deny 1000000000000000000 11 bp11x8743 := by
  apply split bp11x8743 1
  · rw [show leftB bp11x8743 1=bp11x8744 by funext i; fin_cases i <;> rfl]; exact p11x8744
  · rw [show rightB bp11x8743 1=bp11x9015 by funext i; fin_cases i <;> rfl]; exact p11x9015
private def bp11x10596 : B := ![⟨16,some 16⟩,⟨382,none⟩,⟨190,none⟩]
private def bp11x10597 : B := ![⟨16,some 16⟩,⟨382,some 765⟩,⟨190,none⟩]
private def bp11x10598 : B := ![⟨16,some 16⟩,⟨382,some 765⟩,⟨190,some 381⟩]
private def bp11x10599 : B := ![⟨16,some 16⟩,⟨382,some 509⟩,⟨190,some 381⟩]
private def bp11x10600 : B := ![⟨16,some 16⟩,⟨382,some 509⟩,⟨190,some 253⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x10600 : Deny 1000000000000000000 11 bp11x10600 :=
  sound (by decide) (by decide) 16 1611531564270512078871772447534377250508454466190422474316353296397651333435210738247784863744094155314 (tail:=0) (by decide +kernel)
private def bp11x10777 : B := ![⟨16,some 16⟩,⟨382,some 509⟩,⟨254,some 381⟩]
private def bp11x10778 : B := ![⟨16,some 16⟩,⟨382,some 436⟩,⟨254,some 381⟩]
private def bp11x10779 : B := ![⟨16,some 16⟩,⟨382,some 436⟩,⟨254,some 304⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x10779 : Deny 1000000000000000000 11 bp11x10779 :=
  sound (by decide) (by decide) 13 22041501620371124959784946488736688046516440981298039534130 (tail:=0) (by decide +kernel)
private def bp11x10882 : B := ![⟨16,some 16⟩,⟨382,some 436⟩,⟨305,some 381⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x10882 : Deny 1000000000000000000 11 bp11x10882 :=
  sound (by decide) (by decide) 14 13489783355320901619164933326073197031553671389642525722306039456985799119480228555609536544203370566613056402307899799388651286584618046004505811921692084504906586713625154163193733934 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x10778 : Deny 1000000000000000000 11 bp11x10778 := by
  apply split bp11x10778 2
  · rw [show leftB bp11x10778 2=bp11x10779 by funext i; fin_cases i <;> rfl]; exact p11x10779
  · rw [show rightB bp11x10778 2=bp11x10882 by funext i; fin_cases i <;> rfl]; exact p11x10882
private def bp11x11197 : B := ![⟨16,some 16⟩,⟨437,some 509⟩,⟨254,some 381⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x11197 : Deny 1000000000000000000 11 bp11x11197 :=
  sound (by decide) (by decide) 15 498332370580761283435516242932999085624362071320650746804410655963613094988785208791452200198018778527102669228178520464601326523 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x10777 : Deny 1000000000000000000 11 bp11x10777 := by
  apply split bp11x10777 1
  · rw [show leftB bp11x10777 1=bp11x10778 by funext i; fin_cases i <;> rfl]; exact p11x10778
  · rw [show rightB bp11x10777 1=bp11x11197 by funext i; fin_cases i <;> rfl]; exact p11x11197
set_option maxRecDepth 100000 in
private theorem p11x10599 : Deny 1000000000000000000 11 bp11x10599 := by
  apply split bp11x10599 2
  · rw [show leftB bp11x10599 2=bp11x10600 by funext i; fin_cases i <;> rfl]; exact p11x10600
  · rw [show rightB bp11x10599 2=bp11x10777 by funext i; fin_cases i <;> rfl]; exact p11x10777
private def bp11x11422 : B := ![⟨16,some 16⟩,⟨510,some 765⟩,⟨190,some 381⟩]
private def bp11x11423 : B := ![⟨16,some 16⟩,⟨510,some 765⟩,⟨190,some 253⟩]
private def bp11x11424 : B := ![⟨16,some 16⟩,⟨510,some 612⟩,⟨190,some 253⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x11424 : Deny 1000000000000000000 11 bp11x11424 :=
  sound (by decide) (by decide) 14 44847295151671321936848298586414443305762884806114455897903979157576984258992825052179245730943200366633143796747037613229268203967754598839298965652597389472248798533080153525792140220788486411349420176978491 (tail:=0) (by decide +kernel)
private def bp11x11781 : B := ![⟨16,some 16⟩,⟨613,some 765⟩,⟨190,some 253⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x11781 : Deny 1000000000000000000 11 bp11x11781 :=
  sound (by decide) (by decide) 14 11006525548095846919400328051643 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x11423 : Deny 1000000000000000000 11 bp11x11423 := by
  apply split bp11x11423 1
  · rw [show leftB bp11x11423 1=bp11x11424 by funext i; fin_cases i <;> rfl]; exact p11x11424
  · rw [show rightB bp11x11423 1=bp11x11781 by funext i; fin_cases i <;> rfl]; exact p11x11781
private def bp11x11844 : B := ![⟨16,some 16⟩,⟨510,some 765⟩,⟨254,some 381⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x11844 : Deny 1000000000000000000 11 bp11x11844 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x11422 : Deny 1000000000000000000 11 bp11x11422 := by
  apply split bp11x11422 2
  · rw [show leftB bp11x11422 2=bp11x11423 by funext i; fin_cases i <;> rfl]; exact p11x11423
  · rw [show rightB bp11x11422 2=bp11x11844 by funext i; fin_cases i <;> rfl]; exact p11x11844
set_option maxRecDepth 100000 in
private theorem p11x10598 : Deny 1000000000000000000 11 bp11x10598 := by
  apply split bp11x10598 1
  · rw [show leftB bp11x10598 1=bp11x10599 by funext i; fin_cases i <;> rfl]; exact p11x10599
  · rw [show rightB bp11x10598 1=bp11x11422 by funext i; fin_cases i <;> rfl]; exact p11x11422
private def bp11x11845 : B := ![⟨16,some 16⟩,⟨382,some 765⟩,⟨382,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x11845 : Deny 1000000000000000000 11 bp11x11845 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x10597 : Deny 1000000000000000000 11 bp11x10597 := by
  apply split bp11x10597 2
  · rw [show leftB bp11x10597 2=bp11x10598 by funext i; fin_cases i <;> rfl]; exact p11x10598
  · rw [show rightB bp11x10597 2=bp11x11845 by funext i; fin_cases i <;> rfl]; exact p11x11845
private def bp11x11846 : B := ![⟨16,some 16⟩,⟨766,none⟩,⟨190,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x11846 : Deny 1000000000000000000 11 bp11x11846 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x10596 : Deny 1000000000000000000 11 bp11x10596 := by
  apply split bp11x10596 1
  · rw [show leftB bp11x10596 1=bp11x10597 by funext i; fin_cases i <;> rfl]; exact p11x10597
  · rw [show rightB bp11x10596 1=bp11x11846 by funext i; fin_cases i <;> rfl]; exact p11x11846
set_option maxRecDepth 100000 in
private theorem p11x8742 : Deny 1000000000000000000 11 bp11x8742 := by
  apply split bp11x8742 2
  · rw [show leftB bp11x8742 2=bp11x8743 by funext i; fin_cases i <;> rfl]; exact p11x8743
  · rw [show rightB bp11x8742 2=bp11x10596 by funext i; fin_cases i <;> rfl]; exact p11x10596
set_option maxRecDepth 100000 in
private theorem p11x6832 : Deny 1000000000000000000 11 bp11x6832 := by
  apply split bp11x6832 1
  · rw [show leftB bp11x6832 1=bp11x6833 by funext i; fin_cases i <;> rfl]; exact p11x6833
  · rw [show rightB bp11x6832 1=bp11x8742 by funext i; fin_cases i <;> rfl]; exact p11x8742
set_option maxRecDepth 100000 in
private theorem p11x6830 : Deny 1000000000000000000 11 bp11x6830 := by
  apply split bp11x6830 0
  · rw [show leftB bp11x6830 0=bp11x6831 by funext i; fin_cases i <;> rfl]; exact p11x6831
  · rw [show rightB bp11x6830 0=bp11x6832 by funext i; fin_cases i <;> rfl]; exact p11x6832
set_option maxRecDepth 100000 in
private theorem p11x6828 : Deny 1000000000000000000 11 bp11x6828 := by
  apply split bp11x6828 2
  · rw [show leftB bp11x6828 2=bp11x6829 by funext i; fin_cases i <;> rfl]; exact p11x6829
  · rw [show rightB bp11x6828 2=bp11x6830 by funext i; fin_cases i <;> rfl]; exact p11x6830
set_option maxRecDepth 100000 in
private theorem p11x6826 : Deny 1000000000000000000 11 bp11x6826 := by
  apply split bp11x6826 1
  · rw [show leftB bp11x6826 1=bp11x6827 by funext i; fin_cases i <;> rfl]; exact p11x6827
  · rw [show rightB bp11x6826 1=bp11x6828 by funext i; fin_cases i <;> rfl]; exact p11x6828
set_option maxRecDepth 100000 in
private theorem p11x6824 : Deny 1000000000000000000 11 bp11x6824 := by
  apply split bp11x6824 0
  · rw [show leftB bp11x6824 0=bp11x6825 by funext i; fin_cases i <;> rfl]; exact p11x6825
  · rw [show rightB bp11x6824 0=bp11x6826 by funext i; fin_cases i <;> rfl]; exact p11x6826
set_option maxRecDepth 100000 in
private theorem p11x6822 : Deny 1000000000000000000 11 bp11x6822 := by
  apply split bp11x6822 2
  · rw [show leftB bp11x6822 2=bp11x6823 by funext i; fin_cases i <;> rfl]; exact p11x6823
  · rw [show rightB bp11x6822 2=bp11x6824 by funext i; fin_cases i <;> rfl]; exact p11x6824
set_option maxRecDepth 100000 in
private theorem p11x6820 : Deny 1000000000000000000 11 bp11x6820 := by
  apply split bp11x6820 1
  · rw [show leftB bp11x6820 1=bp11x6821 by funext i; fin_cases i <;> rfl]; exact p11x6821
  · rw [show rightB bp11x6820 1=bp11x6822 by funext i; fin_cases i <;> rfl]; exact p11x6822
set_option maxRecDepth 100000 in
private theorem p11x6818 : Deny 1000000000000000000 11 bp11x6818 := by
  apply split bp11x6818 2
  · rw [show leftB bp11x6818 2=bp11x6819 by funext i; fin_cases i <;> rfl]; exact p11x6819
  · rw [show rightB bp11x6818 2=bp11x6820 by funext i; fin_cases i <;> rfl]; exact p11x6820
private def bp11x11847 : B := ![⟨17,some 21⟩,⟨46,none⟩,⟨10,none⟩]
private def bp11x11848 : B := ![⟨17,some 21⟩,⟨46,none⟩,⟨10,some 21⟩]
private def bp11x11849 : B := ![⟨17,some 21⟩,⟨46,some 93⟩,⟨10,some 21⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x11849 : Deny 1000000000000000000 11 bp11x11849 :=
  sound (by decide) (by decide) 16 192143748653948571161137 (tail:=0) (by decide +kernel)
private def bp11x11892 : B := ![⟨17,some 21⟩,⟨94,none⟩,⟨10,some 21⟩]
private def bp11x11893 : B := ![⟨17,some 18⟩,⟨94,none⟩,⟨10,some 21⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x11893 : Deny 1000000000000000000 11 bp11x11893 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x11894 : B := ![⟨19,some 21⟩,⟨94,none⟩,⟨10,some 21⟩]
private def bp11x11895 : B := ![⟨19,some 21⟩,⟨94,none⟩,⟨10,some 13⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x11895 : Deny 1000000000000000000 11 bp11x11895 :=
  sound (by decide) (by decide) 23 16285948501387527561054842554723984269626923653611463442 (tail:=0) (by decide +kernel)
private def bp11x11998 : B := ![⟨19,some 21⟩,⟨94,none⟩,⟨14,some 21⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x11998 : Deny 1000000000000000000 11 bp11x11998 :=
  sound (by decide) (by decide) 20 2435705140191209700792864991983802356279931648398962093435249602381847541329029434829282231845307381183727922658682012351150993890484638561768628958358007998578435737379174228331537449447789254 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x11894 : Deny 1000000000000000000 11 bp11x11894 := by
  apply split bp11x11894 2
  · rw [show leftB bp11x11894 2=bp11x11895 by funext i; fin_cases i <;> rfl]; exact p11x11895
  · rw [show rightB bp11x11894 2=bp11x11998 by funext i; fin_cases i <;> rfl]; exact p11x11998
set_option maxRecDepth 100000 in
private theorem p11x11892 : Deny 1000000000000000000 11 bp11x11892 := by
  apply split bp11x11892 0
  · rw [show leftB bp11x11892 0=bp11x11893 by funext i; fin_cases i <;> rfl]; exact p11x11893
  · rw [show rightB bp11x11892 0=bp11x11894 by funext i; fin_cases i <;> rfl]; exact p11x11894
set_option maxRecDepth 100000 in
private theorem p11x11848 : Deny 1000000000000000000 11 bp11x11848 := by
  apply split bp11x11848 1
  · rw [show leftB bp11x11848 1=bp11x11849 by funext i; fin_cases i <;> rfl]; exact p11x11849
  · rw [show rightB bp11x11848 1=bp11x11892 by funext i; fin_cases i <;> rfl]; exact p11x11892
private def bp11x12327 : B := ![⟨17,some 21⟩,⟨46,none⟩,⟨22,none⟩]
private def bp11x12328 : B := ![⟨17,some 21⟩,⟨46,some 93⟩,⟨22,none⟩]
private def bp11x12329 : B := ![⟨17,some 18⟩,⟨46,some 93⟩,⟨22,none⟩]
private def bp11x12330 : B := ![⟨17,some 18⟩,⟨46,some 93⟩,⟨22,some 45⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x12330 : Deny 1000000000000000000 11 bp11x12330 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x12331 : B := ![⟨17,some 18⟩,⟨46,some 93⟩,⟨46,none⟩]
private def bp11x12332 : B := ![⟨17,some 18⟩,⟨46,some 61⟩,⟨46,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x12332 : Deny 1000000000000000000 11 bp11x12332 :=
  sound (by decide) (by decide) 23 16092072031195706017207955987 (tail:=0) (by decide +kernel)
private def bp11x12389 : B := ![⟨17,some 18⟩,⟨62,some 93⟩,⟨46,none⟩]
private def bp11x12390 : B := ![⟨17,some 18⟩,⟨62,some 93⟩,⟨46,some 93⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x12390 : Deny 1000000000000000000 11 bp11x12390 :=
  sound (by decide) (by decide) 15 298183840007050205790646148058396648602904929323227680400161 (tail:=0) (by decide +kernel)
private def bp11x12495 : B := ![⟨17,some 18⟩,⟨62,some 93⟩,⟨94,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x12495 : Deny 1000000000000000000 11 bp11x12495 :=
  sound (by decide) (by decide) 19 65096459640457876508883949764555537376711283518998165805171988126685663226660943579636813990730808377939796098691702266002696417661041438941420040658187799845523683380074369581462241 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x12389 : Deny 1000000000000000000 11 bp11x12389 := by
  apply split bp11x12389 2
  · rw [show leftB bp11x12389 2=bp11x12390 by funext i; fin_cases i <;> rfl]; exact p11x12390
  · rw [show rightB bp11x12389 2=bp11x12495 by funext i; fin_cases i <;> rfl]; exact p11x12495
set_option maxRecDepth 100000 in
private theorem p11x12331 : Deny 1000000000000000000 11 bp11x12331 := by
  apply split bp11x12331 1
  · rw [show leftB bp11x12331 1=bp11x12332 by funext i; fin_cases i <;> rfl]; exact p11x12332
  · rw [show rightB bp11x12331 1=bp11x12389 by funext i; fin_cases i <;> rfl]; exact p11x12389
set_option maxRecDepth 100000 in
private theorem p11x12329 : Deny 1000000000000000000 11 bp11x12329 := by
  apply split bp11x12329 2
  · rw [show leftB bp11x12329 2=bp11x12330 by funext i; fin_cases i <;> rfl]; exact p11x12330
  · rw [show rightB bp11x12329 2=bp11x12331 by funext i; fin_cases i <;> rfl]; exact p11x12331
private def bp11x12806 : B := ![⟨19,some 21⟩,⟨46,some 93⟩,⟨22,none⟩]
private def bp11x12807 : B := ![⟨19,some 21⟩,⟨46,some 93⟩,⟨22,some 45⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x12807 : Deny 1000000000000000000 11 bp11x12807 :=
  sound (by decide) (by decide) 14 14827037306325040381738276848906815601017719412937812135646641085876882159080722928249282993122860126573162472724488796573161939226903754597334778202018648609857706361715284732628465320597244236391178298299645975270086 (tail:=0) (by decide +kernel)
private def bp11x13176 : B := ![⟨19,some 21⟩,⟨46,some 93⟩,⟨46,none⟩]
private def bp11x13177 : B := ![⟨19,some 21⟩,⟨46,some 61⟩,⟨46,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x13177 : Deny 1000000000000000000 11 bp11x13177 :=
  sound (by decide) (by decide) 19 4361783166189104404000531670091349851716560680667786403193745137020230241108753111571422990893578261803652273111296773366210598186112771955619646830411402564916339131630525229251460280186132561262338861 (tail:=0) (by decide +kernel)
private def bp11x13522 : B := ![⟨19,some 21⟩,⟨62,some 93⟩,⟨46,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x13522 : Deny 1000000000000000000 11 bp11x13522 :=
  sound (by decide) (by decide) 14 1237744616087718340933079201792438646258283698813964013 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x13176 : Deny 1000000000000000000 11 bp11x13176 := by
  apply split bp11x13176 1
  · rw [show leftB bp11x13176 1=bp11x13177 by funext i; fin_cases i <;> rfl]; exact p11x13177
  · rw [show rightB bp11x13176 1=bp11x13522 by funext i; fin_cases i <;> rfl]; exact p11x13522
set_option maxRecDepth 100000 in
private theorem p11x12806 : Deny 1000000000000000000 11 bp11x12806 := by
  apply split bp11x12806 2
  · rw [show leftB bp11x12806 2=bp11x12807 by funext i; fin_cases i <;> rfl]; exact p11x12807
  · rw [show rightB bp11x12806 2=bp11x13176 by funext i; fin_cases i <;> rfl]; exact p11x13176
set_option maxRecDepth 100000 in
private theorem p11x12328 : Deny 1000000000000000000 11 bp11x12328 := by
  apply split bp11x12328 0
  · rw [show leftB bp11x12328 0=bp11x12329 by funext i; fin_cases i <;> rfl]; exact p11x12329
  · rw [show rightB bp11x12328 0=bp11x12806 by funext i; fin_cases i <;> rfl]; exact p11x12806
private def bp11x13623 : B := ![⟨17,some 21⟩,⟨94,none⟩,⟨22,none⟩]
private def bp11x13624 : B := ![⟨17,some 18⟩,⟨94,none⟩,⟨22,none⟩]
private def bp11x13625 : B := ![⟨17,some 18⟩,⟨94,none⟩,⟨22,some 45⟩]
private def bp11x13626 : B := ![⟨17,some 18⟩,⟨94,some 189⟩,⟨22,some 45⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x13626 : Deny 1000000000000000000 11 bp11x13626 :=
  sound (by decide) (by decide) 15 77161538861659329449400483427263422633399862596944977174088815155562197523 (tail:=0) (by decide +kernel)
private def bp11x13757 : B := ![⟨17,some 18⟩,⟨190,none⟩,⟨22,some 45⟩]
private def bp11x13758 : B := ![⟨17,some 18⟩,⟨190,none⟩,⟨22,some 29⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x13758 : Deny 1000000000000000000 11 bp11x13758 :=
  sound (by decide) (by decide) 21 70619153600813326028865477672109662441152116108888017828300425861206707494568322696433158369 (tail:=0) (by decide +kernel)
private def bp11x13921 : B := ![⟨17,some 18⟩,⟨190,none⟩,⟨30,some 45⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x13921 : Deny 1000000000000000000 11 bp11x13921 :=
  sound (by decide) (by decide) 25 50077502111283184393961161760490265069525007774004938439446679123930197137465128111169772636990572472565070065831265985525477325799988449630789807033837873866062111317019375246778292697187698751689 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x13757 : Deny 1000000000000000000 11 bp11x13757 := by
  apply split bp11x13757 2
  · rw [show leftB bp11x13757 2=bp11x13758 by funext i; fin_cases i <;> rfl]; exact p11x13758
  · rw [show rightB bp11x13757 2=bp11x13921 by funext i; fin_cases i <;> rfl]; exact p11x13921
set_option maxRecDepth 100000 in
private theorem p11x13625 : Deny 1000000000000000000 11 bp11x13625 := by
  apply split bp11x13625 1
  · rw [show leftB bp11x13625 1=bp11x13626 by funext i; fin_cases i <;> rfl]; exact p11x13626
  · rw [show rightB bp11x13625 1=bp11x13757 by funext i; fin_cases i <;> rfl]; exact p11x13757
private def bp11x14258 : B := ![⟨17,some 18⟩,⟨94,none⟩,⟨46,none⟩]
private def bp11x14259 : B := ![⟨17,some 18⟩,⟨94,some 189⟩,⟨46,none⟩]
private def bp11x14260 : B := ![⟨17,some 18⟩,⟨94,some 189⟩,⟨46,some 93⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x14260 : Deny 1000000000000000000 11 bp11x14260 :=
  sound (by decide) (by decide) 16 214821653746906358197107031082550862842539459245341299174185621100032823331171945873960417368899856349301472292252575565900448645104995458324814775945768972291072096520393 (tail:=0) (by decide +kernel)
private def bp11x14553 : B := ![⟨17,some 18⟩,⟨94,some 189⟩,⟨94,none⟩]
private def bp11x14554 : B := ![⟨17,some 17⟩,⟨94,some 189⟩,⟨94,none⟩]
private def bp11x14555 : B := ![⟨17,some 17⟩,⟨94,some 125⟩,⟨94,none⟩]
private def bp11x14556 : B := ![⟨17,some 17⟩,⟨94,some 125⟩,⟨94,some 189⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x14556 : Deny 1000000000000000000 11 bp11x14556 :=
  sound (by decide) (by decide) 14 5338246729263791113796379605830036501042 (tail:=0) (by decide +kernel)
private def bp11x14627 : B := ![⟨17,some 17⟩,⟨94,some 125⟩,⟨190,none⟩]
private def bp11x14628 : B := ![⟨17,some 17⟩,⟨94,some 107⟩,⟨190,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x14628 : Deny 1000000000000000000 11 bp11x14628 :=
  sound (by decide) (by decide) 22 870861947858108473091136547700880584778303574004373252355083941121985620850534769687498711776069960348139000387031286123965272566344741277356525531697996180705696637258600363121040738507 (tail:=0) (by decide +kernel)
private def bp11x14945 : B := ![⟨17,some 17⟩,⟨108,some 125⟩,⟨190,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x14945 : Deny 1000000000000000000 11 bp11x14945 :=
  sound (by decide) (by decide) 14 26322796773057889059307554701741978233362368029028501457249443079843813198308887183769128123 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x14627 : Deny 1000000000000000000 11 bp11x14627 := by
  apply split bp11x14627 1
  · rw [show leftB bp11x14627 1=bp11x14628 by funext i; fin_cases i <;> rfl]; exact p11x14628
  · rw [show rightB bp11x14627 1=bp11x14945 by funext i; fin_cases i <;> rfl]; exact p11x14945
set_option maxRecDepth 100000 in
private theorem p11x14555 : Deny 1000000000000000000 11 bp11x14555 := by
  apply split bp11x14555 2
  · rw [show leftB bp11x14555 2=bp11x14556 by funext i; fin_cases i <;> rfl]; exact p11x14556
  · rw [show rightB bp11x14555 2=bp11x14627 by funext i; fin_cases i <;> rfl]; exact p11x14627
private def bp11x15106 : B := ![⟨17,some 17⟩,⟨126,some 189⟩,⟨94,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x15106 : Deny 1000000000000000000 11 bp11x15106 :=
  sound (by decide) (by decide) 15 675511955102016431259833188927714650048706197580766871349890646791638732987854028313488727529061451636423434550214838098614743438978276226856665687880442402264263867 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x14554 : Deny 1000000000000000000 11 bp11x14554 := by
  apply split bp11x14554 1
  · rw [show leftB bp11x14554 1=bp11x14555 by funext i; fin_cases i <;> rfl]; exact p11x14555
  · rw [show rightB bp11x14554 1=bp11x15106 by funext i; fin_cases i <;> rfl]; exact p11x15106
private def bp11x15391 : B := ![⟨18,some 18⟩,⟨94,some 189⟩,⟨94,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x15391 : Deny 1000000000000000000 11 bp11x15391 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x14553 : Deny 1000000000000000000 11 bp11x14553 := by
  apply split bp11x14553 0
  · rw [show leftB bp11x14553 0=bp11x14554 by funext i; fin_cases i <;> rfl]; exact p11x14554
  · rw [show rightB bp11x14553 0=bp11x15391 by funext i; fin_cases i <;> rfl]; exact p11x15391
set_option maxRecDepth 100000 in
private theorem p11x14259 : Deny 1000000000000000000 11 bp11x14259 := by
  apply split bp11x14259 2
  · rw [show leftB bp11x14259 2=bp11x14260 by funext i; fin_cases i <;> rfl]; exact p11x14260
  · rw [show rightB bp11x14259 2=bp11x14553 by funext i; fin_cases i <;> rfl]; exact p11x14553
private def bp11x15392 : B := ![⟨17,some 18⟩,⟨190,none⟩,⟨46,none⟩]
private def bp11x15393 : B := ![⟨17,some 18⟩,⟨190,none⟩,⟨46,some 93⟩]
private def bp11x15394 : B := ![⟨17,some 17⟩,⟨190,none⟩,⟨46,some 93⟩]
private def bp11x15395 : B := ![⟨17,some 17⟩,⟨190,some 381⟩,⟨46,some 93⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x15395 : Deny 1000000000000000000 11 bp11x15395 :=
  sound (by decide) (by decide) 15 3072471538253502169396026739152540815130882288781412152147584458520721593707090763891281973492423244237482020339405761536486544091786862104973212804506583882049084972871452890074250004804155 (tail:=0) (by decide +kernel)
private def bp11x15720 : B := ![⟨17,some 17⟩,⟨382,none⟩,⟨46,some 93⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x15720 : Deny 1000000000000000000 11 bp11x15720 :=
  sound (by decide) (by decide) 16 47556666569172017263223424593291561590270172122043 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x15394 : Deny 1000000000000000000 11 bp11x15394 := by
  apply split bp11x15394 1
  · rw [show leftB bp11x15394 1=bp11x15395 by funext i; fin_cases i <;> rfl]; exact p11x15395
  · rw [show rightB bp11x15394 1=bp11x15720 by funext i; fin_cases i <;> rfl]; exact p11x15720
private def bp11x15813 : B := ![⟨18,some 18⟩,⟨190,none⟩,⟨46,some 93⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x15813 : Deny 1000000000000000000 11 bp11x15813 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x15393 : Deny 1000000000000000000 11 bp11x15393 := by
  apply split bp11x15393 0
  · rw [show leftB bp11x15393 0=bp11x15394 by funext i; fin_cases i <;> rfl]; exact p11x15394
  · rw [show rightB bp11x15393 0=bp11x15813 by funext i; fin_cases i <;> rfl]; exact p11x15813
private def bp11x15814 : B := ![⟨17,some 18⟩,⟨190,none⟩,⟨94,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x15814 : Deny 1000000000000000000 11 bp11x15814 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x15392 : Deny 1000000000000000000 11 bp11x15392 := by
  apply split bp11x15392 2
  · rw [show leftB bp11x15392 2=bp11x15393 by funext i; fin_cases i <;> rfl]; exact p11x15393
  · rw [show rightB bp11x15392 2=bp11x15814 by funext i; fin_cases i <;> rfl]; exact p11x15814
set_option maxRecDepth 100000 in
private theorem p11x14258 : Deny 1000000000000000000 11 bp11x14258 := by
  apply split bp11x14258 1
  · rw [show leftB bp11x14258 1=bp11x14259 by funext i; fin_cases i <;> rfl]; exact p11x14259
  · rw [show rightB bp11x14258 1=bp11x15392 by funext i; fin_cases i <;> rfl]; exact p11x15392
set_option maxRecDepth 100000 in
private theorem p11x13624 : Deny 1000000000000000000 11 bp11x13624 := by
  apply split bp11x13624 2
  · rw [show leftB bp11x13624 2=bp11x13625 by funext i; fin_cases i <;> rfl]; exact p11x13625
  · rw [show rightB bp11x13624 2=bp11x14258 by funext i; fin_cases i <;> rfl]; exact p11x14258
private def bp11x15815 : B := ![⟨19,some 21⟩,⟨94,none⟩,⟨22,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x15815 : Deny 1000000000000000000 11 bp11x15815 :=
  sound (by decide) (by decide) 16 6646011547713812853920183757405458606947925886397925988755036056763841204881116111011677196638729949079025085930311387 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x13623 : Deny 1000000000000000000 11 bp11x13623 := by
  apply split bp11x13623 0
  · rw [show leftB bp11x13623 0=bp11x13624 by funext i; fin_cases i <;> rfl]; exact p11x13624
  · rw [show rightB bp11x13623 0=bp11x15815 by funext i; fin_cases i <;> rfl]; exact p11x15815
set_option maxRecDepth 100000 in
private theorem p11x12327 : Deny 1000000000000000000 11 bp11x12327 := by
  apply split bp11x12327 1
  · rw [show leftB bp11x12327 1=bp11x12328 by funext i; fin_cases i <;> rfl]; exact p11x12328
  · rw [show rightB bp11x12327 1=bp11x13623 by funext i; fin_cases i <;> rfl]; exact p11x13623
set_option maxRecDepth 100000 in
private theorem p11x11847 : Deny 1000000000000000000 11 bp11x11847 := by
  apply split bp11x11847 2
  · rw [show leftB bp11x11847 2=bp11x11848 by funext i; fin_cases i <;> rfl]; exact p11x11848
  · rw [show rightB bp11x11847 2=bp11x12327 by funext i; fin_cases i <;> rfl]; exact p11x12327
set_option maxRecDepth 100000 in
private theorem p11x6817 : Deny 1000000000000000000 11 bp11x6817 := by
  apply split bp11x6817 0
  · rw [show leftB bp11x6817 0=bp11x6818 by funext i; fin_cases i <;> rfl]; exact p11x6818
  · rw [show rightB bp11x6817 0=bp11x11847 by funext i; fin_cases i <;> rfl]; exact p11x11847
set_option maxRecDepth 100000 in
private theorem p11x6227 : Deny 1000000000000000000 11 bp11x6227 := by
  apply split bp11x6227 1
  · rw [show leftB bp11x6227 1=bp11x6228 by funext i; fin_cases i <;> rfl]; exact p11x6228
  · rw [show rightB bp11x6227 1=bp11x6817 by funext i; fin_cases i <;> rfl]; exact p11x6817
set_option maxRecDepth 100000 in
private theorem p11x6225 : Deny 1000000000000000000 11 bp11x6225 := by
  apply split bp11x6225 2
  · rw [show leftB bp11x6225 2=bp11x6226 by funext i; fin_cases i <;> rfl]; exact p11x6226
  · rw [show rightB bp11x6225 2=bp11x6227 by funext i; fin_cases i <;> rfl]; exact p11x6227
set_option maxRecDepth 100000 in
private theorem p11x6223 : Deny 1000000000000000000 11 bp11x6223 := by
  apply split bp11x6223 1
  · rw [show leftB bp11x6223 1=bp11x6224 by funext i; fin_cases i <;> rfl]; exact p11x6224
  · rw [show rightB bp11x6223 1=bp11x6225 by funext i; fin_cases i <;> rfl]; exact p11x6225
set_option maxRecDepth 100000 in
private theorem p11x6221 : Deny 1000000000000000000 11 bp11x6221 := by
  apply split bp11x6221 0
  · rw [show leftB bp11x6221 0=bp11x6222 by funext i; fin_cases i <;> rfl]; exact p11x6222
  · rw [show rightB bp11x6221 0=bp11x6223 by funext i; fin_cases i <;> rfl]; exact p11x6223
private def bp11x16024 : B := ![⟨22,none⟩,⟨10,none⟩,⟨4,none⟩]
private def bp11x16025 : B := ![⟨22,none⟩,⟨10,some 21⟩,⟨4,none⟩]
private def bp11x16026 : B := ![⟨22,some 45⟩,⟨10,some 21⟩,⟨4,none⟩]
private def bp11x16027 : B := ![⟨22,some 45⟩,⟨10,some 21⟩,⟨4,some 9⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x16027 : Deny 1000000000000000000 11 bp11x16027 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
private def bp11x16028 : B := ![⟨22,some 45⟩,⟨10,some 21⟩,⟨10,none⟩]
private def bp11x16029 : B := ![⟨22,some 45⟩,⟨10,some 13⟩,⟨10,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x16029 : Deny 1000000000000000000 11 bp11x16029 :=
  sound (by decide) (by decide) 24 131122560291469923865288428230097952315158931260633812736756484691539802948867400820748096995753778171928599610959012145 (tail:=0) (by decide +kernel)
private def bp11x16236 : B := ![⟨22,some 45⟩,⟨14,some 21⟩,⟨10,none⟩]
private def bp11x16237 : B := ![⟨22,some 29⟩,⟨14,some 21⟩,⟨10,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x16237 : Deny 1000000000000000000 11 bp11x16237 :=
  sound (by decide) (by decide) 25 13278492064452636417442442889573814156205742149204953804198109833187501414358043523427727481960759010890845267676838147467915271088954350977183945087438909527657384444763481345667363 (tail:=0) (by decide +kernel)
private def bp11x16544 : B := ![⟨30,some 45⟩,⟨14,some 21⟩,⟨10,none⟩]
private def bp11x16545 : B := ![⟨30,some 45⟩,⟨14,some 21⟩,⟨10,some 21⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x16545 : Deny 1000000000000000000 11 bp11x16545 :=
  sound (by decide) (by decide) 14 386888593604654860629829629134338828489993709926621212121967569542815109807728693719270522872690317828455850869035938076294636289167325314162839513196971206 (tail:=0) (by decide +kernel)
private def bp11x16810 : B := ![⟨30,some 45⟩,⟨14,some 21⟩,⟨22,none⟩]
private def bp11x16811 : B := ![⟨30,some 45⟩,⟨14,some 16⟩,⟨22,none⟩]
private def bp11x16812 : B := ![⟨30,some 36⟩,⟨14,some 16⟩,⟨22,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x16812 : Deny 1000000000000000000 11 bp11x16812 :=
  sound (by decide) (by decide) 20 9906346635507541543164703694659446220551774239683341625013297454850505040359728970338639087432595323613392269641456615904470559684702637934791 (tail:=0) (by decide +kernel)
private def bp11x17057 : B := ![⟨37,some 45⟩,⟨14,some 16⟩,⟨22,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x17057 : Deny 1000000000000000000 11 bp11x17057 :=
  sound (by decide) (by decide) 15 3589208231382838429562921098753555626629798322029591021552427369343435459873850402501558898696853965145802943901920664381822113095532918473638414204178945904474344410295 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x16811 : Deny 1000000000000000000 11 bp11x16811 := by
  apply split bp11x16811 0
  · rw [show leftB bp11x16811 0=bp11x16812 by funext i; fin_cases i <;> rfl]; exact p11x16812
  · rw [show rightB bp11x16811 0=bp11x17057 by funext i; fin_cases i <;> rfl]; exact p11x17057
private def bp11x17346 : B := ![⟨30,some 45⟩,⟨17,some 21⟩,⟨22,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x17346 : Deny 1000000000000000000 11 bp11x17346 :=
  sound (by decide) (by decide) 17 162939110084647090164725031692396209054545613609478700681071482773935592491932919826274656219381573669476706339658081174408872748451930051934477589381657479902316740267295132956009001506839377315190077833573784695709 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x16810 : Deny 1000000000000000000 11 bp11x16810 := by
  apply split bp11x16810 1
  · rw [show leftB bp11x16810 1=bp11x16811 by funext i; fin_cases i <;> rfl]; exact p11x16811
  · rw [show rightB bp11x16810 1=bp11x17346 by funext i; fin_cases i <;> rfl]; exact p11x17346
set_option maxRecDepth 100000 in
private theorem p11x16544 : Deny 1000000000000000000 11 bp11x16544 := by
  apply split bp11x16544 2
  · rw [show leftB bp11x16544 2=bp11x16545 by funext i; fin_cases i <;> rfl]; exact p11x16545
  · rw [show rightB bp11x16544 2=bp11x16810 by funext i; fin_cases i <;> rfl]; exact p11x16810
set_option maxRecDepth 100000 in
private theorem p11x16236 : Deny 1000000000000000000 11 bp11x16236 := by
  apply split bp11x16236 0
  · rw [show leftB bp11x16236 0=bp11x16237 by funext i; fin_cases i <;> rfl]; exact p11x16237
  · rw [show rightB bp11x16236 0=bp11x16544 by funext i; fin_cases i <;> rfl]; exact p11x16544
set_option maxRecDepth 100000 in
private theorem p11x16028 : Deny 1000000000000000000 11 bp11x16028 := by
  apply split bp11x16028 1
  · rw [show leftB bp11x16028 1=bp11x16029 by funext i; fin_cases i <;> rfl]; exact p11x16029
  · rw [show rightB bp11x16028 1=bp11x16236 by funext i; fin_cases i <;> rfl]; exact p11x16236
set_option maxRecDepth 100000 in
private theorem p11x16026 : Deny 1000000000000000000 11 bp11x16026 := by
  apply split bp11x16026 2
  · rw [show leftB bp11x16026 2=bp11x16027 by funext i; fin_cases i <;> rfl]; exact p11x16027
  · rw [show rightB bp11x16026 2=bp11x16028 by funext i; fin_cases i <;> rfl]; exact p11x16028
private def bp11x17713 : B := ![⟨46,none⟩,⟨10,some 21⟩,⟨4,none⟩]
private def bp11x17714 : B := ![⟨46,none⟩,⟨10,some 21⟩,⟨4,some 9⟩]
private def bp11x17715 : B := ![⟨46,none⟩,⟨10,some 13⟩,⟨4,some 9⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x17715 : Deny 1000000000000000000 11 bp11x17715 :=
  sound (by decide) (by decide) 24 56973047716241866319370478064494413930051312899580503892955567552296005733992470731321084765999410430132495522156452503294273617447217 (tail:=0) (by decide +kernel)
private def bp11x17948 : B := ![⟨46,none⟩,⟨14,some 21⟩,⟨4,some 9⟩]
private def bp11x17949 : B := ![⟨46,some 93⟩,⟨14,some 21⟩,⟨4,some 9⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x17949 : Deny 1000000000000000000 11 bp11x17949 :=
  sound (by decide) (by decide) 14 2392168921360678575840125386528447518804090867347626363984673623321492997722960647823349008871100796051 (tail:=0) (by decide +kernel)
private def bp11x18126 : B := ![⟨94,none⟩,⟨14,some 21⟩,⟨4,some 9⟩]
private def bp11x18127 : B := ![⟨94,none⟩,⟨14,some 21⟩,⟨4,some 5⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x18127 : Deny 1000000000000000000 11 bp11x18127 :=
  sound (by decide) (by decide) 18 3291436472887610140361456716572609686705434053593415942708433682 (tail:=0) (by decide +kernel)
private def bp11x18236 : B := ![⟨94,none⟩,⟨14,some 21⟩,⟨6,some 9⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x18236 : Deny 1000000000000000000 11 bp11x18236 :=
  sound (by decide) (by decide) 19 5932775045505795293385939302370103676194941926486507364449733547290061103478954488085868169564223807977856563856233507144417638336094372252721933364636979620132114760822987829925906344479985813622 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x18126 : Deny 1000000000000000000 11 bp11x18126 := by
  apply split bp11x18126 2
  · rw [show leftB bp11x18126 2=bp11x18127 by funext i; fin_cases i <;> rfl]; exact p11x18127
  · rw [show rightB bp11x18126 2=bp11x18236 by funext i; fin_cases i <;> rfl]; exact p11x18236
set_option maxRecDepth 100000 in
private theorem p11x17948 : Deny 1000000000000000000 11 bp11x17948 := by
  apply split bp11x17948 0
  · rw [show leftB bp11x17948 0=bp11x17949 by funext i; fin_cases i <;> rfl]; exact p11x17949
  · rw [show rightB bp11x17948 0=bp11x18126 by funext i; fin_cases i <;> rfl]; exact p11x18126
set_option maxRecDepth 100000 in
private theorem p11x17714 : Deny 1000000000000000000 11 bp11x17714 := by
  apply split bp11x17714 1
  · rw [show leftB bp11x17714 1=bp11x17715 by funext i; fin_cases i <;> rfl]; exact p11x17715
  · rw [show rightB bp11x17714 1=bp11x17948 by funext i; fin_cases i <;> rfl]; exact p11x17948
private def bp11x18573 : B := ![⟨46,none⟩,⟨10,some 21⟩,⟨10,none⟩]
private def bp11x18574 : B := ![⟨46,none⟩,⟨10,some 13⟩,⟨10,none⟩]
private def bp11x18575 : B := ![⟨46,some 93⟩,⟨10,some 13⟩,⟨10,none⟩]
private def bp11x18576 : B := ![⟨46,some 93⟩,⟨10,some 13⟩,⟨10,some 21⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x18576 : Deny 1000000000000000000 11 bp11x18576 :=
  sound (by decide) (by decide) 14 63545850756566713657727165465257945271873421011345596311848204807819276593651228261160748931663049 (tail:=0) (by decide +kernel)
private def bp11x18745 : B := ![⟨46,some 93⟩,⟨10,some 13⟩,⟨22,none⟩]
private def bp11x18746 : B := ![⟨46,some 61⟩,⟨10,some 13⟩,⟨22,none⟩]
private def bp11x18747 : B := ![⟨46,some 61⟩,⟨10,some 11⟩,⟨22,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x18747 : Deny 1000000000000000000 11 bp11x18747 :=
  sound (by decide) (by decide) 23 175031283186009236513357925390618046574120570493665618670488542717241459449391453145674184739044285187225814154448794661948124335474231507 (tail:=0) (by decide +kernel)
private def bp11x18984 : B := ![⟨46,some 61⟩,⟨12,some 13⟩,⟨22,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x18984 : Deny 1000000000000000000 11 bp11x18984 :=
  sound (by decide) (by decide) 15 758746085428798594336042429246388191053994858643821854126648881872566910144276033596887717619716927074399988282878222680114163210940050419773529070074719330386801644087 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x18746 : Deny 1000000000000000000 11 bp11x18746 := by
  apply split bp11x18746 1
  · rw [show leftB bp11x18746 1=bp11x18747 by funext i; fin_cases i <;> rfl]; exact p11x18747
  · rw [show rightB bp11x18746 1=bp11x18984 by funext i; fin_cases i <;> rfl]; exact p11x18984
private def bp11x19273 : B := ![⟨62,some 93⟩,⟨10,some 13⟩,⟨22,none⟩]
private def bp11x19274 : B := ![⟨62,some 93⟩,⟨10,some 11⟩,⟨22,none⟩]
private def bp11x19275 : B := ![⟨62,some 93⟩,⟨10,some 11⟩,⟨22,some 45⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x19275 : Deny 1000000000000000000 11 bp11x19275 :=
  sound (by decide) (by decide) 13 1084705614238886497476977312965380640135279736832062267611296065416305584120897100271586363748236864583948645517 (tail:=0) (by decide +kernel)
private def bp11x19468 : B := ![⟨62,some 93⟩,⟨10,some 11⟩,⟨46,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x19468 : Deny 1000000000000000000 11 bp11x19468 :=
  sound (by decide) (by decide) 23 1205554687701101885249018447790640858817352839696677285920812529799047867490251016996592747607573721004381074893879572584719928267723036630983492428406868376732798382888350260179923790097840750070035661232724527266539275832429 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x19274 : Deny 1000000000000000000 11 bp11x19274 := by
  apply split bp11x19274 2
  · rw [show leftB bp11x19274 2=bp11x19275 by funext i; fin_cases i <;> rfl]; exact p11x19275
  · rw [show rightB bp11x19274 2=bp11x19468 by funext i; fin_cases i <;> rfl]; exact p11x19468
private def bp11x19851 : B := ![⟨62,some 93⟩,⟨12,some 13⟩,⟨22,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x19851 : Deny 1000000000000000000 11 bp11x19851 :=
  sound (by decide) (by decide) 12 3678976185629016268215 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x19273 : Deny 1000000000000000000 11 bp11x19273 := by
  apply split bp11x19273 1
  · rw [show leftB bp11x19273 1=bp11x19274 by funext i; fin_cases i <;> rfl]; exact p11x19274
  · rw [show rightB bp11x19273 1=bp11x19851 by funext i; fin_cases i <;> rfl]; exact p11x19851
set_option maxRecDepth 100000 in
private theorem p11x18745 : Deny 1000000000000000000 11 bp11x18745 := by
  apply split bp11x18745 0
  · rw [show leftB bp11x18745 0=bp11x18746 by funext i; fin_cases i <;> rfl]; exact p11x18746
  · rw [show rightB bp11x18745 0=bp11x19273 by funext i; fin_cases i <;> rfl]; exact p11x19273
set_option maxRecDepth 100000 in
private theorem p11x18575 : Deny 1000000000000000000 11 bp11x18575 := by
  apply split bp11x18575 2
  · rw [show leftB bp11x18575 2=bp11x18576 by funext i; fin_cases i <;> rfl]; exact p11x18576
  · rw [show rightB bp11x18575 2=bp11x18745 by funext i; fin_cases i <;> rfl]; exact p11x18745
private def bp11x19896 : B := ![⟨94,none⟩,⟨10,some 13⟩,⟨10,none⟩]
private def bp11x19897 : B := ![⟨94,none⟩,⟨10,some 13⟩,⟨10,some 21⟩]
private def bp11x19898 : B := ![⟨94,some 189⟩,⟨10,some 13⟩,⟨10,some 21⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x19898 : Deny 1000000000000000000 11 bp11x19898 :=
  sound (by decide) (by decide) 15 65382734254579825974368338510339242724067631288568160498346109834820184418784693349299445707858691270196682429559201064662098641437998177148998591310 (tail:=0) (by decide +kernel)
private def bp11x20155 : B := ![⟨190,none⟩,⟨10,some 13⟩,⟨10,some 21⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x20155 : Deny 1000000000000000000 11 bp11x20155 :=
  sound (by decide) (by decide) 25 5116050507272934461436136461671738648195754580007138317293194122228728934746033791440609770255838787878477932341537278826740034238780448359783671320793843969521915148769759911098212033366542666713363845854 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x19897 : Deny 1000000000000000000 11 bp11x19897 := by
  apply split bp11x19897 0
  · rw [show leftB bp11x19897 0=bp11x19898 by funext i; fin_cases i <;> rfl]; exact p11x19898
  · rw [show rightB bp11x19897 0=bp11x20155 by funext i; fin_cases i <;> rfl]; exact p11x20155
private def bp11x20506 : B := ![⟨94,none⟩,⟨10,some 13⟩,⟨22,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x20506 : Deny 1000000000000000000 11 bp11x20506 :=
  sound (by decide) (by decide) 16 716571672002158526209936733200321670738779879459057095649456192056187171887982260198265 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x19896 : Deny 1000000000000000000 11 bp11x19896 := by
  apply split bp11x19896 2
  · rw [show leftB bp11x19896 2=bp11x19897 by funext i; fin_cases i <;> rfl]; exact p11x19897
  · rw [show rightB bp11x19896 2=bp11x20506 by funext i; fin_cases i <;> rfl]; exact p11x20506
set_option maxRecDepth 100000 in
private theorem p11x18574 : Deny 1000000000000000000 11 bp11x18574 := by
  apply split bp11x18574 0
  · rw [show leftB bp11x18574 0=bp11x18575 by funext i; fin_cases i <;> rfl]; exact p11x18575
  · rw [show rightB bp11x18574 0=bp11x19896 by funext i; fin_cases i <;> rfl]; exact p11x19896
private def bp11x20663 : B := ![⟨46,none⟩,⟨14,some 21⟩,⟨10,none⟩]
private def bp11x20664 : B := ![⟨46,some 93⟩,⟨14,some 21⟩,⟨10,none⟩]
private def bp11x20665 : B := ![⟨46,some 93⟩,⟨14,some 21⟩,⟨10,some 21⟩]
private def bp11x20666 : B := ![⟨46,some 93⟩,⟨14,some 16⟩,⟨10,some 21⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x20666 : Deny 1000000000000000000 11 bp11x20666 :=
  sound (by decide) (by decide) 13 15663497312932069745501703984201705775177842743754912490215664143692648254363497574201236573587510341755321016429725642422890868317388693689796445403131991896605 (tail:=0) (by decide +kernel)
private def bp11x20941 : B := ![⟨46,some 93⟩,⟨17,some 21⟩,⟨10,some 21⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x20941 : Deny 1000000000000000000 11 bp11x20941 :=
  sound (by decide) (by decide) 12 833999470639079827968093407799563146280960493971205081187317552011960380902607721373 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x20665 : Deny 1000000000000000000 11 bp11x20665 := by
  apply split bp11x20665 1
  · rw [show leftB bp11x20665 1=bp11x20666 by funext i; fin_cases i <;> rfl]; exact p11x20666
  · rw [show rightB bp11x20665 1=bp11x20941 by funext i; fin_cases i <;> rfl]; exact p11x20941
private def bp11x21090 : B := ![⟨46,some 93⟩,⟨14,some 21⟩,⟨22,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x21090 : Deny 1000000000000000000 11 bp11x21090 :=
  sound (by decide) (by decide) 13 4208810118881968142998390 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x20664 : Deny 1000000000000000000 11 bp11x20664 := by
  apply split bp11x20664 2
  · rw [show leftB bp11x20664 2=bp11x20665 by funext i; fin_cases i <;> rfl]; exact p11x20665
  · rw [show rightB bp11x20664 2=bp11x21090 by funext i; fin_cases i <;> rfl]; exact p11x21090
private def bp11x21143 : B := ![⟨94,none⟩,⟨14,some 21⟩,⟨10,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x21143 : Deny 1000000000000000000 11 bp11x21143 :=
  sound (by decide) (by decide) 14 289896923 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x20663 : Deny 1000000000000000000 11 bp11x20663 := by
  apply split bp11x20663 0
  · rw [show leftB bp11x20663 0=bp11x20664 by funext i; fin_cases i <;> rfl]; exact p11x20664
  · rw [show rightB bp11x20663 0=bp11x21143 by funext i; fin_cases i <;> rfl]; exact p11x21143
set_option maxRecDepth 100000 in
private theorem p11x18573 : Deny 1000000000000000000 11 bp11x18573 := by
  apply split bp11x18573 1
  · rw [show leftB bp11x18573 1=bp11x18574 by funext i; fin_cases i <;> rfl]; exact p11x18574
  · rw [show rightB bp11x18573 1=bp11x20663 by funext i; fin_cases i <;> rfl]; exact p11x20663
set_option maxRecDepth 100000 in
private theorem p11x17713 : Deny 1000000000000000000 11 bp11x17713 := by
  apply split bp11x17713 2
  · rw [show leftB bp11x17713 2=bp11x17714 by funext i; fin_cases i <;> rfl]; exact p11x17714
  · rw [show rightB bp11x17713 2=bp11x18573 by funext i; fin_cases i <;> rfl]; exact p11x18573
set_option maxRecDepth 100000 in
private theorem p11x16025 : Deny 1000000000000000000 11 bp11x16025 := by
  apply split bp11x16025 0
  · rw [show leftB bp11x16025 0=bp11x16026 by funext i; fin_cases i <;> rfl]; exact p11x16026
  · rw [show rightB bp11x16025 0=bp11x17713 by funext i; fin_cases i <;> rfl]; exact p11x17713
private def bp11x21170 : B := ![⟨22,none⟩,⟨22,none⟩,⟨4,none⟩]
private def bp11x21171 : B := ![⟨22,some 45⟩,⟨22,none⟩,⟨4,none⟩]
private def bp11x21172 : B := ![⟨22,some 45⟩,⟨22,none⟩,⟨4,some 9⟩]
private def bp11x21173 : B := ![⟨22,some 29⟩,⟨22,none⟩,⟨4,some 9⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x21173 : Deny 1000000000000000000 11 bp11x21173 :=
  sound (by decide) (by decide) 24 668604182621606665518908656772377172075483017794979236375248735605758808363059622638715323789683373890491837434833292194358745945498284721771645196318604788589226664818895162172768809560377738027721378704705074 (tail:=0) (by decide +kernel)
private def bp11x21530 : B := ![⟨30,some 45⟩,⟨22,none⟩,⟨4,some 9⟩]
private def bp11x21531 : B := ![⟨30,some 45⟩,⟨22,some 45⟩,⟨4,some 9⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x21531 : Deny 1000000000000000000 11 bp11x21531 :=
  sound (by decide) (by decide) 15 323296111495650701112137783644497298444652782551678650340423638569027445926493710620747659194237298620323598063826394487612687010660519994074434659 (tail:=0) (by decide +kernel)
private def bp11x21782 : B := ![⟨30,some 45⟩,⟨46,none⟩,⟨4,some 9⟩]
private def bp11x21783 : B := ![⟨30,some 45⟩,⟨46,none⟩,⟨4,some 5⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x21783 : Deny 1000000000000000000 11 bp11x21783 :=
  sound (by decide) (by decide) 20 329189315510935032033218535035330079689022203174530542026700038991611603805334113324546407430640449635483838470395807942 (tail:=0) (by decide +kernel)
private def bp11x21990 : B := ![⟨30,some 45⟩,⟨46,none⟩,⟨6,some 9⟩]
private def bp11x21991 : B := ![⟨30,some 45⟩,⟨46,some 93⟩,⟨6,some 9⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x21991 : Deny 1000000000000000000 11 bp11x21991 :=
  sound (by decide) (by decide) 13 489098009344503167595294568990332292422342043148480579351317817315766986081771532330404080024310837464109841548856823012748779894909257589907758812269 (tail:=0) (by decide +kernel)
private def bp11x22248 : B := ![⟨30,some 45⟩,⟨94,none⟩,⟨6,some 9⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x22248 : Deny 1000000000000000000 11 bp11x22248 :=
  sound (by decide) (by decide) 22 313860723054543580667056088896169867299989173690860631211554472874247961812149738524244031784446859763762110948205 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x21990 : Deny 1000000000000000000 11 bp11x21990 := by
  apply split bp11x21990 1
  · rw [show leftB bp11x21990 1=bp11x21991 by funext i; fin_cases i <;> rfl]; exact p11x21991
  · rw [show rightB bp11x21990 1=bp11x22248 by funext i; fin_cases i <;> rfl]; exact p11x22248
set_option maxRecDepth 100000 in
private theorem p11x21782 : Deny 1000000000000000000 11 bp11x21782 := by
  apply split bp11x21782 2
  · rw [show leftB bp11x21782 2=bp11x21783 by funext i; fin_cases i <;> rfl]; exact p11x21783
  · rw [show rightB bp11x21782 2=bp11x21990 by funext i; fin_cases i <;> rfl]; exact p11x21990
set_option maxRecDepth 100000 in
private theorem p11x21530 : Deny 1000000000000000000 11 bp11x21530 := by
  apply split bp11x21530 1
  · rw [show leftB bp11x21530 1=bp11x21531 by funext i; fin_cases i <;> rfl]; exact p11x21531
  · rw [show rightB bp11x21530 1=bp11x21782 by funext i; fin_cases i <;> rfl]; exact p11x21782
set_option maxRecDepth 100000 in
private theorem p11x21172 : Deny 1000000000000000000 11 bp11x21172 := by
  apply split bp11x21172 0
  · rw [show leftB bp11x21172 0=bp11x21173 by funext i; fin_cases i <;> rfl]; exact p11x21173
  · rw [show rightB bp11x21172 0=bp11x21530 by funext i; fin_cases i <;> rfl]; exact p11x21530
private def bp11x22449 : B := ![⟨22,some 45⟩,⟨22,none⟩,⟨10,none⟩]
private def bp11x22450 : B := ![⟨22,some 29⟩,⟨22,none⟩,⟨10,none⟩]
private def bp11x22451 : B := ![⟨22,some 29⟩,⟨22,some 45⟩,⟨10,none⟩]
private def bp11x22452 : B := ![⟨22,some 29⟩,⟨22,some 45⟩,⟨10,some 21⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x22452 : Deny 1000000000000000000 11 bp11x22452 :=
  sound (by decide) (by decide) 14 56916030870436477723228723701139162117843462384313911690971015030604553207337654906204832350010373889977237099254320433403340491184766910389343243176974229846863979096383285327428108853576383372613437638 (tail:=0) (by decide +kernel)
private def bp11x22797 : B := ![⟨22,some 29⟩,⟨22,some 45⟩,⟨22,none⟩]
private def bp11x22798 : B := ![⟨22,some 29⟩,⟨22,some 29⟩,⟨22,none⟩]
private def bp11x22799 : B := ![⟨22,some 25⟩,⟨22,some 29⟩,⟨22,none⟩]
private def bp11x22800 : B := ![⟨22,some 25⟩,⟨22,some 29⟩,⟨22,some 45⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x22800 : Deny 1000000000000000000 11 bp11x22800 :=
  sound (by decide) (by decide) 12 60441696175748792234770 (tail:=0) (by decide +kernel)
private def bp11x22841 : B := ![⟨22,some 25⟩,⟨22,some 29⟩,⟨46,none⟩]
private def bp11x22842 : B := ![⟨22,some 25⟩,⟨22,some 25⟩,⟨46,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x22842 : Deny 1000000000000000000 11 bp11x22842 :=
  sound (by decide) (by decide) 21 37795403027162908218827046198350788336128653137001687069875649903375763315202218650770558648718013226818023118671960428296697794291059853 (tail:=0) (by decide +kernel)
private def bp11x23079 : B := ![⟨22,some 25⟩,⟨26,some 29⟩,⟨46,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x23079 : Deny 1000000000000000000 11 bp11x23079 :=
  sound (by decide) (by decide) 19 122052452889703452102329988277519815560621570541728168088109981084936554384086076061181111167473919894005420605 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x22841 : Deny 1000000000000000000 11 bp11x22841 := by
  apply split bp11x22841 1
  · rw [show leftB bp11x22841 1=bp11x22842 by funext i; fin_cases i <;> rfl]; exact p11x22842
  · rw [show rightB bp11x22841 1=bp11x23079 by funext i; fin_cases i <;> rfl]; exact p11x23079
set_option maxRecDepth 100000 in
private theorem p11x22799 : Deny 1000000000000000000 11 bp11x22799 := by
  apply split bp11x22799 2
  · rw [show leftB bp11x22799 2=bp11x22800 by funext i; fin_cases i <;> rfl]; exact p11x22800
  · rw [show rightB bp11x22799 2=bp11x22841 by funext i; fin_cases i <;> rfl]; exact p11x22841
private def bp11x23270 : B := ![⟨26,some 29⟩,⟨22,some 29⟩,⟨22,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x23270 : Deny 1000000000000000000 11 bp11x23270 :=
  sound (by decide) (by decide) 14 154598599358377716153693983496271719578763150690527058871122287036523470632525624920641942148995229657771651278626631649237623164259981670523 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x22798 : Deny 1000000000000000000 11 bp11x22798 := by
  apply split bp11x22798 0
  · rw [show leftB bp11x22798 0=bp11x22799 by funext i; fin_cases i <;> rfl]; exact p11x22799
  · rw [show rightB bp11x22798 0=bp11x23270 by funext i; fin_cases i <;> rfl]; exact p11x23270
private def bp11x23513 : B := ![⟨22,some 29⟩,⟨30,some 45⟩,⟨22,none⟩]
private def bp11x23514 : B := ![⟨22,some 25⟩,⟨30,some 45⟩,⟨22,none⟩]
private def bp11x23515 : B := ![⟨22,some 25⟩,⟨30,some 45⟩,⟨22,some 45⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x23515 : Deny 1000000000000000000 11 bp11x23515 :=
  sound (by decide) (by decide) 13 199116604896568220329353217503881987739398659568086634941940968013058979118262669258033311705692414447453866762935540758602528431910948309542112851908190827062 (tail:=0) (by decide +kernel)
private def bp11x23786 : B := ![⟨22,some 25⟩,⟨30,some 45⟩,⟨46,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x23786 : Deny 1000000000000000000 11 bp11x23786 :=
  sound (by decide) (by decide) 15 1764458294104303291177415046702888709956269926122439469923463429696584477231030 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x23514 : Deny 1000000000000000000 11 bp11x23514 := by
  apply split bp11x23514 2
  · rw [show leftB bp11x23514 2=bp11x23515 by funext i; fin_cases i <;> rfl]; exact p11x23515
  · rw [show rightB bp11x23514 2=bp11x23786 by funext i; fin_cases i <;> rfl]; exact p11x23786
private def bp11x23927 : B := ![⟨26,some 29⟩,⟨30,some 45⟩,⟨22,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x23927 : Deny 1000000000000000000 11 bp11x23927 :=
  sound (by decide) (by decide) 12 15047253627 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x23513 : Deny 1000000000000000000 11 bp11x23513 := by
  apply split bp11x23513 0
  · rw [show leftB bp11x23513 0=bp11x23514 by funext i; fin_cases i <;> rfl]; exact p11x23514
  · rw [show rightB bp11x23513 0=bp11x23927 by funext i; fin_cases i <;> rfl]; exact p11x23927
set_option maxRecDepth 100000 in
private theorem p11x22797 : Deny 1000000000000000000 11 bp11x22797 := by
  apply split bp11x22797 1
  · rw [show leftB bp11x22797 1=bp11x22798 by funext i; fin_cases i <;> rfl]; exact p11x22798
  · rw [show rightB bp11x22797 1=bp11x23513 by funext i; fin_cases i <;> rfl]; exact p11x23513
set_option maxRecDepth 100000 in
private theorem p11x22451 : Deny 1000000000000000000 11 bp11x22451 := by
  apply split bp11x22451 2
  · rw [show leftB bp11x22451 2=bp11x22452 by funext i; fin_cases i <;> rfl]; exact p11x22452
  · rw [show rightB bp11x22451 2=bp11x22797 by funext i; fin_cases i <;> rfl]; exact p11x22797
private def bp11x23954 : B := ![⟨22,some 29⟩,⟨46,none⟩,⟨10,none⟩]
private def bp11x23955 : B := ![⟨22,some 29⟩,⟨46,none⟩,⟨10,some 21⟩]
private def bp11x23956 : B := ![⟨22,some 29⟩,⟨46,some 93⟩,⟨10,some 21⟩]
private def bp11x23957 : B := ![⟨22,some 25⟩,⟨46,some 93⟩,⟨10,some 21⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x23957 : Deny 1000000000000000000 11 bp11x23957 :=
  sound (by decide) (by decide) 13 487218716883850546201142391619595853187547426092066296266946020900455512618918258666448461627112815922520284099247300357207162847308987958312039344145629173588763 (tail:=0) (by decide +kernel)
private def bp11x24234 : B := ![⟨26,some 29⟩,⟨46,some 93⟩,⟨10,some 21⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x24234 : Deny 1000000000000000000 11 bp11x24234 :=
  sound (by decide) (by decide) 12 15668483537066957830771697811210113028886390633387348432335483 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x23956 : Deny 1000000000000000000 11 bp11x23956 := by
  apply split bp11x23956 0
  · rw [show leftB bp11x23956 0=bp11x23957 by funext i; fin_cases i <;> rfl]; exact p11x23957
  · rw [show rightB bp11x23956 0=bp11x24234 by funext i; fin_cases i <;> rfl]; exact p11x24234
private def bp11x24343 : B := ![⟨22,some 29⟩,⟨94,none⟩,⟨10,some 21⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x24343 : Deny 1000000000000000000 11 bp11x24343 :=
  sound (by decide) (by decide) 19 7569305669495630518105797051740833365066706839951810889630945961116723343280923675440240750973816899453471910353669909204425543472078670701 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x23955 : Deny 1000000000000000000 11 bp11x23955 := by
  apply split bp11x23955 1
  · rw [show leftB bp11x23955 1=bp11x23956 by funext i; fin_cases i <;> rfl]; exact p11x23956
  · rw [show rightB bp11x23955 1=bp11x24343 by funext i; fin_cases i <;> rfl]; exact p11x24343
private def bp11x24586 : B := ![⟨22,some 29⟩,⟨46,none⟩,⟨22,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x24586 : Deny 1000000000000000000 11 bp11x24586 :=
  sound (by decide) (by decide) 15 874273921026153384399830904246 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x23954 : Deny 1000000000000000000 11 bp11x23954 := by
  apply split bp11x23954 2
  · rw [show leftB bp11x23954 2=bp11x23955 by funext i; fin_cases i <;> rfl]; exact p11x23955
  · rw [show rightB bp11x23954 2=bp11x24586 by funext i; fin_cases i <;> rfl]; exact p11x24586
set_option maxRecDepth 100000 in
private theorem p11x22450 : Deny 1000000000000000000 11 bp11x22450 := by
  apply split bp11x22450 1
  · rw [show leftB bp11x22450 1=bp11x22451 by funext i; fin_cases i <;> rfl]; exact p11x22451
  · rw [show rightB bp11x22450 1=bp11x23954 by funext i; fin_cases i <;> rfl]; exact p11x23954
private def bp11x24649 : B := ![⟨30,some 45⟩,⟨22,none⟩,⟨10,none⟩]
private def bp11x24650 : B := ![⟨30,some 45⟩,⟨22,some 45⟩,⟨10,none⟩]
private def bp11x24651 : B := ![⟨30,some 45⟩,⟨22,some 45⟩,⟨10,some 21⟩]
private def bp11x24652 : B := ![⟨30,some 45⟩,⟨22,some 29⟩,⟨10,some 21⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x24652 : Deny 1000000000000000000 11 bp11x24652 :=
  sound (by decide) (by decide) 13 134365270304300027691296166469982774595050474474953694690220652930166541492984107692439570185013652468236548571559243117772681688469837176680565447828854358440818039982283614985448416179523539895312731293 (tail:=0) (by decide +kernel)
private def bp11x24999 : B := ![⟨30,some 45⟩,⟨30,some 45⟩,⟨10,some 21⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x24999 : Deny 1000000000000000000 11 bp11x24999 :=
  sound (by decide) (by decide) 12 4133111782329194895024830733304279723423727337148023600540161974313248290679573357 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x24651 : Deny 1000000000000000000 11 bp11x24651 := by
  apply split bp11x24651 1
  · rw [show leftB bp11x24651 1=bp11x24652 by funext i; fin_cases i <;> rfl]; exact p11x24652
  · rw [show rightB bp11x24651 1=bp11x24999 by funext i; fin_cases i <;> rfl]; exact p11x24999
private def bp11x25144 : B := ![⟨30,some 45⟩,⟨22,some 45⟩,⟨22,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x25144 : Deny 1000000000000000000 11 bp11x25144 :=
  sound (by decide) (by decide) 13 1095124059549302 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x24650 : Deny 1000000000000000000 11 bp11x24650 := by
  apply split bp11x24650 2
  · rw [show leftB bp11x24650 2=bp11x24651 by funext i; fin_cases i <;> rfl]; exact p11x24651
  · rw [show rightB bp11x24650 2=bp11x25144 by funext i; fin_cases i <;> rfl]; exact p11x25144
private def bp11x25181 : B := ![⟨30,some 45⟩,⟨46,none⟩,⟨10,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x25181 : Deny 1000000000000000000 11 bp11x25181 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x24649 : Deny 1000000000000000000 11 bp11x24649 := by
  apply split bp11x24649 1
  · rw [show leftB bp11x24649 1=bp11x24650 by funext i; fin_cases i <;> rfl]; exact p11x24650
  · rw [show rightB bp11x24649 1=bp11x25181 by funext i; fin_cases i <;> rfl]; exact p11x25181
set_option maxRecDepth 100000 in
private theorem p11x22449 : Deny 1000000000000000000 11 bp11x22449 := by
  apply split bp11x22449 0
  · rw [show leftB bp11x22449 0=bp11x22450 by funext i; fin_cases i <;> rfl]; exact p11x22450
  · rw [show rightB bp11x22449 0=bp11x24649 by funext i; fin_cases i <;> rfl]; exact p11x24649
set_option maxRecDepth 100000 in
private theorem p11x21171 : Deny 1000000000000000000 11 bp11x21171 := by
  apply split bp11x21171 2
  · rw [show leftB bp11x21171 2=bp11x21172 by funext i; fin_cases i <;> rfl]; exact p11x21172
  · rw [show rightB bp11x21171 2=bp11x22449 by funext i; fin_cases i <;> rfl]; exact p11x22449
private def bp11x25182 : B := ![⟨46,none⟩,⟨22,none⟩,⟨4,none⟩]
private def bp11x25183 : B := ![⟨46,none⟩,⟨22,none⟩,⟨4,some 9⟩]
private def bp11x25184 : B := ![⟨46,none⟩,⟨22,some 45⟩,⟨4,some 9⟩]
private def bp11x25185 : B := ![⟨46,some 93⟩,⟨22,some 45⟩,⟨4,some 9⟩]
private def bp11x25186 : B := ![⟨46,some 93⟩,⟨22,some 45⟩,⟨4,some 5⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x25186 : Deny 1000000000000000000 11 bp11x25186 :=
  sound (by decide) (by decide) 13 739894909286926253472095405627408178793381535990325287784396911805921894550714221766 (tail:=0) (by decide +kernel)
private def bp11x25333 : B := ![⟨46,some 93⟩,⟨22,some 45⟩,⟨6,some 9⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x25333 : Deny 1000000000000000000 11 bp11x25333 :=
  sound (by decide) (by decide) 13 40178841464968446871585897421961231406423902987426152099710848723282049452239310910195696090338987027211361588259298245636915159930532690675572522645907225222944545612544815900744925154378153489150582 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x25185 : Deny 1000000000000000000 11 bp11x25185 := by
  apply split bp11x25185 2
  · rw [show leftB bp11x25185 2=bp11x25186 by funext i; fin_cases i <;> rfl]; exact p11x25186
  · rw [show rightB bp11x25185 2=bp11x25333 by funext i; fin_cases i <;> rfl]; exact p11x25333
private def bp11x25674 : B := ![⟨94,none⟩,⟨22,some 45⟩,⟨4,some 9⟩]
private def bp11x25675 : B := ![⟨94,none⟩,⟨22,some 45⟩,⟨4,some 5⟩]
private def bp11x25676 : B := ![⟨94,none⟩,⟨22,some 29⟩,⟨4,some 5⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x25676 : Deny 1000000000000000000 11 bp11x25676 :=
  sound (by decide) (by decide) 24 4652757773653738521261178693038865124871439087104774454130763652776551690598996489858413024788271391739702442860688270586932485558217496098966568895530282401829484297095713437486223353599788621 (tail:=0) (by decide +kernel)
private def bp11x26007 : B := ![⟨94,none⟩,⟨30,some 45⟩,⟨4,some 5⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x26007 : Deny 1000000000000000000 11 bp11x26007 :=
  sound (by decide) (by decide) 15 164187434754347864566063356576643182620521368212390910132529946409738328240259510240886189993891295589146953327773 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x25675 : Deny 1000000000000000000 11 bp11x25675 := by
  apply split bp11x25675 1
  · rw [show leftB bp11x25675 1=bp11x25676 by funext i; fin_cases i <;> rfl]; exact p11x25676
  · rw [show rightB bp11x25675 1=bp11x26007 by funext i; fin_cases i <;> rfl]; exact p11x26007
private def bp11x26206 : B := ![⟨94,none⟩,⟨22,some 45⟩,⟨6,some 9⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x26206 : Deny 1000000000000000000 11 bp11x26206 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x25674 : Deny 1000000000000000000 11 bp11x25674 := by
  apply split bp11x25674 2
  · rw [show leftB bp11x25674 2=bp11x25675 by funext i; fin_cases i <;> rfl]; exact p11x25675
  · rw [show rightB bp11x25674 2=bp11x26206 by funext i; fin_cases i <;> rfl]; exact p11x26206
set_option maxRecDepth 100000 in
private theorem p11x25184 : Deny 1000000000000000000 11 bp11x25184 := by
  apply split bp11x25184 0
  · rw [show leftB bp11x25184 0=bp11x25185 by funext i; fin_cases i <;> rfl]; exact p11x25185
  · rw [show rightB bp11x25184 0=bp11x25674 by funext i; fin_cases i <;> rfl]; exact p11x25674
private def bp11x26207 : B := ![⟨46,none⟩,⟨46,none⟩,⟨4,some 9⟩]
private def bp11x26208 : B := ![⟨46,some 93⟩,⟨46,none⟩,⟨4,some 9⟩]
private def bp11x26209 : B := ![⟨46,some 93⟩,⟨46,none⟩,⟨4,some 5⟩]
private def bp11x26210 : B := ![⟨46,some 61⟩,⟨46,none⟩,⟨4,some 5⟩]
private def bp11x26211 : B := ![⟨46,some 61⟩,⟨46,some 93⟩,⟨4,some 5⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x26211 : Deny 1000000000000000000 11 bp11x26211 :=
  sound (by decide) (by decide) 12 1089905787328743792259431548887075721450191457351534401364038243 (tail:=0) (by decide +kernel)
private def bp11x26324 : B := ![⟨46,some 61⟩,⟨94,none⟩,⟨4,some 5⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x26324 : Deny 1000000000000000000 11 bp11x26324 :=
  sound (by decide) (by decide) 23 3000017315707987537834508110803351882240385911198828203518967693011465323686090121200356705104356791743115771100648795860655548472134544906367205335661733940470088133552008235345290634637585829430811 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x26210 : Deny 1000000000000000000 11 bp11x26210 := by
  apply split bp11x26210 1
  · rw [show leftB bp11x26210 1=bp11x26211 by funext i; fin_cases i <;> rfl]; exact p11x26211
  · rw [show rightB bp11x26210 1=bp11x26324 by funext i; fin_cases i <;> rfl]; exact p11x26324
private def bp11x26665 : B := ![⟨62,some 93⟩,⟨46,none⟩,⟨4,some 5⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x26665 : Deny 1000000000000000000 11 bp11x26665 :=
  sound (by decide) (by decide) 14 1648140014784522208781935306401296652802354768534569086484489465358205805011562542993610062961486868340819479638059420538543169919649065605230 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x26209 : Deny 1000000000000000000 11 bp11x26209 := by
  apply split bp11x26209 0
  · rw [show leftB bp11x26209 0=bp11x26210 by funext i; fin_cases i <;> rfl]; exact p11x26210
  · rw [show rightB bp11x26209 0=bp11x26665 by funext i; fin_cases i <;> rfl]; exact p11x26665
private def bp11x26912 : B := ![⟨46,some 93⟩,⟨46,none⟩,⟨6,some 9⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x26912 : Deny 1000000000000000000 11 bp11x26912 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x26208 : Deny 1000000000000000000 11 bp11x26208 := by
  apply split bp11x26208 2
  · rw [show leftB bp11x26208 2=bp11x26209 by funext i; fin_cases i <;> rfl]; exact p11x26209
  · rw [show rightB bp11x26208 2=bp11x26912 by funext i; fin_cases i <;> rfl]; exact p11x26912
private def bp11x26913 : B := ![⟨94,none⟩,⟨46,none⟩,⟨4,some 9⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x26913 : Deny 1000000000000000000 11 bp11x26913 :=
  sound (by decide) (by decide) 14 26842843 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x26207 : Deny 1000000000000000000 11 bp11x26207 := by
  apply split bp11x26207 0
  · rw [show leftB bp11x26207 0=bp11x26208 by funext i; fin_cases i <;> rfl]; exact p11x26208
  · rw [show rightB bp11x26207 0=bp11x26913 by funext i; fin_cases i <;> rfl]; exact p11x26913
set_option maxRecDepth 100000 in
private theorem p11x25183 : Deny 1000000000000000000 11 bp11x25183 := by
  apply split bp11x25183 1
  · rw [show leftB bp11x25183 1=bp11x25184 by funext i; fin_cases i <;> rfl]; exact p11x25184
  · rw [show rightB bp11x25183 1=bp11x26207 by funext i; fin_cases i <;> rfl]; exact p11x26207
private def bp11x26940 : B := ![⟨46,none⟩,⟨22,none⟩,⟨10,none⟩]
set_option maxHeartbeats 10000000 in
set_option maxRecDepth 100000 in
private theorem p11x26940 : Deny 1000000000000000000 11 bp11x26940 :=
  sound (by decide) (by decide) 1 0 (tail:=0) (by decide +kernel)
set_option maxRecDepth 100000 in
private theorem p11x25182 : Deny 1000000000000000000 11 bp11x25182 := by
  apply split bp11x25182 2
  · rw [show leftB bp11x25182 2=bp11x25183 by funext i; fin_cases i <;> rfl]; exact p11x25183
  · rw [show rightB bp11x25182 2=bp11x26940 by funext i; fin_cases i <;> rfl]; exact p11x26940
set_option maxRecDepth 100000 in
private theorem p11x21170 : Deny 1000000000000000000 11 bp11x21170 := by
  apply split bp11x21170 0
  · rw [show leftB bp11x21170 0=bp11x21171 by funext i; fin_cases i <;> rfl]; exact p11x21171
  · rw [show rightB bp11x21170 0=bp11x25182 by funext i; fin_cases i <;> rfl]; exact p11x25182
set_option maxRecDepth 100000 in
private theorem p11x16024 : Deny 1000000000000000000 11 bp11x16024 := by
  apply split bp11x16024 1
  · rw [show leftB bp11x16024 1=bp11x16025 by funext i; fin_cases i <;> rfl]; exact p11x16025
  · rw [show rightB bp11x16024 1=bp11x21170 by funext i; fin_cases i <;> rfl]; exact p11x21170
set_option maxRecDepth 100000 in
private theorem p11x6220 : Deny 1000000000000000000 11 bp11x6220 := by
  apply split bp11x6220 0
  · rw [show leftB bp11x6220 0=bp11x6221 by funext i; fin_cases i <;> rfl]; exact p11x6221
  · rw [show rightB bp11x6220 0=bp11x16024 by funext i; fin_cases i <;> rfl]; exact p11x16024
set_option maxRecDepth 100000 in
private theorem p11x3802 : Deny 1000000000000000000 11 bp11x3802 := by
  apply split bp11x3802 2
  · rw [show leftB bp11x3802 2=bp11x3803 by funext i; fin_cases i <;> rfl]; exact p11x3803
  · rw [show rightB bp11x3802 2=bp11x6220 by funext i; fin_cases i <;> rfl]; exact p11x6220
set_option maxRecDepth 100000 in
private theorem p11x6 : Deny 1000000000000000000 11 bp11x6 := by
  apply split bp11x6 1
  · rw [show leftB bp11x6 1=bp11x7 by funext i; fin_cases i <;> rfl]; exact p11x7
  · rw [show rightB bp11x6 1=bp11x3802 by funext i; fin_cases i <;> rfl]; exact p11x3802
set_option maxRecDepth 100000 in
private theorem p11x4 : Deny 1000000000000000000 11 bp11x4 := by
  apply split bp11x4 0
  · rw [show leftB bp11x4 0=bp11x5 by funext i; fin_cases i <;> rfl]; exact p11x5
  · rw [show rightB bp11x4 0=bp11x6 by funext i; fin_cases i <;> rfl]; exact p11x6
set_option maxRecDepth 100000 in
private theorem p11x2 : Deny 1000000000000000000 11 bp11x2 := by
  apply split bp11x2 1
  · rw [show leftB bp11x2 1=bp11x3 by funext i; fin_cases i <;> rfl]; exact p11x3
  · rw [show rightB bp11x2 1=bp11x4 by funext i; fin_cases i <;> rfl]; exact p11x4
set_option maxRecDepth 100000 in
theorem p11x0 : Deny 1000000000000000000 11 start := by
  apply split start 0
  · rw [show leftB start 0=bp11x1 by funext i; fin_cases i <;> rfl]; exact p11x1
  · rw [show rightB start 0=bp11x2 by funext i; fin_cases i <;> rfl]; exact p11x2
end OMA.Large245212
