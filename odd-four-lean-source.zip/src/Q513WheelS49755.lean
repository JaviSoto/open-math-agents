import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S49755
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b49755 : Box := ![⟨127,190⟩,⟨21,24⟩,⟨31,62⟩,⟨1,74⟩,⟨479,958⟩]
theorem deny5_13 : Deny 5 13 ![⟨127,190⟩,⟨21,24⟩,⟨31,62⟩,⟨1,74⟩,⟨479,958⟩] := by
  have e49755 : Deny 5 13 b49755 := by
    apply closeAction rule_sound _ _ 64 [0xe152830f8dc80d9e37da32232430f8de325de37da32231e3578dc32030c88c90c32030f8dc88c98c72e32631e32152a3,0x8c78d5e3709d0a68042b8de7109e379c3e270e31e31c82e325d755543e03e080c754a54a2492827555550c92492882ca,0x2e32631f8578de30820f8dc38c72232788c7e1d083e031c8e03e03e2022780956680a2a70832270e31c3e03e232278c9,0x578de3578dd5e370832232420f8203e038c88c98c78d5e370820c88c9e231e3]
    decide +kernel
  exact e49755
end OMA.Blocks5_13_245212.S49755
