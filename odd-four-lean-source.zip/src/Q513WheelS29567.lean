import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S29567
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b29567 : Box := ![⟨36,37⟩,⟨127,169⟩,⟨63,126⟩,⟨3,109⟩,⟨1919,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨36,37⟩,⟨127,169⟩,⟨63,126⟩,⟨3,109⟩,⟨1919,999999999999999999⟩] := by
  have e29567 : Deny 5 13 b29567 := by
    apply closeAction rule_sound _ _ 64 [0x2a32de58ae2358ae2325e58ae37d8779629629ee37da32388c21f8da32237962962a32de59fe09e0a58ae23087e23263,0x83e232380f80f88c88c90c3e23203e23088e23263223796296]
    decide +kernel
  exact e29567
end OMA.Blocks5_13_245212.S29567
