import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S4888
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b4888 : Box := ![⟨15,17⟩,⟨15,30⟩,⟨11,1920000000000000011376⟩,⟨3,1366486486486486494619⟩,⟨37,47⟩]
theorem deny5_13 : Deny 5 13 ![⟨15,17⟩,⟨15,30⟩,⟨11,1920000000000000011376⟩,⟨3,1366486486486486494619⟩,⟨37,47⟩] := by
  have e4888 : Deny 5 13 b4888 := by
    apply closeAction rule_sound _ _ 64 [0x2b61c30f7da22021c22221021f8de228b0c3df6d47d84087e37da325cbdcbe325ce37da32421dce37da3238df68c8de3,0x2632030e31c38c90c40f7d841f88c88c972f79c737da22a3108e2325e737da3108e368c972f11c278df68c80f8df6d62,0xe37da320288a087df68c472f709bdc7020e22021e22a22a326310210b783be222f88a72f703be2103def8841f888abe3,0x72f70308888a11cdf6107e232430881021f8df68c972f8c4087]
    decide +kernel
  exact e4888
end OMA.Blocks5_13_245212.S4888
