import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S56716
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b56716 : Box := ![⟨47,62⟩,⟨31,62⟩,⟨15,30⟩,⟨3,6⟩,⟨127,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,62⟩,⟨31,62⟩,⟨15,30⟩,⟨3,6⟩,⟨127,233⟩] := by
  have e56716 : Deny 5 13 b56716 := by
    apply closeAction rule_sound _ _ 64 [0x5ca5f8dc40f8dc31c42785f70c70c31c9117e370f70c72442c80c31c30f71c9117dc30c72442c30f8243e072072442c8,0xe072445f8dc31c30c72442df0c3e095f8d87d8a5f62840c31c30f8dc72442c80c3e090f8d870c21f8df62381c911f5ca,0xf8dc80f8dc72447d72972830c80c72442c81c91025f8dd7e375c3109e370f8dc32380c72091c910b7d72972830c70c3,0xdd7e370c90f80c70c9244097e370f8dc32072442c85f8dc3e032070c31c3249117e375f8dc31c324910b7d70c9297283,0x175f8dd77d72b85ca1c81c2097e370c81c4278]
    decide +kernel
  exact e56716
end OMA.Blocks5_13_245212.S56716
