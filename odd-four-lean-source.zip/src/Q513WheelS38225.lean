import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S38225
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b38225 : Box := ![⟨47,62⟩,⟨31,62⟩,⟨7,14⟩,⟨3,58⟩,⟨79,113⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,62⟩,⟨31,62⟩,⟨7,14⟩,⟨3,58⟩,⟨79,113⟩] := by
  have e38225 : Deny 5 13 b38225 := by
    apply closeAction rule_sound _ _ 64 [0xc82472842c30c90f8de32430f8de32022778c78c46c20c42380c90c32032472830c90c90c3203e372472842e3223263,0xc3e371c80c4088e37d492a31e311b0820c8109e370820c7108e370f8dc32091ca4f8dd3e370c82420c9e370f70c7203,0x2e321b083e031c42386c3e040c41f80c82892820c41f80f80c72130c725328a6c3e031c30c7203103e37108e092830c7,0xdc32430c924a7c30e3223243e370c80c70c3e0824a8c78c40820c8278dc20832042785f8dc40c4278dc3e03209287dc4,0x278dc20831c4238dc20f8dc31c42380f8dc40c41f80c31c8289102083e370c7209dc42c7e377f8dc3e370c98c9083238,0x2093284]
    decide +kernel
  exact e38225
end OMA.Blocks5_13_245212.S38225
