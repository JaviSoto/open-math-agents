import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S44808
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b44808 : Box := ![⟨95,190⟩,⟨15,17⟩,⟨31,1920000000000000011376⟩,⟨7,1017986577181208059784⟩,⟨127,164⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨15,17⟩,⟨31,1920000000000000011376⟩,⟨7,1017986577181208059784⟩,⟨127,164⟩] := by
  have e44808 : Deny 5 13 b44808 := by
    apply closeAction rule_sound _ _ 64 [0x107e36207244578dc2083109e370f80c71c82442dd54ad845555431c71c3e031c3243103e37d841f81c910b2072a3244,0x2557550f8255e361ca247102095e370f8dc31c924710b108e15e37755295288083109e370f80c70c92030c70c4778df6,0x1f888788a8c98c4082578dd5e37bc32621e21e227710b8c88c41f8742082578dc3e370c72482441f8115e377559a02a0,0x578de311d88456210ae3709d278bdd555778df6884]
    decide +kernel
  exact e44808
end OMA.Blocks5_13_245212.S44808
