import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S55396
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b55396 : Box := ![⟨63,75⟩,⟨127,1920000000000000011376⟩,⟨7,9⟩,⟨1,502335381913959616708⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,75⟩,⟨127,1920000000000000011376⟩,⟨7,9⟩,⟨1,502335381913959616708⟩,⟨479,999999999999999999⟩] := by
  have e55396 : Deny 5 13 b55396 := by
    apply closeAction rule_sound _ _ 64 [0xae32f58daae32f58daae32f58daae32c21f58daae32c22636ab8cb8daae32c22636ab8cb6f88c84b884a4b8dab84aae3,0x209aae322b6ab8c80871eb6ab8c8adaada68bac22021e32021f5ae32358da]
    decide +kernel
  exact e55396
end OMA.Blocks5_13_245212.S55396
