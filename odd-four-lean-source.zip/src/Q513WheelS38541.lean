import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S38541
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b38541 : Box := ![⟨47,94⟩,⟨63,1920000000000000011376⟩,⟨7,14⟩,⟨3,709875930521091815666⟩,⟨79,113⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,94⟩,⟨63,1920000000000000011376⟩,⟨7,14⟩,⟨3,709875930521091815666⟩,⟨79,113⟩] := by
  have e38541 : Deny 5 13 b38541 := by
    apply closeAction rule_sound _ _ 64 [0xe11e12776db0820e12611f80f80f884784984a84a0f80e11c3e2b84984a8c78c40820f8ae12611f710b8c78c88c4278,0x20ab4f8dd3e37853e37]
    decide +kernel
  exact e38541
end OMA.Blocks5_13_245212.S38541
