import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S36721
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b36721 : Box := ![⟨63,94⟩,⟨15,20⟩,⟨15,30⟩,⟨3,52⟩,⟨94,113⟩]
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨15,20⟩,⟨15,30⟩,⟨3,52⟩,⟨94,113⟩] := by
  have e36721 : Deny 5 13 b36721 := by
    apply closeAction rule_sound _ _ 64 [0xdf68c7777da32231030e32430f78c98c710b0c3e090f8d87115e3610ae0a0c40f8de3109e378c9778df68c88c78c88c4,0x1c42c3115e37d841f8df620a0c3de3243df68c78c40c38c70c38c78c910b0c3e372440f8df6107e0a0f8df68c88c90c3,0x243de32232631c3e370c80c32231e31020c4278dc3e370c88c710b0c3e231c80c3df62030f8df62371c40f70c80c3dc8,0xe370e31c80c38c78c88c47f8dc3e370c723710b0f70c90c3dc91c30f8df61c8115e370c9dc3dc32470c31c810b2830e3,0xe370e32480c38c98c88c47f8dc3e370e32632042c3dc31c30c72430f8dc92040831f70f70c72430c92042ca8c97f8dc3,0x20831c4238578dc3e370c72550c9204578dc20c41f8dc320910b2b77c3]
    decide +kernel
  exact e36721
end OMA.Blocks5_13_245212.S36721
