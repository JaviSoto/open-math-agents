import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S49151
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b49151 : Box := ![⟨127,190⟩,⟨25,30⟩,⟨15,30⟩,⟨1,62⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨127,190⟩,⟨25,30⟩,⟨15,30⟩,⟨1,62⟩,⟨479,999999999999999999⟩] := by
  have e49151 : Deny 5 13 b49151 := by
    apply closeAction rule_sound _ _ 64 [0x2637e78cb9c30f88c70f821f9e37e78c7e232631df7f8238088e27087e237e72f89e37f89e32782237df9e02a78cb8c9,0x80be2680880a2972a31e32c39c38c70c38c78c78df9e32e37e78cb8df9e32e37e78cb0c3e378c70888df9e32dfe37263,0x8c9e270f8da31f8088e237e70c22231cbe2344ae232631e32237f89df7c20a6804238083808e030f89e6808809083809,0x8cb9e32637e78cb0f80e32430f88c98c70f89e37f8df68c7e232237df0831f80e02430f880980880a2972a32c3e1fe27,0x2e32631c20820f88c8e278c9e231f8083e232789c30f89e32631c80c38c90c3e232631e37e78cb0f89e3087e362237e7,0x82083e08e231f89e32780820f88c8e231f80f80c90c3e088c78df7e70f80c81ca9e3]
    decide +kernel
  exact e49151
end OMA.Blocks5_13_245212.S49151
