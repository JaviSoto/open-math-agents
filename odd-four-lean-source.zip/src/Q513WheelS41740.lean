import FastReplay245212
import SparseDigit245212
import WheelRule245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S41740
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b41740 : Box := ![⟨63,94⟩,⟨25,30⟩,⟨31,62⟩,⟨3,900178041543026711604⟩,⟨239,478⟩]
private def b41741 : Box := ![⟨63,94⟩,⟨25,30⟩,⟨31,62⟩,⟨3,6⟩,⟨239,478⟩]
private def b41742 : Box := ![⟨63,75⟩,⟨25,30⟩,⟨31,62⟩,⟨3,6⟩,⟨239,478⟩]
private def b41743 : Box := ![⟨63,75⟩,⟨25,30⟩,⟨31,62⟩,⟨3,6⟩,⟨239,318⟩]
private def b41744 : Box := ![⟨63,75⟩,⟨25,27⟩,⟨31,62⟩,⟨3,6⟩,⟨239,317⟩]
private def b41745 : Box := ![⟨63,75⟩,⟨25,27⟩,⟨31,41⟩,⟨3,6⟩,⟨239,317⟩]
private def b41754 : Box := ![⟨63,75⟩,⟨25,27⟩,⟨42,62⟩,⟨3,6⟩,⟨239,317⟩]
private def b41755 : Box := ![⟨63,68⟩,⟨25,27⟩,⟨42,62⟩,⟨3,6⟩,⟨239,317⟩]
private def b41756 : Box := ![⟨63,68⟩,⟨25,27⟩,⟨42,62⟩,⟨3,6⟩,⟨239,272⟩]
private def b41767 : Box := ![⟨63,68⟩,⟨25,27⟩,⟨42,62⟩,⟨3,6⟩,⟨273,317⟩]
private def b41778 : Box := ![⟨69,75⟩,⟨25,27⟩,⟨42,62⟩,⟨3,6⟩,⟨239,317⟩]
private def b41779 : Box := ![⟨69,75⟩,⟨25,27⟩,⟨42,62⟩,⟨3,6⟩,⟨239,272⟩]
private def b41784 : Box := ![⟨69,75⟩,⟨25,27⟩,⟨42,62⟩,⟨3,6⟩,⟨273,317⟩]
private def b41795 : Box := ![⟨63,75⟩,⟨28,30⟩,⟨31,62⟩,⟨3,6⟩,⟨239,317⟩]
private def b41796 : Box := ![⟨63,75⟩,⟨28,30⟩,⟨31,62⟩,⟨3,4⟩,⟨239,317⟩]
private def b41797 : Box := ![⟨63,75⟩,⟨28,30⟩,⟨31,62⟩,⟨5,6⟩,⟨239,317⟩]
private def b41798 : Box := ![⟨63,75⟩,⟨28,30⟩,⟨31,62⟩,⟨5,5⟩,⟨239,317⟩]
private def b41799 : Box := ![⟨63,75⟩,⟨28,30⟩,⟨31,41⟩,⟨5,5⟩,⟨239,317⟩]
private def b41808 : Box := ![⟨63,75⟩,⟨28,30⟩,⟨42,62⟩,⟨5,5⟩,⟨239,317⟩]
private def b41815 : Box := ![⟨63,75⟩,⟨28,30⟩,⟨31,62⟩,⟨6,6⟩,⟨239,317⟩]
private def b41816 : Box := ![⟨63,75⟩,⟨25,30⟩,⟨31,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b41817 : Box := ![⟨63,75⟩,⟨25,27⟩,⟨31,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b41818 : Box := ![⟨63,75⟩,⟨25,27⟩,⟨31,41⟩,⟨3,6⟩,⟨319,478⟩]
private def b41825 : Box := ![⟨63,75⟩,⟨25,27⟩,⟨42,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b41826 : Box := ![⟨63,68⟩,⟨25,27⟩,⟨42,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b41833 : Box := ![⟨69,75⟩,⟨25,27⟩,⟨42,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b41834 : Box := ![⟨69,75⟩,⟨25,27⟩,⟨42,62⟩,⟨3,6⟩,⟨319,382⟩]
private def b41845 : Box := ![⟨69,75⟩,⟨25,27⟩,⟨42,62⟩,⟨3,6⟩,⟨383,478⟩]
private def b41854 : Box := ![⟨63,75⟩,⟨28,30⟩,⟨31,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b41855 : Box := ![⟨63,75⟩,⟨28,30⟩,⟨31,41⟩,⟨3,6⟩,⟨319,478⟩]
private def b41864 : Box := ![⟨63,75⟩,⟨28,30⟩,⟨42,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b41865 : Box := ![⟨63,68⟩,⟨28,30⟩,⟨42,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b41866 : Box := ![⟨63,68⟩,⟨28,30⟩,⟨42,62⟩,⟨3,6⟩,⟨319,382⟩]
private def b41867 : Box := ![⟨63,68⟩,⟨28,30⟩,⟨42,62⟩,⟨3,4⟩,⟨331,379⟩]
private def b41868 : Box := ![⟨63,68⟩,⟨28,30⟩,⟨42,62⟩,⟨5,6⟩,⟨331,379⟩]
private def b41879 : Box := ![⟨63,68⟩,⟨28,30⟩,⟨42,62⟩,⟨3,6⟩,⟨383,478⟩]
private def b41888 : Box := ![⟨69,75⟩,⟨28,30⟩,⟨42,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b41889 : Box := ![⟨69,75⟩,⟨28,30⟩,⟨42,62⟩,⟨3,6⟩,⟨332,391⟩]
private def b41894 : Box := ![⟨69,75⟩,⟨28,30⟩,⟨42,62⟩,⟨3,6⟩,⟨392,478⟩]
private def b41903 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨31,62⟩,⟨3,6⟩,⟨239,478⟩]
private def b41904 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨31,62⟩,⟨3,6⟩,⟨239,318⟩]
private def b41905 : Box := ![⟨76,94⟩,⟨25,27⟩,⟨31,62⟩,⟨3,6⟩,⟨239,317⟩]
private def b41906 : Box := ![⟨76,94⟩,⟨25,27⟩,⟨31,41⟩,⟨3,6⟩,⟨239,317⟩]
private def b41917 : Box := ![⟨76,94⟩,⟨25,27⟩,⟨42,62⟩,⟨3,6⟩,⟨239,317⟩]
private def b41920 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨31,62⟩,⟨3,6⟩,⟨239,317⟩]
private def b41921 : Box := ![⟨76,94⟩,⟨25,30⟩,⟨31,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b41922 : Box := ![⟨76,94⟩,⟨25,27⟩,⟨31,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b41923 : Box := ![⟨76,94⟩,⟨25,27⟩,⟨31,41⟩,⟨3,6⟩,⟨319,478⟩]
private def b41924 : Box := ![⟨76,84⟩,⟨25,27⟩,⟨31,41⟩,⟨3,6⟩,⟨319,478⟩]
private def b41929 : Box := ![⟨85,94⟩,⟨25,27⟩,⟨31,41⟩,⟨3,6⟩,⟨319,478⟩]
private def b41930 : Box := ![⟨85,94⟩,⟨25,27⟩,⟨31,41⟩,⟨3,6⟩,⟨319,382⟩]
private def b41935 : Box := ![⟨85,94⟩,⟨25,27⟩,⟨31,41⟩,⟨3,6⟩,⟨383,478⟩]
private def b41944 : Box := ![⟨76,94⟩,⟨25,27⟩,⟨42,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b41945 : Box := ![⟨76,84⟩,⟨25,27⟩,⟨42,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b41946 : Box := ![⟨76,84⟩,⟨25,27⟩,⟨42,62⟩,⟨3,6⟩,⟨319,382⟩]
private def b41947 : Box := ![⟨76,84⟩,⟨25,25⟩,⟨42,62⟩,⟨3,6⟩,⟨331,379⟩]
private def b41956 : Box := ![⟨76,84⟩,⟨26,27⟩,⟨42,62⟩,⟨3,6⟩,⟨331,379⟩]
private def b41961 : Box := ![⟨76,84⟩,⟨25,27⟩,⟨42,62⟩,⟨3,6⟩,⟨383,478⟩]
private def b41962 : Box := ![⟨76,84⟩,⟨25,25⟩,⟨42,62⟩,⟨3,6⟩,⟨383,467⟩]
private def b41971 : Box := ![⟨76,84⟩,⟨26,27⟩,⟨42,62⟩,⟨3,6⟩,⟨383,467⟩]
private def b41978 : Box := ![⟨85,94⟩,⟨25,27⟩,⟨42,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b41981 : Box := ![⟨76,94⟩,⟨28,30⟩,⟨31,62⟩,⟨3,6⟩,⟨319,478⟩]
private def b41990 : Box := ![⟨63,94⟩,⟨25,30⟩,⟨31,62⟩,⟨7,60⟩,⟨239,478⟩]
private theorem e41745 : Deny 5 13 b41745 := by
    apply closeAction rule_sound _ _ 64 [0xc3243e080c40f8107e07]
    decide +kernel
private theorem e41756 : Deny 5 13 b41756 := by
    apply closeAction rule_sound _ _ 64 [0x5f8dc31c30c72430c9204]
    decide +kernel
private theorem e41767 : Deny 5 13 b41767 := by
    apply closeAction rule_sound _ _ 64 [0xc31c30c72431028841f8df6204]
    decide +kernel
private theorem e41755 : Deny 5 13 b41755 :=
    branchAction rule_sound _ _ 1
      0xb b41755 b41756 b41767 (by decide +kernel) e41756 e41767
private theorem e41779 : Deny 5 13 b41779 := by
    apply closeAction rule_sound _ _ 64 [0x5f8dd5e370c9204]
    decide +kernel
private theorem e41784 : Deny 5 13 b41784 := by
    apply closeAction rule_sound _ _ 64 [0x838841f8dc3e370c72430c9204]
    decide +kernel
private theorem e41778 : Deny 5 13 b41778 :=
    branchAction rule_sound _ _ 1
      0xb b41778 b41779 b41784 (by decide +kernel) e41779 e41784
private theorem e41754 : Deny 5 13 b41754 :=
    branchAction rule_sound _ _ 1
      0x7 b41754 b41755 b41778 (by decide +kernel) e41755 e41778
private theorem e41744 : Deny 5 13 b41744 :=
    branchAction rule_sound _ _ 1
      0x9 b41744 b41745 b41754 (by decide +kernel) e41745 e41754
private theorem e41796 : Deny 5 13 b41796 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e41799 : Deny 5 13 b41799 := by
    apply closeAction rule_sound _ _ 64 [0x20f80c7109e03e031c7]
    decide +kernel
private theorem e41808 : Deny 5 13 b41808 := by
    apply closeAction rule_sound _ _ 64 [0x20820c72441f8]
    decide +kernel
private theorem e41798 : Deny 5 13 b41798 :=
    branchAction rule_sound _ _ 1
      0x9 b41798 b41799 b41808 (by decide +kernel) e41799 e41808
private theorem e41815 : Deny 5 13 b41815 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e41797 : Deny 5 13 b41797 :=
    branchAction rule_sound _ _ 1
      0xa b41797 b41798 b41815 (by decide +kernel) e41798 e41815
private theorem e41795 : Deny 5 13 b41795 :=
    branchAction rule_sound _ _ 1
      0xa b41795 b41796 b41797 (by decide +kernel) e41796 e41797
private theorem e41743 : Deny 5 13 b41743 :=
    branchAction rule_sound _ _ 2
      0x204 b41743 b41744 b41795 (by decide +kernel) e41744 e41795
private theorem e41818 : Deny 5 13 b41818 := by
    apply closeAction rule_sound _ _ 64 [0x30f8dc90881021f8]
    decide +kernel
private theorem e41826 : Deny 5 13 b41826 := by
    apply closeAction rule_sound _ _ 64 [0xc3e37243e37d87102238]
    decide +kernel
private theorem e41834 : Deny 5 13 b41834 := by
    apply closeAction rule_sound _ _ 64 [0xc31c30c72430f8dc9204]
    decide +kernel
private theorem e41845 : Deny 5 13 b41845 := by
    apply closeAction rule_sound _ _ 64 [0x30c70c3e371c90f8df6204]
    decide +kernel
private theorem e41833 : Deny 5 13 b41833 :=
    branchAction rule_sound _ _ 1
      0xb b41833 b41834 b41845 (by decide +kernel) e41834 e41845
private theorem e41825 : Deny 5 13 b41825 :=
    branchAction rule_sound _ _ 1
      0x7 b41825 b41826 b41833 (by decide +kernel) e41826 e41833
private theorem e41817 : Deny 5 13 b41817 :=
    branchAction rule_sound _ _ 1
      0x9 b41817 b41818 b41825 (by decide +kernel) e41818 e41825
private theorem e41855 : Deny 5 13 b41855 := by
    apply closeAction rule_sound _ _ 64 [0xf80c90c70c3e07e07]
    decide +kernel
private theorem e41867 : Deny 5 13 b41867 := by
    apply closeAction rule_sound _ _ 64 [0x17]
    decide +kernel
private theorem e41868 : Deny 5 13 b41868 := by
    apply closeAction rule_sound _ _ 64 [0x1f083107e032030c724a]
    decide +kernel
private theorem e41866 : Deny 5 13 b41866 :=
    branchAction rule_sound _ _ 2
      0x284 b41866 b41867 b41868 (by decide +kernel) e41867 e41868
private theorem e41879 : Deny 5 13 b41879 := by
    apply closeAction rule_sound _ _ 64 [0xc31c32030c7244]
    decide +kernel
private theorem e41865 : Deny 5 13 b41865 :=
    branchAction rule_sound _ _ 1
      0xb b41865 b41866 b41879 (by decide +kernel) e41866 e41879
private theorem e41889 : Deny 5 13 b41889 := by
    apply closeAction rule_sound _ _ 64 [0x97e370c7244]
    decide +kernel
private theorem e41894 : Deny 5 13 b41894 := by
    apply closeAction rule_sound _ _ 64 [0x5f8dc321f5c320a244]
    decide +kernel
private theorem e41888 : Deny 5 13 b41888 :=
    branchAction rule_sound _ _ 2
      0x2f8 b41888 b41889 b41894 (by decide +kernel) e41889 e41894
private theorem e41864 : Deny 5 13 b41864 :=
    branchAction rule_sound _ _ 1
      0x7 b41864 b41865 b41888 (by decide +kernel) e41865 e41888
private theorem e41854 : Deny 5 13 b41854 :=
    branchAction rule_sound _ _ 1
      0x9 b41854 b41855 b41864 (by decide +kernel) e41855 e41864
private theorem e41816 : Deny 5 13 b41816 :=
    branchAction rule_sound _ _ 1
      0x8 b41816 b41817 b41854 (by decide +kernel) e41817 e41854
private theorem e41742 : Deny 5 13 b41742 :=
    branchAction rule_sound _ _ 1
      0xb b41742 b41743 b41816 (by decide +kernel) e41743 e41816
private theorem e41906 : Deny 5 13 b41906 := by
    apply closeAction rule_sound _ _ 64 [0x20951c4238dc3e370c8e03207]
    decide +kernel
private theorem e41917 : Deny 5 13 b41917 := by
    apply closeAction rule_sound _ _ 64 [0x2548e37]
    decide +kernel
private theorem e41905 : Deny 5 13 b41905 :=
    branchAction rule_sound _ _ 1
      0x9 b41905 b41906 b41917 (by decide +kernel) e41906 e41917
private theorem e41920 : Deny 5 13 b41920 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
private theorem e41904 : Deny 5 13 b41904 :=
    branchAction rule_sound _ _ 2
      0x204 b41904 b41905 b41920 (by decide +kernel) e41905 e41920
private theorem e41924 : Deny 5 13 b41924 := by
    apply closeAction rule_sound _ _ 64 [0xc3203e08]
    decide +kernel
private theorem e41930 : Deny 5 13 b41930 := by
    apply closeAction rule_sound _ _ 64 [0x578dc3e370c8244]
    decide +kernel
private theorem e41935 : Deny 5 13 b41935 := by
    apply closeAction rule_sound _ _ 64 [0x1f54ae032430c9204]
    decide +kernel
private theorem e41929 : Deny 5 13 b41929 :=
    branchAction rule_sound _ _ 1
      0xb b41929 b41930 b41935 (by decide +kernel) e41930 e41935
private theorem e41923 : Deny 5 13 b41923 :=
    branchAction rule_sound _ _ 1
      0x7 b41923 b41924 b41929 (by decide +kernel) e41924 e41929
private theorem e41947 : Deny 5 13 b41947 := by
    apply closeAction rule_sound _ _ 64 [0x1f083107e0324a54a]
    decide +kernel
private theorem e41956 : Deny 5 13 b41956 := by
    apply closeAction rule_sound _ _ 64 [0x820c7109e37]
    decide +kernel
private theorem e41946 : Deny 5 13 b41946 :=
    branchAction rule_sound _ _ 2
      0x204 b41946 b41947 b41956 (by decide +kernel) e41947 e41956
private theorem e41962 : Deny 5 13 b41962 := by
    apply closeAction rule_sound _ _ 64 [0x7c20c77c910b54a]
    decide +kernel
private theorem e41971 : Deny 5 13 b41971 := by
    apply closeAction rule_sound _ _ 64 [0x83107e03e031c9]
    decide +kernel
private theorem e41961 : Deny 5 13 b41961 :=
    branchAction rule_sound _ _ 2
      0x204 b41961 b41962 b41971 (by decide +kernel) e41962 e41971
private theorem e41945 : Deny 5 13 b41945 :=
    branchAction rule_sound _ _ 1
      0xb b41945 b41946 b41961 (by decide +kernel) e41946 e41961
private theorem e41978 : Deny 5 13 b41978 := by
    apply closeAction rule_sound _ _ 64 [0x7f81152b8]
    decide +kernel
private theorem e41944 : Deny 5 13 b41944 :=
    branchAction rule_sound _ _ 1
      0x7 b41944 b41945 b41978 (by decide +kernel) e41945 e41978
private theorem e41922 : Deny 5 13 b41922 :=
    branchAction rule_sound _ _ 1
      0x9 b41922 b41923 b41944 (by decide +kernel) e41923 e41944
private theorem e41981 : Deny 5 13 b41981 := by
    apply closeAction rule_sound _ _ 64 [0x17e375f8ddfe045cae03207278]
    decide +kernel
private theorem e41921 : Deny 5 13 b41921 :=
    branchAction rule_sound _ _ 1
      0x8 b41921 b41922 b41981 (by decide +kernel) e41922 e41981
private theorem e41903 : Deny 5 13 b41903 :=
    branchAction rule_sound _ _ 1
      0xb b41903 b41904 b41921 (by decide +kernel) e41904 e41921
private theorem e41741 : Deny 5 13 b41741 :=
    branchAction rule_sound _ _ 1
      0x7 b41741 b41742 b41903 (by decide +kernel) e41742 e41903
private theorem e41990 : Deny 5 13 b41990 := by
    apply closeAction rule_sound _ _ 64 [0x1f]
    decide +kernel
private theorem e41740 : Deny 5 13 b41740 :=
    branchAction rule_sound _ _ 2
      0x2a3 b41740 b41741 b41990 (by decide +kernel) e41741 e41990
theorem deny5_13 : Deny 5 13 ![⟨63,94⟩,⟨25,30⟩,⟨31,62⟩,⟨3,900178041543026711604⟩,⟨239,478⟩] := by
  exact e41740
end OMA.Blocks5_13_245212.S41740
