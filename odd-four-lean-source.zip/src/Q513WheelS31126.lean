import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S31126
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b31126 : Box := ![⟨42,46⟩,⟨63,84⟩,⟨31,62⟩,⟨1,68⟩,⟨959,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨42,46⟩,⟨63,84⟩,⟨31,62⟩,⟨1,68⟩,⟨959,999999999999999999⟩] := by
  have e31126 : Deny 5 13 b31126 := by
    apply closeAction rule_sound _ _ 64 [0x28a58a8cb7df0f80f82380f8278d960c90c3e0824be03e361f80f8087088e362172b82b82972b88dfe37db58c7e23263,0x28a58a8cb8c90c3e23203e23243e23df68c8e2325fe37da31e32030f8df68c87f8df68c77f8de32788c2238d878df7d6,0x20c70c38c98c80c3e37da32078df7d628a58a8cb0c38c80e325ee37d878df7d6]
    decide +kernel
  exact e31126
end OMA.Blocks5_13_245212.S31126
