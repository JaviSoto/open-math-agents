import FastReplay245212
import SparseDigit245212
import FastRound245212
import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S12013
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b12013 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029553⟩,⟨207,414⟩]
private def b12014 : Box := ![⟨18,19⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029546⟩,⟨207,414⟩]
private def b12015 : Box := ![⟨18,19⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨1,2⟩,⟨207,414⟩]
private def b12016 : Box := ![⟨18,19⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨3,864390243902439029546⟩,⟨207,414⟩]
private def b12017 : Box := ![⟨18,19⟩,⟨31,41⟩,⟨31,1920000000000000011376⟩,⟨3,864390243902439029546⟩,⟨207,414⟩]
private def b12018 : Box := ![⟨18,19⟩,⟨31,41⟩,⟨31,62⟩,⟨3,864390243902439029539⟩,⟨207,414⟩]
private def b12019 : Box := ![⟨18,19⟩,⟨31,41⟩,⟨31,62⟩,⟨3,47⟩,⟨207,276⟩]
private def b12020 : Box := ![⟨18,19⟩,⟨31,35⟩,⟨31,62⟩,⟨3,47⟩,⟨211,271⟩]
private def b12025 : Box := ![⟨18,19⟩,⟨36,41⟩,⟨31,62⟩,⟨3,47⟩,⟨211,271⟩]
private def b12036 : Box := ![⟨18,19⟩,⟨31,41⟩,⟨31,62⟩,⟨3,47⟩,⟨277,414⟩]
private def b12043 : Box := ![⟨18,19⟩,⟨31,41⟩,⟨63,1920000000000000011376⟩,⟨3,864390243902439029539⟩,⟨207,414⟩]
private def b12044 : Box := ![⟨18,19⟩,⟨31,41⟩,⟨63,1920000000000000011376⟩,⟨3,6⟩,⟨207,414⟩]
private def b12045 : Box := ![⟨18,19⟩,⟨31,41⟩,⟨63,1920000000000000011376⟩,⟨7,864390243902439029539⟩,⟨207,414⟩]
private def b12046 : Box := ![⟨18,19⟩,⟨31,41⟩,⟨63,1920000000000000011376⟩,⟨7,864390243902439029539⟩,⟨207,276⟩]
private def b12055 : Box := ![⟨18,19⟩,⟨31,41⟩,⟨63,1920000000000000011376⟩,⟨7,864390243902439029539⟩,⟨277,414⟩]
private def b12068 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨31,1920000000000000011376⟩,⟨3,864390243902439029546⟩,⟨207,414⟩]
private def b12069 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨31,62⟩,⟨3,864390243902439029546⟩,⟨207,414⟩]
private def b12070 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨31,62⟩,⟨3,53⟩,⟨207,276⟩]
private def b12071 : Box := ![⟨18,19⟩,⟨42,50⟩,⟨31,62⟩,⟨3,53⟩,⟨211,271⟩]
private def b12082 : Box := ![⟨18,19⟩,⟨51,62⟩,⟨31,62⟩,⟨3,53⟩,⟨211,271⟩]
private def b12089 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨31,62⟩,⟨3,53⟩,⟨277,414⟩]
private def b12090 : Box := ![⟨18,19⟩,⟨42,50⟩,⟨31,62⟩,⟨3,51⟩,⟨277,414⟩]
private def b12105 : Box := ![⟨18,19⟩,⟨51,62⟩,⟨31,62⟩,⟨3,51⟩,⟨277,414⟩]
private def b12106 : Box := ![⟨18,19⟩,⟨51,62⟩,⟨31,62⟩,⟨3,6⟩,⟨277,414⟩]
private def b12107 : Box := ![⟨18,19⟩,⟨51,62⟩,⟨31,62⟩,⟨7,51⟩,⟨277,414⟩]
private def b12108 : Box := ![⟨18,19⟩,⟨51,62⟩,⟨31,62⟩,⟨7,12⟩,⟨277,414⟩]
private def b12109 : Box := ![⟨18,19⟩,⟨51,62⟩,⟨31,62⟩,⟨7,8⟩,⟨277,414⟩]
private def b12124 : Box := ![⟨18,19⟩,⟨51,62⟩,⟨31,62⟩,⟨9,12⟩,⟨277,414⟩]
private def b12125 : Box := ![⟨18,19⟩,⟨51,62⟩,⟨31,62⟩,⟨13,51⟩,⟨277,414⟩]
private def b12126 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨3,864390243902439029546⟩,⟨207,414⟩]
private def b12127 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨3,6⟩,⟨228,414⟩]
private def b12128 : Box := ![⟨18,19⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨7,864390243902439029546⟩,⟨228,414⟩]
private def b12129 : Box := ![⟨18,18⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨7,848862275449101801470⟩,⟨266,414⟩]
private def b12130 : Box := ![⟨18,18⟩,⟨42,50⟩,⟨63,1920000000000000011376⟩,⟨7,824985451018428714910⟩,⟨266,414⟩]
private def b12139 : Box := ![⟨18,18⟩,⟨51,62⟩,⟨63,1920000000000000011376⟩,⟨7,824985451018428714910⟩,⟨266,414⟩]
private def b12146 : Box := ![⟨19,19⟩,⟨42,62⟩,⟨63,1920000000000000011376⟩,⟨7,848862275449101801470⟩,⟨266,414⟩]
private def b12147 : Box := ![⟨20,22⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029546⟩,⟨207,414⟩]
private def b12148 : Box := ![⟨20,22⟩,⟨31,41⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029546⟩,⟨207,414⟩]
private def b12149 : Box := ![⟨20,22⟩,⟨31,41⟩,⟨31,62⟩,⟨1,864390243902439029540⟩,⟨207,414⟩]
private def b12150 : Box := ![⟨20,22⟩,⟨31,41⟩,⟨31,62⟩,⟨1,48⟩,⟨207,276⟩]
private def b12151 : Box := ![⟨20,22⟩,⟨31,41⟩,⟨31,62⟩,⟨1,2⟩,⟨211,271⟩]
private def b12156 : Box := ![⟨20,22⟩,⟨31,41⟩,⟨31,62⟩,⟨3,47⟩,⟨211,271⟩]
private def b12169 : Box := ![⟨20,22⟩,⟨31,41⟩,⟨31,62⟩,⟨1,48⟩,⟨277,414⟩]
private def b12170 : Box := ![⟨20,20⟩,⟨31,41⟩,⟨31,62⟩,⟨1,45⟩,⟨277,414⟩]
private def b12177 : Box := ![⟨21,22⟩,⟨31,41⟩,⟨31,62⟩,⟨1,45⟩,⟨277,414⟩]
private def b12178 : Box := ![⟨21,22⟩,⟨31,35⟩,⟨31,62⟩,⟨1,45⟩,⟨277,414⟩]
private def b12189 : Box := ![⟨21,22⟩,⟨36,41⟩,⟨31,62⟩,⟨1,45⟩,⟨277,414⟩]
private def b12194 : Box := ![⟨20,22⟩,⟨31,41⟩,⟨63,1920000000000000011376⟩,⟨1,864390243902439029540⟩,⟨207,414⟩]
private def b12207 : Box := ![⟨20,22⟩,⟨42,62⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029546⟩,⟨207,414⟩]
theorem deny5_11 : Deny 5 11 ![⟨18,22⟩,⟨31,62⟩,⟨31,1920000000000000011376⟩,⟨1,864390243902439029553⟩,⟨207,414⟩] := by
  have e12015 : Deny 5 11 b12015 := by
    apply closeAction rule_sound _ _ 64 [0x5a2]
    decide +kernel
  have e12020 : Deny 5 11 b12020 := by
    apply closeAction rule_sound _ _ 64 [0x30f8df68c80f8df61e3]
    decide +kernel
  have e12025 : Deny 5 11 b12025 := by
    apply closeAction rule_sound _ _ 64 [0x3e370e32030f8dc88c70dee37d878c9]
    decide +kernel
  have e12019 : Deny 5 11 b12019 :=
    branchAction rule_sound _ _ 2
      0x204 b12019 b12020 b12025 (by decide +kernel) e12020 e12025
  have e12036 : Deny 5 11 b12036 := by
    apply closeAction rule_sound _ _ 64 [0xc3e36203e37da321ce37db51e3]
    decide +kernel
  have e12018 : Deny 5 11 b12018 :=
    branchAction rule_sound _ _ 2
      0x2e3 b12018 b12019 b12036 (by decide +kernel) e12019 e12036
  have e12044 : Deny 5 11 b12044 := by
    apply closeAction rule_sound _ _ 64 [0x14]
    decide +kernel
  have e12046 : Deny 5 11 b12046 := by
    apply closeAction rule_sound _ _ 64 [0x72f79e72f0e326f8c8be322f8c98c4]
    decide +kernel
  have e12055 : Deny 5 11 b12055 := by
    apply closeAction rule_sound _ _ 64 [0x71cbe310be2f7af8c972f703e2f88a087be3263223]
    decide +kernel
  have e12045 : Deny 5 11 b12045 :=
    branchAction rule_sound _ _ 1
      0xb b12045 b12046 b12055 (by decide +kernel) e12046 e12055
  have e12043 : Deny 5 11 b12043 :=
    branchAction rule_sound _ _ 1
      0xa b12043 b12044 b12045 (by decide +kernel) e12044 e12045
  have e12017 : Deny 5 11 b12017 :=
    branchAction rule_sound _ _ 2
      0x263 b12017 b12018 b12043 (by decide +kernel) e12018 e12043
  have e12071 : Deny 5 11 b12071 := by
    apply closeAction rule_sound _ _ 64 [0x25b8dc32770e32070f8dc31e3263]
    decide +kernel
  have e12082 : Deny 5 11 b12082 := by
    apply closeAction rule_sound _ _ 64 [0x5b8dc20f8dc38c88c78c9]
    decide +kernel
  have e12070 : Deny 5 11 b12070 :=
    branchAction rule_sound _ _ 2
      0x204 b12070 b12071 b12082 (by decide +kernel) e12071 e12082
  have e12090 : Deny 5 11 b12090 := by
    apply closeAction rule_sound _ _ 64 [0x20f7109e370e32380c3e378c90f8de32381c30f8df61e3263]
    decide +kernel
  have e12106 : Deny 5 11 b12106 := by
    apply closeAction rule_sound _ _ 64 [0x16]
    decide +kernel
  have e12109 : Deny 5 11 b12109 := by
    apply closeAction rule_sound _ _ 64 [0x2583e03e092041f8083108e03103e042381c9]
    decide +kernel
  have e12124 : Deny 5 11 b12124 := by
    apply closeAction rule_sound _ _ 64 [0x1e]
    decide +kernel
  have e12108 : Deny 5 11 b12108 :=
    branchAction rule_sound _ _ 1
      0xa b12108 b12109 b12124 (by decide +kernel) e12109 e12124
  have e12125 : Deny 5 11 b12125 := by
    apply closeAction rule_sound _ _ 64 [0x1e]
    decide +kernel
  have e12107 : Deny 5 11 b12107 :=
    branchAction rule_sound _ _ 1
      0xa b12107 b12108 b12125 (by decide +kernel) e12108 e12125
  have e12105 : Deny 5 11 b12105 :=
    branchAction rule_sound _ _ 1
      0xa b12105 b12106 b12107 (by decide +kernel) e12106 e12107
  have e12089 : Deny 5 11 b12089 :=
    branchAction rule_sound _ _ 2
      0x223 b12089 b12090 b12105 (by decide +kernel) e12090 e12105
  have e12069 : Deny 5 11 b12069 :=
    branchAction rule_sound _ _ 2
      0x2e3 b12069 b12070 b12089 (by decide +kernel) e12070 e12089
  have e12127 : Deny 5 11 b12127 := by
    apply closeAction rule_sound _ _ 64 [0x16b62]
    decide +kernel
  have e12130 : Deny 5 11 b12130 := by
    apply closeAction rule_sound _ _ 64 [0x2709e2f7af7af0e3263263263]
    decide +kernel
  have e12139 : Deny 5 11 b12139 := by
    apply closeAction rule_sound _ _ 64 [0x20820c9888de2109e37]
    decide +kernel
  have e12129 : Deny 5 11 b12129 :=
    branchAction rule_sound _ _ 2
      0x223 b12129 b12130 b12139 (by decide +kernel) e12130 e12139
  have e12146 : Deny 5 11 b12146 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e12128 : Deny 5 11 b12128 :=
    branchAction rule_sound _ _ 3
      0x7e23 b12128 b12129 b12146 (by decide +kernel) e12129 e12146
  have e12126 : Deny 5 11 b12126 :=
    branchAction rule_sound _ _ 2
      0x2b8 b12126 b12127 b12128 (by decide +kernel) e12127 e12128
  have e12068 : Deny 5 11 b12068 :=
    branchAction rule_sound _ _ 1
      0x9 b12068 b12069 b12126 (by decide +kernel) e12069 e12126
  have e12016 : Deny 5 11 b12016 :=
    branchAction rule_sound _ _ 1
      0x8 b12016 b12017 b12068 (by decide +kernel) e12017 e12068
  have e12014 : Deny 5 11 b12014 :=
    branchAction rule_sound _ _ 1
      0xa b12014 b12015 b12016 (by decide +kernel) e12015 e12016
  have e12151 : Deny 5 11 b12151 := by
    apply closeAction rule_sound _ _ 64 [0x5960e2222222]
    decide +kernel
  have e12156 : Deny 5 11 b12156 := by
    apply closeAction rule_sound _ _ 64 [0x820c9884238dc20c4278dc30e3223207]
    decide +kernel
  have e12150 : Deny 5 11 b12150 :=
    branchAction rule_sound _ _ 3
      0xa8c4 b12150 b12151 b12156 (by decide +kernel) e12151 e12156
  have e12170 : Deny 5 11 b12170 := by
    apply closeAction rule_sound _ _ 64 [0xc38c80c3e37da32378c8]
    decide +kernel
  have e12178 : Deny 5 11 b12178 := by
    apply closeAction rule_sound _ _ 64 [0x2be31038c42780f8dc31e32560e22222a3]
    decide +kernel
  have e12189 : Deny 5 11 b12189 := by
    apply closeAction rule_sound _ _ 64 [0x16e378820c7277]
    decide +kernel
  have e12177 : Deny 5 11 b12177 :=
    branchAction rule_sound _ _ 1
      0x8 b12177 b12178 b12189 (by decide +kernel) e12178 e12189
  have e12169 : Deny 5 11 b12169 :=
    branchAction rule_sound _ _ 2
      0x1e3 b12169 b12170 b12177 (by decide +kernel) e12170 e12177
  have e12149 : Deny 5 11 b12149 :=
    branchAction rule_sound _ _ 2
      0x2e3 b12149 b12150 b12169 (by decide +kernel) e12150 e12169
  have e12194 : Deny 5 11 b12194 := by
    apply closeAction rule_sound _ _ 64 [0x820af72f8c470388a8c4278be32632231f850a]
    decide +kernel
  have e12148 : Deny 5 11 b12148 :=
    branchAction rule_sound _ _ 2
      0x263 b12148 b12149 b12194 (by decide +kernel) e12149 e12194
  have e12207 : Deny 5 11 b12207 := by
    apply closeAction rule_sound _ _ 64 [0x2096e375b8dc32481f7116dc42c9e37]
    decide +kernel
  have e12147 : Deny 5 11 b12147 :=
    branchAction rule_sound _ _ 1
      0x8 b12147 b12148 b12207 (by decide +kernel) e12148 e12207
  have e12013 : Deny 5 11 b12013 :=
    branchAction rule_sound _ _ 2
      0x1e3 b12013 b12014 b12147 (by decide +kernel) e12014 e12147
  exact e12013
end OMA.Blocks5_11_245212.S12013
