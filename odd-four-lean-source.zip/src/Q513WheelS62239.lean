import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S62239
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b62239 : Box := ![⟨95,190⟩,⟨31,62⟩,⟨7,9⟩,⟨1,74⟩,⟨127,233⟩]
theorem deny5_13 : Deny 5 13 ![⟨95,190⟩,⟨31,62⟩,⟨7,9⟩,⟨1,74⟩,⟨127,233⟩] := by
  have e62239 : Deny 5 13 b62239 := by
    apply closeAction rule_sound _ _ 64 [0xf8dc3204278dc20c90f70c98c78c40820c91f78c42f80c3e2780980a8c80c38c86c3e202a78c88c98c78c42e32132a3,0x1dbe378c98c40c32436f8dc98c70c22602842e32036f8de32040a3108e378c98c78c4091238de311b9e3109e274f8dc4,0x10b9e32676c3e032670c72a70c3e378c98c78c46c20f8dc32042780f80c91ca0f8dc38099c30f824780a10b0e70f8de3,0x83e370e3223107e132a32232631f710b0a78c4083e3711b9e3108e27263107e029e311b0e78c88c41f86c99e321b6e7,0x1e3113e370820c8109e13287dc42e321b6d30c3e086f8dc7103e032030f820710b20a2932a32631e3113e374f8dd3e37,0xe374f8ddb9e311b6d396028a8c41f89e32232424c7e374f8dd3e370c82776db083108e03e03e0824a2930c3e372482a3,0x13]
    decide +kernel
  exact e62239
end OMA.Blocks5_13_245212.S62239
