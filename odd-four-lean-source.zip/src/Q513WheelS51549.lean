import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S51549
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b51549 : Box := ![⟨191,382⟩,⟨21,24⟩,⟨15,20⟩,⟨3,95⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨191,382⟩,⟨21,24⟩,⟨15,20⟩,⟨3,95⟩,⟨479,999999999999999999⟩] := by
  have e51549 : Deny 5 13 b51549 := by
    apply closeAction rule_sound _ _ 64 [0x2768d99e32d99e37c2238da78c7e368c76678c21f8db48c88d99d99d97d99c4089e2720a8c76678c98c79e32d1e202a3,0xc38c70878d99e32d9e378c9678df62236678cb678de3]
    decide +kernel
  exact e51549
end OMA.Blocks5_13_245212.S51549
