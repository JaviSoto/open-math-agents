import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S61355
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b61355 : Box := ![⟨47,62⟩,⟨127,1920000000000000011376⟩,⟨15,30⟩,⟨1,502335381913959616711⟩,⟨479,999999999999999999⟩]
private def b61356 : Box := ![⟨47,62⟩,⟨127,1920000000000000011376⟩,⟨15,20⟩,⟨1,502335381913959616711⟩,⟨479,999999999999999999⟩]
private def b61357 : Box := ![⟨47,53⟩,⟨127,1920000000000000011376⟩,⟨15,20⟩,⟨1,502335381913959616707⟩,⟨479,999999999999999999⟩]
private def b61358 : Box := ![⟨47,53⟩,⟨127,1920000000000000011376⟩,⟨15,20⟩,⟨1,2⟩,⟨479,999999999999999999⟩]
private def b61359 : Box := ![⟨47,53⟩,⟨127,1920000000000000011376⟩,⟨15,20⟩,⟨3,502335381913959616706⟩,⟨479,999999999999999999⟩]
private def b61360 : Box := ![⟨47,53⟩,⟨127,1920000000000000011376⟩,⟨15,20⟩,⟨3,502335381913959616706⟩,⟨479,958⟩]
private def b61363 : Box := ![⟨47,53⟩,⟨127,1920000000000000011376⟩,⟨15,20⟩,⟨3,502335381913959616706⟩,⟨959,999999999999999999⟩]
private def b61364 : Box := ![⟨47,53⟩,⟨127,254⟩,⟨15,20⟩,⟨3,451586424625098660953⟩,⟨959,999999999999999999⟩]
private def b61547 : Box := ![⟨47,53⟩,⟨255,1920000000000000011376⟩,⟨15,20⟩,⟨3,451586424625098660953⟩,⟨959,999999999999999999⟩]
private def b61684 : Box := ![⟨54,62⟩,⟨127,1920000000000000011376⟩,⟨15,20⟩,⟨1,502335381913959616707⟩,⟨479,999999999999999999⟩]
private def b61785 : Box := ![⟨47,62⟩,⟨127,1920000000000000011376⟩,⟨21,30⟩,⟨1,502335381913959616711⟩,⟨479,999999999999999999⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,62⟩,⟨127,1920000000000000011376⟩,⟨15,30⟩,⟨1,502335381913959616711⟩,⟨479,999999999999999999⟩] := by
  have e61358 : Deny 5 13 b61358 := by
    apply closeAction rule_sound _ _ 64 [0x61]
    decide +kernel
  have e61360 : Deny 5 13 b61360 := by
    apply closeAction rule_sound _ _ 64 [0x6ab7eb8c8ae3]
    decide +kernel
  have e61364 : Deny 5 13 b61364 := by
    apply closeAction rule_sound _ _ 64 [0x8daae32e36ab8cb8daae32e36ab8cbac30f88c80878dfae32dae37d632632236ab7e322b8cb6ab8dfe2b8c8e231e3263,0x8daae32e36ab8cb8daae32e36ab8cb4b7d498daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cb,0x8cb8dfae32da6ab0c32421c86ab84b6ab84b6ab84b6ab84b6ab84b6ab84b0612d22d22e12a36ab8cb8daae32e36ab8cb,0xae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cbac3087ac22368c8d631e37eb8cb8dfae32e37eb8cb8dfae32e37eb,0x84b6ab84b6abaa12c184b48b48b48b84a8daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8da,0x20820e32632231eb0838c80e32430e32022478dfae32e321a6ab0c3dab1c21c86ab84b6ab84b6ab84b6ab]
    decide +kernel
  have e61547 : Deny 5 13 b61547 := by
    apply closeAction rule_sound _ _ 64 [0x2e36ab8cb8daae32e36ab8cb8daae32c21c226b8c88c7ae32636ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32eb,0xae32e36ab8cb8daae32eb8c808209aae3238adaae32351c21c9adaae322b6ab8c8adaae322b6ab0eb0880898c88daae3,0x8daae32e36ab8cbae32231c26ab8c8ada69aada6922d22d22d22e128848b48b48b84a48b48b84a8daae32e36ab8cb8da,0x826ab69a6ab69a48b48b48b84a2122d22d22d22e12922ca8c88daae32e36ab8cb8daae32e36ab8cb]
    decide +kernel
  have e61363 : Deny 5 13 b61363 :=
    branchAction rule_sound _ _ 2
      0x223 b61363 b61364 b61547 (by decide +kernel) e61364 e61547
  have e61359 : Deny 5 13 b61359 :=
    branchAction rule_sound _ _ 1
      0xb b61359 b61360 b61363 (by decide +kernel) e61360 e61363
  have e61357 : Deny 5 13 b61357 :=
    branchAction rule_sound _ _ 2
      0x2a3 b61357 b61358 b61359 (by decide +kernel) e61358 e61359
  have e61684 : Deny 5 13 b61684 := by
    apply closeAction rule_sound _ _ 64 [0x8cb8daae32e36ab8cb8c7e2b0838c70c31e32237eb8cb0c3e2322326369f2ab8cb8c8ae31e309f238ae32e3278ae3238,0x2e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32e36ab,0x6ab6830e11e12886ab84b6ab84b6ab84b6ab84b6ab84b6ab84b6abaa12c184b48b84a6ab8cb8daae32e36ab8cb8daae3,0x20820820f88c7e2b8c9e2323809a]
    decide +kernel
  have e61356 : Deny 5 13 b61356 :=
    branchAction rule_sound _ _ 2
      0x1e3 b61356 b61357 b61684 (by decide +kernel) e61357 e61684
  have e61785 : Deny 5 13 b61785 := by
    apply closeAction rule_sound _ _ 64 [0xc32421e32232232478dfae32e37eb8cb8dfae32e37eb8cb8dfae32e37eb8cb8dfae32e37eb8cb8dfae32f8ae32231f8,0xae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32e36ab8cb8daae32e326322b0832431eb,0x820820838c98c88c78c88c90820820c78c88c98c80826820c80c76ab84b6ab84b6ab84b6ab84b6ab84b2a36ab8cb8da,0x82]
    decide +kernel
  have e61355 : Deny 5 13 b61355 :=
    branchAction rule_sound _ _ 1
      0x9 b61355 b61356 b61785 (by decide +kernel) e61356 e61785
  exact e61355
end OMA.Blocks5_13_245212.S61355
