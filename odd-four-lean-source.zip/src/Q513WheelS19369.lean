import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S19369
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b19369 : Box := ![⟨31,46⟩,⟨63,1920000000000000011376⟩,⟨7,14⟩,⟨3,709875930521091815654⟩,⟨79,113⟩]
theorem deny5_13 : Deny 5 13 ![⟨31,46⟩,⟨63,1920000000000000011376⟩,⟨7,14⟩,⟨3,709875930521091815654⟩,⟨79,113⟩] := by
  have e19369 : Deny 5 13 b19369 := by
    apply closeAction rule_sound _ _ 64 [0xe31e3203e03ae31eb0f88c88c96ab0f80eb8c98c8ac3ac3e2322321a0a110ae37d6b8c98c710b8c80ebaa884a8c98c7,0xae12842e321aadaae322b6ab0c3e2b1e322b0c46b8dc41f88c86ab102238df58c76b8df58c98c40820eb8c98c41f8ac3,0x8c8ac31021f8de322b8c9ae31e311fe370838441f8dc20e1107e37ac3e2b0e32232231e32420e1109e03aa11c2aa884a,0x8c98c8683e03ae11e110ae2b0c38c78c88c90c3dab84784a7da7e12ab8c9adf0eb8c9ac3de322321aac3103e2b8c41f8,0xc8108e37083108e37ac38c88c98c70840aaa2110ae370eb8470eb84984a10bae322325aae311aae3108e2b7f8deb7c3,0x6c3e3784aae325a0f80e126b84aac3ac38c88c86838440f8df58441f8d612840a110ae37ae326b8c78c409b109e37082,0x243e370e11c3ae12611c40820f8ae12611e110b84a8c42386ab8c46ab8c4238ac20f8ae11f8deb0f8deb0e32038c78c8,0xab8c40820ab0f8dc38c88c88c98c41f8083e370f8ae11e1]
    decide +kernel
  exact e19369
end OMA.Blocks5_13_245212.S19369
