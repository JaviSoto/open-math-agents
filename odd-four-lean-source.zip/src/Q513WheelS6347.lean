import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S6347
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b6347 : Box := ![⟨18,22⟩,⟨31,62⟩,⟨23,1920000000000000011376⟩,⟨3,1366486486486486494634⟩,⟨37,47⟩]
theorem deny5_13 : Deny 5 13 ![⟨18,22⟩,⟨31,62⟩,⟨23,1920000000000000011376⟩,⟨3,1366486486486486494634⟩,⟨37,47⟩] := by
  have e6347 : Deny 5 13 b6347 := by
    apply closeAction rule_sound _ _ 64 [0x108e3688a8888871025820c9dc3887888884238dd6dc20831c90838870c988810210b5830f888788888a88888788b88a,0x8842380c91d60c31c3e0788888a8885965832492562960f7da2202236102583da223688758a0c3df61c32622042d60a2,0xf70f71c32430f725edf61f62040b8dc32420c70c920b2a3263223107e16e378961f70820f70c9887884238083277103,0x83248dc3dc3207262108e378c409e0820c72425b70c81c3dc31c92040842ca278dde8840838841f80ef8888842b8dde,0x2082]
    decide +kernel
  exact e6347
end OMA.Blocks5_13_245212.S6347
