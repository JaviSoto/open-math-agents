import FastReplay245212
import SparseDigit245212
import FastRound245212

import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S9180
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b9180 : Box := ![⟨23,46⟩,⟨7,9⟩,⟨7,1920000000000000011376⟩,⟨3,1328583941605839423966⟩,⟨41,53⟩]
theorem deny5_13 : Deny 5 13 ![⟨23,46⟩,⟨7,9⟩,⟨7,1920000000000000011376⟩,⟨3,1328583941605839423966⟩,⟨41,53⟩] := by
  have e9180 : Deny 5 13 b9180 := by
    apply closeAction rule_sound _ _ 64 [0xda3102749e3776325cbdc25c8c98c772f709d882dd88a778df688a778df68c972f738df68c9e37da31c2204087e37da3,0x72f709]
    decide +kernel
  exact e9180
end OMA.Blocks5_13_245212.S9180
