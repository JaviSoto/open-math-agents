import FastReplay245212

/-! A single exponent cut or a single prime cut on a four-prime box.
The trace can skip three unrelated cofactors when only one cut helps. -/
namespace OMA.SparseDigit245212
open Box245212 SparseEngine245212 FastDigit245212

private theorem correct : Correct FastFactor245212.scale hull :=
  fun _ _ _ _ start pi ei=>FastFactor245212.bounds start pi ei

def individual (ax : ℕ) (p q : ℕ) (b : Box) : Option Box :=
  if ∀i,1<(baseBox p q b i).lo then
    let Z := FastFactor245212.scale^3
    let i : Fin 4 := Fin.ofNat 4 (ax-52)
    let j : Fin 5 := if ax=56 then 4 else i.castSucc
    let r := if ax=56 then
      let V := cofactor hull p q b 3
      highPrime Z V.xu V.yu (b 3) (lowPrime Z V.xl V.yl (b 3) (b 4))
    else digitAt Z (cofactor hull p q b i) (b i.castSucc) (baseBox p q b i)
    if r.lo≤r.hi then some (clip b j r) else none
  else some b

theorem individual_sound (ax : ℕ) : CutSound (individual ax) := by
  intro p q b v fit c
  unfold individual
  by_cases start : ∀i,1<(baseBox p q b i).lo
  · simp only [if_pos start]
    let i : Fin 4 := Fin.ofNat 4 (ax-52)
    by_cases last : ax=56
    · simp only [last,if_true]
      have ob := obey_box FastFactor245212.scale_pos correct c fit start 3 (v 4) (v 4) (c.prime 3).pos le_rfl le_rfl
      have w := highPrime_ok (fit 3) (lowPrime_ok (fit 3) (fit 4) ob.1 ob.2.1) ob.2.2
      exact ⟨_,if_pos (w.1.trans w.2),clip_fits fit w⟩
    · simp only [last,if_false]
      have bp := inside_primes (p:=p) (q:=q) fit i
      have w := digitAt_ok (fit i.castSucc) (obey_box FastFactor245212.scale_pos correct c fit start i
        _ _ (start i).le bp.1 bp.2)
      exact ⟨_,if_pos (w.1.trans w.2),clip_fits fit w⟩
  · exact ⟨_,if_neg start,fit⟩

def act (p q op : ℕ) : Stack→Option Stack :=
  if 52≤op ∧ op≤56 then step (individual op) FastReplay245212.leaf p q 6
  else step fastDigit FastReplay245212.leaf p q op

theorem act_sound : AdvanceSound act := by
  intro p q op s t h y
  unfold act at h
  split_ifs at h
  · exact step_sound (individual_sound op) FastReplay245212.leaf_sound p q 6 s t h y
  · exact step_sound (fun _ _ _ _ f c=>fastDigit_sound f c) FastReplay245212.leaf_sound p q op s t h y

theorem certify (p q fuel : ℕ) (ws : List ℕ) (b : Box) (check : run act p q fuel ws [b]=some []) : Deny p q b :=
  run_sound act_sound p q fuel ws check (by simp [solved]) b List.mem_cons_self

end OMA.SparseDigit245212
