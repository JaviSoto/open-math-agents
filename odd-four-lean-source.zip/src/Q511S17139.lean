import FastReplay245212
import SparseDigit245212
import FastRound245212
import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S17139
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b17139 : Box := ![⟨47,94⟩,⟨7,9⟩,⟨15,1920000000000000011376⟩,⟨1,1450666666666666675295⟩,⟨103,999999999999999999⟩]
private def b17140 : Box := ![⟨47,94⟩,⟨7,9⟩,⟨15,1920000000000000011376⟩,⟨1,994807017543859655063⟩,⟨103,206⟩]
private def b17141 : Box := ![⟨47,94⟩,⟨7,7⟩,⟨15,1920000000000000011376⟩,⟨1,994807017543859655055⟩,⟨103,199⟩]
private def b17142 : Box := ![⟨47,94⟩,⟨7,7⟩,⟨25,1920000000000000011376⟩,⟨2,4⟩,⟨103,160⟩]
private def b17143 : Box := ![⟨47,94⟩,⟨7,7⟩,⟨25,1920000000000000011376⟩,⟨5,994807017543859655054⟩,⟨103,160⟩]
private def b17144 : Box := ![⟨47,62⟩,⟨7,7⟩,⟨25,1920000000000000011376⟩,⟨5,994807017543859655054⟩,⟨103,157⟩]
private def b17147 : Box := ![⟨63,94⟩,⟨7,7⟩,⟨25,1920000000000000011376⟩,⟨5,994807017543859655054⟩,⟨103,157⟩]
private def b17148 : Box := ![⟨63,94⟩,⟨7,7⟩,⟨25,50⟩,⟨5,994807017543859655054⟩,⟨103,157⟩]
private def b17153 : Box := ![⟨63,94⟩,⟨7,7⟩,⟨51,1920000000000000011376⟩,⟨5,994807017543859655054⟩,⟨103,157⟩]
private def b17154 : Box := ![⟨63,94⟩,⟨7,7⟩,⟨51,1920000000000000011376⟩,⟨5,994807017543859655054⟩,⟨103,124⟩]
private def b17165 : Box := ![⟨63,94⟩,⟨7,7⟩,⟨51,1920000000000000011376⟩,⟨5,994807017543859655054⟩,⟨125,157⟩]
private def b17170 : Box := ![⟨47,94⟩,⟨8,9⟩,⟨15,1920000000000000011376⟩,⟨1,994807017543859655055⟩,⟨103,199⟩]
private def b17171 : Box := ![⟨47,94⟩,⟨8,9⟩,⟨15,30⟩,⟨1,994807017543859655055⟩,⟨103,199⟩]
private def b17172 : Box := ![⟨47,62⟩,⟨8,9⟩,⟨15,30⟩,⟨1,44⟩,⟨103,199⟩]
private def b17179 : Box := ![⟨63,94⟩,⟨8,9⟩,⟨15,30⟩,⟨1,44⟩,⟨103,199⟩]
private def b17180 : Box := ![⟨63,94⟩,⟨8,9⟩,⟨15,30⟩,⟨1,2⟩,⟨103,199⟩]
private def b17183 : Box := ![⟨63,94⟩,⟨8,9⟩,⟨15,30⟩,⟨3,44⟩,⟨103,199⟩]
private def b17184 : Box := ![⟨63,94⟩,⟨8,9⟩,⟨15,30⟩,⟨3,44⟩,⟨103,135⟩]
private def b17185 : Box := ![⟨63,94⟩,⟨8,9⟩,⟨15,20⟩,⟨3,44⟩,⟨103,131⟩]
private def b17192 : Box := ![⟨63,94⟩,⟨8,9⟩,⟨21,30⟩,⟨3,44⟩,⟨103,131⟩]
private def b17205 : Box := ![⟨63,94⟩,⟨8,9⟩,⟨15,30⟩,⟨3,44⟩,⟨136,199⟩]
private def b17206 : Box := ![⟨63,94⟩,⟨8,9⟩,⟨15,20⟩,⟨3,41⟩,⟨137,199⟩]
private def b17211 : Box := ![⟨63,94⟩,⟨8,9⟩,⟨21,30⟩,⟨3,41⟩,⟨137,199⟩]
private def b17224 : Box := ![⟨47,94⟩,⟨8,9⟩,⟨31,1920000000000000011376⟩,⟨1,994807017543859655055⟩,⟨103,199⟩]
private def b17225 : Box := ![⟨47,94⟩,⟨8,9⟩,⟨31,1920000000000000011376⟩,⟨1,2⟩,⟨103,199⟩]
private def b17226 : Box := ![⟨47,94⟩,⟨8,9⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655055⟩,⟨103,199⟩]
private def b17227 : Box := ![⟨47,62⟩,⟨8,9⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655055⟩,⟨103,199⟩]
private def b17228 : Box := ![⟨47,62⟩,⟨8,9⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655048⟩,⟨103,135⟩]
private def b17229 : Box := ![⟨47,62⟩,⟨8,9⟩,⟨31,62⟩,⟨3,994807017543859655047⟩,⟨103,131⟩]
private def b17230 : Box := ![⟨47,62⟩,⟨8,8⟩,⟨31,62⟩,⟨3,53⟩,⟨103,131⟩]
private def b17231 : Box := ![⟨47,53⟩,⟨8,8⟩,⟨31,62⟩,⟨3,52⟩,⟨103,131⟩]
private def b17238 : Box := ![⟨54,62⟩,⟨8,8⟩,⟨31,62⟩,⟨3,52⟩,⟨103,131⟩]
private def b17249 : Box := ![⟨47,62⟩,⟨9,9⟩,⟨31,62⟩,⟨3,53⟩,⟨103,131⟩]
private def b17258 : Box := ![⟨47,62⟩,⟨8,9⟩,⟨63,1920000000000000011376⟩,⟨3,994807017543859655047⟩,⟨103,131⟩]
private def b17261 : Box := ![⟨47,62⟩,⟨8,9⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655048⟩,⟨136,199⟩]
private def b17262 : Box := ![⟨47,62⟩,⟨8,9⟩,⟨31,62⟩,⟨3,936740088105726877826⟩,⟨137,199⟩]
private def b17263 : Box := ![⟨47,62⟩,⟨8,8⟩,⟨31,62⟩,⟨3,50⟩,⟨137,199⟩]
private def b17264 : Box := ![⟨47,62⟩,⟨9,9⟩,⟨31,62⟩,⟨3,50⟩,⟨137,199⟩]
private def b17265 : Box := ![⟨47,53⟩,⟨9,9⟩,⟨31,62⟩,⟨3,50⟩,⟨137,199⟩]
private def b17274 : Box := ![⟨54,62⟩,⟨9,9⟩,⟨31,62⟩,⟨3,50⟩,⟨137,199⟩]
private def b17285 : Box := ![⟨47,62⟩,⟨8,9⟩,⟨63,1920000000000000011376⟩,⟨3,936740088105726877826⟩,⟨137,199⟩]
private def b17288 : Box := ![⟨63,94⟩,⟨8,9⟩,⟨31,1920000000000000011376⟩,⟨3,994807017543859655055⟩,⟨103,199⟩]
private def b17289 : Box := ![⟨63,94⟩,⟨8,9⟩,⟨31,1920000000000000011376⟩,⟨3,6⟩,⟨103,199⟩]
private def b17290 : Box := ![⟨63,94⟩,⟨8,9⟩,⟨31,1920000000000000011376⟩,⟨7,994807017543859655055⟩,⟨103,199⟩]
private def b17291 : Box := ![⟨63,94⟩,⟨8,9⟩,⟨31,1920000000000000011376⟩,⟨7,994807017543859655055⟩,⟨105,137⟩]
private def b17304 : Box := ![⟨63,94⟩,⟨8,9⟩,⟨31,1920000000000000011376⟩,⟨7,994807017543859655055⟩,⟨138,199⟩]
private def b17305 : Box := ![⟨63,94⟩,⟨8,9⟩,⟨31,62⟩,⟨7,933655323819978051671⟩,⟨139,199⟩]
private def b17312 : Box := ![⟨63,94⟩,⟨8,9⟩,⟨63,1920000000000000011376⟩,⟨7,933655323819978051671⟩,⟨139,199⟩]
private def b17313 : Box := ![⟨63,94⟩,⟨8,8⟩,⟨63,1920000000000000011376⟩,⟨7,933655323819978051671⟩,⟨139,199⟩]
private def b17328 : Box := ![⟨63,94⟩,⟨9,9⟩,⟨63,1920000000000000011376⟩,⟨7,933655323819978051671⟩,⟨139,199⟩]
private def b17329 : Box := ![⟨47,94⟩,⟨7,9⟩,⟨15,1920000000000000011376⟩,⟨1,994807017543859655063⟩,⟨207,999999999999999999⟩]
private def b17330 : Box := ![⟨47,94⟩,⟨7,7⟩,⟨17,1920000000000000011376⟩,⟨1,864390243902439029552⟩,⟨207,999999999999999999⟩]
private def b17331 : Box := ![⟨47,94⟩,⟨8,9⟩,⟨17,1920000000000000011376⟩,⟨1,864390243902439029552⟩,⟨207,999999999999999999⟩]
private def b17332 : Box := ![⟨47,94⟩,⟨8,9⟩,⟨17,1920000000000000011376⟩,⟨1,2⟩,⟨207,999999999999999999⟩]
private def b17333 : Box := ![⟨47,94⟩,⟨8,9⟩,⟨17,1920000000000000011376⟩,⟨3,864390243902439029552⟩,⟨207,999999999999999999⟩]
private def b17334 : Box := ![⟨47,94⟩,⟨8,9⟩,⟨18,36⟩,⟨3,864390243902439029552⟩,⟨207,999999999999999999⟩]
private def b17335 : Box := ![⟨47,62⟩,⟨8,9⟩,⟨18,36⟩,⟨3,48⟩,⟨207,388⟩]
private def b17336 : Box := ![⟨63,94⟩,⟨8,9⟩,⟨18,36⟩,⟨3,48⟩,⟨207,388⟩]
private def b17337 : Box := ![⟨63,94⟩,⟨8,8⟩,⟨18,36⟩,⟨3,41⟩,⟨207,386⟩]
private def b17338 : Box := ![⟨63,94⟩,⟨9,9⟩,⟨18,36⟩,⟨3,41⟩,⟨207,386⟩]
private def b17353 : Box := ![⟨47,94⟩,⟨8,9⟩,⟨37,1920000000000000011376⟩,⟨3,864390243902439029552⟩,⟨207,999999999999999999⟩]
private def b17354 : Box := ![⟨47,62⟩,⟨8,9⟩,⟨37,1920000000000000011376⟩,⟨3,864390243902439029552⟩,⟨207,999999999999999999⟩]
private def b17369 : Box := ![⟨63,94⟩,⟨8,9⟩,⟨37,1920000000000000011376⟩,⟨3,864390243902439029552⟩,⟨207,999999999999999999⟩]
private def b17370 : Box := ![⟨63,94⟩,⟨8,9⟩,⟨37,1920000000000000011376⟩,⟨3,864390243902439029552⟩,⟨207,414⟩]
private def b17371 : Box := ![⟨63,94⟩,⟨8,9⟩,⟨37,1920000000000000011376⟩,⟨3,6⟩,⟨207,414⟩]
private def b17372 : Box := ![⟨63,94⟩,⟨8,9⟩,⟨37,1920000000000000011376⟩,⟨7,864390243902439029545⟩,⟨207,414⟩]
private def b17373 : Box := ![⟨63,94⟩,⟨8,8⟩,⟨37,1920000000000000011376⟩,⟨7,864390243902439029545⟩,⟨207,414⟩]
private def b17374 : Box := ![⟨63,75⟩,⟨8,8⟩,⟨41,1920000000000000011376⟩,⟨7,864390243902439029545⟩,⟨207,374⟩]
private def b17377 : Box := ![⟨76,94⟩,⟨8,8⟩,⟨41,1920000000000000011376⟩,⟨7,864390243902439029545⟩,⟨207,374⟩]
private def b17392 : Box := ![⟨63,94⟩,⟨9,9⟩,⟨37,1920000000000000011376⟩,⟨7,864390243902439029545⟩,⟨207,414⟩]
private def b17393 : Box := ![⟨63,94⟩,⟨9,9⟩,⟨37,74⟩,⟨7,864390243902439029545⟩,⟨207,414⟩]
private def b17406 : Box := ![⟨63,94⟩,⟨9,9⟩,⟨75,1920000000000000011376⟩,⟨7,864390243902439029545⟩,⟨207,414⟩]
private def b17411 : Box := ![⟨63,94⟩,⟨8,9⟩,⟨37,1920000000000000011376⟩,⟨3,864390243902439029552⟩,⟨415,999999999999999999⟩]
private def b17412 : Box := ![⟨63,94⟩,⟨8,8⟩,⟨37,1920000000000000011376⟩,⟨3,764204851752021567905⟩,⟨415,999999999999999999⟩]
private def b17413 : Box := ![⟨63,94⟩,⟨9,9⟩,⟨37,1920000000000000011376⟩,⟨3,764204851752021567905⟩,⟨415,999999999999999999⟩]
private def b17414 : Box := ![⟨63,94⟩,⟨9,9⟩,⟨37,74⟩,⟨3,764204851752021567905⟩,⟨415,999999999999999999⟩]
private def b17419 : Box := ![⟨63,94⟩,⟨9,9⟩,⟨75,1920000000000000011376⟩,⟨3,764204851752021567905⟩,⟨415,999999999999999999⟩]
private def b17420 : Box := ![⟨63,94⟩,⟨9,9⟩,⟨75,1920000000000000011376⟩,⟨3,6⟩,⟨415,999999999999999999⟩]
private def b17421 : Box := ![⟨63,94⟩,⟨9,9⟩,⟨75,1920000000000000011376⟩,⟨7,764204851752021567905⟩,⟨415,999999999999999999⟩]
private def b17422 : Box := ![⟨63,75⟩,⟨9,9⟩,⟨75,1920000000000000011376⟩,⟨7,764204851752021567905⟩,⟨415,999999999999999999⟩]
private def b17425 : Box := ![⟨76,94⟩,⟨9,9⟩,⟨75,1920000000000000011376⟩,⟨7,764204851752021567905⟩,⟨415,999999999999999999⟩]
private def b17426 : Box := ![⟨76,94⟩,⟨9,9⟩,⟨75,1920000000000000011376⟩,⟨7,764204851752021567905⟩,⟨415,830⟩]
private def b17431 : Box := ![⟨76,94⟩,⟨9,9⟩,⟨75,1920000000000000011376⟩,⟨7,764204851752021567905⟩,⟨831,999999999999999999⟩]
private def b17432 : Box := ![⟨76,94⟩,⟨9,9⟩,⟨75,150⟩,⟨7,685382755842062856631⟩,⟨831,999999999999999999⟩]
private def b17433 : Box := ![⟨76,94⟩,⟨9,9⟩,⟨151,1920000000000000011376⟩,⟨7,685382755842062856631⟩,⟨831,999999999999999999⟩]
private def b17434 : Box := ![⟨76,94⟩,⟨9,9⟩,⟨151,302⟩,⟨7,685382755842062856631⟩,⟨831,999999999999999999⟩]
private def b17435 : Box := ![⟨76,94⟩,⟨9,9⟩,⟨303,1920000000000000011376⟩,⟨7,685382755842062856631⟩,⟨831,999999999999999999⟩]
private def b17436 : Box := ![⟨76,94⟩,⟨9,9⟩,⟨303,1920000000000000011376⟩,⟨14,685382755842062856631⟩,⟨831,1662⟩]
private def b17437 : Box := ![⟨76,94⟩,⟨9,9⟩,⟨303,1920000000000000011376⟩,⟨14,685382755842062856631⟩,⟨1663,999999999999999999⟩]
private def b17438 : Box := ![⟨76,94⟩,⟨9,9⟩,⟨303,1920000000000000011376⟩,⟨14,621300219138056979605⟩,⟨1663,3326⟩]
private def b17439 : Box := ![⟨76,94⟩,⟨9,9⟩,⟨303,1920000000000000011376⟩,⟨14,621300219138056979605⟩,⟨3327,999999999999999999⟩]
private def b17440 : Box := ![⟨76,84⟩,⟨9,9⟩,⟨303,1920000000000000011376⟩,⟨14,568176352705410825036⟩,⟨3327,999999999999999999⟩]
private def b17441 : Box := ![⟨85,94⟩,⟨9,9⟩,⟨303,1920000000000000011376⟩,⟨14,568176352705410825036⟩,⟨3327,999999999999999999⟩]
private def b17442 : Box := ![⟨85,94⟩,⟨9,9⟩,⟨303,1920000000000000011376⟩,⟨14,568176352705410825036⟩,⟨3327,6654⟩]
private def b17443 : Box := ![⟨85,94⟩,⟨9,9⟩,⟨303,1920000000000000011376⟩,⟨14,568176352705410825036⟩,⟨6655,999999999999999999⟩]
private def b17444 : Box := ![⟨85,94⟩,⟨9,9⟩,⟨303,1920000000000000011376⟩,⟨14,523421538461538464664⟩,⟨6655,13310⟩]
private def b17445 : Box := ![⟨85,94⟩,⟨9,9⟩,⟨303,1920000000000000011376⟩,⟨14,523421538461538464664⟩,⟨13311,999999999999999999⟩]
private def b17446 : Box := ![⟨85,89⟩,⟨9,9⟩,⟨360,1920000000000000011376⟩,⟨14,485202509982886483216⟩,⟨13311,999999999999999999⟩]
private def b17447 : Box := ![⟨90,94⟩,⟨9,9⟩,⟨360,1920000000000000011376⟩,⟨14,485202509982886483216⟩,⟨13311,999999999999999999⟩]
private def b17448 : Box := ![⟨90,94⟩,⟨9,9⟩,⟨360,1920000000000000011376⟩,⟨17,485202509982886483216⟩,⟨13311,26622⟩]
private def b17449 : Box := ![⟨90,94⟩,⟨9,9⟩,⟨360,1920000000000000011376⟩,⟨17,485202509982886483216⟩,⟨26623,999999999999999999⟩]
private def b17450 : Box := ![⟨90,94⟩,⟨9,9⟩,⟨423,846⟩,⟨17,452185007974481661392⟩,⟨26623,999999999999999999⟩]
private def b17451 : Box := ![⟨90,94⟩,⟨9,9⟩,⟨847,1920000000000000011376⟩,⟨17,452185007974481661392⟩,⟨26623,999999999999999999⟩]
theorem deny5_11 : Deny 5 11 ![⟨47,94⟩,⟨7,9⟩,⟨15,1920000000000000011376⟩,⟨1,1450666666666666675295⟩,⟨103,999999999999999999⟩] := by
  have e17142 : Deny 5 11 b17142 := by
    apply closeAction rule_sound _ _ 64 [0x2884]
    decide +kernel
  have e17144 : Deny 5 11 b17144 := by
    apply closeAction rule_sound _ _ 64 [0x72f11cbe3109e37da3]
    decide +kernel
  have e17148 : Deny 5 11 b17148 := by
    apply closeAction rule_sound _ _ 64 [0x755e362a311de37da3107e37da3]
    decide +kernel
  have e17154 : Deny 5 11 b17154 := by
    apply closeAction rule_sound _ _ 64 [0x14e37bdd54a8c972f72f8c9bddde32631c4]
    decide +kernel
  have e17165 : Deny 5 11 b17165 := by
    apply closeAction rule_sound _ _ 64 [0x72f76f8c9bdde37da32768c4]
    decide +kernel
  have e17153 : Deny 5 11 b17153 :=
    branchAction rule_sound _ _ 1
      0xb b17153 b17154 b17165 (by decide +kernel) e17154 e17165
  have e17147 : Deny 5 11 b17147 :=
    branchAction rule_sound _ _ 1
      0x9 b17147 b17148 b17153 (by decide +kernel) e17148 e17153
  have e17143 : Deny 5 11 b17143 :=
    branchAction rule_sound _ _ 2
      0x1c4 b17143 b17144 b17147 (by decide +kernel) e17144 e17147
  have e17141 : Deny 5 11 b17141 :=
    branchAction rule_sound _ _ 5
      0xae37da3 b17141 b17142 b17143 (by decide +kernel) e17142 e17143
  have e17172 : Deny 5 11 b17172 := by
    apply closeAction rule_sound _ _ 64 [0x30f8de31c3e378c911de37d84238de3]
    decide +kernel
  have e17180 : Deny 5 11 b17180 := by
    apply closeAction rule_sound _ _ 64 [0x15578df6809]
    decide +kernel
  have e17185 : Deny 5 11 b17185 := by
    apply closeAction rule_sound _ _ 64 [0xc38c90c3e378c9de3223]
    decide +kernel
  have e17192 : Deny 5 11 b17192 := by
    apply closeAction rule_sound _ _ 64 [0x95e370c9107e370c38c70c3e378c98c78c8]
    decide +kernel
  have e17184 : Deny 5 11 b17184 :=
    branchAction rule_sound _ _ 2
      0x244 b17184 b17185 b17192 (by decide +kernel) e17185 e17192
  have e17206 : Deny 5 11 b17206 := by
    apply closeAction rule_sound _ _ 64 [0xc3e23242223]
    decide +kernel
  have e17211 : Deny 5 11 b17211 := by
    apply closeAction rule_sound _ _ 64 [0x3e038c70c3e232631c3778df68c71021f8dc8]
    decide +kernel
  have e17205 : Deny 5 11 b17205 :=
    branchAction rule_sound _ _ 3
      0x98c4 b17205 b17206 b17211 (by decide +kernel) e17206 e17211
  have e17183 : Deny 5 11 b17183 :=
    branchAction rule_sound _ _ 1
      0xb b17183 b17184 b17205 (by decide +kernel) e17184 e17205
  have e17179 : Deny 5 11 b17179 :=
    branchAction rule_sound _ _ 1
      0xa b17179 b17180 b17183 (by decide +kernel) e17180 e17183
  have e17171 : Deny 5 11 b17171 :=
    branchAction rule_sound _ _ 2
      0x1e3 b17171 b17172 b17179 (by decide +kernel) e17172 e17179
  have e17225 : Deny 5 11 b17225 := by
    apply closeAction rule_sound _ _ 64 [0x562]
    decide +kernel
  have e17231 : Deny 5 11 b17231 := by
    apply closeAction rule_sound _ _ 64 [0x1ddf68c475d778df68842b8df688a2f8de3]
    decide +kernel
  have e17238 : Deny 5 11 b17238 := by
    apply closeAction rule_sound _ _ 64 [0x75d7550f8da21e210ae2228a54a]
    decide +kernel
  have e17230 : Deny 5 11 b17230 :=
    branchAction rule_sound _ _ 2
      0x1e3 b17230 b17231 b17238 (by decide +kernel) e17231 e17238
  have e17249 : Deny 5 11 b17249 := by
    apply closeAction rule_sound _ _ 64 [0x578de2103109e370f8def0f8bc7dc38c98c7]
    decide +kernel
  have e17229 : Deny 5 11 b17229 :=
    branchAction rule_sound _ _ 2
      0x223 b17229 b17230 b17249 (by decide +kernel) e17230 e17249
  have e17258 : Deny 5 11 b17258 := by
    apply closeAction rule_sound _ _ 64 [0x72f76f8c9]
    decide +kernel
  have e17228 : Deny 5 11 b17228 :=
    branchAction rule_sound _ _ 3
      0x98c4 b17228 b17229 b17258 (by decide +kernel) e17229 e17258
  have e17263 : Deny 5 11 b17263 := by
    apply closeAction rule_sound _ _ 64 [0x1de37da3]
    decide +kernel
  have e17265 : Deny 5 11 b17265 := by
    apply closeAction rule_sound _ _ 64 [0x1d7438840a2107e368842b888a103e37da210ae23]
    decide +kernel
  have e17274 : Deny 5 11 b17274 := by
    apply closeAction rule_sound _ _ 64 [0x75d0f80f888788a10ae03e222838c9]
    decide +kernel
  have e17264 : Deny 5 11 b17264 :=
    branchAction rule_sound _ _ 1
      0x7 b17264 b17265 b17274 (by decide +kernel) e17265 e17274
  have e17262 : Deny 5 11 b17262 :=
    branchAction rule_sound _ _ 2
      0x223 b17262 b17263 b17264 (by decide +kernel) e17263 e17264
  have e17285 : Deny 5 11 b17285 := by
    apply closeAction rule_sound _ _ 64 [0x72f76f8c9]
    decide +kernel
  have e17261 : Deny 5 11 b17261 :=
    branchAction rule_sound _ _ 3
      0x98c4 b17261 b17262 b17285 (by decide +kernel) e17262 e17285
  have e17227 : Deny 5 11 b17227 :=
    branchAction rule_sound _ _ 2
      0x2e3 b17227 b17228 b17261 (by decide +kernel) e17228 e17261
  have e17289 : Deny 5 11 b17289 := by
    apply closeAction rule_sound _ _ 64 [0x562]
    decide +kernel
  have e17291 : Deny 5 11 b17291 := by
    apply closeAction rule_sound _ _ 64 [0x8276f8841f8ddd75d54a28a8c98c88c4]
    decide +kernel
  have e17305 : Deny 5 11 b17305 := by
    apply closeAction rule_sound _ _ 64 [0x75d75528a2a3]
    decide +kernel
  have e17313 : Deny 5 11 b17313 := by
    apply closeAction rule_sound _ _ 64 [0xaf8c476f75d54a88a8c98c427872f8c4709e2f76f8c98c7]
    decide +kernel
  have e17328 : Deny 5 11 b17328 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e17312 : Deny 5 11 b17312 :=
    branchAction rule_sound _ _ 1
      0x8 b17312 b17313 b17328 (by decide +kernel) e17313 e17328
  have e17304 : Deny 5 11 b17304 :=
    branchAction rule_sound _ _ 3
      0x98c4 b17304 b17305 b17312 (by decide +kernel) e17305 e17312
  have e17290 : Deny 5 11 b17290 :=
    branchAction rule_sound _ _ 2
      0x2f8 b17290 b17291 b17304 (by decide +kernel) e17291 e17304
  have e17288 : Deny 5 11 b17288 :=
    branchAction rule_sound _ _ 1
      0xa b17288 b17289 b17290 (by decide +kernel) e17289 e17290
  have e17226 : Deny 5 11 b17226 :=
    branchAction rule_sound _ _ 1
      0x7 b17226 b17227 b17288 (by decide +kernel) e17227 e17288
  have e17224 : Deny 5 11 b17224 :=
    branchAction rule_sound _ _ 1
      0xa b17224 b17225 b17226 (by decide +kernel) e17225 e17226
  have e17170 : Deny 5 11 b17170 :=
    branchAction rule_sound _ _ 1
      0x9 b17170 b17171 b17224 (by decide +kernel) e17171 e17224
  have e17140 : Deny 5 11 b17140 :=
    branchAction rule_sound _ _ 3
      0x88c4 b17140 b17141 b17170 (by decide +kernel) e17141 e17170
  have e17330 : Deny 5 11 b17330 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e17332 : Deny 5 11 b17332 := by
    apply closeAction rule_sound _ _ 64 [0x578da2]
    decide +kernel
  have e17335 : Deny 5 11 b17335 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e17337 : Deny 5 11 b17337 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e17338 : Deny 5 11 b17338 := by
    apply closeAction rule_sound _ _ 64 [0xf80f88c70f88c90f7d84778df68c41f8de31dd0f8d8adc4087e378c9]
    decide +kernel
  have e17336 : Deny 5 11 b17336 :=
    branchAction rule_sound _ _ 3
      0x8e23 b17336 b17337 b17338 (by decide +kernel) e17337 e17338
  have e17334 : Deny 5 11 b17334 :=
    branchAction rule_sound _ _ 3
      0x7e23 b17334 b17335 b17336 (by decide +kernel) e17335 e17336
  have e17354 : Deny 5 11 b17354 := by
    apply closeAction rule_sound _ _ 64 [0x72f76f8c9bdd0f8da229ce37da31f61021f8da324288a8c2238da3]
    decide +kernel
  have e17371 : Deny 5 11 b17371 := by
    apply closeAction rule_sound _ _ 64 [0x562]
    decide +kernel
  have e17374 : Deny 5 11 b17374 := by
    apply closeAction rule_sound _ _ 64 [0x72f8c472f8c4278da3]
    decide +kernel
  have e17377 : Deny 5 11 b17377 := by
    apply closeAction rule_sound _ _ 64 [0x72f76f8c97430e325dde31cb778de327611de37da3107e368c9]
    decide +kernel
  have e17373 : Deny 5 11 b17373 :=
    branchAction rule_sound _ _ 3
      0x7e36 b17373 b17374 b17377 (by decide +kernel) e17374 e17377
  have e17393 : Deny 5 11 b17393 := by
    apply closeAction rule_sound _ _ 64 [0x1d75d555543e368841f8da2107e221e228a2a3]
    decide +kernel
  have e17406 : Deny 5 11 b17406 := by
    apply closeAction rule_sound _ _ 64 [0x2707e2f8ddbe3278]
    decide +kernel
  have e17392 : Deny 5 11 b17392 :=
    branchAction rule_sound _ _ 1
      0x9 b17392 b17393 b17406 (by decide +kernel) e17393 e17406
  have e17372 : Deny 5 11 b17372 :=
    branchAction rule_sound _ _ 1
      0x8 b17372 b17373 b17392 (by decide +kernel) e17373 e17392
  have e17370 : Deny 5 11 b17370 :=
    branchAction rule_sound _ _ 2
      0x2a3 b17370 b17371 b17372 (by decide +kernel) e17371 e17372
  have e17412 : Deny 5 11 b17412 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e17414 : Deny 5 11 b17414 := by
    apply closeAction rule_sound _ _ 64 [0x1d54ae23087e23]
    decide +kernel
  have e17420 : Deny 5 11 b17420 := by
    apply closeAction rule_sound _ _ 64 [0x14e22]
    decide +kernel
  have e17422 : Deny 5 11 b17422 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe376f8c9e23]
    decide +kernel
  have e17426 : Deny 5 11 b17426 := by
    apply closeAction rule_sound _ _ 64 [0x9c1f8bddbe3263]
    decide +kernel
  have e17432 : Deny 5 11 b17432 := by
    apply closeAction rule_sound _ _ 64 [0x1de23]
    decide +kernel
  have e17434 : Deny 5 11 b17434 := by
    apply closeAction rule_sound _ _ 64 [0x1de23]
    decide +kernel
  have e17436 : Deny 5 11 b17436 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e17438 : Deny 5 11 b17438 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e17440 : Deny 5 11 b17440 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e17442 : Deny 5 11 b17442 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e17444 : Deny 5 11 b17444 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e17446 : Deny 5 11 b17446 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e17448 : Deny 5 11 b17448 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e17450 : Deny 5 11 b17450 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e17451 : Deny 5 11 b17451 := by
    apply closeAction rule_sound _ _ 64 [0x209cbe3278be372f8c9e2f8dcbe3278bdcbe326f087d87bdcbe326f]
    decide +kernel
  have e17449 : Deny 5 11 b17449 :=
    branchAction rule_sound _ _ 3
      0x9da3 b17449 b17450 b17451 (by decide +kernel) e17450 e17451
  have e17447 : Deny 5 11 b17447 :=
    branchAction rule_sound _ _ 2
      0x2ef b17447 b17448 b17449 (by decide +kernel) e17448 e17449
  have e17445 : Deny 5 11 b17445 :=
    branchAction rule_sound _ _ 3
      0x7da3 b17445 b17446 b17447 (by decide +kernel) e17446 e17447
  have e17443 : Deny 5 11 b17443 :=
    branchAction rule_sound _ _ 2
      0x2e3 b17443 b17444 b17445 (by decide +kernel) e17444 e17445
  have e17441 : Deny 5 11 b17441 :=
    branchAction rule_sound _ _ 1
      0xb b17441 b17442 b17443 (by decide +kernel) e17442 e17443
  have e17439 : Deny 5 11 b17439 :=
    branchAction rule_sound _ _ 2
      0x1e3 b17439 b17440 b17441 (by decide +kernel) e17440 e17441
  have e17437 : Deny 5 11 b17437 :=
    branchAction rule_sound _ _ 2
      0x2e3 b17437 b17438 b17439 (by decide +kernel) e17438 e17439
  have e17435 : Deny 5 11 b17435 :=
    branchAction rule_sound _ _ 2
      0x2ef b17435 b17436 b17437 (by decide +kernel) e17436 e17437
  have e17433 : Deny 5 11 b17433 :=
    branchAction rule_sound _ _ 1
      0x9 b17433 b17434 b17435 (by decide +kernel) e17434 e17435
  have e17431 : Deny 5 11 b17431 :=
    branchAction rule_sound _ _ 2
      0x263 b17431 b17432 b17433 (by decide +kernel) e17432 e17433
  have e17425 : Deny 5 11 b17425 :=
    branchAction rule_sound _ _ 1
      0xb b17425 b17426 b17431 (by decide +kernel) e17426 e17431
  have e17421 : Deny 5 11 b17421 :=
    branchAction rule_sound _ _ 1
      0x7 b17421 b17422 b17425 (by decide +kernel) e17422 e17425
  have e17419 : Deny 5 11 b17419 :=
    branchAction rule_sound _ _ 1
      0xa b17419 b17420 b17421 (by decide +kernel) e17420 e17421
  have e17413 : Deny 5 11 b17413 :=
    branchAction rule_sound _ _ 1
      0x9 b17413 b17414 b17419 (by decide +kernel) e17414 e17419
  have e17411 : Deny 5 11 b17411 :=
    branchAction rule_sound _ _ 2
      0x223 b17411 b17412 b17413 (by decide +kernel) e17412 e17413
  have e17369 : Deny 5 11 b17369 :=
    branchAction rule_sound _ _ 1
      0xb b17369 b17370 b17411 (by decide +kernel) e17370 e17411
  have e17353 : Deny 5 11 b17353 :=
    branchAction rule_sound _ _ 1
      0x7 b17353 b17354 b17369 (by decide +kernel) e17354 e17369
  have e17333 : Deny 5 11 b17333 :=
    branchAction rule_sound _ _ 2
      0x276 b17333 b17334 b17353 (by decide +kernel) e17334 e17353
  have e17331 : Deny 5 11 b17331 :=
    branchAction rule_sound _ _ 1
      0xa b17331 b17332 b17333 (by decide +kernel) e17332 e17333
  have e17329 : Deny 5 11 b17329 :=
    branchAction rule_sound _ _ 3
      0x8da3 b17329 b17330 b17331 (by decide +kernel) e17330 e17331
  have e17139 : Deny 5 11 b17139 :=
    branchAction rule_sound _ _ 2
      0x2e3 b17139 b17140 b17329 (by decide +kernel) e17140 e17329
  exact e17139
end OMA.Blocks5_11_245212.S17139
