import FastReplay245212
import SparseDigit245212
import FastRound245212
import WheelRule245212

/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_11_245212.S13369
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.WheelRule245212.rule
private theorem rule_sound : AdvanceSound rule := OMA.WheelRule245212.sound
private def b13369 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨1,1445853658536585374451⟩,⟨207,999999999999999999⟩]
private def b13370 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨1,1445853658536585374451⟩,⟨207,414⟩]
private def b13371 : Box := ![⟨18,19⟩,⟨63,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨1,1445853658536585374444⟩,⟨207,414⟩]
private def b13372 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨31,1920000000000000011376⟩,⟨1,1445853658536585374444⟩,⟨207,414⟩]
private def b13373 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨31,62⟩,⟨1,864390243902439029565⟩,⟨207,414⟩]
private def b13374 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨31,62⟩,⟨1,73⟩,⟨207,276⟩]
private def b13375 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨31,62⟩,⟨1,73⟩,⟨277,414⟩]
private def b13376 : Box := ![⟨18,19⟩,⟨63,84⟩,⟨31,62⟩,⟨1,69⟩,⟨277,414⟩]
private def b13377 : Box := ![⟨18,19⟩,⟨63,84⟩,⟨31,62⟩,⟨1,2⟩,⟨277,414⟩]
private def b13378 : Box := ![⟨18,19⟩,⟨63,84⟩,⟨31,62⟩,⟨3,57⟩,⟨277,414⟩]
private def b13393 : Box := ![⟨18,19⟩,⟨85,126⟩,⟨31,62⟩,⟨1,69⟩,⟨277,414⟩]
private def b13394 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨63,1920000000000000011376⟩,⟨1,864390243902439029565⟩,⟨207,414⟩]
private def b13395 : Box := ![⟨18,19⟩,⟨127,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨1,1445853658536585374444⟩,⟨207,414⟩]
private def b13396 : Box := ![⟨20,22⟩,⟨63,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨1,1445853658536585374444⟩,⟨207,414⟩]
private def b13397 : Box := ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨1,1445853658536585374451⟩,⟨415,999999999999999999⟩]
private def b13398 : Box := ![⟨18,19⟩,⟨63,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨1,1278274932614555263666⟩,⟨415,999999999999999999⟩]
private def b13399 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨31,1920000000000000011376⟩,⟨1,1278274932614555263665⟩,⟨415,999999999999999999⟩]
private def b13400 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨31,62⟩,⟨1,764204851752021567923⟩,⟨415,999999999999999999⟩]
private def b13401 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨31,62⟩,⟨1,70⟩,⟨415,830⟩]
private def b13402 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨31,62⟩,⟨1,2⟩,⟨415,830⟩]
private def b13403 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨31,62⟩,⟨3,64⟩,⟨415,830⟩]
private def b13404 : Box := ![⟨18,19⟩,⟨63,84⟩,⟨31,62⟩,⟨3,64⟩,⟨415,830⟩]
private def b13405 : Box := ![⟨18,19⟩,⟨63,84⟩,⟨31,41⟩,⟨3,53⟩,⟨415,830⟩]
private def b13406 : Box := ![⟨18,18⟩,⟨63,84⟩,⟨31,41⟩,⟨3,45⟩,⟨415,830⟩]
private def b13419 : Box := ![⟨19,19⟩,⟨63,84⟩,⟨31,41⟩,⟨3,45⟩,⟨415,830⟩]
private def b13426 : Box := ![⟨18,19⟩,⟨63,84⟩,⟨42,62⟩,⟨3,53⟩,⟨415,830⟩]
private def b13435 : Box := ![⟨18,19⟩,⟨85,126⟩,⟨31,62⟩,⟨3,64⟩,⟨415,830⟩]
private def b13436 : Box := ![⟨18,18⟩,⟨85,126⟩,⟨31,62⟩,⟨3,64⟩,⟨415,830⟩]
private def b13437 : Box := ![⟨18,18⟩,⟨85,126⟩,⟨31,41⟩,⟨3,64⟩,⟨415,830⟩]
private def b13450 : Box := ![⟨18,18⟩,⟨85,126⟩,⟨42,62⟩,⟨3,64⟩,⟨415,830⟩]
private def b13457 : Box := ![⟨19,19⟩,⟨85,126⟩,⟨31,62⟩,⟨3,64⟩,⟨415,830⟩]
private def b13458 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨31,62⟩,⟨1,70⟩,⟨831,999999999999999999⟩]
private def b13459 : Box := ![⟨18,19⟩,⟨63,84⟩,⟨31,62⟩,⟨1,63⟩,⟨831,999999999999999999⟩]
private def b13460 : Box := ![⟨18,19⟩,⟨63,84⟩,⟨31,41⟩,⟨1,53⟩,⟨831,999999999999999999⟩]
private def b13461 : Box := ![⟨18,18⟩,⟨63,84⟩,⟨31,41⟩,⟨1,45⟩,⟨831,999999999999999999⟩]
private def b13462 : Box := ![⟨19,19⟩,⟨63,84⟩,⟨31,41⟩,⟨1,45⟩,⟨831,999999999999999999⟩]
private def b13477 : Box := ![⟨18,19⟩,⟨63,84⟩,⟨42,62⟩,⟨1,53⟩,⟨831,999999999999999999⟩]
private def b13478 : Box := ![⟨18,18⟩,⟨63,84⟩,⟨42,62⟩,⟨1,53⟩,⟨831,999999999999999999⟩]
private def b13491 : Box := ![⟨19,19⟩,⟨63,84⟩,⟨42,62⟩,⟨1,53⟩,⟨831,999999999999999999⟩]
private def b13492 : Box := ![⟨19,19⟩,⟨63,84⟩,⟨42,62⟩,⟨1,53⟩,⟨831,1662⟩]
private def b13497 : Box := ![⟨19,19⟩,⟨63,84⟩,⟨42,62⟩,⟨1,53⟩,⟨1663,999999999999999999⟩]
private def b13508 : Box := ![⟨18,19⟩,⟨85,126⟩,⟨31,62⟩,⟨1,63⟩,⟨831,999999999999999999⟩]
private def b13509 : Box := ![⟨18,19⟩,⟨85,126⟩,⟨31,41⟩,⟨1,63⟩,⟨831,999999999999999999⟩]
private def b13510 : Box := ![⟨18,18⟩,⟨85,126⟩,⟨31,41⟩,⟨1,55⟩,⟨831,999999999999999999⟩]
private def b13525 : Box := ![⟨19,19⟩,⟨85,126⟩,⟨31,41⟩,⟨1,55⟩,⟨831,999999999999999999⟩]
private def b13540 : Box := ![⟨18,19⟩,⟨85,126⟩,⟨42,62⟩,⟨1,63⟩,⟨831,999999999999999999⟩]
private def b13541 : Box := ![⟨18,18⟩,⟨85,126⟩,⟨42,62⟩,⟨1,63⟩,⟨831,999999999999999999⟩]
private def b13542 : Box := ![⟨18,18⟩,⟨85,126⟩,⟨42,62⟩,⟨1,63⟩,⟨831,1662⟩]
private def b13553 : Box := ![⟨18,18⟩,⟨85,126⟩,⟨42,62⟩,⟨1,63⟩,⟨1663,999999999999999999⟩]
private def b13554 : Box := ![⟨18,18⟩,⟨85,101⟩,⟨42,62⟩,⟨1,57⟩,⟨1663,999999999999999999⟩]
private def b13565 : Box := ![⟨18,18⟩,⟨102,126⟩,⟨42,62⟩,⟨1,57⟩,⟨1663,999999999999999999⟩]
private def b13580 : Box := ![⟨19,19⟩,⟨85,126⟩,⟨42,62⟩,⟨1,63⟩,⟨831,999999999999999999⟩]
private def b13581 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567923⟩,⟨415,999999999999999999⟩]
private def b13582 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567923⟩,⟨415,830⟩]
private def b13583 : Box := ![⟨18,19⟩,⟨63,84⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567917⟩,⟨415,830⟩]
private def b13584 : Box := ![⟨18,19⟩,⟨63,84⟩,⟨63,126⟩,⟨1,764204851752021567906⟩,⟨415,830⟩]
private def b13599 : Box := ![⟨18,19⟩,⟨63,84⟩,⟨127,1920000000000000011376⟩,⟨1,764204851752021567906⟩,⟨415,830⟩]
private def b13600 : Box := ![⟨18,19⟩,⟨85,126⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567917⟩,⟨415,830⟩]
private def b13601 : Box := ![⟨18,19⟩,⟨63,126⟩,⟨63,1920000000000000011376⟩,⟨1,764204851752021567923⟩,⟨831,999999999999999999⟩]
private def b13602 : Box := ![⟨18,19⟩,⟨63,84⟩,⟨63,1920000000000000011376⟩,⟨1,685382755842062856647⟩,⟨831,999999999999999999⟩]
private def b13603 : Box := ![⟨18,19⟩,⟨63,84⟩,⟨63,126⟩,⟨1,685382755842062856637⟩,⟨831,999999999999999999⟩]
private def b13604 : Box := ![⟨18,18⟩,⟨63,84⟩,⟨63,126⟩,⟨1,76⟩,⟨831,999999999999999999⟩]
private def b13605 : Box := ![⟨18,18⟩,⟨63,84⟩,⟨63,126⟩,⟨1,76⟩,⟨831,1662⟩]
private def b13606 : Box := ![⟨18,18⟩,⟨63,84⟩,⟨63,126⟩,⟨1,2⟩,⟨831,1662⟩]
private def b13607 : Box := ![⟨18,18⟩,⟨63,84⟩,⟨63,126⟩,⟨3,71⟩,⟨831,1662⟩]
private def b13622 : Box := ![⟨18,18⟩,⟨63,84⟩,⟨63,126⟩,⟨1,76⟩,⟨1663,999999999999999999⟩]
private def b13623 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨63,126⟩,⟨1,68⟩,⟨1663,999999999999999999⟩]
private def b13628 : Box := ![⟨18,18⟩,⟨73,84⟩,⟨63,126⟩,⟨1,68⟩,⟨1663,999999999999999999⟩]
private def b13629 : Box := ![⟨18,18⟩,⟨73,84⟩,⟨63,84⟩,⟨1,68⟩,⟨1663,999999999999999999⟩]
private def b13634 : Box := ![⟨18,18⟩,⟨73,84⟩,⟨85,126⟩,⟨1,68⟩,⟨1663,999999999999999999⟩]
private def b13635 : Box := ![⟨18,18⟩,⟨73,84⟩,⟨85,126⟩,⟨1,68⟩,⟨1663,3326⟩]
private def b13638 : Box := ![⟨18,18⟩,⟨73,84⟩,⟨85,126⟩,⟨1,68⟩,⟨3327,999999999999999999⟩]
private def b13651 : Box := ![⟨19,19⟩,⟨63,84⟩,⟨63,126⟩,⟨1,76⟩,⟨831,999999999999999999⟩]
private def b13658 : Box := ![⟨18,19⟩,⟨63,84⟩,⟨127,1920000000000000011376⟩,⟨1,685382755842062856637⟩,⟨831,999999999999999999⟩]
private def b13659 : Box := ![⟨18,18⟩,⟨63,84⟩,⟨127,1920000000000000011376⟩,⟨3,685382755842062856637⟩,⟨1267,999999999999999999⟩]
private def b13660 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨127,1920000000000000011376⟩,⟨3,644852160727824113029⟩,⟨1267,999999999999999999⟩]
private def b13661 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨127,1920000000000000011376⟩,⟨3,644852160727824113027⟩,⟨1267,2534⟩]
private def b13664 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨127,1920000000000000011376⟩,⟨3,644852160727824113027⟩,⟨2535,999999999999999999⟩]
private def b13665 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨127,254⟩,⟨3,587809260539046306207⟩,⟨2535,999999999999999999⟩]
private def b13666 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨127,254⟩,⟨4,102⟩,⟨2535,5070⟩]
private def b13667 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨127,254⟩,⟨4,102⟩,⟨5071,999999999999999999⟩]
private def b13668 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨127,254⟩,⟨4,93⟩,⟨5071,10142⟩]
private def b13669 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨127,254⟩,⟨4,93⟩,⟨10143,999999999999999999⟩]
private def b13670 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨127,254⟩,⟨4,86⟩,⟨10143,20286⟩]
private def b13671 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨127,254⟩,⟨4,86⟩,⟨20287,999999999999999999⟩]
private def b13672 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨127,254⟩,⟨4,80⟩,⟨20287,40574⟩]
private def b13673 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨127,254⟩,⟨4,80⟩,⟨40575,999999999999999999⟩]
private def b13674 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨130,254⟩,⟨4,75⟩,⟨40575,81150⟩]
private def b13675 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨130,254⟩,⟨4,75⟩,⟨81151,999999999999999999⟩]
private def b13676 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨132,254⟩,⟨4,70⟩,⟨81151,162302⟩]
private def b13677 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨132,254⟩,⟨4,70⟩,⟨162303,999999999999999999⟩]
private def b13678 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨133,254⟩,⟨4,66⟩,⟨162303,324606⟩]
private def b13679 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨133,254⟩,⟨4,66⟩,⟨324607,999999999999999999⟩]
private def b13680 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨134,254⟩,⟨5,63⟩,⟨324607,649214⟩]
private def b13681 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨134,254⟩,⟨5,63⟩,⟨649215,999999999999999999⟩]
private def b13682 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨134,254⟩,⟨5,59⟩,⟨649215,1298430⟩]
private def b13683 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨134,254⟩,⟨5,59⟩,⟨1298431,999999999999999999⟩]
private def b13684 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨134,254⟩,⟨5,56⟩,⟨1298431,2596862⟩]
private def b13685 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨134,254⟩,⟨5,56⟩,⟨2596863,999999999999999999⟩]
private def b13686 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨134,254⟩,⟨5,54⟩,⟨2596863,5193726⟩]
private def b13687 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨134,254⟩,⟨5,54⟩,⟨5193727,999999999999999999⟩]
private def b13688 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨134,254⟩,⟨5,51⟩,⟨5193727,10387454⟩]
private def b13689 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨134,254⟩,⟨5,51⟩,⟨10387455,999999999999999999⟩]
private def b13690 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨134,254⟩,⟨5,49⟩,⟨10387455,20774910⟩]
private def b13691 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨134,254⟩,⟨5,49⟩,⟨20774911,999999999999999999⟩]
private def b13692 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨134,254⟩,⟨5,47⟩,⟨20774911,41549822⟩]
private def b13693 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨134,254⟩,⟨5,47⟩,⟨41549823,999999999999999999⟩]
private def b13694 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨134,254⟩,⟨5,45⟩,⟨41549823,83099646⟩]
private def b13695 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨134,254⟩,⟨5,45⟩,⟨83099647,999999999999999999⟩]
private def b13696 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨134,254⟩,⟨5,43⟩,⟨83099647,166199294⟩]
private def b13697 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨134,254⟩,⟨5,43⟩,⟨166199295,999999999999999999⟩]
private def b13698 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨134,254⟩,⟨5,42⟩,⟨166199295,332398590⟩]
private def b13699 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨134,254⟩,⟨5,42⟩,⟨332398591,999999999999999999⟩]
private def b13700 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨134,254⟩,⟨5,40⟩,⟨332398591,664797182⟩]
private def b13701 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨134,254⟩,⟨5,40⟩,⟨664797183,999999999999999999⟩]
private def b13702 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨134,254⟩,⟨5,9⟩,⟨664797183,999999999999999999⟩]
private def b13703 : Box := ![⟨18,18⟩,⟨63,67⟩,⟨134,217⟩,⟨5,9⟩,⟨664797183,999999999999999999⟩]
private def b13704 : Box := ![⟨18,18⟩,⟨68,72⟩,⟨134,217⟩,⟨5,9⟩,⟨664797183,999999999999999999⟩]
private def b13705 : Box := ![⟨18,18⟩,⟨68,72⟩,⟨134,217⟩,⟨5,9⟩,⟨664797183,1329594366⟩]
private def b13706 : Box := ![⟨18,18⟩,⟨68,72⟩,⟨134,217⟩,⟨5,9⟩,⟨1329594367,999999999999999999⟩]
private def b13707 : Box := ![⟨18,18⟩,⟨68,72⟩,⟨134,217⟩,⟨5,9⟩,⟨1329594367,2659188731⟩]
private def b13708 : Box := ![⟨18,18⟩,⟨68,72⟩,⟨134,217⟩,⟨5,9⟩,⟨2659188732,999999999999999999⟩]
private def b13709 : Box := ![⟨18,18⟩,⟨68,72⟩,⟨134,217⟩,⟨5,9⟩,⟨2659188732,5318377450⟩]
private def b13710 : Box := ![⟨18,18⟩,⟨68,72⟩,⟨134,217⟩,⟨5,9⟩,⟨5318377451,999999999999999999⟩]
private def b13711 : Box := ![⟨18,18⟩,⟨68,72⟩,⟨134,217⟩,⟨5,9⟩,⟨5318377451,10636754846⟩]
private def b13712 : Box := ![⟨18,18⟩,⟨68,72⟩,⟨134,217⟩,⟨5,9⟩,⟨10636754847,999999999999999999⟩]
private def b13713 : Box := ![⟨18,18⟩,⟨68,72⟩,⟨134,217⟩,⟨5,9⟩,⟨10636754847,21273509468⟩]
private def b13714 : Box := ![⟨18,18⟩,⟨68,72⟩,⟨134,217⟩,⟨5,9⟩,⟨21273509469,999999999999999999⟩]
private def b13715 : Box := ![⟨18,18⟩,⟨68,72⟩,⟨134,217⟩,⟨5,9⟩,⟨21273509469,42547018033⟩]
private def b13716 : Box := ![⟨18,18⟩,⟨68,72⟩,⟨134,217⟩,⟨5,9⟩,⟨42547018034,999999999999999999⟩]
private def b13717 : Box := ![⟨18,18⟩,⟨68,72⟩,⟨134,217⟩,⟨5,9⟩,⟨42547018034,85094032448⟩]
private def b13718 : Box := ![⟨18,18⟩,⟨68,72⟩,⟨134,217⟩,⟨5,9⟩,⟨85094032449,999999999999999999⟩]
private def b13733 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨134,254⟩,⟨10,39⟩,⟨664797183,999999999999999999⟩]
private def b13734 : Box := ![⟨18,18⟩,⟨63,72⟩,⟨255,1920000000000000011376⟩,⟨3,587809260539046306207⟩,⟨2535,999999999999999999⟩]
private def b13735 : Box := ![⟨18,18⟩,⟨63,67⟩,⟨255,1920000000000000011376⟩,⟨11,587809260539046306207⟩,⟨4556,999999999999999999⟩]
private def b13736 : Box := ![⟨18,18⟩,⟨63,67⟩,⟨255,1920000000000000011376⟩,⟨11,546983922829581996836⟩,⟨4556,9112⟩]
private def b13737 : Box := ![⟨18,18⟩,⟨63,67⟩,⟨255,1920000000000000011376⟩,⟨11,546983922829581996836⟩,⟨9113,999999999999999999⟩]
private def b13738 : Box := ![⟨18,18⟩,⟨63,67⟩,⟨255,1920000000000000011376⟩,⟨11,505383244206773621557⟩,⟨9113,18226⟩]
private def b13739 : Box := ![⟨18,18⟩,⟨63,67⟩,⟨255,1920000000000000011376⟩,⟨11,505383244206773621557⟩,⟨18227,999999999999999999⟩]
private def b13740 : Box := ![⟨18,18⟩,⟨63,67⟩,⟨255,1920000000000000011376⟩,⟨11,469663169519602432402⟩,⟨18227,36454⟩]
private def b13741 : Box := ![⟨18,18⟩,⟨63,67⟩,⟨255,1920000000000000011376⟩,⟨11,469663169519602432402⟩,⟨36455,999999999999999999⟩]
private def b13742 : Box := ![⟨18,18⟩,⟨63,67⟩,⟨255,1920000000000000011376⟩,⟨11,438659102630221766416⟩,⟨36455,72910⟩]
private def b13743 : Box := ![⟨18,18⟩,⟨63,67⟩,⟨255,1920000000000000011376⟩,⟨11,438659102630221766416⟩,⟨72911,999999999999999999⟩]
private def b13744 : Box := ![⟨18,18⟩,⟨63,67⟩,⟨255,1920000000000000011376⟩,⟨11,411494920174165459642⟩,⟨72911,145822⟩]
private def b13745 : Box := ![⟨18,18⟩,⟨63,67⟩,⟨255,1920000000000000011376⟩,⟨11,411494920174165459642⟩,⟨145823,999999999999999999⟩]
private def b13746 : Box := ![⟨18,18⟩,⟨63,67⟩,⟨255,510⟩,⟨11,387498861047835993203⟩,⟨145823,999999999999999999⟩]
private def b13761 : Box := ![⟨18,18⟩,⟨63,67⟩,⟨511,1920000000000000011376⟩,⟨11,387498861047835993203⟩,⟨145823,999999999999999999⟩]
private def b13764 : Box := ![⟨18,18⟩,⟨68,72⟩,⟨255,1920000000000000011376⟩,⟨11,587809260539046306207⟩,⟨4556,999999999999999999⟩]
private def b13765 : Box := ![⟨18,18⟩,⟨73,84⟩,⟨127,1920000000000000011376⟩,⟨3,644852160727824113029⟩,⟨1267,999999999999999999⟩]
private def b13776 : Box := ![⟨19,19⟩,⟨63,84⟩,⟨127,1920000000000000011376⟩,⟨3,685382755842062856637⟩,⟨1267,999999999999999999⟩]
private def b13777 : Box := ![⟨18,19⟩,⟨85,126⟩,⟨63,1920000000000000011376⟩,⟨1,685382755842062856647⟩,⟨831,999999999999999999⟩]
private def b13778 : Box := ![⟨18,19⟩,⟨85,126⟩,⟨63,126⟩,⟨1,685382755842062856647⟩,⟨1346,999999999999999999⟩]
private def b13779 : Box := ![⟨18,18⟩,⟨85,126⟩,⟨63,126⟩,⟨1,80⟩,⟨1352,999999999999999999⟩]
private def b13780 : Box := ![⟨18,18⟩,⟨85,101⟩,⟨63,126⟩,⟨1,80⟩,⟨1352,999999999999999999⟩]
private def b13795 : Box := ![⟨18,18⟩,⟨102,126⟩,⟨63,126⟩,⟨1,80⟩,⟨1352,999999999999999999⟩]
private def b13796 : Box := ![⟨19,19⟩,⟨85,126⟩,⟨63,126⟩,⟨1,80⟩,⟨1352,999999999999999999⟩]
private def b13797 : Box := ![⟨18,19⟩,⟨85,126⟩,⟨127,1920000000000000011376⟩,⟨1,685382755842062856647⟩,⟨1346,999999999999999999⟩]
private def b13798 : Box := ![⟨18,19⟩,⟨127,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨1,1278274932614555263665⟩,⟨415,999999999999999999⟩]
private def b13799 : Box := ![⟨18,19⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨1,1278274932614555263665⟩,⟨510,999999999999999999⟩]
private def b13800 : Box := ![⟨18,18⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨1,497098175499565598122⟩,⟨510,999999999999999999⟩]
private def b13801 : Box := ![⟨18,18⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨1,497098175499565598122⟩,⟨510,1020⟩]
private def b13806 : Box := ![⟨18,18⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨1,497098175499565598122⟩,⟨1021,999999999999999999⟩]
private def b13807 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,62⟩,⟨1,447349491790461300577⟩,⟨1021,999999999999999999⟩]
private def b13808 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨1,91⟩,⟨1021,999999999999999999⟩]
private def b13809 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,83⟩,⟨1021,2042⟩]
private def b13810 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,83⟩,⟨2043,999999999999999999⟩]
private def b13811 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,76⟩,⟨2043,4086⟩]
private def b13812 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,76⟩,⟨4087,999999999999999999⟩]
private def b13813 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,69⟩,⟨4087,8174⟩]
private def b13814 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,69⟩,⟨8175,999999999999999999⟩]
private def b13815 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,64⟩,⟨8175,16350⟩]
private def b13816 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,64⟩,⟨16351,999999999999999999⟩]
private def b13817 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,59⟩,⟨16351,32702⟩]
private def b13818 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,59⟩,⟨32703,999999999999999999⟩]
private def b13819 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,55⟩,⟨32703,65406⟩]
private def b13820 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,55⟩,⟨65407,999999999999999999⟩]
private def b13821 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,52⟩,⟨65407,130814⟩]
private def b13822 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,52⟩,⟨130815,999999999999999999⟩]
private def b13823 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,49⟩,⟨130815,261630⟩]
private def b13824 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,49⟩,⟨261631,999999999999999999⟩]
private def b13825 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,46⟩,⟨261631,523262⟩]
private def b13826 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,46⟩,⟨523263,999999999999999999⟩]
private def b13827 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,44⟩,⟨523263,1046526⟩]
private def b13828 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,44⟩,⟨1046527,999999999999999999⟩]
private def b13829 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,41⟩,⟨1046527,2093054⟩]
private def b13830 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,41⟩,⟨2093055,999999999999999999⟩]
private def b13831 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,39⟩,⟨2093055,4186110⟩]
private def b13832 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,39⟩,⟨4186111,999999999999999999⟩]
private def b13833 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,38⟩,⟨4186111,8372222⟩]
private def b13834 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,38⟩,⟨8372223,999999999999999999⟩]
private def b13835 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,36⟩,⟨8372223,16744446⟩]
private def b13836 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,36⟩,⟨16744447,999999999999999999⟩]
private def b13837 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,34⟩,⟨16744447,33488894⟩]
private def b13838 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨31,41⟩,⟨2,34⟩,⟨33488895,999999999999999999⟩]
private def b13839 : Box := ![⟨18,18⟩,⟨127,169⟩,⟨31,41⟩,⟨2,33⟩,⟨33488895,999999999999999999⟩]
private def b13844 : Box := ![⟨18,18⟩,⟨170,254⟩,⟨31,41⟩,⟨2,33⟩,⟨33488895,999999999999999999⟩]
private def b13845 : Box := ![⟨18,18⟩,⟨170,254⟩,⟨31,35⟩,⟨4,33⟩,⟨33488895,999999999999999999⟩]
private def b13846 : Box := ![⟨18,18⟩,⟨170,254⟩,⟨31,35⟩,⟨4,32⟩,⟨33488895,66977790⟩]
private def b13847 : Box := ![⟨18,18⟩,⟨170,254⟩,⟨31,35⟩,⟨4,32⟩,⟨66977791,999999999999999999⟩]
private def b13848 : Box := ![⟨18,18⟩,⟨170,254⟩,⟨31,35⟩,⟨4,31⟩,⟨66977791,133955582⟩]
private def b13849 : Box := ![⟨18,18⟩,⟨170,254⟩,⟨31,35⟩,⟨4,31⟩,⟨133955583,999999999999999999⟩]
private def b13850 : Box := ![⟨18,18⟩,⟨170,254⟩,⟨31,35⟩,⟨4,30⟩,⟨133955583,267911166⟩]
private def b13851 : Box := ![⟨18,18⟩,⟨170,254⟩,⟨31,35⟩,⟨4,30⟩,⟨267911167,999999999999999999⟩]
private def b13852 : Box := ![⟨18,18⟩,⟨170,254⟩,⟨31,35⟩,⟨4,29⟩,⟨267911167,535822334⟩]
private def b13853 : Box := ![⟨18,18⟩,⟨170,254⟩,⟨31,35⟩,⟨4,29⟩,⟨535822335,999999999999999999⟩]
private def b13854 : Box := ![⟨18,18⟩,⟨170,254⟩,⟨31,35⟩,⟨4,28⟩,⟨535822335,1071644670⟩]
private def b13855 : Box := ![⟨18,18⟩,⟨170,254⟩,⟨31,35⟩,⟨4,28⟩,⟨1071644671,999999999999999999⟩]
private def b13856 : Box := ![⟨18,18⟩,⟨170,254⟩,⟨31,35⟩,⟨4,7⟩,⟨1071644671,999999999999999999⟩]
private def b13857 : Box := ![⟨18,18⟩,⟨170,251⟩,⟨31,35⟩,⟨4,7⟩,⟨1071644671,2143289340⟩]
private def b13858 : Box := ![⟨18,18⟩,⟨170,251⟩,⟨31,35⟩,⟨4,7⟩,⟨2143289341,999999999999999999⟩]
private def b13859 : Box := ![⟨18,18⟩,⟨170,251⟩,⟨31,35⟩,⟨4,7⟩,⟨2143289341,4286578673⟩]
private def b13860 : Box := ![⟨18,18⟩,⟨170,251⟩,⟨31,35⟩,⟨4,7⟩,⟨4286578674,999999999999999999⟩]
private def b13861 : Box := ![⟨18,18⟩,⟨170,251⟩,⟨31,35⟩,⟨4,7⟩,⟨4286578674,8573157312⟩]
private def b13862 : Box := ![⟨18,18⟩,⟨170,251⟩,⟨31,35⟩,⟨4,7⟩,⟨8573157313,999999999999999999⟩]
private def b13863 : Box := ![⟨18,18⟩,⟨170,251⟩,⟨31,35⟩,⟨4,7⟩,⟨8573157313,17146314480⟩]
private def b13864 : Box := ![⟨18,18⟩,⟨170,251⟩,⟨31,35⟩,⟨4,7⟩,⟨17146314481,999999999999999999⟩]
private def b13879 : Box := ![⟨18,18⟩,⟨170,254⟩,⟨31,35⟩,⟨8,27⟩,⟨1071644671,999999999999999999⟩]
private def b13880 : Box := ![⟨18,18⟩,⟨170,254⟩,⟨36,41⟩,⟨4,33⟩,⟨33488895,999999999999999999⟩]
private def b13885 : Box := ![⟨18,18⟩,⟨127,254⟩,⟨42,62⟩,⟨1,91⟩,⟨1021,999999999999999999⟩]
private def b13894 : Box := ![⟨18,18⟩,⟨255,1920000000000000011376⟩,⟨31,62⟩,⟨1,447349491790461300577⟩,⟨1021,999999999999999999⟩]
private def b13907 : Box := ![⟨19,19⟩,⟨127,1920000000000000011376⟩,⟨31,62⟩,⟨1,497098175499565598122⟩,⟨510,999999999999999999⟩]
private def b13908 : Box := ![⟨18,19⟩,⟨127,1920000000000000011376⟩,⟨63,1920000000000000011376⟩,⟨1,1278274932614555263665⟩,⟨510,999999999999999999⟩]
private def b13909 : Box := ![⟨20,22⟩,⟨63,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨1,1278274932614555263666⟩,⟨415,999999999999999999⟩]
theorem deny5_11 : Deny 5 11 ![⟨18,22⟩,⟨63,1920000000000000011376⟩,⟨31,1920000000000000011376⟩,⟨1,1445853658536585374451⟩,⟨207,999999999999999999⟩] := by
  have e13374 : Deny 5 11 b13374 := by
    apply closeAction rule_sound _ _ 64 [0x16dc4]
    decide +kernel
  have e13377 : Deny 5 11 b13377 := by
    apply closeAction rule_sound _ _ 64 [0x16]
    decide +kernel
  have e13378 : Deny 5 11 b13378 := by
    apply closeAction rule_sound _ _ 64 [0x16e3709e7960f80c824a10ae162878c9]
    decide +kernel
  have e13376 : Deny 5 11 b13376 :=
    branchAction rule_sound _ _ 2
      0x2a3 b13376 b13377 b13378 (by decide +kernel) e13377 e13378
  have e13393 : Deny 5 11 b13393 := by
    apply closeAction rule_sound _ _ 64 [0x5b7]
    decide +kernel
  have e13375 : Deny 5 11 b13375 :=
    branchAction rule_sound _ _ 2
      0x223 b13375 b13376 b13393 (by decide +kernel) e13376 e13393
  have e13373 : Deny 5 11 b13373 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13373 b13374 b13375 (by decide +kernel) e13374 e13375
  have e13394 : Deny 5 11 b13394 := by
    apply closeAction rule_sound _ _ 64 [0x16e37]
    decide +kernel
  have e13372 : Deny 5 11 b13372 :=
    branchAction rule_sound _ _ 2
      0x263 b13372 b13373 b13394 (by decide +kernel) e13373 e13394
  have e13395 : Deny 5 11 b13395 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e13371 : Deny 5 11 b13371 :=
    branchAction rule_sound _ _ 1
      0x8 b13371 b13372 b13395 (by decide +kernel) e13372 e13395
  have e13396 : Deny 5 11 b13396 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e13370 : Deny 5 11 b13370 :=
    branchAction rule_sound _ _ 2
      0x1e3 b13370 b13371 b13396 (by decide +kernel) e13371 e13396
  have e13402 : Deny 5 11 b13402 := by
    apply closeAction rule_sound _ _ 64 [0x16]
    decide +kernel
  have e13406 : Deny 5 11 b13406 := by
    apply closeAction rule_sound _ _ 64 [0x3e1ee378c97b8df68c88c30e32430f8de32632232f8]
    decide +kernel
  have e13419 : Deny 5 11 b13419 := by
    apply closeAction rule_sound _ _ 64 [0x83109e378c3e370e3263238]
    decide +kernel
  have e13405 : Deny 5 11 b13405 :=
    branchAction rule_sound _ _ 2
      0x1e3 b13405 b13406 b13419 (by decide +kernel) e13406 e13419
  have e13426 : Deny 5 11 b13426 := by
    apply closeAction rule_sound _ _ 64 [0x279e58a296287]
    decide +kernel
  have e13404 : Deny 5 11 b13404 :=
    branchAction rule_sound _ _ 2
      0x263 b13404 b13405 b13426 (by decide +kernel) e13405 e13426
  have e13437 : Deny 5 11 b13437 := by
    apply closeAction rule_sound _ _ 64 [0x16e377ab8c9e2b0c38c88c88c2ad6e370eb8c98c82e3]
    decide +kernel
  have e13450 : Deny 5 11 b13450 := by
    apply closeAction rule_sound _ _ 64 [0x82083209e08e37]
    decide +kernel
  have e13436 : Deny 5 11 b13436 :=
    branchAction rule_sound _ _ 1
      0x9 b13436 b13437 b13450 (by decide +kernel) e13437 e13450
  have e13457 : Deny 5 11 b13457 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e13435 : Deny 5 11 b13435 :=
    branchAction rule_sound _ _ 1
      0x7 b13435 b13436 b13457 (by decide +kernel) e13436 e13457
  have e13403 : Deny 5 11 b13403 :=
    branchAction rule_sound _ _ 1
      0x8 b13403 b13404 b13435 (by decide +kernel) e13404 e13435
  have e13401 : Deny 5 11 b13401 :=
    branchAction rule_sound _ _ 2
      0x2a3 b13401 b13402 b13403 (by decide +kernel) e13402 e13403
  have e13461 : Deny 5 11 b13461 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e13462 : Deny 5 11 b13462 := by
    apply closeAction rule_sound _ _ 64 [0xc3e23243e37da32230f80e32430f88c98c858a8cb]
    decide +kernel
  have e13460 : Deny 5 11 b13460 :=
    branchAction rule_sound _ _ 2
      0x1e3 b13460 b13461 b13462 (by decide +kernel) e13461 e13462
  have e13478 : Deny 5 11 b13478 := by
    apply closeAction rule_sound _ _ 64 [0x1e79e79628a8cb2d62b88d62b8]
    decide +kernel
  have e13492 : Deny 5 11 b13492 := by
    apply closeAction rule_sound _ _ 64 [0x96e370e3263223]
    decide +kernel
  have e13497 : Deny 5 11 b13497 := by
    apply closeAction rule_sound _ _ 64 [0x20f8dc3e232388c9e03e038c80e3263223]
    decide +kernel
  have e13491 : Deny 5 11 b13491 :=
    branchAction rule_sound _ _ 1
      0xb b13491 b13492 b13497 (by decide +kernel) e13492 e13497
  have e13477 : Deny 5 11 b13477 :=
    branchAction rule_sound _ _ 1
      0x7 b13477 b13478 b13491 (by decide +kernel) e13478 e13491
  have e13459 : Deny 5 11 b13459 :=
    branchAction rule_sound _ _ 2
      0x263 b13459 b13460 b13477 (by decide +kernel) e13460 e13477
  have e13510 : Deny 5 11 b13510 := by
    apply closeAction rule_sound _ _ 64 [0x1e5b8da12b88de7b8aea0c884aac30f8df68c8e368c82f88d62b8]
    decide +kernel
  have e13525 : Deny 5 11 b13525 := by
    apply closeAction rule_sound _ _ 64 [0x2083e23238ae32780c38c88c88c2083e2b8c9e232232f8]
    decide +kernel
  have e13509 : Deny 5 11 b13509 :=
    branchAction rule_sound _ _ 2
      0x1e3 b13509 b13510 b13525 (by decide +kernel) e13510 e13525
  have e13542 : Deny 5 11 b13542 := by
    apply closeAction rule_sound _ _ 64 [0x7b87b87b80e32232632162962a3]
    decide +kernel
  have e13554 : Deny 5 11 b13554 := by
    apply closeAction rule_sound _ _ 64 [0xf80f88c90f88c858a0f88dee37da3238de3263]
    decide +kernel
  have e13565 : Deny 5 11 b13565 := by
    apply closeAction rule_sound _ _ 64 [0x20f88c9e230f80f88c9e232388d62b80f80f88c90f88c88c9]
    decide +kernel
  have e13553 : Deny 5 11 b13553 :=
    branchAction rule_sound _ _ 2
      0x223 b13553 b13554 b13565 (by decide +kernel) e13554 e13565
  have e13541 : Deny 5 11 b13541 :=
    branchAction rule_sound _ _ 1
      0xb b13541 b13542 b13553 (by decide +kernel) e13542 e13553
  have e13580 : Deny 5 11 b13580 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e13540 : Deny 5 11 b13540 :=
    branchAction rule_sound _ _ 1
      0x7 b13540 b13541 b13580 (by decide +kernel) e13541 e13580
  have e13508 : Deny 5 11 b13508 :=
    branchAction rule_sound _ _ 1
      0x9 b13508 b13509 b13540 (by decide +kernel) e13509 e13540
  have e13458 : Deny 5 11 b13458 :=
    branchAction rule_sound _ _ 2
      0x223 b13458 b13459 b13508 (by decide +kernel) e13459 e13508
  have e13400 : Deny 5 11 b13400 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13400 b13401 b13458 (by decide +kernel) e13401 e13458
  have e13584 : Deny 5 11 b13584 := by
    apply closeAction rule_sound _ _ 64 [0x96e370af5b8dc3e37bc38c98c88c958a8c88d6dcb1e3]
    decide +kernel
  have e13599 : Deny 5 11 b13599 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e13583 : Deny 5 11 b13583 :=
    branchAction rule_sound _ _ 2
      0x263 b13583 b13584 b13599 (by decide +kernel) e13584 e13599
  have e13600 : Deny 5 11 b13600 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e13582 : Deny 5 11 b13582 :=
    branchAction rule_sound _ _ 2
      0x223 b13582 b13583 b13600 (by decide +kernel) e13583 e13600
  have e13606 : Deny 5 11 b13606 := by
    apply closeAction rule_sound _ _ 64 [0x16]
    decide +kernel
  have e13607 : Deny 5 11 b13607 := by
    apply closeAction rule_sound _ _ 64 [0x1e7b8ddebde79e58a2a310b8c98c88cb58a]
    decide +kernel
  have e13605 : Deny 5 11 b13605 :=
    branchAction rule_sound _ _ 2
      0x2a3 b13605 b13606 b13607 (by decide +kernel) e13606 e13607
  have e13623 : Deny 5 11 b13623 := by
    apply closeAction rule_sound _ _ 64 [0x1ebe37962b8be3278da3]
    decide +kernel
  have e13629 : Deny 5 11 b13629 := by
    apply closeAction rule_sound _ _ 64 [0x1e58ae2358ae23]
    decide +kernel
  have e13635 : Deny 5 11 b13635 := by
    apply closeAction rule_sound _ _ 64 [0x7962b8be3]
    decide +kernel
  have e13638 : Deny 5 11 b13638 := by
    apply closeAction rule_sound _ _ 64 [0x83e03223243e0322f0f8be30f8be32388c9be3223]
    decide +kernel
  have e13634 : Deny 5 11 b13634 :=
    branchAction rule_sound _ _ 1
      0xb b13634 b13635 b13638 (by decide +kernel) e13635 e13638
  have e13628 : Deny 5 11 b13628 :=
    branchAction rule_sound _ _ 1
      0x9 b13628 b13629 b13634 (by decide +kernel) e13629 e13634
  have e13622 : Deny 5 11 b13622 :=
    branchAction rule_sound _ _ 2
      0x223 b13622 b13623 b13628 (by decide +kernel) e13623 e13628
  have e13604 : Deny 5 11 b13604 :=
    branchAction rule_sound _ _ 1
      0xb b13604 b13605 b13622 (by decide +kernel) e13605 e13622
  have e13651 : Deny 5 11 b13651 := by
    apply closeAction rule_sound _ _ 64 [0x82083e232788c9e23238]
    decide +kernel
  have e13603 : Deny 5 11 b13603 :=
    branchAction rule_sound _ _ 2
      0x1e3 b13603 b13604 b13651 (by decide +kernel) e13604 e13651
  have e13661 : Deny 5 11 b13661 := by
    apply closeAction rule_sound _ _ 64 [0x9e278be3]
    decide +kernel
  have e13666 : Deny 5 11 b13666 := by
    apply closeAction rule_sound _ _ 64 [0x1ebe3]
    decide +kernel
  have e13668 : Deny 5 11 b13668 := by
    apply closeAction rule_sound _ _ 64 [0x1ebe3]
    decide +kernel
  have e13670 : Deny 5 11 b13670 := by
    apply closeAction rule_sound _ _ 64 [0x1ebe3]
    decide +kernel
  have e13672 : Deny 5 11 b13672 := by
    apply closeAction rule_sound _ _ 64 [0x1ebe3]
    decide +kernel
  have e13674 : Deny 5 11 b13674 := by
    apply closeAction rule_sound _ _ 64 [0x1ebe3]
    decide +kernel
  have e13676 : Deny 5 11 b13676 := by
    apply closeAction rule_sound _ _ 64 [0x1ebe3]
    decide +kernel
  have e13678 : Deny 5 11 b13678 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e13680 : Deny 5 11 b13680 := by
    apply closeAction rule_sound _ _ 64 [0x1e]
    decide +kernel
  have e13682 : Deny 5 11 b13682 := by
    apply closeAction rule_sound _ _ 64 [0x1e]
    decide +kernel
  have e13684 : Deny 5 11 b13684 := by
    apply closeAction rule_sound _ _ 64 [0x1e]
    decide +kernel
  have e13686 : Deny 5 11 b13686 := by
    apply closeAction rule_sound _ _ 64 [0x1e]
    decide +kernel
  have e13688 : Deny 5 11 b13688 := by
    apply closeAction rule_sound _ _ 64 [0x1e]
    decide +kernel
  have e13690 : Deny 5 11 b13690 := by
    apply closeAction rule_sound _ _ 64 [0x1e]
    decide +kernel
  have e13692 : Deny 5 11 b13692 := by
    apply closeAction rule_sound _ _ 64 [0x1e]
    decide +kernel
  have e13694 : Deny 5 11 b13694 := by
    apply closeAction rule_sound _ _ 64 [0x1e]
    decide +kernel
  have e13696 : Deny 5 11 b13696 := by
    apply closeAction rule_sound _ _ 64 [0x1e]
    decide +kernel
  have e13698 : Deny 5 11 b13698 := by
    apply closeAction rule_sound _ _ 64 [0x1e]
    decide +kernel
  have e13700 : Deny 5 11 b13700 := by
    apply closeAction rule_sound _ _ 64 [0x1e]
    decide +kernel
  have e13703 : Deny 5 11 b13703 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e13705 : Deny 5 11 b13705 := by
    apply closeAction rule_sound _ _ 64 [0x1e]
    decide +kernel
  have e13707 : Deny 5 11 b13707 := by
    apply closeAction rule_sound _ _ 64 [0x1e]
    decide +kernel
  have e13709 : Deny 5 11 b13709 := by
    apply closeAction rule_sound _ _ 64 [0x1e]
    decide +kernel
  have e13711 : Deny 5 11 b13711 := by
    apply closeAction rule_sound _ _ 64 [0x1e]
    decide +kernel
  have e13713 : Deny 5 11 b13713 := by
    apply closeAction rule_sound _ _ 64 [0x1e]
    decide +kernel
  have e13715 : Deny 5 11 b13715 := by
    apply closeAction rule_sound _ _ 64 [0x1e]
    decide +kernel
  have e13717 : Deny 5 11 b13717 := by
    apply closeAction rule_sound _ _ 64 [0x1e]
    decide +kernel
  have e13718 : Deny 5 11 b13718 := by
    apply closeAction rule_sound _ _ 64 [0x72f0c220978b78b78b78b78b]
    decide +kernel
  have e13716 : Deny 5 11 b13716 :=
    branchAction rule_sound _ _ 1
      0xb b13716 b13717 b13718 (by decide +kernel) e13717 e13718
  have e13714 : Deny 5 11 b13714 :=
    branchAction rule_sound _ _ 1
      0xb b13714 b13715 b13716 (by decide +kernel) e13715 e13716
  have e13712 : Deny 5 11 b13712 :=
    branchAction rule_sound _ _ 1
      0xb b13712 b13713 b13714 (by decide +kernel) e13713 e13714
  have e13710 : Deny 5 11 b13710 :=
    branchAction rule_sound _ _ 1
      0xb b13710 b13711 b13712 (by decide +kernel) e13711 e13712
  have e13708 : Deny 5 11 b13708 :=
    branchAction rule_sound _ _ 1
      0xb b13708 b13709 b13710 (by decide +kernel) e13709 e13710
  have e13706 : Deny 5 11 b13706 :=
    branchAction rule_sound _ _ 1
      0xb b13706 b13707 b13708 (by decide +kernel) e13707 e13708
  have e13704 : Deny 5 11 b13704 :=
    branchAction rule_sound _ _ 1
      0xb b13704 b13705 b13706 (by decide +kernel) e13705 e13706
  have e13702 : Deny 5 11 b13702 :=
    branchAction rule_sound _ _ 2
      0x222 b13702 b13703 b13704 (by decide +kernel) e13703 e13704
  have e13733 : Deny 5 11 b13733 := by
    apply closeAction rule_sound _ _ 64 [0x1c]
    decide +kernel
  have e13701 : Deny 5 11 b13701 :=
    branchAction rule_sound _ _ 2
      0x2a3 b13701 b13702 b13733 (by decide +kernel) e13702 e13733
  have e13699 : Deny 5 11 b13699 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13699 b13700 b13701 (by decide +kernel) e13700 e13701
  have e13697 : Deny 5 11 b13697 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13697 b13698 b13699 (by decide +kernel) e13698 e13699
  have e13695 : Deny 5 11 b13695 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13695 b13696 b13697 (by decide +kernel) e13696 e13697
  have e13693 : Deny 5 11 b13693 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13693 b13694 b13695 (by decide +kernel) e13694 e13695
  have e13691 : Deny 5 11 b13691 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13691 b13692 b13693 (by decide +kernel) e13692 e13693
  have e13689 : Deny 5 11 b13689 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13689 b13690 b13691 (by decide +kernel) e13690 e13691
  have e13687 : Deny 5 11 b13687 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13687 b13688 b13689 (by decide +kernel) e13688 e13689
  have e13685 : Deny 5 11 b13685 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13685 b13686 b13687 (by decide +kernel) e13686 e13687
  have e13683 : Deny 5 11 b13683 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13683 b13684 b13685 (by decide +kernel) e13684 e13685
  have e13681 : Deny 5 11 b13681 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13681 b13682 b13683 (by decide +kernel) e13682 e13683
  have e13679 : Deny 5 11 b13679 :=
    branchAction rule_sound _ _ 4
      0x2f6be3 b13679 b13680 b13681 (by decide +kernel) e13680 e13681
  have e13677 : Deny 5 11 b13677 :=
    branchAction rule_sound _ _ 3
      0xbda3 b13677 b13678 b13679 (by decide +kernel) e13678 e13679
  have e13675 : Deny 5 11 b13675 :=
    branchAction rule_sound _ _ 3
      0xbda3 b13675 b13676 b13677 (by decide +kernel) e13676 e13677
  have e13673 : Deny 5 11 b13673 :=
    branchAction rule_sound _ _ 3
      0xbda3 b13673 b13674 b13675 (by decide +kernel) e13674 e13675
  have e13671 : Deny 5 11 b13671 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13671 b13672 b13673 (by decide +kernel) e13672 e13673
  have e13669 : Deny 5 11 b13669 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13669 b13670 b13671 (by decide +kernel) e13670 e13671
  have e13667 : Deny 5 11 b13667 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13667 b13668 b13669 (by decide +kernel) e13668 e13669
  have e13665 : Deny 5 11 b13665 :=
    branchAction rule_sound _ _ 3
      0xbbe3 b13665 b13666 b13667 (by decide +kernel) e13666 e13667
  have e13736 : Deny 5 11 b13736 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e13738 : Deny 5 11 b13738 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e13740 : Deny 5 11 b13740 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e13742 : Deny 5 11 b13742 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e13744 : Deny 5 11 b13744 := by
    apply closeAction rule_sound _ _ 64 [0x1cbe3]
    decide +kernel
  have e13746 : Deny 5 11 b13746 := by
    apply closeAction rule_sound _ _ 64 [0x72f72f0c222326378b8de2e378b0888c9be3]
    decide +kernel
  have e13761 : Deny 5 11 b13761 := by
    apply closeAction rule_sound _ _ 64 [0x272f8c9e2f]
    decide +kernel
  have e13745 : Deny 5 11 b13745 :=
    branchAction rule_sound _ _ 2
      0x263 b13745 b13746 b13761 (by decide +kernel) e13746 e13761
  have e13743 : Deny 5 11 b13743 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13743 b13744 b13745 (by decide +kernel) e13744 e13745
  have e13741 : Deny 5 11 b13741 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13741 b13742 b13743 (by decide +kernel) e13742 e13743
  have e13739 : Deny 5 11 b13739 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13739 b13740 b13741 (by decide +kernel) e13740 e13741
  have e13737 : Deny 5 11 b13737 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13737 b13738 b13739 (by decide +kernel) e13738 e13739
  have e13735 : Deny 5 11 b13735 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13735 b13736 b13737 (by decide +kernel) e13736 e13737
  have e13764 : Deny 5 11 b13764 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e13734 : Deny 5 11 b13734 :=
    branchAction rule_sound _ _ 3
      0x8e2f b13734 b13735 b13764 (by decide +kernel) e13735 e13764
  have e13664 : Deny 5 11 b13664 :=
    branchAction rule_sound _ _ 2
      0x263 b13664 b13665 b13734 (by decide +kernel) e13665 e13734
  have e13660 : Deny 5 11 b13660 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13660 b13661 b13664 (by decide +kernel) e13661 e13664
  have e13765 : Deny 5 11 b13765 := by
    apply closeAction rule_sound _ _ 64 [0x82082083e232782388c9e23238be3278]
    decide +kernel
  have e13659 : Deny 5 11 b13659 :=
    branchAction rule_sound _ _ 2
      0x223 b13659 b13660 b13765 (by decide +kernel) e13660 e13765
  have e13776 : Deny 5 11 b13776 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e13658 : Deny 5 11 b13658 :=
    branchAction rule_sound _ _ 3
      0x7e2f b13658 b13659 b13776 (by decide +kernel) e13659 e13776
  have e13602 : Deny 5 11 b13602 :=
    branchAction rule_sound _ _ 2
      0x263 b13602 b13603 b13658 (by decide +kernel) e13603 e13658
  have e13780 : Deny 5 11 b13780 := by
    apply closeAction rule_sound _ _ 64 [0x820f88c9e03e038c98c88de58a8cbe162b88c9e23]
    decide +kernel
  have e13795 : Deny 5 11 b13795 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e13779 : Deny 5 11 b13779 :=
    branchAction rule_sound _ _ 1
      0x8 b13779 b13780 b13795 (by decide +kernel) e13780 e13795
  have e13796 : Deny 5 11 b13796 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e13778 : Deny 5 11 b13778 :=
    branchAction rule_sound _ _ 3
      0x7e23 b13778 b13779 b13796 (by decide +kernel) e13779 e13796
  have e13797 : Deny 5 11 b13797 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e13777 : Deny 5 11 b13777 :=
    branchAction rule_sound _ _ 2
      0x278 b13777 b13778 b13797 (by decide +kernel) e13778 e13797
  have e13601 : Deny 5 11 b13601 :=
    branchAction rule_sound _ _ 2
      0x223 b13601 b13602 b13777 (by decide +kernel) e13602 e13777
  have e13581 : Deny 5 11 b13581 :=
    branchAction rule_sound _ _ 1
      0xb b13581 b13582 b13601 (by decide +kernel) e13582 e13601
  have e13399 : Deny 5 11 b13399 :=
    branchAction rule_sound _ _ 2
      0x263 b13399 b13400 b13581 (by decide +kernel) e13400 e13581
  have e13801 : Deny 5 11 b13801 := by
    apply closeAction rule_sound _ _ 64 [0x209eae3278ae3223]
    decide +kernel
  have e13809 : Deny 5 11 b13809 := by
    apply closeAction rule_sound _ _ 64 [0x1eae3]
    decide +kernel
  have e13811 : Deny 5 11 b13811 := by
    apply closeAction rule_sound _ _ 64 [0x1eae3]
    decide +kernel
  have e13813 : Deny 5 11 b13813 := by
    apply closeAction rule_sound _ _ 64 [0x1eae3]
    decide +kernel
  have e13815 : Deny 5 11 b13815 := by
    apply closeAction rule_sound _ _ 64 [0x1eae3]
    decide +kernel
  have e13817 : Deny 5 11 b13817 := by
    apply closeAction rule_sound _ _ 64 [0x1eae3]
    decide +kernel
  have e13819 : Deny 5 11 b13819 := by
    apply closeAction rule_sound _ _ 64 [0x1eae3]
    decide +kernel
  have e13821 : Deny 5 11 b13821 := by
    apply closeAction rule_sound _ _ 64 [0x1eae3]
    decide +kernel
  have e13823 : Deny 5 11 b13823 := by
    apply closeAction rule_sound _ _ 64 [0x1eae3]
    decide +kernel
  have e13825 : Deny 5 11 b13825 := by
    apply closeAction rule_sound _ _ 64 [0x1eae3]
    decide +kernel
  have e13827 : Deny 5 11 b13827 := by
    apply closeAction rule_sound _ _ 64 [0x1eae3]
    decide +kernel
  have e13829 : Deny 5 11 b13829 := by
    apply closeAction rule_sound _ _ 64 [0x1eae3]
    decide +kernel
  have e13831 : Deny 5 11 b13831 := by
    apply closeAction rule_sound _ _ 64 [0x1eae3]
    decide +kernel
  have e13833 : Deny 5 11 b13833 := by
    apply closeAction rule_sound _ _ 64 [0x1eae3]
    decide +kernel
  have e13835 : Deny 5 11 b13835 := by
    apply closeAction rule_sound _ _ 64 [0x1eae3]
    decide +kernel
  have e13837 : Deny 5 11 b13837 := by
    apply closeAction rule_sound _ _ 64 [0x1eae3]
    decide +kernel
  have e13839 : Deny 5 11 b13839 := by
    apply closeAction rule_sound _ _ 64 [0xeb0e3202ac9da3]
    decide +kernel
  have e13846 : Deny 5 11 b13846 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13848 : Deny 5 11 b13848 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13850 : Deny 5 11 b13850 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13852 : Deny 5 11 b13852 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13854 : Deny 5 11 b13854 := by
    apply closeAction rule_sound _ _ 64 [0x1aae3]
    decide +kernel
  have e13857 : Deny 5 11 b13857 := by
    apply closeAction rule_sound _ _ 64 [0x12]
    decide +kernel
  have e13859 : Deny 5 11 b13859 := by
    apply closeAction rule_sound _ _ 64 [0x12]
    decide +kernel
  have e13861 : Deny 5 11 b13861 := by
    apply closeAction rule_sound _ _ 64 [0xabaa1]
    decide +kernel
  have e13863 : Deny 5 11 b13863 := by
    apply closeAction rule_sound _ _ 64 [0xabaa1]
    decide +kernel
  have e13864 : Deny 5 11 b13864 := by
    apply closeAction rule_sound _ _ 64 [0x6ab0c22486ab84b0ab84b0ab84b0ab84b0ab84b]
    decide +kernel
  have e13862 : Deny 5 11 b13862 :=
    branchAction rule_sound _ _ 1
      0xb b13862 b13863 b13864 (by decide +kernel) e13863 e13864
  have e13860 : Deny 5 11 b13860 :=
    branchAction rule_sound _ _ 1
      0xb b13860 b13861 b13862 (by decide +kernel) e13861 e13862
  have e13858 : Deny 5 11 b13858 :=
    branchAction rule_sound _ _ 1
      0xb b13858 b13859 b13860 (by decide +kernel) e13859 e13860
  have e13856 : Deny 5 11 b13856 :=
    branchAction rule_sound _ _ 2
      0x2e1 b13856 b13857 b13858 (by decide +kernel) e13857 e13858
  have e13879 : Deny 5 11 b13879 := by
    apply closeAction rule_sound _ _ 64 [0x1a]
    decide +kernel
  have e13855 : Deny 5 11 b13855 :=
    branchAction rule_sound _ _ 2
      0x2a3 b13855 b13856 b13879 (by decide +kernel) e13856 e13879
  have e13853 : Deny 5 11 b13853 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13853 b13854 b13855 (by decide +kernel) e13854 e13855
  have e13851 : Deny 5 11 b13851 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13851 b13852 b13853 (by decide +kernel) e13852 e13853
  have e13849 : Deny 5 11 b13849 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13849 b13850 b13851 (by decide +kernel) e13850 e13851
  have e13847 : Deny 5 11 b13847 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13847 b13848 b13849 (by decide +kernel) e13848 e13849
  have e13845 : Deny 5 11 b13845 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13845 b13846 b13847 (by decide +kernel) e13846 e13847
  have e13880 : Deny 5 11 b13880 := by
    apply closeAction rule_sound _ _ 64 [0x20838c88c8]
    decide +kernel
  have e13844 : Deny 5 11 b13844 :=
    branchAction rule_sound _ _ 2
      0x26b b13844 b13845 b13880 (by decide +kernel) e13845 e13880
  have e13838 : Deny 5 11 b13838 :=
    branchAction rule_sound _ _ 2
      0x223 b13838 b13839 b13844 (by decide +kernel) e13839 e13844
  have e13836 : Deny 5 11 b13836 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13836 b13837 b13838 (by decide +kernel) e13837 e13838
  have e13834 : Deny 5 11 b13834 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13834 b13835 b13836 (by decide +kernel) e13835 e13836
  have e13832 : Deny 5 11 b13832 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13832 b13833 b13834 (by decide +kernel) e13833 e13834
  have e13830 : Deny 5 11 b13830 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13830 b13831 b13832 (by decide +kernel) e13831 e13832
  have e13828 : Deny 5 11 b13828 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13828 b13829 b13830 (by decide +kernel) e13829 e13830
  have e13826 : Deny 5 11 b13826 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13826 b13827 b13828 (by decide +kernel) e13827 e13828
  have e13824 : Deny 5 11 b13824 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13824 b13825 b13826 (by decide +kernel) e13825 e13826
  have e13822 : Deny 5 11 b13822 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13822 b13823 b13824 (by decide +kernel) e13823 e13824
  have e13820 : Deny 5 11 b13820 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13820 b13821 b13822 (by decide +kernel) e13821 e13822
  have e13818 : Deny 5 11 b13818 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13818 b13819 b13820 (by decide +kernel) e13819 e13820
  have e13816 : Deny 5 11 b13816 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13816 b13817 b13818 (by decide +kernel) e13817 e13818
  have e13814 : Deny 5 11 b13814 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13814 b13815 b13816 (by decide +kernel) e13815 e13816
  have e13812 : Deny 5 11 b13812 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13812 b13813 b13814 (by decide +kernel) e13813 e13814
  have e13810 : Deny 5 11 b13810 :=
    branchAction rule_sound _ _ 2
      0x2e3 b13810 b13811 b13812 (by decide +kernel) e13811 e13812
  have e13808 : Deny 5 11 b13808 :=
    branchAction rule_sound _ _ 3
      0xbae3 b13808 b13809 b13810 (by decide +kernel) e13809 e13810
  have e13885 : Deny 5 11 b13885 := by
    apply closeAction rule_sound _ _ 64 [0x2082083e232788c8e2b8c9e23238]
    decide +kernel
  have e13807 : Deny 5 11 b13807 :=
    branchAction rule_sound _ _ 2
      0x263 b13807 b13808 b13885 (by decide +kernel) e13808 e13885
  have e13894 : Deny 5 11 b13894 := by
    apply closeAction rule_sound _ _ 64 [0x820820820f88c8e232788c8e2b8c9e2b8c8e2b8c9e2b]
    decide +kernel
  have e13806 : Deny 5 11 b13806 :=
    branchAction rule_sound _ _ 2
      0x223 b13806 b13807 b13894 (by decide +kernel) e13807 e13894
  have e13800 : Deny 5 11 b13800 :=
    branchAction rule_sound _ _ 1
      0xb b13800 b13801 b13806 (by decide +kernel) e13801 e13806
  have e13907 : Deny 5 11 b13907 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e13799 : Deny 5 11 b13799 :=
    branchAction rule_sound _ _ 2
      0x1e3 b13799 b13800 b13907 (by decide +kernel) e13800 e13907
  have e13908 : Deny 5 11 b13908 := by
    apply closeAction rule_sound _ _ 64 [0x2]
    decide +kernel
  have e13798 : Deny 5 11 b13798 :=
    branchAction rule_sound _ _ 2
      0x278 b13798 b13799 b13908 (by decide +kernel) e13799 e13908
  have e13398 : Deny 5 11 b13398 :=
    branchAction rule_sound _ _ 2
      0x223 b13398 b13399 b13798 (by decide +kernel) e13399 e13798
  have e13909 : Deny 5 11 b13909 := by
    apply closeAction rule_sound _ _ 64 [0x82082082083e232788c8e232788c8e07e23263238]
    decide +kernel
  have e13397 : Deny 5 11 b13397 :=
    branchAction rule_sound _ _ 2
      0x1e3 b13397 b13398 b13909 (by decide +kernel) e13398 e13909
  have e13369 : Deny 5 11 b13369 :=
    branchAction rule_sound _ _ 1
      0xb b13369 b13370 b13397 (by decide +kernel) e13370 e13397
  exact e13369
end OMA.Blocks5_11_245212.S13369
