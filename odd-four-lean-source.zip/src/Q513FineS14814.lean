import FastReplay245212
import SparseDigit245212
import FastRound245212


/-! Independent bounded subtree replays for a four-prime exclusion. -/
namespace OMA.Blocks5_13_245212.S14814
open OMA.Box245212 OMA.FastReplay245212 OMA.FastDigit245212 OMA.SparseEngine245212
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def rule := OMA.FastRound245212.withSingles (OMA.FastRound245212.withRounds OMA.SparseDigit245212.act)
private theorem rule_sound : AdvanceSound rule := OMA.FastRound245212.withSingles_sound (OMA.FastRound245212.withRounds_sound OMA.SparseDigit245212.act_sound)
private def b14814 : Box := ![⟨47,94⟩,⟨10,14⟩,⟨9,18⟩,⟨3,1210212765957446815727⟩,⟨59,109⟩]
theorem deny5_13 : Deny 5 13 ![⟨47,94⟩,⟨10,14⟩,⟨9,18⟩,⟨3,1210212765957446815727⟩,⟨59,109⟩] := by
  have e14814 : Deny 5 13 b14814 := by
    apply closeAction rule_sound _ _ 64 [0x2c3da78040f8df6107e20283e37d88de32430f8de3243e378c90f8df68c8df68c72c30f78c9088dc4087e37db48c8e23,0x9a02831021f8df61c22040e00e02b70e02430f72470c21f7da02042ca0d9e378c90f8df68c78c40c38c90c3de32631c4,0x2021f7da3103dc38c70c38c78c90c38c98c70f6087de32231020831c9dc3dc38c98c70c38c98c810b0c31c38090f8df6,0xc3e378c70c2238de31c3102238de3242]
    decide +kernel
  exact e14814
end OMA.Blocks5_13_245212.S14814
