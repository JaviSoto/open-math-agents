# Odd A245212 solutions with at most four prime factors

The main theorem is in `src/OddFourComplete245212.lean`. Only the original OEIS
definition and Mathlib are imported from outside this source archive. No compiled
proofs are bundled. The ten four-prime families and three three-prime supports
cover all primes and positive exponents in the statement.

From the Formal Conjectures checkout at `9097e2f90e66d2f6244209cb1c07f7120d17ec53`,
with its dependencies available, run:

    lake build FormalConjectures.OEIS.245212
    lake env python3 /path/to/extracted/verify.py

Use `--jobs 1` on a machine with limited memory. The first run checks several
hundred modules; individual families can take many minutes. Rerunning resumes
from the already checked modules. The last output audits the theorem's axioms.
