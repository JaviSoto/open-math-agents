import DivisorFloorLadder245212

/-! Finiteness on the original input at every rational divisor-growth rate
below the exponent-dependent floor, without assuming a bound on rank. -/
namespace OMA.DivisorLadderHeight245212
open Nat Finset ArithmeticFunction OMA.FixedRankInteger245212 OMA.DivisorFloorLadder245212
open scoped ArithmeticFunction.sigma
open private OMA.SparseDivisorHeight245212.bern from SparseDivisorHeight245212

theorem rank_bound {n A B C s : ℕ} (ap : 0<A)
    (floor : B^(support n).card≤(σ 0 (ordCompl[2] n))^s)
    {b : ℕ} (low : A^s<B*b^s)
    (small : σ 0 (ordCompl[2] n)*b^(support n).card≤C*A^(support n).card) :
    (support n).card≤A^s*C^s := by
  let r:=(support n).card
  let D:=σ 0 (ordCompl[2] n)
  change B^r≤D^s at floor
  change D*b^r≤C*A^r at small
  have high : (B*b^s)^r≤C^s*(A^s)^r:=calc
    _ = B^r*(b^r)^s := by rw [mul_pow,←pow_mul,←pow_mul,Nat.mul_comm s r]
    _ ≤ (D*b^r)^s := by rw [mul_pow];exact Nat.mul_le_mul_right _ floor
    _ ≤ (C*A^r)^s := Nat.pow_le_pow_left small s
    _ = _ := by rw [mul_pow,←pow_mul,←pow_mul,Nat.mul_comm r s]
  have bern:=OMA.SparseDivisorHeight245212.bern (A^s) r
  have mid:=Nat.pow_le_pow_left (Nat.succ_le_of_lt low) r
  have cancel : (A^s)^r*(A^s+r)≤(A^s)^r*(A^s*C^s):=by
    exact bern.trans ((Nat.mul_le_mul_left _ (mid.trans high)).trans_eq (by ring))
  have bound:=Nat.le_of_mul_le_mul_left cancel (pow_pos (pow_pos ap s) r)
  change r≤_
  omega

theorem whole {n s a b C : ℕ} (pos : 0<n) (non : (support n).Nonempty)
    (hit : OeisA245212.a n=(σ 1 n:ℤ)) (sp : 2 ≤ s) (excluded : misses n s)
    (ap : 0<a) (low : a^s<base s*b^s)
    (small : σ 0 (ordCompl[2] n)*b^(support n).card≤C*a^(support n).card) :
    n≤OMA.SparseDivisorHeight245212.height (a^s*C^s) :=
  (OMA.FixedRankAbsolute245212.absolute pos non hit).trans
    (single_le_sum (f:=OMA.FixedRankAbsolute245212.bound) (fun _ _=>Nat.zero_le _)
      (mem_range.mpr (Nat.lt_succ_of_le (rank_bound ap (OMA.DivisorFloorLadder245212.original pos hit sp excluded) low small))))

theorem all_levels {n a b C : ℕ} (pos : 0<n) (non : (support n).Nonempty)
    (hit : OeisA245212.a n=(σ 1 n:ℤ))
    (excluded : ∀p∈support n,∀j,2≤j → n.factorization p+2≠2^j)
    (ap : 0<a) (low : a<4*b)
    (small : σ 0 (ordCompl[2] n)*b^(support n).card≤C*a^(support n).card) :
    n≤OMA.SparseDivisorHeight245212.height (a*C) := by
  have bound:=rank_bound (n:=n) (s:=1) (B:=4) ap
    (by simpa using no_pure_shift pos hit excluded) (by simpa using low) small
  simp only [pow_one] at bound
  exact (OMA.FixedRankAbsolute245212.absolute pos non hit).trans
    (single_le_sum (f:=OMA.FixedRankAbsolute245212.bound) (fun _ _=>Nat.zero_le _)
      (mem_range.mpr (Nat.lt_succ_of_le bound)))

#print axioms whole
#print axioms all_levels
end OMA.DivisorLadderHeight245212
