import SparseDivisorHeight245212

/-! A hierarchy of rank-independent lower bounds for the divisor count of
the odd part. Omitting exponents 2, 6, 14, ... successively raises the base. -/
namespace OMA.DivisorFloorLadder245212
open Nat Finset ArithmeticFunction OMA.FixedRankInteger245212 OMA.OddDivisorFloor245212
open scoped ArithmeticFunction.sigma

def misses (n s : ℕ) := ∀p∈support n,∀j,2≤j → j<s → n.factorization p+2≠2^j
def base (s : ℕ) := 2^(s-1)*(2^s-1)

private theorem ordinary {e v : ℕ} (ep : 0<e) (hv : (e+2).factorization 2=v)
    (no : 2≤v → e+2≠2^v) : 2*2^v≤e+1 := by
  by_cases zero : v=0
  · rw [zero,pow_zero,mul_one];omega
  let m:=ordCompl[2] (e+2)
  have odd : Odd m:=Nat.coprime_two_left.mp (Nat.coprime_ordCompl prime_two (by omega : e+2≠0))
  have repr : 2^v*m=e+2:=by
    rw [←hv];exact Nat.ordProj_mul_ordCompl_eq_self (e+2) 2
  have m3 : 3 ≤ m:=by
    obtain ⟨j,hj⟩:=odd
    by_contra! small
    have one : m=1:=by omega
    rw [one,mul_one] at repr
    by_cases two : 2≤v
    · exact no two repr.symm
    · have onev : v=1:=by omega
      rw [onev] at repr;omega
  have low:=Nat.mul_le_mul_left (2^v) m3
  have pw:=Nat.two_pow_pos v
  omega

private theorem local_bound {s e : ℕ} (ep : 0<e)
    (excluded : ∀j,2≤j → j < s → e+2≠2^j) :
    let v:=(e+2).factorization 2
    2^s*(2^s-1)^v≤2^v*(e+1)^s := by
  dsimp only
  generalize hv : (e+2).factorization 2=v
  have pos:=Nat.two_pow_pos s
  by_cases hi : s≤v
  · obtain ⟨w,rfl⟩:=Nat.exists_eq_add_of_le hi
    have mass:=Nat.le_of_dvd (by omega : 0<e+2)
      ((prime_two.pow_dvd_iff_le_factorization (by omega : e+2≠0)).mpr hv.ge)
    rw [pow_add] at mass
    have zp:=Nat.two_pow_pos w
    have near : (2^s-1)*2^w≤e+1:=by
      have red:=congrArg (·*2^w) (Nat.sub_add_cancel (show 1≤2^s by omega))
      nlinarith only [mass,red,zp]
    have high:=Nat.pow_le_pow_left near s
    rw [mul_pow,←pow_mul,Nat.mul_comm w s,pow_mul] at high
    have grow:=Nat.pow_le_pow_left (Nat.sub_le (2^s) 1) w
    rw [pow_add,pow_add]
    calc
      _ ≤ 2^s*((2^s-1)^s*(2^s)^w) := by gcongr
      _ ≤ (2^s*2^w)*(e+1)^s := Nat.mul_le_mul (by nlinarith only [Nat.mul_le_mul_left (2^s) zp]) high
  · have len:=ordinary ep hv (fun lo=>excluded v lo (by omega))
    have raised:=Nat.pow_le_pow_left len s
    rw [mul_pow,←pow_mul,Nat.mul_comm v s,pow_mul] at raised
    have cap:=Nat.pow_le_pow_left (Nat.sub_le (2^s) 1) v
    exact (Nat.mul_le_mul_left _ cap).trans (raised.trans
      (Nat.le_mul_of_pos_left _ (Nat.two_pow_pos v)))

theorem original {n s : ℕ} (pos : 0<n) (hit : OeisA245212.a n=(σ 1 n:ℤ))
    (sp : 2 ≤ s) (excluded : misses n s) :
    (base s)^(support n).card≤(σ 0 (ordCompl[2] n))^s := by
  let r:=(support n).card
  let V:=∑p∈support n,(n.factorization p+2).factorization 2
  have B:=budget pos hit
  change r≤V at B
  have prod : (2^s)^r*(2^s-1)^V≤2^V*(lengthProd n)^s := by
    simpa only [r,V,lengthProd,prod_mul_distrib,prod_const,prod_pow_eq_pow_sum,prod_pow] using
      (prod_le_prod' (s:=support n) fun p mem=>local_bound
        (Nat.pos_of_ne_zero (Finsupp.mem_support_iff.mp (mem_erase.mp mem).2)) (excluded p mem))
  have sb : 2^s=2*2^(s-1):=by
    conv_lhs=>rw [show s=(s-1)+1 by omega,pow_succ,mul_comm]
  have large : 2≤2^s-1:=by
    have :=Nat.pow_le_pow_right (by decide : 0<2) sp
    omega
  have comparison : 2^V*(base s)^r≤(2^s)^r*(2^s-1)^V:=by
    obtain ⟨w,hw⟩:=Nat.exists_eq_add_of_le B
    rw [hw,pow_add,pow_add,base,mul_pow]
    calc
      _ = (2*2^(s-1))^r*(2^s-1)^r*2^w := by rw [mul_pow];ring
      _ ≤ (2^s)^r*((2^s-1)^r*(2^s-1)^w) := by rw [←sb,mul_assoc];gcongr
  rw [OMA.SparseDivisorHeight245212.odd_count pos]
  exact Nat.le_of_mul_le_mul_left (comparison.trans prod) (Nat.two_pow_pos V)

theorem no_pure_shift {n : ℕ} (pos : 0<n) (hit : OeisA245212.a n=(σ 1 n:ℤ))
    (excluded : ∀p∈support n,∀j,2≤j → n.factorization p+2≠2^j) :
    4^(support n).card≤σ 0 (ordCompl[2] n) := by
  have B:=budget pos hit
  have prod : 2^(support n).card*2^(∑p∈support n,(n.factorization p+2).factorization 2)≤lengthProd n := by
    simpa only [lengthProd,prod_mul_distrib,prod_const,prod_pow_eq_pow_sum] using
      (prod_le_prod' (s:=support n) fun p mem=>ordinary
        (Nat.pos_of_ne_zero (Finsupp.mem_support_iff.mp (mem_erase.mp mem).2)) rfl (excluded p mem _))
  rw [OMA.SparseDivisorHeight245212.odd_count pos,show 4=2*2 by decide,mul_pow]
  exact (Nat.mul_le_mul_left _ (Nat.pow_le_pow_right (by decide : 0<2) B)).trans prod

#print axioms original
#print axioms no_pure_shift
end OMA.DivisorFloorLadder245212
