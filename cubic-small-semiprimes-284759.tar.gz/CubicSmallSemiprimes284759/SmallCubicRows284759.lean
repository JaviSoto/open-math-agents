import BernoulliList284759
import PrattRows284759

namespace OMA.SmallCubicRows284759
open OMA.BernoulliList284759 OMA.PrattRows284759
set_option maxRecDepth 65536
set_option maxHeartbeats 0
private def data:List ℤ:=[117288381359406970983270,-58644190679703485491635,19548063559901161830545,0,-3909612711980232366109,0,2792580508557308832935,0,-3909612711980232366109,0,8885483436318709922975,0,-29687278944816929285509,0,136836444919308132813815,0,-831827598778382380483309,0,6447480482572814030229455,0,-62060125931961850334423509,0,726264105946166152143673895,0,-10154857745376400364660802109,0,167196601078381306956319931135,0,-3201765335919225172319660547109,0,70558446956583857937898967065175,0,-1772968208439921418506649377818509,0,50388806092943619857172626414420015,0,-1608217844763097977263566777424008309,0,57275707257898363866531649321536619655,0,-2263264556789521123807814394864273740509,0,98720815151383560847395902019358601568095,0,-4731187154922086023514472442331162912871109,0,248073707230031824271815688716185260902449335,0,-14176208608958377565787153081487291535638488109,0,879764519439969048939855863579482941685333727375,0,-59099012755194024999880431893589136769594730911509,0,4284401066943885675566805652970005387196639671146215,0,-334257452221961966008565390215914584966870907637693309,0,27991373618881717075294980054448641465401013587915729855,0,-2509965409553402879582773192133475171882497240453229617509,0,240452625889524333991296968009976560258893352643316661782295,0,-24557848222355115368429335144982705526693616830854229608700109]
private theorem checked:∀j:Fin 65, row data j=if (j:ℕ)=0 then (117288381359406970983270:ℤ) else 0:=by decide +kernel
theorem prime113161 : Nat.Prime 113161 := by
  apply lucas_primality 113161 (7:ZMod 113161)
  · exact eq_one [false,false,false,true,false,false,false,false,false,true,false,true,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(7:ZMod 113161)^((113161-1)/2)≠1:=
    ne_one [false,false,true,false,false,false,false,false,true,false,true,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(7:ZMod 113161)^((113161-1)/3)≠1:=
    ne_one [false,false,false,true,true,false,true,false,true,true,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(7:ZMod 113161)^((113161-1)/5)≠1:=
    ne_one [false,false,false,true,false,true,true,false,false,false,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w23:(7:ZMod 113161)^((113161-1)/23)≠1:=
    ne_one [false,false,false,true,true,true,false,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w41:(7:ZMod 113161)^((113161-1)/41)≠1:=
    ne_one [false,false,false,true,false,false,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (113161-1)=2*(2*(2*(3*(5*(23*(41)))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=23:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w23
  have eqn:q=41:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w41
theorem prime163979 : Nat.Prime 163979 := by
  apply lucas_primality 163979 (2:ZMod 163979)
  · exact eq_one [false,true,false,true,false,false,false,true,false,false,false,false,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 163979)^((163979-1)/2)≠1:=
    ne_one [true,false,true,false,false,false,true,false,false,false,false,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w163:(2:ZMod 163979)^((163979-1)/163)≠1:=
    ne_one [false,true,true,true,false,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w503:(2:ZMod 163979)^((163979-1)/503)≠1:=
    ne_one [false,true,true,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (163979-1)=2*(163*(503)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=163:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w163
  have eqn:q=503:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w503
theorem prime1619 : Nat.Prime 1619 := by
  apply lucas_primality 1619 (2:ZMod 1619)
  · exact eq_one [false,true,false,false,true,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 1619)^((1619-1)/2)≠1:=
    ne_one [true,false,false,true,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w809:(2:ZMod 1619)^((1619-1)/809)≠1:=
    ne_one [false,true] (by decide +kernel) (by decide +kernel)
  rw [show (1619-1)=2*(809) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  have eqn:q=809:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w809
theorem prime223423 : Nat.Prime 223423 := by
  apply lucas_primality 223423 (5:ZMod 223423)
  · exact eq_one [false,true,true,true,true,true,false,true,false,false,false,true,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 223423)^((223423-1)/2)≠1:=
    ne_one [true,true,true,true,true,false,true,false,false,false,true,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(5:ZMod 223423)^((223423-1)/3)≠1:=
    ne_one [false,true,false,true,false,true,true,true,false,true,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w23:(5:ZMod 223423)^((223423-1)/23)≠1:=
    ne_one [false,true,false,false,true,true,true,true,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w1619:(5:ZMod 223423)^((223423-1)/1619)≠1:=
    ne_one [false,true,false,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (223423-1)=2*(3*(23*(1619))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=23:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w23
  have eqn:q=1619:=(Nat.prime_dvd_prime_iff_eq hp prime1619).mp hd; rw [eqn]; exact w1619
theorem prime1226592271 : Nat.Prime 1226592271 := by
  apply lucas_primality 1226592271 (7:ZMod 1226592271)
  · exact eq_one [false,true,true,true,false,false,false,false,false,false,false,false,true,false,true,false,false,false,true,true,true,false,false,false,true,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(7:ZMod 1226592271)^((1226592271-1)/2)≠1:=
    ne_one [true,true,true,false,false,false,false,false,false,false,false,true,false,true,false,false,false,true,true,true,false,false,false,true,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(7:ZMod 1226592271)^((1226592271-1)/3)≠1:=
    ne_one [false,true,false,true,true,false,true,false,true,false,true,false,false,false,true,true,false,true,true,true,true,false,true,false,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w5:(7:ZMod 1226592271)^((1226592271-1)/5)≠1:=
    ne_one [false,true,true,false,true,true,false,false,true,true,false,false,false,false,true,false,true,true,true,true,true,false,false,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w61:(7:ZMod 1226592271)^((1226592271-1)/61)≠1:=
    ne_one [false,true,true,false,false,true,false,false,true,true,false,false,true,false,true,true,false,true,false,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w223423:(7:ZMod 1226592271)^((1226592271-1)/223423)≠1:=
    ne_one [false,true,false,false,true,true,true,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (1226592271-1)=2*(3*(3*(5*(61*(223423))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=61:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w61
  have eqn:q=223423:=(Nat.prime_dvd_prime_iff_eq hp prime223423).mp hd; rw [eqn]; exact w223423
theorem prime66463 : Nat.Prime 66463 := by
  apply lucas_primality 66463 (10:ZMod 66463)
  · exact eq_one [false,true,true,true,true,false,false,true,true,true,false,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(10:ZMod 66463)^((66463-1)/2)≠1:=
    ne_one [true,true,true,true,false,false,true,true,true,false,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(10:ZMod 66463)^((66463-1)/3)≠1:=
    ne_one [false,true,false,true,false,false,false,true,false,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w11:(10:ZMod 66463)^((66463-1)/11)≠1:=
    ne_one [false,true,false,true,true,false,false,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w19:(10:ZMod 66463)^((66463-1)/19)≠1:=
    ne_one [false,true,false,true,false,true,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w53:(10:ZMod 66463)^((66463-1)/53)≠1:=
    ne_one [false,true,true,false,false,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (66463-1)=2*(3*(11*(19*(53)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w11
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=19:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w19
  have eqn:q=53:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w53
theorem prime16216973 : Nat.Prime 16216973 := by
  apply lucas_primality 16216973 (2:ZMod 16216973)
  · exact eq_one [false,false,true,true,false,false,false,true,true,true,false,false,true,true,true,false,true,true,true,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 16216973)^((16216973-1)/2)≠1:=
    ne_one [false,true,true,false,false,false,true,true,true,false,false,true,true,true,false,true,true,true,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w61:(2:ZMod 16216973)^((16216973-1)/61)≠1:=
    ne_one [false,false,true,true,true,true,true,false,false,true,true,true,false,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w66463:(2:ZMod 16216973)^((16216973-1)/66463)≠1:=
    ne_one [false,false,true,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (16216973-1)=2*(2*(61*(66463))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=61:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w61
  have eqn:q=66463:=(Nat.prime_dvd_prime_iff_eq hp prime66463).mp hd; rw [eqn]; exact w66463
theorem prime151628697551 : Nat.Prime 151628697551 := by
  apply lucas_primality 151628697551 (7:ZMod 151628697551)
  · exact eq_one [false,true,true,true,false,false,true,true,true,true,true,true,false,false,true,false,false,true,true,false,false,false,true,true,true,false,true,true,false,false,true,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(7:ZMod 151628697551)^((151628697551-1)/2)≠1:=
    ne_one [true,true,true,false,false,true,true,true,true,true,true,false,false,true,false,false,true,true,false,false,false,true,true,true,false,true,true,false,false,true,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(7:ZMod 151628697551)^((151628697551-1)/5)≠1:=
    ne_one [false,true,true,false,true,true,true,true,true,true,true,true,false,false,false,false,false,true,true,true,false,false,false,true,true,true,true,true,false,false,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w11:(7:ZMod 151628697551)^((151628697551-1)/11)≠1:=
    ne_one [false,true,false,true,false,true,false,false,false,true,false,true,false,true,false,true,true,false,true,true,true,false,false,true,true,false,true,false,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w17:(7:ZMod 151628697551)^((151628697551-1)/17)≠1:=
    ne_one [false,true,true,true,false,true,true,true,false,false,false,false,false,false,true,false,false,true,false,false,false,true,false,true,true,true,false,false,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w16216973:(7:ZMod 151628697551)^((151628697551-1)/16216973)≠1:=
    ne_one [false,true,true,false,false,false,false,true,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (151628697551-1)=2*(5*(5*(11*(17*(16216973))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w11
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=17:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w17
  have eqn:q=16216973:=(Nat.prime_dvd_prime_iff_eq hp prime16216973).mp hd; rw [eqn]; exact w16216973
theorem prime1231 : Nat.Prime 1231 := by
  apply lucas_primality 1231 (3:ZMod 1231)
  · exact eq_one [false,true,true,true,false,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 1231)^((1231-1)/2)≠1:=
    ne_one [true,true,true,false,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 1231)^((1231-1)/3)≠1:=
    ne_one [false,true,false,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w5:(3:ZMod 1231)^((1231-1)/5)≠1:=
    ne_one [false,true,true,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w41:(3:ZMod 1231)^((1231-1)/41)≠1:=
    ne_one [false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (1231-1)=2*(3*(5*(41))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  have eqn:q=41:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w41
theorem prime11177 : Nat.Prime 11177 := by
  apply lucas_primality 11177 (3:ZMod 11177)
  · exact eq_one [false,false,false,true,false,true,false,true,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 11177)^((11177-1)/2)≠1:=
    ne_one [false,false,true,false,true,false,true,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w11:(3:ZMod 11177)^((11177-1)/11)≠1:=
    ne_one [false,false,false,true,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w127:(3:ZMod 11177)^((11177-1)/127)≠1:=
    ne_one [false,false,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (11177-1)=2*(2*(2*(11*(127)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w11
  have eqn:q=127:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w127
theorem prime26863 : Nat.Prime 26863 := by
  apply lucas_primality 26863 (5:ZMod 26863)
  · exact eq_one [false,true,true,true,false,true,true,true,false,false,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 26863)^((26863-1)/2)≠1:=
    ne_one [true,true,true,false,true,true,true,false,false,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(5:ZMod 26863)^((26863-1)/3)≠1:=
    ne_one [false,true,false,true,true,true,true,true,false,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w11:(5:ZMod 26863)^((26863-1)/11)≠1:=
    ne_one [false,true,false,true,false,false,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w37:(5:ZMod 26863)^((26863-1)/37)≠1:=
    ne_one [false,true,true,false,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (26863-1)=2*(3*(11*(11*(37)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w11
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w11
  have eqn:q=37:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w37
theorem prime2957 : Nat.Prime 2957 := by
  apply lucas_primality 2957 (2:ZMod 2957)
  · exact eq_one [false,false,true,true,false,false,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 2957)^((2957-1)/2)≠1:=
    ne_one [false,true,true,false,false,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w739:(2:ZMod 2957)^((2957-1)/739)≠1:=
    ne_one [false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (2957-1)=2*(2*(739)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  have eqn:q=739:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w739
theorem prime195623293 : Nat.Prime 195623293 := by
  apply lucas_primality 195623293 (2:ZMod 195623293)
  · exact eq_one [false,false,true,true,true,true,true,false,true,false,false,true,true,true,true,true,false,false,false,true,false,true,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 195623293)^((195623293-1)/2)≠1:=
    ne_one [false,true,true,true,true,true,false,true,false,false,true,true,true,true,true,false,false,false,true,false,true,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(2:ZMod 195623293)^((195623293-1)/3)≠1:=
    ne_one [false,false,true,false,true,false,true,true,true,false,true,true,true,true,true,true,false,true,false,false,false,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w37:(2:ZMod 195623293)^((195623293-1)/37)≠1:=
    ne_one [false,false,true,true,false,false,true,true,false,false,true,true,false,true,false,true,false,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w149:(2:ZMod 195623293)^((195623293-1)/149)≠1:=
    ne_one [false,false,true,true,false,false,false,true,false,false,false,true,false,false,false,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w2957:(2:ZMod 195623293)^((195623293-1)/2957)≠1:=
    ne_one [false,false,true,true,false,true,true,false,false,true,false,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (195623293-1)=2*(2*(3*(37*(149*(2957))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=37:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w37
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=149:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w149
  have eqn:q=2957:=(Nat.prime_dvd_prime_iff_eq hp prime2957).mp hd; rw [eqn]; exact w2957
theorem prime19088082706840550550313 : Nat.Prime 19088082706840550550313 := by
  apply lucas_primality 19088082706840550550313 (10:ZMod 19088082706840550550313)
  · exact eq_one [false,false,false,true,false,true,false,false,true,true,false,true,false,true,false,true,false,true,false,false,false,false,true,true,true,true,false,true,true,true,true,true,true,true,true,true,true,false,true,true,false,false,false,true,false,false,false,true,false,false,true,true,true,false,true,false,false,false,true,false,false,false,true,true,false,true,false,true,false,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(10:ZMod 19088082706840550550313)^((19088082706840550550313-1)/2)≠1:=
    ne_one [false,false,true,false,true,false,false,true,true,false,true,false,true,false,true,false,true,false,false,false,false,true,true,true,true,false,true,true,true,true,true,true,true,true,true,true,false,true,true,false,false,false,true,false,false,false,true,false,false,true,true,true,false,true,false,false,false,true,false,false,false,true,true,false,true,false,true,false,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(10:ZMod 19088082706840550550313)^((19088082706840550550313-1)/3)≠1:=
    ne_one [false,false,false,true,true,true,false,true,true,true,false,false,false,true,true,true,false,false,false,false,false,false,true,false,true,false,false,true,false,true,false,true,false,true,false,true,false,false,true,false,false,false,false,true,true,false,true,true,false,true,true,true,true,false,false,false,false,false,true,true,false,true,true,true,false,false,false,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w11:(10:ZMod 19088082706840550550313)^((19088082706840550550313-1)/11)≠1:=
    ne_one [false,false,false,true,true,true,true,false,false,true,false,false,true,true,false,true,true,false,false,false,true,false,false,false,true,false,false,false,true,false,true,true,true,false,true,false,false,true,true,true,true,false,true,true,true,false,true,true,true,false,false,true,true,false,true,true,true,false,false,false,true,false,false,false,false,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w1231:(10:ZMod 19088082706840550550313)^((19088082706840550550313-1)/1231)≠1:=
    ne_one [false,false,false,true,true,false,true,false,false,false,true,true,true,true,false,true,true,true,true,false,true,true,true,false,false,false,true,false,false,false,false,true,true,false,true,true,false,true,false,false,false,true,false,false,true,true,true,true,false,false,false,false,true,true,false,false,true,true,true,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w11177:(10:ZMod 19088082706840550550313)^((19088082706840550550313-1)/11177)≠1:=
    ne_one [false,false,false,true,false,true,true,true,false,true,false,true,false,false,false,true,false,true,false,false,false,false,true,true,false,true,true,true,true,false,false,false,true,false,false,true,true,true,false,false,true,true,false,false,true,false,true,false,true,true,false,false,true,true,false,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w26863:(10:ZMod 19088082706840550550313)^((19088082706840550550313-1)/26863)≠1:=
    ne_one [false,false,false,true,true,false,true,false,true,true,true,false,true,true,true,true,false,false,false,false,false,true,false,true,true,true,true,true,false,false,false,false,false,false,false,true,false,false,false,false,true,false,true,false,true,true,true,false,false,false,true,true,true,false,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w195623293:(10:ZMod 19088082706840550550313)^((19088082706840550550313-1)/195623293)≠1:=
    ne_one [false,false,false,true,false,false,true,false,false,false,false,false,false,false,false,true,false,true,true,false,true,false,true,true,true,false,true,true,true,false,false,true,false,true,true,true,true,true,false,true,false,false,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (19088082706840550550313-1)=2*(2*(2*(3*(11*(1231*(11177*(26863*(195623293)))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w11
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=1231:=(Nat.prime_dvd_prime_iff_eq hp prime1231).mp leaf; rw [eqn]; exact w1231
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11177:=(Nat.prime_dvd_prime_iff_eq hp prime11177).mp leaf; rw [eqn]; exact w11177
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=26863:=(Nat.prime_dvd_prime_iff_eq hp prime26863).mp leaf; rw [eqn]; exact w26863
  have eqn:q=195623293:=(Nat.prime_dvd_prime_iff_eq hp prime195623293).mp hd; rw [eqn]; exact w195623293
theorem prime1723 : Nat.Prime 1723 := by
  apply lucas_primality 1723 (3:ZMod 1723)
  · exact eq_one [false,true,false,true,true,true,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 1723)^((1723-1)/2)≠1:=
    ne_one [true,false,true,true,true,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 1723)^((1723-1)/3)≠1:=
    ne_one [false,true,true,true,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w7:(3:ZMod 1723)^((1723-1)/7)≠1:=
    ne_one [false,true,true,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w41:(3:ZMod 1723)^((1723-1)/41)≠1:=
    ne_one [false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (1723-1)=2*(3*(7*(41))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  have eqn:q=41:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w41
theorem prime3373 : Nat.Prime 3373 := by
  apply lucas_primality 3373 (5:ZMod 3373)
  · exact eq_one [false,false,true,true,false,true,false,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 3373)^((3373-1)/2)≠1:=
    ne_one [false,true,true,false,true,false,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(5:ZMod 3373)^((3373-1)/3)≠1:=
    ne_one [false,false,true,false,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w281:(5:ZMod 3373)^((3373-1)/281)≠1:=
    ne_one [false,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (3373-1)=2*(2*(3*(281))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=281:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w281
theorem prime276587 : Nat.Prime 276587 := by
  apply lucas_primality 276587 (2:ZMod 276587)
  · exact eq_one [false,true,false,true,false,true,true,false,false,false,false,true,true,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 276587)^((276587-1)/2)≠1:=
    ne_one [true,false,true,false,true,true,false,false,false,false,true,true,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w41:(2:ZMod 276587)^((276587-1)/41)≠1:=
    ne_one [false,true,false,true,true,false,true,false,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3373:(2:ZMod 276587)^((276587-1)/3373)≠1:=
    ne_one [false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (276587-1)=2*(41*(3373)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=41:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w41
  have eqn:q=3373:=(Nat.prime_dvd_prime_iff_eq hp prime3373).mp hd; rw [eqn]; exact w3373
theorem prime179781551 : Nat.Prime 179781551 := by
  apply lucas_primality 179781551 (11:ZMod 179781551)
  · exact eq_one [false,true,true,true,false,true,false,true,true,true,true,true,true,true,false,false,true,true,true,false,true,true,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(11:ZMod 179781551)^((179781551-1)/2)≠1:=
    ne_one [true,true,true,false,true,false,true,true,true,true,true,true,true,false,false,true,true,true,false,true,true,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(11:ZMod 179781551)^((179781551-1)/5)≠1:=
    ne_one [false,true,true,false,true,false,true,false,false,true,true,false,false,true,false,true,false,false,true,false,false,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w13:(11:ZMod 179781551)^((179781551-1)/13)≠1:=
    ne_one [false,true,true,false,false,true,true,true,false,false,true,false,false,false,false,false,true,true,false,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w276587:(11:ZMod 179781551)^((179781551-1)/276587)≠1:=
    ne_one [false,true,false,true,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (179781551-1)=2*(5*(5*(13*(276587)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=13:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w13
  have eqn:q=276587:=(Nat.prime_dvd_prime_iff_eq hp prime276587).mp hd; rw [eqn]; exact w276587
theorem prime9867871345074121 : Nat.Prime 9867871345074121 := by
  apply lucas_primality 9867871345074121 (26:ZMod 9867871345074121)
  · exact eq_one [false,false,false,true,false,false,true,true,true,true,true,true,true,false,true,false,false,true,true,false,true,true,false,false,false,true,true,false,true,false,true,true,false,true,true,false,false,false,true,true,false,true,true,true,false,false,false,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(26:ZMod 9867871345074121)^((9867871345074121-1)/2)≠1:=
    ne_one [false,false,true,false,false,true,true,true,true,true,true,true,false,true,false,false,true,true,false,true,true,false,false,false,true,true,false,true,false,true,true,false,true,true,false,false,false,true,true,false,true,true,true,false,false,false,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(26:ZMod 9867871345074121)^((9867871345074121-1)/3)≠1:=
    ne_one [false,false,false,true,true,false,false,true,false,true,false,true,false,false,true,true,false,false,true,true,true,true,false,true,false,false,true,true,true,false,false,true,true,true,true,false,true,false,false,true,true,true,true,true,false,true,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(26:ZMod 9867871345074121)^((9867871345074121-1)/5)≠1:=
    ne_one [false,false,false,true,false,true,false,false,true,true,false,false,true,false,false,false,false,true,true,true,true,true,false,false,true,false,false,false,true,false,false,true,false,false,true,false,true,true,true,true,false,true,false,false,false,false,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w7:(26:ZMod 9867871345074121)^((9867871345074121-1)/7)≠1:=
    ne_one [false,false,false,true,true,true,true,true,true,true,true,true,true,false,false,true,false,true,true,true,true,true,false,true,true,true,true,false,false,true,true,false,false,false,true,true,true,false,false,false,false,true,false,false,false,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w23:(26:ZMod 9867871345074121)^((9867871345074121-1)/23)≠1:=
    ne_one [false,false,false,true,true,true,true,false,true,true,false,false,true,true,true,false,false,false,true,false,true,true,false,true,false,true,false,true,false,true,false,false,true,false,true,false,true,true,false,false,false,true,true,false,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w947:(26:ZMod 9867871345074121)^((9867871345074121-1)/947)≠1:=
    ne_one [false,false,false,true,true,false,false,false,true,false,true,true,true,false,true,false,false,true,false,true,false,true,false,true,false,false,false,false,false,true,false,false,false,true,false,true,true,true,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w179781551:(26:ZMod 9867871345074121)^((9867871345074121-1)/179781551)≠1:=
    ne_one [false,false,false,true,true,true,false,true,false,true,true,false,false,false,false,true,true,false,true,false,false,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (9867871345074121-1)=2*(2*(2*(3*(3*(5*(7*(23*(947*(179781551))))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=23:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w23
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=947:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w947
  have eqn:q=179781551:=(Nat.prime_dvd_prime_iff_eq hp prime179781551).mp hd; rw [eqn]; exact w179781551
theorem prime2526175064338974977 : Nat.Prime 2526175064338974977 := by
  apply lucas_primality 2526175064338974977 (3:ZMod 2526175064338974977)
  · exact eq_one [false,false,false,false,false,false,false,false,true,false,false,true,false,false,true,true,true,true,true,true,true,false,true,false,false,true,true,false,true,true,false,false,false,true,true,false,true,false,true,true,false,true,true,false,false,false,true,true,false,true,true,true,false,false,false,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 2526175064338974977)^((2526175064338974977-1)/2)≠1:=
    ne_one [false,false,false,false,false,false,false,true,false,false,true,false,false,true,true,true,true,true,true,true,false,true,false,false,true,true,false,true,true,false,false,false,true,true,false,true,false,true,true,false,true,true,false,false,false,true,true,false,true,true,true,false,false,false,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w9867871345074121:(3:ZMod 2526175064338974977)^((2526175064338974977-1)/9867871345074121)≠1:=
    ne_one [false,false,false,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (2526175064338974977-1)=2*(2*(2*(2*(2*(2*(2*(2*(9867871345074121)))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  have eqn:q=9867871345074121:=(Nat.prime_dvd_prime_iff_eq hp prime9867871345074121).mp hd; rw [eqn]; exact w9867871345074121
theorem prime954894174320132541307 : Nat.Prime 954894174320132541307 := by
  apply lucas_primality 954894174320132541307 (3:ZMod 954894174320132541307)
  · exact eq_one [false,true,false,true,true,true,true,false,true,true,false,true,false,false,true,true,false,true,true,true,false,true,true,false,true,false,false,true,false,false,true,false,false,false,true,true,false,false,true,false,false,false,false,true,true,false,false,true,true,false,false,false,true,false,true,true,true,true,false,false,false,false,true,true,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 954894174320132541307)^((954894174320132541307-1)/2)≠1:=
    ne_one [true,false,true,true,true,true,false,true,true,false,true,false,false,true,true,false,true,true,true,false,true,true,false,true,false,false,true,false,false,true,false,false,false,true,true,false,false,true,false,false,false,false,true,true,false,false,true,true,false,false,false,true,false,true,true,true,true,false,false,false,false,true,true,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 954894174320132541307)^((954894174320132541307-1)/3)≠1:=
    ne_one [false,true,true,true,true,true,true,false,false,true,true,true,false,true,true,true,false,false,true,false,false,true,false,false,true,true,false,false,false,false,true,true,false,true,true,true,false,true,true,false,true,false,true,true,true,false,true,true,true,false,true,false,false,false,true,false,true,false,false,false,false,false,true,false,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w7:(3:ZMod 954894174320132541307)^((954894174320132541307-1)/7)≠1:=
    ne_one [false,true,true,false,true,true,false,false,false,true,true,false,false,true,true,false,false,false,true,false,true,true,false,false,false,false,false,true,true,true,true,false,true,true,true,true,false,true,false,false,true,false,false,false,true,true,true,true,true,false,true,true,true,false,false,false,true,false,true,false,false,true,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w2526175064338974977:(3:ZMod 954894174320132541307)^((954894174320132541307-1)/2526175064338974977)≠1:=
    ne_one [false,true,false,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (954894174320132541307-1)=2*(3*(3*(3*(7*(2526175064338974977))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  have eqn:q=2526175064338974977:=(Nat.prime_dvd_prime_iff_eq hp prime2526175064338974977).mp hd; rw [eqn]; exact w2526175064338974977
theorem prime1745546550657202285509197 : Nat.Prime 1745546550657202285509197 := by
  apply lucas_primality 1745546550657202285509197 (2:ZMod 1745546550657202285509197)
  · exact eq_one [false,false,true,true,false,false,true,false,false,true,false,true,true,true,true,true,false,false,true,false,false,true,false,false,true,true,false,true,true,false,true,false,false,false,true,true,true,true,false,true,false,false,false,false,false,false,false,true,true,true,false,false,false,true,false,true,false,false,true,false,false,false,true,false,false,true,false,false,false,true,false,true,true,false,false,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 1745546550657202285509197)^((1745546550657202285509197-1)/2)≠1:=
    ne_one [false,true,true,false,false,true,false,false,true,false,true,true,true,true,true,false,false,true,false,false,true,false,false,true,true,false,true,true,false,true,false,false,false,true,true,true,true,false,true,false,false,false,false,false,false,false,true,true,true,false,false,false,true,false,true,false,false,true,false,false,false,true,false,false,true,false,false,false,true,false,true,true,false,false,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w457:(2:ZMod 1745546550657202285509197)^((1745546550657202285509197-1)/457)≠1:=
    ne_one [false,false,true,true,false,true,true,true,true,false,true,true,false,true,false,false,true,true,false,true,true,true,false,true,true,false,true,false,false,true,false,false,true,false,false,false,true,true,false,false,true,false,false,false,false,true,true,false,false,true,true,false,false,false,true,false,true,true,true,true,false,false,false,false,true,true,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w954894174320132541307:(2:ZMod 1745546550657202285509197)^((1745546550657202285509197-1)/954894174320132541307)≠1:=
    ne_one [false,false,true,false,false,true,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (1745546550657202285509197-1)=2*(2*(457*(954894174320132541307))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=457:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w457
  have eqn:q=954894174320132541307:=(Nat.prime_dvd_prime_iff_eq hp prime954894174320132541307).mp hd; rw [eqn]; exact w954894174320132541307
theorem prime87057315354522179184989699791727 : Nat.Prime 87057315354522179184989699791727 := by
  apply lucas_primality 87057315354522179184989699791727 (5:ZMod 87057315354522179184989699791727)
  · exact eq_one [false,true,true,true,false,true,true,false,true,true,false,true,true,false,true,false,true,true,false,true,false,false,true,false,false,true,false,true,false,true,false,false,false,true,true,true,false,false,true,false,false,true,true,true,true,true,true,true,false,true,false,false,true,true,false,false,false,true,true,true,false,true,true,false,false,true,false,false,true,true,false,false,true,false,false,false,true,true,true,false,true,true,false,true,true,false,true,false,true,false,false,false,true,false,true,true,false,true,false,true,false,false,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 87057315354522179184989699791727)^((87057315354522179184989699791727-1)/2)≠1:=
    ne_one [true,true,true,false,true,true,false,true,true,false,true,true,false,true,false,true,true,false,true,false,false,true,false,false,true,false,true,false,true,false,false,false,true,true,true,false,false,true,false,false,true,true,true,true,true,true,true,false,true,false,false,true,true,false,false,false,true,true,true,false,true,true,false,false,true,false,false,true,true,false,false,true,false,false,false,true,true,true,false,true,true,false,true,true,false,true,false,true,false,false,false,true,false,true,true,false,true,false,true,false,false,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w41:(5:ZMod 87057315354522179184989699791727)^((87057315354522179184989699791727-1)/41)≠1:=
    ne_one [false,true,true,true,true,true,false,true,true,false,true,false,true,true,true,true,false,false,true,false,false,false,false,true,true,false,true,true,false,false,false,false,false,false,true,true,false,true,true,false,true,false,true,false,false,true,false,false,true,false,true,false,false,true,true,false,false,true,true,true,false,true,false,false,true,true,false,false,true,true,false,false,true,false,false,false,false,false,true,false,true,false,false,true,false,true,true,true,false,false,true,true,false,false,true,true,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w353:(5:ZMod 87057315354522179184989699791727)^((87057315354522179184989699791727-1)/353)≠1:=
    ne_one [false,true,true,true,false,true,false,false,false,false,true,true,true,false,false,true,false,false,true,false,true,true,true,true,true,false,false,true,true,true,true,false,false,true,true,false,false,true,true,false,true,false,false,false,true,false,false,false,true,true,false,true,true,true,true,true,false,false,true,false,true,false,false,true,true,false,true,false,false,false,false,true,true,false,false,true,true,false,true,false,false,false,false,false,false,true,true,true,false,false,true,true,true,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w1723:(5:ZMod 87057315354522179184989699791727)^((87057315354522179184989699791727-1)/1723)≠1:=
    ne_one [false,true,false,true,false,true,true,false,false,true,true,false,true,false,false,true,true,false,true,false,true,false,false,false,true,true,false,true,true,true,false,true,true,false,false,true,true,true,true,false,true,false,false,false,true,true,false,false,false,true,false,false,true,false,true,false,true,true,true,true,true,true,true,true,false,false,true,false,true,true,false,true,true,false,true,true,true,false,false,true,false,true,false,false,false,false,true,false,true,true,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w1745546550657202285509197:(5:ZMod 87057315354522179184989699791727)^((87057315354522179184989699791727-1)/1745546550657202285509197)≠1:=
    ne_one [false,true,true,false,false,true,false,false,false,false,true,false,false,false,false,false,true,false,false,true,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (87057315354522179184989699791727-1)=2*(41*(353*(1723*(1745546550657202285509197)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=41:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w41
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=353:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w353
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=1723:=(Nat.prime_dvd_prime_iff_eq hp prime1723).mp leaf; rw [eqn]; exact w1723
  have eqn:q=1745546550657202285509197:=(Nat.prime_dvd_prime_iff_eq hp prime1745546550657202285509197).mp hd; rw [eqn]; exact w1745546550657202285509197
theorem numerator34: (bernoulli 34).num.natAbs=2577687858367:=by
  have eqn:=sound (j:=34) 117288381359406970983270 data checked (by decide)
  rw [show coeff data 34=50388806092943619857172626414420015 by decide +kernel] at eqn
  have value:bernoulli 34=(2577687858367:ℚ)/6:=by push_cast at eqn; linarith
  rw [value]; norm_num
theorem factors34 {q:ℕ} (hp:q.Prime) (hd:q∣2577687858367) : q=17 ∨ q=151628697551 := by
  rw [show 2577687858367=17*(151628697551) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=17:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; decide +kernel
  have eqn:q=151628697551:=(Nat.prime_dvd_prime_iff_eq hp prime151628697551).mp hd; rw [eqn]; decide +kernel
theorem numerator56: (bernoulli 56).num.natAbs=2479392929313226753685415739663229:=by
  have eqn:=sound (j:=56) 117288381359406970983270 data checked (by decide)
  rw [show coeff data 56=-334257452221961966008565390215914584966870907637693309 by decide +kernel] at eqn
  have value:bernoulli 56=(-2479392929313226753685415739663229:ℚ)/870:=by push_cast at eqn; linarith
  rw [value]; norm_num
theorem factors56 {q:ℕ} (hp:q.Prime) (hd:q∣2479392929313226753685415739663229) : q=7 ∨ q=113161 ∨ q=163979 ∨ q=19088082706840550550313 := by
  rw [show 2479392929313226753685415739663229=7*(113161*(163979*(19088082706840550550313))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=113161:=(Nat.prime_dvd_prime_iff_eq hp prime113161).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=163979:=(Nat.prime_dvd_prime_iff_eq hp prime163979).mp leaf; rw [eqn]; decide +kernel
  have eqn:q=19088082706840550550313:=(Nat.prime_dvd_prime_iff_eq hp prime19088082706840550550313).mp hd; rw [eqn]; decide +kernel
theorem numerator64: (bernoulli 64).num.natAbs=106783830147866529886385444979142647942017:=by
  have eqn:=sound (j:=64) 117288381359406970983270 data checked (by decide)
  rw [show coeff data 64=-24557848222355115368429335144982705526693616830854229608700109 by decide +kernel] at eqn
  have value:bernoulli 64=(-106783830147866529886385444979142647942017:ℚ)/510:=by push_cast at eqn; linarith
  rw [value]; norm_num
theorem factors64 {q:ℕ} (hp:q.Prime) (hd:q∣106783830147866529886385444979142647942017) : q=1226592271 ∨ q=87057315354522179184989699791727 := by
  rw [show 106783830147866529886385444979142647942017=1226592271*(87057315354522179184989699791727) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=1226592271:=(Nat.prime_dvd_prime_iff_eq hp prime1226592271).mp leaf; rw [eqn]; decide +kernel
  have eqn:q=87057315354522179184989699791727:=(Nat.prime_dvd_prime_iff_eq hp prime87057315354522179184989699791727).mp hd; rw [eqn]; decide +kernel
end OMA.SmallCubicRows284759
