import CubicSmallPrimeFilter284759
import CubicBernoulliAll284759
import SmallCubicRows284759

namespace OMA.CubicSmallSemiprimes284759
open Nat Finset OMA.SmallCubicRows284759

/-- There are no semiprime counterexamples with a prime factor below 101,
regardless of the size of the other prime. Equality of the primes is allowed. -/
theorem excluded {p q:ℕ} (pp:p.Prime) (qp:q.Prime) (ord:p≤q) (small:p<101) :
    ¬(p*q)^3∣∑i∈Icc 1 (p*q-1),i^(p*q-2) := by
  intro hit
  have on:=((OMA.CubicBernoulliAll284759.original_all (Nat.mul_pos pp.pos qp.pos)).mp hit).1
  have op:Odd p:=(Nat.odd_mul.mp on).1
  have options:=OMA.CubicSmallPrimeFilter284759.options on pp small (dvd_mul_right p q) hit
  have bound (lo:7≤p) (lt:p<q) : q∣(bernoulli (p-3)).num.natAbs :=
    OMA.CubicCofactorBound284759.bound qp lt lo op (by simpa only [mul_comm q p] using hit)
  rcases options with ⟨rfl,idx⟩|⟨rfl,idx⟩|⟨rfl,idx⟩
  · have lt:37<q:=by
      by_contra! le
      have eq:q=37:=by omega
      rw [eq] at idx
      norm_num at idx
    have dv:=bound (by decide) lt
    rw [show (37:ℕ)-3=34 by decide,numerator34] at dv
    rcases factors34 qp dv with rfl|rfl <;> revert idx <;> decide +kernel
  · have lt:59<q:=by
      by_contra! le
      have eq:q=59:=by omega
      rw [eq] at idx
      norm_num at idx
    have dv:=bound (by decide) lt
    rw [show (59:ℕ)-3=56 by decide,numerator56] at dv
    rcases factors56 qp dv with rfl|rfl|rfl|rfl <;> revert idx <;> decide +kernel
  · have lt:67<q:=by
      by_contra! le
      have eq:q=67:=by omega
      rw [eq] at idx
      norm_num at idx
    have dv:=bound (by decide) lt
    rw [show (67:ℕ)-3=64 by decide,numerator64] at dv
    rcases factors64 qp dv with rfl|rfl <;> revert idx <;> decide +kernel

#print axioms excluded
end OMA.CubicSmallSemiprimes284759
