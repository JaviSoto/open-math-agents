import Mathlib

/-! Primality certificates with binary modular exponentiation. No large
unreduced power or unverified factorization is needed by the kernel. -/
namespace OMA.PrattRows284759
open Nat Finset

def index : List Bool → ℕ
  | [] => 0
  | b::t => 2*index t+b.toNat

def binary (p a:ℕ) : List Bool → ℕ
  | [] => 1%p
  | b::t => let r:=binary p a t; (r*r*(if b then a else 1))%p

theorem binary_eq (p a:ℕ) (l:List Bool) :
    ((binary p a l:ℕ):ZMod p)=(a:ZMod p)^(index l) := by
  induction l with
  | nil=>simp [binary,index,ZMod.natCast_mod]
  | cons b t ih=>
    cases b <;> simp [binary,index,ZMod.natCast_mod,ih,pow_succ,pow_mul] <;> ring

theorem eq_one {p a e:ℕ} (l:List Bool) (ix:index l=e) (ok:binary p a l=1) :
    (a:ZMod p)^e=1 := by rw [←ix,←binary_eq,ok,Nat.cast_one]

theorem ne_one {p a e:ℕ} (l:List Bool) (ix:index l=e)
    (ok:¬binary p a l ≡ 1 [MOD p]) : (a:ZMod p)^e≠1 := by
  rw [←ix,←binary_eq]
  intro eqn;apply ok
  exact (ZMod.natCast_eq_natCast_iff (binary p a l) 1 p).mp (by simpa only [Nat.cast_one] using eqn)

end OMA.PrattRows284759
