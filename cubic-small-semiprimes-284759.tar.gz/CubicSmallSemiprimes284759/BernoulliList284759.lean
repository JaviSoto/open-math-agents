import Mathlib

/-! A finite exact table is certified by the triangular Bernoulli recurrence.
All validation uses integers and the fast falling-factorial binomial formula. -/
namespace OMA.BernoulliList284759
open Nat Finset

def coeff (l:List ℤ) (i:ℕ) := l[i]?.getD 0

def row (l:List ℤ) (j:ℕ) : ℤ :=
  ∑i∈range (j+1), (Nat.fast_choose (j+1) i:ℤ)*coeff l i

theorem sound {N:ℕ} (D:ℤ) (l:List ℤ)
    (check:∀j:Fin N, row l j=if (j:ℕ)=0 then D else 0) {j:ℕ} (lt:j<N) :
    (D:ℚ)*bernoulli j=(coeff l j:ℚ) := by
  induction j using Nat.strong_induction_on with
  | h j ih=>
    have z:=check ⟨j,lt⟩
    change row l j=(if j=0 then D else 0) at z
    unfold row at z
    rw [←Nat.choose_eq_fast_choose] at z
    have q:(∑i∈range (j+1),((j+1).choose i:ℚ)*(coeff l i:ℚ))=
        (if j=0 then (D:ℚ) else 0):=by
      split_ifs at z ⊢ with hj <;> exact_mod_cast z
    have b:=sum_bernoulli (j+1)
    have eqrhs: (D:ℚ)*(if j+1=1 then (1:ℚ) else 0)=(if j=0 then (D:ℚ) else 0):=by
      by_cases h:j=0 <;> simp [h]
    have all:(∑i∈range (j+1), ((j+1).choose i:ℚ)*((D:ℚ)*bernoulli i))=
        ∑i∈range (j+1),((j+1).choose i:ℚ)*(coeff l i:ℚ):=by
      rw [q,←eqrhs,←b,mul_sum];apply sum_congr rfl;intro i _;ring
    have prev:(∑i∈range j, ((j+1).choose i:ℚ)*((D:ℚ)*bernoulli i))=
        ∑i∈range j,((j+1).choose i:ℚ)*(coeff l i:ℚ):=by
      apply sum_congr rfl;intro i hi
      rw [ih i (mem_range.mp hi) (by have :=mem_range.mp hi;omega)]
    simp only [sum_range_succ,Nat.choose_succ_self_right] at all
    rw [prev] at all
    exact mul_left_cancel₀ (by positivity : ((j+1:ℕ):ℚ)≠0) (add_left_cancel all)

end OMA.BernoulliList284759
