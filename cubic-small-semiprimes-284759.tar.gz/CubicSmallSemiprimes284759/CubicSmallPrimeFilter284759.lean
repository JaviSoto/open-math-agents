import CubicCofactorBound284759

namespace OMA.CubicSmallPrimeFilter284759
open Nat Finset
open private OMA.PowerSumRegular284760.shrink from PowerSumRegular284760

theorem small_row {n p:ℕ} (on:Odd n) (hp:p.Prime) (large:5≤p) (pn:p∣n)
    (hit:n^3∣∑i∈Icc 1 (n-1),i^(n-2)) :
    let k:=(n-3)%(p-1)
    1<k ∧ k<p-1 ∧ Even k ∧ p^2∣∑i∈range p,i^k := by
  let k:=(n-3)%(p-1)
  let j:=(n-3)/(p-1)
  have nb:=Nat.le_of_dvd on.pos pn
  have form:n-3=k+(p-1)*j:=(Nat.mod_add_div _ _).symm
  have hi:k<p-1:=Nat.mod_lt _ (by omega)
  have two:2∣p-1:=by obtain ⟨a,ha⟩:=hp.odd_of_ne_two (by omega);exact ⟨a,by omega⟩
  have even:Even k:=by
    rw [even_iff_two_dvd,Nat.dvd_iff_mod_eq_zero,Nat.mod_mod_of_dvd _ two]
    obtain ⟨a,ha⟩:=on;omega
  have noz:k≠0:=by
    intro h
    have no:=OMA.PowerSum284760.local_obstruction on hp pn (Nat.dvd_of_mod_eq_zero h)
    rw [show Icc 1 (n-1)=Ico 1 n by ext x;simp;omega] at hit
    exact no ((pow_dvd_pow n (by decide : 2≤3)).trans hit)
  have lo:1<k:=by obtain ⟨a,ha⟩:=even;omega
  have os:Odd (n-2):=by obtain ⟨a,ha⟩:=on;exact ⟨a-1,by omega⟩
  have od:Odd (n-3-1):=by obtain ⟨a,ha⟩:=on;exact ⟨a-2,by omega⟩
  have ref:=OMA.CubicBernoulliOriginal284759.reflection on os (by omega)
    ((Nat.coprime_self_sub_right (by omega)).mpr (Nat.coprime_two_right.mpr on))
  have sq:=ref.mp hit
  rw [show n-2-1=n-3 by omega] at sq
  have row:=OMA.PowerSumRegular284760.shrink hp large od n on pn
    ((show p*n∣n^2 by rw [pow_two];exact Nat.mul_dvd_mul_right pn n).trans sq)
  have unit:¬p∣n-3:=by intro d;have d3:p∣3:=(Nat.dvd_add_left d).mp (by rwa [show 3+(n-3)=n by omega]);have :=Nat.le_of_dvd (by decide : 0<3) d3;omega
  rw [form] at unit row
  have short:=OMA.CubicCofactorBound284759.lower hp lo hi unit
    (by simpa only [Nat.cast_sum,Nat.cast_pow] using (ZMod.natCast_eq_zero_iff _ _).mpr row)
  exact ⟨lo,hi,even,(ZMod.natCast_eq_zero_iff _ _).mp (by simpa only [Nat.cast_sum,Nat.cast_pow] using short)⟩

private theorem table :
    ∀p∈range 101, p.Prime → 5≤p → ∀ k∈range (p-1), 1<k → k%2=0 →
       p^2∣∑i∈range p,i^k → (p=37 ∧ k=32) ∨ (p=59 ∧ k=44) ∨ (p=67 ∧ k=58) := by
  intro p pm pp lb
  rw [mem_range] at pm
  interval_cases p <;> first | contradiction | norm_num at pp
  all_goals decide +kernel

theorem options {n p:ℕ} (on:Odd n) (hp:p.Prime) (lt:p<101) (pn:p∣n)
    (hit:n^3∣∑i∈Icc 1 (n-1),i^(n-2)) :
    (p=37 ∧ (n-3)%36=32) ∨ (p=59 ∧ (n-3)%58=44) ∨ (p=67 ∧ (n-3)%66=58) := by
  by_cases big:5≤p
  · obtain ⟨lo,hi,ev,div⟩:=small_row on hp big pn hit
    have h:=table p (mem_range.mpr lt) hp big _ (mem_range.mpr hi) lo
      (Nat.mod_eq_zero_of_dvd ev.two_dvd) div
    rcases h with ⟨rfl,k⟩|⟨rfl,k⟩|⟨rfl,k⟩
    · exact Or.inl ⟨rfl,k⟩
    · exact Or.inr (Or.inl ⟨rfl,k⟩)
    · exact Or.inr (Or.inr ⟨rfl,k⟩)
  · have no2:=on.not_two_dvd_nat
    have np2:p≠2:=fun h=>no2 (h ▸ pn)
    have np4:p≠4:=fun h=>(by decide : ¬Nat.Prime 4) (h ▸ hp)
    have p3:p=3:=by have :=hp.two_le;omega
    subst p
    have nr:3-1∣n-3:=by obtain ⟨a,ha⟩:=on;exact ⟨a-1,by omega⟩
    have no:=OMA.PowerSum284760.local_obstruction on hp pn nr
    rw [show Icc 1 (n-1)=Ico 1 n by ext x;simp;omega] at hit
    exact False.elim (no ((pow_dvd_pow n (by decide : 2≤3)).trans hit))

#print axioms options
end OMA.CubicSmallPrimeFilter284759
