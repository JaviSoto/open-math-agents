import RankTwoInteriorCover245212
/-! Checked rank-two finite arithmetic. -/
namespace OMA.RankTwoCell22
open OMA.RankTwoInteriorCover245212 OMA.RankTwoInteriorWalk245212
private abbrev e := Script.leaf .empty
private abbrev p := Script.leaf .pole
private abbrev g := Script.leaf .exterior
private abbrev a := Script.leaf .arithmetic
private abbrev s := Script.fork
set_option maxHeartbeats 0
set_option maxRecDepth 20000
private theorem n0 : Closed ⟨6,22,22,225,22,22,13,258⟩ := of_script g _ (by decide +kernel)
private theorem n1 : Closed ⟨23,44,22,225,22,22,22,258⟩ := of_script g _ (by decide +kernel)
private theorem n2 : Closed ⟨45,86,22,70,22,22,43,258⟩ := of_script (s (s g g) (s g g)) _ (by decide +kernel)
private theorem n3 : Closed ⟨45,86,71,225,22,22,43,258⟩ := of_script (s (s (s g g) (s g g)) (s (s (s g g) (s g g)) g)) _ (by decide +kernel)
private theorem n4 : Closed ⟨45,86,22,225,22,22,22,258⟩ := join _ n2 n3 (by decide +kernel)
private theorem n5 : Closed ⟨23,86,22,225,22,22,13,258⟩ := join _ n1 n4 (by decide +kernel)
private theorem n6 : Closed ⟨6,86,22,225,22,22,13,3750⟩ := join _ n0 n5 (by decide +kernel)
private theorem n7 : Closed ⟨87,169,22,70,22,22,83,507⟩ := of_script (s (s g (s (s (s (s (s g g) p) (s (s g g) p)) g) p)) g) _ (by decide +kernel)
private theorem n8 : Closed ⟨87,107,71,98,22,22,85,234⟩ := of_script (s (s (s g g) p) (s (s g g) p)) _ (by decide +kernel)
private theorem n9 : Closed ⟨108,128,71,98,22,22,85,234⟩ := of_script (s (s (s g p) g) (s (s (s g (s (s g p) g)) p) g)) _ (by decide +kernel)
private theorem n10 : Closed ⟨87,128,71,98,22,22,85,234⟩ := join _ n8 n9 (by decide +kernel)
private theorem n11 : Closed ⟨87,128,71,98,22,22,235,384⟩ := of_script p _ (by decide +kernel)
private theorem n12 : Closed ⟨87,128,71,98,22,22,85,384⟩ := join _ n10 n11 (by decide +kernel)
private theorem n13 : Closed ⟨87,107,99,126,22,22,86,235⟩ := of_script (s (s (s g g) p) (s (s g g) p)) _ (by decide +kernel)
private theorem n14 : Closed ⟨108,128,99,112,22,22,106,235⟩ := of_script (s (s (s (s (s g p) g) (s (s g p) g)) p) g) _ (by decide +kernel)
private theorem n15 : Closed ⟨108,128,113,126,22,22,106,235⟩ := of_script (s (s (s (s (s g p) g) (s (s g p) g)) p) g) _ (by decide +kernel)
private theorem n16 : Closed ⟨108,128,99,126,22,22,86,235⟩ := join _ n14 n15 (by decide +kernel)
private theorem n17 : Closed ⟨87,128,99,126,22,22,86,235⟩ := join _ n13 n16 (by decide +kernel)
private theorem n18 : Closed ⟨87,128,99,126,22,22,236,384⟩ := of_script p _ (by decide +kernel)
private theorem n19 : Closed ⟨87,128,99,126,22,22,85,384⟩ := join _ n17 n18 (by decide +kernel)
private theorem n20 : Closed ⟨87,128,71,126,22,22,85,507⟩ := join _ n12 n19 (by decide +kernel)
private theorem n21 : Closed ⟨129,169,71,126,22,22,85,507⟩ := of_script g _ (by decide +kernel)
private theorem n22 : Closed ⟨87,169,71,126,22,22,85,507⟩ := join _ n20 n21 (by decide +kernel)
private theorem n23 : Closed ⟨87,107,127,151,22,22,86,235⟩ := of_script (s (s (s g g) p) (s g p)) _ (by decide +kernel)
private theorem n24 : Closed ⟨108,128,127,151,22,22,86,235⟩ := of_script (s (s (s (s (s (s g p) g) (s g g)) p) g) g) _ (by decide +kernel)
private theorem n25 : Closed ⟨87,128,127,151,22,22,86,235⟩ := join _ n23 n24 (by decide +kernel)
private theorem n26 : Closed ⟨87,128,127,151,22,22,236,384⟩ := of_script p _ (by decide +kernel)
private theorem n27 : Closed ⟨87,128,127,151,22,22,86,384⟩ := join _ n25 n26 (by decide +kernel)
private theorem n28 : Closed ⟨87,128,152,176,22,22,86,384⟩ := of_script g _ (by decide +kernel)
private theorem n29 : Closed ⟨87,128,127,176,22,22,86,507⟩ := join _ n27 n28 (by decide +kernel)
private theorem n30 : Closed ⟨129,169,127,176,22,22,86,507⟩ := of_script g _ (by decide +kernel)
private theorem n31 : Closed ⟨87,169,127,176,22,22,86,507⟩ := join _ n29 n30 (by decide +kernel)
private theorem n32 : Closed ⟨87,169,177,225,22,22,86,507⟩ := of_script g _ (by decide +kernel)
private theorem n33 : Closed ⟨87,169,127,225,22,22,85,507⟩ := join _ n31 n32 (by decide +kernel)
private theorem n34 : Closed ⟨87,169,71,225,22,22,83,507⟩ := join _ n22 n33 (by decide +kernel)
private theorem n35 : Closed ⟨87,169,22,225,22,22,83,987⟩ := join _ n7 n34 (by decide +kernel)
private theorem n36 : Closed ⟨170,329,22,225,22,22,83,987⟩ := of_script g _ (by decide +kernel)
private theorem n37 : Closed ⟨87,329,22,225,22,22,83,3750⟩ := join _ n35 n36 (by decide +kernel)
private theorem n38 : Closed ⟨330,1250,22,225,22,22,83,3750⟩ := of_script g _ (by decide +kernel)
private theorem n39 : Closed ⟨87,1250,22,225,22,22,13,3750⟩ := join _ n37 n38 (by decide +kernel)
private theorem n40 : Closed ⟨6,1250,22,225,22,22,13,3750⟩ := join _ n6 n39 (by decide +kernel)
theorem normal : Closed (root 22 6 1250 false) := n40
private theorem n41 : Closed ⟨6,1250,22,22,23,225,13,3750⟩ := of_script (s (s g (s g (s (s (s g g) g) g))) (s (s g g) g)) _ (by decide +kernel)
theorem reverse : Closed (root 22 6 1250 true) := n41
#print axioms normal
#print axioms reverse
end OMA.RankTwoCell22
