import RankTwoInteriorCover245212
/-! Checked rank-two finite arithmetic. -/
namespace OMA.RankTwoCell23
open OMA.RankTwoInteriorCover245212 OMA.RankTwoInteriorWalk245212
private abbrev e := Script.leaf .empty
private abbrev p := Script.leaf .pole
private abbrev g := Script.leaf .exterior
private abbrev a := Script.leaf .arithmetic
private abbrev s := Script.fork
set_option maxHeartbeats 0
set_option maxRecDepth 20000
private theorem n0 : Closed ⟨6,86,23,225,23,23,13,3750⟩ := of_script (s g (s g (s (s (s g g) g) g))) _ (by decide +kernel)
private theorem n1 : Closed ⟨87,169,23,71,23,23,83,507⟩ := of_script (s (s g (s (s g g) p)) g) _ (by decide +kernel)
private theorem n2 : Closed ⟨87,128,72,99,23,23,85,384⟩ := of_script (s (s g (s (s (s g p) g) (s (s g p) g))) p) _ (by decide +kernel)
private theorem n3 : Closed ⟨87,128,100,127,23,23,85,384⟩ := of_script (s (s g (s (s (s g p) g) (s (s g p) g))) p) _ (by decide +kernel)
private theorem n4 : Closed ⟨87,128,72,127,23,23,85,507⟩ := join _ n2 n3 (by decide +kernel)
private theorem n5 : Closed ⟨129,169,72,127,23,23,85,507⟩ := of_script g _ (by decide +kernel)
private theorem n6 : Closed ⟨87,169,72,127,23,23,85,507⟩ := join _ n4 n5 (by decide +kernel)
private theorem n7 : Closed ⟨87,128,128,152,23,23,86,235⟩ := of_script (s g (s (s (s (s (s g g) (s g g)) p) g) (s (s g p) g))) _ (by decide +kernel)
private theorem n8 : Closed ⟨87,128,128,152,23,23,236,384⟩ := of_script p _ (by decide +kernel)
private theorem n9 : Closed ⟨87,128,128,152,23,23,86,384⟩ := join _ n7 n8 (by decide +kernel)
private theorem n10 : Closed ⟨87,128,153,176,23,23,86,384⟩ := of_script (s g p) _ (by decide +kernel)
private theorem n11 : Closed ⟨87,128,128,176,23,23,86,507⟩ := join _ n9 n10 (by decide +kernel)
private theorem n12 : Closed ⟨129,169,128,176,23,23,86,507⟩ := of_script g _ (by decide +kernel)
private theorem n13 : Closed ⟨87,169,128,176,23,23,86,507⟩ := join _ n11 n12 (by decide +kernel)
private theorem n14 : Closed ⟨87,169,177,225,23,23,86,507⟩ := of_script g _ (by decide +kernel)
private theorem n15 : Closed ⟨87,169,128,225,23,23,85,507⟩ := join _ n13 n14 (by decide +kernel)
private theorem n16 : Closed ⟨87,169,72,225,23,23,83,507⟩ := join _ n6 n15 (by decide +kernel)
private theorem n17 : Closed ⟨87,169,23,225,23,23,83,987⟩ := join _ n1 n16 (by decide +kernel)
private theorem n18 : Closed ⟨170,329,23,225,23,23,83,987⟩ := of_script g _ (by decide +kernel)
private theorem n19 : Closed ⟨87,329,23,225,23,23,83,3750⟩ := join _ n17 n18 (by decide +kernel)
private theorem n20 : Closed ⟨330,1250,23,225,23,23,83,3750⟩ := of_script g _ (by decide +kernel)
private theorem n21 : Closed ⟨87,1250,23,225,23,23,13,3750⟩ := join _ n19 n20 (by decide +kernel)
private theorem n22 : Closed ⟨6,1250,23,225,23,23,13,3750⟩ := join _ n0 n21 (by decide +kernel)
theorem normal : Closed (root 23 6 1250 false) := n22
private theorem n23 : Closed ⟨6,1250,23,23,24,225,13,3750⟩ := of_script (s (s g (s g (s (s (s g g) g) g))) (s (s g g) g)) _ (by decide +kernel)
theorem reverse : Closed (root 23 6 1250 true) := n23
#print axioms normal
#print axioms reverse
end OMA.RankTwoCell23
