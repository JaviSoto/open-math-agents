import RankTwoInteriorCover245212
/-! Checked rank-two finite arithmetic. -/
namespace OMA.RankTwoCell24
open OMA.RankTwoInteriorCover245212 OMA.RankTwoInteriorWalk245212
private abbrev e := Script.leaf .empty
private abbrev p := Script.leaf .pole
private abbrev g := Script.leaf .exterior
private abbrev a := Script.leaf .arithmetic
private abbrev s := Script.fork
set_option maxHeartbeats 0
set_option maxRecDepth 20000
private theorem n0 : Closed ⟨6,86,24,225,24,24,13,3750⟩ := of_script (s g (s g g)) _ (by decide +kernel)
private theorem n1 : Closed ⟨87,169,24,73,24,24,83,507⟩ := of_script (s (s g (s (s g g) p)) g) _ (by decide +kernel)
private theorem n2 : Closed ⟨87,128,74,101,24,24,85,384⟩ := of_script (s (s g (s (s g g) (s g g))) p) _ (by decide +kernel)
private theorem n3 : Closed ⟨87,128,102,129,24,24,85,384⟩ := of_script (s (s g (s (s g g) (s g g))) p) _ (by decide +kernel)
private theorem n4 : Closed ⟨87,128,74,129,24,24,85,507⟩ := join _ n2 n3 (by decide +kernel)
private theorem n5 : Closed ⟨129,169,74,129,24,24,85,507⟩ := of_script g _ (by decide +kernel)
private theorem n6 : Closed ⟨87,169,74,129,24,24,85,507⟩ := join _ n4 n5 (by decide +kernel)
private theorem n7 : Closed ⟨87,169,130,177,24,24,86,507⟩ := of_script (s (s (s (s g (s (s g g) (s g g))) p) (s (s g g) p)) g) _ (by decide +kernel)
private theorem n8 : Closed ⟨87,169,178,225,24,24,86,507⟩ := of_script g _ (by decide +kernel)
private theorem n9 : Closed ⟨87,169,130,225,24,24,85,507⟩ := join _ n7 n8 (by decide +kernel)
private theorem n10 : Closed ⟨87,169,74,225,24,24,83,507⟩ := join _ n6 n9 (by decide +kernel)
private theorem n11 : Closed ⟨87,169,24,225,24,24,83,987⟩ := join _ n1 n10 (by decide +kernel)
private theorem n12 : Closed ⟨170,329,24,225,24,24,83,987⟩ := of_script g _ (by decide +kernel)
private theorem n13 : Closed ⟨87,329,24,225,24,24,83,3750⟩ := join _ n11 n12 (by decide +kernel)
private theorem n14 : Closed ⟨330,1250,24,225,24,24,83,3750⟩ := of_script g _ (by decide +kernel)
private theorem n15 : Closed ⟨87,1250,24,225,24,24,13,3750⟩ := join _ n13 n14 (by decide +kernel)
private theorem n16 : Closed ⟨6,1250,24,225,24,24,13,3750⟩ := join _ n0 n15 (by decide +kernel)
theorem normal : Closed (root 24 6 1250 false) := n16
private theorem n17 : Closed ⟨6,1250,24,24,25,225,13,3750⟩ := of_script (s (s g (s g g)) (s (s g g) g)) _ (by decide +kernel)
theorem reverse : Closed (root 24 6 1250 true) := n17
#print axioms normal
#print axioms reverse
end OMA.RankTwoCell24
