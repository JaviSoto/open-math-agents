import RankTwoInteriorCover245212
/-! Checked rank-two finite arithmetic. -/
namespace OMA.RankTwoCell31
open OMA.RankTwoInteriorCover245212 OMA.RankTwoInteriorWalk245212
private abbrev e := Script.leaf .empty
private abbrev p := Script.leaf .pole
private abbrev g := Script.leaf .exterior
private abbrev a := Script.leaf .arithmetic
private abbrev s := Script.fork
set_option maxHeartbeats 0
set_option maxRecDepth 20000
private theorem n0 : Closed ⟨6,86,31,225,31,31,13,3750⟩ := of_script (s g g) _ (by decide +kernel)
private theorem n1 : Closed ⟨87,1250,31,225,31,31,13,3750⟩ := of_script (s (s (s (s g g) (s (s g g) (s (s g g) (s g g)))) g) g) _ (by decide +kernel)
private theorem n2 : Closed ⟨6,1250,31,225,31,31,13,3750⟩ := join _ n0 n1 (by decide +kernel)
theorem normal : Closed (root 31 6 1250 false) := n2
private theorem n3 : Closed ⟨6,1250,31,31,32,225,13,3750⟩ := of_script (s (s g g) (s (s g g) g)) _ (by decide +kernel)
theorem reverse : Closed (root 31 6 1250 true) := n3
#print axioms normal
#print axioms reverse
end OMA.RankTwoCell31
