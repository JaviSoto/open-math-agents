import RankTwoInteriorCover245212
/-! Checked rank-two finite arithmetic. -/
namespace OMA.RankTwoCell25
open OMA.RankTwoInteriorCover245212 OMA.RankTwoInteriorWalk245212
private abbrev e := Script.leaf .empty
private abbrev p := Script.leaf .pole
private abbrev g := Script.leaf .exterior
private abbrev a := Script.leaf .arithmetic
private abbrev s := Script.fork
set_option maxHeartbeats 0
set_option maxRecDepth 20000
private theorem n0 : Closed ⟨6,86,25,225,25,25,13,3750⟩ := of_script (s g (s g g)) _ (by decide +kernel)
private theorem n1 : Closed ⟨87,169,25,75,25,25,83,507⟩ := of_script (s (s g (s (s g g) p)) g) _ (by decide +kernel)
private theorem n2 : Closed ⟨87,169,76,130,25,25,85,507⟩ := of_script (s (s (s (s g g) p) (s (s g g) p)) g) _ (by decide +kernel)
private theorem n3 : Closed ⟨87,169,131,225,25,25,85,507⟩ := of_script (s (s (s (s (s g g) p) (s (s g g) p)) g) g) _ (by decide +kernel)
private theorem n4 : Closed ⟨87,169,76,225,25,25,83,507⟩ := join _ n2 n3 (by decide +kernel)
private theorem n5 : Closed ⟨87,169,25,225,25,25,83,987⟩ := join _ n1 n4 (by decide +kernel)
private theorem n6 : Closed ⟨170,329,25,225,25,25,83,987⟩ := of_script g _ (by decide +kernel)
private theorem n7 : Closed ⟨87,329,25,225,25,25,83,3750⟩ := join _ n5 n6 (by decide +kernel)
private theorem n8 : Closed ⟨330,1250,25,225,25,25,83,3750⟩ := of_script g _ (by decide +kernel)
private theorem n9 : Closed ⟨87,1250,25,225,25,25,13,3750⟩ := join _ n7 n8 (by decide +kernel)
private theorem n10 : Closed ⟨6,1250,25,225,25,25,13,3750⟩ := join _ n0 n9 (by decide +kernel)
theorem normal : Closed (root 25 6 1250 false) := n10
private theorem n11 : Closed ⟨6,1250,25,25,26,225,13,3750⟩ := of_script (s (s g (s g g)) (s (s g g) g)) _ (by decide +kernel)
theorem reverse : Closed (root 25 6 1250 true) := n11
#print axioms normal
#print axioms reverse
end OMA.RankTwoCell25
