import RankTwoInteriorCover245212
/-! Checked rank-two finite arithmetic. -/
namespace OMA.RankTwoCell27
open OMA.RankTwoInteriorCover245212 OMA.RankTwoInteriorWalk245212
private abbrev e := Script.leaf .empty
private abbrev p := Script.leaf .pole
private abbrev g := Script.leaf .exterior
private abbrev a := Script.leaf .arithmetic
private abbrev s := Script.fork
set_option maxHeartbeats 0
set_option maxRecDepth 20000
private theorem n0 : Closed ⟨6,86,27,225,27,27,13,3750⟩ := of_script (s g g) _ (by decide +kernel)
private theorem n1 : Closed ⟨87,329,27,225,27,27,83,3750⟩ := of_script (s (s (s (s g g) g) (s (s g g) (s (s g g) (s g g)))) g) _ (by decide +kernel)
private theorem n2 : Closed ⟨330,1250,27,225,27,27,83,3750⟩ := of_script g _ (by decide +kernel)
private theorem n3 : Closed ⟨87,1250,27,225,27,27,13,3750⟩ := join _ n1 n2 (by decide +kernel)
private theorem n4 : Closed ⟨6,1250,27,225,27,27,13,3750⟩ := join _ n0 n3 (by decide +kernel)
theorem normal : Closed (root 27 6 1250 false) := n4
private theorem n5 : Closed ⟨6,1250,27,27,28,225,13,3750⟩ := of_script (s (s g (s g g)) (s (s g g) g)) _ (by decide +kernel)
theorem reverse : Closed (root 27 6 1250 true) := n5
#print axioms normal
#print axioms reverse
end OMA.RankTwoCell27
