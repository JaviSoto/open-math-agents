import FormalConjectures.Arxiv.«1601.03081».UniqueCrystalComponents

/-! Executable finite certificate for the two complementary-squareclass
parameter ranges isolated in the accompanying mathematical argument. -/
namespace OMA.CrystalComplementFinite

def halves (q : ℕ) : ℕ → ℕ × ℕ
  | 0 => (0,1)
  | r+1 =>
    let (x,y) := halves q r
    (y,(q-2)*y+2-x)

def value (q r : ℕ) : ℕ :=
  let (x,y) := halves q r
  (2*x-1)*(2*y-1)

def belowSize (q n : ℕ) : Bool :=
  if q < 11 then decide (n<64*q^21) else decide (4096*n<q^15)

/-- A necessary test for a second parameter in the complementary squareclass.
The integer t is forced by the width of the interval in the paper proof. -/
def possible (q r : ℕ) : Bool :=
  let n := value q r
  let d := q-4
  let base := 4*d*(n+1)
  let t := base.sqrt+1
  let z := t^2-base
  let Q := z/d
  let sd := Q*(4*(n+1)+Q)
  let u := sd.sqrt
  let T := (u+Q)/2
  let g := T^2-4*n
  decide (z%d=0 && z.sqrt^2=z && Q^3≤4*n && u^2=sd && (u+Q)%2=0 &&
    4*n≤T^2 && g.sqrt^2=g && (T+g.sqrt)%2=0)

private def small : List (ℕ × ℕ) := (List.range 32).flatMap fun q =>
  ((List.range 19).filter fun r => 5≤q && 2≤r && belowSize q (value q r)).map (q,·)

private def large : List (ℕ × ℕ) := (List.range 8).flatMap fun r =>
  let top := 4*(4*r-1)^2
  ((List.range (top+1)).filter fun d => 2≤r && 28≤d && top%d=0).map (fun d => (d+4,r))

/-- The monotone row sequence in every small parameter already exceeds
its analytic size bound at index 19. -/
theorem small_tail :
    (List.range 32).all (fun q => q<5 || !(belowSize q (value q 19))) = true := by
  decide +kernel

theorem counts : small.length=184 ∧ large.length=44 := by decide +kernel

theorem all_excluded : (small++large).all (fun z => !(possible z.1 z.2)) = true := by
  decide +kernel

end OMA.CrystalComplementFinite
