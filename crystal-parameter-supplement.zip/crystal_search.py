"""Check all unequal biharmonic crystal decompositions up to a given bound.

The classification is Theorem 4 of Abrate--Barbero--Cerruti--Murru. The degree
three class is recognized by integer cube root, rather than materializing it.
The w=4 class is recognized by two square tests. All other rows (w>=5, j>=2)
are sparse enough to store in a table. The search uses exact integers.
"""

from math import isqrt
from sys import argv


def cubic_root(x: int) -> int:
    r = 1 << ((x.bit_length() + 2) // 3)
    while True:
        s = (2 * r + x // (r * r)) // 3
        if s >= r:
            return r
        r = s


def cubic_pair(n: int):
    # 4(w-1)^3 < (2w-1)(2(w-1)^2-1) < 4w^3 for w>=3.
    w = cubic_root(n // 4) + 1
    a, b = 2 * w - 1, 2 * (w - 1) ** 2 - 1
    return (a, b) if a * b == n else None


def parabolic_pair(n: int):
    r = isqrt(n + 2)
    if r * r != n + 2:
        return None
    # r=2h(h+1)-1; then 2r+3=(2h+1)^2.
    t = isqrt(2 * r + 3)
    if t * t != 2 * r + 3:
        return None
    h = (t - 1) // 2
    a, b = 2 * h * h - 1, 2 * (h + 1) ** 2 - 1
    return (a, b) if a * b == n and a > 1 else None


def check(bound: int):
    seen = {}
    collisions = []
    parabolic = 0
    h = 2
    while True:
        a, b = 2 * h * h - 1, 2 * (h + 1) ** 2 - 1
        n = a * b
        if n > bound:
            break
        cc = cubic_pair(n)
        if cc and cc != (a, b):
            collisions.append((n, (a, b), cc))
        parabolic += 1
        h += 1
    w = 5
    while True:
        x, y = (w - 1) ** 2, w * (w - 2) ** 2
        if (2 * x - 1) * (2 * y - 1) > bound:
            break
        while True:
            pair = (2 * x - 1, 2 * y - 1)
            n = pair[0] * pair[1]
            if n > bound:
                break
            for other in [seen.get(n), cubic_pair(n), parabolic_pair(n)]:
                if other and other != pair:
                    collisions.append((n, pair, other))
            seen[n] = pair
            x, y = y, (w - 2) * y - x + 2
        w += 1
    return dict(limit=bound, parabolic=parabolic, sparse=len(seen),
                max_sparse_parameter=w - 1, collisions=collisions)


if __name__ == "__main__":
    print(check(int(argv[1])))
