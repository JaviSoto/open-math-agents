"""Complete the two finite ranges in the complementary-squareclass theorem.

Only exact integers are used. Run as python3 crystal_complement_certificate.py.
"""

from math import isqrt


def row(q: int, r: int) -> tuple[int, int]:
    x, y = 0, 1
    for _ in range(r):
        x, y = y, (q - 2) * y - x + 2
    return 2 * x - 1, 2 * y - 1


def possible(q: int, r: int) -> bool:
    a, b = row(q, r)
    n, d = a * b, q - 4
    base = 4 * d * (n + 1)
    t = isqrt(base) + 1
    z = t * t - base
    if z % d or isqrt(z) ** 2 != z:
        return False
    Q = z // d
    if Q**3 > 4 * n:
        return False
    # Now Q is the only possible competing parameter. Its sum is determined.
    sum_disc = Q * (4 * (n + 1) + Q)
    delta = isqrt(sum_disc)
    if delta**2 != sum_disc or (delta + Q) % 2:
        return False
    total = (delta + Q) // 2
    pair_disc = total**2 - 4 * n
    return (pair_disc >= 0 and isqrt(pair_disc) ** 2 == pair_disc
            and (total + isqrt(pair_disc)) % 2 == 0)


def small() -> list[tuple[int, int]]:
    pairs = []
    for q in range(5, 32):
        r = 2
        while True:
            a, b = row(q, r)
            n = a * b
            if (q < 11 and n >= 64 * q**21) or (q >= 11 and 4096 * n >= q**15):
                break
            pairs.append((q, r))
            r += 1
    return pairs


def large() -> list[tuple[int, int]]:
    return [(d+4, r) for r in range(2, 8)
            for d in range(28, 4 * (4*r-1)**2 + 1)
            if (4 * (4*r-1)**2) % d == 0]


if __name__ == "__main__":
    for name, rows in (("small", small()), ("large", large())):
        found = [(q, r) for q, r in rows if possible(q, r)]
        print(f"{name}: {len(rows)} possible rows; candidates after exact tests: {found}")
        assert not found
