"""Reconcile direct factorization, the Python recurrence, and the wide search.

Usage: python3 crystal_search_crosscheck.py /tmp/crystal-wide
This uses only the standard library and the adjacent crystal_search.py.
"""

from math import isqrt
from pathlib import Path
import re
import subprocess
import sys

from crystal_search import check


def divisor_pairs(limit: int) -> set[tuple[int, int, int]]:
    return {
        (a * b, a, b)
        for a in range(3, isqrt(limit) + 1, 2)
        for b in range(a, limit // a + 1, 2)
        if (a + b) ** 2 % ((a + 1) * (b + 1)) == 0
    }


def recurrence_pairs(limit: int) -> set[tuple[int, int, int]]:
    pairs = {(35, 5, 7)} if limit >= 35 else set()
    q = 4
    while True:
        x, y = q, (q - 1) ** 2
        if (2 * x - 1) * (2 * y - 1) > limit:
            break
        while (2 * x - 1) * (2 * y - 1) <= limit:
            a, b = 2 * x - 1, 2 * y - 1
            pairs.add((a * b, a, b))
            x, y = y, (q - 2) * y - x + 2
        q += 1
    return pairs


def compare(executable: Path, exponent: int) -> None:
    exact = check(10**exponent)
    run = subprocess.run(
        [executable, str(exponent)], check=True, capture_output=True, text=True
    ).stdout.strip()
    fields = {k: int(v) for k, v in re.findall(r"(\w+)=(\d+)(?: |$)", run)}
    assert fields["parabolic"] == exact["parabolic"], (run, exact)
    assert fields["quintic"] + fields["deeper"] == exact["sparse"], (run, exact)
    assert fields["collisions"] == len(exact["collisions"]) == 0, (run, exact)
    print(run)


if __name__ == "__main__":
    for bound in (100, 1000, 10000, 100000, 1000000):
        brute = divisor_pairs(bound)
        generated = recurrence_pairs(bound)
        assert brute == generated, sorted(brute ^ generated)[:10]
        assert len({n for n, _, _ in brute}) == len(brute)
        print(f"bound={bound}: divisor search and recurrence agree on all {len(brute)} pairs")
    for power in (2, 4, 5, 8, 12, 16, 20):
        compare(Path(sys.argv[1]).resolve(), power)
