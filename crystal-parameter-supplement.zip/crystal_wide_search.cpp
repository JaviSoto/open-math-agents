// Independent full search through 10^e, 2 <= e <= 38.
// Build: clang++ -O3 -std=c++17 crystal_wide_search.cpp -o /tmp/crystal-wide
// Run: /tmp/crystal-wide 38
// The only mathematical input is the recurrence classification of Abrate et al.;
// no elliptic curve point tables or heuristic root tests are used.
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <map>
#include <string>
#include <vector>

using Wide = __uint128_t;
using Word = uint64_t;
struct Pair { Wide a, b; };

std::string decimal(Wide n) {
    std::string s;
    do { s += char('0' + n % 10); n /= 10; } while (n);
    std::reverse(s.begin(), s.end());
    return s;
}
Pair cubic(Wide w) { return {2*w-1, 2*(w-1)*(w-1)-1}; }
Pair parabolic(Wide h) { return {2*h*h-1, 2*(h+1)*(h+1)-1}; }
Pair quintic(Wide w) { return {2*(w-1)*(w-1)-1, 2*w*(w-2)*(w-2)-1}; }
bool within(Pair e, Wide limit) { return e.b <= limit / e.a; }

template<class Family> Word last(Word minimum, Wide limit, Family family) {
    Word hi = minimum;
    while (within(family(hi), limit)) hi *= 2;
    Word lo = minimum-1;
    while (hi-lo>1) {
        Word mid = lo+(hi-lo)/2;
        if (within(family(mid),limit)) lo=mid; else hi=mid;
    }
    return lo;
}
Word square_root(Wide n) {
    Word t = static_cast<Word>(std::sqrt(static_cast<double>(n)));
    while (Wide(t)*t>n) --t;
    while (Wide(t+1)*(t+1)<=n) ++t;
    return t;
}
Wide cube(Wide x) { return x*x*x; }
Pair cubic_match(Wide n) {
    Wide c = static_cast<Word>(std::cbrt(static_cast<double>(n/4)));
    while (cube(c)>n/4) --c;
    while (cube(c+1)<=n/4) ++c;
    // Cubic(w)/4 is strictly between (w-1)^3 and w^3.
    return cubic(c+1);
}
Pair parabolic_match(Wide n) {
    Word t=square_root(n+2);
    if (Wide(t)*t!=n+2) return {0,0};
    Word s=square_root(2*Wide(t)+3);
    if (Wide(s)*s!=2*Wide(t)+3 || s<5 || !(s%2)) return {0,0};
    return parabolic((s-1)/2);
}

// Every possible equality survives every prime: a failed residue test
// proves that the two products differ. The bit masks test 64 inputs at once.
struct Masks {
    static constexpr std::array<unsigned,16> primes{
        7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67
    };
    std::array<std::array<Word,67>,primes.size()> masks{};
    template<class From, class Into> Masks(From from, Into into) {
        for(size_t k=0;k<primes.size();++k) {
            unsigned p=primes[k]; bool image[67]{};
            // Lift input away from 0 and 1 as formulas use unsigned subtraction.
            auto residue=[p](auto f,unsigned x) {
                Pair b=f(Wide(x)+2*p); return unsigned(b.a*b.b%p);
            };
            for(unsigned r=0;r<p;++r) image[residue(into,r)]=true;
            for(unsigned r=0;r<p;++r)
                for(unsigned i=0;i<64;++i)
                    if(image[residue(from,r+i)]) masks[k][r]|=Word(1)<<i;
        }
    }
    template<class Test> void scan(Word lo,Word hi,Test test) const {
        std::array<unsigned,primes.size()> positions{};
        for(size_t k=0;k<primes.size();++k) positions[k]=lo%primes[k];
        for(Word base=lo;base<=hi;base+=64) {
            Word mask=~Word(0);
            for(size_t k=0;k<primes.size();++k) {
                mask &= masks[k][positions[k]];
                positions[k]+=(64%primes[k]);
                if(positions[k]>=primes[k]) positions[k]-=primes[k];
            }
            while(mask) {
                Word value=base+__builtin_ctzll(mask);
                if(value<=hi) test(value);
                mask&=mask-1;
            }
        }
    }
};

int main(int argc,char **argv) {
    if(argc!=2) return 2;
    int exponent=std::stoi(argv[1]);
    if(exponent<2 || exponent>38) return 2;
    Wide limit=1;
    for(int i=0;i<exponent;++i) limit*=10;
    Word lastP=last(2,limit,parabolic), lastQ=last(5,limit,quintic);
    size_t collisions=0, pcCandidates=0, qcCandidates=0, qpCandidates=0;
    bool recoveredCommonBase=false;
    auto compare=[&](Pair e,Pair other) {
        if(other.a && e.a*e.b==other.a*other.b && e.a!=other.a) {
            ++collisions;
            std::cout<<"collision "<<decimal(e.a*e.b)<<": "<<decimal(e.a)<<" "
                     <<decimal(e.b)<<" vs "<<decimal(other.a)<<" "<<decimal(other.b)<<"\n";
        }
    };
    Masks(parabolic,cubic).scan(2,lastP,[&](Word i) {
        ++pcCandidates;
        Pair e=parabolic(i), other=cubic_match(e.a*e.b);
        if(i==2 && e.a==other.a && e.b==other.b) recoveredCommonBase=true;
        compare(e,other);
    });
    if(lastP>=2 && !recoveredCommonBase) return 3;
    Masks(quintic,cubic).scan(5,lastQ,[&](Word i) {
        ++qcCandidates;
        Pair e=quintic(i); compare(e,cubic_match(e.a*e.b));
    });
    Masks(quintic,parabolic).scan(5,lastQ,[&](Word i) {
        ++qpCandidates;
        Pair e=quintic(i); compare(e,parabolic_match(e.a*e.b));
    });
    // The cubic, quartic and quintic families each strictly increase. Only
    // the higher rows need storage; all cross-family checks are exact.
    std::map<Wide,Pair> deep; size_t deepOccurrences=0;
    for(Word w=5;;++w) {
        Pair row=quintic(w);
        Wide x=(row.b+1)/2, y=(w-2)*x-(row.a+1)/2+2;
        if(!within({2*x-1,2*y-1},limit)) break; // first deep row grows in w
        for(Pair e={2*x-1,2*y-1};within(e,limit);e={2*x-1,2*y-1}) {
            Wide n=e.a*e.b;
            ++deepOccurrences;
            auto ins=deep.emplace(n,e);
            if(!ins.second) compare(e,ins.first->second);
            compare(e,cubic_match(n));
            compare(e,parabolic_match(n));
            Word q=last(5,n,quintic);
            if(q>=5) compare(e,quintic(q));
            Wide z=(w-2)*y-x+2; x=y; y=z;
        }
    }
    std::cout<<"bound=10^"<<exponent<<" parabolic="<<(lastP-1)
             <<" quintic="<<(lastQ-4)<<" deeper="<<deepOccurrences
             <<" exact-PC/QC/QP="<<pcCandidates<<"/"<<qcCandidates<<"/"<<qpCandidates
             <<" common-base="<<recoveredCommonBase<<" collisions="<<collisions<<"\n";
    return collisions!=0;
}
