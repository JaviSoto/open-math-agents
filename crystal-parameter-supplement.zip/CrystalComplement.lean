import FormalConjectures.Arxiv.«1601.03081».UniqueCrystalComponents

/-! Algebra and the quantitative approximation for complementary
parameter squareclasses in a prospective crystal collision. -/
namespace OMA.CrystalComplement

/-- If dQ is a square and Q is a second parameter, then d times the
square root appearing in its comparison with the first parameter is integral. -/
theorem integer_companion {n S Q d A : ℕ} (hQ : 0<Q) (hle : Q≤2*S)
    (e : S^2=Q*(n+1+S)) (sq : d*Q=A^2) :
    ∃ v : ℕ, v^2=d^3*(4*(n+1)+Q) := by
  let m := 2*S-Q
  have mdef : m+Q=2*S := by dsimp [m]; omega
  have msq : m^2=Q*(4*(n+1)+Q) := by
    have a := congrArg (fun t : ℕ => t^2) mdef
    have b := congrArg (fun t : ℕ => t*(2*Q)) mdef
    nlinarith only [e,a,b]
  have eq : (A*m)^2=Q^2*(d*(4*(n+1)+Q)) := by
    rw [mul_pow, ←sq, msq]; ring
  have dvdSq : Q^2 ∣ (A*m)^2 := ⟨_,eq⟩
  obtain ⟨t,ht⟩ := (Nat.pow_dvd_pow_iff (by decide : 2≠0)).mp dvdSq
  rw [ht,mul_pow] at eq
  have tsq := Nat.eq_of_mul_eq_mul_left (pow_pos hQ 2) eq
  exact ⟨d*t,by rw [mul_pow,tsq]; ring⟩

/-- The exact rationalized identity, valid for any positive real data
satisfying the crystal component and difference equations. -/
theorem pell {q d n S D : ℝ} (hq : 0<q) (hd : 0<d) (hn : 0≤n)
    (de : d=q-4) (es : S^2=q*(n+1+S)) (ed : D^2=S^2-4*n)
    (hs : q≤2*S) :
    (d*Real.sqrt (d*(4*(n+1)+q))+q*Real.sqrt (q*d))^2
      = (2*d*D)^2+64*d := by
  let U := d*Real.sqrt (d*(4*(n+1)+q))
  let R := Real.sqrt (q*d)
  have rs : R^2=q*d := Real.sq_sqrt (by positivity)
  have us : U^2=d^3*(4*(n+1)+q) := by
    dsimp [U]; rw [mul_pow,Real.sq_sqrt (by positivity)]; ring
  have e : (2*S-q)^2=q*(4*(n+1)+q) := by nlinarith only [es]
  have ueq : q*U=d*R*(2*S-q) := by
    have sq : (q*U)^2=(d*R*(2*S-q))^2 := by
      rw [mul_pow q U,mul_pow (d*R) (2*S-q),mul_pow d R,rs,us,e]; ring
    apply (sq_eq_sq₀ (by dsimp [U]; positivity) (mul_nonneg
      (by dsimp [R]; positivity) (by linarith))).mp sq
  have norm : (d*S+2*q)^2-q*d*D^2=16*q := by
    rw [de]
    linear_combination -q*(q-4)*ed -4*(q-4)*es
  have sum : q*(U+q*R)=2*R*(d*S+2*q) := by
    calc
      _=d*R*(2*S-q)+q*q*R := by linear_combination ueq
      _=_ := by rw [de]; ring
  have squared := congrArg (fun x : ℝ => x^2) sum
  change (U+q*R)^2=(2*d*D)^2+64*d
  apply (mul_left_cancel₀ (pow_ne_zero 2 hq.ne') :
    q^2 * _ = q^2 * _ → _)
  calc
    q^2*(U+q*R)^2 = (2*R*(d*S+2*q))^2 := by simpa [mul_pow] using squared
    _ = 4*(q*d)*(q*d*D^2+16*q) := by
      rw [mul_pow,mul_pow,rs,show (d*S+2*q)^2=q*d*D^2+16*q by linarith]
      ring
    _ = _ := by ring

end OMA.CrystalComplement
