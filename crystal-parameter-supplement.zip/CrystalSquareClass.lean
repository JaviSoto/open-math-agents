import FormalConjectures.Arxiv.«1601.03081».UniqueCrystalComponents

/-! An independent exclusion on the full crystal-uniqueness question:
two distinct decompositions cannot have parameters in the same square class. -/

namespace OMA.CrystalSquareClass
open Arxiv.«1601.03081»

/- Given the sorted half-components x,y, Vieta gives a positive integer
z with yz=(x-1)^2. Hence y≤(x-1)^2 and the parameter is at most x. -/
private theorem half_bound {x y q : ℤ} (hx : 1<x) (hy : x≤y)
    (e : (x+y-1)^2=q*x*y) : q≤x := by
  let z := (q-2)*x+2-y
  have f : y*z=(x-1)^2 := by dsimp [z]; nlinarith only [e]
  have hz : 0<z := by
    have p : 0<y*z := by rw [f]; exact sq_pos_of_pos (by omega)
    exact pos_of_mul_pos_right p (by omega)
  have cap : y≤(x-1)^2 := by
    rw [← f]
    exact le_mul_of_one_le_right (by omega) (by omega)
  have diff := mul_nonneg (show 0≤y-1 by omega) (sub_nonneg.mpr cap)
  have v : q*(x*y)≤x*(x*y) := by nlinarith only [e,diff]
  exact le_of_mul_le_mul_right v (mul_pos (by omega) (by omega))

theorem size {n a b q : ℕ} (h : IsCrystalWithComponents n a b) (ord : a≤b)
    (eq : (a+b)^2=q*((a+1)*(b+1))) : q^2 ≤ a+b := by
  obtain ⟨odd,ha,hb,prod,_⟩ := h
  obtain ⟨u, hu⟩ := Nat.Odd.of_mul_left (prod ▸ odd)
  obtain ⟨v, hv⟩ := Nat.Odd.of_mul_right (prod ▸ odd)
  have ez : ((a:ℤ)+b)^2=(q:ℤ)*((a+1)*(b+1)) := by exact_mod_cast eq
  have hu' : (a:ℤ)=2*u+1 := by exact_mod_cast hu
  have hv' : (b:ℤ)=2*v+1 := by exact_mod_cast hv
  have e : ((u:ℤ)+1+(v+1)-1)^2=(q:ℤ)*(u+1)*(v+1) := by
    rw [hu',hv'] at ez
    nlinarith only [ez]
  have hq := half_bound (x:=(u:ℤ)+1) (y:=(v:ℤ)+1) (by omega) (by omega) e
  have qa : 2*q≤a+1 := by omega
  have qb : a+b≤2*(b+1) := by omega
  have mult := Nat.mul_le_mul qa qb
  have ord' : q*(a+b)≤(a+1)*(b+1) := by nlinarith only [mult]
  have v' := Nat.mul_le_mul_left q ord'
  have v'' : q^2*(a+b)≤(a+b)*(a+b) := by nlinarith only [v',eq]
  exact Nat.le_of_mul_le_mul_right v'' (by omega)

private theorem almost_square {n a b s A : ℕ} (h : IsCrystalWithComponents n a b) (ord : a≤b)
    (hs : 0<s) (hA : 0<A) (eq : (a+b)^2=(s*A^2)*((a+1)*(b+1))) :
    ∃ U : ℕ, U^2=4*s*(n+1)+(s*A)^2 ∧ (s*A)^2≤U := by
  have big := size h ord eq
  let S := a+b
  have dvd' : A^2 ∣ S^2 := by
    use s*((a+1)*(b+1))
    dsimp [S]; rw [eq]; ring
  obtain ⟨t,ht⟩ := (Nat.pow_dvd_pow_iff (by decide : 2≠0)).mp dvd'
  have eq' : A^2*t^2=A^2*(s*((a+1)*(b+1))) := by
    calc
      A^2*t^2 = S^2 := by rw [ht]; ring
      _ = _ := by dsimp [S]; rw [eq]; ring
  have ts := Nat.eq_of_mul_eq_mul_left (pow_pos hA 2) eq'
  have lo : (s*A)^2 ≤ t := by
    have bnd : A*((s*A)^2*A)≤A*t := by rw [←ht]; dsimp [S]; nlinarith only [big]
    have l := Nat.le_of_mul_le_mul_left bnd hA
    exact (Nat.le_mul_of_pos_right _ hA).trans l
  have sa : 0<s*A := Nat.mul_pos hs hA
  have sa' : s*A≤t := by
    apply le_trans _ lo
    simpa [pow_two] using Nat.le_mul_of_pos_right (s*A) sa
  let U := 2*t-s*A
  have ud : U+s*A=2*t := by dsimp [U]; omega
  refine ⟨U,?_,by omega⟩
  have p := h.2.2.2.1
  have ds : (a+1)*(b+1)=n+1+A*t := by rw [←ht]; dsimp [S]; nlinarith only [p]
  rw [ds] at ts
  have sq := congrArg (fun z : ℕ => z^2) ud
  have mul' := congrArg (fun z : ℕ => z*(2*s*A)) ud
  nlinarith only [sq,mul',ts]

private theorem square_gap {u v : ℕ} (h : u<v) : u^2+u+v≤v^2 := by
  obtain ⟨k,rfl⟩ := Nat.exists_eq_add_of_le h.le
  cases k with
  | zero => omega
  | succ k => ring_nf; omega

private theorem floor_unique {u v a b N : ℕ}
    (hu : u^2=N+a) (hv : v^2=N+b) (ha : a≤u) (hb : b≤v) :
    0<N → u=v := by
  intro positive
  have up : 0<u := by by_contra! z; simp [Nat.eq_zero_of_le_zero z] at hu; omega
  have vp : 0<v := by by_contra! z; simp [Nat.eq_zero_of_le_zero z] at hv; omega
  rcases lt_trichotomy u v with h|h|h
  · have := square_gap h
    omega
  · exact h
  · have := square_gap h
    omega

theorem same_class {n a b c e s A B : ℕ}
    (h : IsCrystalWithComponents n a b) (ab : a≤b)
    (H : IsCrystalWithComponents n c e) (ce : c≤e)
    (hs : 0<s) (hA : 0<A) (hB : 0<B)
    (eq : (a+b)^2=(s*A^2)*((a+1)*(b+1)))
    (EQ : (c+e)^2=(s*B^2)*((c+1)*(e+1))) : a=c ∧ b=e := by
  obtain ⟨U,hu,lu⟩ := almost_square h ab hs hA eq
  obtain ⟨V,hv,lv⟩ := almost_square H ce hs hB EQ
  have uv := floor_unique hu hv lu lv (by positivity)
  subst V
  have sy : (s*A)^2=(s*B)^2 := by omega
  have : A=B := Nat.eq_of_mul_eq_mul_left hs (Nat.pow_left_injective (by decide : 2≠0) sy)
  subst B
  have p := h.2.2.2.1
  have P := H.2.2.2.1
  let q := s*A^2
  let S := a+b
  let T := c+e
  have es : S^2=q*(n+1+S) := by dsimp [q,S]; rw [eq]; congr 1; nlinarith only [p]
  have et : T^2=q*(n+1+T) := by dsimp [q,T]; rw [EQ]; congr 1; nlinarith only [P]
  have l := size h ab eq
  have L := size H ce EQ
  have qpos : 0<q := by dsimp [q]; positivity
  have qle : q≤S := (by simpa [pow_two] using (Nat.le_mul_of_pos_right q qpos) : q≤q^2).trans l
  have tpos : 0<T := by dsimp [T]; have := H.2.1; omega
  have de : ((S:ℤ)-T)*(S+T-q)=0 := by
    have es' : (S:ℤ)^2=q*(n+1+S) := by exact_mod_cast es
    have et' : (T:ℤ)^2=q*(n+1+T) := by exact_mod_cast et
    nlinarith only [es',et']
  rcases mul_eq_zero.mp de with zero|zero
  · have sum : a+b=c+e := by change S=T; omega
    have f : ((a:ℤ)-c)*(a-e)=0 := by
      have sZ : (a:ℤ)+b=c+e := by exact_mod_cast sum
      have pZ : (a:ℤ)*b=c*e := by exact_mod_cast p.symm.trans P
      nlinarith only [pZ,congrArg (fun z : ℤ => (a:ℤ)*z) sZ]
    rcases mul_eq_zero.mp f with hh|hh <;> omega
  · omega

end OMA.CrystalSquareClass
