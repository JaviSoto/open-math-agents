import DyadicEuler245212
import DyadicLeast245212

/-! Euler products on separated supports. In particular, a nontrivial
odd solution must contain two odd primes less than a factor of two apart. -/
namespace OMA.SeparatedPrimeSupport245212
open Nat Finset ArithmeticFunction OMA.Smooth245212 OMA.OddFaces245212
open scoped ArithmeticFunction.sigma

theorem euler {k m : ℕ} (odd : Odd m) (many : m.primeFactors.Nonempty)
    (hit : OeisA245212.a (2^k*m)=(σ 1 (2^k*m):ℤ)) :
    2≤X 2 (some k)*(∏q∈m.primeFactors,limitX q) := by
  let F:=m.primeFactors
  let p:=F.orderEmbOfFin rfl
  let e (i : Fin F.card):=m.factorization (p i)
  have mem (i : Fin F.card) : p i∈m.primeFactors:=orderEmbOfFin_mem F rfl i
  have hp (i) := prime_of_mem_primeFactors (mem i)
  have po (i) := Nat.coprime_two_left.mp ((Nat.coprime_two_left.mpr odd).of_dvd_right
    (dvd_of_mem_primeFactors (mem i)))
  have ep (i) := (hp i).factorization_pos_of_dvd odd.pos.ne' (dvd_of_mem_primeFactors (mem i))
  have repr : total p e=m:=(Fintype.prod_equiv (F.orderIsoOfFin rfl).toEquiv _
    (fun j : F=>j.val^(m.factorization j.val)) (fun _=>rfl)).trans
    (Nat.prod_primeFactors_coe_pow_factorization odd.pos.ne').symm
  have i : Fin F.card:=⟨0,card_pos.mpr many⟩
  have cap:=OMA.DyadicEuler245212.cap_needed_at_two k p e (fun j=>(hp j).one_lt) i (ep i)
    (OMA.BoundedAtom245212.normalized_dyadic k p e hp po p.injective (by rwa [repr]))
  have prod:=(Fintype.prod_equiv (F.orderIsoOfFin rfl).toEquiv (fun i=>limitX (p i))
    (fun j : F=>limitX j.val) (fun _=>rfl)).trans (F.prod_coe_sort limitX)
  rwa [prod] at cap

theorem telescope (s : Finset ℕ) (B : ℕ→ℚ) (non : s.Nonempty)
    (positive : ∀p∈s,0<limitX p)
    (last : ∀p∈s,limitX p<B p)
    (step : ∀p∈s,∀q∈s,p<q → limitX p*B q≤B p) :
    ∃p∈s,(∀q∈s,p≤q) ∧ (∏q∈s,limitX q)<B p := by
  induction s using Finset.induction_on_min with
  | empty=>simp at non
  | insert p t less ih=>
    have fresh : p∉t:=fun h=>(less p h).false
    have here:=mem_insert_self p t
    have sub : t⊆insert p t:=subset_insert _ _
    refine ⟨p,here,?_,?_⟩
    · intro q h;rcases mem_insert.mp h with rfl|h
      · exact le_rfl
      · exact (less q h).le
    · rw [prod_insert fresh]
      by_cases nt : t.Nonempty
      · obtain ⟨q,hq,_,bound⟩:=ih nt (fun r h=>positive r (sub h))
          (fun r h=>last r (sub h)) (fun r h u hu=>step r (sub h) u (sub hu))
        exact (mul_lt_mul_of_pos_left bound (positive p here)).trans_le (step p here q (sub hq) (less q hq))
      · simpa [Finset.not_nonempty_iff_eq_empty.mp nt] using last p here

theorem ratio {p : ℕ} (hp : 1<p) : limitX p=(p:ℚ)/(p-1) := by
  have gt : (1:ℚ)<p:=by exact_mod_cast hp
  dsimp [limitX,X,Y];field_simp [ne_of_gt (sub_pos.mpr gt)];ring

def envelope (p : ℕ) : ℚ := ((p:ℚ)+1)/(p-1)

theorem double_bound {s : Finset ℕ} (non : s.Nonempty) (pr : ∀p∈s,1<p)
    (sparse : ∀p∈s,∀q∈s,p<q → 2*p<q) :
    ∃p∈s,(∀q∈s,p≤q) ∧ (∏q∈s,limitX q)<envelope p := by
  apply telescope s envelope non
  · intro p hp;rw [ratio (pr p hp)]
    have gt : (1:ℚ)<p:=by exact_mod_cast pr p hp
    positivity
  · intro p hp;rw [ratio (pr p hp)]
    have gt : (1:ℚ)<p:=by exact_mod_cast pr p hp
    unfold envelope;exact div_lt_div_of_pos_right (by linarith) (by linarith)
  · intro p hp q hq pq
    rw [ratio (pr p hp)]
    have pg : (1:ℚ)<p:=by exact_mod_cast pr p hp
    have qg : (1:ℚ)<q:=by exact_mod_cast pr q hq
    have spaced : 2*(p:ℚ)+1≤q:=by exact_mod_cast sparse p hp q hq pq
    unfold envelope
    field_simp [sub_pos.mpr pg,sub_pos.mpr qg]
    nlinarith only [spaced]

theorem odd_original {n : ℕ} (odd : Odd n) (large : 1<n)
    (hit : OeisA245212.a n=(σ 1 n:ℤ)) :
    ∃p∈n.primeFactors,∃q∈n.primeFactors,p<q ∧ q<2*p := by
  by_contra! separated
  have op p (mem : p∈n.primeFactors) : Odd p:=Nat.coprime_two_left.mp
    ((Nat.coprime_two_left.mpr odd).of_dvd_right (dvd_of_mem_primeFactors mem))
  have spaced p (hp : p∈n.primeFactors) q (hq : q∈n.primeFactors) (lt : p<q) : 2*p<q:=by
    have z:=separated p hp q hq lt
    obtain ⟨j,hj⟩:=op q hq;omega
  have non:=Nat.nonempty_primeFactors.mpr large
  obtain ⟨p,mp,_,bound⟩:=double_bound non (fun q hq=>(prime_of_mem_primeFactors hq).one_lt) spaced
  have lo:=euler (k:=0) odd non (by simpa using hit)
  have one : X 2 (some 0)=1:=by decide +kernel
  rw [one,one_mul] at lo
  have three : 3≤p:=by have :=(prime_of_mem_primeFactors mp).two_le;obtain ⟨j,hj⟩:=op p mp;omega
  have pg : (3:ℚ)≤p:=by exact_mod_cast three
  have ub : envelope p≤2:=(div_le_iff₀ (by linarith : 0<(p:ℚ)-1)).mpr (by linarith)
  exact (bound.trans_le ub).not_ge lo

#print axioms odd_original
end OMA.SeparatedPrimeSupport245212
