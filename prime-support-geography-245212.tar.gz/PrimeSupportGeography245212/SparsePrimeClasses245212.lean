import SeparatedPrimeSupport245212
import Mathlib.NumberTheory.Fermat

/-! All odd integers supported on Fermat primes, or on Mersenne primes,
obey the OEIS conjecture, without limiting the rank or exponents. For
even integers, the smallest prime in such a support bounds the dyadic exponent. -/
namespace OMA.SparsePrimeClasses245212
open Nat Finset ArithmeticFunction OMA.Smooth245212 OMA.OddFaces245212 OMA.SeparatedPrimeSupport245212
open scoped ArithmeticFunction.sigma

theorem dyadic {k : ℕ} : X 2 (some k)*((k:ℚ)+2)≤2*((k:ℚ)+1) := by
  have weight : W (2^k)=k*2^(k+1)+1:=by
    rw [w_pow Nat.prime_two]
    induction k with
    | zero=>norm_num
    | succ j ih=>rw [sum_range_succ _ (j+1),ih,pow_succ (2:ℕ) (j+1)];ring
  have h:=x_factor Nat.prime_two k
  rw [weight] at h
  push_cast at h
  rw [pow_succ] at h
  have bound : (k:ℚ)+2≤2*(2:ℚ)^k:=by
    have v:=Nat.lt_two_pow_self (n:=k+1)
    rw [pow_succ] at v
    exact_mod_cast (by omega : k+2≤2*2^k)
  apply (mul_le_mul_iff_left₀ (by positivity : 0<((k:ℚ)+1)*2^k)).mp
  nlinarith only [bound,congrArg (fun z:ℚ=>z*((k:ℚ)+2)) h]

theorem double {k m : ℕ} (odd : Odd m) (non : m.primeFactors.Nonempty)
    (hit : OeisA245212.a (2^k*m)=(σ 1 (2^k*m):ℤ))
    (spaced : ∀p∈m.primeFactors,∀q∈m.primeFactors,p<q → 2*p<q) :
    ∃p∈m.primeFactors,p≤2*k+1 := by
  obtain ⟨p,mem,_,cap⟩:=double_bound non (fun q hq=>(prime_of_mem_primeFactors hq).one_lt) spaced
  refine ⟨p,mem,?_⟩
  have pr:=prime_of_mem_primeFactors mem
  have od:=Nat.coprime_two_left.mp ((Nat.coprime_two_left.mpr odd).of_dvd_right (dvd_of_mem_primeFactors mem))
  obtain ⟨u,hu⟩:=od
  by_contra! no
  have big : (2:ℚ)*k+3≤p:=by exact_mod_cast (by omega : 2*k+3≤p)
  have pp : (1:ℚ)<p:=by exact_mod_cast pr.one_lt
  have xpos : 0<X 2 (some k):=lt_of_lt_of_le (by decide : (0:ℚ)<1)
    (by dsimp [X];norm_num;linarith only [y_one (by decide : 1<2) (some k)])
  have strict:=(euler odd non hit).trans_lt (mul_lt_mul_of_pos_left cap xpos)
  change 2<X 2 (some k)*(((p:ℚ)+1)/(p-1)) at strict
  rw [←mul_div_assoc] at strict
  have less:=(lt_div_iff₀ (sub_pos.mpr pp)).mp strict
  have d:=dyadic (k:=k)
  nlinarith only [mul_lt_mul_of_pos_right less (by positivity : 0<(k:ℚ)+2),
    mul_le_mul_of_nonneg_right d (by positivity : 0≤(p:ℚ)+1),big]

def squareEnvelope (p : ℕ) : ℚ := ((p:ℚ)-1)/(p-2)

theorem squares {k m : ℕ} (odd : Odd m) (non : m.primeFactors.Nonempty)
    (hit : OeisA245212.a (2^k*m)=(σ 1 (2^k*m):ℤ))
    (spaced : ∀p∈m.primeFactors,∀q∈m.primeFactors,p<q → (p-1)^2+1≤q) :
    ∃p∈m.primeFactors,p≤k+2 := by
  have gt p (mem : p∈m.primeFactors) : (2:ℚ)<p:=by
    have od:=Nat.coprime_two_left.mp ((Nat.coprime_two_left.mpr odd).of_dvd_right (dvd_of_mem_primeFactors mem))
    obtain ⟨u,hu⟩:=od
    have pr:=(prime_of_mem_primeFactors mem).two_le
    exact_mod_cast (by omega : 2<p)
  obtain ⟨p,mem,_,cap⟩:=telescope m.primeFactors squareEnvelope non
    (fun p hp=>by rw [ratio (prime_of_mem_primeFactors hp).one_lt];have :=gt p hp;exact div_pos (by linarith) (by linarith))
    (fun p hp=>by
      rw [ratio (prime_of_mem_primeFactors hp).one_lt]
      have g:=gt p hp
      unfold squareEnvelope
      rw [div_lt_div_iff₀ (by linarith) (by linarith)]
      nlinarith)
    (fun p hp q hq pq=>by
      rw [ratio (prime_of_mem_primeFactors hp).one_lt]
      have pg:=gt p hp
      have qg:=gt q hq
      have h:=spaced p hp q hq pq
      have cast : ((p:ℚ)-1)^2+1≤q:=by
        simpa only [Nat.cast_add,Nat.cast_one,Nat.cast_pow,Nat.cast_sub (prime_of_mem_primeFactors hp).one_le] using
          (show (((p-1)^2+1:ℕ):ℚ)≤q by exact_mod_cast h)
      unfold squareEnvelope
      field_simp [show 0<(p:ℚ)-2 by linarith,show 0<(p:ℚ)-1 by linarith,show 0<(q:ℚ)-2 by linarith]
      nlinarith only [cast])
  refine ⟨p,mem,?_⟩
  have g:=gt p mem
  by_contra! no
  have big : (k:ℚ)+3≤p:=by exact_mod_cast (by omega : k+3≤p)
  have xpos : 0<X 2 (some k):=lt_of_lt_of_le (by decide : (0:ℚ)<1)
    (by dsimp [X];norm_num;linarith only [y_one (by decide : 1<2) (some k)])
  have strict:=(euler odd non hit).trans_lt (mul_lt_mul_of_pos_left cap xpos)
  change 2<X 2 (some k)*(((p:ℚ)-1)/(p-2)) at strict
  rw [←mul_div_assoc] at strict
  have less:=(lt_div_iff₀ (by linarith : 0<(p:ℚ)-2)).mp strict
  have d:=dyadic (k:=k)
  nlinarith only [mul_lt_mul_of_pos_right less (by positivity : 0<(k:ℚ)+2),
    mul_le_mul_of_nonneg_right d (by linarith : 0≤(p:ℚ)-1),big]

theorem mersenne {k m : ℕ} (odd : Odd m) (non : m.primeFactors.Nonempty)
    (hit : OeisA245212.a (2^k*m)=(σ 1 (2^k*m):ℤ))
    (shape : ∀p∈m.primeFactors,∃u : ℕ,p+1=2^u) : ∃p∈m.primeFactors,p≤2*k+1 := by
  apply double odd non hit
  intro p hp q hq order
  obtain ⟨i,hi⟩:=shape p hp
  obtain ⟨j,hj⟩:=shape q hq
  have ij : i<j:=Nat.lt_of_not_ge (fun le=>by have :=Nat.pow_le_pow_right (by decide : 0<2) le;omega)
  have b:=Nat.pow_le_pow_right (by decide : 0<2) (show i+1≤j by omega)
  rw [pow_succ] at b;omega

theorem fermat {k m : ℕ} (odd : Odd m) (non : m.primeFactors.Nonempty)
    (hit : OeisA245212.a (2^k*m)=(σ 1 (2^k*m):ℤ))
    (shape : ∀p∈m.primeFactors,∃u : ℕ,p=Nat.fermatNumber u) : ∃p∈m.primeFactors,p≤k+2 := by
  apply squares odd non hit
  intro p hp q hq order
  obtain ⟨i,rfl⟩:=shape p hp
  obtain ⟨j,rfl⟩:=shape q hq
  have ij:=Nat.fermatNumber_strictMono.lt_iff_lt.mp order
  have b:=Nat.fermatNumber_strictMono.monotone (show i+1≤j by omega)
  have id : (Nat.fermatNumber i-1)^2+1=Nat.fermatNumber (i+1):=by
    simp [Nat.fermatNumber,pow_succ (2:ℕ) i,pow_mul]
  rwa [id]

#print axioms mersenne
#print axioms fermat
end OMA.SparsePrimeClasses245212
