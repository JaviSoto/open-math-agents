import SparsePrimeClasses245212

/-! Every solution with an odd prime divisor has many prime factors in one
dyadic interval, even when the total number of factors is unrestricted. -/
namespace OMA.PrimeDensity245212
open Nat Finset ArithmeticFunction OMA.Smooth245212 OMA.OddFaces245212
open OMA.SeparatedPrimeSupport245212
open scoped ArithmeticFunction.sigma

def reciprocal (p : ℕ) : ℚ := 1/(p:ℚ)
def remaining (s : Finset ℕ) : ℚ := ∏p∈s,(1-reciprocal p)

private theorem fraction (s : Finset ℕ) (large : ∀p∈s,1<p) :
    remaining s*(∏p∈s,limitX p)=1 ∧ 1-remaining s≤∑p∈s,reciprocal p := by
  induction s using Finset.induction_on with
  | empty=>simp [remaining]
  | @insert p s fresh ih=>
    have hp:=large p (mem_insert_self _ _)
    have pr : (1:ℚ)<p:=by exact_mod_cast hp
    have all (q) (hq : q∈s):=large q (mem_insert_of_mem hq)
    obtain ⟨product,bound⟩:=ih all
    have between (q : ℕ) (hq : 1<q) : 0≤1-reciprocal q ∧ 1-reciprocal q≤1:=by
      have qr : (1:ℚ)<q:=by exact_mod_cast hq
      dsimp [reciprocal];constructor
      · exact sub_nonneg.mpr ((div_le_one (by linarith)).mpr qr.le)
      · have : 0≤1/(q:ℚ):=by positivity
        linarith
    have rem : remaining s≤1:=prod_le_one (fun q h=>(between q (all q h)).1) (fun q h=>(between q (all q h)).2)
    have ident : (1-reciprocal p)*limitX p=1:=by
      rw [ratio hp];dsimp [reciprocal];field_simp [ne_of_gt (sub_pos.mpr pr)]
    have ins : remaining (insert p s)=(1-reciprocal p)*remaining s:=by simp [remaining,fresh]
    rw [ins,prod_insert fresh,sum_insert fresh]
    exact ⟨by rw [mul_mul_mul_comm,ident,product,one_mul],
      by nlinarith only [bound,mul_nonneg (show 0≤reciprocal p by dsimp [reciprocal];positivity) (sub_nonneg.mpr rem)]⟩

theorem lower {k m : ℕ} (odd : Odd m) (non : m.primeFactors.Nonempty)
    (hit : OeisA245212.a (2^k*m)=(σ 1 (2^k*m):ℤ)) :
    1≤((k:ℚ)+2)*(∑p∈m.primeFactors,reciprocal p) := by
  let s:=m.primeFactors
  have hp p (mem : p∈s):=(prime_of_mem_primeFactors mem).one_lt
  obtain ⟨prod,bound⟩:=fraction s hp
  have pos : 0≤remaining s:=by
    apply prod_nonneg
    intro p mem
    have gt : (1:ℚ)<p:=by exact_mod_cast hp p mem
    exact sub_nonneg.mpr ((div_le_one (by linarith : 0<(p:ℚ))).mpr gt.le)
  have cap:=mul_le_mul_of_nonneg_right (euler odd non hit) pos
  change 2*remaining s≤X 2 (some k)*(∏p∈s,limitX p)*remaining s at cap
  rw [mul_assoc,mul_comm (∏p∈s,limitX p) (remaining s),prod,mul_one] at cap
  have dy:=OMA.SparsePrimeClasses245212.dyadic (k:=k)
  change 1≤((k:ℚ)+2)*_
  nlinarith only [dy,mul_le_mul_of_nonneg_right cap (by positivity : 0≤(k:ℚ)+2),
    mul_le_mul_of_nonneg_left bound (by positivity : 0≤(k:ℚ)+2)]

def block (s : Finset ℕ) (P j : ℕ) := s.filter fun p=>P*2^j≤p ∧ p<P*2^(j+1)
private def below (s : Finset ℕ) (P j : ℕ) := s.filter (·<P*2^j)

theorem crowded {s : Finset ℕ} {P k : ℕ} (pos : 0<P) (least : ∀p∈s,P≤p)
    (lo : 1≤((k:ℚ)+2)*(∑p∈s,reciprocal p)) : ∃j : ℕ,P<2*(k+2)*(block s P j).card := by
  by_contra! all
  have weighted j : ((k:ℚ)+2)*(2:ℚ)^(j+1)*(∑p∈block s P j,reciprocal p)≤1:=by
    let L:=P*2^j
    have lp : 0<L:=Nat.mul_pos pos (Nat.two_pow_pos j)
    have ub : (∑p∈block s P j,reciprocal p)≤(∑_p∈block s P j,(1:ℚ)/L):=by
      apply sum_le_sum
      intro p mem
      have h : L≤p:=(mem_filter.mp mem).2.1
      exact one_div_le_one_div_of_le (by exact_mod_cast lp) (by exact_mod_cast h)
    simp only [sum_const,nsmul_eq_mul] at ub
    have cast : 2*((k:ℚ)+2)*((block s P j).card:ℚ)≤P:=by exact_mod_cast all j
    have bh : (∑p∈block s P j,reciprocal p)*(L:ℚ)≤(block s P j).card := by
      apply (le_div_iff₀ (by exact_mod_cast lp : (0:ℚ)<L)).mp
      simpa only [←mul_div_assoc,mul_one] using ub
    dsimp only [L] at bh
    push_cast at bh
    apply (mul_le_mul_iff_left₀ (show (0:ℚ)<P by exact_mod_cast pos)).mp
    rw [pow_succ]
    nlinarith only [cast,mul_le_mul_of_nonneg_left bh (by positivity : 0≤2*((k:ℚ)+2))]
  have cumulative (j : ℕ) : ((k:ℚ)+2)*(2:ℚ)^j*(∑p∈below s P j,reciprocal p)≤2^j-1 := by
    induction j with
    | zero=>
      have emp : below s P 0=∅:=by
        apply Finset.eq_empty_iff_forall_notMem.mpr
        intro p mem
        have :=(mem_filter.mp mem).2
        exact (lt_irrefl p) ((by simpa using this : p<P).trans_le (least p (mem_filter.mp mem).1))
      simp [emp]
    | succ j ih=>
      have set : below s P (j+1)=below s P j ∪ block s P j:=by
        ext p
        simp only [below,block,mem_filter,mem_union]
        have inc : P*2^j≤P*2^(j+1):=Nat.mul_le_mul_left P (Nat.pow_le_pow_right (by decide : 0<2) (Nat.le_succ j))
        by_cases h : p∈s
        · simp only [h,true_and];omega
        · simp [h]
      have dis : Disjoint (below s P j) (block s P j):=by
        apply Finset.disjoint_left.mpr
        intro p small large
        exact (mem_filter.mp small).2.not_ge (mem_filter.mp large).2.1
      rw [set,sum_union dis]
      have b:=weighted j
      rw [pow_succ] at b ⊢
      nlinarith only [b,ih]
  let j:=s.sup id+1
  have eq : below s P j=s:=by
    apply filter_true_of_mem
    intro p mem
    have bound : p ≤ s.sup id:=le_sup (f:=id) mem
    have wide:=Nat.lt_two_pow_self (n:=j)
    have grow:=Nat.le_mul_of_pos_left (2^j) pos
    dsimp only [j] at *
    omega
  have upper:=cumulative j
  rw [eq] at upper
  nlinarith only [upper,mul_le_mul_of_nonneg_right lo (by positivity : (0:ℚ)≤2^j)]

theorem original {n P : ℕ} (pos : 0<n) (base : 0<P) (non : (n.primeFactors.erase 2).Nonempty)
    (least : ∀p∈n.primeFactors.erase 2,P≤p) (hit : OeisA245212.a n=(σ 1 n:ℤ)) :
    ∃j : ℕ,P<2*(n.factorization 2+2)*(block (n.primeFactors.erase 2) P j).card := by
  let m:=ordCompl[2] n
  have odd : Odd m:=Nat.coprime_two_left.mp (Nat.coprime_ordCompl prime_two pos.ne')
  have supp : m.primeFactors=n.primeFactors.erase 2:=by
    dsimp [m];rw [←Nat.support_factorization,Nat.factorization_ordCompl,Finsupp.support_erase,Nat.support_factorization]
  apply crowded base least
  rw [←supp]
  exact lower odd (supp ▸ non) (by simpa only [m,Nat.ordProj_mul_ordCompl_eq_self] using hit)

#print axioms original
end OMA.PrimeDensity245212
