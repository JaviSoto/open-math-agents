import PrimeDensity245212

/-! Odd inputs whose factors are all Mersenne primes or all Fermat primes. -/
namespace OMA.PrimeSupportGeography245212
open Nat Finset ArithmeticFunction OMA.SparsePrimeClasses245212
open scoped ArithmeticFunction.sigma

theorem odd_mersenne {n : ℕ} (odd : Odd n) (large : 1<n)
    (shape : ∀p∈n.primeFactors,∃u : ℕ,p+1=2^u) :
    OeisA245212.a n≠(σ 1 n:ℤ) := by
  intro hit
  obtain ⟨p,mem,small⟩:=mersenne (k:=0) odd (Nat.nonempty_primeFactors.mpr large)
    (by simpa using hit) shape
  have :=(prime_of_mem_primeFactors mem).two_le
  omega

theorem odd_fermat {n : ℕ} (odd : Odd n) (large : 1<n)
    (shape : ∀p∈n.primeFactors,∃u : ℕ,p=Nat.fermatNumber u) :
    OeisA245212.a n≠(σ 1 n:ℤ) := by
  intro hit
  obtain ⟨p,mem,small⟩:=fermat (k:=0) odd (Nat.nonempty_primeFactors.mpr large)
    (by simpa using hit) shape
  have :=(prime_of_mem_primeFactors mem).two_le
  obtain ⟨j,hj⟩:=Nat.coprime_two_left.mp ((Nat.coprime_two_left.mpr odd).of_dvd_right (dvd_of_mem_primeFactors mem))
  omega

#print axioms odd_mersenne
#print axioms odd_fermat
end OMA.PrimeSupportGeography245212
