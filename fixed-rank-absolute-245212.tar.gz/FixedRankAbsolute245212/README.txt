Kernel proof: OMA.FixedRankAbsolute245212.bounded_finite

From the compiled google-deepmind/formal-conjectures checkout at 9097e2f90e66d2f6244209cb1c07f7120d17ec53, run:
  lake env python3 /absolute/path/to/lean_source_bundle_245212.py --workers 4
One worker per file. Use --workers 1 on a smaller machine. No prebuilt research modules are required.
