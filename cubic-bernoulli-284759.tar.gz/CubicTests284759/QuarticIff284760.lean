import ThirdOrder284760

namespace OMA.QuarticIff284760
open Nat Finset
open private OMA.BernoulliScreen284760.integers OMA.BernoulliScreen284760.integral_iff
  OMA.BernoulliScreen284760.bernoulli_integral OMA.BernoulliScreen284760.p_bernoulli
  OMA.BernoulliScreen284760.scaled_terms from BernoulliScreen284760
open private OMA.ThirdOrder284760.inv_mem from ThirdOrder284760
open private Bernoulli.not_dvd_den_bernoulli_add_indicator Bernoulli.vonStaudtIndicator from Mathlib.NumberTheory.Bernoulli
private abbrev R (p:ℕ) [Fact p.Prime] := OMA.BernoulliScreen284760.integers p

private theorem nat_of_local {n s t:ℕ} (nn:0<n)
    (h:∀ p:ℕ, ∀ hp:p.Prime, p∣n → (s:ℚ)/(n:ℚ)^t∈@R p ⟨hp⟩) : n^t∣s := by
  let x:ℚ:=(s:ℚ)/(n:ℚ)^t
  have co:n.Coprime x.den:=Nat.coprime_of_dvd (fun p hp pn=>by
    let _ : Fact p.Prime:=⟨hp⟩
    exact (OMA.BernoulliScreen284760.integral_iff x).mp (h p hp pn))
  have zn:(n:ℚ)≠0:=by exact_mod_cast nn.ne'
  have id:(x.num:ℚ)/x.den=(s:ℚ)/(n:ℚ)^t:=Rat.num_div_den _
  have dn:(x.den:ℚ)≠0:=by exact_mod_cast x.den_ne_zero
  field_simp at id
  have eq:x.num*(n:ℤ)^t=(s:ℤ)*x.den:=by rw [mul_comm (s:ℤ)];exact_mod_cast id
  have val:=congrArg Int.natAbs eq
  simp only [Int.natAbs_mul,Int.natAbs_natCast,Int.natAbs_pow] at val
  have d:=dvd_mul_left (n^t) x.num.natAbs
  rw [val] at d;exact (co.pow_left _).dvd_of_dvd_mul_right d

private theorem quotient {p d:ℕ} [Fact p.Prime] (x:ℚ) (pos:0<d) (pd:p∣d)
    (dv:d∣x.num.natAbs) : x/(d:ℚ)∈R p := by
  have dn:(d:ℚ)≠0:=by exact_mod_cast pos.ne'
  have cp:¬p∣x.den := (Fact.out : p.Prime).coprime_iff_not_dvd.mp (x.reduced.of_dvd_left (pd.trans dv))
  obtain ⟨z,hz⟩:=Int.natCast_dvd.mpr dv
  have num:(x.num:ℚ)=(d:ℚ)*z:=by exact_mod_cast hz
  have id:x/(d:ℚ)=(z:ℚ)*(x.den:ℚ)⁻¹:=by nth_rw 1 [←Rat.num_div_den x];rw [num];field_simp
  rw [id];exact (R p).mul_mem (intCast_mem _ _) (OMA.ThirdOrder284760.inv_mem x.den_pos cp)

private theorem not_regular_den {p t:ℕ} [Fact p.Prime] (pos:0<t)
    (ev:Even t) (hd:p∣(bernoulli t).num.natAbs): ¬p-1∣t := by
  intro reg
  have hp:=Fact.out (p:=p.Prime)
  have be:bernoulli t∈R p:=(OMA.BernoulliScreen284760.integral_iff _).mpr
    (hp.coprime_iff_not_dvd.mp ((bernoulli t).reduced.of_dvd_left hd))
  obtain ⟨k,hk⟩:=ev
  have tform:t=2*k:=by omega
  have v:=Bernoulli.not_dvd_den_bernoulli_add_indicator (p:=p) (k:=k) (by omega)
  have add:bernoulli t+(p:ℚ)⁻¹∈R p:=by
    apply (OMA.BernoulliScreen284760.integral_iff _).mpr
    simpa [←tform,Bernoulli.vonStaudtIndicator,reg] using v
  have inv:=(R p).sub_mem add be
  rw [add_sub_cancel_left] at inv
  have contra:=(OMA.BernoulliScreen284760.integral_iff _).mp inv
  rw [Rat.inv_natCast_den_of_pos hp.pos] at contra
  exact contra (dvd_refl _)

private theorem local_square {p b:ℕ} [Fact p.Prime] (big:5≤p) (ev:Even b) (bp:0<b)
    (unit:¬p∣b+3) (num:p^2∣(bernoulli (b+2)).num.natAbs) :
    p^2∣∑i∈range p,i^(b+2) := by
  have hp:=Fact.out (p:=p.Prime)
  have nz:(p:ℚ)≠0:=by exact_mod_cast hp.ne_zero
  let f (i:ℕ):=bernoulli i*((b+3).choose i:ℚ)*(p:ℚ)^(b+3-i)/(p:ℚ)^2
  have early :(∑i∈range (b+1),f i)∈R p := by
    apply (R p).sum_mem;intro i hi;have lt:=mem_range.mp hi
    have id:f i=(p*bernoulli i)*((b+3).choose i:ℚ)*(p:ℚ)^(b-i) := by
      dsimp [f];rw [show b+3-i=(b-i)+1+2 by omega,pow_add _ _ 2,pow_succ];field_simp
    rw [id];exact (R p).mul_mem ((R p).mul_mem
      (OMA.BernoulliScreen284760.p_bernoulli big i) (natCast_mem _ _)) ((R p).pow_mem (natCast_mem _ p) _)
  have ob:Odd (b+1):=by obtain ⟨j,hj⟩:=ev;exact ⟨j,by omega⟩
  have z1:f (b+1)=0:=by simp [f,bernoulli_eq_zero_of_odd ob (by omega)]
  have top:f (b+2)∈R p := by
    have id:f (b+2)=bernoulli (b+2)/(p^2:ℕ)*(((b+3).choose (b+2):ℚ)*p) := by
      dsimp [f];rw [show b+3-(b+2)=1 by omega,pow_one];push_cast;field_simp
    rw [id];exact (R p).mul_mem (quotient _ (pow_pos hp.pos _) (dvd_pow_self p (by decide)) num)
      ((R p).mul_mem (natCast_mem _ _) (natCast_mem _ _))
  have all:(∑i∈range (b+3),f i)∈R p := by
    rw [sum_range_succ,sum_range_succ,z1,add_zero];exact (R p).add_mem early top
  have mem:((∑i∈range p,i^(b+2):ℕ):ℚ)/(p:ℚ)^2∈R p := by
    have id:((∑i∈range p,i^(b+2):ℕ):ℚ)/(p:ℚ)^2 =
        (∑i∈range (b+3),f i)*((b+3:ℕ):ℚ)⁻¹ := by
      push_cast;rw [sum_range_pow,←Finset.sum_div];unfold f;rw [←Finset.sum_div];push_cast;ring
    rw [id];exact (R p).mul_mem all (OMA.ThirdOrder284760.inv_mem (by omega) unit)
  apply nat_of_local hp.pos
  intro q hq dq
  obtain rfl:=(Nat.prime_dvd_prime_iff_eq hq hp).mp dq;exact mem

private theorem quartic_local {p n b:ℕ} [Fact p.Prime] (big:5≤p) (pn:p∣n)
    (nf:n=b+5) (bp:0<b) (ev:Even b) (good:¬p-1∣b)
    (num:n^2∣(bernoulli (b+2)).num.natAbs) :
    ((∑i∈range n,i^(b+3):ℕ):ℚ)/(n:ℚ)^4∈R p := by
  have nn:0<n:=by omega
  have nz:(n:ℚ)≠0:=by exact_mod_cast nn.ne'
  let f (i:ℕ):=bernoulli i*((b+4).choose i:ℚ)*(n:ℚ)^(b+4-i)/(n:ℚ)^4
  have early:(∑i∈range b,f i)∈R p := (R p).sum_mem fun i hi=>
    OMA.BernoulliScreen284760.scaled_terms big nn pn i (mem_range.mp hi)
  have term0:f b∈R p := by
    have id:f b=bernoulli b*((b+4).choose b:ℚ):=by dsimp [f];rw [show b+4-b=4 by omega];field_simp
    rw [id];exact (R p).mul_mem (OMA.BernoulliScreen284760.bernoulli_integral bp ev good) (natCast_mem _ _)
  have term2:f (b+2)∈R p := by
    have id:f (b+2)=bernoulli (b+2)/(n^2:ℕ)*((b+4).choose (b+2):ℚ):=by
      dsimp [f];rw [show b+4-(b+2)=2 by omega];push_cast;field_simp
    rw [id];exact (R p).mul_mem
      (quotient _ (pow_pos nn _) (pn.trans (dvd_pow_self _ (by decide))) num) (natCast_mem _ _)
  have ob:Odd (b+1):=by obtain ⟨j,hj⟩:=ev;exact ⟨j,by omega⟩
  have oc:Odd (b+3):=by obtain ⟨j,hj⟩:=ev;exact ⟨j+1,by omega⟩
  have z1:f (b+1)=0:=by simp [f,bernoulli_eq_zero_of_odd ob (by omega)]
  have z3:f (b+3)=0:=by simp [f,bernoulli_eq_zero_of_odd oc (by omega)]
  have all:(∑i∈range (b+4),f i)∈R p := by
    rw [sum_range_succ,sum_range_succ,sum_range_succ,sum_range_succ,z3,z1,add_zero,add_zero]
    exact (R p).add_mem ((R p).add_mem early term0) term2
  have unit:¬p∣b+4:=by
    intro d
    exact (Fact.out : p.Prime).not_dvd_one <| (Nat.dvd_add_left d).mp (by rwa [show 1+(b+4)=n by omega])
  have id:((∑i∈range n,i^(b+3):ℕ):ℚ)/(n:ℚ)^4 =
      (∑i∈range (b+4),f i)*((b+4:ℕ):ℚ)⁻¹ := by
    push_cast;rw [sum_range_pow,←Finset.sum_div];unfold f;rw [←Finset.sum_div];push_cast;ring
  rw [id];exact (R p).mul_mem all (OMA.ThirdOrder284760.inv_mem (by omega) unit)

/-- Exact composite-and-prime Bernoulli characterization of the original
quartic power-sum congruence for every positive odd n. -/
theorem original_iff {n:ℕ} (on:Odd n) :
    n^4∣∑i∈Ico 1 n,i^(n-2) ↔ n^2∣(bernoulli (n-3)).num.natAbs := by
  refine ⟨OMA.DoubleBernoulli284760.whole_square on,?_⟩
  intro sq
  by_cases nn:7≤n
  · let b:=n-5
    have nf:n=b+5:=by dsimp [b];omega
    have bp:0<b:=by omega
    have ev:Even b:=by obtain ⟨j,hj⟩:=on;exact ⟨j-2,by omega⟩
    have exp:n-3=b+2:=by omega
    rw [exp] at sq
    rw [show n-2=b+3 by omega]
    have split:=sum_range_add_sum_Ico (fun i:ℕ=>i^(b+3)) on.pos
    have same:(∑i∈Ico 1 n,i^(b+3))=∑i∈range n,i^(b+3):=by simpa using split
    rw [same]
    apply nat_of_local on.pos
    intro p hp pn
    let _ : Fact p.Prime:=⟨hp⟩
    have q2:p^2∣(bernoulli (b+2)).num.natAbs := (pow_dvd_pow_of_dvd pn 2).trans sq
    have nr:=not_regular_den (by omega : 0<b+2) (ev.add (by decide : Even 2))
      ((dvd_pow_self _ (by decide : 2≠0)).trans q2)
    have oddp:=Nat.coprime_two_left.mp ((Nat.coprime_two_left.mpr on).of_dvd_right pn)
    have big:5≤p := by
      obtain ⟨j,hj⟩:=oddp
      obtain ⟨t,ht⟩:=ev
      have :=hp.two_le
      by_contra! small
      have h3:p=3:=by omega
      rw [h3] at nr;omega
    have unit:¬p∣b+3:=by
      intro d
      have d2:p∣2:=(Nat.dvd_add_left d).mp (by rwa [show 2+(b+3)=n by omega])
      have :=Nat.le_of_dvd (by decide : 0<2) d2;omega
    have loc:=local_square big ev bp unit q2
    rw [←exp] at loc
    exact quartic_local big pn nf bp ev (OMA.DoubleBernoulli284760.not_two_of_test hp big on pn loc) sq
  · obtain ⟨j,hj⟩:=on
    have cases:n=1∨n=3∨n=5:=by omega
    rcases cases with rfl|rfl|rfl
    · simp
    · norm_num [bernoulli_zero] at sq
    · norm_num [bernoulli_two] at sq

end OMA.QuarticIff284760
