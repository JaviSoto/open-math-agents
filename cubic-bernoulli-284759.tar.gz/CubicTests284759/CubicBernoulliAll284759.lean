import CubicBernoulliOriginal284759
import QuarticAll284760

namespace OMA.CubicBernoulliAll284759
open Nat Finset OMA.CubicBernoulliOriginal284759
open private OMA.PowerSumRegular284760.ico_range from PowerSumRegular284760

theorem original_all {n:ℕ} (pos:0<n) :
    n^3∣∑i∈Icc 1 (n-1),i^(n-2) ↔ Odd n ∧ n∣(bernoulli (n-3)).num.natAbs := by
  rcases Nat.even_or_odd n with en|on
  · by_cases nt:n=2
    · subst n;decide
    have lo:4≤n:=by obtain ⟨j,hj⟩:=en;omega
    have ev:Even (n-2):=by obtain ⟨j,hj⟩:=en;exact ⟨j-1,by omega⟩
    have fail:=OMA.QuarticAll284760.even_obstruction pos en (by omega : 0<n-2) ev
    rw [←OMA.PowerSumRegular284760.ico_range (f:=fun i:ℕ=>i^(n-2)) pos (zero_pow (by omega : n-2≠0))] at fail
    rw [show Icc 1 (n-1)=Ico 1 n by ext x;simp;omega]
    constructor
    · intro d;exact False.elim (fail ((dvd_pow_self n (by decide : 3≠0)).trans d))
    · intro h;exact False.elim ((Nat.not_even_iff_odd.mpr h.1) en)
  · by_cases big:7≤n
    · simpa [on] using original big on
    · obtain ⟨j,hj⟩:=on
      have cases:n=1∨n=3∨n=5:=by omega
      rcases cases with rfl|rfl|rfl
      · simp
      · rw [show (3:ℕ)-3=0 by decide,bernoulli_zero];decide
      · rw [show (5:ℕ)-3=2 by decide,bernoulli_two,show ((6:ℚ)⁻¹).num.natAbs=1 by norm_num];decide

/-- The same criterion covers every positive n congruent to 3 modulo 4
for Meštrović's half-exponent conjecture. -/
theorem half_all {n:ℕ} (res:n%4=3) :
    n^3∣∑i∈Icc 1 (n-1),i^((n-1)/2) ↔ n∣(bernoulli ((n-3)/2)).num.natAbs := by
  by_cases big:11≤n
  · exact half big res
  · have cases:n=3∨n=7:=by omega
    rcases cases with rfl|rfl
    · rw [show ((3:ℕ)-3)/2=0 by decide,bernoulli_zero];decide
    · rw [show ((7:ℕ)-3)/2=2 by decide,bernoulli_two,show ((6:ℚ)⁻¹).num.natAbs=1 by norm_num];decide

#print axioms original_all
#print axioms half_all
end OMA.CubicBernoulliAll284759
