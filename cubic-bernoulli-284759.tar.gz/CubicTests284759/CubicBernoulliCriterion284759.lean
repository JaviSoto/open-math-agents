import CubicBernoulliLocal284759

/-! Pass from the local even power-sum comparison to ordinary divisibility
of the reduced Bernoulli numerator, without a squarefreeness assumption. -/
namespace OMA.CubicBernoulliCriterion284759
open Nat Finset OMA.CubicBernoulliLocal284759

theorem denominator {n:ℕ} (nn:0<n) (q:ℚ) :
    n∣q.num.natAbs ↔ n.Coprime (q/(n:ℚ)).den := by
  let x:=q/(n:ℚ)
  have hn:(n:ℚ)≠0:=by exact_mod_cast nn.ne'
  have xd:(x.den:ℚ)≠0:=by exact_mod_cast x.den_ne_zero
  have qd:(q.den:ℚ)≠0:=by exact_mod_cast q.den_ne_zero
  have frac : (x.num:ℚ)/x.den=((q.num:ℚ)/q.den)/n := by rw [Rat.num_div_den,Rat.num_div_den]
  have cross:x.num*(q.den:ℤ)*n=q.num*x.den := by
    exact_mod_cast (by field_simp at frac;linear_combination frac :
      (x.num:ℚ)*q.den*n=q.num*x.den)
  have eqn:=congrArg Int.natAbs cross
  simp only [Int.natAbs_mul,Int.natAbs_natCast] at eqn
  change _ ↔ n.Coprime x.den
  constructor
  · rintro ⟨z,hz⟩
    have can : x.num.natAbs*q.den=z*x.den := Nat.eq_of_mul_eq_mul_right nn
      (by rw [hz] at eqn;simpa only [mul_left_comm,mul_assoc,mul_comm] using eqn)
    apply Nat.coprime_of_dvd;intro p pp pn pd
    have lhs : p∣x.num.natAbs*q.den := can ▸ dvd_mul_of_dvd_right pd z
    rcases pp.dvd_mul.mp lhs with a|b
    · exact (Nat.not_coprime_of_dvd_of_dvd pp.one_lt a pd) x.reduced
    · exact (Nat.not_coprime_of_dvd_of_dvd pp.one_lt
        (pn.trans (show n∣q.num.natAbs from ⟨z,hz⟩)) b) q.reduced
  · intro cp
    apply cp.dvd_of_dvd_mul_right
    rw [←eqn];exact dvd_mul_left _ _

/-- For positive n all of whose prime factors are odd, even t=b+2≥4,
and gcd(t+1,n)=1, n² divides the complete even-power sum iff n divides
the numerator of B_t. -/
theorem even_iff {n b:ℕ} (nn:0<n) (bp:0<b) (ev:Even b)
    (large:∀p:ℕ,p.Prime→p∣n→3≤p) (unit:n.Coprime (b+3)) :
    n^2∣∑i∈range n,i^(b+2) ↔ n∣(bernoulli (b+2)).num.natAbs := by
  let S:=∑i∈range n,i^(b+2)
  let B:=bernoulli (b+2)
  let X:ℚ:=S/(n:ℚ)^2
  let Y:ℚ:=B/n
  have eqv {p:ℕ} (pp:p.Prime) (pn:p∣n) : ¬p∣X.den ↔ ¬p∣Y.den := by
    let : Fact p.Prime:=⟨pp⟩
    have d : X-Y∈localRing p := by
      have err:=error (b:=b) (large p pp pn) nn pn ev bp
        (fun pd=>(Nat.not_coprime_of_dvd_of_dvd pp.one_lt pn pd) unit)
      dsimp [X,Y,S,B];push_cast;exact err
    rw [←Rat.padicValuation_le_one_iff,←Rat.padicValuation_le_one_iff]
    change X∈localRing p ↔ Y∈localRing p
    constructor
    · intro x;simpa only [sub_sub_cancel] using (localRing p).sub_mem x d
    · intro y;simpa only [sub_add_cancel] using (localRing p).add_mem d y
  have left:n^2∣S ↔ n.Coprime X.den := by
    have f:=denominator (pow_pos nn 2) (S:ℚ)
    simpa only [Rat.num_natCast,Int.natAbs_natCast,Nat.cast_pow,Nat.coprime_pow_left_iff
      (by decide : 0<2),X] using f
  have right:=denominator nn B
  change n^2∣S↔n∣B.num.natAbs
  rw [left,right]
  change n.Coprime X.den ↔ n.Coprime Y.den
  constructor
  · intro x;apply Nat.coprime_of_dvd;intro p pp pn
    exact (eqv pp pn).mp (fun pd=>(Nat.not_coprime_of_dvd_of_dvd pp.one_lt pn pd) x)
  · intro y;apply Nat.coprime_of_dvd;intro p pp pn
    exact (eqv pp pn).mpr (fun pd=>(Nat.not_coprime_of_dvd_of_dvd pp.one_lt pn pd) y)

#print axioms even_iff
end OMA.CubicBernoulliCriterion284759
