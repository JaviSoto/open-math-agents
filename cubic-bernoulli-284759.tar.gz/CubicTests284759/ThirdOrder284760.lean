import DoubleBernoulli284760

namespace OMA.ThirdOrder284760
open Finset Nat
open private OMA.BernoulliScreen284760.integers OMA.BernoulliScreen284760.integral_iff
  OMA.BernoulliScreen284760.p_bernoulli OMA.BernoulliScreen284760.bernoulli_integral from BernoulliScreen284760
open OMA.BernoulliScreen284760

private abbrev localRing (p:ℕ) [Fact p.Prime] := OMA.BernoulliScreen284760.integers p

private theorem inv_mem {p d:ℕ} [Fact p.Prime] (pos:0<d) (good:¬p∣d):
    (d:ℚ)⁻¹∈localRing p := by
  apply (OMA.BernoulliScreen284760.integral_iff _).mpr
  rwa [Rat.inv_natCast_den_of_pos pos]

private theorem quotient_mem {p:ℕ} [Fact p.Prime] (x:ℚ) (d:p^2∣x.num.natAbs) :
    x/(p:ℚ)^2∈localRing p := by
  have pr:=Fact.out (p:=p.Prime)
  have dvd:p∣x.num.natAbs := (dvd_pow_self p (by decide : 2≠0)).trans d
  have good : ¬p∣x.den := pr.coprime_iff_not_dvd.mp (x.reduced.of_dvd_left dvd)
  obtain ⟨t, ht⟩:=Int.natCast_dvd.mpr d
  have hid:(x.num:ℚ)=(p:ℚ)^2*t:=by exact_mod_cast ht
  have zn:(p:ℚ)≠0:=by exact_mod_cast pr.ne_zero
  have eq:x/(p:ℚ)^2=(t:ℚ)*(x.den:ℚ)⁻¹ := by
    nth_rw 1 [←Rat.num_div_den x]
    rw [hid];field_simp
  rw [eq];exact (localRing p).mul_mem (intCast_mem _ _) (inv_mem x.den_pos good)

private theorem integral_cube {p a:ℕ} [Fact p.Prime]
    (h:(a:ℚ)/(p:ℚ)^3∈localRing p) : p^3∣a := by
  let x:ℚ:=(a:ℚ)/(p:ℚ)^3
  have hp:=Fact.out (p:=p.Prime)
  have good:=hp.coprime_iff_not_dvd.mpr ((OMA.BernoulliScreen284760.integral_iff x).mp h)
  have nz:(p:ℚ)≠0:=by exact_mod_cast hp.ne_zero
  have eq:(x.num:ℚ)/x.den=a/(p:ℚ)^3 := Rat.num_div_den _
  have dn:(x.den:ℚ)≠0:=by exact_mod_cast x.den_ne_zero
  field_simp at eq
  have eq':x.num*(p:ℤ)^3=(a:ℤ)*x.den:=by rw [mul_comm (a:ℤ)];exact_mod_cast eq
  have nat:=congrArg Int.natAbs eq'
  simp only [Int.natAbs_mul,Int.natAbs_pow,Int.natAbs_natCast] at nat
  have dv:=dvd_mul_left (p^3) x.num.natAbs
  rw [nat] at dv
  exact (good.pow_left 3).dvd_of_dvd_mul_right dv

/-- The full third-order complete residue test, independent of the remaining
prime factors or their multiplicities. -/
theorem cube_test {n p:ℕ} (hp:p.Prime) (big:7≤p) (on:Odd n) (pn:p∣n)
    (bad:n^4∣∑i∈Ico 1 n,i^(n-2)) : p^3∣∑i∈range p,i^(n-3) := by
  let _ : Fact p.Prime:=⟨hp⟩
  let b:=n-5
  have nn:=Nat.le_of_dvd on.pos pn
  have bp:0<b:=by dsimp [b];omega
  have eb:Even b:=by obtain ⟨j,hj⟩:=on;exact ⟨j-2,by dsimp [b];omega⟩
  have e:n-3=b+2 := by dsimp [b];omega
  have nform:n=b+5 := by dsimp [b];omega
  have nd:=OMA.DoubleBernoulli284760.not_two hp (by omega) on pn bad
  have sq:=OMA.DoubleBernoulli284760.square_bernoulli (a:=1) hp big on (by decide)
    (by simpa using pn) bad
  rw [e] at sq ⊢
  have zn:(p:ℚ)≠0:=by exact_mod_cast hp.ne_zero
  let f (i:ℕ) := bernoulli i*((b+3).choose i:ℚ)*(p:ℚ)^(b+3-i)/(p:ℚ)^3
  have early : (∑i∈range b,f i)∈localRing p := by
    apply (localRing p).sum_mem
    intro i hi
    have lt:=mem_range.mp hi
    have id:f i=(p*bernoulli i)*((b+3).choose i:ℚ)*(p:ℚ)^(b-i-1) := by
      dsimp [f];rw [show b+3-i=(b-i-1)+1+3 by omega,pow_add _ _ 3,pow_succ]
      field_simp
    rw [id]
    exact (localRing p).mul_mem ((localRing p).mul_mem
      (OMA.BernoulliScreen284760.p_bernoulli (by omega : 5≤p) i) (natCast_mem _ _))
      ((localRing p).pow_mem (natCast_mem _ p) _)
  have fb:f b∈localRing p := by
    have id:f b=bernoulli b*((b+3).choose b:ℚ) := by dsimp [f];rw [show b+3-b=3 by omega];field_simp
    rw [id];exact (localRing p).mul_mem (OMA.BernoulliScreen284760.bernoulli_integral bp eb nd) (natCast_mem _ _)
  have ob:Odd (b+1):=by obtain ⟨j,hj⟩:=eb;exact ⟨j,by omega⟩
  have z1:f (b+1)=0 := by simp [f,bernoulli_eq_zero_of_odd ob (by omega)]
  have z2:f (b+2)∈localRing p := by
    have id:f (b+2)=bernoulli (b+2)/(p:ℚ)^2*((b+3).choose (b+2):ℚ) := by
      dsimp [f];rw [show b+3-(b+2)=1 by omega,pow_one];field_simp
    rw [id];exact (localRing p).mul_mem (quotient_mem _ sq) (natCast_mem _ _)
  have all:(∑i∈range (b+3),f i)∈localRing p := by
    rw [sum_range_succ,sum_range_succ,sum_range_succ,z1,add_zero]
    exact (localRing p).add_mem ((localRing p).add_mem early fb) z2
  have unit:¬p∣b+3 := by
    intro d
    have two:p∣2:=(Nat.dvd_add_left d).mp (by simpa only [show 2+(b+3)=n by omega] using pn)
    have :=Nat.le_of_dvd (by decide : 0<2) two;omega
  apply integral_cube
  have val:((∑i∈range p,i^(b+2):ℕ):ℚ)/(p:ℚ)^3 =
      (∑i∈range (b+3),f i)*((b+3:ℕ):ℚ)⁻¹ := by
    push_cast
    rw [sum_range_pow,←Finset.sum_div]
    unfold f;rw [←Finset.sum_div]
    push_cast;ring
  rw [val];exact (localRing p).mul_mem all (inv_mem (by omega) unit)

end OMA.ThirdOrder284760
