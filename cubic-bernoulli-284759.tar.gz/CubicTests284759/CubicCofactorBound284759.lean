import CubicBernoulliOriginal284759
import PowerSumIndexTransfer284759

/-! A prime larger than its complementary factor belongs to a finite list
depending only on that complementary factor, not on the size of n. -/
namespace OMA.CubicCofactorBound284759
open Nat Finset OMA.PowerSumIndexTransfer284759
open private OMA.PowerSumIndexTransfer284759.cs OMA.PowerSumIndexTransfer284759.voronoi
  OMA.PowerSumIndexTransfer284759.same_times_p from PowerSumIndexTransfer284759
open private OMA.PowerSumRegular284760.shrink from PowerSumRegular284760

theorem lower {p k j:ℕ} (hp:p.Prime) (lo:1<k) (hi:k<p-1)
    (unit:¬p∣k+(p-1)*j) (large:(∑i∈range p,(i:ZMod (p^2))^(k+(p-1)*j))=0) :
    (∑i∈range p,(i:ZMod (p^2))^k)=0 := by
  let _ : Fact p.Prime:=⟨hp⟩
  obtain ⟨a,ha⟩:=exists_pow_ne_one_of_isCyclic (G:=(ZMod p)ˣ) (show k≠0 by omega)
    (by rw [Nat.card_eq_fintype_card,ZMod.card_units];exact hi)
  let g:ℕ:=(a:ZMod p).val
  let v:ℕ:=(a⁻¹: (ZMod p)ˣ).val.val
  have gg:(g:ZMod p)=a:=ZMod.natCast_zmod_val _
  have vv:(v:ZMod p)=(a⁻¹: (ZMod p)ˣ):=ZMod.natCast_zmod_val _
  have inv:g*v ≡ 1 [MOD p]:=(ZMod.natCast_eq_natCast_iff ..).mp
    (by rw [Nat.cast_mul,Nat.cast_one,gg,vv];exact a.mul_inv)
  have sep:(g:ZMod p)^k≠1:=by
    rw [gg];intro eqn;apply ha;apply Units.ext;simpa only [Units.val_pow_eq_pow_val,Units.val_one] using eqn
  have cancel:IsUnit ((g:ZMod (p^2))^k-1):=by
    simpa using (separated (j:=0) hp (by rw [gg];exact a.ne_zero) sep)
  have eu:IsUnit ((k+(p-1)*j:ℕ):ZMod (p^2)):=
    (ZMod.isUnit_natCast_iff_not_dvd_pow hp (by decide : 0<2)).mpr unit
  have big:=OMA.PowerSumIndexTransfer284759.voronoi (e:=k+(p-1)*j) hp.pos inv
  have zero:OMA.PowerSumIndexTransfer284759.cs p g (k+(p-1)*j)=0:=
    eu.mul_right_inj.mp (by simpa only [large,mul_zero] using big.symm)
  have same : OMA.PowerSumIndexTransfer284759.cs p g (k+(p-1)*j)=OMA.PowerSumIndexTransfer284759.cs p g k := by
    unfold OMA.PowerSumIndexTransfer284759.cs
    apply sum_congr rfl;intro i _
    apply congrArg (·*(((g*i)/p:ℕ):ZMod (p^2)))
    let x:ℕ:=(g*i)%p
    change (x:ZMod (p^2))^_*p=(x:ZMod (p^2))^_*p
    rw [←Nat.cast_pow,←Nat.cast_pow]
    apply OMA.PowerSumIndexTransfer284759.same_times_p
    simp only [Nat.cast_pow]
    rw [show k+(p-1)*j-1=k-1+(p-1)*j by omega,pow_add,pow_mul]
    by_cases z:(x:ZMod p)=0
    · simp [z,zero_pow (show k-1≠0 by omega)]
    · simp [ZMod.pow_card_sub_one_eq_one z]
  rw [same] at zero
  have small:=OMA.PowerSumIndexTransfer284759.voronoi (e:=k) hp.pos inv
  exact cancel.mul_right_inj.mp (by simpa only [zero,mul_zero] using small)

theorem bound {p m : ℕ} (hp : p.Prime) (lt : m < p) (mb : 7 ≤ m) (om : Odd m)
    (hit:(p*m)^3∣∑i∈Icc 1 (p*m-1),i^(p*m-2)) :
    p∣(bernoulli (m-3)).num.natAbs := by
  let n:=p*m
  have pb:7≤p:=by omega
  have nb:7≤n:=by dsimp [n];nlinarith only [lt,mb]
  have on:Odd n:=(hp.odd_of_ne_two (by omega)).mul om
  have pn:p∣n:=dvd_mul_right p m
  have oddsub (t:ℕ) (ot:Odd t) (lb:7≤t) : Odd (t-2) ∧ Odd (t-3-1) ∧ Even (t-5) := by
    obtain ⟨j,hj⟩:=ot
    exact ⟨⟨j-1,by omega⟩,⟨j-2,by omega⟩,⟨j-2,by omega⟩⟩
  have ref:=OMA.CubicBernoulliOriginal284759.reflection on (oddsub n on nb).1
    (show 3≤n-2 by omega) ((Nat.coprime_self_sub_right (by omega)).mpr (Nat.coprime_two_right.mpr on))
  have sq:=ref.mp hit
  rw [show n-2-1=n-3 by omega] at sq
  have row:=OMA.PowerSumRegular284760.shrink hp (by omega) (oddsub n on nb).2.1 n on pn
    ((show p*n∣n^2 by rw [pow_two];exact Nat.mul_dvd_mul_right pn n).trans sq)
  have id:n-3=(m-3)+(p-1)*m:=by
    have add:p-1+1=p:=by omega
    dsimp [n];nth_rw 1 [←add];rw [Nat.add_mul,one_mul];omega
  have unit:¬p∣n-3:=by
    intro d
    have three:p∣3:=(Nat.dvd_add_left d).mp (by rwa [show 3+(n-3)=n by omega])
    have :=Nat.le_of_dvd (by decide : 0<3) three;omega
  rw [id] at unit row
  have short:=lower hp (show 1 < m-3 by omega) (by omega : m-3 < p-1) unit
    (by simpa only [Nat.cast_sum,Nat.cast_pow] using (ZMod.natCast_eq_zero_iff _ _).mpr row)
  have dvd:p^2∣∑i∈range p,i^(m-3) := (ZMod.natCast_eq_zero_iff _ _).mp
    (by simpa only [Nat.cast_sum,Nat.cast_pow] using short)
  have small:m-5+2=m-3:=by omega
  rw [←small] at dvd ⊢
  apply (OMA.CubicBernoulliCriterion284759.even_iff hp.pos (by omega) (oddsub m om mb).2.2
    (fun q hq d=>by have :=(Nat.prime_dvd_prime_iff_eq hq hp).mp d;omega)
    (hp.coprime_iff_not_dvd.mpr (fun d=>by have :=Nat.le_of_dvd (by omega : 0 < m-5+3) d;omega))).mp dvd

#print axioms bound
end OMA.CubicCofactorBound284759
