import QuarticIff284760

namespace OMA.QuarticAll284760
open Nat Finset
open private OMA.PowerSum284760.blocks_cast OMA.PowerSum284760.taylor from PowerSum284760
open private OMA.PowerSumRegular284760.ico_range from PowerSumRegular284760

/-- For n even and e positive even, already n itself fails to divide the
complete power sum. Halving the number of terms preserves the obstruction. -/
theorem even_obstruction {n e:ℕ} (nn:0<n) (en:Even n) (ep:0<e) (ee:Even e) :
    ¬n∣∑i∈range n,i^e := by
  induction n using Nat.strong_induction_on with
  | h n ih =>
    obtain ⟨m,hm⟩:=en
    have nf:n=2*m:=by omega
    have mp:0 < m :=by omega
    intro hz
    rw [nf] at hz
    rcases Nat.even_or_odd m with em|om
    · let R:=ZMod (2*m)
      have sq:(m:R)^2=0:=by
        rw [←Nat.cast_pow,ZMod.natCast_eq_zero_iff,pow_two]
        exact Nat.mul_dvd_mul_right em.two_dvd _
      have emul:(m:R)*e=0:=by
        rw [←Nat.cast_mul,ZMod.natCast_eq_zero_iff,mul_comm 2 m]
        exact Nat.mul_dvd_mul_left _ ee.two_dvd
      have term (i:ℕ) : ((m+i:ℕ):R)^e=(i:R)^e := by
        rw [Nat.cast_add,add_comm,OMA.PowerSum284760.taylor _ _ sq e]
        linear_combination (i:R)^(e-1)*emul
      have val:(∑i∈range (2*m),(i:R)^e)=0:=by
        simpa only [Nat.cast_pow,Nat.cast_sum] using (ZMod.natCast_eq_zero_iff _ _).mpr hz
      conv at val => lhs;arg 1;rw [two_mul m]
      rw [sum_range_add,sum_congr rfl (fun i _=>term i),←two_mul] at val
      have div:2*m∣2*(∑i∈range m,i^e):=(ZMod.natCast_eq_zero_iff _ _).mp (by push_cast;exact val)
      exact ih m (by omega) mp em ((Nat.dvd_of_mul_dvd_mul_left (by decide : 0<2)) div)
    · have span:=OMA.PowerSum284760.blocks_cast 2 m e
      have zero:(∑i∈range (2*m),(i:ZMod 2)^e)=0:=by
        simpa only [Nat.cast_sum,Nat.cast_pow] using (ZMod.natCast_eq_zero_iff _ _).mpr
          ((dvd_mul_right 2 m).trans hz)
      rw [zero] at span
      have base:(∑i∈range 2,(i:ZMod 2)^e)=1:=by
        rw [sum_range_succ,sum_range_succ];simp [zero_pow ep.ne']
      rw [base,mul_one] at span
      exact om.not_two_dvd_nat ((ZMod.natCast_eq_zero_iff ..).mp span.symm)

/-- Complete characterization for the original positive integer n. -/
theorem all_iff {n:ℕ} (pos:0<n) :
    n^4∣∑i∈Ico 1 n,i^(n-2) ↔ Odd n ∧ n^2∣(bernoulli (n-3)).num.natAbs := by
  rcases Nat.even_or_odd n with en|on
  · by_cases nt:n=2
    · subst n;decide
    have lo:4≤n:=by obtain ⟨j,hj⟩:=en;omega
    have ev:Even (n-2):=by obtain ⟨j,hj⟩:=en;exact ⟨j-1,by omega⟩
    have fail:=even_obstruction pos en (by omega : 0<n-2) ev
    rw [←OMA.PowerSumRegular284760.ico_range pos (by exact zero_pow (by omega : n-2≠0))] at fail
    constructor
    · intro d;exact False.elim (fail ((dvd_pow_self n (by decide : 4≠0)).trans d))
    · intro h;obtain ⟨u,hu⟩:=h.1;obtain ⟨t,ht⟩:=en;omega
  · simpa [on] using OMA.QuarticIff284760.original_iff on

end OMA.QuarticAll284760
