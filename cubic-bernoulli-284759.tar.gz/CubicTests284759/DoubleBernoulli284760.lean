import BernoulliScreen284760
import PowerSumRegular284760

namespace OMA.DoubleBernoulli284760
open Nat Finset
open private OMA.PowerSum284760.taylor from PowerSum284760
open private OMA.PowerSumRegular284760.ico_range from PowerSumRegular284760

private theorem perm {R:Type*} [AddCommMonoid R] (p:ℕ) (odd:Odd p) (f:ℕ→R):
    (∑i∈range p,f ((2*i)%p))=∑i∈range p,f i := by
  let u:=(p+1)/2
  have id:2*u=p+1:=by dsimp [u];obtain ⟨t,h⟩:=odd;omega
  have inv (i:ℕ) (hi:i<p) : (2*u*i)%p=i := by
    rw [id,add_mul,one_mul,Nat.mul_add_mod_self_left,Nat.mod_eq_of_lt hi]
  apply sum_bij' (fun i _=>(2*i)%p) (fun i _=>(u*i)%p)
  · intro i _;exact mem_range.mpr (Nat.mod_lt _ odd.pos)
  · intro i _;exact mem_range.mpr (Nat.mod_lt _ odd.pos)
  · intro i hi;rw [Nat.mul_mod_mod,←mul_assoc,mul_comm u 2];exact inv _ (mem_range.mp hi)
  · intro i hi;rw [Nat.mul_mod_mod,←mul_assoc];exact inv _ (mem_range.mp hi)
  · intro _ _;rfl

private theorem weight (h:ℕ) :
    (∑i∈range (2*h+1), ((2*i)/(2*h+1))*((2*i)%(2*h+1)))=h^2 := by
  conv_lhs => arg 1;rw [show 2*h+1=(h+1)+h by omega]
  rw [sum_range_add]
  have first (i:ℕ) (hi:i∈range (h+1)) : ((2*i)/(2*h+1))*((2*i)%(2*h+1))=0:=by
    have :=mem_range.mp hi;rw [Nat.div_eq_of_lt (by omega),zero_mul]
  have last (i:ℕ) (hi:i∈range h) :
      ((2*(h+1+i))/(2*h+1))*((2*(h+1+i))%(2*h+1))=2*i+1:=by
    have ih:=mem_range.mp hi
    rw [show 2*(h+1+i)=(2*i+1)+(2*h+1) by omega,Nat.add_div_right _ (by omega),
        Nat.div_eq_of_lt (by omega),Nat.add_mod_right,Nat.mod_eq_of_lt (by omega)];simp
  rw [sum_congr rfl first,sum_congr rfl last,sum_const_zero,zero_add,sum_add_distrib,
    ←mul_sum,sum_const,card_range,nsmul_eq_mul,mul_one]
  cases h with
  | zero=>simp
  | succ h=>
    have id:=sum_range_id_mul_two (h+1)
    rw [Nat.add_sub_cancel] at id;nlinarith only [id]

/-- Under the square-local test, doubling the representatives forces one
weighted half-residue sum to vanish modulo p. -/
private theorem weight_zero {e p:ℕ} (hp:p.Prime) (odd:Odd p)
    (de:¬p∣e) (he:p^2∣∑i∈range p,i^e) :
    p∣∑i∈range p, (2*i/p)*((2*i)%p)^(e-1) := by
  let R:=ZMod (p^2)
  have sq:(p:R)^2=0:=by rw [←Nat.cast_pow];exact ZMod.natCast_self _
  have base : (∑i∈range p,(i:R)^e)=0 := by
    simpa only [Nat.cast_pow,Nat.cast_sum] using (ZMod.natCast_eq_zero_iff _ _).mpr he
  have eq (i:ℕ) : ((2*i:ℕ):R)^e = (((2*i)%p:ℕ):R)^e+
      ((p:R)*e)*((2*i/p:ℕ):R)*(((2*i)%p:ℕ):R)^(e-1) := by
    calc
      _ = ((((2*i)%p:ℕ):R)+(p:R)*((2*i/p:ℕ):R))^e := by
        congr 1
        simpa only [R,Nat.cast_add,Nat.cast_mul,Nat.cast_ofNat] using congrArg (fun a:ℕ=>(a:ZMod (p^2))) (Nat.mod_add_div (2*i) p).symm
      _ = _ := by rw [OMA.PowerSum284760.taylor _ _ (by rw [mul_pow,sq,zero_mul])];ring
  have tot := sum_congr (s₁:=range p) rfl (fun i _=>eq i)
  rw [sum_add_distrib,perm p odd (fun i=>(i:R)^e)] at tot
  have lm : (∑i∈range p,((2*i:ℕ):R)^e)=0 := by
    change (∑i∈range p,((2*i:ℕ):ZMod (p^2))^e)=0
    simp only [Nat.cast_mul,Nat.cast_ofNat,mul_pow,←mul_sum];rw [base,mul_zero]
  rw [lm,base,zero_add] at tot
  have val : (p:R)*((e:R)*(∑i∈range p, ((2*i/p:ℕ):R)*(((2*i)%p:ℕ):R)^(e-1)))=0 := by
    rw [mul_sum,mul_sum];simpa only [mul_assoc] using tot.symm
  have dv:p^2∣p*(e*(∑i∈range p, (2*i/p)*((2*i)%p)^(e-1))) :=
    (ZMod.natCast_eq_zero_iff _ _).mp (by push_cast;exact val)
  rw [pow_two] at dv
  exact (hp.coprime_iff_not_dvd.mpr de).dvd_of_dvd_mul_left (Nat.dvd_of_mul_dvd_mul_left hp.pos dv)

/-- The missing second Bernoulli index is impossible for an actual odd
counterexample: its half-residue sum would be a nonzero triangular number. -/
theorem not_two_of_test {n p:ℕ} (hp:p.Prime) (big:5≤p) (on:Odd n) (pn:p∣n)
    (h:p^2∣∑i∈range p,i^(n-3)) : ¬p-1∣n-5 := by
  have nn:=Nat.le_of_dvd on.pos pn
  have op:=hp.odd_of_ne_two (by omega)
  have de:¬p∣n-3 := by
    intro dv
    have dd:p∣3 := (Nat.dvd_add_left dv).mp (by rwa [Nat.add_sub_cancel' (by omega : 3≤n)])
    have := Nat.le_of_dvd (by decide : 0<3) dd;omega
  have half:=weight_zero hp op de h
  intro twice
  obtain ⟨q,hq⟩:=twice
  have exp:n-3-1=1+(p-1)*q:=by omega
  let _ : Fact p.Prime:=⟨hp⟩
  have same (a:ℕ) : ((a%p:ℕ):ZMod p)^(n-3-1)=((a%p:ℕ):ZMod p) := by
    by_cases z:((a%p:ℕ):ZMod p)=0
    · rw [z,zero_pow (by omega : n-3-1≠0)]
    · rw [exp,pow_add,pow_mul,ZMod.pow_card_sub_one_eq_one z,one_pow,pow_one,mul_one]
  have z1 : (∑i∈range p,((2*i/p:ℕ):ZMod p)*(((2*i)%p:ℕ):ZMod p)^(n-3-1))=0 := by
    simpa only [Nat.cast_sum,Nat.cast_mul,Nat.cast_pow] using (ZMod.natCast_eq_zero_iff _ _).mpr half
  simp_rw [same] at z1
  have dw : p∣∑i∈range p,(2*i/p)*((2*i)%p) := (ZMod.natCast_eq_zero_iff _ _).mp (by
    simpa only [Nat.cast_sum,Nat.cast_mul] using z1)
  obtain ⟨b,hb⟩:=op
  rw [hb,weight] at dw
  have pb:(2*b+1).Prime:=hb ▸ hp
  have small: 2*b+1 ≤ b := Nat.le_of_dvd (by omega) (pb.dvd_of_dvd_pow dw)
  omega

theorem not_two {n p:ℕ} (hp:p.Prime) (big:5≤p) (on:Odd n) (pn:p∣n)
    (bad:n^4∣∑i∈Ico 1 n,i^(n-2)) : ¬p-1∣n-5 := by
  have nn:=Nat.le_of_dvd on.pos pn
  have h:=OMA.PowerSumRegular284760.prime_test on hp big pn bad
  rw [OMA.PowerSumRegular284760.ico_range hp.pos (by exact zero_pow (by omega : n-3≠0))] at h
  exact not_two_of_test hp big on pn h

/-- All prime divisors p≥7 of a counterexample, without an index exception,
must divide the Bernoulli numerator to twice their multiplicity in n. -/
theorem square_bernoulli {n p a:ℕ} (hp:p.Prime) (large:7≤p) (on:Odd n)
    (pos:0<a) (dvd:p^a∣n) (bad:n^4∣∑i∈Ico 1 n,i^(n-2)) :
    p^(2*a)∣(bernoulli (n-3)).num.natAbs :=
  OMA.BernoulliScreen284760.square_bernoulli hp large on pos dvd
    (not_two hp (by omega) on ((dvd_pow_self _ pos.ne').trans dvd) bad) bad

/-- Meštrović's quartic divisibility at any odd n forces the entire square
of n to divide the reduced numerator of the single Bernoulli number B_(n−3). -/
theorem whole_square {n:ℕ} (on:Odd n) (bad:n^4∣∑i∈Ico 1 n,i^(n-2)) :
    n^2∣(bernoulli (n-3)).num.natAbs := by
  by_cases z:(bernoulli (n-3)).num.natAbs=0
  · rw [z];exact dvd_zero _
  apply (Nat.factorization_prime_le_iff_dvd (pow_ne_zero _ on.pos.ne') z).mp
  intro p hp
  simp only [Nat.factorization_pow,Finsupp.nsmul_apply,smul_eq_mul]
  by_cases a:n.factorization p=0
  · simp [a]
  have pd:= (hp.dvd_iff_one_le_factorization on.pos.ne').mpr (by omega)
  have nr : ¬p-1∣n-3 := fun h => OMA.PowerSum284760.local_obstruction on hp pd h
    ((pow_dvd_pow n (by decide : 2≤4)).trans bad)
  have large:7≤p := by
    by_contra! small
    have op:=Nat.coprime_two_left.mp ((Nat.coprime_two_left.mpr on).of_dvd_right pd)
    obtain ⟨j,hj⟩:=op
    have :=hp.two_le
    have :=Nat.le_of_dvd on.pos pd
    obtain ⟨t,ht⟩:=on
    have cases:p=3 ∨ p=5 := by omega
    rcases cases with rfl|rfl
    · omega
    · have nt:=not_two hp (by decide) (show Odd n from ⟨t,ht⟩) pd bad
      omega
  apply (hp.pow_dvd_iff_le_factorization z).mp
  exact square_bernoulli hp large on (by omega) ((hp.pow_dvd_iff_le_factorization on.pos.ne').mpr le_rfl) bad

end OMA.DoubleBernoulli284760
