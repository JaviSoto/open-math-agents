import Mathlib

/-! Faulhaber at the actual exponent n−2.  Since its denominator n−1
is a unit at every prime dividing n, all but one of the top terms can be
controlled directly with von Staudt–Clausen. -/
namespace OMA.BernoulliScreen284760
open Finset Nat
open private Bernoulli.not_dvd_den_bernoulli_add_indicator Bernoulli.vonStaudtIndicator from Mathlib.NumberTheory.Bernoulli

private abbrev integers (p:ℕ) [Fact p.Prime] : Subring ℚ := (Rat.padicValuation p).integer

private theorem integral_iff {p:ℕ} [Fact p.Prime] (x:ℚ) :
    x∈integers p ↔ ¬p∣x.den := Rat.padicValuation_le_one_iff

private theorem bernoulli_integral {p i:ℕ} [Fact p.Prime] (ip : 0 < i)
    (ei:Even i) (nd:¬p-1∣i) : bernoulli i∈integers p := by
  obtain ⟨k,h⟩:=ei
  have hh:i=2*k:=by omega
  clear h
  subst i
  have x:=Bernoulli.not_dvd_den_bernoulli_add_indicator (p:=p) (k:=k) (by omega)
  apply (integral_iff _).mpr
  simpa [Bernoulli.vonStaudtIndicator,nd] using x

private theorem p_bernoulli {p:ℕ} [Fact p.Prime] (hp:5≤p) (i:ℕ) :
    (p:ℚ)*bernoulli i∈integers p := by
  by_cases iz:i=0
  · subst i;simp
  by_cases io:i=1
  · subst i;apply (integers p).mul_mem (natCast_mem (integers p) _) ((integral_iff _).mpr ?_)
    norm_num [bernoulli_one];intro d;have :=Nat.le_of_dvd (by decide : 0<2) d;omega
  rcases Nat.even_or_odd i with ev|od
  · obtain ⟨k,h⟩:=ev;have hh:i=2*k:=by omega
    clear h
    subst i
    have z:=(integral_iff _).mpr (Bernoulli.not_dvd_den_bernoulli_add_indicator (p:=p) (k:=k) (by omega))
    have mult:=(integers p).mul_mem (natCast_mem (integers p) p) z
    by_cases d:p-1∣2*k
    · have nz:(p:ℚ)≠0:=by exact_mod_cast (Fact.out : p.Prime).ne_zero
      have ident:(p:ℚ)*bernoulli (2*k)=p*(bernoulli (2*k)+1/p)-1:=by field_simp;ring
      rw [ident]
      apply (integers p).sub_mem _ (integers p).one_mem
      simpa [Bernoulli.vonStaudtIndicator,d] using mult
    · simpa [Bernoulli.vonStaudtIndicator,d] using mult
  · rw [bernoulli_eq_zero_of_odd od (by omega),mul_zero];exact (integers p).zero_mem

private theorem scaled_terms {p n b:ℕ} [Fact p.Prime] (hp:5≤p)
    (nn:0<n) (pn:p∣n) (i:ℕ) (lt:i<b) :
    bernoulli i*((b+4).choose i:ℚ)*(n:ℚ)^(b+4-i)/(n:ℚ)^4 ∈integers p := by
  obtain ⟨u,hu⟩:=pn
  have hpow : b+4-i=(b-i-1)+1+4:=by omega
  have nz:(n:ℚ)≠0:=by exact_mod_cast nn.ne'
  have hm:(n:ℚ)=(p:ℚ)*u:=by exact_mod_cast hu
  have id : bernoulli i*((b+4).choose i:ℚ)*(n:ℚ)^(b+4-i)/(n:ℚ)^4 =
      (p*bernoulli i)*u*((b+4).choose i:ℚ)*(n:ℚ)^(b-i-1) := by
    rw [hpow,pow_add _ _ 4,pow_succ];field_simp;rw [hm];ring
  rw [id]
  exact (integers p).mul_mem ((integers p).mul_mem ((integers p).mul_mem (p_bernoulli hp i)
    (natCast_mem (integers p) u)) (natCast_mem (integers p) _))
    ((integers p).pow_mem (natCast_mem (integers p) _) _)

private theorem principal {n p b:ℕ} [Fact p.Prime] (hp:7≤p) (nform:n=b+5)
    (eb:Even b) (pn:p∣n) (nd:¬p-1∣b) (sq:n^4∣∑i∈range n,i^(b+3)) :
    bernoulli (b+2)*((b+4).choose (b+2):ℚ)/(n:ℚ)^2 ∈integers p := by
  have nn:0<n:=by omega
  have bpos:0<b:=by have :=Nat.le_of_dvd nn pn;omega
  have nz:(n:ℚ)≠0:=by exact_mod_cast nn.ne'
  let f (i:ℕ) := bernoulli i*((b+4).choose i:ℚ)*(n:ℚ)^(b+4-i)/(n:ℚ)^4
  have integral : (∑i∈range (b+4),f i)∈integers p := by
    obtain ⟨c,hc⟩:=sq
    have faul:=sum_range_pow n (b+3)
    have scast : (∑i∈range n,(i:ℚ)^(b+3))=(n:ℚ)^4*c:=by exact_mod_cast hc
    rw [scast,←Finset.sum_div] at faul
    have den:(b+3+1:ℚ)≠0:=by positivity
    have alg: (∑i∈range (b+4),f i)= (b+3+1:ℚ)*c := by
      unfold f;rw [←Finset.sum_div]
      rw [div_eq_iff (pow_ne_zero 4 nz)]
      push_cast at faul
      have v:=(eq_div_iff den).mp faul
      linear_combination -v
    rw [alg];exact (integers p).mul_mem (by exact_mod_cast natCast_mem (integers p) (b+3+1)) (natCast_mem (integers p) c)
  have early : (∑i∈range b,f i)∈integers p :=
    (integers p).sum_mem (fun i hi=>scaled_terms (by omega : 5≤p) nn pn i (mem_range.mp hi))
  have fb : f b∈integers p := by
    have nb:=bernoulli_integral bpos eb nd
    have eq:f b=bernoulli b*((b+4).choose b:ℚ):=by dsimp [f];rw [show b+4-b=4 by omega];field_simp
    rw [eq];exact (integers p).mul_mem nb (natCast_mem (integers p) _)
  have odd1:Odd (b+1):=by obtain ⟨t,ht⟩:=eb;exact ⟨t,by omega⟩
  have odd3:Odd (b+3):=by obtain ⟨t,ht⟩:=eb;exact ⟨t+1,by omega⟩
  have z1:f (b+1)=0:=by simp [f,bernoulli_eq_zero_of_odd odd1 (by omega)]
  have z3:f (b+3)=0:=by simp [f,bernoulli_eq_zero_of_odd odd3 (by omega)]
  rw [Finset.sum_range_succ,Finset.sum_range_succ,Finset.sum_range_succ,Finset.sum_range_succ,z1,z3,add_zero,add_zero] at integral
  have last:= (integers p).sub_mem integral ((integers p).add_mem early fb)
  rw [add_sub_cancel_left] at last
  have eq:f (b+2)=bernoulli (b+2)*((b+4).choose (b+2):ℚ)/(n:ℚ)^2:=by
    dsimp [f];rw [show b+4-(b+2)=2 by omega];field_simp
  simpa only [eq] using last

private theorem numerator_of_scaled_integral {p n a c:ℕ} [Fact p.Prime] (q:ℚ)
    (nn:0<n) (pn:p^a∣n) (pc:p.Coprime c)
    (mem:q*c/(n:ℚ)^2∈integers p) : p^(2*a)∣q.num.natAbs := by
  let x:=q*c/(n:ℚ)^2
  have dx:¬p∣x.den:=(integral_iff _).mp mem
  have nz:(n:ℚ)≠0:=by exact_mod_cast nn.ne'
  have alg : (x.num:ℚ)*q.den*(n:ℚ)^2=q.num*c*x.den := by
    have h : (x.num:ℚ)/x.den=((q.num:ℚ)/q.den)*c/(n:ℚ)^2 := by
      rw [Rat.num_div_den,Rat.num_div_den]
    have xd:(x.den:ℚ)≠0:=by exact_mod_cast x.den_ne_zero
    have qd:(q.den:ℚ)≠0:=by exact_mod_cast q.den_ne_zero
    field_simp at h;linear_combination h
  have ints : x.num*(q.den:ℤ)*(n:ℤ)^2=q.num*c*x.den := by exact_mod_cast alg
  have natid:=congrArg Int.natAbs ints
  simp only [Int.natAbs_mul,Int.natAbs_pow,Int.natAbs_natCast] at natid
  have left:p^(2*a)∣n^2 := by
    rw [mul_comm 2 a,pow_mul];exact pow_dvd_pow_of_dvd pn 2
  have prod := dvd_mul_of_dvd_right left (x.num.natAbs*q.den)
  rw [natid,mul_assoc] at prod
  exact ((pc.mul_right ((Fact.out : p.Prime).coprime_iff_not_dvd.mpr dx)).pow_left (2*a)).dvd_of_dvd_mul_right prod

/-- If p−1 does not divide n−5, a counterexample forces the full square of
each p-power divisor of n to divide the Bernoulli numerator at n−3. -/
theorem square_bernoulli {n p a:ℕ} (hp:p.Prime) (large:7≤p) (on:Odd n)
    (pos:0<a) (dvd:p^a∣n) (nonres:¬p-1∣n-5)
    (bad:n^4∣∑i∈Ico 1 n,i^(n-2)) : p^(2*a)∣(bernoulli (n-3)).num.natAbs := by
  let _ : Fact p.Prime:=⟨hp⟩
  have pn:= (dvd_pow_self _ pos.ne').trans dvd
  have lg:=Nat.le_of_dvd on.pos pn
  let b:=n-5
  have nf:n=b+5:=by dsimp [b];omega
  have ev:Even b:=by obtain ⟨j,hj⟩:=on;exact ⟨j-2,by dsimp [b];omega⟩
  have exp:n-2=b+3:=by omega
  have exp':n-3=b+2:=by omega
  have cd:p.Coprime ((b+4).choose (b+2)) := by
    apply hp.coprime_iff_not_dvd.mpr
    intro h
    have id:2*((b+4).choose (b+2))=(b+4)*(b+3) := by
      rw [Nat.choose_symm_of_eq_add (show b+4=(b+2)+2 by omega),Nat.choose_two_right]
      have even:2∣(b+4)*(b+3):=dvd_mul_of_dvd_left (show 2∣b+4 from ev.add (by decide : Even 4) |>.two_dvd) _
      rw [show b+4-1=b+3 by omega,Nat.mul_div_cancel' even]
    have d:=(dvd_mul_of_dvd_right h 2);rw [id] at d
    rcases hp.dvd_mul.mp d with d|d
    · have dd:p∣1:=by apply (Nat.dvd_add_left d).mp;simpa only [nf,show b+4+1=b+5 by omega,add_comm 1 (b+4)] using pn
      exact hp.not_dvd_one dd
    · have dd:p∣2:=by apply (Nat.dvd_add_left d).mp;simpa only [nf,show b+3+2=b+5 by omega,add_comm 2 (b+3)] using pn
      have :=Nat.le_of_dvd (by decide : 0<2) dd;omega
  rw [exp] at bad
  have split:=sum_range_add_sum_Ico (fun i:ℕ=>i^(b+3)) on.pos
  have same:(∑i∈Ico 1 n,i^(b+3))=∑i∈range n,i^(b+3):=by simpa using split
  rw [same] at bad
  rw [exp']
  exact numerator_of_scaled_integral _ on.pos dvd cd (principal large nf ev pn nonres bad)

end OMA.BernoulliScreen284760
