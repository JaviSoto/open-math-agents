import CubicBernoulliAll284759
import CubicCofactorBound284759

namespace OMA.CubicTests284759
open Nat Finset

abbrev passes (n e:ℕ) := n^3∣∑i∈Icc 1 (n-1),i^e

/-- Ordinary cubic sums, half-exponent cubic sums, and the finite
list of possible largest primes for each smaller odd cofactor. -/
theorem tests :
    (∀n:ℕ, 0<n → (passes n (n-2) ↔ Odd n ∧ n∣(bernoulli (n-3)).num.natAbs)) ∧
    (∀n:ℕ, n%4=3 → (passes n ((n-1)/2) ↔ n∣(bernoulli ((n-3)/2)).num.natAbs)) ∧
    (∀p m:ℕ, p.Prime → m < p → 7 ≤ m → Odd m → passes (p*m) (p*m-2) →
      p∣(bernoulli (m-3)).num.natAbs) :=
  ⟨fun _ h=>CubicBernoulliAll284759.original_all h,
   fun _ h=>CubicBernoulliAll284759.half_all h,
   fun _ _ pp gt lo om h=>CubicCofactorBound284759.bound pp gt lo om h⟩

#print axioms tests
end OMA.CubicTests284759
