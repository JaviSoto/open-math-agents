import BernoulliScreen284760

/-! At every sufficiently large prime dividing the upper summation
limit, compare the entire even-power sum with n times a Bernoulli
number modulo the full square of the p-part of n. -/
namespace OMA.CubicBernoulliLocal284759
open Finset Nat
open private OMA.BernoulliScreen284760.p_bernoulli from BernoulliScreen284760
open private Bernoulli.not_dvd_den_bernoulli_add_indicator Bernoulli.vonStaudtIndicator
  from Mathlib.NumberTheory.Bernoulli

abbrev localRing (p:ℕ) [Fact p.Prime] := (Rat.padicValuation p).integer

private theorem odd_prime_scaled {p:ℕ} [Fact p.Prime] (hp:3≤p) (i:ℕ) :
    (p:ℚ)*bernoulli i∈localRing p := by
  by_cases big:5≤p
  · exact OMA.BernoulliScreen284760.p_bernoulli big i
  have prime:=Fact.out (p:=p.Prime)
  have eq:p=3 := by interval_cases p <;> norm_num at *
  subst p
  by_cases iz:i=0
  · subst i;simp
  by_cases io:i=1
  · subst i;apply Rat.padicValuation_le_one_iff.mpr;norm_num [bernoulli_one]
  rcases Nat.even_or_odd i with even|odd
  · obtain ⟨k,hk⟩:=even
    have ik:i=2*k:=by omega
    subst i
    have hd:=Bernoulli.not_dvd_den_bernoulli_add_indicator (p:=3) (k:=k) (by omega)
    have frac:bernoulli (2*k)+1/3∈localRing 3 := Rat.padicValuation_le_one_iff.mpr
      (by simpa [Bernoulli.vonStaudtIndicator] using hd)
    have alg:3*bernoulli (2*k)=3*(bernoulli (2*k)+1/3)-1:=by ring
    rw [ik]
    norm_num only [Nat.cast_ofNat]
    rw [alg]
    exact (localRing 3).sub_mem ((localRing 3).mul_mem (by exact_mod_cast natCast_mem (localRing 3) 3) frac)
      (localRing 3).one_mem
  · rw [bernoulli_eq_zero_of_odd odd (by omega),mul_zero];exact (localRing 3).zero_mem

theorem inverse_mem {p d:ℕ} [Fact p.Prime] (hd:¬p∣d) :
    (d:ℚ)⁻¹∈localRing p := by
  apply Rat.padicValuation_le_one_iff.mpr
  by_cases dz : d=0
  · exact False.elim (hd (dz ▸ dvd_zero _))
  simpa [Rat.den_inv,Int.natAbs_natCast,dz] using hd

theorem error {p n b:ℕ} [Fact p.Prime] (big:3≤p) (nn:0<n) (pn:p∣n)
    (even:Even b) (bp:0<b) (unit:¬p∣b+3) :
    ((∑i∈range n,(i:ℚ)^(b+2))/(n:ℚ)^2 - bernoulli (b+2)/n)∈localRing p := by
  let S:=∑i∈range n,(i:ℚ)^(b+2)
  let F (i:ℕ):=bernoulli i*((b+3).choose i:ℚ)*(n:ℚ)^(b+3-i)/(n:ℚ)^2
  have nz : (n:ℚ)≠0:=by exact_mod_cast nn.ne'
  obtain ⟨u,nu⟩:=pn
  have np : (n:ℚ)=(p:ℚ)*u:=by exact_mod_cast nu
  have early:(∑i∈range (b+1),F i)∈localRing p := by
    apply (localRing p).sum_mem
    intro i hi
    have ib:=mem_range.mp hi
    have form : F i=(p*bernoulli i)*u*((b+3).choose i:ℚ)*(n:ℚ)^(b-i) := by
      dsimp [F];rw [show b+3-i=(b-i)+1+2 by omega,pow_add _ _ 2,pow_succ]
      field_simp;rw [np];ring
    rw [form]
    exact (localRing p).mul_mem ((localRing p).mul_mem ((localRing p).mul_mem
      (odd_prime_scaled big i) (natCast_mem _ _)) (natCast_mem _ _))
      ((localRing p).pow_mem (natCast_mem _ _) _)
  have odd:Odd (b+1):=by obtain ⟨j,h⟩:=even;exact ⟨j,by omega⟩
  have penult:F (b+1)=0:=by simp [F,bernoulli_eq_zero_of_odd odd (by omega)]
  have final:F (b+2)=(b+3:ℚ)*bernoulli (b+2)/n := by
    dsimp only [F];rw [Nat.choose_succ_self_right,show b+3-(b+2)=1 by omega,pow_one]
    push_cast;field_simp;ring
  have faul:=sum_range_pow n (b+2)
  rw [←Finset.sum_div] at faul
  push_cast at faul
  have nonzero:(b+2+1:ℚ)≠0:=by positivity
  have all:(∑i∈range (b+3),F i)=(b+3:ℚ)*S/(n:ℚ)^2 := by
    dsimp only [F,S];rw [←Finset.sum_div]
    congr 1
    have v:=(eq_div_iff nonzero).mp faul
    linear_combination -v
  rw [Finset.sum_range_succ,Finset.sum_range_succ,penult,add_zero,final] at all
  have id : S/(n:ℚ)^2-bernoulli (b+2)/n =
      (∑i∈range (b+1),F i)*((b+3:ℕ):ℚ)⁻¹ := by
    push_cast
    field_simp [nz] at all ⊢
    linear_combination -all
  rw [id]
  exact (localRing p).mul_mem early (inverse_mem unit)

#print axioms error
end OMA.CubicBernoulliLocal284759
