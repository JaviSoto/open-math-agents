import CubicBernoulliCriterion284759
import PowerSumRegular284760

/-! The odd cubic test is an ordinary divisibility test on the numerator
of one Bernoulli number. Multiplicities in n are retained on both sides. -/
namespace OMA.CubicBernoulliOriginal284759
open Nat Finset
open OMA.CubicBernoulliCriterion284759
open private OMA.PowerSumRegular284760.reflect3 OMA.PowerSumRegular284760.ico_range from PowerSumRegular284760

theorem reflection {n e:ℕ} (on:Odd n) (oe:Odd e) (large:3≤e) (cop:n.Coprime e) :
    n^3∣∑i∈Icc 1 (n-1),i^e ↔ n^2∣∑i∈range n,i^(e-1) := by
  have nn:=on.pos
  rw [show Icc 1 (n-1)=Ico 1 n by ext x;simp;omega,
    ←OMA.PowerSumRegular284760.ico_range (f:=fun i:ℕ=>i^(e-1)) nn (zero_pow (by omega : e-1≠0))]
  have ref:=OMA.PowerSumRegular284760.reflect3 (e:=e) on oe large
  constructor
  · intro h
    have z:(∑i∈Ico 1 n,(i:ZMod (n^3))^e)=0 := by
      simpa only [Nat.cast_sum,Nat.cast_pow] using (ZMod.natCast_eq_zero_iff _ _).mpr h
    rw [z,mul_zero] at ref
    have dv:n^3∣n*(e*(∑i∈Ico 1 n,i^(e-1))) := by
      apply (ZMod.natCast_eq_zero_iff _ _).mp;push_cast;rw [←mul_assoc];exact ref.symm
    rw [pow_succ'] at dv
    exact (cop.pow_left 2).dvd_of_dvd_mul_left (Nat.dvd_of_mul_dvd_mul_left nn dv)
  · intro h
    have cube:n^3∣n*(∑i∈Ico 1 n,i^(e-1)) := by rw [pow_succ'];exact Nat.mul_dvd_mul_left _ h
    have zero:(n:ZMod (n^3))*(∑i∈Ico 1 n,(i:ZMod (n^3))^(e-1))=0 := by
      simpa only [Nat.cast_mul,Nat.cast_sum,Nat.cast_pow] using (ZMod.natCast_eq_zero_iff _ _).mpr cube
    rw [mul_right_comm,zero,zero_mul] at ref
    have two:n^3∣2*(∑i∈Ico 1 n,i^e):=(ZMod.natCast_eq_zero_iff _ _).mp (by push_cast;exact ref)
    exact ((Nat.coprime_two_right.mpr on).pow_left 3).dvd_of_dvd_mul_left two

theorem test {n e:ℕ} (on:Odd n) (oe:Odd e) (big:5≤e) (cop:n.Coprime e)
    :
    n^3∣∑i∈Icc 1 (n-1),i^e ↔ n∣(bernoulli (e-1)).num.natAbs := by
  rw [reflection on oe (by omega) cop]
  let b:=e-3
  have form:b+2=e-1:=by dsimp [b];omega
  have plus:b+3=e:=by dsimp [b];omega
  have ev:Even b:=by obtain ⟨j,h⟩:=oe;exact ⟨j-1,by dsimp [b];omega⟩
  rw [←form]
  apply even_iff on.pos (by dsimp [b];omega) ev _ (by rwa [plus])
  intro p hp pn
  have pos:=hp.two_le
  have two:=Nat.not_even_iff_odd.mpr on
  by_contra! h
  exact two (even_iff_two_dvd.mpr (by simpa only [show p=2 by omega] using pn))

theorem original {n:ℕ} (big:7≤n) (on:Odd n) :
    n^3∣∑i∈Icc 1 (n-1),i^(n-2) ↔ n∣(bernoulli (n-3)).num.natAbs := by
  have oe:Odd (n-2):=by obtain ⟨j,h⟩:=on;exact ⟨j-1,by omega⟩
  exact test on oe (by omega) ((Nat.coprime_self_sub_right (by omega)).mpr (Nat.coprime_two_right.mpr on))

/-- Conjecture 15 in the same paper: n≡3 (mod 4) and the half-exponent. -/
theorem half {n:ℕ} (big:11≤n) (res:n%4=3) :
    n^3∣∑i∈Icc 1 (n-1),i^((n-1)/2) ↔ n∣(bernoulli ((n-3)/2)).num.natAbs := by
  let e:=(n-1)/2
  have on:Odd n:=⟨e,by dsimp [e];omega⟩
  have oe:Odd e:=⟨n/4,by dsimp [e];omega⟩
  have cp:n.Coprime e:=by
    have rep:n=2*e+1:=by dsimp [e];omega
    rw [rep];simp [Nat.coprime_comm]
  have ix : e-1=(n-3)/2:=by dsimp [e];omega
  rw [←ix]
  exact test on oe (by omega) cp

#print axioms original
#print axioms half
end OMA.CubicBernoulliOriginal284759
