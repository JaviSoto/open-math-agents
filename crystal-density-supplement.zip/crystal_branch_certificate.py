"""Prove disjoint finite branch loci for finitely many crystal polynomials.

Usage: uv run --no-project --with python-flint python crystal_branch_certificate.py 100
For each integer polynomial f, the finite branch locus is cut out by
R(T)=Res_X(f(X)-T,f'(X)). We prove all characteristic-zero R's pairwise
coprime by full-degree reduction and exact Euclidean gcd over a prime field.
"""

from math import comb
from sys import argv

from flint import fmpz_mod_mpoly_ctx, nmod_poly

PRIME = 1_000_000_007


def branch(f, x):
    derivative = f.derivative()
    degree = f.degree() - 1
    # The resultant has degree at most degree in T. Reconstruct by the
    # Newton forward-difference formula in the binomial polynomial basis.
    samples = [int((f - t).resultant(derivative)) for t in range(degree + 1)]
    basis = x**0
    result = x * 0
    for k in range(degree + 1):
        result += samples[0] * basis
        if k < degree:
            samples = [(b - a) % PRIME for a, b in zip(samples, samples[1:])]
            basis = basis * (x - k) * pow(k + 1, -1, PRIME)
    assert result.degree() == degree
    assert result(degree + 1) == (f - (degree + 1)).resultant(derivative)
    return result


def certificate(m: int):
    assert 1 <= m and 2 * m + 2 < PRIME
    x = nmod_poly([0, 1], PRIME)
    # Parabolic family, followed by all positive-parameter rows through m.
    product = branch((2 * x**2 - 1) * (2 * (x + 1) ** 2 - 1), x)
    a, b = x, (x - 1) ** 2
    for j in range(1, m + 1):
        f = (2 * a - 1) * (2 * b - 1)
        assert f.degree() == 2 * j + 1
        current = branch(f, x)
        common = product.gcd(current)
        if common.degree() > 0:
            raise ArithmeticError(f"nontrivial modular gcd at index {j}: {common}")
        product *= current
        a, b = b, (x - 2) * b - a + 2
    print(f"{m+1} branch loci pairwise disjoint; total degree {product.degree()}, prime {PRIME}")


def independent(m: int):
    """Direct bivariate resultant, another prime and a closed binomial formula."""
    prime = 2**31 - 1
    assert 1 <= m and 2 * m + 2 < prime
    ctx = fmpz_mod_mpoly_ctx.get(("d", "t"), prime)
    d, t = ctx.gens()

    def half(r):
        # Generating function in z:
        # z(1+z) / ((1-z) ((1-z)^2-dz)), where d=w-4.
        return sum((comb(r + e + 1, 2 * e + 2) + comb(r + e, 2 * e + 2)) * d**e
                   for e in range(r))

    product = nmod_poly([1], prime)
    for j in range(m + 1):
        if j == 0:
            f = (2 * d**2 - 1) * (2 * (d + 1) ** 2 - 1)
            degree = 4
        else:
            f = (2 * half(j + 1) - 1) * (2 * half(j + 2) - 1)
            degree = 2 * j + 1
        terms = (f - t).resultant(f.derivative(0), 0).to_dict()
        assert all(wdeg == 0 for wdeg, _ in terms)
        current = nmod_poly([int(terms.get((0, k), 0)) for k in range(degree)], prime)
        assert current.degree() == degree - 1
        assert product.gcd(current).is_one(), f"nontrivial modular gcd at {j}"
        product *= current
    print(f"independent run: {m+1} disjoint branch loci, total degree {product.degree()}, prime {prime}")


if __name__ == "__main__":
    independent(int(argv[1])) if "--independent" in argv else certificate(int(argv[1]))
