import OMAReductions.R_Arxiv_1601_03081_crystals_components_unique_R3

/-! We implement the recurrence classification from Abrate, Barbero, Cerruti
and Murru (arXiv:1601.03081, §3) via Vieta descent on the smaller positive
half-component. We then isolate the cubic and parabolic families. -/

namespace OMA.CrystalDensity
open Arxiv.«1601.03081»

/-- The two coordinates are the smaller half-component and the difference of
the half-components, for the parameter w=d+4 of the crystal recurrence. -/
def row (d : ℕ) : ℕ → ℕ × ℕ
  | 0 => (1, d+3)
  | j+1 =>
    let (x,h) := row d j
    (x+h, h+d*(x+h)+2)

def value (d j : ℕ) : ℕ :=
  let (x,h) := row d j
  (2*x-1)*(2*(x+h)-1)

private theorem descent (d : ℕ) : ∀ x y : ℕ, 0<x → x≤y →
    (x+y)^2+1=(d+4)*x*y+2*(x+y) →
    ∃ j, (row d j).1=x ∧ (row d j).1+(row d j).2=y := by
  intro x
  induction x using Nat.strong_induction_on with
  | h x ih =>
    intro y hx hxy eq
    by_cases one : x=1
    · subst x
      have e : y*y = (d+4)*y := by nlinarith only [eq]
      have ey : y=d+4 := Nat.eq_of_mul_eq_mul_right (by omega) e
      exact ⟨0,rfl,by simp [row]; omega⟩
    · let z : ℤ := ((d:ℤ)+2)*x+2-y
      have e : ((x:ℤ)+y)^2+1 = ((d:ℤ)+4)*x*y+2*(x+y) := by exact_mod_cast eq
      have yz : (y:ℤ)*z=((x:ℤ)-1)^2 := by dsimp [z]; nlinarith only [e]
      have pos : 0<z := by
        have : 0 < (y:ℤ)*z := by rw [yz]; exact sq_pos_of_pos (by omega)
        exact pos_of_mul_pos_right this (by positivity)
      have lt : z<x := by
        by_contra! le
        have h := mul_le_mul (show (x:ℤ)≤y by exact_mod_cast hxy) le (by positivity)
          (show (0:ℤ)≤y by positivity)
        nlinarith only [h,yz,show (1:ℤ)<x by omega]
      have back : (z.toNat:ℤ)=z := Int.toNat_of_nonneg pos.le
      have ze : (z.toNat+x)^2+1=(d+4)*z.toNat*x+2*(z.toNat+x) := by
        rw [← Nat.cast_inj (R := ℤ)]
        push_cast
        rw [back]
        dsimp [z]
        nlinarith only [e]
      obtain ⟨j, hj, hnext⟩ := ih z.toNat (by omega) x (by omega) (by omega) ze
      refine ⟨j+1, by simpa [row] using hnext, ?_⟩
      simp only [row, hnext]
      have zsum : z.toNat+y=(d+2)*x+2 := by
        rw [← Nat.cast_inj (R := ℤ)]
        push_cast
        rw [back]
        dsimp [z]
        ring
      nlinarith only [hj,hnext,zsum]

private theorem encode {n a b : ℕ} (h : IsCrystalWithComponents n a b) (ord : a≤b) :
    (n=35 ∧ a=5 ∧ b=7) ∨ ∃ d j, 1≤j ∧ n=value d j ∧
      a=2*(row d j).1-1 ∧ b=2*((row d j).1+(row d j).2)-1 ∧
      (a+b)^2=(d+4)*((a+1)*(b+1)) := by
  obtain ⟨hn, ha, hb, prod, q, hq⟩ :=
    (isCrystalWithComponents_iff_sum_sq_dvd n a b).mp h
  obtain ⟨u, hu⟩ := Nat.Odd.of_mul_left (prod ▸ hn)
  obtain ⟨v, hv⟩ := Nat.Odd.of_mul_right (prod ▸ hn)
  let x := u+1
  let y := v+1
  have hx : 1<x := by dsimp [x]; omega
  have hxy : x≤y := by dsimp [x,y]; omega
  have e : (x+y)^2+1=q*x*y+2*(x+y) := by dsimp [x,y]; rw [hu,hv] at hq; nlinarith only [hq]
  by_cases sm : q<4
  · have eqZ : ((x:ℤ)+y)^2+1=(q:ℤ)*x*y+2*(x+y) := by exact_mod_cast e
    have ub : (q:ℤ)*x*y≤3*x*y := by gcongr; omega
    have hy : y≤4 := by
      by_contra! hlarge
      have hpos : 0<(y:ℤ)*(y-4) := mul_pos (by omega) (by omega)
      nlinarith only [sq_nonneg (2*(x:ℤ)-y-2),hpos,eqZ,ub]
    have only : x=3 ∧ y=4 := by
      have xb : x≤4 := hxy.trans hy
      have finite : ∀ x y q : Fin 5, 2≤x.val → x.val≤y.val → q.val<4 →
          (x.val+y.val)^2+1=q.val*x.val*y.val+2*(x.val+y.val) →
          x.val=3 ∧ y.val=4 := by decide
      exact finite ⟨x,by omega⟩ ⟨y,by omega⟩ ⟨q,by omega⟩ hx hxy sm e
    have : a=5 := by dsimp [x] at only; omega
    have : b=7 := by dsimp [y] at only; omega
    exact Or.inl (by simp_all)
  · obtain ⟨j,hj,hnext⟩ := descent (q-4) x y (by omega) hxy (by simpa [show q-4+4=q by omega] using e)
    have aa : a=2*(row (q-4) j).1-1 := by rw [hj]; dsimp [x]; omega
    have bb : b=2*((row (q-4) j).1+(row (q-4) j).2)-1 := by rw [hnext]; dsimp [y]; omega
    refine Or.inr ⟨q-4,j,?_,by simpa [value,aa,bb] using prod,aa,bb,by
      rw [show q-4+4=q by omega, mul_comm q]; exact hq⟩
    by_contra! hzero
    have : j=0 := by omega
    simp [this,row] at hj
    omega

private theorem row_zero (j : ℕ) :
    row 0 j=((j+1)^2,2*j+3) := by
  induction j with
  | zero => rfl
  | succ j ih => simpa [row,ih,Prod.mk.injEq] using
      (show (j+1)^2+(2*j+3)=(j+1+1)^2 ∧ 2*j+3+2=2*(j+1)+3 from ⟨by ring,by ring⟩)

/-- The classification needed in the uniqueness reduction. -/
theorem classify {n a b : ℕ} (h : IsCrystalWithComponents n a b) (ord : a≤b) :
    (a=5 ∧ b=7) ∨ (∃ d : ℕ, a=2*d+7 ∧ b=2*d^2+12*d+17) ∨
    (∃ j : ℕ, a=2*j^2+4*j+1 ∧ b=2*j^2+8*j+7) ∨
    ∃ q : ℕ, 5≤q ∧ 2*q<a ∧ (a+b)^2=q*((a+1)*(b+1)) := by
  rcases encode h ord with h | ⟨d,j,hj,_,aa,bb,qq⟩
  · exact Or.inl h.2
  right
  by_cases j1 : j=1
  · subst j
    refine Or.inl ⟨d,?_,?_⟩
    · simp [row] at aa; omega
    · simp [row] at bb; ring_nf at bb ⊢; omega
  right
  by_cases d0 : d=0
  · subst d
    rw [row_zero] at aa bb
    simp only at aa bb
    refine Or.inl ⟨j,?_,?_⟩ <;> ring_nf at aa bb ⊢ <;> omega
  right
  refine ⟨d+4,by omega,?_,qq⟩
  have first_mono : Monotone (fun i => (row d i).1) := by
    apply monotone_nat_of_le_succ
    intro i; simp [row]
  have lo := first_mono (show 2≤j by omega)
  change (row d 2).1 ≤ (row d j).1 at lo
  simp [row] at lo
  ring_nf at lo
  omega

end OMA.CrystalDensity

theorem OMA.solution : OMA.R_Arxiv_1601_03081_crystals_components_unique_R3.H1 := by
  intro n a b h ord
  exact OMA.CrystalDensity.classify h ord

