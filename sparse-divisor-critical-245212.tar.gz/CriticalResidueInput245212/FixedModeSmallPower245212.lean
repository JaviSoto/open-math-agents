import ComplementarySize245212

/-! The exponents in a small-dyadic-order restoration can be compared
without taking roots near the moving largest length L. -/
namespace OMA.FixedModeSmallPower245212
open Nat

private theorem bern (L j : ℕ) :
    (L+1)*(L+1)^j≤(L+1)*L^j+j*(L+1)^j := by
  induction j with
  | zero => simp
  | succ j ih =>
    have h:=Nat.mul_le_mul_right L ih
    rw [pow_succ,pow_succ]
    nlinarith only [h,Nat.zero_le (j*(L+1)^j)]

private theorem step (m L : ℕ) (h : m≤L) : (L+1)^m≤(m+1)*L^m := by
  have coeff : L+1+(m+1)*m≤(m+1)*(L+1):=by nlinarith only [Nat.mul_le_mul_left m h]
  have left:=Nat.mul_le_mul_right ((L+1)^m) coeff
  have right:=Nat.mul_le_mul_left (m+1) (bern L m)
  have out : (L+1)*(L+1)^m≤(L+1)*((m+1)*L^m):=by nlinarith only [left,right]
  exact Nat.le_of_mul_le_mul_left out (Nat.succ_pos _)

theorem compare {q L : ℕ} (qp : 1≤q) (le : q≤L) : L^(q-1)≤q^(L-1) := by
  obtain ⟨d,rfl⟩:=Nat.exists_eq_add_of_le le
  clear le
  induction d with
  | zero => simp
  | succ d ih =>
    have eq : q+(d+1)-1=(q+d-1)+1:=by omega
    rw [eq,pow_succ]
    have s:=step (q-1) (q+d) (by omega)
    rw [Nat.sub_add_cancel qp] at s
    exact s.trans ((Nat.mul_le_mul_left q ih).trans_eq (Nat.mul_comm ..))

theorem slope {L q r b d : ℕ} (q0 : 2≤q) (qL : q≤L) (rL : r≤L)
    (long : b+1=L) (short : 32*(d+1)≤27*q) (big : 16*140^2≤L) :
    32*L^3*r^d<q^b := by
  have up : 32*L^3*r^d≤L^(d+4):=calc
    _ ≤ L*L^3*L^d := Nat.mul_le_mul (Nat.mul_le_mul_right _ (by omega)) (Nat.pow_le_pow_left rL _)
    _ = _ := by rw [pow_add];ring
  apply up.trans_lt
  by_cases large : 64≤q
  · have hp:=Nat.pow_lt_pow_right (by omega : 1<L) (show d+4<q-1 by omega)
    exact hp.trans_le (by simpa only [show L-1=b by omega] using compare (by omega : 1≤q) qL)
  · have tall : 16*((d+4)+1)^2≤L:= (Nat.mul_le_mul_left 16
        (Nat.pow_le_pow_left (by omega : d+4+1≤140) 2)).trans big
    have grow:=OMA.ComplementarySize245212.absorb tall
    apply (pow_lt_pow_iff_left₀ (Nat.zero_le _) (Nat.zero_le _) (by decide : (2:ℕ)≠0)).mp
    calc
      (L^(d+4))^2=L^(2*(d+4)):=by rw [mul_comm 2 (d+4),pow_mul]
      _ ≤ 2^L:=grow
      _ ≤ q^L:=Nat.pow_le_pow_left q0 _
      _ < q^(b*2):=Nat.pow_lt_pow_right (by omega) (by omega)
      _ = (q^b)^2:=pow_mul ..

#print axioms slope
end OMA.FixedModeSmallPower245212
