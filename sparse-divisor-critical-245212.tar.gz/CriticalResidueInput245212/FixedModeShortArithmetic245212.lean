import FixedModeSmallSetup245212
import FixedModeSmallForce245212
import ArbitraryMixedFinite245212

/-! Arithmetic conclusion for bounded physical k and large rank, using
only the two local strength estimates for a family with at least five slots. -/
namespace OMA.FixedModeShortArithmetic245212
open Nat Finset ArithmeticFunction OMA.FixedRankGap245212 OMA.FixedModeRestore245212
open OMA.FixedModeProduct245212 (dropped exactSet mult)
open OMA.FixedModeAnyProduct245212
open OMA.ThreeMovingOriginal245212 (F G)
open OMA.Smooth245212 (total W)
open scoped ArithmeticFunction.sigma
open private OMA.FixedRankHeight245212.identities from FixedRankHeight245212

def fixedExp (r : ℕ) := 1+OMA.FixedModeOriginal245212.exponent r*r

theorem weights (k : ℕ) : 0<G k ∧ G k≤F k := by
  refine ⟨(OMA.FixedRankHeight245212.identities k).1,?_⟩
  cases k with
  | zero=>decide
  | succ k=>
    rw [(OMA.FixedRankHeight245212.identities (k+1)).2.2]
    exact (Nat.le_mul_of_pos_left _ (Nat.succ_pos k)).trans (Nat.le_add_right _ _)

theorem rank_pref {r} (k : ℕ) (c : Family r) (b : Fin r→Option Bool) :
    (pref k c b).primeFactors.card≤r+1 := by
  let s:=(univ : Finset (Fin r)).image c.p
  have cover : (pref k c b).primeFactors⊆insert 2 s:=by
    intro z zm
    have pr:=prime_of_mem_primeFactors zm
    have dv:=dvd_of_mem_primeFactors zm
    obtain two|prod:=pr.dvd_mul.mp dv
    · have same:=(Nat.prime_dvd_prime_iff_eq pr Nat.prime_two).mp (pr.dvd_of_dvd_pow two)
      exact mem_insert.mpr (Or.inl same)
    · obtain ⟨i,_,di⟩:=(pr.prime.dvd_finsetProd_iff _).mp prod
      have :=(Nat.prime_dvd_prime_iff_eq pr (c.prime i)).mp (pr.dvd_of_dvd_pow di)
      exact mem_insert_of_mem (mem_image.mpr ⟨i,mem_univ _,this.symm⟩)
  have card : s.card=r:=by dsimp [s];rw [card_image_of_injective _ c.inj];simp
  exact (card_le_card cover).trans ((card_insert_le _ _).trans_eq (by rw [card]))

theorem small {r k} (c : Family r) (b : Fin r→Option Bool) {Q : ℕ}
    (two : 2^k≤c.L) (Qcap : Q≤c.L^OMA.FixedModeOriginal245212.exponent r)
    (rule : ∀i,b i=if c.p i^c.e i≤Q then none else some (decide (c.p i≤Q))) :
    pref k c b≤(c.L+1)^fixedExp r := by
  let D:=OMA.FixedModeOriginal245212.exponent r
  let t:=c.L+1
  have two : 2^k≤t^1:=by simpa only [pow_one] using two.trans (Nat.le_succ _)
  have per i (mem:i∈exactSet b) : c.p i^c.e i≤t^D:=by
    have none:=(mem_filter.mp mem).2
    rw [rule] at none
    have v : c.p i^c.e i≤Q:=by split at none <;> simp_all
    exact (v.trans Qcap).trans (Nat.pow_le_pow_left (Nat.le_succ _) _)
  have ec : (exactSet b).card≤r:=by simpa using card_le_card (subset_univ (exactSet b))
  have powers : (∏i∈exactSet b,c.p i^c.e i)≤t^(D*r):=by
    calc
      _ ≤ ∏_i∈exactSet b,t^D:=prod_le_prod' per
      _ = t^(D*(exactSet b).card):=by simp [←pow_mul]
      _ ≤ _:=Nat.pow_le_pow_right (by dsimp [t];omega) (Nat.mul_le_mul_left _ ec)
  rw [fixedExp,pow_add]
  exact Nat.mul_le_mul two powers

theorem bounded {r k} (c : Family r) (smallK : k<256)
    (odd : ∀i,Odd (c.p i)) (large : OMA.FixedModeSmallSetup245212.limit r≤c.L)
    (v : Fin r) (long : c.e v+1=c.L)
    (eqn : OeisA245212.a (2^k*total c.p c.e)=(σ 1 (2^k*total c.p c.e):ℤ))
    (localGain : ∀ (b : Fin r→Option Bool), (∀j,b j=some true → c.p j≤c.L) →
      ∀ (s : Finset (Fin r)) {i}, i≠v → i∉s → b i=some true →
        (G k:ℚ)/(32*(c.L:ℚ)^3*(c.p i:ℚ)^c.e i)≤
        val c b (F k) (G k) (insert i s)-val c b (F k) (G k) s)
    (localRisk : ∀ (b : Fin r→Option Bool) {i : Fin r}, i≠v →
      (F k:ℚ)*ox c b ∅ v<(G k:ℚ)*((c.p v:ℚ)-1)*oy c b ∅ v →
      32*(c.e i+1)≤27*c.p v) :
    c.L≤OMA.ArbitraryMixedFinite245212.cutoff (r+1) (fixedExp r) := by
  let x:=c.L^OMA.FixedTallScalar245212.h r
  obtain ⟨big,cl,rate,f8,coef,power⟩:=OMA.FixedModeSmallSetup245212.scales c smallK large v long
  have actual:=OMA.FixedRankHeight245212.physical c k odd c.inj eqn
  obtain ⟨b,Q,xQ,Qcap,rule,hit⟩:=OMA.FixedModeWitness245212.witness c (F k) (G k) x big coef cl rate actual
  have id:=OMA.FixedRankHeight245212.identities k
  have fg := (weights k).2
  have sum : 2≤F k+G k:=by omega
  have kept:=OMA.FixedModeSmallSetup245212.base_le c sum f8 hit
  have mv : b v≠none:=by rw [rule];simp [(Qcap.trans_lt power).not_ge]
  have tall : 16*140^2≤c.L:=by dsimp only [OMA.FixedModeSmallSetup245212.limit] at large;omega
  obtain ⟨keep,only,weak⟩:=OMA.FixedModeSmallForce245212.force c b id.1 fg tall v long mv kept hit actual
    (localGain b kept) (localRisk b)
  have hp : 0<pref k c b:=mul_pos (Nat.two_pow_pos _) (prod_pos (fun i _=>pow_pos (c.prime i).pos _))
  have cp : 0 < mult c b:=prod_pos (fun _ _=>Nat.succ_pos _)
  have two : 2^k≤c.L:=by
    have pow:=Nat.pow_le_pow_right (by decide : 0<2) (show k≤k+1 by omega)
    have mul : 2^(k+1)≤F k+G k:=by rw [id.2.1];exact Nat.le_mul_of_pos_left _ (Nat.succ_pos _)
    exact pow.trans (mul.trans (by omega))
  have qsmall : Q≤c.L^OMA.FixedModeOriginal245212.exponent r:=by simpa only [x,OMA.FixedModeOriginal245212.exponent,pow_mul] using Qcap
  apply OMA.ArbitraryMixedFinite245212.bounded hp (rank_pref k c b) (c.prime v).two_le (by omega) cp
    (small c b two qsmall rule) (OMA.FixedModeAnySign245212.side k c odd keep only weak hit actual eqn)
  simpa only [long] using equation k c odd keep only hit

end OMA.FixedModeShortArithmetic245212
