import OddDivisorFloor245212

/-! Equality in the geometric odd-divisor floor determines all exponents. -/
namespace OMA.OddDivisorCritical245212
open Nat Finset OMA.OddDivisorFloor245212 OMA.FixedRankInteger245212
private theorem local_eq {e v : ℕ} (eqn : 4*3^v=2^v*(e+1)^2) : e=1 ∨ e=2 := by
  have dvd : 2^v∣4*3^v:=⟨_,eqn⟩
  have cop : (2^v).Coprime (3^v) := ((by decide : Nat.Coprime 2 3).pow_left v).pow_right v
  have four:=cop.dvd_of_dvd_mul_right dvd
  have cap : v≤2:=by
    by_contra! hi
    have low:=Nat.pow_le_pow_right (by decide : 0<2) (show 3≤v by omega)
    have high:=Nat.le_of_dvd (by decide : 0<4) four
    omega
  by_contra! neither
  by_cases big : 3≤e
  · have h:=Nat.pow_le_pow_left (show 4≤e+1 by omega) 2
    interval_cases v <;> norm_num at eqn h <;> omega
  · have z : e=0:=by omega
    subst e;interval_cases v <;> norm_num at eqn

open private OMA.OddDivisorFloor245212.loc from OddDivisorFloor245212
open scoped ArithmeticFunction.sigma

theorem only {n : ℕ} (pos : 0<n) (hit : OeisA245212.a n=(σ 1 n:ℤ))
    (edge : 6^(support n).card=(lengthProd n)^2) :
    ∀p∈support n,n.factorization p=1 ∨ n.factorization p=2 := by
  let s:=support n
  let v (p : ℕ):=(n.factorization p+2).factorization 2
  let left (p : ℕ):=4*3^(v p)
  let right (p : ℕ):=2^(v p)*(n.factorization p+1)^2
  have le p (mem:p∈s) : left p≤right p := (OMA.OddDivisorFloor245212.loc
      (Nat.pos_of_ne_zero (Finsupp.mem_support_iff.mp (mem_erase.mp mem).2))).1
  have rev := scaled_floor (budget pos hit)
  rw [edge] at rev
  intro p mem
  apply local_eq (v:=v p)
  change left p=right p
  by_contra ne
  have lt : left p<right p:=lt_of_le_of_ne (le p mem) ne
  have strict:=prod_lt_prod (s:=s) (fun i _=>by dsimp [left];positivity) le ⟨p,mem,lt⟩
  simp only [left,right,prod_mul_distrib,prod_const,prod_pow_eq_pow_sum,prod_pow] at strict
  exact (not_lt_of_ge rev) strict

theorem counts {n : ℕ} (pos : 0<n) (hit : OeisA245212.a n=(σ 1 n:ℤ))
    (edge : 6^(support n).card=(lengthProd n)^2) :
    (support n).card=2*((support n).filter (fun p=>n.factorization p=2)).card := by
  let s:=support n
  let a:=(s.filter (fun p=>n.factorization p=2)).card
  let b:=(s.filter (fun p=>¬n.factorization p=2)).card
  have pattern:=only pos hit edge
  have len : lengthProd n=3^a*2^b := by
    calc
      _ = ∏p∈s, if n.factorization p=2 then 3 else 2 := by
        apply prod_congr rfl
        intro p mem
        rcases pattern p mem with h|h <;> simp [h]
      _ = _ := by rw [prod_ite];simp only [prod_const];rfl
  have at3:=congrArg (fun z : ℕ=>z.factorization 3) edge
  rw [len] at at3
  have six : (6:ℕ).factorization 3=1 := by
    rw [show 6=2*3 by decide,Nat.factorization_mul (by decide) (by decide),Finsupp.add_apply,
      Nat.factorization_eq_zero_of_not_dvd (by decide : ¬3∣2),(by decide : Nat.Prime 3).factorization_self]
  simp only [Nat.factorization_pow,Finsupp.coe_smul,Pi.smul_apply,smul_eq_mul,six,mul_one,
    Nat.factorization_mul (by positivity : 3^a≠0) (by positivity : 2^b≠0),Finsupp.add_apply,
    (by decide : Nat.Prime 3).factorization_self,Nat.factorization_eq_zero_of_not_dvd (by decide : ¬3∣2),
    mul_zero,add_zero] at at3
  exact at3

#print axioms counts
end OMA.OddDivisorCritical245212
