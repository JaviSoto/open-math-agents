import FixedModeSign245212
/-! The original equality produces the integer pole equation, strict side,
and a polynomially bounded exact cofactor at every fixed rank for k≥256. -/
namespace OMA.FixedModeArithmetic245212
open Nat Finset ArithmeticFunction OMA.FixedRankGap245212 OMA.FixedModeProduct245212
open OMA.Smooth245212 (W total)
open OMA.ThreeMovingOriginal245212 (F G)
open scoped ArithmeticFunction.sigma

def exponent (r : ℕ) := 2*OMA.FixedRankHeight245212.exponent r+1+
  OMA.FixedModeOriginal245212.exponent r*r

theorem rank_pref {r} (c : Family r) (b : Fin r→Option Bool) :
    (pref c b).primeFactors.card≤r+1 := by
  let s:=(univ : Finset (Fin r)).image c.p
  have cover : (pref c b).primeFactors⊆insert 2 s:=by
    intro z zm
    have pr:=prime_of_mem_primeFactors zm
    have dv:=dvd_of_mem_primeFactors zm
    obtain two|prod:=pr.dvd_mul.mp dv
    · have same:=(Nat.prime_dvd_prime_iff_eq pr Nat.prime_two).mp (pr.dvd_of_dvd_pow two)
      exact mem_insert.mpr (Or.inl same)
    · obtain ⟨i,_,di⟩:=(pr.prime.dvd_finsetProd_iff _).mp prod
      have :=(Nat.prime_dvd_prime_iff_eq pr (c.prime i)).mp (pr.dvd_of_dvd_pow di)
      exact mem_insert_of_mem (mem_image.mpr ⟨i,mem_univ _,this.symm⟩)
  have card : s.card=r:=by dsimp [s];rw [card_image_of_injective _ c.inj];simp
  exact (card_le_card cover).trans ((card_insert_le _ _).trans_eq (by rw [card]))

theorem small {r} (c : Family r) (odd : ∀i,Odd (c.p i)) (b : Fin r→Option Bool) {Q : ℕ}
    (large : OMA.FixedTallScalar245212.threshold r 1≤c.L)
    (Qcap : Q≤c.L^OMA.FixedModeOriginal245212.exponent r)
    (rule : ∀i,b i=if c.p i^c.e i≤Q then none else some (decide (c.p i≤Q)))
    (eqn : OeisA245212.a (2^c.k*total c.p c.e)=(σ 1 (2^c.k*total c.p c.e):ℤ)) :
    pref c b≤(c.L+1)^exponent r := by
  let E:=OMA.FixedRankHeight245212.exponent r
  let D:=OMA.FixedModeOriginal245212.exponent r
  let t:=c.L+1
  have e:=OMA.FixedRankHeight245212.original c.k c.L c.p c.e c.prime odd c.inj c.positive c.longest c.cap eqn
  have C : OMA.SingleMovingHeight245212.constant E≤t:=by
    dsimp only [OMA.FixedTallScalar245212.threshold] at large
    dsimp only [t,E];omega
  have two : 2^c.k≤t^(2*E+1):=e.trans (by rw [pow_succ'];exact Nat.mul_le_mul_right _ C)
  have per i (mem:i∈exactSet b) : c.p i^c.e i≤t^D:=by
    have none:=(mem_filter.mp mem).2
    rw [rule] at none
    have v : c.p i^c.e i≤Q:=by split at none <;> simp_all
    exact (v.trans Qcap).trans (Nat.pow_le_pow_left (Nat.le_succ _) _)
  have ec : (exactSet b).card≤r:=by simpa using card_le_card (subset_univ (exactSet b))
  have powers : (∏i∈exactSet b,c.p i^c.e i)≤t^(D*r):=by
    calc
      _ ≤ ∏_i∈exactSet b,t^D:=prod_le_prod' per
      _ = t^(D*(exactSet b).card):=by simp [←pow_mul]
      _ ≤ _:=Nat.pow_le_pow_right (by dsimp [t];omega) (Nat.mul_le_mul_left _ ec)
  rw [exponent,pow_add]
  exact Nat.mul_le_mul two powers

theorem original {r} (c : Family r) (odd : ∀i,Odd (c.p i))
    (klarge : 256≤c.k) (large : OMA.FixedTallScalar245212.threshold r 1≤c.L)
    (v : Fin r) (long : c.e v+1=c.L)
    (eqn : OeisA245212.a (2^c.k*total c.p c.e)=(σ 1 (2^c.k*total c.p c.e):ℤ)) :
    ∃ h q C : ℕ, 0<h ∧ h.primeFactors.card≤r+1 ∧ 2≤q ∧ 0<c.L ∧ 0<C ∧
      h≤(c.L+1)^exponent r ∧ C*W h<(q-1)*σ 1 h ∧
      (2*h*σ 0 h)*c.L*C*(q-1)^2=q*(W h*C*(c.L*(q-1)-1)+σ 1 h*(q-1)) := by
  obtain ⟨b,Q,_,Qcap,rule,hit,keep,only,weak⟩:=OMA.FixedModeOriginal245212.original c odd klarge large v long eqn
  have actual:=OMA.FixedRankHeight245212.physical c c.k odd c.inj eqn
  have hp : 0<pref c b:=mul_pos (Nat.two_pow_pos _) (prod_pos (fun i _=>pow_pos (c.prime i).pos _))
  have Cp : 0 < mult c b:=prod_pos (fun _ _=>Nat.succ_pos _)
  refine ⟨pref c b,c.p v,mult c b,hp,rank_pref c b,(c.prime v).two_le,by omega,Cp,
    small c odd b large Qcap rule eqn,OMA.FixedModeSign245212.side c odd keep only weak hit actual eqn,?_⟩
  simpa only [long] using equation c odd keep only hit

end OMA.FixedModeArithmetic245212
