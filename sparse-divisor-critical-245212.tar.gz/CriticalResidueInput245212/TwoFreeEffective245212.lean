import TwoFreeEffectivePole245212
import RankThreeFourSmallHarmonic245212

/-! A computable height for every extension of a fixed positive integer by
two arbitrary distinct odd prime powers, including exact Euler resonance. -/
namespace OMA.TwoFreeEffective245212
open Nat Finset ArithmeticFunction OMA.Smooth245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallHarmonic245212 OMA.RankThreeFourSmallBounds245212
open OMA.TwoFreeEffectivePole245212 (scalar poleExponent)
open scoped ArithmeticFunction.sigma
open private OMA.PairHeight245212.combine from PairHeight245212

def lastCut (A S H P : ℕ) := P^4+scalar A S+H+2*A*P+2
def finiteExponent (A S Z : ℕ) := 4*A*Z+2*(A+S*Z^2)
def looseExponent (A S P : ℕ) := 2*A+4*S*P+poleExponent A S P
def atomBound (A S H : ℕ) :=
  let P:=primeCut A S H
  let Z:=lastCut A S H P
  max (Z^finiteExponent A S Z) (P^looseExponent A S P)

/-- The factor 1 also covers absent prime powers. -/
def height (h : ℕ) := 4*(h*max 1 (atomBound (W h) (σ 1 h) (2*(h*σ 0 h))))^7

private theorem bounded_pair {A S H p q a d Z : ℕ} (hp : p.Prime) (hq : q.Prime)
    (ap : 0<A) (sp : 0<S) (pq : p<q) (qz : q≤Z) (b : Bal A S H p q a d) :
    min a d ≤ finiteExponent A S Z := by
  by_cases high : H*(p-1)*(q-1)<A*p*q
  · have raw:=(short_pair hp hq high (strict hp hq sp b)).trans (Nat.div_le_self _ _)
    have x : 2*A*(p+q)≤4*A*Z := by
      nlinarith only [Nat.mul_le_mul_left A pq.le,Nat.mul_le_mul_left A qz]
    unfold finiteExponent;omega
  · have raw:=(under_pair hp hq ap b (le_of_not_gt high)).trans (Nat.div_le_self _ _)
    have x : 2*(A+S*(p-1)*(q-1))≤2*(A+S*Z^2) := by
      rw [sq,←mul_assoc S Z Z];gcongr <;> omega
    unfold finiteExponent;omega

theorem atom {h p q a d : ℕ} (hh : 0<h) (hp : p.Prime) (hq : q.Prime) (op : 3≤p)
    (cp : h.Coprime p) (cq : h.Coprime q) (pq : p<q) (ap : 0<a) (dp : 0<d)
    (eqn : OeisA245212.a (h*p^a*q^d)=(σ 1 (h*p^a*q^d):ℤ)) :
    min (p^a) (q^d) ≤ atomBound (W h) (σ 1 h) (2*(h*σ 0 h)) := by
  let A:=W h
  let S:=σ 1 h
  let H:=2*(h*σ 0 h)
  let P:=primeCut A S H
  let Z:=lastCut A S H P
  have wp : 0<A := by
    dsimp [A];rw [w_apply]
    exact sum_pos' (fun _ _=>Nat.zero_le _) ⟨1,Nat.one_mem_divisors.mpr hh.ne',by simp⟩
  have sp : 0<S := sigma_pos 1 h hh.ne'
  have pp : p≤P := first_prime hh hp hq cp cq pq ap dp eqn
  have b : Bal A S H p q a d := by simpa [A,S,H,Bal] using normalized hh hp hq cp cq pq.ne eqn
  by_cases finite : q≤Z
  · apply le_trans _ (le_max_left ..)
    have lim:=bounded_pair hp hq wp sp pq finite b
    have zp : 0<Z := hq.pos.trans_le finite
    rcases le_total a d with ad|da
    · rw [min_eq_left ad] at lim
      exact (min_le_left ..).trans ((Nat.pow_le_pow_left (pq.le.trans finite) a).trans (Nat.pow_le_pow_right zp lim))
    · rw [min_eq_right da] at lim
      exact (min_le_right ..).trans ((Nat.pow_le_pow_left finite d).trans (Nat.pow_le_pow_right zp lim))
  have short : a ≤ looseExponent A S P := by
    rcases lt_trichotomy (A*p) (H*(p-1)) with low|pole|high
    · rcases under_first hp hq b low with short|impossible
      · have cap:= short.trans (Nat.div_le_self _ _)
        have ext : 4*S*(p-1)≤4*S*P := Nat.mul_le_mul_left _ ((Nat.sub_le _ _).trans pp)
        unfold looseExponent;omega
      · have cap:=Nat.div_le_self (2*A*p) (H*(p-1)-A*p)
        have sec:=Nat.mul_le_mul_left (2*A) pp
        dsimp [Z,lastCut] at finite;omega
    · have cap:=OMA.TwoFreeEffectivePole245212.original hh hp hq op cp cq pq ap dp pp pole
          (show P^4≤q by dsimp [Z,lastCut] at finite;omega)
          (show scalar A S<q by dsimp [Z,lastCut] at finite;omega)
          (show H<q by dsimp [Z,lastCut] at finite;omega) eqn
      unfold looseExponent;exact (by omega : a≤2*A+4*S*P+poleExponent (W h) (σ 1 h) P)
    · have cap:=(short_first hp hq high (strict hp hq sp b)).trans (Nat.div_le_self _ _)
      unfold looseExponent;omega
  apply (min_le_left ..).trans (le_trans _ (le_max_right ..))
  exact (Nat.pow_le_pow_left pp a).trans (Nat.pow_le_pow_right (hp.pos.trans_le pp) short)

theorem ordered {h p q a d : ℕ} (hh : 0<h) (hp : p.Prime) (hq : q.Prime) (op : 3≤p)
    (cp : h.Coprime p) (cq : h.Coprime q) (pq : p<q) (ap : 0<a) (dp : 0<d)
    (eqn : OeisA245212.a (h*p^a*q^d)=(σ 1 (h*p^a*q^d):ℤ)) : h*p^a*q^d ≤ height h := by
  let B:=max 1 (atomBound (W h) (σ 1 h) (2*(h*σ 0 h)))
  have small : min (p^a) (q^d)≤B := (atom hh hp hq op cp cq pq ap dp eqn).trans (le_max_right ..)
  have pp:=hp.pos
  have qp:=hq.pos
  rcases le_total (p^a) (q^d) with first|second
  · rw [min_eq_left first] at small
    exact OMA.PairHeight245212.combine (by positivity : 0<h*p^a) (Nat.mul_le_mul_left h small)
      (OMA.PairHeight245212.last_square (by positivity) hq (by omega)
        (cq.mul_left (((coprime_primes hp hq).mpr pq.ne).pow_left a)) dp eqn)
  · rw [min_eq_right second] at small
    rw [mul_right_comm] at eqn ⊢
    exact OMA.PairHeight245212.combine (by positivity : 0<h*q^d) (Nat.mul_le_mul_left h small)
      (OMA.PairHeight245212.last_square (by positivity) hp (by omega)
        (cp.mul_left (((coprime_primes hq hp).mpr pq.ne.symm).pow_left d)) ap eqn)


private theorem absent {h q d : ℕ} (hh : 0<h) (hq : q.Prime) (oq : 3≤q) (cq : h.Coprime q)
    (eqn : OeisA245212.a (h*q^d)=(σ 1 (h*q^d):ℤ)) : h*q^d ≤ height h := by
  let B:=max 1 (atomBound (W h) (σ 1 h) (2*(h*σ 0 h)))
  have hb : h≤h*B := Nat.le_mul_of_pos_right _ (lt_of_lt_of_le (by decide : 0<1) (le_max_left ..))
  by_cases zero : d=0
  · subst d
    change h*1≤4*(h*B)^7
    have hpos : 0<h*B := hh.trans_le hb
    have growth : h*B≤(h*B)^7 := by simpa using Nat.pow_le_pow_right hpos (by decide : 1≤7)
    omega
  · exact OMA.PairHeight245212.combine hh hb (OMA.PairHeight245212.last_square hh hq (by omega) cq (by omega) eqn)

/-- Arbitrary order and arbitrary nonnegative exponents, so this includes
extensions by zero, one or two distinct odd primes. -/
theorem original {h p q a d : ℕ} (hh : 0<h) (hp : p.Prime) (hq : q.Prime) (op : 3≤p) (oq : 3≤q)
    (cp : h.Coprime p) (cq : h.Coprime q) (ne : p≠q)
    (eqn : OeisA245212.a (h*p^a*q^d)=(σ 1 (h*p^a*q^d):ℤ)) : h*p^a*q^d ≤ height h := by
  by_cases empty : a=0
  · subst a;simp only [pow_zero,mul_one] at eqn ⊢;exact absent hh hq oq cq eqn
  by_cases empty' : d=0
  · subst d;simp only [pow_zero,mul_one] at eqn ⊢;exact absent hh hp op cp eqn
  rcases lt_or_gt_of_ne ne with pq|qp
  · exact ordered hh hp hq op cp cq pq (by omega) (by omega) eqn
  · rw [mul_right_comm] at eqn ⊢
    exact ordered hh hq hp oq cq cp qp (by omega) (by omega) eqn


/-- Prime-support form, including the empty odd cofactor m=1. -/
theorem of_rank {h m : ℕ} (hh : 0<h) (om : Odd m) (cop : h.Coprime m)
    (rank : m.primeFactors.card≤2) (eqn : OeisA245212.a (h*m)=(σ 1 (h*m):ℤ)) :
    h*m ≤ height h := by
  classical
  have props {r : ℕ} (mem : r∈m.primeFactors) : r.Prime ∧ 3≤r ∧ h.Coprime r := by
    have pr := Nat.prime_of_mem_primeFactors mem
    have dv := Nat.dvd_of_mem_primeFactors mem
    have od := Nat.coprime_two_left.mp ((Nat.coprime_two_left.mpr om).of_dvd_right dv)
    have ne : r≠2 := by rintro rfl; exact (by decide : ¬Odd 2) od
    exact ⟨pr,lt_of_le_of_ne pr.two_le ne.symm,cop.of_dvd_right dv⟩
  have repr := Nat.prod_primeFactors_pow_factorization om.pos.ne'
  by_cases two : m.primeFactors.card=2
  · obtain ⟨p,q,diff,s⟩:=card_eq_two.mp two
    obtain ⟨hp,op,cp⟩:=props (r:=p) (by simp [s])
    obtain ⟨hq,oq,cq⟩:=props (r:=q) (by simp [s])
    rw [s,prod_insert (by simpa using diff),prod_singleton] at repr
    have target:=congrArg (h*·) repr
    rw [←mul_assoc] at target
    rw [target] at eqn ⊢
    exact original hh hp hq op oq cp cq diff eqn
  by_cases one : m.primeFactors.card=1
  · obtain ⟨p,s⟩:=card_eq_one.mp one
    obtain ⟨hp,op,cp⟩:=props (r:=p) (by simp [s])
    rw [s,prod_singleton] at repr
    have target:=congrArg (h*·) repr
    rw [target] at eqn ⊢
    exact absent hh hp op cp eqn
  have empty : m.primeFactors=∅ := card_eq_zero.mp (by omega)
  rw [empty,prod_empty] at repr
  rw [repr,mul_one]
  let U:=max 1 (atomBound (W h) (σ 1 h) (2*(h*σ 0 h)))
  have hu : h≤h*U := Nat.le_mul_of_pos_right _ (lt_of_lt_of_le (by decide : 0<1) (le_max_left ..))
  have power : h*U≤(h*U)^7 := by simpa using Nat.pow_le_pow_right (hh.trans_le hu) (by decide : 1≤7)
  change h≤4*(h*U)^7;omega

end OMA.TwoFreeEffective245212
