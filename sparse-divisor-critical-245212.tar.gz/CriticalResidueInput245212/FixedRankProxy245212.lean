import FixedRankGap245212
import SingleMovingLoss245212

/-! The actual dyadic deficit exceeds the total possible loss caused by
all risky rounded coordinates, without any comparability assumption. -/
namespace OMA.FixedRankProxy245212
open Nat Finset OMA.FixedRankGap245212 OMA.TwoTallLocal245212
open OMA.ThreeMovingOriginal245212 (G)
variable {r : ℕ}

def deficit (c : Family r) : ℚ := (c.k:ℚ)+1-score c.k 1 (exactX c) (exactY c)

theorem lower (c : Family r) (link : deficit c*(G c.k:ℕ)=((c.k:ℚ)+1)*((∏i,exactX c i)-1)) (i) :
    1≤(2*(c.p i:ℚ))*(G c.k)*(deficit c) := by
  have xb j : 1≤exactX c j:=(ranges (c.prime j) (c.positive j) none).1
  have xi : exactX c i≤∏j,exactX c j := by
    rw [←prod_erase_mul (univ : Finset (Fin r)) (exactX c) (mem_univ i)]
    exact le_mul_of_one_le_left (zero_le_one.trans (xb _)) (one_le_prod (fun j _=>xb j))
  have localBound:=OMA.SingleMovingLoss245212.single_lb (c.prime i) (c.positive i)
  change 1≤(2*(c.p i:ℚ))*(exactX c i-1) at localBound
  have xm : 0≤(∏j,exactX c j)-1:=by linarith only [xi,xb i]
  have more:=mul_nonneg (Nat.cast_nonneg (α:=ℚ) c.k) xm
  have cc : 0≤2*(c.p i:ℚ):=by positivity
  nlinarith only [localBound,mul_le_mul_of_nonneg_left xi cc,mul_nonneg cc more,
    congrArg (fun z:ℚ=>2*(c.p i:ℚ)*z) link]


set_option maxHeartbeats 1200000 in
/-- All coordinates apart from one longest coordinate have nonnegative
restoration, regardless of how many other coordinates there are. -/
theorem separated (c : Family r) (b : Fin r→Option Bool)
    (link : deficit c*(G c.k:ℕ)=((c.k:ℚ)+1)*((∏i,exactX c i)-1)) :
    (c.k+1)*dust c b ≠ c.k*NX c b+NY c b := by
  classical
  obtain ⟨v,vbig⟩:=c.longest
  have gd : 0<deficit c := by
    have h:=lower c link v
    by_contra! n
    have t:=mul_nonpos_of_nonneg_of_nonpos (show 0≤2*(c.p v:ℚ)*(G c.k:ℕ) by positivity) n
    linarith
  intro hit
  have scale:=retained (b:=b) (f:=c.k) (g:=1) (l:=1) (by simp)
    (fun i=>Nat.not_dvd_of_pos_of_lt (by decide) (c.prime i).one_lt) (by simpa using hit)
  let mix (s : Finset (Fin r)) (i : Fin r) := if i∈s then exactX c i else x' c b i
  let miy (s : Finset (Fin r)) (i : Fin r) := if i∈s then exactY c i else y' c b i
  let val (s : Finset (Fin r)):=score c.k 1 (mix s) (miy s)
  have adv (s : Finset (Fin r)) {i} (fresh : i∉s) :
      val s ≤ val (insert i s)+(if i=v then deficit c/4 else 0) := by
    have bound j : 1≤ mix s j ∧ 0≤ miy s j ∧ miy s j≤2/((c.e j:ℚ)+1) := by
      by_cases mem : j∈s
      · have w:=ranges (c.prime j) (c.positive j) none
        simpa only [mix,miy,if_pos mem,exactX,exactY,xx',yy'] using And.intro w.1 w.2.2
      · have w:=ranges (c.prime j) (c.positive j) (b j)
        simpa only [mix,miy,if_neg mem,x',y'] using And.intro w.1 w.2.2
    have size j : miy s j≤1 := (bound j).2.2.trans ((div_le_iff₀ (by positivity)).mpr (by
      have:= (by exact_mod_cast c.positive j : (1:ℚ)≤c.e j);linarith))
    let t:=(univ:Finset (Fin r)).erase i
    let xx:=∏j∈t,mix s j
    let yy:=∏j∈t,miy s j
    have x1 : 1≤xx:=one_le_prod (fun j _=>(bound j).1)
    have y0 : 0≤yy:=prod_nonneg (fun j _=>(bound j).2.1)
    have y1 : yy≤1:=prod_le_one (fun j _=>(bound j).2.1) (fun j _=>size j)
    have sameX : ∏j∈t,mix (insert i s) j=xx := Finset.prod_congr rfl (by
      intro j hj
      have ji:=ne_of_mem_erase hj
      simp [mix,Finset.mem_insert,ji])
    have sameY : ∏j∈t,miy (insert i s) j=yy := Finset.prod_congr rfl (by
      intro j hj
      have ji:=ne_of_mem_erase hj
      simp [miy,Finset.mem_insert,ji])
    have step:=OMA.SingleMovingLoss245212.restore (c.prime i) (c.positive i)
      (by have:=c.kp;omega : 0<c.k) (b i) xx 1 yy 1
      (if i=v then deficit c/4 else 0) x1 le_rfl y0 zero_le_one
      (by simpa only [mul_one] using y1) (by split <;> positivity)
    have bad (bit : b i=some true) (risk : (c.k:ℚ)<((c.p i:ℚ)-1)*(yy*1)) :
        1/(c.p i:ℚ)^(c.e i) ≤ if i=v then deficit c/4 else 0 := by
      simp only [mul_one] at risk
      have u0 : 0≤(c.p i:ℚ)-1:=by have z:=(by exact_mod_cast (c.prime i).one_le : (1:ℚ)≤c.p i);linarith
      have pk : c.k+1<c.p i := by
        have up:=mul_le_mul_of_nonneg_left y1 u0
        exact_mod_cast (show (c.k:ℚ)+1<c.p i by linarith only [up,risk])
      have pL : c.p i≤c.L:=by have:=scale i bit;omega
      have unique : i=v := by
        by_contra iv
        have vm : v∈t:=mem_erase.mpr ⟨Ne.symm iv,mem_univ _⟩
        have rest : ∏j∈t.erase v,miy s j≤1:=prod_le_one (fun j _=>(bound j).2.1) (fun j _=>size j)
        have yv : yy ≤ miy s v := by
          dsimp [yy];rw [←prod_erase_mul t (miy s) vm]
          simpa only [one_mul] using mul_le_mul_of_nonneg_right rest (bound v).2.1
        have base : c.p i≤c.e v+1:=by omega
        have base' : (c.p i:ℚ)-1≤(c.e v:ℚ)+1:=by
          have u:(c.p i:ℚ)≤c.e v+1:=by exact_mod_cast base
          linarith
        have M:=(le_div_iff₀ (by positivity)).mp (bound v).2.2
        have g:=mul_le_mul_of_nonneg_left yv u0
        have h:=mul_le_mul_of_nonneg_right base' (bound v).2.1
        have k8 : (8:ℚ)≤c.k:=by exact_mod_cast c.kp
        nlinarith only [risk,g,h,M,k8]
      rw [if_pos unique]
      have len : c.p i≤c.e i+1:=by simpa [unique,vbig] using pL
      have pw:=OMA.SingleMovingLoss245212.scalar c.kp pk len
      have more:=lower c link i
      have pwq : 8*(c.p i:ℚ)*(G c.k)≤(c.p i:ℚ)^(c.e i):=by exact_mod_cast pw
      apply (div_le_iff₀ (by have:=(c.prime i).pos;positivity : (0:ℚ)<(c.p i:ℚ)^(c.e i))).mpr
      nlinarith only [more,mul_le_mul_of_nonneg_right pwq gd.le]
    have h:=step bad
    dsimp only [val,score];simp only [Nat.cast_one,one_mul]
    rw [←prod_erase_mul univ (mix s) (mem_univ i),←prod_erase_mul univ (miy s) (mem_univ i),
        ←prod_erase_mul univ (mix (insert i s)) (mem_univ i),←prod_erase_mul univ (miy (insert i s)) (mem_univ i)]
    change (c.k:ℚ)*(xx*mix s i)+yy*miy s i≤ _*(_*mix (insert i s) i)+_*miy (insert i s) i+_
    change (c.k:ℚ)*(xx*mix s i)+yy*miy s i≤
      c.k*((∏j∈t,mix (insert i s) j)*mix (insert i s) i)+
      (∏j∈t,miy (insert i s) j)*miy (insert i s) i+_
    rw [sameX,sameY]
    simpa only [mix,miy,if_neg fresh,mem_insert_self,if_true,exactX,exactY,x',y',mul_one,one_mul,
      mul_comm,mul_left_comm,mul_assoc] using h
  have sum (s : Finset (Fin r)) : val ∅ ≤ val s+(if v∈s then deficit c/4 else 0) := by
    induction s using Finset.induction_on with
    | empty=>simp
    | @insert i s fresh ih=>
      have h:=adv s fresh
      by_cases iv : i=v
      · subst i
        simpa [fresh] using ih.trans (by simpa [fresh] using h : val s+(if v∈s then deficit c/4 else 0) ≤ val (insert v s)+deficit c/4)
      · have adv0 : val s≤val (insert i s):=by simpa only [if_neg iv,add_zero] using h
        simpa only [Finset.mem_insert,Ne.symm iv,false_or] using ih.trans
          (add_le_add_left adv0 (if v∈s then deficit c/4 else 0))
  have a:=sum univ
  simp only [val,mix,miy,notMem_empty,if_false,mem_univ,if_true] at a
  have eq:=clear c b c.k 1
  simp only [one_mul] at eq
  rw [←hit] at eq
  push_cast at eq
  have dp : (0:ℚ)<dust c b:=by exact_mod_cast dust_pos c b
  have eq' : score c.k 1 (x' c b) (y' c b)=(c.k:ℚ)+1:=mul_right_cancel₀ dp.ne' eq
  dsimp only [deficit] at a gd
  linarith only [a,eq',gd]

end OMA.FixedRankProxy245212
