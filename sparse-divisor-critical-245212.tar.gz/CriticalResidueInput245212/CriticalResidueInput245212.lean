import CriticalResidueLocal245212
import OddDivisorCritical245212
import SparseDivisorHeight245212
import ThreeMovingDividend245212

/-! The odd part at the critical divisor count has residue 5^(r/2)
modulo eight, for every rank and every dyadic exponent. -/
namespace OMA.CriticalResidueInput245212
open Nat Finset ArithmeticFunction OMA.CriticalResidueLocal245212 OMA.FixedRankInteger245212
open OMA.Smooth245212 (W w_pow w_mult)
open scoped ArithmeticFunction.sigma
open private OMA.DivisorHeight245212.dyadic_moments from ThreeMovingDividend245212

private theorem local_data (p : ℕ) (pr : p.Prime) (od : Odd p) :
    W p=w1 p ∧ σ 1 p=2*s1 p ∧ W (p^2)=2*w2 p ∧ σ 1 (p^2)=s2 p := by
  have w:=w_pow pr 1
  have s:=sigma_one_apply_prime_pow pr (i:=1)
  have ww:=w_pow pr 2
  have ss:=sigma_one_apply_prime_pow pr (i:=2)
  simp only [sum_range_succ,sum_range_zero,pow_zero,pow_one,zero_add,mul_one] at w s ww ss
  obtain ⟨_,l⟩:=lin p od
  have h:=(sqr p od).2.2.1
  dsimp [w1,s2]
  exact ⟨by linarith only [w],by linarith only [s,l],by linarith only [ww,h],by linarith only [ss]⟩

theorem factored {k m : ℕ} (odd : Odd m) (hit : OeisA245212.a (2^k*m)=(σ 1 (2^k*m):ℤ))
    (shape : ∀p∈m.primeFactors,m.factorization p=1 ∨ m.factorization p=2)
    (rank : m.primeFactors.card=2*(m.primeFactors.filter (fun p=>m.factorization p=2)).card) :
    m ≡ 5^(m.primeFactors.card/2) [MOD 8] := by
  let s:=m.primeFactors
  let P:=s.filter (fun p=>m.factorization p=1)
  let Q:=s.filter (fun p=>¬m.factorization p=1)
  have qs : Q=s.filter (fun p=>m.factorization p=2):=by
    ext p
    simp only [Q,mem_filter]
    constructor
    · rintro ⟨pm,no⟩;exact ⟨pm,(shape p pm).resolve_left no⟩
    · rintro ⟨pm,two⟩;exact ⟨pm,by omega⟩
  have split:=card_filter_add_card_filter_not (s:=s) (p:=fun p=>m.factorization p=1)
  change P.card+Q.card=s.card at split
  have qr : s.card=2*Q.card:=by rw [qs];exact rank
  have same : P.card=Q.card:=by omega
  have prime (p) (mem : p∈s):=Nat.prime_of_mem_primeFactors mem
  have op (p) (mem : p∈s):=Nat.coprime_two_left.mp
    ((Nat.coprime_two_left.mpr odd).of_dvd_right (Nat.dvd_of_mem_primeFactors mem))
  have po p (mem : p∈P):=op p (mem_filter.mp mem).1
  have qo p (mem : p∈Q):=op p (mem_filter.mp mem).1
  have data p (mem : p∈s):=local_data p (prime p mem) (op p mem)
  have pieces (f : ℕ→ℕ) : (∏p∈s,f (p^m.factorization p))=(∏p∈P,f p)*(∏q∈Q,f (q^2)) := by
    rw [←prod_filter_mul_prod_filter_not s (fun p=>m.factorization p=1) (fun p=>f (p^m.factorization p))]
    apply congrArg₂ Nat.mul
    · apply prod_congr rfl;intro p mem;rw [(mem_filter.mp mem).2,pow_one]
    · apply prod_congr rfl;intro p mem
      rw [((shape p (mem_filter.mp mem).1).resolve_left (mem_filter.mp mem).2)]
  have mult (f : ArithmeticFunction ℕ) (mf : f.IsMultiplicative) :
      f m=(∏p∈P,f p)*(∏q∈Q,f (q^2)) := by
    rw [mf.multiplicative_factorization _ odd.pos.ne'];exact pieces f
  have repr : m=(∏p∈P,p)*(∏q∈Q,q^2):=(Nat.prod_primeFactors_pow_factorization odd.pos.ne').trans (pieces id)
  let A:=(∏p∈P,w1 p)*(∏q∈Q,w2 q)
  let S:=(∏p∈P,s1 p)*(∏q∈Q,s2 q)
  have wa : W m=2^P.card*A := by
    rw [mult W w_mult,prod_congr rfl (fun p hp=>(data p (mem_filter.mp hp).1).1),
      prod_congr rfl (fun p hp=>(data p (mem_filter.mp hp).1).2.2.1),prod_mul_distrib,prod_const,←same]
    dsimp [A];ring
  have ss : σ 1 m=2^P.card*S := by
    rw [mult _ isMultiplicative_sigma,prod_congr rfl (fun p hp=>(data p (mem_filter.mp hp).1).2.1),
      prod_congr rfl (fun p hp=>(data p (mem_filter.mp hp).1).2.2.2),prod_mul_distrib,prod_const]
    dsimp [S];ring
  have tau : σ 0 m=2^P.card*3^Q.card := by
    rw [mult _ isMultiplicative_sigma]
    have two p (hp:p∈P) : σ 0 p=2:=by
      simpa using sigma_zero_apply_prime_pow (prime p (mem_filter.mp hp).1) (i:=1)
    have three q (hq:q∈Q) : σ 0 (q^2)=3:=sigma_zero_apply_prime_pow (prime q (mem_filter.mp hq).1)
    rw [prod_congr rfl two,prod_congr rfl three,prod_const,prod_const]
  have cop:=(Nat.coprime_two_left.mpr odd).pow_left k
  have bal:=OMA.Abundance245212.balance (Nat.mul_ne_zero (Nat.two_pow_pos k).ne' odd.pos.ne') hit
  obtain ⟨wf,sigmaDy⟩:=OMA.DivisorHeight245212.dyadic_moments k
  rw [w_mult.map_mul_of_coprime cop,isMultiplicative_sigma.map_mul_of_coprime cop,
    isMultiplicative_sigma.map_mul_of_coprime cop,wf,wa,ss,tau,sigma_zero_apply_prime_pow prime_two] at bal
  have fix : σ 1 (2^k)=2^(k+1)-1:=by omega
  rw [fix] at bal
  have eqn : (1+k*2^(k+1))*A+(2^(k+1)-1)*S=2^(k+1)*(k+1)*(m*3^Q.card):=by
    apply Nat.eq_of_mul_eq_mul_left (Nat.two_pow_pos P.card)
    rw [pow_succ (2:ℕ) k] at bal ⊢
    linear_combination bal
  have oa : Odd A:=by
    apply Odd.mul
    · apply Nat.coprime_two_left.mp;apply Coprime.prod_right;intro p _
      apply Nat.coprime_two_left.mpr;exact ⟨p,by dsimp [w1];omega⟩
    · apply Nat.coprime_two_left.mp;apply Coprime.prod_right;intro q hq
      have main:=sqr q (qo q hq)
      apply Nat.coprime_two_left.mpr
      rw [Nat.odd_iff] at *
      have congr:=(main.1.of_dvd (by decide : 2∣4))
      change w2 q%2=s2 q%2 at congr
      exact congr.trans main.2.1
  have out:=(unit_test P Q po qo (normalized oa (odd.mul (Odd.pow (by decide : Odd 3))) eqn)).2
  rw [←repr] at out
  have h : P.card=m.primeFactors.card/2:=by change P.card=s.card/2;omega
  rwa [h] at out

theorem original {n : ℕ} (pos : 0<n) (hit : OeisA245212.a n=(σ 1 n:ℤ))
    (edge : 6^(support n).card=(σ 0 (ordCompl[2] n))^2) :
    ordCompl[2] n ≡ 5^((support n).card/2) [MOD 8] := by
  let m:=ordCompl[2] n
  have odd : Odd m:=Nat.coprime_two_left.mp (Nat.coprime_ordCompl prime_two pos.ne')
  have ss : m.primeFactors=support n := by
    dsimp [m,support];rw [←Nat.support_factorization,Nat.factorization_ordCompl,Finsupp.support_erase,Nat.support_factorization]
  have eqp p (mem : p∈support n) : m.factorization p=n.factorization p:=by
    dsimp [m];rw [Nat.factorization_ordCompl,Finsupp.erase_ne (mem_erase.mp mem).1]
  rw [OMA.SparseDivisorHeight245212.odd_count pos] at edge
  have shape:=OMA.OddDivisorCritical245212.only pos hit edge
  have count:=OMA.OddDivisorCritical245212.counts pos hit edge
  have filters : (m.primeFactors.filter (fun p=>m.factorization p=2))=
      (support n).filter (fun p=>n.factorization p=2):=by
    rw [ss];apply filter_congr
    intro p mem;rw [eqp p mem]
  have id : 2^(n.factorization 2)*m=n:=Nat.ordProj_mul_ordCompl_eq_self n 2
  have out:=factored (k:=n.factorization 2) odd (by rwa [id])
    (fun p mem=>by rw [ss] at mem;rw [eqp p mem];exact shape p mem)
    (by rw [filters,ss];exact count)
  simpa only [ss] using out

#print axioms original
end OMA.CriticalResidueInput245212
