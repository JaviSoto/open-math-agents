import FixedRankHeight245212

/-! The fixed-support dyadic estimate directly on the original integer, without
an ordered factorization as input. The nonempty hypothesis removes pure powers of two. -/
namespace OMA.FixedRankInteger245212
open Nat Finset OMA.Smooth245212 OMA.FixedRankHeight245212
open scoped ArithmeticFunction.sigma

def support (n : ℕ) := n.primeFactors.erase 2
def longest (n : ℕ) := (support n).sup (fun p=>n.factorization p+1)
def polynomial (r L : ℕ) := OMA.SingleMovingHeight245212.constant (exponent r)*(L+1)^(2*exponent r)

/-- A single explicit function works simultaneously for every nonempty odd
support, even when the number of primes is itself allowed to vary. -/
theorem original {n : ℕ} (pos : 0<n) (nonempty : (support n).Nonempty)
    (eqn : OeisA245212.a n=(σ 1 n:ℤ)) :
    2^(n.factorization 2)≤polynomial (support n).card (longest n) := by
  let s:=support n
  let P : Fin s.card ↪o ℕ:=s.orderEmbOfFin rfl
  let e (i : Fin s.card):=n.factorization (P i)
  have mem (i : Fin s.card) : P i∈s:=s.orderEmbOfFin_mem rfl i
  have prime i := prime_of_mem_primeFactors (mem_erase.mp (mem i)).2
  have odd i := (prime i).odd_of_ne_two (mem_erase.mp (mem i)).1
  have ep (i) : 0<e i:=Nat.pos_of_ne_zero (Finsupp.mem_support_iff.mp (mem_erase.mp (mem i)).2)
  have lift : univ.map P.toEmbedding=s:=s.map_orderEmbOfFin_univ rfl
  have fac : 2^(n.factorization 2)*(∏ p∈s,p^(n.factorization p))=n := by
    by_cases h : 2∈n.primeFactors
    · exact (mul_prod_erase n.primeFactors (fun p => p^(n.factorization p)) h).trans
        (Nat.prod_primeFactors_pow_factorization pos.ne').symm
    · have z : n.factorization 2=0:=Finsupp.notMem_support_iff.mp h
      simpa [z,s,support,erase_eq_of_notMem h] using (Nat.prod_primeFactors_pow_factorization pos.ne').symm
  rw [←lift,prod_map] at fac
  change 2^(n.factorization 2)*total P e=n at fac
  obtain ⟨z,zm,zt⟩:=Finset.exists_mem_eq_sup s nonempty (fun p=>n.factorization p+1)
  obtain ⟨i,_,zi⟩:=Finset.mem_map.mp (lift.symm ▸ zm)
  change P i=z at zi
  have zmax : ∃ i,e i+1=longest n:=⟨i,by change n.factorization (P i)+1=longest n;rw [zi];exact zt.symm⟩
  have cap i : e i+1≤longest n := Finset.le_sup (f:=fun p=>n.factorization p+1) (mem i)
  exact OMA.FixedRankHeight245212.original (n.factorization 2) (longest n) P e prime odd P.injective ep zmax cap (by rwa [fac])

/-- In rank four the exponent of (L+1) is exactly 824633720840. -/
theorem four {n : ℕ} (pos : 0<n) (rank : (support n).card=4)
    (eqn : OeisA245212.a n=(σ 1 n:ℤ)) :
    2^(n.factorization 2)≤OMA.SingleMovingHeight245212.constant 412316860420*(longest n+1)^824633720840 := by
  have ne:=Finset.card_pos.mp (show 0<(support n).card by omega)
  simpa only [rank,polynomial,show exponent 4=412316860420 by decide,show 2*412316860420=824633720840 by decide]
    using original pos ne eqn

end OMA.FixedRankInteger245212
