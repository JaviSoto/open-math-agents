import FixedRankStep245212
import FixedRankProxy245212
import SingleMovingHeight245212

/-! The dyadic factor of every solution with three distinct odd primes
is polynomially bounded in the largest odd exponent length. -/
namespace OMA.FixedRankHeight245212
open Nat Finset ArithmeticFunction OMA.FixedRankGap245212 OMA.FixedRankStep245212
open OMA.ThreeMovingOriginal245212 (F G)
open OMA.TwoTallScalar245212 (base)
open OMA.Smooth245212 (total W)
open scoped ArithmeticFunction.sigma
open private OMA.ComplementaryLocal245212.binary from ComplementaryLocal245212
variable {r : ℕ}

private theorem identities (k : ℕ) : 0<G k ∧ F k+G k=(k+1)*2^(k+1) ∧ F k=k*G k+(k+1) := by
  have g:=Nat.two_pow_pos k
  dsimp [F,G];rw [pow_succ]
  have sub:=Nat.sub_add_cancel (show 1≤2^k*2 by omega)
  exact ⟨by omega,by nlinarith only [sub],by nlinarith only [congrArg (k*·) sub]⟩


theorem physical (c : Family r) (k : ℕ) (op : ∀i,Odd (c.p i)) (inj : c.p.Injective)
    (eqn : OeisA245212.a (2^k*total c.p c.e)=(σ 1 (2^k*total c.p c.e):ℤ)) :
    score (F k) (G k) (exactX c) (exactY c)=(F k+G k:ℕ) := by
  let t:=2^k*σ 0 (2^k)
  have t0 : 0<t := Nat.mul_pos (Nat.two_pow_pos k) (sigma_pos 0 _ (Nat.two_pow_pos k).ne')
  have norm:=OMA.CofactorCrossOriginal245212.normalized_extension (p:=c.p) (e:=c.e) (Nat.two_pow_pos k)
    c.prime inj (fun i=>(Nat.coprime_two_left.mpr (op i)).pow_left k) eqn
  change ((W (2^k):ℚ)/t)*(∏i,exactX c i)+((σ 1 (2^k):ℚ)/t)*(∏i,exactY c i)=2 at norm
  field_simp [show (t:ℚ)≠0 by exact_mod_cast t0.ne'] at norm
  have z0:=Nat.two_pow_pos (k+1)
  have gold : σ 1 (2^k)=G k := by
    dsimp [G];zify [Nat.cast_sub (show 1≤2^(k+1) from z0)]
    exact (OMA.ComplementaryLocal245212.binary k).1
  have fold : W (2^k)=F k := by exact_mod_cast (OMA.ComplementaryLocal245212.binary k).2
  have ht : 2*t=F k+G k := by
    dsimp [t];rw [sigma_zero_apply_prime_pow Nat.prime_two,(identities k).2.1,pow_succ];ring
  rw [gold,fold] at norm
  dsimp [score];rw [←ht];push_cast;linarith only [norm]


theorem coarse (c : Family r) (op : ∀i,Odd (c.p i))
    (eqn : OeisA245212.a (2^c.k*total c.p c.e)=(σ 1 (2^c.k*total c.p c.e):ℤ)) :
    G c.k < 2^r*(c.k+1)*((base c.k c.L)^(r+2))^(degree r) := by
  have exact:=physical c c.k op c.inj eqn
  let x:=(base c.k c.L)^(r+2)
  have toX : base c.k c.L≤x:=Nat.le_self_pow (by omega) _
  have big : 128≤x := by apply le_trans _ toX; dsimp [base];nlinarith only [Nat.zero_le (c.k*c.L),Nat.zero_le c.k,Nat.zero_le c.L]
  have cf : c.k+1≤x := by apply le_trans _ toX; dsimp [base];nlinarith only [Nat.zero_le (c.k*c.L),Nat.zero_le c.k,Nat.zero_le c.L]
  have cl : c.L≤x := by apply le_trans _ toX; dsimp [base];nlinarith only [Nat.zero_le (c.k*c.L),Nat.zero_le c.k,Nat.zero_le c.L]
  have dx : 1≤x:=by omega
  have r0 := (identities c.k).1
  let PX:=∏i,exactX c i
  let PY:=∏i,exactY c i
  have xb i := OMA.TwoTallLocal245212.ranges (c.prime i) (c.positive i) none
  have low : (1:ℚ)≤PX:=one_le_prod (fun i _=>(xb i).1)
  have top : PX≤(2:ℚ)^r := calc
    _ ≤ ∏_i:Fin r,(2:ℚ) := prod_le_prod (fun i _=>zero_le_one.trans (xb i).1) (fun i _=>(xb i).2.1)
    _ = _ := by norm_num
  have id : (G c.k:ℚ)*((c.k:ℚ)+1-score c.k 1 (exactX c) (exactY c))=((c.k:ℚ)+1)*(PX-1) := by
    change (F c.k:ℚ)*PX+(G c.k:ℚ)*PY=(F c.k+G c.k:ℕ) at exact
    change _*((c.k:ℚ)+1-((c.k:ℚ)*PX+(1:ℕ)*PY))=_
    have f : (F c.k:ℚ)=(c.k:ℚ)*G c.k+(c.k+1:ℕ) := by exact_mod_cast (identities c.k).2.2
    push_cast at f exact ⊢
    linear_combination -exact+(PX-1)*f
  have gp : (0:ℚ)<G c.k := by exact_mod_cast r0
  by_contra! ample
  have below : score c.k 1 (exactX c) (exactY c)≤(c.k+1:ℕ):=by
    push_cast
    exact sub_nonneg.mp (nonneg_of_mul_nonneg_right (id ▸ mul_nonneg (by positivity) (sub_nonneg.mpr low)) gp)
  have close : |score c.k 1 (exactX c) (exactY c)-(c.k+1:ℕ)|≤1/((x^(degree r):ℕ):ℚ) := by
    rw [abs_of_nonpos (sub_nonpos.mpr below),neg_sub]
    have h : (((c.k+1:ℕ):ℚ)-score c.k 1 (exactX c) (exactY c))*(x^(degree r):ℕ)≤1 := by
      apply le_of_mul_le_mul_left (a:=(G c.k:ℚ)) _ gp
      have g0 : (2:ℚ)^r*(c.k+1)*(x^(degree r):ℕ)≤G c.k:=by exact_mod_cast ample
      push_cast at g0 ⊢
      nlinarith only [congrArg (·*(x:ℚ)^(degree r)) id,g0,
        mul_le_mul_of_nonneg_right (show PX-1≤(2:ℚ)^r by linarith) (show 0≤((c.k:ℚ)+1)*x^(degree r) by positivity)]
    exact (le_div_iff₀ (by exact_mod_cast pow_pos dx (degree r) : (0:ℚ)<(x^(degree r):ℕ))).mpr h

  apply OMA.FixedRankStep245212.contradiction c c.k 1 x big cf cl ?_ ?_ close
  · have B : 4≤base c.k c.L := by dsimp [base];nlinarith only [Nat.zero_le (c.k*c.L),Nat.zero_le c.k,Nat.zero_le c.L]
    calc
      2*r*2^r ≤ 2*(2^r)*2^r := Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ ((Nat.lt_two_pow_self).le))
      _ = 2*4^r := by rw [show (4:ℕ)=2*2 by decide,mul_pow];ring
      _ ≤ 4^r*4^2 := by nlinarith only [Nat.zero_le (4^r)]
      _ = 4^(r+2) := (pow_add ..).symm
      _ ≤ x := Nat.pow_le_pow_left B _
  intro b
  have link : OMA.FixedRankProxy245212.deficit c*(G c.k:ℕ)=((c.k:ℚ)+1)*((∏i,exactX c i)-1) := by
    simpa only [OMA.FixedRankProxy245212.deficit,mul_comm] using id
  simpa only [one_mul] using OMA.FixedRankProxy245212.separated c b link


/-- The explicit polynomial degree depends only on the number of odd primes. -/
def exponent (r : ℕ) := (r+2)*degree r+r

open private OMA.SingleMovingHeight245212.all_k from SingleMovingHeight245212

/-- The full A245212 equality bounds its dyadic prime power polynomially in
the largest odd exponent length at every fixed positive support size. -/
theorem original {r : ℕ} (k L : ℕ) (p e : Fin r→ℕ) (prime : ∀i,(p i).Prime)
    (odd : ∀i,Odd (p i)) (distinct : p.Injective) (positive : ∀i,0<e i)
    (longest : ∃i,e i+1=L) (cap : ∀i,e i+1≤L)
    (eqn : OeisA245212.a (2^k*total p e)=(σ 1 (2^k*total p e):ℤ)) :
    2^k≤OMA.SingleMovingHeight245212.constant (exponent r)*(L+1)^(2*exponent r) := by
  apply OMA.SingleMovingHeight245212.all_k
  intro hk
  let c : Family r := ⟨p,e,k,L,prime,positive,hk,longest,cap,distinct⟩
  have z:=coarse c odd eqn
  change G k < 2^r*(k+1)*((base k L)^(r+2))^(degree r) at z
  apply z.trans_le
  let b:=base k L
  have hb : 2≤b := by dsimp [base,b];nlinarith only [Nat.zero_le (k*L),Nat.zero_le k,Nat.zero_le L]
  have h:=Nat.pow_le_pow_left hb r
  calc
    _ ≤ b^r*(k+1)*(b^(r+2))^(degree r) := Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ h)
    _ = (k+1)*b^(exponent r) := by rw [exponent,pow_add b ((r+2)*degree r) r,pow_mul];ring
    _ ≤ 8*(k+1)*b^(exponent r) := Nat.mul_le_mul_right _ (by omega)

end OMA.FixedRankHeight245212
