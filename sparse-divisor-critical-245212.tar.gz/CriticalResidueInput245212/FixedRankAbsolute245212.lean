import FixedModeClose245212
import FixedModeShortArithmetic245212
import FixedModeSmallGain245212
import ThreeMovingDividend245212
import RankThreeEffective245212

/-! Every fixed positive number of distinct odd prime divisors gives only
finitely many possible solutions to the original divisor balance. -/
namespace OMA.FixedRankAbsolute245212
open Nat Finset ArithmeticFunction OMA.FixedRankGap245212 OMA.FixedRankInteger245212
open OMA.Smooth245212 (total)
open OMA.ThreeMovingOriginal245212 (F G)
open scoped ArithmeticFunction.sigma Function

noncomputable section

def lengthCap (r : ℕ) := OMA.FixedModeClose245212.lengthCap r +
  OMA.FixedModeSmallSetup245212.limit r +
  OMA.ArbitraryMixedFinite245212.cutoff (r+1) (OMA.FixedModeShortArithmetic245212.fixedExp r)

theorem lengths {r k L : ℕ} (many : 5≤r) (p e : Fin r→ℕ)
    (pr : ∀i,(p i).Prime) (odd : ∀i,Odd (p i)) (inj : p.Injective)
    (ep : ∀i,0<e i) (longest : ∃i,e i+1=L) (cap : ∀i,e i+1≤L)
    (eqn : OeisA245212.a (2^k*total p e)=(σ 1 (2^k*total p e):ℤ)) :
    L≤lengthCap r := by
  by_cases hi : 256≤k
  · have bound:=(OMA.FixedModeClose245212.orderBound p e pr odd inj ep longest cap eqn).1 hi
    dsimp only [lengthCap];omega
  by_cases big : OMA.FixedModeSmallSetup245212.limit r≤L
  · let c : Family r:=⟨p,e,8,L,pr,ep,by decide,longest,cap,inj⟩
    obtain ⟨v,vl⟩:=longest
    obtain ⟨gp,fg⟩:=OMA.FixedModeShortArithmetic245212.weights k
    have bound:=OMA.FixedModeShortArithmetic245212.bounded c (lt_of_not_ge hi) odd big v vl eqn
      (fun b small s _ iv fr bi=>OMA.FixedModeSmallGain245212.gain c odd many b fg v vl small s iv fr bi)
      (fun b _ iv neg=>OMA.FixedModeSmallGain245212.risk c odd many b gp fg v iv neg)
    change L≤_ at bound
    dsimp only [lengthCap];omega
  · dsimp only [lengthCap];omega

def divisorBound (r : ℕ) := ∑t∈range ((lengthCap r)^r+1),
  2^OMA.DivisorHeight245212.exponentLimit t*OMA.DivisorHeight245212.coreLimit t

theorem factored {r k L : ℕ} (many : 5≤r) (p e : Fin r→ℕ)
    (pr : ∀i,(p i).Prime) (op : ∀i,Odd (p i)) (inj : p.Injective)
    (ep : ∀i,0<e i) (longest : ∃i,e i+1=L) (cap : ∀i,e i+1≤L)
    (eqn : OeisA245212.a (2^k*total p e)=(σ 1 (2^k*total p e):ℤ)) :
    2^k*total p e≤divisorBound r := by
  classical
  have lim:=lengths many p e pr op inj ep longest cap eqn
  obtain ⟨i,_⟩:=longest
  have odd : Odd (total p e) := Nat.coprime_two_left.mp
    (Coprime.prod_right (fun j _ => (Nat.coprime_two_left.mpr (op j)).pow_right _))
  have dvd : p i∣total p e := (dvd_pow_self _ (ep i).ne').trans
    (dvd_prod_of_mem (fun j=>p j^e j) (mem_univ i))
  have big := (pr i).one_lt.trans_le (Nat.le_of_dvd odd.pos dvd)
  have pair : (↑(univ : Finset (Fin r)) : Set (Fin r)).Pairwise (Nat.Coprime on (fun i=>p i^e i)) := by
    intro i _ j _ ne
    exact (((Nat.coprime_primes (pr i) (pr j)).mpr (inj.ne ne)).pow_left _).pow_right _
  have count : (total p e).divisors.card=∏i,(e i+1) := by
    rw [←sigma_zero_apply]
    simpa [total,sigma_zero_apply_prime_pow (pr _)] using
      IsMultiplicative.map_prod (fun i=>p i^e i) (isMultiplicative_sigma (k:=0)) univ pair
  have tc : (total p e).divisors.card≤(lengthCap r)^r := by
    rw [count]
    calc
      _ ≤ ∏_i : Fin r,lengthCap r := prod_le_prod' (fun j _=>(cap j).trans lim)
      _ = _ := by simp
  obtain ⟨ke,co⟩:=OMA.DivisorHeight245212.effective_box odd big eqn
  exact (Nat.mul_le_mul (Nat.pow_le_pow_right (by decide : 0<2) ke.le) co).trans
    (single_le_sum (f:=fun t=>2^OMA.DivisorHeight245212.exponentLimit t*OMA.DivisorHeight245212.coreLimit t)
      (fun _ _=>Nat.zero_le _) (mem_range.mpr (Nat.lt_succ_of_le tc)))

theorem large_rank {n : ℕ} (pos : 0<n) (many : 5≤(support n).card)
    (eqn : OeisA245212.a n=(σ 1 n:ℤ)) : n≤divisorBound (support n).card := by
  let s:=support n
  have nonempty : s.Nonempty:=card_pos.mp (by change 0<(support n).card;omega)
  let P : Fin s.card ↪o ℕ:=s.orderEmbOfFin rfl
  let e (i : Fin s.card):=n.factorization (P i)
  have mem (i : Fin s.card) : P i∈s:=s.orderEmbOfFin_mem rfl i
  have prime i := prime_of_mem_primeFactors (mem_erase.mp (mem i)).2
  have odd i := (prime i).odd_of_ne_two (mem_erase.mp (mem i)).1
  have ep (i) : 0<e i:=Nat.pos_of_ne_zero (Finsupp.mem_support_iff.mp (mem_erase.mp (mem i)).2)
  have lift : univ.map P.toEmbedding=s:=s.map_orderEmbOfFin_univ rfl
  have fac : 2^(n.factorization 2)*(∏ p∈s,p^(n.factorization p))=n := by
    by_cases h : 2∈n.primeFactors
    · exact (mul_prod_erase n.primeFactors (fun p=>p^(n.factorization p)) h).trans
        (Nat.prod_primeFactors_pow_factorization pos.ne').symm
    · have z : n.factorization 2=0:=Finsupp.notMem_support_iff.mp h
      simpa [z,s,support,erase_eq_of_notMem h] using (Nat.prod_primeFactors_pow_factorization pos.ne').symm
  rw [←lift,prod_map] at fac
  change 2^(n.factorization 2)*total P e=n at fac
  obtain ⟨z,zm,zt⟩:=Finset.exists_mem_eq_sup s nonempty (fun p=>n.factorization p+1)
  obtain ⟨i,_,zi⟩:=Finset.mem_map.mp (lift.symm ▸ zm)
  change P i=z at zi
  have zmax : ∃ i,e i+1=longest n:=⟨i,by change n.factorization (P i)+1=longest n;rw [zi];exact zt.symm⟩
  have cap i : e i+1≤longest n := Finset.le_sup (f:=fun p=>n.factorization p+1) (mem i)
  have h : OeisA245212.a (2^(n.factorization 2)*total P e) =
      (σ 1 (2^(n.factorization 2)*total P e):ℤ):=by rwa [fac]
  calc
    n = 2^(n.factorization 2)*total P e := fac.symm
    _ ≤ divisorBound s.card := factored (r:=s.card) (k:=n.factorization 2) many P e prime odd P.injective ep zmax cap h

def lowBound (k : ℕ) := OMA.TwoFreeEffectiveUniform245212.envelope (2^k) +
  OMA.RankThreeEffective245212.bound k + OMA.RankFourEffective245212.bound k

/-- Explicit rank-dependent upper bound on a solution with positive odd rank. -/
def bound (r : ℕ) := divisorBound r +
  ∑j∈range (OMA.FixedModeClose245212.kCap r+1),lowBound j

theorem absolute {n : ℕ} (pos : 0<n) (nonempty : (support n).Nonempty)
    (eqn : OeisA245212.a n=(σ 1 n:ℤ)) : n≤bound (support n).card := by
  by_cases many : 5≤(support n).card
  · exact (large_rank pos many eqn).trans (Nat.le_add_right _ _)
  let m:=ordCompl[2] n
  let k:=n.factorization 2
  have cm : Odd m:=Nat.coprime_two_left.mp (Nat.coprime_ordCompl prime_two pos.ne')
  have ss : m.primeFactors=support n := by
    dsimp [m,support];rw [←Nat.support_factorization,Nat.factorization_ordCompl,Finsupp.support_erase,Nat.support_factorization]
  have id : 2^k*m=n:=Nat.ordProj_mul_ordCompl_eq_self n 2
  have h : OeisA245212.a (2^k*m)=(σ 1 (2^k*m):ℤ):=by rwa [id]
  have rank := congrArg Finset.card ss
  have low : 2^k*m≤lowBound k := by
    by_cases near : m.primeFactors.card≤2
    · have u:=OMA.TwoFreeEffectiveUniform245212.of_rank (Nat.two_pow_pos k) (le_refl _) cm
        ((Nat.coprime_two_left.mpr cm).pow_left k) near h
      exact u.trans ((Nat.le_add_right _ _).trans (Nat.le_add_right _ _))
    by_cases three : m.primeFactors.card=3
    · exact (OMA.RankThreeEffective245212.original cm three h).trans
        ((Nat.le_add_left _ _).trans (Nat.le_add_right _ _))
    · exact (OMA.RankFourEffective245212.original cm (by omega) h).trans (Nat.le_add_left _ _)
  rw [id] at low
  have kb:= (OMA.FixedModeClose245212.original pos nonempty eqn).2
  exact low.trans ((single_le_sum (f:=lowBound) (fun _ _=>Nat.zero_le _)
    (mem_range.mpr (Nat.lt_succ_of_le kb))).trans (Nat.le_add_left _ _))

/-- Finitely many possible exceptions have at most any prescribed number of
distinct odd primes. The family of powers of two is excluded by nonemptiness. -/
theorem bounded_finite (R : ℕ) : {n : ℕ | 0<n ∧ (n.primeFactors.erase 2).Nonempty ∧
    (n.primeFactors.erase 2).card≤R ∧ OeisA245212.a n=(σ 1 n:ℤ)}.Finite := by
  apply (Set.finite_Iic (∑i∈range (R+1),bound i)).subset
  intro n hn
  exact (absolute hn.1 hn.2.1 hn.2.2.2).trans
    (single_le_sum (f:=bound) (fun _ _=>Nat.zero_le _) (mem_range.mpr (Nat.lt_succ_of_le hn.2.2.1)))

end
end OMA.FixedRankAbsolute245212
