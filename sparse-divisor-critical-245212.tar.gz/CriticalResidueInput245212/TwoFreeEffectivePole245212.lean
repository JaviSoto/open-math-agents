import TwoFreeEffectivePower245212

/-! Explicit first-exponent bound at the exact smaller-prime Euler slope. -/
namespace OMA.TwoFreeEffectivePole245212
open Nat ArithmeticFunction OMA.Smooth245212 OMA.TwoFreeEffectivePower245212
open OMA.RankThreeFourSmallSeparation245212
open scoped ArithmeticFunction.sigma

def scalar (A S : ℕ) := 16*(A+S+1)
def multiplier (A S P : ℕ) := 2*P*(A+S)*(S*P+1)
def scale (A S : ℕ) := max (scalar A S) ((2*(4*A+S))^2)
def poleExponent (A S P : ℕ) := max 784 (64*(scale A S*(multiplier A S P)^6))

theorem cost_le {A S q M : ℕ} (pos : 0<q) (small : M+1≤q) :
    cost A S q M ≤ scalar A S*q^3 := by
  have t : 1≤q^3 := Nat.one_le_pow _ _ pos
  have one : q≤q^3 := by simpa using Nat.pow_le_pow_right pos (by decide : 1≤3)
  have two : q^2≤q^3 := Nat.pow_le_pow_right pos (by decide : 2≤3)
  have cm:=Nat.mul_le_mul_right (A*q^2) small
  unfold cost scalar
  nlinarith only [cm,Nat.mul_le_mul_left A one,Nat.mul_le_mul_left A t,Nat.mul_le_mul_left S two,t]

private theorem small_second {h p q a d : ℕ} (hh : 0<h) (hp : p.Prime) (hq : q.Prime) (op : 3≤p)
    (cp : h.Coprime p) (cq : h.Coprime q) (pq : p<q) (ap : 0<a) (low : d≤3)
    (eqn : OeisA245212.a (h*p^a*q^d)=(σ 1 (h*p^a*q^d):ℤ)) :
    p^a ≤ scale (W h) (σ 1 h)*q^6 := by
  have swapped : OeisA245212.a (h*q^d*p^a)=(σ 1 (h*q^d*p^a):ℤ) := by rwa [mul_right_comm]
  have pw:=next_power hh hq hp (by omega) cq cp pq.ne.symm ap swapped
  let A:=W h
  let S:=σ 1 h
  have le : 2*(A*(d+1)+S)*q^d≤2*(4*A+S)*q^3 := by
    rw [mul_comm 4 A]
    exact Nat.mul_le_mul (Nat.mul_le_mul_left 2 (Nat.add_le_add_right (Nat.mul_le_mul_left A (by omega)) _))
      (Nat.pow_le_pow_right hq.pos low)
  calc
    _ ≤ (2*(4*A+S)*q^3)^2 := pw.trans (Nat.pow_le_pow_left le 2)
    _ = (2*(4*A+S))^2*q^6 := by ring
    _ ≤ scale A S*q^6 := Nat.mul_le_mul_right _ (le_max_right ..)

theorem original {h p q a d P : ℕ} (hh : 0<h) (hp : p.Prime) (hq : q.Prime) (op : 3≤p)
    (cp : h.Coprime p) (cq : h.Coprime q) (pq : p<q) (ap : 0<a) (dp : 0<d) (maxp : p≤P)
    (pole : W h*p=2*(h*σ 0 h)*(p-1)) (pa : P^4≤q) (costly : scalar (W h) (σ 1 h)<q)
    (qt : 2*(h*σ 0 h)<q) (eqn : OeisA245212.a (h*p^a*q^d)=(σ 1 (h*p^a*q^d):ℤ)) :
    a ≤ poleExponent (W h) (σ 1 h) P := by
  let A:=W h
  let S:=σ 1 h
  let K:=multiplier A S P
  have iz : (W h:ℤ)*p=2*((h:ℤ)*σ 0 h)*(p-1) := by
    zify [Nat.cast_sub hp.pos] at pole
    simpa only [mul_assoc] using pole
  obtain ⟨d,rfl⟩:=Nat.exists_eq_succ_of_ne_zero dp.ne'
  obtain ⟨lin,lower⟩:=OMA.CofactorPairPole245212.original_slope hh hp hq op (by omega) cp cq pq.ne iz eqn
  have lin' : q≤2*(p-1)*(A+S)*(S*(p-1)+1)*(a+1) := by
    dsimp [A,S];exact_mod_cast (by simpa only [Nat.cast_sub hp.pos,Nat.cast_one,Nat.cast_mul,Nat.cast_add,Nat.cast_ofNat] using lin :
      (q:ℤ)≤(2*(p-1)*(W h+σ 1 h)*(σ 1 h*(p-1)+1)*(a+1):ℕ))
  have qb : q≤K*(a+1) := lin'.trans (by dsimp [K,multiplier];gcongr <;> omega)
  have pw : p^a ≤ scale A S*q^6 := by
    by_cases sd : d+1≤3
    · exact small_second hh hp hq op cp cq pq ap sd eqn
    have aq:=lower ap (by omega)
    have qo:=lengths ((Nat.pow_le_pow_left maxp 4).trans pa) costly.le aq (next_power hh hp hq (by omega) cp cq pq.ne (by omega) eqn)
    let M:=max a (d+1)
    have m : M+1<q := by dsimp [M];omega
    have hd:=min_power hh hp hq cp cq pq (le_max_left ..) (le_max_right ..) m
      (Nat.not_dvd_of_pos_of_lt (by have := sigma_pos 0 h hh.ne'; positivity) qt) eqn
    have cap := hd.trans (cost_le hq.pos m.le)
    rcases le_total (p^a) (q^(d+1)) with x|y
    · rw [min_eq_left x] at cap
      exact cap.trans (Nat.mul_le_mul (le_max_left ..) (Nat.pow_le_pow_right hq.pos (by decide : 3≤6)))
    · rw [min_eq_right y] at cap
      have small := cap.trans_lt (Nat.mul_lt_mul_of_pos_right costly (pow_pos hq.pos 3))
      have order := (Nat.pow_le_pow_right hq.pos (show 4≤d+1 by omega)).trans_lt small
      have zero : q*q^3=q^4 := by ring
      rw [zero] at order
      exact order.false.elim
  apply polynomial_cut (C:=scale A S*K^6)
  calc
    _ ≤ p^a := Nat.pow_le_pow_left hp.two_le _
    _ ≤ scale A S*(K*(a+1))^6 := pw.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left qb 6))
    _ = _ := by ring

end OMA.TwoFreeEffectivePole245212
