import Mathlib

/-! Unit residues for the critical (linear, square) exponent pattern. -/
namespace OMA.CriticalResidueLocal245212
open Nat Finset

def w1 (p : ℕ) := 1+2*p
def s1 (p : ℕ) := (p+1)/2
def w2 (q : ℕ) := (1+2*q+3*q^2)/2
def s2 (q : ℕ) := 1+q+q^2
def liftUnit (x : ℕ) := 2*x+7

theorem lin (p : ℕ) (op : Odd p) : w1 p ≡ 3 [MOD 4] ∧ 2*s1 p=p+1 := by
  obtain ⟨u,rfl⟩:=op
  dsimp [w1,s1,Nat.ModEq];omega

theorem sqr (p : ℕ) (op : Odd p) : w2 p ≡ s2 p [MOD 4] ∧ Odd (s2 p) ∧
    2*w2 p=1+2*p+3*p^2 ∧ p^2 ≡ 1 [MOD 8] := by
  obtain ⟨u,hu⟩:=op
  have sq : p^2 ≡ 1 [MOD 8]:=by
    rcases Nat.even_or_odd u with ⟨t,ht⟩|⟨t,ht⟩
    · apply Nat.modEq_of_dvd
      rw [hu,ht];push_cast;exact ⟨-(2*(t:ℤ)^2+t),by ring⟩
    · apply Nat.modEq_of_dvd
      rw [hu,ht];push_cast;exact ⟨-(2*(t:ℤ)^2+3*t+1),by ring⟩
  change p^2%8=1 at sq
  dsimp [w2,s2,Nat.ModEq]
  rw [Nat.odd_iff]
  omega

private theorem prod_mod (s : Finset ℕ) (f g : ℕ→ℕ) (m : ℕ)
    (eqn : ∀p∈s,f p ≡ g p [MOD m]) : (∏p∈s,f p) ≡ (∏p∈s,g p) [MOD m] := by
  induction s using Finset.induction_on with
  | empty=>rfl
  | @insert p s hp ih=>
    rw [prod_insert hp,prod_insert hp]
    exact (eqn p (mem_insert_self ..)).mul (ih (fun q h=>eqn q (mem_insert_of_mem h)))

private theorem odds (s : Finset ℕ) (f : ℕ→ℕ) (h : ∀p∈s,Odd (f p)) : Odd (∏p∈s,f p) :=
  Nat.coprime_two_left.mp (Coprime.prod_right (fun p mem=>Nat.coprime_two_left.mpr (h p mem)))

private theorem lift_mul {x y : ℕ} (ox : Odd x) (oy : Odd y) :
    liftUnit (x*y) ≡ liftUnit x*liftUnit y [MOD 8] := by
  obtain ⟨u,rfl⟩:=ox;obtain ⟨v,rfl⟩:=oy
  apply Nat.modEq_of_dvd
  dsimp [liftUnit]
  exact ⟨(u:ℤ)*v+4*u+4*v+9,by ring⟩

private theorem lift_prod (s : Finset ℕ) (f : ℕ→ℕ) (odd : ∀p∈s,Odd (f p)) :
    liftUnit (∏p∈s,f p) ≡ (∏p∈s,liftUnit (f p)) [MOD 8] := by
  induction s using Finset.induction_on with
  | empty=>simp only [prod_empty];decide
  | @insert p s hp ih=>
    have os q (mem:q∈s):=odd q (mem_insert_of_mem mem)
    rw [prod_insert hp,prod_insert hp]
    exact (lift_mul (odd p (mem_insert_self ..)) (odds s f os)).trans ((ih os).mul_left _)

theorem unit_test (P Q : Finset ℕ) (po : ∀p∈P,Odd p) (qo : ∀q∈Q,Odd q)
    (equal : (∏p∈P,w1 p)*(∏q∈Q,w2 q) ≡ (∏p∈P,s1 p)*(∏q∈Q,s2 q) [MOD 4]) :
    (∏p∈P,s1 p) ≡ 3^P.card [MOD 4] ∧
      (∏p∈P,p)*(∏q∈Q,q^2) ≡ 5^P.card [MOD 8] := by
  have ones:=prod_mod P w1 (fun _=>3) 4 (fun p hp=>(lin p (po p hp)).1)
  have two:=prod_mod Q w2 s2 4 (fun q hq=>(sqr q (qo q hq)).1)
  rw [prod_const] at ones
  have oq:=odds Q s2 (fun q hq=>(sqr q (qo q hq)).2.1)
  have cop : (4:ℕ).Coprime (∏q∈Q,s2 q) := (Nat.coprime_two_left.mpr oq).pow_left 2
  have main:=((ones.mul two).symm.trans equal).cancel_right_of_coprime cop
  have mod4 : (∏p∈P,s1 p) ≡ 3^P.card [MOD 4] := main.symm
  refine ⟨mod4,?_⟩
  have op3 : Odd (3^P.card):=Odd.pow (by decide : Odd 3)
  have os : Odd (∏p∈P,s1 p):=by
    rw [Nat.odd_iff] at op3 ⊢
    change (∏p∈P,s1 p)%4=(3^P.card)%4 at mod4
    omega
  have os1 p (mem:p∈P) : Odd (s1 p) := Nat.coprime_two_left.mp
    ((Nat.coprime_two_left.mpr os).of_dvd_right (dvd_prod_of_mem s1 mem))
  have base:=prod_mod P (fun p=>p) (fun p=>liftUnit (s1 p)) 8 (fun p hp=>by
    have h:=(lin p (po p hp)).2
    dsimp [liftUnit,Nat.ModEq];omega)
  have powers:=prod_mod Q (fun q=>q^2) (fun _=>1) 8 (fun q hq=>(sqr q (qo q hq)).2.2.2)
  simp only [prod_const_one] at powers
  have lift : liftUnit (∏p∈P,s1 p) ≡ liftUnit (3^P.card) [MOD 8] := by
    dsimp only [Nat.ModEq,liftUnit] at mod4 ⊢;omega
  have lift3:=lift_prod P (fun _=>3) (fun _ _=>(by decide : Odd 3))
  simp only [prod_const] at lift3
  have end3 : (liftUnit 3)^P.card ≡ 5^P.card [MOD 8]:=(by decide : liftUnit 3 ≡ 5 [MOD 8]).pow _
  simpa using (base.trans ((lift_prod P s1 os1).symm.trans (lift.trans (lift3.trans end3)))).mul powers

theorem normalized {k A S T : ℕ} (oddA : Odd A) (oddT : Odd T)
    (balance : (1+k*2^(k+1))*A+(2^(k+1)-1)*S=2^(k+1)*(k+1)*T) :
    A ≡ S [MOD 4] := by
  change A%4=S%4
  cases k with
  | zero=>
    norm_num at balance
    rw [Nat.odd_iff] at oddA oddT
    omega
  | succ j=>
    have div : 4∣2^(j+1+1):=pow_dvd_pow 2 (by omega : 2≤j+1+1)
    obtain ⟨u,hu⟩:=div
    have pos:=Nat.two_pow_pos (j+1+1)
    rw [hu] at balance pos
    have id : 4*u-1=4*(u-1)+3:=by omega
    rw [id] at balance
    have eq : A+3*S+4*((j+1)*u*A+(u-1)*S)=4*(u*(j+1+1)*T):=by
      nlinarith only [balance]
    omega

#print axioms unit_test
end OMA.CriticalResidueLocal245212
