import TwoFreeEffective245212

/-! A monotone arithmetic height for all positive cofactors up to B. -/
namespace OMA.TwoFreeEffectiveUniform245212
open Nat ArithmeticFunction OMA.Smooth245212 OMA.TwoFreeEffective245212
open OMA.RankThreeFourSmallHarmonic245212 OMA.TwoFreeEffectivePole245212
open scoped ArithmeticFunction.sigma
open private OMA.PairHeight245212.moment_bound OMA.PairHeight245212.count_le from PairHeight245212

def envelope (B : ℕ) :=
  let C:=2*B^3+1
  let P:=2*C*(C+4)
  let Z:=lastCut C C C P
  let X:=max (Z^finiteExponent C C Z) (P^looseExponent C C P)
  4*(B*max 1 X)^7

private theorem last_mono {A S H P C P' : ℕ} (a : A≤C) (s : S≤C) (h : H≤C) (p : P≤P') :
    lastCut A S H P ≤ lastCut C C C P' := by unfold lastCut scalar;gcongr

private theorem finite_mono {A S Z C Z' : ℕ} (a : A≤C) (s : S≤C) (z : Z≤Z') :
    finiteExponent A S Z ≤ finiteExponent C C Z' := by unfold finiteExponent;gcongr

private theorem loose_mono {A S P C P' : ℕ} (a : A≤C) (s : S≤C) (p : P≤P') :
    looseExponent A S P ≤ looseExponent C C P' := by unfold looseExponent poleExponent scale scalar multiplier;gcongr

theorem dominates {h B : ℕ} (hh : 0<h) (hb : h≤B) : height h ≤ envelope B := by
  let A:=W h
  let S:=σ 1 h
  let H:=2*(h*σ 0 h)
  let C:=2*B^3+1
  let P:=primeCut A S H
  let P':=2*C*(C+4)
  let Z:=lastCut A S H P
  let Z':=lastCut C C C P'
  have bpos : 0<B := hh.trans_le hb
  have cm:= (OMA.PairHeight245212.moment_bound hh).trans (Nat.mul_le_mul_left 2 (Nat.pow_le_pow_left hb 3))
  have a : A≤C := by dsimp [A,C];omega
  have s : S≤C := by dsimp [S,C];omega
  have t : H≤C := by
    have c : σ 0 h≤B := by rw [sigma_zero_apply];exact (OMA.PairHeight245212.count_le h).trans hb
    have b2 : B^2≤B^3 := Nat.pow_le_pow_right bpos (by decide : 2≤3)
    have lim:=Nat.mul_le_mul hb c
    dsimp [H,C];nlinarith only [lim,b2]
  have l : lengthCut A S H≤C+4 := max_le (by omega) (by have := Nat.div_le_self S (H-A);omega)
  have p : P≤P' := (Nat.div_le_self _ _).trans (Nat.mul_le_mul (Nat.mul_le_mul_left 2 t) l)
  have z:=last_mono a s t p
  change Z≤Z' at z
  have pp : 0<P' := by dsimp [P',C];positivity
  have zp : 0<Z' := by dsimp [Z',lastCut];omega
  have one:= (Nat.pow_le_pow_left z (finiteExponent A S Z)).trans (Nat.pow_le_pow_right zp (finite_mono a s z))
  have two:= (Nat.pow_le_pow_left p (looseExponent A S P)).trans (Nat.pow_le_pow_right pp (loose_mono a s p))
  exact Nat.mul_le_mul_left 4 (Nat.pow_le_pow_left (Nat.mul_le_mul hb
    (max_le_max le_rfl (max_le_max one two))) 7)


theorem monotone : Monotone envelope := by
  intro B D bd
  let C:=2*B^3+1
  let K:=2*D^3+1
  let P:=2*C*(C+4)
  let Q:=2*K*(K+4)
  let Z:=lastCut C C C P
  let Y:=lastCut K K K Q
  have c : C≤K := by dsimp [C,K];gcongr
  have p : P≤Q := by dsimp only [P,Q];gcongr
  have z : Z≤Y := last_mono c c c p
  have qp : 0<Q := by dsimp [Q,K];positivity
  have yp : 0<Y := by dsimp [Y,lastCut];omega
  have one:= (Nat.pow_le_pow_left z (finiteExponent C C Z)).trans (Nat.pow_le_pow_right yp (finite_mono c c z))
  have two:= (Nat.pow_le_pow_left p (looseExponent C C P)).trans (Nat.pow_le_pow_right qp (loose_mono c c p))
  exact Nat.mul_le_mul_left 4 (Nat.pow_le_pow_left (Nat.mul_le_mul bd
    (max_le_max le_rfl (max_le_max one two))) 7)

theorem original {B h p q a d : ℕ} (hh : 0<h) (hb : h≤B) (hp : p.Prime) (hq : q.Prime)
    (op : 3≤p) (oq : 3≤q) (cp : h.Coprime p) (cq : h.Coprime q) (ne : p≠q)
    (eqn : OeisA245212.a (h*p^a*q^d)=(σ 1 (h*p^a*q^d):ℤ)) : h*p^a*q^d ≤ envelope B :=
  (OMA.TwoFreeEffective245212.original hh hp hq op oq cp cq ne eqn).trans (dominates hh hb)


/-- A uniform height for every odd cofactor of rank at most two. -/
theorem of_rank {B h m : ℕ} (hh : 0<h) (hb : h≤B) (om : Odd m) (cp : h.Coprime m)
    (rank : m.primeFactors.card≤2) (eqn : OeisA245212.a (h*m)=(σ 1 (h*m):ℤ)) :
    h*m ≤ envelope B :=
  (OMA.TwoFreeEffective245212.of_rank hh om cp rank eqn).trans (dominates hh hb)

end OMA.TwoFreeEffectiveUniform245212
#print axioms OMA.TwoFreeEffectiveUniform245212.original
