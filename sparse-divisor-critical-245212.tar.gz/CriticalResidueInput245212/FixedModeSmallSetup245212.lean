import FixedModeAnySign245212
import FixedModeArithmetic245212
import FixedModeSmallPower245212

/-! At bounded physical dyadic order, small exact dyadic coefficients replace
the dyadic proxy. The auxiliary state's k field need not equal physical k. -/
namespace OMA.FixedModeSmallSetup245212
open Nat Finset ArithmeticFunction OMA.FixedRankGap245212
open OMA.Smooth245212 (total)
open OMA.FixedRankStep245212 (degree)
open OMA.FixedTallScalar245212 (threshold h)
open OMA.ThreeMovingOriginal245212 (F G)
open scoped ArithmeticFunction.sigma
open private OMA.FixedRankHeight245212.identities from FixedRankHeight245212

def headroom := (2:ℕ)^270
def limit (r : ℕ) := threshold r 1+headroom+16*140^2

theorem scales {r k : ℕ} (c : Family r) (small : k<256) (large : limit r≤c.L)
    (v : Fin r) (long : c.e v+1=c.L) :
    let x:=c.L^h r
    128≤x ∧ c.L≤x ∧ 2*r*2^r≤x ∧ 8*(F k+G k)≤c.L ∧ F k+G k≤x ∧
      x^(degree r)<c.p v^c.e v := by
  have cutoff : threshold r 1≤c.L:=by dsimp only [limit] at large;omega
  have p0:=OMA.FixedTallScalar245212.scale (k:=0) cutoff (by simp only [one_mul,le_refl] : c.L≤1*c.L)
    (by rw [pow_zero];apply Nat.one_le_iff_ne_zero.mpr;dsimp only [OMA.SingleMovingHeight245212.constant];positivity)
  obtain ⟨big,_,cl,ec,p⟩:=p0
  have cf : 8*(F k+G k)≤c.L := by
    rw [(OMA.FixedRankHeight245212.identities k).2.1]
    have a : k+1≤2^8 := by norm_num;omega
    have b : 2^(k+1)≤2^256:=Nat.pow_le_pow_right (by decide) (by omega)
    have last : headroom≤c.L:=by dsimp only [limit] at large;omega
    apply le_trans _ last
    apply (Nat.mul_le_mul_left 8 (Nat.mul_le_mul a b)).trans
    decide +kernel
  exact ⟨big,cl,ec,cf,(by omega : F k+G k≤c.L).trans cl,p _ _ (c.prime v).two_le long.ge⟩

/-- One may exclude large retained primes using solely a bound on f+g. It is
convenient to rescale by eight so the metadata of the earlier proxy state can
be reused even for dyadic orders zero and one. -/
theorem base_le {r f g : ℕ} (c : Family r) {b : Fin r→Option Bool} (sum : 2≤f+g)
    (size : 8*(f+g)≤c.L) (hit : (f+g)*dust c b=f*NX c b+g*NY c b) :
    ∀i,b i=some true → c.p i≤c.L := by
  let aux : Family r:={c with k:=8*(f+g)-1,kp:=by omega}
  have frac : 8*f+8*g=(aux.k+1)*1:=by dsimp [aux];omega
  have other : (8*f+8*g)*dust aux b=(8*f)*NX aux b+(8*g)*NY aux b:=by
    change (8*f+8*g)*dust c b=(8*f)*NX c b+(8*g)*NY c b
    calc
      _ = 8*((f+g)*dust c b):=by ring
      _ = _:=by rw [hit];ring
  have sz : aux.k+1≤aux.L:=by dsimp [aux];omega
  intro i bit
  have yes:=retained (c:=aux) (f:=8*f) (g:=8*g) (l:=1) frac
    (fun i=>Nat.not_dvd_of_pos_of_lt (by decide) (c.prime i).one_lt) other i bit
  simpa only [max_eq_right sz] using yes

end OMA.FixedModeSmallSetup245212
