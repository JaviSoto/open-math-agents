import FixedRankHeight245212

/-! Explicit thresholds for the exact dyadic coefficient and a long prime
power; all parameters outside the exponents are the rank and a ratio bound. -/
namespace OMA.FixedTallScalar245212
open Nat OMA.FixedRankHeight245212 OMA.FixedRankStep245212
open OMA.ThreeMovingOriginal245212 (F G)

def h (r : ℕ) := 12*exponent r+4
def threshold (r C : ℕ) := 128 + 2*r*2^r + OMA.SingleMovingHeight245212.constant (exponent r) +
  (C+1) + 16*(h r*degree r+2)^2

theorem scale {r C m k L : ℕ} (large : threshold r C ≤ m) (width : L≤C*m)
    (dyad : 2^k≤OMA.SingleMovingHeight245212.constant (exponent r)*(L+1)^(2*exponent r)) :
    let x:=m^h r
    128≤x ∧ F k+G k≤x ∧ L≤x ∧ 2*r*2^r≤x ∧
      ∀ p e : ℕ, 2≤p → m≤e+1 → x^(degree r)<p^e := by
  dsimp only
  have raw:=large
  dsimp only [threshold] at raw
  have three : 3 ≤ m:=by omega
  have m0 : 0 < m:=by omega
  have mh : m ≤ m^h r:=Nat.le_self_pow (by dsimp [h];omega) _
  have mc : C < m:=by omega
  have Len : L+1 ≤ m^3 := by
    have prod:=Nat.mul_lt_mul_of_pos_right mc m0
    exact (show L+1 ≤ m^2 by nlinarith only [width,prod]).trans
      (Nat.pow_le_pow_right m0 (by decide))
  have c0 : OMA.SingleMovingHeight245212.constant (exponent r) ≤ m:=by omega
  have kd : 2^k ≤ m^(6*exponent r+1) := by
    calc
      _ ≤ _ := dyad
      _ ≤ m*(m^3)^(2*exponent r) := Nat.mul_le_mul c0 (Nat.pow_le_pow_left Len _)
      _ = _ := by rw [←pow_mul,pow_succ,show 3*(2*exponent r)=6*exponent r by ring];ring
  have km : k+1≤2^k:=Nat.lt_two_pow_self
  have fg : F k+G k=(k+1)*2^(k+1) := by
    dsimp [F,G];have:=Nat.two_pow_pos (k+1)
    nlinarith only [Nat.sub_add_cancel (show 1≤2^(k+1) by omega)]
  refine ⟨(by omega : 128 ≤ m).trans mh,?_,(Nat.le_succ L).trans (Len.trans
    (Nat.pow_le_pow_right m0 (by dsimp [h];omega))),(by omega : 2*r*2^r ≤ m).trans mh,?_⟩
  · rw [fg,pow_succ]
    calc
      _ ≤ m^(6*exponent r+1)*(m^(6*exponent r+1)*m) :=
        Nat.mul_le_mul (km.trans kd) (Nat.mul_le_mul kd (by omega))
      _ = m^((6*exponent r+1)+(6*exponent r+1)+1) := by rw [pow_succ,pow_add];ring
      _ ≤ m^h r := Nat.pow_le_pow_right m0 (by dsimp [h];omega)
  · intro p e pp ell
    let J:=h r*degree r
    have cutoff : 16*((J+1)+1)^2 ≤ m:=by change 16*(h r*degree r+2)^2 ≤ m;omega
    have pwr:=OMA.ComplementarySize245212.absorb cutoff
    have bigger : 2*m^J < m^(2*(J+1)) := by
      have more:=Nat.pow_le_pow_right m0 (show J+1≤2*(J+1) by omega)
      exact (show 2*m^J < m^(J+1) by rw [_root_.pow_succ'];exact Nat.mul_lt_mul_of_pos_right (by omega) (pow_pos m0 _)).trans_le more
    have z:=bigger.trans_le (pwr.trans (Nat.pow_le_pow_right (by decide) ell))
    rw [_root_.pow_succ'] at z
    have le:=Nat.lt_of_mul_lt_mul_left z
    exact (by simpa only [←pow_mul,J] using le : (m^h r)^degree r<2^e).trans_le (Nat.pow_le_pow_left pp e)

end OMA.FixedTallScalar245212
