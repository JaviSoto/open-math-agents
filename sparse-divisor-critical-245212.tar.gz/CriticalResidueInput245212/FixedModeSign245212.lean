import FixedModeProduct245212

/-! The restoration sign is strict. A dropped coordinate forces a strict
score increase; if none is dropped, equality is the excluded last-prime pole. -/
namespace OMA.FixedModeSign245212
open Finset Nat ArithmeticFunction OMA.Smooth245212 OMA.FixedRankGap245212 OMA.FixedModeRestore245212
open OMA.FixedModeProduct245212 OMA.TwoTallLocal245212
open OMA.ThreeMovingOriginal245212 (F G)
open scoped ArithmeticFunction.sigma

theorem drop_sign {r : ℕ} (c : Family r) {b : Fin r→Option Bool} {v : Fin r}
    {f g : ℕ} (fp : 0<f) (keep : b v=some true) (only : ∀i,i≠v → b i≠some true)
    (d : (dropped b).Nonempty) (hit : (f+g)*dust c b=f*NX c b+g*NY c b)
    (actual : score f g (exactX c) (exactY c)=(f+g:ℕ)) :
    (f:ℚ)*ox c b ∅ v<g*((c.p v:ℚ)-1)*oy c b ∅ v := by
  let V:=val c b f g
  have same:=OMA.FixedModeRestore245212.same c b f g hit actual
  have step (s : Finset (Fin r)) {i} (fr : i∉s) (drop : b i=some false) : V s<V (insert i s):=by
    have x:=caps c b s i
    have inc:=OMA.MiddleChange245212.dropped (f:=f) (g:=g) (c.prime i) (c.positive i) x.1 x.2.1
    have z:=change c b f g s fr
    rw [drop] at z
    have ni : 0<(f:ℚ)/(2*(c.p i:ℚ)):=by have:=(c.prime i).pos;positivity
    exact sub_pos.mp (z ▸ ni.trans_le inc)
  have adv (s : Finset (Fin r)) {i} (iv : i≠v) (fr : i∉s): V s≤V (insert i s):=by
    cases tag : b i with
    | none=>have q:=change c b f g s fr;rw [tag,OMA.MiddleChange245212.exact_inc] at q;exact (sub_eq_zero.mp q).symm.le
    | some t=>cases t with
      | false=>exact (step s fr tag).le
      | true=>exact False.elim (only i iv tag)
  have finish (s : Finset (Fin r)) (hv : v∈s) : V s≤V univ:=by
    have grow (t : Finset (Fin r)) : V s≤V (t∪s):=by
      induction t using Finset.induction_on with
      | empty=>simp
      | @insert i t fresh ih=>
        by_cases it : i∈t∪s
        · simpa only [insert_union,insert_eq_of_mem it] using ih
        · have iv : i≠v:=fun h=>it (h ▸ mem_union_right _ hv)
          simpa only [insert_union] using ih.trans (adv (t∪s) iv it)
    have union : (univ:Finset (Fin r))∪s=univ:=Finset.union_eq_left.mpr (subset_univ _)
    simpa only [union] using grow univ
  obtain ⟨i,im⟩:=d
  have fl : b i=some false:=(mem_filter.mp im).2
  have iv : i≠v:=by rintro rfl;simp_all
  have plus:=step {v} (by simpa using iv : i∉({v}:Finset (Fin r))) fl
  have minus : V {v}-V ∅<0:=sub_neg.mpr ((plus.trans_le
    (finish (insert i {v}) (mem_insert_of_mem (mem_singleton_self v)))).trans_eq same.symm)
  have formula:=change c b f g ∅ (notMem_empty v)
  rw [insert_empty,keep,OMA.MiddleChange245212.retained (c.prime v)] at formula
  have den : 0<((c.e v:ℚ)+1)*((c.p v:ℚ)-1)^2*(c.p v:ℚ)^c.e v:=by
    have : (1:ℚ)<c.p v:=by exact_mod_cast (c.prime v).one_lt
    positivity
  change val c b f g {v}-val c b f g ∅<0 at minus
  rw [formula] at minus
  exact sub_neg.mp (by simpa only [zero_mul] using (div_lt_iff₀ den).mp minus)

theorem side {r : ℕ} (c : Family r) (odd : ∀i,Odd (c.p i)) {b : Fin r→Option Bool} {v : Fin r}
    (keep : b v=some true) (only : ∀i,i≠v → b i≠some true)
    (weak : (F c.k:ℚ)*ox c b ∅ v≤(G c.k:ℚ)*((c.p v:ℚ)-1)*oy c b ∅ v)
    (hit : (F c.k+G c.k)*dust c b=F c.k*NX c b+G c.k*NY c b)
    (actual : score (F c.k) (G c.k) (exactX c) (exactY c)=(F c.k+G c.k:ℕ))
    (original : OeisA245212.a (2^c.k*total c.p c.e)=(σ 1 (2^c.k*total c.p c.e):ℤ)) :
    mult c b*W (pref c b)<(c.p v-1)*σ 1 (pref c b) := by
  let t:=(univ:Finset (Fin r)).erase v
  let de i:=Dn (c.p i) (c.e i) (b i)
  let D:=∏i∈t,de i
  have pos : (0:ℚ)<D:=by exact_mod_cast prod_pos (fun i _=>Dpos (c.prime i) _ (b i))
  have oxD : ox c b ∅ v*(D:ℚ)=((∏i∈t,Nx (c.p i) (c.e i) (b i)):ℕ) := by
    dsimp only [ox,xx,tag,notMem_empty,if_false,D];push_cast;rw [←prod_mul_distrib]
    exact prod_congr rfl (fun i _=>(moments (c.prime i) (c.e i) (b i)).1)
  have oyD : oy c b ∅ v*(D:ℚ)=((∏i∈t,Ny (c.p i) (c.e i) (b i)):ℕ) := by
    dsimp only [oy,yy,tag,notMem_empty,if_false,D];push_cast;rw [←prod_mul_distrib]
    exact prod_congr rfl (fun i _=>(moments (c.prime i) (c.e i) (b i)).2)
  have ⟨wp,sp,_⟩:=prefix_moments c odd b
  have ⟨_,x,y⟩:=others c keep only
  change (∏i∈t,_) = _ at x y
  rw [x] at oxD
  rw [y] at oyD
  have left : ((F c.k:ℚ)*ox c b ∅ v)*D=(mult c b*W (pref c b):ℕ):=by
    rw [mul_assoc,oxD,wp];push_cast;ring
  have right : ((G c.k:ℚ)*((c.p v:ℚ)-1)*oy c b ∅ v)*D=((c.p v-1)*σ 1 (pref c b):ℕ):=by
    rw [mul_assoc,oyD,sp];push_cast [Nat.cast_sub (c.prime v).pos];ring
  by_cases drop : (dropped b).Nonempty
  · have fp : 0<F c.k:=by dsimp [F];omega
    have sign:=drop_sign c fp keep only drop hit actual
    have z:=mul_lt_mul_of_pos_right sign pos
    rwa [left,right,Nat.cast_lt] at z
  · have emp : dropped b=∅:=not_nonempty_iff_eq_empty.mp drop
    have C : mult c b=1:=by simp [mult,emp]
    rw [C,one_mul]
    have le:=mul_le_mul_of_nonneg_right weak pos.le
    rw [left,right,C,one_mul,Nat.cast_le] at le
    refine lt_of_le_of_ne le ?_
    intro eq
    have part:=(partition keep only).2
    rw [emp,union_empty] at part
    have joined : pref c b*(c.p v)^c.e v=2^c.k*total c.p c.e:=by
      dsimp [pref,total];rw [part,mul_assoc,prod_erase_mul _ _ (mem_univ v)]
    have eqn : OeisA245212.a (pref c b*(c.p v)^c.e v)=(σ 1 (pref c b*(c.p v)^c.e v):ℤ):=by rwa [joined]
    have cop : (pref c b).Coprime (c.p v):=by
      dsimp only [pref];apply Nat.Coprime.mul_left
      · exact (Nat.coprime_two_left.mpr (odd v)).pow_left _
      · apply Nat.coprime_prod_left_iff.mpr
        intro i im
        have iv:=ne_of_mem_erase (part ▸ im)
        exact (((Nat.coprime_primes (c.prime i) (c.prime v)).mpr (c.inj.ne iv)).pow_left _)
    have pp : 0<pref c b:=mul_pos (Nat.two_pow_pos _) (prod_pos (fun i _=>pow_pos (c.prime i).pos _))
    have pn : c.p v≠2:=by have:=(c.prime v).odd_iff.mp (odd v);omega
    have no:=OMA.PrimePowerDiv245212.nonzero pp (c.prime v) pn cop (c.e v) eqn
    apply no
    have ez:=congrArg (fun x:ℕ=>(x:ℤ)) eq
    push_cast [Nat.cast_sub (c.prime v).pos] at ez
    exact sub_eq_zero.mpr ez

end OMA.FixedModeSign245212
