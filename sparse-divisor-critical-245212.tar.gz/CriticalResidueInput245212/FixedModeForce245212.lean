import FixedModeRestore245212
import MiddlePower245212
/-! In a mixed exact equality at large dyadic order, only the longest odd
prime can be retained: every other local moment must be exact or dropped. -/
namespace OMA.FixedModeForce245212
open Nat Finset OMA.FixedRankGap245212 OMA.FixedModeRestore245212 OMA.MiddleChange245212
variable {r : ℕ}

theorem force (c : Family r) (b : Fin r→Option Bool) {f g : ℕ} (gp : 0<g)
    (fg : c.k*g≤f) (k0 : 256≤c.k) (v : Fin r) (long : c.e v+1=c.L) (move : b v≠none)
    (small : ∀i,b i=some true → c.p i≤c.L)
    (hit : (f+g)*dust c b=f*NX c b+g*NY c b)
    (actual : score f g (exactX c) (exactY c)=(f+g:ℕ)) :
    b v=some true ∧ (∀i,i≠v → b i≠some true) ∧
    (f:ℚ)*ox c b ∅ v≤(g:ℚ)*((c.p v:ℚ)-1)*oy c b ∅ v := by
  classical
  let V:=val c b f g
  have endEq : V ∅=V univ:=same c b f g hit actual
  have gain (s : Finset (Fin r)) {i} (iv : i≠v) (fr : i∉s) (keep : b i=some true) :
      (g:ℚ)/((c.L:ℚ)^3*(c.p i:ℚ)^c.e i)≤V (insert i s)-V s := by
    have bounds:=caps c b s i
    have ey:=other_length c b s iv.symm
    have len : (c.e v:ℚ)+1=c.L:=by exact_mod_cast long
    rw [len] at ey
    have z:=retained_gain (g:=g) (c.prime i) c.kp fg (small i keep) (c.cap i) bounds.1 bounds.2.1 ey
    change _≤val c b f g (insert i s)-val c b f g s
    rw [change c b f g s fr,keep]
    exact z
  have advance (s : Finset (Fin r)) {i} (iv : i≠v) (fr : i∉s) : V s≤V (insert i s) := by
    cases bi : b i with
    | none=>
      have diff:=change c b f g s fr
      rw [bi,exact_inc] at diff
      exact (sub_eq_zero.mp diff).symm.le
    | some tag=>
      cases tag with
      | true=>exact sub_nonneg.mp ((by positivity : (0:ℚ)≤g/((c.L:ℚ)^3*(c.p i:ℚ)^c.e i)).trans (gain s iv fr bi))
      | false=>
        have bounds:=caps c b s i
        have h:=dropped (f:=f) (g:=g) (c.prime i) (c.positive i) bounds.1 bounds.2.1
        have diff:=change c b f g s fr
        rw [bi] at diff
        change val c b f g s≤val c b f g (insert i s)
        apply sub_nonneg.mp
        rw [diff]
        exact (by positivity : (0:ℚ)≤ f/(2*(c.p i:ℚ))).trans h
  have endBound (s : Finset (Fin r)) (sv : v∈s) : V s≤V univ := by
    have h (t : Finset (Fin r)) : V s≤V (t∪s) := by
      induction t using Finset.induction_on with
      | empty=>simp
      | @insert i t fresh ih=>
        by_cases it : i∈t∪s
        · simpa only [insert_union,insert_eq_of_mem it] using ih
        · have iv : i≠v:=fun h=>it (h ▸ mem_union_right _ sv)
          simpa only [insert_union] using ih.trans (advance (t∪s) iv it)
    have union : (univ:Finset (Fin r))∪s=univ:=Finset.union_eq_left.mpr (subset_univ _)
    simpa only [union] using h univ
  have initial : V {v}≤V ∅:=(endBound _ (mem_singleton_self v)).trans_eq endEq.symm
  have base:=caps c b ∅ v
  have changeV : V {v}-V ∅=inc (c.p v) (c.e v) f g (b v) (ox c b ∅ v) (oy c b ∅ v):=by
    simpa only [insert_empty] using change c b f g ∅ (notMem_empty v)
  have fp : 0<f:=(Nat.mul_pos (show 0<c.k by omega) gp).trans_le fg
  have vv : b v=some true := by
    rcases Option.ne_none_iff_exists'.mp move with ⟨flag,fl⟩
    cases flag with
    | true=>exact fl
    | false=>
      have z:=dropped (f:=f) (g:=g) (c.prime v) (c.positive v) base.1 base.2.1
      rw [fl] at changeV
      have nz : 0<(f:ℚ)/(2*c.p v):=by have:=(c.prime v).pos;positivity
      linarith only [changeV,initial,z,nz]
  rw [vv] at changeV
  have p2 : (1:ℚ)<c.p v:=by exact_mod_cast (c.prime v).one_lt
  have den : 0<((c.e v:ℚ)+1)*((c.p v:ℚ)-1)^2*(c.p v:ℚ)^c.e v:=by positivity
  have formula:=retained (f:=f) (g:=g) (e:=c.e v) (c.prime v) (ox c b ∅ v) (oy c b ∅ v)
  have gap : (f:ℚ)*ox c b ∅ v≤g*((c.p v:ℚ)-1)*oy c b ∅ v:=by
    have low:=sub_nonpos.mpr initial
    rw [changeV,formula] at low
    exact sub_nonpos.mp (by simpa only [zero_mul] using (div_le_iff₀ den).mp low)
  refine ⟨vv,?_,gap⟩
  intro i iv keep
  have fr : i∉({v}:Finset (Fin r)):=by simpa
  have perk:=gain {v} iv fr keep
  have up:=(endBound (insert i {v}) (mem_insert_of_mem (mem_singleton_self v))).trans_eq endEq.symm
  have gl : 0<(g:ℚ)/((c.L:ℚ)^3*(c.p i:ℚ)^c.e i):=by
    have lp : 0<c.L:=by omega
    have pi:=(c.prime i).pos
    positivity
  have loss : V {v}-V ∅<0:=by linarith only [perk,up,gl]
  have neg : (f:ℚ)*ox c b ∅ v<g*((c.p v:ℚ)-1)*oy c b ∅ v:=by
    rw [changeV,formula] at loss
    exact sub_neg.mp (by simpa only [zero_mul] using (div_lt_iff₀ den).mp loss)
  have fk : (c.k:ℚ)*g≤f:=by exact_mod_cast fg
  have risk : (c.k:ℚ)<((c.p v:ℚ)-1)*oy c b ∅ v := by
    apply lt_of_mul_lt_mul_right (a:=(g:ℚ)) _ (by positivity)
    nlinarith only [neg,mul_le_mul_of_nonneg_left base.1 (Nat.cast_nonneg (α:=ℚ) f),fk]
  have ey:=other_length c b ∅ iv
  have ep : 0<(c.e i:ℚ)+1:=by positivity
  have slope : c.k*(c.e i+1)<4*c.p v:=by
    exact_mod_cast (show (c.k:ℚ)*((c.e i:ℚ)+1)<4*(c.p v:ℚ) by
      nlinarith only [mul_lt_mul_of_pos_right risk ep,
        mul_le_mul_of_nonneg_left ey (show 0≤(c.p v:ℚ)-1 by linarith),p2])
  have vl:=small v vv
  have sep : 16*(c.e i+1)<c.e v+1:=by
    have ks:=Nat.mul_le_mul_right (c.e i+1) k0
    omega
  have powers:=OMA.MiddlePower245212.right k0 (c.prime v).two_le (small i keep) slope sep long
  have powerq : (c.L:ℚ)^3*(c.p i:ℚ)^c.e i < (c.p v:ℚ)^c.e v:=by exact_mod_cast powers
  have cost:=retained_loss (f:=f) (g:=g) (e:=c.e v) (c.prime v) (zero_le_one.trans base.1) base.2.2
  have comp : (g:ℚ)/(c.p v:ℚ)^c.e v < g/((c.L:ℚ)^3*(c.p i:ℚ)^c.e i):=by
    apply div_lt_div_of_pos_left (by positivity) _ powerq
    have lp : 0<c.L:=by omega
    have pi:=(c.prime i).pos
    positivity
  rw [←changeV] at cost
  let P:ℚ:=g/(c.p v:ℚ)^c.e v
  let Q:ℚ:=g/((c.L:ℚ)^3*(c.p i:ℚ)^c.e i)
  have d : -P≤V {v}-V ∅:=by simpa only [P,neg_div] using cost
  change P<Q at comp
  change Q≤V (insert i {v})-V {v} at perk
  linarith only [d,comp,perk,up]

end OMA.FixedModeForce245212
