import FixedModeAnyProduct245212

/-! Strictness, without a restriction on the physical power of two. -/
namespace OMA.FixedModeAnySign245212
open Finset Nat ArithmeticFunction OMA.Smooth245212 OMA.FixedRankGap245212 OMA.FixedModeRestore245212
open OMA.FixedModeProduct245212 (exactSet dropped mult others partition)
open OMA.FixedModeSign245212 (drop_sign)
open OMA.FixedModeAnyProduct245212 OMA.TwoTallLocal245212
open OMA.ThreeMovingOriginal245212 (F G)
open scoped ArithmeticFunction.sigma
theorem side {r : ℕ} (k : ℕ) (c : Family r) (odd : ∀i,Odd (c.p i)) {b : Fin r→Option Bool} {v : Fin r}
    (keep : b v=some true) (only : ∀i,i≠v → b i≠some true)
    (weak : (F k:ℚ)*ox c b ∅ v≤(G k:ℚ)*((c.p v:ℚ)-1)*oy c b ∅ v)
    (hit : (F k+G k)*dust c b=F k*NX c b+G k*NY c b)
    (actual : score (F k) (G k) (exactX c) (exactY c)=(F k+G k:ℕ))
    (original : OeisA245212.a (2^k*total c.p c.e)=(σ 1 (2^k*total c.p c.e):ℤ)) :
    mult c b*W (pref k c b)<(c.p v-1)*σ 1 (pref k c b) := by
  let t:=(univ:Finset (Fin r)).erase v
  let de i:=Dn (c.p i) (c.e i) (b i)
  let D:=∏i∈t,de i
  have pos : (0:ℚ)<D:=by exact_mod_cast prod_pos (fun i _=>Dpos (c.prime i) _ (b i))
  have oxD : ox c b ∅ v*(D:ℚ)=((∏i∈t,Nx (c.p i) (c.e i) (b i)):ℕ) := by
    dsimp only [ox,xx,tag,notMem_empty,if_false,D];push_cast;rw [←prod_mul_distrib]
    exact prod_congr rfl (fun i _=>(moments (c.prime i) (c.e i) (b i)).1)
  have oyD : oy c b ∅ v*(D:ℚ)=((∏i∈t,Ny (c.p i) (c.e i) (b i)):ℕ) := by
    dsimp only [oy,yy,tag,notMem_empty,if_false,D];push_cast;rw [←prod_mul_distrib]
    exact prod_congr rfl (fun i _=>(moments (c.prime i) (c.e i) (b i)).2)
  have ⟨wp,sp,_⟩:=prefix_moments k c odd b
  have ⟨_,x,y⟩:=others c keep only
  change (∏i∈t,_) = _ at x y
  rw [x] at oxD
  rw [y] at oyD
  have left : ((F k:ℚ)*ox c b ∅ v)*D=(mult c b*W (pref k c b):ℕ):=by
    rw [mul_assoc,oxD,wp];push_cast;ring
  have right : ((G k:ℚ)*((c.p v:ℚ)-1)*oy c b ∅ v)*D=((c.p v-1)*σ 1 (pref k c b):ℕ):=by
    rw [mul_assoc,oyD,sp];push_cast [Nat.cast_sub (c.prime v).pos];ring
  by_cases drop : (dropped b).Nonempty
  · have fp : 0<F k:=by dsimp [F];omega
    have sign:=drop_sign c fp keep only drop hit actual
    have z:=mul_lt_mul_of_pos_right sign pos
    rwa [left,right,Nat.cast_lt] at z
  · have emp : dropped b=∅:=not_nonempty_iff_eq_empty.mp drop
    have C : mult c b=1:=by simp [mult,emp]
    rw [C,one_mul]
    have le:=mul_le_mul_of_nonneg_right weak pos.le
    rw [left,right,C,one_mul,Nat.cast_le] at le
    refine lt_of_le_of_ne le ?_
    intro eq
    have part:=(partition keep only).2
    rw [emp,union_empty] at part
    have joined : pref k c b*(c.p v)^c.e v=2^k*total c.p c.e:=by
      dsimp [pref,total];rw [part,mul_assoc,prod_erase_mul _ _ (mem_univ v)]
    have eqn : OeisA245212.a (pref k c b*(c.p v)^c.e v)=(σ 1 (pref k c b*(c.p v)^c.e v):ℤ):=by rwa [joined]
    have cop : (pref k c b).Coprime (c.p v):=by
      dsimp only [pref];apply Nat.Coprime.mul_left
      · exact (Nat.coprime_two_left.mpr (odd v)).pow_left _
      · apply Nat.coprime_prod_left_iff.mpr
        intro i im
        have iv:=ne_of_mem_erase (part ▸ im)
        exact (((Nat.coprime_primes (c.prime i) (c.prime v)).mpr (c.inj.ne iv)).pow_left _)
    have pp : 0<pref k c b:=mul_pos (Nat.two_pow_pos _) (prod_pos (fun i _=>pow_pos (c.prime i).pos _))
    have pn : c.p v≠2:=by have:=(c.prime v).odd_iff.mp (odd v);omega
    have no:=OMA.PrimePowerDiv245212.nonzero pp (c.prime v) pn cop (c.e v) eqn
    apply no
    have ez:=congrArg (fun x:ℕ=>(x:ℤ)) eq
    push_cast [Nat.cast_sub (c.prime v).pos] at ez
    exact sub_eq_zero.mpr ez


end OMA.FixedModeAnySign245212
