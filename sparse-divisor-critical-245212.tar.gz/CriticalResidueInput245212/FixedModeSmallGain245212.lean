import FixedModeRestore245212

/-! With at least five odd factors the other ordinary moments make
every restoration away from the longest coordinate profitable, even at k=0. -/
namespace OMA.FixedModeSmallGain245212
open Nat Finset OMA.FixedRankGap245212 OMA.FixedModeRestore245212 OMA.MiddleChange245212
open OMA.TwoTallLocal245212
open OMA.Smooth245212 (Y)
open OMA.ThreeMovingLocal245212 (den)
open private OMA.ThreeMovingLocal245212.quotients from ThreeMovingLocal245212
variable {r : ℕ}

private theorem localY {p e : ℕ} (hp : p.Prime) (he : 0<e) (odd : Odd p) (mode : Option Bool) :
    yy' p e mode≤3/4 := by
  have pt:=hp.two_le
  obtain ⟨j,hj⟩:=odd
  have pr : (3:ℚ)≤p:=by exact_mod_cast (show 3≤p by omega)
  have ep : (1:ℚ)≤e:=by exact_mod_cast he
  have B : (0:ℚ)<(e:ℚ)+1:=by positivity
  have u : (0:ℚ)<(p:ℚ)-1:=by linarith
  have yn : ThreeMovingLocal245212.yy p e true = (p:ℚ)/(((e:ℚ)+1)*(p-1)) := by
    dsimp [ThreeMovingLocal245212.yy,OMA.ThreeMovingLocal245212.yn,den]
    push_cast [Nat.cast_sub hp.one_le];field_simp
  have yb : ThreeMovingLocal245212.yy p e true≤3/4 := by
    rw [yn,div_le_iff₀ (mul_pos B u)]
    nlinarith only [pr,mul_nonneg (sub_nonneg.mpr ep) u.le]
  rcases mode with _|b
  · have q:=(OMA.ThreeMovingLocal245212.quotients (e:=e) hp).2
    change Y p (some e)≤3/4
    have pw : 0<(p:ℚ)^e := by positivity
    have dn : 0≤1/(((e:ℚ)+1)*((p:ℚ)-1)^2*(p:ℚ)^e):=by positivity
    linarith only [q,mul_nonneg u.le dn,yb]
  · cases b
    · change ThreeMovingLocal245212.yy p e false≤_
      simp [ThreeMovingLocal245212.yy,OMA.ThreeMovingLocal245212.yn,den]
      rw [←one_div];apply (div_le_iff₀ B).mpr;linarith only [ep]
    · exact yb

theorem other_short (c : Family r) (odd : ∀i,Odd (c.p i)) (many : 5≤r)
    (b : Fin r→Option Bool) (s : Finset (Fin r)) {i z : Fin r} (ne : z≠i) :
    oy c b s i*((c.e z:ℚ)+1)≤27/32 := by
  let t:=(univ:Finset (Fin r)).erase i
  have zm : z∈t:=mem_erase.mpr ⟨ne,mem_univ _⟩
  have card : 3≤(t.erase z).card:=by
    rw [card_erase_of_mem zm];dsimp [t];rw [card_erase_of_mem (mem_univ _)]
    have count : (univ : Finset (Fin r)).card=r:=by simp
    rw [count];omega
  have nn (j) : 0≤FixedModeRestore245212.yy c b s j := (ranges (c.prime j) (c.positive j) (tag b s j)).2.2.1
  have rest : ∏j∈t.erase z,FixedModeRestore245212.yy c b s j≤27/64:=calc
    _ ≤ ∏ _j∈t.erase z,(3/4:ℚ) := prod_le_prod (fun j _=>nn j)
      (fun j _=>localY (c.prime j) (c.positive j) (odd j) (tag b s j))
    _ = (3/4:ℚ)^(t.erase z).card := by rw [prod_const]
    _ ≤ (3/4:ℚ)^3 := pow_le_pow_of_le_one (by norm_num) (by norm_num) card
    _ = _ := by norm_num
  have ex := (le_div_iff₀ (by positivity)).mp (ranges (c.prime z) (c.positive z) (tag b s z)).2.2.2
  change FixedModeRestore245212.yy c b s z*((c.e z:ℚ)+1)≤2 at ex
  change (∏j∈t,FixedModeRestore245212.yy c b s j)*_≤_
  rw [←prod_erase_mul t _ zm,mul_assoc]
  exact (mul_le_mul rest ex (mul_nonneg (nn z) (by positivity)) (by norm_num)).trans_eq (by norm_num)

theorem gain (c : Family r) (odd : ∀i,Odd (c.p i)) (many : 5≤r)
    (b : Fin r→Option Bool) {f g : ℕ} (fg : g≤f) (v : Fin r) (long : c.e v+1=c.L)
    (small : ∀i,b i=some true → c.p i≤c.L) (s : Finset (Fin r)) {i : Fin r}
    (iv : i≠v) (fr : i∉s) (keep : b i=some true) :
    (g:ℚ)/(32*(c.L:ℚ)^3*(c.p i:ℚ)^c.e i) ≤ val c b f g (insert i s)-val c b f g s := by
  have pp : (1:ℚ)<c.p i:=by exact_mod_cast (c.prime i).one_lt
  have base : (c.p i:ℚ)≤c.L:=by exact_mod_cast small i keep
  have lp : (0:ℚ)<c.L:=by linarith
  have el : (c.e i:ℚ)+1≤c.L:=by exact_mod_cast c.cap i
  have eqL : (c.e v:ℚ)+1=c.L:=by exact_mod_cast long
  have ey:=other_short c odd many b s iv.symm
  rw [eqL] at ey
  have bounds:=caps c b s i
  let u:ℚ:=(c.p i:ℚ)-1
  have up : 0<u:=by dsimp [u];linarith
  have ub : u≤c.L:=by dsimp [u];linarith
  have y : u*oy c b s i≤27/32:=by
    rw [mul_comm];exact (mul_le_mul_of_nonneg_left ub bounds.2.1).trans ey
  have gf : (g:ℚ)≤f:=by exact_mod_cast fg
  have num : (g:ℚ)/32≤f*ox c b s i-g*u*oy c b s i:=by
    nlinarith only [mul_le_mul_of_nonneg_left y (Nat.cast_nonneg (α:=ℚ) g),
      mul_le_mul_of_nonneg_left bounds.1 (Nat.cast_nonneg (α:=ℚ) f),gf,Nat.cast_nonneg (α:=ℚ) g]
  have den : ((c.e i:ℚ)+1)*u^2 ≤(c.L:ℚ)^3:=by
    calc
      _ ≤ (c.L:ℚ)*(c.L:ℚ)^2:=mul_le_mul el (pow_le_pow_left₀ up.le ub _) (sq_nonneg _) lp.le
      _ = _ := by ring
  rw [change c b f g s fr,keep,retained (c.prime i)]
  change _≤(_-g*u*_)/(((c.e i:ℚ)+1)*u^2*(c.p i:ℚ)^c.e i)
  calc
    _ = ((g:ℚ)/32)/((c.L:ℚ)^3*(c.p i:ℚ)^c.e i) := by ring
    _ ≤ _ := (div_le_div_of_nonneg_left (by positivity) (by positivity)
      (mul_le_mul_of_nonneg_right den (by positivity))).trans (div_le_div_of_nonneg_right num (by positivity))

theorem risk (c : Family r) (odd : ∀i,Odd (c.p i)) (many : 5≤r)
    (b : Fin r→Option Bool) {f g : ℕ} (gp : 0<g) (fg : g≤f) (v : Fin r) {i : Fin r}
    (iv : i≠v) (neg : (f:ℚ)*ox c b ∅ v < g*((c.p v:ℚ)-1)*oy c b ∅ v) :
    32*(c.e i+1)≤27*c.p v := by
  have p2 : (1:ℚ)<c.p v:=by exact_mod_cast (c.prime v).one_lt
  have ey:=other_short c odd many b ∅ iv
  have gf : (g:ℚ)≤f:=by exact_mod_cast fg
  have x:=mul_le_mul_of_nonneg_left (caps c b ∅ v).1 (Nat.cast_nonneg (α:=ℚ) f)
  have one : (1:ℚ)<((c.p v:ℚ)-1)*oy c b ∅ v:=by
    apply lt_of_mul_lt_mul_left (a:=(g:ℚ)) _ (by positivity)
    linarith only [gf,x,neg,mul_assoc (g:ℚ) ((c.p v:ℚ)-1) (oy c b ∅ v)]
  exact_mod_cast (show 32*((c.e i:ℚ)+1)≤27*(c.p v:ℚ) by
    nlinarith only [mul_lt_mul_of_pos_right one (by positivity : (0:ℚ)<(c.e i:ℚ)+1),
      mul_le_mul_of_nonneg_left ey (show 0≤(c.p v:ℚ)-1 by linarith),p2])

#print axioms gain
#print axioms risk
end OMA.FixedModeSmallGain245212
