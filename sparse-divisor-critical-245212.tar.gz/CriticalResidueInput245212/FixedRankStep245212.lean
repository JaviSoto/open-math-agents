import FixedRankGap245212
import SingleMovingStep245212

/-! Uniform integer separation for a finite list of odd prime powers. -/
namespace OMA.FixedRankStep245212
open Nat Finset OMA.TwoTallLocal245212 OMA.ThreeMovingLocal245212 OMA.FixedRankGap245212
open private OMA.CofactorEffectiveAtom245212.product_error from CofactorEffectiveAtom245212
variable {r : ℕ}

def cut (r x j : ℕ) := x^((3*r+4)^j)
def degree (r : ℕ) := (3*r+4)^(2*r+1)

theorem cut_succ (r x j : ℕ) : cut r x (j+1)=(cut r x j)^(3*r+4) := by
  simp only [cut,pow_succ (3*r+4),←pow_mul]

theorem cut_mono (r : ℕ) {x : ℕ} (hx : 1≤x) : Monotone (cut r x) :=
  fun _ _ z=>Nat.pow_le_pow_right hx (Nat.pow_le_pow_right (by omega) z)

theorem empty_band (x : ℕ) (hx : 1≤x) (p : Fin r ⊕ Fin r →ℕ) :
    ∃j : Fin (2*r+1),∀i, p i ≤ cut r x j.val ∨ cut r x (j.val+1) < p i := by
  by_contra! no
  choose f above below using no
  have inj:Function.Injective f := by
    intro j k eqn
    rcases lt_trichotomy j k with lt|eq|gt
    · have h := cut_mono r hx (show j.val+1≤k.val from lt)
      have impossible:=(below j).trans h
      rw [eqn] at impossible
      exact False.elim ((above k).not_ge impossible)
    · exact eq
    · have h := cut_mono r hx (show k.val+1≤j.val from gt)
      have impossible:=(below k).trans h
      rw [←eqn] at impossible
      exact False.elim ((above j).not_ge impossible)
  have h:=Fintype.card_le_of_injective _ inj
  simp only [Fintype.card_fin,Fintype.card_sum] at h
  omega

private theorem integer_gap (c : Family r) (bits : Fin r→Option Bool) (f g : ℕ)
    (different : (f+g)*dust c bits ≠ f*NX c bits+g*NY c bits) :
    (1:ℚ)≤|score f g (x' c bits) (y' c bits)-(f+g:ℕ)| * dust c bits := by
  let B:=dust c bits
  let T:=f*NX c bits+g*NY c bits
  let L:ℤ:=(T:ℤ)-((f+g)*B:ℕ)
  have nz : L≠0 := fun h => different (by exact_mod_cast (sub_eq_zero.mp h).symm)
  have la : (1:ℤ)≤|L| := by have:=abs_pos.mpr nz;omega
  have raw : (1:ℚ)≤|(T:ℚ)-((f+g)*B:ℕ)| := by dsimp [L] at la;exact_mod_cast la
  have ab:=congrArg (fun w:ℚ=>|w|) (show (score f g (x' c bits) (y' c bits)-(f+g:ℕ))*B =
      (T:ℚ)-((f+g)*B:ℕ) by rw [sub_mul];push_cast;rw [show score f g (x' c bits) (y' c bits)*B=(T:ℚ) from clear ..])
  rw [abs_mul,abs_of_nonneg (Nat.cast_nonneg B : (0:ℚ)≤B)] at ab
  exact ab.trans_ge raw

private theorem difference (c : Family r) (b : Fin r→Option Bool) (f g N : ℕ) (n0 : 0<N)
    (space : ∀ i t, b i=some t → N ≤ (if t then (c.p i)^(c.e i) else c.p i)) :
    |score f g (x' c b) (y' c b)-score f g (exactX c) (exactY c)|≤(2*r*2^r:ℕ)*((f:ℚ)+g)/N := by
  have bp i := ranges (c.prime i) (c.positive i) (b i)
  have ex i := ranges (c.prime i) (c.positive i) none
  have er (i) : |exactX c i-x' c b i|≤2/(N:ℚ) ∧ |exactY c i-y' c b i|≤2/(N:ℚ) := by
    cases h:b i with
    | none=>simp [exactX,x',exactY,y',h,xx',yy'];positivity
    | some t=>simpa [exactX,x',exactY,y',h,xx',yy'] using error (c.prime i) (c.positive i) n0 t (space i t h)
  have eps : (0:ℚ)≤2/N := by positivity
  have one i : 2/((c.e i:ℚ)+1)≤2 := div_le_self (by decide) (by have:=Nat.cast_nonneg (α:=ℚ) (c.e i);linarith)
  have x:=OMA.CofactorEffectiveAtom245212.product_error (univ:Finset (Fin r)) (exactX c) (x' c b) eps
    (fun i _=>⟨zero_le_one.trans (ex i).1,(ex i).2.1,zero_le_one.trans (bp i).1,(bp i).2.1,(er i).1⟩)
  have y:=OMA.CofactorEffectiveAtom245212.product_error (univ:Finset (Fin r)) (exactY c) (y' c b) eps
    (fun i _=>⟨(ex i).2.2.1,(ex i).2.2.2.trans (one i),(bp i).2.2.1,(bp i).2.2.2.trans (one i),(er i).2⟩)
  have cards : (univ:Finset (Fin r)).card=r:=Finset.card_fin _
  rw [cards] at x y
  change |(∏i,exactX c i)-(∏i,x' c b i)| ≤ (r:ℚ)*2^r*(2/N) at x
  change |(∏i,exactY c i)-(∏i,y' c b i)| ≤ (r:ℚ)*2^r*(2/N) at y
  dsimp [score]
  rw [abs_sub_comm]
  calc
    _ = |(f:ℚ)*((∏i,exactX c i)-∏i,x' c b i)+(g:ℚ)*((∏i,exactY c i)-∏i,y' c b i)| := by congr 1;ring
    _ ≤ _ := (abs_add_le ..).trans (by
      rw [abs_mul,abs_of_nonneg (Nat.cast_nonneg f : (0:ℚ)≤f),abs_mul,
        abs_of_nonneg (Nat.cast_nonneg g : (0:ℚ)≤g)]
      push_cast
      simp only [div_eq_mul_inv] at x y ⊢
      nlinarith only [mul_le_mul_of_nonneg_left x (Nat.cast_nonneg f : (0:ℚ)≤f),
        mul_le_mul_of_nonneg_left y (Nat.cast_nonneg g : (0:ℚ)≤g)])

theorem contradiction (c : Family r) (f g x : ℕ) (big : 128≤x) (cf : f+g≤x) (cl : c.L≤x) (errorCap : 2*r*2^r≤x)
    (separated : ∀ b, (f+g)*dust c b ≠ f*NX c b+g*NY c b)
    (close : |score f g (exactX c) (exactY c)-(f+g:ℕ)| ≤ 1/((x^(degree r):ℕ):ℚ)) : False := by
  let point : Fin r ⊕ Fin r → ℕ := Sum.elim c.p (fun i=>c.p i^c.e i)
  obtain ⟨j,band⟩:=empty_band x (by omega) point
  have bp (i:Fin r) := band (Sum.inl i)
  have bd (i:Fin r) := band (Sum.inr i)
  let Q:=cut r x j.val
  let N:=cut r x (j.val+1)
  let b (i:Fin r) : Option Bool := if c.p i^c.e i≤Q then none else some (decide (c.p i≤Q))
  have next : N=Q^(3*r+4) := cut_succ ..
  have xQ : x≤Q := by
    have old:=cut_mono r (show 1≤x by omega) (Nat.zero_le j.val)
    simpa [cut,Q] using old
  have np : 0<N := by rw [next];exact pow_pos (by omega) _
  have nb : N≤x^(degree r):=cut_mono r (by omega) (show j.val+1≤2*r+1 by omega)
  have space (i) (t:Bool) (mode:b i=some t) : N ≤ (if t then c.p i^c.e i else c.p i) := by
    dsimp [b] at mode
    split at mode
    next=>contradiction
    next off=>
      obtain rfl:=Option.some.inj mode
      by_cases lo : c.p i≤Q
      · simp [lo]
        exact ((bd i).resolve_left off).le
      · simp [lo]
        exact ((bp i).resolve_left lo).le
  have ds : dust c b≤Q^(3*r) := by
    have per i : Dn (c.p i) (c.e i) (b i)≤Q^3 := by
      have el := (c.cap i).trans (cl.trans xQ)
      by_cases exactMode : c.p i^c.e i≤Q
      · rw [show b i=none from if_pos exactMode]
        change (c.e i+1)*(c.p i^c.e i)≤Q^3
        exact
          (Nat.mul_le_mul el exactMode).trans (show Q*Q≤Q^3 by rw [←sq];exact Nat.pow_le_pow_right (by omega) (by decide))
      · by_cases keep:c.p i≤Q
        · simpa [b,exactMode,keep,Dn,den] using
            (Nat.mul_le_mul el (Nat.pow_le_pow_left (show c.p i-1≤Q by omega) 2)).trans_eq (by ring : Q*Q^2=Q^3)
        · simpa [b,exactMode,keep,Dn,den] using el.trans (Nat.le_self_pow (by decide : 3≠0) Q)
    dsimp [dust]
    exact (prod_le_prod' (fun i _=>per i)).trans_eq (by simp [←pow_mul])
  have nz:=separated b
  have iga:=integer_gap c b f g nz
  let orig:=score f g (exactX c) (exactY c)
  let approx:=score f g (x' c b) (y' c b)
  let W:ℚ:=(f+g:ℕ)
  have lite : |orig-W|≤1/(N:ℚ) := close.trans (one_div_le_one_div_of_le (by positivity) (by exact_mod_cast nb))
  have diff:=difference c b f g N np space
  change |approx-orig|≤_ at diff
  change (1:ℚ)≤|approx-W| * dust c b at iga
  have err : |approx-W| * (N:ℚ)≤(2*r*2^r:ℕ)*((f:ℚ)+g)+1 := by
    have t:=abs_sub_le approx orig W
    have wn : (0:ℚ)<N:=by exact_mod_cast np
    nlinarith only [mul_le_mul_of_nonneg_right t wn.le,(le_div_iff₀ wn).mp diff,(le_div_iff₀ wn).mp lite]
  have sep : N≤((2*r*2^r)*(f+g)+1)*dust c b := by
    have z : (N:ℚ)≤((2*r*2^r:ℕ)*((f:ℚ)+g)+1)*dust c b := by
      nlinarith only [mul_le_mul_of_nonneg_right iga (Nat.cast_nonneg N : (0:ℚ)≤N),
        mul_le_mul_of_nonneg_right err (Nat.cast_nonneg (dust c b) : (0:ℚ)≤_)]
    exact_mod_cast z
  have qr : 128≤Q:=big.trans xQ
  have cfq : f+g≤Q:=cf.trans xQ
  have rate : 2*r*2^r≤Q := errorCap.trans xQ
  have cf' : (2*r*2^r)*(f+g)+1<Q^3 := by
    have m:=Nat.mul_le_mul rate cfq
    have grow:=Nat.mul_le_mul_left (Q*Q) (show 2≤Q by omega)
    nlinarith only [m,grow,qr,Nat.mul_self_le_mul_self (show 2≤Q by omega)]
  have bad : N < Q^(3+3*r) := sep.trans_lt ((Nat.mul_lt_mul_of_lt_of_le cf' ds
    (pow_pos (by omega) _)).trans_eq (by rw [pow_add]))
  have natural : Q^(3+3*r)≤N:=next ▸ Nat.pow_le_pow_right (by omega) (by omega)
  omega

end OMA.FixedRankStep245212
