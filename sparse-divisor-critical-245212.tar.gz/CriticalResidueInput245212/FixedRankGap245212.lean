import TwoTallLocal245212

/-! Cleared moments and the restriction on every retained prime. -/
namespace OMA.FixedRankGap245212
open Nat Finset OMA.Smooth245212 OMA.TwoTallLocal245212

structure Family (r : ℕ) where
  p : Fin r→ℕ
  e : Fin r→ℕ
  k : ℕ
  L : ℕ
  prime : ∀i,(p i).Prime
  positive : ∀i,0<e i
  kp : 8≤k
  longest : ∃i,e i+1=L
  cap : ∀i,e i+1≤L
  inj : p.Injective

variable {r : ℕ}

def exactX (c : Family r) (i : Fin r) := X (c.p i) (some (c.e i))
def exactY (c : Family r) (i : Fin r) := Y (c.p i) (some (c.e i))
def x' (c : Family r) (b : Fin r→Option Bool) (i : Fin r) := xx' (c.p i) (c.e i) (b i)
def y' (c : Family r) (b : Fin r→Option Bool) (i : Fin r) := yy' (c.p i) (c.e i) (b i)
def dust (c : Family r) (b : Fin r→Option Bool) := ∏i,Dn (c.p i) (c.e i) (b i)
def NX (c : Family r) (b : Fin r→Option Bool) := ∏i,Nx (c.p i) (c.e i) (b i)
def NY (c : Family r) (b : Fin r→Option Bool) := ∏i,Ny (c.p i) (c.e i) (b i)
def score (f g : ℕ) (x y : Fin r→ℚ) := (f:ℚ)*(∏i,x i)+(g:ℚ)*(∏i,y i)

theorem dust_pos (c : Family r) (b : Fin r→Option Bool) : 0<dust c b :=
  prod_pos (fun i _=>Dpos (c.prime i) _ _)

theorem clear (c : Family r) (b : Fin r→Option Bool) (f g : ℕ) :
    score f g (x' c b) (y' c b)*dust c b=(f*NX c b+g*NY c b:ℕ) := by
  have w : (∏i,x' c b i)*(dust c b:ℚ)=NX c b := by
    dsimp [dust,NX,x'];push_cast;rw [←prod_mul_distrib]
    exact prod_congr rfl (fun i _=>(moments (c.prime i) (c.e i) (b i)).1)
  have s : (∏i,y' c b i)*(dust c b:ℚ)=NY c b := by
    dsimp [dust,NY,y'];push_cast;rw [←prod_mul_distrib]
    exact prod_congr rfl (fun i _=>(moments (c.prime i) (c.e i) (b i)).2)
  dsimp [score];push_cast
  linear_combination (f:ℚ)*w+(g:ℚ)*s


private theorem largest {c : Family r} {b : Fin r→Option Bool} {f g l : ℕ} (frac : f+g=(c.k+1)*l)
    (unit : ∀i,¬c.p i∣l) (hit : (f+g)*dust c b=f*NX c b+g*NY c b) :
    ∀i,b i=some true → c.p i≤ max (c.k+1) c.L := by
  classical
  let s:=univ.filter (fun j=>b j=some true)
  intro i hi
  have im : i∈s:=mem_filter.mpr ⟨mem_univ _,hi⟩
  obtain ⟨j,jm,top⟩:=s.exists_max_image c.p ⟨i,im⟩
  have sh: b j=some true := (mem_filter.mp jm).2
  let q:=c.p j
  have pr:=c.prime j
  have dn : q∣NX c b := by
    apply dvd_trans (b:=Nx (c.p j) (c.e j) (b j)) _ (dvd_prod_of_mem (fun i=>Nx (c.p i) (c.e i) (b i)) (mem_univ j))
    simp [Nx,OMA.ThreeMovingLocal245212.xn,sh,q]
  have ds : q∣NY c b := by
    apply dvd_trans (b:=Ny (c.p j) (c.e j) (b j)) _ (dvd_prod_of_mem (fun i=>Ny (c.p i) (c.e i) (b i)) (mem_univ j))
    simp [Ny,OMA.ThreeMovingLocal245212.yn,sh,q]
  have total : q∣(f+g)*dust c b := hit ▸ dvd_add (dvd_mul_of_dvd_right dn f) (dvd_mul_of_dvd_right ds g)
  apply (top _ im).trans
  by_contra! no
  change max (c.k+1) c.L < q at no
  rw [frac] at total
  rcases pr.dvd_mul.mp total with h|h
  · rcases pr.dvd_mul.mp h with small|bad
    · exact (Nat.not_dvd_of_pos_of_lt (by omega) (by omega)) small
    · exact unit j bad
  · obtain ⟨i',_,v⟩:=(pr.prime.dvd_finsetProd_iff _).mp h
    have le0:=c.cap i'
    have absent := Nat.not_dvd_of_pos_of_lt (by omega : 0<c.e i'+1) (by omega : c.e i'+1<q)
    change q∣Dn (c.p i') (c.e i') (b i') at v
    cases which : b i' with
    | none =>
      rw [which] at v
      rcases pr.dvd_mul.mp v with hit|hit
      · exact absent hit
      have same:=c.inj ((prime_dvd_prime_iff_eq pr (c.prime i')).mp (pr.dvd_of_dvd_pow hit))
      exact (by rw [←same,sh] at which; contradiction)
    | some bit =>
      cases bit with
      | false => rw [which] at v;exact absent v
      | true =>
        have mt : i'∈s:=mem_filter.mpr ⟨mem_univ _,which⟩
        have sz:=top i' mt
        rw [which] at v
        rcases pr.dvd_mul.mp v with bad|bad
        · exact absent bad
        · exact Nat.not_dvd_of_pos_of_lt (by have:=(c.prime i').two_le;omega : 0<c.p i'-1)
            (by omega) (pr.dvd_of_dvd_pow bad)


theorem retained {c : Family r} {b : Fin r→Option Bool} {f g l : ℕ} (frac : f+g=(c.k+1)*l)
    (unit : ∀i,¬c.p i∣l) (hit : (f+g)*dust c b=f*NX c b+g*NY c b) :
    ∀i,b i=some true → c.p i≤ max (c.k+1) c.L := largest frac unit hit

end OMA.FixedRankGap245212
