import FixedRankGap245212
import MiddleChange245212
/-! Mixed score changes at an arbitrary rank, in any order of restoration. -/
namespace OMA.FixedModeRestore245212
open Nat Finset OMA.FixedRankGap245212 OMA.MiddleChange245212 OMA.TwoTallLocal245212
variable {r : ℕ} (c : Family r) (b : Fin r→Option Bool) (f g : ℕ)

def tag (s : Finset (Fin r)) (j : Fin r) := if j∈s then none else b j
def xx (s : Finset (Fin r)) (j : Fin r) := xx' (c.p j) (c.e j) (tag b s j)
def yy (s : Finset (Fin r)) (j : Fin r) := yy' (c.p j) (c.e j) (tag b s j)
def val (s : Finset (Fin r)) := score f g (xx c b s) (yy c b s)
def ox (s : Finset (Fin r)) (i : Fin r) := ∏j∈univ.erase i,xx c b s j
def oy (s : Finset (Fin r)) (i : Fin r) := ∏j∈univ.erase i,yy c b s j

theorem caps (s : Finset (Fin r)) (i : Fin r) : 1≤ox c b s i ∧ 0≤oy c b s i ∧ oy c b s i≤1 := by
  have range j:=ranges (c.prime j) (c.positive j) (tag b s j)
  have one j : yy c b s j≤1:=(range j).2.2.2.trans ((div_le_iff₀ (by positivity)).mpr (by
    have ep : (1:ℚ)≤c.e j:=by exact_mod_cast c.positive j
    linarith))
  exact ⟨one_le_prod (fun j _=>(range j).1),prod_nonneg (fun j _=>(range j).2.2.1),
    prod_le_one (fun j _=>(range j).2.2.1) (fun j _=>one j)⟩

theorem other_length (s : Finset (Fin r)) {i z : Fin r} (ne : z≠i) :
    oy c b s i*((c.e z:ℚ)+1)≤2 := by
  have range j:=ranges (c.prime j) (c.positive j) (tag b s j)
  have one j : yy c b s j≤1:=(range j).2.2.2.trans ((div_le_iff₀ (by positivity)).mpr (by
    have ep : (1:ℚ)≤c.e j:=by exact_mod_cast c.positive j
    linarith))
  let t:=(univ:Finset (Fin r)).erase i
  have zm : z∈t:=mem_erase.mpr ⟨ne,mem_univ _⟩
  have rest : ∏j∈t.erase z,yy c b s j≤1:=prod_le_one (fun j _=>(range j).2.2.1) (fun j _=>one j)
  have h : oy c b s i ≤ yy c b s z := by
    change ∏j∈t, yy c b s j≤ _
    rw [←prod_erase_mul t (yy c b s) zm]
    have h0 : 0≤yy c b s z:=(range z).2.2.1
    simpa only [one_mul] using mul_le_mul_of_nonneg_right rest h0
  exact (mul_le_mul_of_nonneg_right h (by positivity)).trans ((le_div_iff₀ (by positivity)).mp (range z).2.2.2)

theorem change (s : Finset (Fin r)) {i} (fresh : i∉s) :
    val c b f g (insert i s)-val c b f g s =
      inc (c.p i) (c.e i) f g (b i) (ox c b s i) (oy c b s i) := by
  have same (j : Fin r) (ji : j≠i) : tag b (insert i s) j=tag b s j:=by simp [tag,ji]
  have eqX : ox c b (insert i s) i=ox c b s i:=by
    apply prod_congr rfl;intro j hj;dsimp only [xx];rw [same j (ne_of_mem_erase hj)]
  have eqY : oy c b (insert i s) i=oy c b s i:=by
    apply prod_congr rfl;intro j hj;dsimp only [yy];rw [same j (ne_of_mem_erase hj)]
  have expand (t) : val c b f g t=(f:ℚ)*(ox c b t i*xx c b t i)+g*(oy c b t i*yy c b t i) := by
    dsimp only [val,score,ox,oy];rw [prod_erase_mul _ _ (mem_univ i),prod_erase_mul _ _ (mem_univ i)]
  rw [expand,expand,eqX,eqY]
  dsimp only [xx,yy,tag,inc];simp only [mem_insert_self,if_true,if_neg fresh]
  simp only [xx',yy']
  ring

theorem same (hit : (f+g)*dust c b=f*NX c b+g*NY c b)
    (actual : score f g (exactX c) (exactY c)=(f+g:ℕ)) :
    val c b f g (∅:Finset (Fin r))=val c b f g univ := by
  have clr:=clear c b f g
  rw [←hit] at clr
  push_cast at clr
  have dp : (0:ℚ)<dust c b:=by exact_mod_cast dust_pos c b
  have z:=mul_right_cancel₀ dp.ne' clr
  have eq : score f g (x' c b) (y' c b)=score f g (exactX c) (exactY c):=z.trans (by simpa only [Nat.cast_add] using actual.symm)
  have a : xx c b ∅=x' c b:=by funext j;simp [xx,tag,x']
  have d : yy c b ∅=y' c b:=by funext j;simp [yy,tag,y']
  have u : xx c b univ=exactX c:=by funext j;simp [xx,tag,xx',exactX]
  have w : yy c b univ=exactY c:=by funext j;simp [yy,tag,yy',exactY]
  simpa only [val,a,d,u,w] using eq

end OMA.FixedModeRestore245212
