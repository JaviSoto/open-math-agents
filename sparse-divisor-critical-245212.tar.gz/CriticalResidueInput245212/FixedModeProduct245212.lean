import FixedModeOriginal245212
import PrimePowerDiv245212

/-! Natural-number coefficient factors for the uniquely retained prime:
the selected exact prefix, dropped divisor-count product, and the score. -/
namespace OMA.FixedModeProduct245212
open Nat Finset ArithmeticFunction OMA.Smooth245212 OMA.FixedRankGap245212
open OMA.TwoTallLocal245212 OMA.ThreeMovingLocal245212
open OMA.ThreeMovingOriginal245212 (F G)
open scoped ArithmeticFunction.sigma Function
open private OMA.ComplementaryLocal245212.binary from ComplementaryLocal245212
open private OMA.FixedRankHeight245212.identities from FixedRankHeight245212
variable {r : ℕ}

def exactSet (b : Fin r→Option Bool) := univ.filter (fun i=>b i=none)
def dropped (b : Fin r→Option Bool) := univ.filter (fun i=>b i=some false)
def pref (c : Family r) (b : Fin r→Option Bool) := 2^c.k*∏i∈exactSet b,c.p i^c.e i
def mult (c : Family r) (b : Fin r→Option Bool) := ∏i∈dropped b,(c.e i+1)

theorem partition {b : Fin r→Option Bool} {v : Fin r} (keep : b v=some true) (only : ∀i,i≠v → b i≠some true) :
    Disjoint (exactSet b) (dropped b) ∧ exactSet b∪dropped b=univ.erase v := by
  constructor
  · refine disjoint_left.mpr ?_;intro i h1 h2
    have a:=(mem_filter.mp h1).2;have z:=(mem_filter.mp h2).2
    simp_all
  · ext i
    by_cases iv : i=v
    · subst i;simp [exactSet,dropped,keep]
    · have n:=only i iv
      cases h : b i with
      | none=>simp [exactSet,dropped,h,iv]
      | some t=>cases t <;> simp_all [exactSet,dropped]

theorem prefix_moments (c : Family r) (odd : ∀i,Odd (c.p i)) (b : Fin r→Option Bool) :
    W (pref c b)=F c.k*(∏i∈exactSet b,W (c.p i^c.e i)) ∧
    σ 1 (pref c b)=G c.k*(∏i∈exactSet b,σ 1 (c.p i^c.e i)) ∧
    2*(pref c b)*(σ 0 (pref c b))=(F c.k+G c.k)*(∏i∈exactSet b,((c.e i+1)*c.p i^c.e i)) := by
  let s:=exactSet b
  let a i:=c.p i^c.e i
  have cop : (2^c.k).Coprime (∏i∈s,a i):=Nat.coprime_prod_right_iff.mpr (fun i _=>
    ((Nat.coprime_two_left.mpr (odd i)).pow_left _).pow_right _)
  have pw : (s:Set (Fin r)).Pairwise (Nat.Coprime on a):=fun i _ j _ ij=>
    (((Nat.coprime_primes (c.prime i) (c.prime j)).mpr (c.inj.ne ij)).pow_left _).pow_right _
  have Wp:=IsMultiplicative.map_prod a w_mult s pw
  have Sp:=IsMultiplicative.map_prod a (isMultiplicative_sigma (k:=1)) s pw
  have Tp:=IsMultiplicative.map_prod a (isMultiplicative_sigma (k:=0)) s pw
  have gf : σ 1 (2^c.k)=G c.k := by
    dsimp [G];zify [Nat.cast_sub (show 1≤2^(c.k+1) from Nat.two_pow_pos _)]
    exact (OMA.ComplementaryLocal245212.binary c.k).1
  have ff : W (2^c.k)=F c.k := by exact_mod_cast (OMA.ComplementaryLocal245212.binary c.k).2
  change W (2^c.k*∏i∈s,a i)=_ ∧ σ 1 (2^c.k*∏i∈s,a i)=_ ∧ 2*(2^c.k*∏i∈s,a i)*σ 0 (2^c.k*∏i∈s,a i)=_
  rw [w_mult.map_mul_of_coprime cop,isMultiplicative_sigma.map_mul_of_coprime cop,
    isMultiplicative_sigma.map_mul_of_coprime cop,ff,gf,Wp,Sp,Tp]
  refine ⟨rfl,rfl,?_⟩
  simp only [a,sigma_zero_apply_prime_pow (c.prime _),sigma_zero_apply_prime_pow Nat.prime_two,
    (OMA.FixedRankHeight245212.identities c.k).2.1,pow_succ 2,prod_mul_distrib,s]
  ring

theorem others (c : Family r) {b : Fin r→Option Bool} {v : Fin r} (keep : b v=some true)
    (only : ∀i,i≠v → b i≠some true) :
    (∏i∈univ.erase v,Dn (c.p i) (c.e i) (b i))=(∏i∈exactSet b,((c.e i+1)*c.p i^c.e i))*mult c b ∧
    (∏i∈univ.erase v,Nx (c.p i) (c.e i) (b i))=(∏i∈exactSet b,W (c.p i^c.e i))*mult c b ∧
    (∏i∈univ.erase v,Ny (c.p i) (c.e i) (b i))=∏i∈exactSet b,σ 1 (c.p i^c.e i) := by
  have ⟨dis,part⟩:=partition keep only
  have ed i (hi : i∈exactSet b) := (mem_filter.mp hi).2
  have dd i (hi : i∈dropped b) := (mem_filter.mp hi).2
  rw [←part]
  simp only [prod_union dis]
  have denE : (∏i∈exactSet b,Dn (c.p i) (c.e i) (b i))=_ :=
    prod_congr rfl (fun i hi=>show Dn (c.p i) (c.e i) (b i)=(c.e i+1)*c.p i^c.e i by rw [ed i hi];rfl)
  have denD : (∏i∈dropped b,Dn (c.p i) (c.e i) (b i))=mult c b:=
    prod_congr rfl (fun i hi=>by rw [dd i hi];rfl)
  have wxE : (∏i∈exactSet b,Nx (c.p i) (c.e i) (b i))=_ :=
    prod_congr rfl (fun i hi=>show Nx (c.p i) (c.e i) (b i)=W (c.p i^c.e i) by rw [ed i hi];rfl)
  have wxD : (∏i∈dropped b,Nx (c.p i) (c.e i) (b i))=mult c b:=
    prod_congr rfl (fun i hi=>by rw [dd i hi];rfl)
  have syE : (∏i∈exactSet b,Ny (c.p i) (c.e i) (b i))=_ :=
    prod_congr rfl (fun i hi=>show Ny (c.p i) (c.e i) (b i)=σ 1 (c.p i^c.e i) by rw [ed i hi];rfl)
  have syD : (∏i∈dropped b,Ny (c.p i) (c.e i) (b i))=1:=
    Finset.prod_eq_one (fun i hi=>by rw [dd i hi];rfl)
  rw [denE,denD,wxE,wxD,syE,syD,mul_one]
  exact ⟨rfl,rfl,rfl⟩

theorem equation (c : Family r) (odd : ∀i,Odd (c.p i)) {b : Fin r→Option Bool} {v : Fin r}
    (keep : b v=some true) (only : ∀i,i≠v → b i≠some true)
    (hit : (F c.k+G c.k)*dust c b=F c.k*NX c b+G c.k*NY c b) :
    let H:=2*(pref c b)*σ 0 (pref c b)
    let B:=c.e v+1; let C:=mult c b; let q:=c.p v; let u:=q-1
    H*B*C*u^2=q*(W (pref c b)*C*(B*u-1)+σ 1 (pref c b)*u) := by
  obtain ⟨av,sv,hv⟩:=prefix_moments c odd b
  obtain ⟨d,x,y⟩:=others c keep only
  dsimp only
  rw [av,sv,hv]
  unfold dust NX NY at hit
  rw [←prod_erase_mul _ _ (mem_univ v),←prod_erase_mul _ (fun i=>Nx _ _ _) (mem_univ v),
    ←prod_erase_mul _ (fun i=>Ny _ _ _) (mem_univ v)] at hit
  rw [d,x,y,keep] at hit
  simp only [Dn,Nx,Ny,den,xn,yn,if_true] at hit
  linear_combination hit

end OMA.FixedModeProduct245212
