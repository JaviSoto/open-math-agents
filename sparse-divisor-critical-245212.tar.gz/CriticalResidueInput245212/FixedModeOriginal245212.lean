import FixedModeWitness245212
import FixedModeForce245212
import FixedTallScalar245212

/-! Every solution with large dyadic exponent and large maximum length has
an exact mixed equality with precisely one retained base, at the longest slot. -/
namespace OMA.FixedModeOriginal245212
open Nat Finset OMA.FixedRankGap245212 OMA.FixedModeRestore245212
open OMA.FixedTallScalar245212 (threshold h)
open OMA.FixedRankStep245212 (degree)
open OMA.ThreeMovingOriginal245212 (F G)
open scoped ArithmeticFunction.sigma
open OMA.Smooth245212 (total)
open private OMA.FixedRankHeight245212.identities from FixedRankHeight245212

def exponent (r : ℕ):=h r*degree r

theorem original {r : ℕ} (c : Family r) (odd : ∀i,Odd (c.p i))
    (klarge : 256≤c.k) (large : threshold r 1≤c.L)
    (v : Fin r) (long : c.e v+1=c.L)
    (eqn : OeisA245212.a (2^c.k*total c.p c.e)=(σ 1 (2^c.k*total c.p c.e):ℤ)) :
    ∃ (b : Fin r→Option Bool) (Q : ℕ), c.L≤Q ∧ Q≤c.L^exponent r ∧
    (∀i,b i=if c.p i^c.e i≤Q then none else some (decide (c.p i≤Q))) ∧
    (F c.k+G c.k)*dust c b=F c.k*NX c b+G c.k*NY c b ∧
    b v=some true ∧ (∀i,i≠v → b i≠some true) ∧
    (F c.k:ℚ)*ox c b ∅ v≤(G c.k:ℚ)*((c.p v:ℚ)-1)*oy c b ∅ v := by
  have dyad:=OMA.FixedRankHeight245212.original c.k c.L c.p c.e c.prime odd c.inj c.positive c.longest c.cap eqn
  have actual:=OMA.FixedRankHeight245212.physical c c.k odd c.inj eqn
  obtain ⟨big,coef,lc,rate,pow⟩:=OMA.FixedTallScalar245212.scale large (by simp only [one_mul,le_refl] : c.L≤1*c.L) dyad
  let x:=c.L^h r
  have post : x^(degree r)<c.p v^c.e v:=pow _ _ (c.prime v).two_le long.ge
  obtain ⟨b,Q,xQ,Qcap,rule,hit⟩:=OMA.FixedModeWitness245212.witness c (F c.k) (G c.k) x big coef lc rate actual
  have id:=OMA.FixedRankHeight245212.identities c.k
  have Fcap : c.k*G c.k≤F c.k:=by omega
  have unit (i) : ¬c.p i∣2^(c.k+1):=by
    intro dv
    have two:=(c.prime i).dvd_of_dvd_pow dv
    have g:=(c.prime i).odd_iff.mp (odd i)
    exact Nat.not_dvd_of_pos_of_lt (by decide) g two
  have kL : c.k+1≤c.L := by
    have dpos : 0<degree r:=pow_pos (by omega) _
    have xp : x≤x^(degree r):=Nat.le_self_pow dpos.ne' _
    have two : x^(degree r)<2^(c.e v):=pow 2 _ (by decide) long.ge
    have mul : 2^(c.k+1)≤F c.k+G c.k:=by rw [id.2.1];exact Nat.le_mul_of_pos_left _ (Nat.succ_pos _)
    have less:=((mul.trans coef).trans xp).trans_lt two
    have exp : c.k+1<c.e v := (Nat.pow_lt_pow_iff_right (by decide : 1<2)).mp less
    omega
  have base i (keep : b i=some true) : c.p i≤c.L:=by simpa [max_eq_right kL] using retained id.2.1 unit hit i keep
  have mv : b v≠none:=by rw [rule];simp [(Qcap.trans_lt post).not_ge]
  obtain ⟨keep,unique,negative⟩:=OMA.FixedModeForce245212.force c b id.1 Fcap klarge v long mv base hit actual
  exact ⟨b,Q,lc.trans xQ,by simpa only [x,exponent,pow_mul] using Qcap,rule,hit,keep,unique,negative⟩

end OMA.FixedModeOriginal245212
