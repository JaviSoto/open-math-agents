import OddDivisorFloor245212
import FixedRankAbsolute245212

/-! Finite exceptions without imposing any bound on input rank: the divisor
count of the odd part cannot grow more slowly than sqrt(6) to that rank. -/
namespace OMA.SparseDivisorHeight245212
open Nat Finset ArithmeticFunction OMA.OddDivisorFloor245212 OMA.FixedRankInteger245212
open scoped ArithmeticFunction.sigma

theorem odd_count {n : ℕ} (pos : 0<n) : σ 0 (ordCompl[2] n)=lengthProd n := by
  let m:=ordCompl[2] n
  have odd : Odd m:=Nat.coprime_two_left.mp (Nat.coprime_ordCompl prime_two pos.ne')
  have ss : m.primeFactors=support n := by
    dsimp [m,support];rw [←Nat.support_factorization,Nat.factorization_ordCompl,Finsupp.support_erase,Nat.support_factorization]
  change σ 0 m=_
  rw [sigma_eq_prod_primeFactors_sum_range_factorization_pow_mul odd.pos.ne']
  simp only [Nat.mul_zero,pow_zero,sum_const,card_range,smul_eq_mul,mul_one]
  rw [ss]
  apply prod_congr rfl
  intro p mem
  dsimp [m]
  rw [Nat.factorization_ordCompl,Finsupp.erase_ne (mem_erase.mp mem).1]

private theorem bern (A r : ℕ) : A^r*(A+r)≤A*(A+1)^r := by
  induction r with
  | zero=>simp
  | succ r ih=>
    have step:=Nat.mul_le_mul_right (A+1) ih
    simp only [pow_succ]
    nlinarith only [step,Nat.zero_le (A^r*r)]

/-- For a rational growth base a/b strictly below sqrt(6), bound the
number of odd factors on a solution whose odd divisor count is at most
C(a/b)^r. No rank cap is assumed. -/
theorem rank {n a b C : ℕ} (pos : 0<n) (hit : OeisA245212.a n=(σ 1 n:ℤ))
    (ap : 0<a) (subcritical : a^2<6*b^2)
    (small : (σ 0 (ordCompl[2] n))*b^(support n).card≤C*a^(support n).card) :
    (support n).card≤a^2*C^2 := by
  let r:=(support n).card
  rw [odd_count pos] at small
  have lo:=(OMA.OddDivisorFloor245212.floor pos hit).1
  change 6^r≤(lengthProd n)^2 at lo
  change lengthProd n*b^r≤C*a^r at small
  have high : (6*b^2)^r≤C^2*(a^2)^r:=calc
    _ = 6^r*(b^r)^2 := by rw [mul_pow,←pow_mul,←pow_mul,Nat.mul_comm 2 r]
    _ ≤ (lengthProd n*b^r)^2 := by rw [mul_pow];exact Nat.mul_le_mul_right _ lo
    _ ≤ (C*a^r)^2 := Nat.pow_le_pow_left small 2
    _ = _ := by rw [mul_pow,←pow_mul,←pow_mul,Nat.mul_comm r 2]
  have bl:=bern (a^2) r
  have mid:=Nat.pow_le_pow_left (Nat.succ_le_of_lt subcritical) r
  have cancel : (a^2)^r*(a^2+r)≤(a^2)^r*(a^2*C^2):=by
    exact bl.trans ((Nat.mul_le_mul_left _ (mid.trans high)).trans_eq (by ring))
  have bound:=Nat.le_of_mul_le_mul_left cancel (pow_pos (pow_pos ap 2) r)
  change r≤_
  omega

noncomputable def height (r : ℕ) := ∑i∈range (r+1),OMA.FixedRankAbsolute245212.bound i

theorem whole {n a b C : ℕ} (pos : 0<n) (oddprime : (support n).Nonempty)
    (hit : OeisA245212.a n=(σ 1 n:ℤ)) (ap : 0<a) (subcritical : a^2<6*b^2)
    (small : (σ 0 (ordCompl[2] n))*b^(support n).card≤C*a^(support n).card) :
    n≤height (a^2*C^2) :=
  (OMA.FixedRankAbsolute245212.absolute pos oddprime hit).trans
    (single_le_sum (f:=OMA.FixedRankAbsolute245212.bound) (fun _ _=>Nat.zero_le _)
      (mem_range.mpr (Nat.lt_succ_of_le (rank pos hit ap subcritical small))))

theorem few_repeated {n C : ℕ} (pos : 0<n) (oddprime : (support n).Nonempty)
    (hit : OeisA245212.a n=(σ 1 n:ℤ)) (small : repetitions n≤C) : n≤height (2*C) :=
  (OMA.FixedRankAbsolute245212.absolute pos oddprime hit).trans
    (single_le_sum (f:=OMA.FixedRankAbsolute245212.bound) (fun _ _=>Nat.zero_le _)
      (mem_range.mpr (Nat.lt_succ_of_le ((OMA.OddDivisorFloor245212.floor pos hit).2.trans
        (Nat.mul_le_mul_left _ small)))))

#print axioms whole
#print axioms few_repeated
end OMA.SparseDivisorHeight245212
