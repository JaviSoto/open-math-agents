import ExponentParity245212
import FixedRankInteger245212

/-! The exponent parity obstruction has a sharp geometric consequence:
the square of the odd divisor count is at least six to the odd rank. -/
namespace OMA.OddDivisorFloor245212
open Nat Finset ArithmeticFunction OMA.FixedRankInteger245212
open OMA.Smooth245212 (total)
open scoped ArithmeticFunction.sigma

def lengthProd (n : ℕ) := ∏p∈support n,(n.factorization p+1)
def repetitions (n : ℕ) := ∑p∈support n,(n.factorization p-1)

private theorem loc {e : ℕ} (ep : 0<e) :
    let v:=(e+2).factorization 2
    4*3^v≤2^v*(e+1)^2 ∧ v≤2*(e-1) := by
  dsimp only
  generalize hv : (e+2).factorization 2=v
  have pow : 2^v≤e+2:=Nat.le_of_dvd (by omega)
    ((Nat.prime_two.pow_dvd_iff_le_factorization (by omega : e+2≠0)).mpr hv.ge)
  have rep : v≤2*(e-1):=by
    by_cases large : 3≤e
    · have h:=Nat.lt_two_pow_self (n:=v);omega
    · interval_cases e
      · have h : (1+2:ℕ).factorization 2=0:=Nat.factorization_eq_zero_of_not_dvd (by decide)
        omega
      · by_contra! no
        have h:=Nat.pow_le_pow_right (by decide : 0<2) (show 3≤v by omega)
        omega
  refine ⟨?_,rep⟩
  cases v with
  | zero=>simp only [pow_zero,mul_one,one_mul];exact (by simpa using Nat.pow_le_pow_left (show 2≤e+1 by omega) 2)
  | succ u=>
    cases u with
    | zero=>
      have e2 : 2≤e:=by
        by_contra! small
        have : e=1:=by omega
        subst e
        have h : (1+2:ℕ).factorization 2=0:=Nat.factorization_eq_zero_of_not_dvd (by decide)
        omega
      have h:=Nat.pow_le_pow_left (show 3≤e+1 by omega) 2
      norm_num at h ⊢;omega
    | succ a=>
      have pos:=Nat.two_pow_pos a
      rw [pow_succ,pow_succ] at pow
      have h : 3*2^a≤e+1:=by omega
      have grow : 3^a≤(2^a)^3:=by
        rw [←pow_mul,Nat.mul_comm a 3,pow_mul]
        exact Nat.pow_le_pow_left (by decide : 3≤2^3) _
      have out:=Nat.mul_le_mul_left (2^(a+2)) (Nat.pow_le_pow_left h 2)
      calc
        4*3^(a+2)=36*3^a := by rw [pow_add];ring
        _ ≤ 36*(2^a)^3 := Nat.mul_le_mul_left _ grow
        _ = 2^(a+2)*(3*2^a)^2 := by rw [pow_add];ring
        _ ≤ _ := out

theorem scaled_floor {r v : ℕ} (budget : r≤v) : 2^v*6^r≤4^r*3^v := by
  obtain ⟨d,rfl⟩:=Nat.exists_eq_add_of_le budget
  rw [pow_add (3:ℕ)]
  calc
    _ = 4^r*3^r*2^d:=by rw [pow_add,show 6=2*3 by decide,mul_pow,show 4=2*2 by decide,mul_pow];ring
    _ ≤ _ := by simpa only [mul_assoc] using Nat.mul_le_mul_left (4^r*3^r)
                  (Nat.pow_le_pow_left (by decide : 2≤3) d)

theorem budget {n : ℕ} (pos : 0<n) (hit : OeisA245212.a n=(σ 1 n:ℤ)) :
    (support n).card≤∑p∈support n,(n.factorization p+2).factorization 2 := by
  let s:=support n
  let e (p : s):=n.factorization p.val
  have pr (p : s) := Nat.prime_of_mem_primeFactors (Finset.mem_erase.mp p.property).2
  have odd (p : s) := (pr p).odd_of_ne_two (Finset.mem_erase.mp p.property).1
  have fac : 2^(n.factorization 2)*total (fun p : s=>p.val) e=n := by
    dsimp only [total,e]
    rw [s.prod_coe_sort (fun p=>p^n.factorization p)]
    by_cases h : 2∈n.primeFactors
    · exact (mul_prod_erase _ _ h).trans (Nat.prod_primeFactors_pow_factorization pos.ne').symm
    · have z : n.factorization 2=0:=Finsupp.notMem_support_iff.mp h
      simpa [z,s,support,erase_eq_of_notMem h] using (Nat.prod_primeFactors_pow_factorization pos.ne').symm
  have parity:=OMA.ExponentParity245212.exponent_product _ e pr odd Subtype.val_injective (n.factorization 2)
    (by rwa [fac])
  let v (p : s):=(e p+2).factorization 2
  have low := (Nat.prime_two.pow_dvd_iff_le_factorization
    (Finset.prod_ne_zero_iff.mpr (fun i _=>by omega : ∀i∈(univ:Finset s),e i+2≠0))).mp parity
  rw [Nat.factorization_prod_apply (fun i _=>by omega)] at low
  change Fintype.card s≤∑p,v p at low
  have cards : Fintype.card s=s.card:=Fintype.card_coe _
  rw [cards] at low
  exact low.trans_eq (s.sum_coe_sort (fun p=>(n.factorization p+2).factorization 2))

theorem local_product (n : ℕ) :
    4^(support n).card*3^(∑p∈support n,(n.factorization p+2).factorization 2)
      ≤2^(∑p∈support n,(n.factorization p+2).factorization 2)*(lengthProd n)^2 := by
  have ep p (mem : p∈support n) : 0<n.factorization p :=
    Nat.pos_of_ne_zero (Finsupp.mem_support_iff.mp (mem_erase.mp mem).2)
  simpa only [prod_mul_distrib,prod_const,prod_pow_eq_pow_sum,prod_pow,lengthProd] using
    (prod_le_prod' (s:=support n) (fun p mem=>(loc (ep p mem)).1))

theorem floor {n : ℕ} (pos : 0<n) (hit : OeisA245212.a n=(σ 1 n:ℤ)) :
    6^(support n).card≤(lengthProd n)^2 ∧ (support n).card≤2*repetitions n := by
  have low:=budget pos hit
  refine ⟨Nat.le_of_mul_le_mul_left ((scaled_floor low).trans (local_product n)) (Nat.two_pow_pos _),low.trans ?_⟩
  dsimp only [repetitions];rw [Finset.mul_sum]
  exact sum_le_sum fun p mem=>(loc (Nat.pos_of_ne_zero
    (Finsupp.mem_support_iff.mp (mem_erase.mp mem).2))).2

#print axioms floor
end OMA.OddDivisorFloor245212
