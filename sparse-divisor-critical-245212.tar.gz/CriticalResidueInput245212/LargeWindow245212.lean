import Moving245212
import SmoothValue245212

/-! A two-sided window for the exponent at an arbitrarily large last
prime; each box uses only the three cofactor exponents. -/
namespace OMA.Large245212
open OMA.Smooth245212 OMA.Moving245212 Finset

abbrev B := Fin 3 → Band
def bases (q : ℕ) : Fin 3 → ℕ := ![3,5,q]
def singleton (p : ℕ) : Band := ⟨p,some p⟩
def lows (f : Band → Band → ℚ) (q : ℕ) (b : B) : ℚ :=
  ∏ i,f (singleton (bases q i)) (b i)
def lowerD (L G : ℚ) := max 2 ⌈G/(2-L)⌉₊
def upperD (scale U V : ℚ) := ⌊V*scale/(2-U*scale)⌋₊
def scale (R : ℕ) : ℚ := (R:ℚ)/((R:ℚ)-1)
def prefProd (f : ℕ → Option ℕ → ℚ) (q : ℕ) (e : Fin 3 → ℕ) :=
  ∏ i,f (bases q i) (some (e i))

private theorem y_both {r d : ℕ} (hr : 1<r) :
    1/((d:ℚ)+1)≤Y r (some d) ∧ Y r (some d)≤ scale r/((d:ℚ)+1) := by
  have rr : (1:ℚ)<r := by exact_mod_cast hr
  rw [y_avg hr]
  have low : (1:ℚ) ≤ ∑ i∈range (d+1),(r:ℚ)⁻¹^i := by
    simpa using single_le_sum (s:=range (d+1)) (f:=fun i => (r:ℚ)⁻¹^i)
      (fun i _ => by positivity) (mem_range.mpr (by omega : 0<d+1))
  have up : (∑ i∈range (d+1),(r:ℚ)⁻¹^i) ≤ (r:ℚ)/((r:ℚ)-1) := by
    have u := geom_sum_Ico_le_of_lt_one (m:=0) (n:=d+1) (by positivity : (0:ℚ)≤(r:ℚ)⁻¹)
      (inv_lt_one_of_one_lt₀ rr)
    rw [Nat.Ico_zero_eq_range,pow_zero] at u
    rwa [show (1:ℚ)-(r:ℚ)⁻¹=(r-1)/r by field_simp,div_div_eq_mul_div,one_mul] at u
  exact ⟨by gcongr, by dsimp [scale]; gcongr⟩

private theorem scale_anti {R r : ℕ} (hR : 1<R) (rr : R≤r) : scale r≤ scale R := by
  have a : (1:ℚ)<R := by exact_mod_cast hR
  have b : (R:ℚ)≤r := by exact_mod_cast rr
  apply (div_le_div_iff₀ (by linarith : 0<(r:ℚ)-1) (by linarith : 0<(R:ℚ)-1)).2
  linarith

private theorem finale {r d R : ℕ} (hR : 1<R) (hrr : R≤r) :
    1≤X r (some d) ∧ X r (some d)≤ scale R ∧
    1/((d:ℚ)+1)≤Y r (some d) ∧ Y r (some d)≤ scale R/((d:ℚ)+1) := by
  have hr := hR.trans_le hrr
  have rr : (1:ℚ)<r := by exact_mod_cast hr
  have y0 := y_nonneg hr (some d)
  have y1 := y_one hr (some d)
  have lim := y_both (d:=d) hr
  have scaleR := scale_anti hR hrr
  refine ⟨le_add_of_nonneg_right (div_nonneg (by linarith only [y1]) (by linarith)),?_,lim.1,
    lim.2.trans (div_le_div_of_nonneg_right scaleR (by positivity))⟩
  apply le_trans _ scaleR
  unfold X scale
  rw [show (r:ℚ)/(r-1)=1+1/(r-1) by field_simp [(by linarith : (r:ℚ)-1≠0)]; ring]
  exact add_le_add_right (div_le_div_of_nonneg_right (by linarith only [y0]) (by linarith)) _

structure Window (R q : ℕ) (b : B) (d : ℕ) : Prop where
  xl : lows xl q b<2
  coarse : 2≤(lows xu q b+lows yu q b/2)*scale R
  low : lowerD (lows OMA.Moving245212.xl q b) (lows yl q b)≤d+1
  high : 0<2-lows xu q b*scale R → d+1≤upperD (scale R) (lows xu q b) (lows yu q b)

theorem window {R q r d : ℕ} (hR : 1<R) (hrr : R≤r) (hq : 1<q) (hd : 0<d)
    (b : B) (e : Fin 3 → ℕ) (inb : ∀ i,(b i).Contains (e i))
    (eq : prefProd X q e*X r (some d)+prefProd Y q e*Y r (some d)=2) : Window R q b d := by
  have p1 (i : Fin 3) : 1<bases q i := by fin_cases i <;> simp [bases,hq]
  have f (i : Fin 3) := factor_bounds (p:=bases q i) (pb:=singleton (bases q i)) (e:=e i)
    (p1 i) (by simp [singleton,Band.Contains]) (inb i)
  have x0 : 0≤prefProd X q e := prod_nonneg (fun i _ => x_nonneg (p1 i) _)
  have y0 : 0<prefProd Y q e := prod_pos (fun i _ => lt_of_lt_of_le
    (by positivity : 0 < 1/((e i:ℚ)+1)) (y_both (p1 i)).1)
  have xlow : lows xl q b≤prefProd X q e := prod_le_prod (fun i _ => (f i).1) (fun i _ => (f i).2.1)
  have xup : prefProd X q e≤lows xu q b := prod_le_prod (fun i _ => (f i).1.trans (f i).2.1)
    (fun i _ => (f i).2.2.1)
  have ylow : lows yl q b≤prefProd Y q e := prod_le_prod (fun i _ => (f i).2.2.2.1)
    (fun i _ => (f i).2.2.2.2.1)
  have yup : prefProd Y q e≤lows yu q b := prod_le_prod (fun i _ => (f i).2.2.2.1.trans
    (f i).2.2.2.2.1) (fun i _ => (f i).2.2.2.2.2)
  obtain ⟨x1,xcap,y1,ycap⟩ := finale (d:=d) hR hrr
  have z : (0:ℚ)<(d:ℚ)+1 := by positivity
  have Rreal : (1:ℚ)<R := by exact_mod_cast hR
  have posR : 0<scale R := div_pos (by linarith) (by linarith)
  have low : prefProd X q e+prefProd Y q e/((d:ℚ)+1)≤2 := by
    rw [←eq,div_eq_mul_one_div]
    exact add_le_add (le_mul_of_one_le_right x0 x1) (mul_le_mul_of_nonneg_left y1 y0.le)
  have up : 2≤(lows xu q b+lows yu q b/((d:ℚ)+1))*scale R := by
    rw [←eq,add_mul,div_mul_eq_mul_div,mul_div_assoc]
    exact add_le_add (mul_le_mul xup xcap (x1.trans' zero_le_one) (x0.trans xup))
      (mul_le_mul yup ycap (y_nonneg (hR.trans_le hrr) _) (y0.le.trans yup))
  have L2 : lows xl q b<2 := by linarith only [xlow,low,div_pos y0 z]
  have two : (2:ℚ)≤(d:ℚ)+1 := by exact_mod_cast (by omega : 2≤d+1)
  have divbd := div_le_div_of_nonneg_left (y0.le.trans yup) (by norm_num : (0:ℚ)<2) two
  refine ⟨L2,up.trans (mul_le_mul_of_nonneg_right (add_le_add_right divbd _) posR.le),?_,?_⟩
  · apply max_le (by omega)
    rw [Nat.ceil_le,Nat.cast_add_one,div_le_iff₀ (by linarith)]
    have a := (div_le_iff₀ z).mp (show prefProd Y q e/((d:ℚ)+1)≤2-prefProd X q e by linarith)
    nlinarith only [a,ylow,mul_nonneg (sub_nonneg.mpr xlow) z.le]
  · intro h
    apply Nat.le_floor
    rw [Nat.cast_add_one,le_div_iff₀ h]
    have a : 2-lows xu q b*scale R≤lows yu q b*scale R/((d:ℚ)+1) := by
      rw [add_mul,div_mul_eq_mul_div] at up; linarith
    have := (le_div_iff₀ z).mp a
    linarith
end OMA.Large245212
