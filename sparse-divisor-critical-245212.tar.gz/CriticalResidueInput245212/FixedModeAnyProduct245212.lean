import FixedModeSign245212

/-! Prefix identities with any physical dyadic order k. The numerical
state used to label local odd moments is independent of this k. -/
namespace OMA.FixedModeAnyProduct245212
open Nat Finset ArithmeticFunction OMA.Smooth245212 OMA.FixedRankGap245212
open OMA.FixedModeProduct245212 (exactSet dropped mult others partition)
open OMA.TwoTallLocal245212 OMA.ThreeMovingLocal245212
open OMA.ThreeMovingOriginal245212 (F G)
open scoped ArithmeticFunction.sigma Function
open private OMA.ComplementaryLocal245212.binary from ComplementaryLocal245212
open private OMA.FixedRankHeight245212.identities from FixedRankHeight245212
variable {r : ℕ}
def pref (k : ℕ) (c : Family r) (b : Fin r→Option Bool) := 2^k*∏i∈exactSet b,c.p i^c.e i

theorem prefix_moments (k : ℕ) (c : Family r) (odd : ∀i,Odd (c.p i)) (b : Fin r→Option Bool) :
    W (pref k c b)=F k*(∏i∈exactSet b,W (c.p i^c.e i)) ∧
    σ 1 (pref k c b)=G k*(∏i∈exactSet b,σ 1 (c.p i^c.e i)) ∧
    2*(pref k c b)*(σ 0 (pref k c b))=(F k+G k)*(∏i∈exactSet b,((c.e i+1)*c.p i^c.e i)) := by
  let s:=exactSet b
  let a i:=c.p i^c.e i
  have cop : (2^k).Coprime (∏i∈s,a i):=Nat.coprime_prod_right_iff.mpr (fun i _=>
    ((Nat.coprime_two_left.mpr (odd i)).pow_left _).pow_right _)
  have pw : (s:Set (Fin r)).Pairwise (Nat.Coprime on a):=fun i _ j _ ij=>
    (((Nat.coprime_primes (c.prime i) (c.prime j)).mpr (c.inj.ne ij)).pow_left _).pow_right _
  have Wp:=IsMultiplicative.map_prod a w_mult s pw
  have Sp:=IsMultiplicative.map_prod a (isMultiplicative_sigma (k:=1)) s pw
  have Tp:=IsMultiplicative.map_prod a (isMultiplicative_sigma (k:=0)) s pw
  have gf : σ 1 (2^k)=G k := by
    dsimp [G];zify [Nat.cast_sub (show 1≤2^(k+1) from Nat.two_pow_pos _)]
    exact (OMA.ComplementaryLocal245212.binary k).1
  have ff : W (2^k)=F k := by exact_mod_cast (OMA.ComplementaryLocal245212.binary k).2
  change W (2^k*∏i∈s,a i)=_ ∧ σ 1 (2^k*∏i∈s,a i)=_ ∧ 2*(2^k*∏i∈s,a i)*σ 0 (2^k*∏i∈s,a i)=_
  rw [w_mult.map_mul_of_coprime cop,isMultiplicative_sigma.map_mul_of_coprime cop,
    isMultiplicative_sigma.map_mul_of_coprime cop,ff,gf,Wp,Sp,Tp]
  refine ⟨rfl,rfl,?_⟩
  simp only [a,sigma_zero_apply_prime_pow (c.prime _),sigma_zero_apply_prime_pow Nat.prime_two,
    (OMA.FixedRankHeight245212.identities k).2.1,pow_succ 2,prod_mul_distrib,s]
  ring

theorem equation (k : ℕ) (c : Family r) (odd : ∀i,Odd (c.p i)) {b : Fin r→Option Bool} {v : Fin r}
    (keep : b v=some true) (only : ∀i,i≠v → b i≠some true)
    (hit : (F k+G k)*dust c b=F k*NX c b+G k*NY c b) :
    let H:=2*(pref k c b)*σ 0 (pref k c b)
    let B:=c.e v+1; let C:=mult c b; let q:=c.p v; let u:=q-1
    H*B*C*u^2=q*(W (pref k c b)*C*(B*u-1)+σ 1 (pref k c b)*u) := by
  obtain ⟨av,sv,hv⟩:=prefix_moments k c odd b
  obtain ⟨d,x,y⟩:=others c keep only
  dsimp only
  rw [av,sv,hv]
  unfold dust NX NY at hit
  rw [←prod_erase_mul _ _ (mem_univ v),←prod_erase_mul _ (fun i=>Nx _ _ _) (mem_univ v),
    ←prod_erase_mul _ (fun i=>Ny _ _ _) (mem_univ v)] at hit
  rw [d,x,y,keep] at hit
  simp only [Dn,Nx,Ny,den,xn,yn,if_true] at hit
  linear_combination hit

end OMA.FixedModeAnyProduct245212
