import RankThreeFourSmallSeparation245212
import RankThreeFourSmallBounds245212
import ComplementarySize245212

/-! Prime-power estimates for making the exceptional two-prime Euler slope effective. -/
namespace OMA.TwoFreeEffectivePower245212
open Nat ArithmeticFunction OMA.Smooth245212 OMA.CofactorPairPole245212
open OMA.RankThreeFourSmallSeparation245212
open scoped ArithmeticFunction.sigma
open private OMA.RankThreeFourSmallSeparation245212.squeeze OMA.RankThreeFourSmallSeparation245212.coeff from RankThreeFourSmallSeparation245212
open private OMA.CapOrder245212.geom from CapOrder245212

theorem min_power {h p q a d M : ℕ} (hh : 0<h) (hp : p.Prime) (hq : q.Prime)
    (cp : h.Coprime p) (cq : h.Coprime q) (pq : p<q)
    (am : a≤M) (dm : d≤M) (qm : M+1<q) (qt : ¬q∣2*(h*σ 0 h))
    (eqn : OeisA245212.a (h*p^a*q^d)=(σ 1 (h*p^a*q^d):ℤ)) :
    min (p^a) (q^d)≤cost (W h) (σ 1 h) q M := by
  let A:=W h
  let S:=σ 1 h
  let T:=h*σ 0 h
  have nt:=separated' (A:=A) (S:=S) (T:=T) hq hp.two_le pq (Nat.succ_pos a)
    (Nat.succ_pos d) qt (by omega) (by omega)
  have f:=OMA.ComplementaryLocal245212.moments hp a
  have g:=OMA.ComplementaryLocal245212.moments hq d
  have id:=tails A S T p q (a+1) (d+1) ((p:ℤ)^a) ((q:ℤ)^d)
    (W (p^a)) (W (q^d)) (σ 1 (p^a)) (σ 1 (q^d)) f.2 g.2 f.1 g.1
    (balance hh hp hq cp cq pq.ne eqn)
  have x:=OMA.RankThreeFourSmallSeparation245212.coeff (p:=(q:ℤ)) (q:=(p:ℤ)) (z:=(q:ℤ)) (A:=(A:ℤ)) (S:=(S:ℤ)) (M:=(M:ℤ)) (Int.natCast_nonneg _) (Int.natCast_nonneg _)
    (by exact_mod_cast hq.two_le) (by exact_mod_cast hp.two_le) (by rfl : (q:ℤ)≤q)
    (by exact_mod_cast pq.le) (by omega : 1≤(d:ℤ)+1) (by omega)
  have y:=OMA.RankThreeFourSmallSeparation245212.coeff (p:=(p:ℤ)) (q:=(q:ℤ)) (z:=(q:ℤ)) (A:=(A:ℤ)) (S:=(S:ℤ)) (M:=(M:ℤ)) (Int.natCast_nonneg _) (Int.natCast_nonneg _)
    (by exact_mod_cast hp.two_le) (by exact_mod_cast hq.two_le) (by exact_mod_cast pq.le)
    (by rfl : (q:ℤ)≤q) (by omega : 1≤(a:ℤ)+1) (by omega)
  have ip : (2:ℤ)≤p := by exact_mod_cast hp.two_le
  have iq : (2:ℤ)≤q := by exact_mod_cast hq.two_le
  have ord : (p:ℤ)≤q := by exact_mod_cast pq.le
  have u : ((p:ℤ)-1)*(q-1)≤(q:ℤ)*q :=
    mul_le_mul (by omega) (by omega) (by omega) (by omega)
  have wle : (A:ℤ)+(S:ℤ)*((p:ℤ)-1)*((q:ℤ)-1)≤A+S*(q:ℤ)^2 := by
    nlinarith only [mul_le_mul_of_nonneg_left u (Int.natCast_nonneg S)]
  have n : defect A S T p q ((a:ℤ)+1) ((d:ℤ)+1)≠0 := by exact_mod_cast nt
  rw [mul_right_comm (S:ℤ) ((q:ℤ)-1) ((p:ℤ)-1)] at x
  have w0 : (0:ℤ)≤(A:ℤ)+(S:ℤ)*((p:ℤ)-1)*((q:ℤ)-1) := add_nonneg (Int.natCast_nonneg A)
    (mul_nonneg (mul_nonneg (Int.natCast_nonneg S) (by omega)) (by omega))
  have k:=OMA.RankThreeFourSmallSeparation245212.squeeze (P:=(p:ℤ)^a) (Q:=(q:ℤ)^d) n (by exact_mod_cast Nat.one_le_pow a p hp.pos)
    (by exact_mod_cast Nat.one_le_pow d q hq.pos) x y w0 wle (by simpa only [add_assoc] using id)
  unfold cost; rw [Nat.add_assoc];exact_mod_cast k

theorem moments {h p e : ℕ} (hp : p.Prime) (cp : h.Coprime p) :
    W (h*p^e)+σ 1 (h*p^e)≤2*(W h*(e+1)+σ 1 h)*p^e := by
  have sg : σ 1 (p^e)<2*p^e := by rw [sigma_one_apply_prime_pow hp];exact OMA.CapOrder245212.geom p hp.one_lt e
  have wt : W (p^e)≤(e+1)*(σ 1 (p^e)) := by
    rw [w_pow hp,sigma_one_apply_prime_pow hp,Finset.mul_sum]
    exact Finset.sum_le_sum fun j hj => by
      have le:=show j+1≤e+1 by have := Finset.mem_range.mp hj;omega
      simpa only [Nat.mul_comm] using Nat.mul_le_mul_left (p^j) le
  rw [w_mult.map_mul_of_coprime (cp.pow_right e),isMultiplicative_sigma.map_mul_of_coprime (cp.pow_right e)]
  nlinarith only [Nat.mul_le_mul_left (W h) wt,Nat.mul_le_mul_left (W h*(e+1)+σ 1 h) sg.le]

theorem next_power {h p q a d : ℕ} (hh : 0<h) (hp : p.Prime) (hq : q.Prime) (oq : q≠2)
    (cp : h.Coprime p) (cq : h.Coprime q) (pq : p≠q) (dp : 0<d)
    (eqn : OeisA245212.a (h*p^a*q^d)=(σ 1 (h*p^a*q^d):ℤ)) :
    q^d≤(2*(W h*(a+1)+σ 1 h)*p^a)^2 := by
  have pos:=hp.pos
  have mp : 0<h*p^a := by positivity
  have c:=(cq.mul_left (((coprime_primes hp hq).mpr pq).pow_left a))
  exact (OMA.PairHeight245212.last_square mp hq oq c dp eqn).trans (Nat.pow_le_pow_left (moments hp cp) 2)

theorem lengths {A S p q a d : ℕ} (pa : p^4≤q) (large : 16*(A+S+1)≤q)
    (aq : a+1<q) (pow : q^d≤(2*(A*(a+1)+S)*p^a)^2) : d+1<q := by
  have q1 : 1<q := by omega
  have small : 2*(A*(a+1)+S)≤q^2 := by
    have ord : 2*(A+S)≤q := by omega
    nlinarith only [Nat.mul_le_mul_right q ord,Nat.mul_le_mul_left A aq.le,Nat.le_mul_of_pos_right S (by omega : 0<q)]
  have twice:=Nat.pow_le_pow_left (pow.trans (Nat.pow_le_pow_left (Nat.mul_le_mul_right _ small) 2)) 2
  have le : q^(2*d)≤q^(8+a) := calc
    _ = (q^d)^2 := by rw [←pow_mul];ring_nf
    _ ≤ ((q^2*p^a)^2)^2 := twice
    _ = q^8*(p^4)^a := by ring_nf
    _ ≤ q^8*q^a := Nat.mul_le_mul_left _ (Nat.pow_le_pow_left pa a)
    _ = _ := (pow_add q 8 a).symm
  have := (pow_le_pow_iff_right₀ q1).mp le
  omega

theorem polynomial_cut {C a : ℕ} (z : 2^a≤C*(a+1)^6) : a ≤ max 784 (64*C) := by
  by_cases big : 784≤a
  · have abs:=OMA.ComplementarySize245212.absorb (d:=6) big
    have le1 : a+1≤2*a := by omega
    have le:=abs.trans (z.trans (Nat.mul_le_mul_left C (Nat.pow_le_pow_left le1 6)))
    have v : a^6*a^6≤64*C*a^6 := calc
      _ = a^(2*6) := by ring
      _ ≤ C*(2*a)^6 := le
      _ = _ := by ring
    have a0 : 0<a^6 := by positivity
    have x:=Nat.le_of_mul_le_mul_right v a0
    have aa : a≤a^6 := by simpa using (Nat.pow_le_pow_right (show 0<a by omega) (by decide : 1≤6))
    exact (aa.trans x).trans (le_max_right _ _)
  · omega

end OMA.TwoFreeEffectivePower245212
