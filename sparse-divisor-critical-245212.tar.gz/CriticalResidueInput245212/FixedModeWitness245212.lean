import FixedRankStep245212

/-! A polynomial-width empty interval producing an exact mixed equality at any rank. -/
namespace OMA.FixedModeWitness245212
open Nat Finset OMA.TwoTallLocal245212 OMA.ThreeMovingLocal245212 OMA.FixedRankGap245212 OMA.FixedRankStep245212
open private OMA.FixedRankStep245212.integer_gap OMA.FixedRankStep245212.difference from FixedRankStep245212
variable {r : ℕ}

theorem witness (c : Family r) (f g x : ℕ) (big : 128≤x) (cf : f+g≤x) (cl : c.L≤x) (errorCap : 2*r*2^r≤x)
    (actual : score f g (exactX c) (exactY c)=(f+g:ℕ)) :
    ∃ (b : Fin r→Option Bool) (Q : ℕ), x≤Q ∧ Q≤x^(degree r) ∧
      (∀i,b i=if c.p i^c.e i≤Q then none else some (decide (c.p i≤Q))) ∧
      (f+g)*dust c b=f*NX c b+g*NY c b := by
  have close : |score f g (exactX c) (exactY c)-(f+g:ℕ)| ≤ 1/((x^(degree r):ℕ):ℚ):=by
    rw [actual,sub_self,abs_zero];positivity
  let point : Fin r ⊕ Fin r → ℕ := Sum.elim c.p (fun i=>c.p i^c.e i)
  obtain ⟨j,band⟩:=empty_band x (by omega) point
  have bp (i:Fin r) := band (Sum.inl i)
  have bd (i:Fin r) := band (Sum.inr i)
  let Q:=cut r x j.val
  let N:=cut r x (j.val+1)
  let b (i:Fin r) : Option Bool := if c.p i^c.e i≤Q then none else some (decide (c.p i≤Q))
  have next : N=Q^(3*r+4) := cut_succ ..
  have xQ : x≤Q := by
    have old:=cut_mono r (show 1≤x by omega) (Nat.zero_le j.val)
    simpa [cut,Q] using old
  have np : 0<N := by rw [next];exact pow_pos (by omega) _
  have nb : N≤x^(degree r):=cut_mono r (by omega) (show j.val+1≤2*r+1 by omega)
  have space (i) (t:Bool) (mode:b i=some t) : N ≤ (if t then c.p i^c.e i else c.p i) := by
    dsimp [b] at mode
    split at mode
    next=>contradiction
    next off=>
      obtain rfl:=Option.some.inj mode
      by_cases lo : c.p i≤Q
      · simp [lo]
        exact ((bd i).resolve_left off).le
      · simp [lo]
        exact ((bp i).resolve_left lo).le
  have ds : dust c b≤Q^(3*r) := by
    have per i : Dn (c.p i) (c.e i) (b i)≤Q^3 := by
      have el := (c.cap i).trans (cl.trans xQ)
      by_cases exactMode : c.p i^c.e i≤Q
      · rw [show b i=none from if_pos exactMode]
        change (c.e i+1)*(c.p i^c.e i)≤Q^3
        exact
          (Nat.mul_le_mul el exactMode).trans (show Q*Q≤Q^3 by rw [←sq];exact Nat.pow_le_pow_right (by omega) (by decide))
      · by_cases keep:c.p i≤Q
        · simpa [b,exactMode,keep,Dn,den] using
            (Nat.mul_le_mul el (Nat.pow_le_pow_left (show c.p i-1≤Q by omega) 2)).trans_eq (by ring : Q*Q^2=Q^3)
        · simpa [b,exactMode,keep,Dn,den] using el.trans (Nat.le_self_pow (by decide : 3≠0) Q)
    dsimp [dust]
    exact (prod_le_prod' (fun i _=>per i)).trans_eq (by simp [←pow_mul])
  have below:=cut_mono r (show 1≤x by omega) (show j.val≤2*r+1 by omega)
  refine ⟨b,Q,xQ,below,fun _=>rfl,?_⟩
  by_contra nz
  have iga:=OMA.FixedRankStep245212.integer_gap c b f g nz
  let orig:=score f g (exactX c) (exactY c)
  let approx:=score f g (x' c b) (y' c b)
  let W:ℚ:=(f+g:ℕ)
  have lite : |orig-W|≤1/(N:ℚ) := close.trans (one_div_le_one_div_of_le (by positivity) (by exact_mod_cast nb))
  have diff:=OMA.FixedRankStep245212.difference c b f g N np space
  change |approx-orig|≤_ at diff
  change (1:ℚ)≤|approx-W| * dust c b at iga
  have err : |approx-W| * (N:ℚ)≤(2*r*2^r:ℕ)*((f:ℚ)+g)+1 := by
    have t:=abs_sub_le approx orig W
    have wn : (0:ℚ)<N:=by exact_mod_cast np
    nlinarith only [mul_le_mul_of_nonneg_right t wn.le,(le_div_iff₀ wn).mp diff,(le_div_iff₀ wn).mp lite]
  have sep : N≤((2*r*2^r)*(f+g)+1)*dust c b := by
    have z : (N:ℚ)≤((2*r*2^r:ℕ)*((f:ℚ)+g)+1)*dust c b := by
      nlinarith only [mul_le_mul_of_nonneg_right iga (Nat.cast_nonneg N : (0:ℚ)≤N),
        mul_le_mul_of_nonneg_right err (Nat.cast_nonneg (dust c b) : (0:ℚ)≤_)]
    exact_mod_cast z
  have qr : 128≤Q:=big.trans xQ
  have cfq : f+g≤Q:=cf.trans xQ
  have rate : 2*r*2^r≤Q := errorCap.trans xQ
  have cf' : (2*r*2^r)*(f+g)+1<Q^3 := by
    have m:=Nat.mul_le_mul rate cfq
    have grow:=Nat.mul_le_mul_left (Q*Q) (show 2≤Q by omega)
    nlinarith only [m,grow,qr,Nat.mul_self_le_mul_self (show 2≤Q by omega)]
  have bad : N < Q^(3+3*r) := sep.trans_lt ((Nat.mul_lt_mul_of_lt_of_le cf' ds
    (pow_pos (by omega) _)).trans_eq (by rw [pow_add]))
  have natural : Q^(3+3*r)≤N:=next ▸ Nat.pow_le_pow_right (by omega) (by omega)
  omega

end OMA.FixedModeWitness245212
