import FixedModeArithmetic245212
import FixedRankInteger245212
import ArbitraryMixedFinite245212
import RankFourEffective245212

/-! At each fixed rank all solutions with large dyadic valuation have bounded
odd exponent lengths. Consequently the dyadic valuation is always bounded;
the independently established fixed-dyadic-order height closes rank four. -/
namespace OMA.FixedModeClose245212
open Nat Finset OMA.FixedRankGap245212 OMA.FixedRankInteger245212
open OMA.Smooth245212 (total)
open scoped ArithmeticFunction.sigma

noncomputable section

def lengthCap (r : ℕ) := OMA.FixedTallScalar245212.threshold r 1+
  OMA.ArbitraryMixedFinite245212.cutoff (r+1) (OMA.FixedModeArithmetic245212.exponent r)
def kCap (r : ℕ) := 256+polynomial r (lengthCap r)
def fourCap := ∑ j∈range (kCap 4+1),OMA.RankFourEffective245212.bound j

theorem high {r : ℕ} (c : Family r) (odd : ∀i,Odd (c.p i)) (klarge : 256≤c.k)
    (eqn : OeisA245212.a (2^c.k*total c.p c.e)=(σ 1 (2^c.k*total c.p c.e):ℤ)) : c.L≤lengthCap r := by
  by_cases big : OMA.FixedTallScalar245212.threshold r 1≤c.L
  · obtain ⟨v,vl⟩:=c.longest
    obtain ⟨h,q,C,hp,rank,qg,bp,cp,small,side,hit⟩:=OMA.FixedModeArithmetic245212.original c odd klarge big v vl eqn
    exact (OMA.ArbitraryMixedFinite245212.bounded hp rank qg bp cp small side hit).trans (Nat.le_add_left _ _)
  · exact (le_of_lt (lt_of_not_ge big)).trans (Nat.le_add_right _ _)

theorem orderBound {r k L : ℕ} (p e : Fin r→ℕ) (pr : ∀i,(p i).Prime) (odd : ∀i,Odd (p i))
    (inj : p.Injective) (ep : ∀i,0<e i) (longest : ∃i,e i+1=L) (cap : ∀i,e i+1≤L)
    (eqn : OeisA245212.a (2^k*total p e)=(σ 1 (2^k*total p e):ℤ)) :
    (256≤k → L≤lengthCap r) ∧ k≤kCap r := by
  have H (large : 256≤k) : L≤lengthCap r :=
    high (⟨p,e,k,L,pr,ep,by omega,longest,cap,inj⟩ : Family r) odd large eqn
  refine ⟨H,?_⟩
  by_cases large : 256≤k
  · have limit:=H large
    have b:=OMA.FixedRankHeight245212.original k L p e pr odd inj ep longest cap eqn
    have mono : polynomial r L≤polynomial r (lengthCap r):=
      Nat.mul_le_mul_left _ (Nat.pow_le_pow_left (Nat.succ_le_succ limit) _)
    exact Nat.lt_two_pow_self.le.trans (b.trans (mono.trans (Nat.le_add_left _ _)))
  · exact (le_of_lt (lt_of_not_ge large)).trans (Nat.le_add_right _ _)

theorem original {n : ℕ} (pos : 0<n) (nonempty : (support n).Nonempty)
    (eqn : OeisA245212.a n=(σ 1 n:ℤ)) :
    (256≤n.factorization 2 → longest n≤lengthCap (support n).card) ∧
      n.factorization 2≤kCap (support n).card := by
  let s:=support n
  let P : Fin s.card ↪o ℕ:=s.orderEmbOfFin rfl
  let e (i : Fin s.card):=n.factorization (P i)
  have mem (i : Fin s.card) : P i∈s:=s.orderEmbOfFin_mem rfl i
  have prime i := prime_of_mem_primeFactors (mem_erase.mp (mem i)).2
  have odd i := (prime i).odd_of_ne_two (mem_erase.mp (mem i)).1
  have ep (i) : 0<e i:=Nat.pos_of_ne_zero (Finsupp.mem_support_iff.mp (mem_erase.mp (mem i)).2)
  have lift : univ.map P.toEmbedding=s:=s.map_orderEmbOfFin_univ rfl
  have fac : 2^(n.factorization 2)*(∏ p∈s,p^(n.factorization p))=n := by
    by_cases h : 2∈n.primeFactors
    · exact (mul_prod_erase n.primeFactors (fun p => p^(n.factorization p)) h).trans
        (Nat.prod_primeFactors_pow_factorization pos.ne').symm
    · have z : n.factorization 2=0:=Finsupp.notMem_support_iff.mp h
      simpa [z,s,support,erase_eq_of_notMem h] using (Nat.prod_primeFactors_pow_factorization pos.ne').symm
  rw [←lift,prod_map] at fac
  change 2^(n.factorization 2)*total P e=n at fac
  obtain ⟨z,zm,zt⟩:=Finset.exists_mem_eq_sup s nonempty (fun p=>n.factorization p+1)
  obtain ⟨i,_,zi⟩:=Finset.mem_map.mp (lift.symm ▸ zm)
  change P i=z at zi
  have zmax : ∃ i,e i+1=longest n:=⟨i,by change n.factorization (P i)+1=longest n;rw [zi];exact zt.symm⟩
  have cap i : e i+1≤longest n := Finset.le_sup (f:=fun p=>n.factorization p+1) (mem i)
  exact orderBound P e prime odd P.injective ep zmax cap (by rwa [fac])

theorem four {n : ℕ} (pos : 0<n) (rank : (support n).card=4)
    (eqn : OeisA245212.a n=(σ 1 n:ℤ)) : n≤fourCap := by
  let m:=ordCompl[2] n
  let k:=n.factorization 2
  have cm : Odd m:=Nat.coprime_two_left.mp (Nat.coprime_ordCompl prime_two pos.ne')
  have ss : m.primeFactors=support n := by
    dsimp [m,support];rw [←Nat.support_factorization,Nat.factorization_ordCompl,Finsupp.support_erase,Nat.support_factorization]
  have id : 2^k*m=n:=Nat.ordProj_mul_ordCompl_eq_self n 2
  have b:=OMA.RankFourEffective245212.original (k:=k) cm ((congrArg Finset.card ss).trans rank) (by rwa [id])
  rw [id] at b
  have kb:=(original pos (Finset.card_pos.mp (show 0<(support n).card by omega)) eqn).2
  rw [rank] at kb
  change k≤kCap 4 at kb
  have use (K j : ℕ) (hj : j≤K) : OMA.RankFourEffective245212.bound j≤
      ∑ t∈range (K+1),OMA.RankFourEffective245212.bound t :=
    single_le_sum (f:=OMA.RankFourEffective245212.bound) (fun _ _=>Nat.zero_le _) (mem_range.mpr (Nat.lt_succ_of_le hj))
  exact b.trans (use (kCap 4) k kb)

theorem four_finite : {n : ℕ | 0<n ∧ (support n).card=4 ∧ OeisA245212.a n=(σ 1 n:ℤ)}.Finite :=
  (Set.finite_Iic fourCap).subset (fun _ h=>four h.1 h.2.1 h.2.2)

end
end OMA.FixedModeClose245212
