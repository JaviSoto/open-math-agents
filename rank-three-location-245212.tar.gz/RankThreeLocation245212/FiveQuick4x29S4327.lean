import FiveFastNear245212
namespace OMA.FiveQuick4x29
open OMA.CofactorEulerPair245212 OMA.FiveFastNear245212
open OMA.RankThreeFiveTail245212 (cofactor wt sg ta)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 0
theorem span4327 : every 4327 4470 (OMA.RankThreeFiveShort245212.test 4 29)=true :=
  interval (m:=30) (by decide +kernel) (show every 4327 4470 (fast 2980232238769531250000 893545802682638168334969 7217749953269958496086 447034835815429687500000 30)=true by decide +kernel)
end OMA.FiveQuick4x29
