import RankThreeFiveFar245212
/-! Check the terminal divisor counts above the middle-prime cutoff. -/
namespace OMA.FiveFar4x20
open OMA.RankThreeFiveFar245212 OMA.CofactorEulerPair245212
open OMA.RankThreeMiddle245212 (joinEvery)
open OMA.RankThreeEightMoving245212 (single)
set_option maxHeartbeats 2400000
set_option maxRecDepth 65536
private theorem local4_2 : every 2 2 (splitPair 319093465805053719 3695487976074211 160217285156250000 956 4)=true := by decide +kernel
private theorem n4 : every 4 4 (bucket 319093465805053719 3695487976074211 160217285156250000 956)=true := single local4_2
private theorem local5_2 : every 2 2 (splitPair 319093465805053719 3695487976074211 160217285156250000 956 5)=true := by decide +kernel
private theorem n5 : every 5 5 (bucket 319093465805053719 3695487976074211 160217285156250000 956)=true := single local5_2
theorem scan : every 4 5 (bucket 319093465805053719 3695487976074211 160217285156250000 956)=true := (joinEvery n4 n5)
end OMA.FiveFar4x20
