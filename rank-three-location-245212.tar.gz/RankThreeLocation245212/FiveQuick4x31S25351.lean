import FiveFastNear245212
namespace OMA.FiveQuick4x31
open OMA.CofactorEulerPair245212 OMA.FiveFastNear245212
open OMA.RankThreeFiveTail245212 (cofactor wt sg ta)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 0
theorem span25351 : every 25351 25606 (OMA.RankThreeFiveShort245212.test 4 31)=true :=
  interval (m:=32) (by decide +kernel) (show every 25351 25606 (fast 74505805969238281250000 23840402718633413314819344 180443748831748962402336 11920928955078125000000000 32)=true by decide +kernel)
end OMA.FiveQuick4x31
