import FiveFastNear245212
namespace OMA.FiveQuick4x28
open OMA.CofactorEulerPair245212 OMA.FiveFastNear245212
open OMA.RankThreeFiveTail245212 (cofactor wt sg ta)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 0
theorem span3319 : every 3319 3462 (OMA.RankThreeFiveShort245212.test 4 28)=true :=
  interval (m:=29) (by decide +kernel) (show every 3319 3462 (fast 596046447753906250000 172702129930257797241219 1443549990653991699211 86426734924316406250000 29)=true by decide +kernel)
end OMA.FiveQuick4x28
