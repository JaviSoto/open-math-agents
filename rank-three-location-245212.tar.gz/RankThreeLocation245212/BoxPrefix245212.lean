import BoxKernel245212
import PrefixLeaf245212

/-! Exact-prefix exclusions for rectangular ranges of all three cofactor exponents. -/
namespace OMA.Box245212
open OMA.Smooth245212 Finset OMA.Large245212
open scoped ArithmeticFunction.sigma

def Range.entries (r : Range) := List.range' r.lo (r.hi+1-r.lo)
theorem Range.mem_entries {r : Range} {v : ℕ} (h : r.has v) : v∈r.entries := by
  rcases h with ⟨l,u⟩
  exact List.mem_range'_1.mpr ⟨l,by omega⟩

def exactBlock (p q : ℕ) (b : Box) : Bool :=
  decide (1<(b 4).lo) &&
  (b 0).entries.all (fun k => (b 1).entries.all (fun e => (b 2).entries.all (fun f =>
    PrefixLeaf245212.exact (wt 3 k*wt p e*wt q f) (sig 3 k*sig p e*sig q f)
      (tax 3 k*tax p e*tax q f) (b 4).lo (b 4).hi (b 3).lo (b 3).hi)))

theorem prefix_sound {p q : ℕ} {b : Box} (yes : exactBlock p q b=true) : Deny p q b := by
  intro v inside c
  have h := Bool.and_eq_true_iff.mp yes
  have check0 := List.all_eq_true.mp h.2 (v 0) (Range.mem_entries (inside 0))
  have check1 := List.all_eq_true.mp check0 (v 1) (Range.mem_entries (inside 1))
  have check2 := List.all_eq_true.mp check1 (v 2) (Range.mem_entries (inside 2))
  let m := 3^(v 0)*p^(v 1)*q^(v 2)
  have hp : p.Prime := c.prime 1
  have hq : q.Prime := c.prime 2
  have hr : (v 4).Prime := c.prime 3
  have small : 3<p := c.ordered (show (0:Fin 4)<1 by decide)
  have pq : p<q := c.ordered (show (1:Fin 4)<2 by decide)
  have qr : q<v 4 := c.ordered (show (2:Fin 4)<3 by decide)
  have same : total (bases p q v) (exponents v)=m*(v 4)^(v 3) := by
    simp [total,bases,exponents,m,Fin.prod_univ_four]
  have s := c.eqn; dsimp only at s; rw [same] at s
  have cop : m.Coprime (v 4) :=
    (((Nat.coprime_primes Nat.prime_three hr).mpr (by omega)).pow_left _).mul_left
      (((Nat.coprime_primes hp hr).mpr (by omega)).pow_left _) |>.mul_left
        (((Nat.coprime_primes hq hr).mpr qr.ne).pow_left _)
  have mp : 0 < m := mul_pos (mul_pos (pow_pos (by decide) _) (pow_pos hp.pos _)) (pow_pos hq.pos _)
  have no := PrefixLeaf245212.extension mp
    hr (by omega) cop (of_decide_eq_true h.1) (inside 4).1 (inside 4).2 (inside 3).1 (inside 3).2
    (c.pos 3) s
  have triple := PrefixLeaf245212.triple Nat.prime_three hp hq small.ne (by omega) pq.ne (v 0) (v 1) (v 2)
  dsimp only at triple
  dsimp only [m] at no
  rw [triple.1,triple.2.1,triple.2.2] at no
  exact Bool.noConfusion (check2.symm.trans no)

end OMA.Box245212
