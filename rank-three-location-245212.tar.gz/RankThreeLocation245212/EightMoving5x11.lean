import RankThreeEightMoving245212
/-! Complete enumeration of both short prefixes for one moving-prime family. -/
/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E1P11
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b12 : every 12 13 (quick 40 539 90 320 11)=true := by decide +kernel
theorem certificate : atom 5 11 1=true := by
  apply row_low (h:=40) (A:=539) (S:=90) (T:=320) (R:=12) (Q:=13) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 13≤12+128)]
  exact b12
end OMA.EightAt5E1P11

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E2P11
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b12 : every 12 27 (quick 200 4214 465 2400 11)=true := by decide +kernel
private theorem b28 : every 28 29 (quick 200 4214 465 2400 11)=true := by decide +kernel
theorem certificate : atom 5 11 2=true := by
  apply row_low (h:=200) (A:=4214) (S:=465) (T:=2400) (R:=12) (Q:=29) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 29≤12+128)]
  exact (joinEvery b12 b28)
end OMA.EightAt5E2P11

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E3P11
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b12 : every 12 27 (quick 1000 28714 2340 16000 11)=true := by decide +kernel
private theorem b28 : every 28 43 (quick 1000 28714 2340 16000 11)=true := by decide +kernel
private theorem b44 : every 44 59 (quick 1000 28714 2340 16000 11)=true := by decide +kernel
private theorem b60 : every 60 75 (quick 1000 28714 2340 16000 11)=true := by decide +kernel
private theorem b76 : every 76 77 (quick 1000 28714 2340 16000 11)=true := by decide +kernel
theorem certificate : atom 5 11 3=true := by
  apply row_low (h:=1000) (A:=28714) (S:=2340) (T:=16000) (R:=12) (Q:=77) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 77≤12+128)]
  exact (joinEvery (joinEvery b12 b28) (joinEvery b44 (joinEvery b60 b76)))
end OMA.EightAt5E3P11

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E4P11
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b17 : every 17 32 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b33 : every 33 48 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b49 : every 49 64 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b65 : every 65 80 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b81 : every 81 96 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b97 : every 97 112 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b113 : every 113 128 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b129 : every 129 144 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b145 : every 145 160 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b161 : every 161 176 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b177 : every 177 192 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b193 : every 193 208 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b209 : every 209 224 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b225 : every 225 240 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b241 : every 241 256 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b257 : every 257 272 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b273 : every 273 288 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b289 : every 289 304 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b305 : every 305 320 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b321 : every 321 336 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b337 : every 337 352 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b353 : every 353 368 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b369 : every 369 384 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b385 : every 385 400 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b401 : every 401 416 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b417 : every 417 432 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b433 : every 433 448 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b449 : every 449 464 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b465 : every 465 480 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b481 : every 481 496 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b497 : every 497 512 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b513 : every 513 528 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b529 : every 529 544 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b545 : every 545 560 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b561 : every 561 576 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b577 : every 577 592 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b593 : every 593 608 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b609 : every 609 624 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b625 : every 625 640 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b641 : every 641 656 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b657 : every 657 672 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b673 : every 673 688 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b689 : every 689 704 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b705 : every 705 720 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b721 : every 721 736 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b737 : every 737 752 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b753 : every 753 768 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b769 : every 769 784 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b785 : every 785 800 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b801 : every 801 816 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b817 : every 817 832 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b833 : every 833 848 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b849 : every 849 864 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b865 : every 865 880 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b881 : every 881 896 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b897 : every 897 912 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b913 : every 913 928 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b929 : every 929 944 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b945 : every 945 960 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b961 : every 961 976 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b977 : every 977 992 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b993 : every 993 1008 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1009 : every 1009 1024 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1025 : every 1025 1040 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1041 : every 1041 1056 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1057 : every 1057 1072 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1073 : every 1073 1088 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1089 : every 1089 1104 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1105 : every 1105 1120 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1121 : every 1121 1136 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1137 : every 1137 1152 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1153 : every 1153 1168 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1169 : every 1169 1184 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1185 : every 1185 1200 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1201 : every 1201 1216 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1217 : every 1217 1232 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1233 : every 1233 1248 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1249 : every 1249 1264 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1265 : every 1265 1280 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1281 : every 1281 1296 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1297 : every 1297 1312 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1313 : every 1313 1328 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1329 : every 1329 1344 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1345 : every 1345 1360 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1361 : every 1361 1376 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1377 : every 1377 1392 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1393 : every 1393 1408 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1409 : every 1409 1424 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1425 : every 1425 1440 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1441 : every 1441 1456 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1457 : every 1457 1472 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1473 : every 1473 1488 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1489 : every 1489 1504 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1505 : every 1505 1520 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1521 : every 1521 1536 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1537 : every 1537 1552 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1553 : every 1553 1568 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1569 : every 1569 1584 (line 181839 11715 100000 11 12)=true := by decide +kernel
private theorem b1585 : every 1585 1588 (line 181839 11715 100000 11 12)=true := by decide +kernel
theorem certificate : atom 5 11 4=true := by
  apply row_high (h:=5000) (A:=181839) (S:=11715) (T:=100000) (R:=12) (B:=1588) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery b145 (joinEvery b161 b177)))) (joinEvery (joinEvery (joinEvery b193 (joinEvery b209 b225)) (joinEvery b241 (joinEvery b257 b273))) (joinEvery (joinEvery b289 (joinEvery b305 b321)) (joinEvery (joinEvery b337 b353) (joinEvery b369 b385))))) (joinEvery (joinEvery (joinEvery (joinEvery b401 (joinEvery b417 b433)) (joinEvery b449 (joinEvery b465 b481))) (joinEvery (joinEvery b497 (joinEvery b513 b529)) (joinEvery b545 (joinEvery b561 b577)))) (joinEvery (joinEvery (joinEvery b593 (joinEvery b609 b625)) (joinEvery b641 (joinEvery b657 b673))) (joinEvery (joinEvery b689 (joinEvery b705 b721)) (joinEvery (joinEvery b737 b753) (joinEvery b769 b785)))))) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b801 (joinEvery b817 b833)) (joinEvery b849 (joinEvery b865 b881))) (joinEvery (joinEvery b897 (joinEvery b913 b929)) (joinEvery b945 (joinEvery b961 b977)))) (joinEvery (joinEvery (joinEvery b993 (joinEvery b1009 b1025)) (joinEvery b1041 (joinEvery b1057 b1073))) (joinEvery (joinEvery b1089 (joinEvery b1105 b1121)) (joinEvery (joinEvery b1137 b1153) (joinEvery b1169 b1185))))) (joinEvery (joinEvery (joinEvery (joinEvery b1201 (joinEvery b1217 b1233)) (joinEvery b1249 (joinEvery b1265 b1281))) (joinEvery (joinEvery b1297 (joinEvery b1313 b1329)) (joinEvery b1345 (joinEvery b1361 b1377)))) (joinEvery (joinEvery (joinEvery b1393 (joinEvery b1409 b1425)) (joinEvery b1441 (joinEvery b1457 b1473))) (joinEvery (joinEvery b1489 (joinEvery b1505 b1521)) (joinEvery (joinEvery b1537 b1553) (joinEvery b1569 b1585)))))))
end OMA.EightAt5E4P11

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E5P11
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 1100589 58590 600000 11 12)=true := by decide +kernel
private theorem b17 : every 17 20 (line 1100589 58590 600000 11 12)=true := by decide +kernel
theorem certificate : atom 5 11 5=true := by
  apply row_high (h:=25000) (A:=1100589) (S:=58590) (T:=600000) (R:=12) (B:=20) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery b1 b17)
end OMA.EightAt5E5P11

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt11E1P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b17 : every 17 32 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b33 : every 33 48 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b49 : every 49 64 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b65 : every 65 80 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b81 : every 81 96 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b97 : every 97 112 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b113 : every 113 128 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b129 : every 129 144 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b145 : every 145 160 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b161 : every 161 176 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b177 : every 177 192 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b193 : every 193 208 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b209 : every 209 224 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b225 : every 225 240 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b241 : every 241 256 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b257 : every 257 272 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b273 : every 273 288 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b289 : every 289 304 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b305 : every 305 320 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b321 : every 321 336 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b337 : every 337 352 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b353 : every 353 368 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b369 : every 369 384 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b385 : every 385 400 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b401 : every 401 416 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b417 : every 417 432 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b433 : every 433 448 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b449 : every 449 464 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b465 : every 465 480 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b481 : every 481 496 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b497 : every 497 512 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b513 : every 513 528 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b529 : every 529 544 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b545 : every 545 560 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b561 : every 561 576 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b577 : every 577 592 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b593 : every 593 608 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b609 : every 609 624 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b625 : every 625 640 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b641 : every 641 656 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b657 : every 657 672 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b673 : every 673 688 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b689 : every 689 704 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b705 : every 705 720 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b721 : every 721 736 (line 1127 180 704 5 12)=true := by decide +kernel
private theorem b737 : every 737 751 (line 1127 180 704 5 12)=true := by decide +kernel
theorem certificate : atom 11 5 1=true := by
  apply row_high (h:=88) (A:=1127) (S:=180) (T:=704) (R:=12) (B:=751) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65))) (joinEvery (joinEvery b81 (joinEvery b97 b113)) (joinEvery b129 (joinEvery b145 b161)))) (joinEvery (joinEvery (joinEvery b177 (joinEvery b193 b209)) (joinEvery b225 (joinEvery b241 b257))) (joinEvery (joinEvery b273 (joinEvery b289 b305)) (joinEvery b321 (joinEvery b337 b353))))) (joinEvery (joinEvery (joinEvery (joinEvery b369 (joinEvery b385 b401)) (joinEvery b417 (joinEvery b433 b449))) (joinEvery (joinEvery b465 (joinEvery b481 b497)) (joinEvery b513 (joinEvery b529 b545)))) (joinEvery (joinEvery (joinEvery b561 (joinEvery b577 b593)) (joinEvery b609 (joinEvery b625 b641))) (joinEvery (joinEvery b657 (joinEvery b673 b689)) (joinEvery b705 (joinEvery b721 b737))))))
end OMA.EightAt11E1P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt11E2P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 18914 1995 11616 5 12)=true := by decide +kernel
private theorem b17 : every 17 23 (line 18914 1995 11616 5 12)=true := by decide +kernel
theorem certificate : atom 11 5 2=true := by
  apply row_high (h:=968) (A:=18914) (S:=1995) (T:=11616) (R:=12) (B:=23) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery b1 b17)
end OMA.EightAt11E2P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt11E3P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 15 (line 279790 21960 170368 5 12)=true := by decide +kernel
theorem certificate : atom 11 5 3=true := by
  apply row_high (h:=10648) (A:=279790) (S:=21960) (T:=170368) (R:=12) (B:=15) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact b1
end OMA.EightAt11E3P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt11E4P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 13 (line 3866835 241575 2342560 5 12)=true := by decide +kernel
theorem certificate : atom 11 5 4=true := by
  apply row_high (h:=117128) (A:=3866835) (S:=241575) (T:=2342560) (R:=12) (B:=13) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact b1
end OMA.EightAt11E4P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt11E5P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 11 (line 51215829 2657340 30921792 5 12)=true := by decide +kernel
theorem certificate : atom 11 5 5=true := by
  apply row_high (h:=1288408) (A:=51215829) (S:=2657340) (T:=30921792) (R:=12) (B:=11) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact b1
end OMA.EightAt11E5P5

namespace OMA.EightMoving5x11
open OMA.CofactorEulerPair245212 OMA.RankThreeEightMoving245212 OMA.Smooth245212
open OMA.RankThreeMiddle245212 (joinEvery)
open scoped ArithmeticFunction.sigma
private theorem range5 : every 1 5 (atom 5 11)=true := (joinEvery (joinEvery (single (f:=atom 5 11) OMA.EightAt5E1P11.certificate) (single (f:=atom 5 11) OMA.EightAt5E2P11.certificate)) (joinEvery (single (f:=atom 5 11) OMA.EightAt5E3P11.certificate) (joinEvery (single (f:=atom 5 11) OMA.EightAt5E4P11.certificate) (single (f:=atom 5 11) OMA.EightAt5E5P11.certificate))))
private theorem range11 : every 1 5 (atom 11 5)=true := (joinEvery (joinEvery (single (f:=atom 11 5) OMA.EightAt11E1P5.certificate) (single (f:=atom 11 5) OMA.EightAt11E2P5.certificate)) (joinEvery (single (f:=atom 11 5) OMA.EightAt11E3P5.certificate) (joinEvery (single (f:=atom 11 5) OMA.EightAt11E4P5.certificate) (single (f:=atom 11 5) OMA.EightAt11E5P5.certificate))))
theorem exclude {r a b c : ℕ} (pr : r.Prime) (large : 11<r) (ap : 0<a) (bp : 0<b) (cp : 0<c) :
    OeisA245212.a (8*5^a*11^b*r^c)≠(σ 1 (8*5^a*11^b*r^c):ℤ) :=
  close (l:=6) (u:=6) (by decide) (by decide) pr (by decide) (by decide) large ap bp cp (by decide +kernel) range5 range11
#print axioms exclude
end OMA.EightMoving5x11
