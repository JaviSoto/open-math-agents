import RankThreeEightMoving245212
/-! Complete enumeration of both short prefixes for one moving-prime family. -/
/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E1P17
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
theorem certificate : atom 5 17 1=true := by
  apply row_low (h:=40) (A:=539) (S:=90) (T:=320) (R:=18) (Q:=9) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 9≤18+128)]
  exact (by decide +kernel)
end OMA.EightAt5E1P17

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E2P17
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
theorem certificate : atom 5 17 2=true := by
  apply row_low (h:=200) (A:=4214) (S:=465) (T:=2400) (R:=18) (Q:=14) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 14≤18+128)]
  exact (by decide +kernel)
end OMA.EightAt5E2P17

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E3P17
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b18 : every 18 21 (quick 1000 28714 2340 16000 17)=true := by decide +kernel
theorem certificate : atom 5 17 3=true := by
  apply row_low (h:=1000) (A:=28714) (S:=2340) (T:=16000) (R:=18) (Q:=21) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 21≤18+128)]
  exact b18
end OMA.EightAt5E3P17

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E4P17
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b18 : every 18 29 (quick 5000 181839 11715 100000 17)=true := by decide +kernel
theorem certificate : atom 5 17 4=true := by
  apply row_low (h:=5000) (A:=181839) (S:=11715) (T:=100000) (R:=18) (Q:=29) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 29≤18+128)]
  exact b18
end OMA.EightAt5E4P17

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E5P17
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b18 : every 18 33 (quick 25000 1100589 58590 600000 17)=true := by decide +kernel
private theorem b34 : every 34 39 (quick 25000 1100589 58590 600000 17)=true := by decide +kernel
theorem certificate : atom 5 17 5=true := by
  apply row_low (h:=25000) (A:=1100589) (S:=58590) (T:=600000) (R:=18) (Q:=39) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 39≤18+128)]
  exact (joinEvery b18 b34)
end OMA.EightAt5E5P17

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E6P17
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b18 : every 18 33 (quick 125000 6459964 292965 3500000 17)=true := by decide +kernel
private theorem b34 : every 34 49 (quick 125000 6459964 292965 3500000 17)=true := by decide +kernel
private theorem b50 : every 50 51 (quick 125000 6459964 292965 3500000 17)=true := by decide +kernel
theorem certificate : atom 5 17 6=true := by
  apply row_low (h:=125000) (A:=6459964) (S:=292965) (T:=3500000) (R:=18) (Q:=51) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 51≤18+128)]
  exact (joinEvery b18 (joinEvery b34 b50))
end OMA.EightAt5E6P17

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E7P17
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b18 : every 18 33 (quick 625000 37084964 1464840 20000000 17)=true := by decide +kernel
private theorem b34 : every 34 49 (quick 625000 37084964 1464840 20000000 17)=true := by decide +kernel
private theorem b50 : every 50 65 (quick 625000 37084964 1464840 20000000 17)=true := by decide +kernel
private theorem b66 : every 66 66 (quick 625000 37084964 1464840 20000000 17)=true := by decide +kernel
theorem certificate : atom 5 17 7=true := by
  apply row_low (h:=625000) (A:=37084964) (S:=1464840) (T:=20000000) (R:=18) (Q:=66) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 66≤18+128)]
  exact (joinEvery (joinEvery b18 b34) (joinEvery b50 b66))
end OMA.EightAt5E7P17

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E8P17
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b18 : every 18 33 (quick 3125000 209350589 7324215 112500000 17)=true := by decide +kernel
private theorem b34 : every 34 49 (quick 3125000 209350589 7324215 112500000 17)=true := by decide +kernel
private theorem b50 : every 50 65 (quick 3125000 209350589 7324215 112500000 17)=true := by decide +kernel
private theorem b66 : every 66 81 (quick 3125000 209350589 7324215 112500000 17)=true := by decide +kernel
private theorem b82 : every 82 87 (quick 3125000 209350589 7324215 112500000 17)=true := by decide +kernel
theorem certificate : atom 5 17 8=true := by
  apply row_low (h:=3125000) (A:=209350589) (S:=7324215) (T:=112500000) (R:=18) (Q:=87) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 87≤18+128)]
  exact (joinEvery (joinEvery b18 b34) (joinEvery b50 (joinEvery b66 b82)))
end OMA.EightAt5E8P17

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E9P17
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b18 : every 18 33 (quick 15625000 1166381839 36621090 625000000 17)=true := by decide +kernel
private theorem b34 : every 34 49 (quick 15625000 1166381839 36621090 625000000 17)=true := by decide +kernel
private theorem b50 : every 50 65 (quick 15625000 1166381839 36621090 625000000 17)=true := by decide +kernel
private theorem b66 : every 66 81 (quick 15625000 1166381839 36621090 625000000 17)=true := by decide +kernel
private theorem b82 : every 82 97 (quick 15625000 1166381839 36621090 625000000 17)=true := by decide +kernel
private theorem b98 : every 98 113 (quick 15625000 1166381839 36621090 625000000 17)=true := by decide +kernel
private theorem b114 : every 114 116 (quick 15625000 1166381839 36621090 625000000 17)=true := by decide +kernel
theorem certificate : atom 5 17 9=true := by
  apply row_low (h:=15625000) (A:=1166381839) (S:=36621090) (T:=625000000) (R:=18) (Q:=116) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 116≤18+128)]
  exact (joinEvery (joinEvery b18 (joinEvery b34 b50)) (joinEvery (joinEvery b66 b82) (joinEvery b98 b114)))
end OMA.EightAt5E9P17

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E10P17
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 6430053714 183105465 3437500000 17 18)=true := by decide +kernel
private theorem b17 : every 17 32 (line 6430053714 183105465 3437500000 17 18)=true := by decide +kernel
private theorem b33 : every 33 48 (line 6430053714 183105465 3437500000 17 18)=true := by decide +kernel
private theorem b49 : every 49 55 (line 6430053714 183105465 3437500000 17 18)=true := by decide +kernel
theorem certificate : atom 5 17 10=true := by
  apply row_low (h:=78125000) (A:=6430053714) (S:=183105465) (T:=3437500000) (R:=18) (Q:=159) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬159≤18+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 78125000 6430053714 183105465 17 159=55 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery b1 b17) (joinEvery b33 b49))⟩
end OMA.EightAt5E10P17

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E11P17
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 35140991214 915527340 18750000000 17 18)=true := by decide +kernel
private theorem b17 : every 17 32 (line 35140991214 915527340 18750000000 17 18)=true := by decide +kernel
private theorem b33 : every 33 48 (line 35140991214 915527340 18750000000 17 18)=true := by decide +kernel
private theorem b49 : every 49 59 (line 35140991214 915527340 18750000000 17 18)=true := by decide +kernel
theorem certificate : atom 5 17 11=true := by
  apply row_low (h:=390625000) (A:=35140991214) (S:=915527340) (T:=18750000000) (R:=18) (Q:=230) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬230≤18+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 390625000 35140991214 915527340 17 230=59 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery b1 b17) (joinEvery b33 b49))⟩
end OMA.EightAt5E11P17

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E12P17
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 190658569339 4577636715 101562500000 17 18)=true := by decide +kernel
private theorem b17 : every 17 32 (line 190658569339 4577636715 101562500000 17 18)=true := by decide +kernel
private theorem b33 : every 33 48 (line 190658569339 4577636715 101562500000 17 18)=true := by decide +kernel
private theorem b49 : every 49 64 (line 190658569339 4577636715 101562500000 17 18)=true := by decide +kernel
theorem certificate : atom 5 17 12=true := by
  apply row_low (h:=1953125000) (A:=190658569339) (S:=4577636715) (T:=101562500000) (R:=18) (Q:=369) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬369≤18+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 1953125000 190658569339 4577636715 17 369=64 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery b1 b17) (joinEvery b33 b49))⟩
end OMA.EightAt5E12P17

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E13P17
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 1028060913089 22888183590 546875000000 17 18)=true := by decide +kernel
private theorem b17 : every 17 32 (line 1028060913089 22888183590 546875000000 17 18)=true := by decide +kernel
private theorem b33 : every 33 48 (line 1028060913089 22888183590 546875000000 17 18)=true := by decide +kernel
private theorem b49 : every 49 64 (line 1028060913089 22888183590 546875000000 17 18)=true := by decide +kernel
private theorem b65 : every 65 67 (line 1028060913089 22888183590 546875000000 17 18)=true := by decide +kernel
theorem certificate : atom 5 17 13=true := by
  apply row_low (h:=9765625000) (A:=1028060913089) (S:=22888183590) (T:=546875000000) (R:=18) (Q:=762) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬762≤18+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 9765625000 1028060913089 22888183590 17 762=67 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65)))⟩
end OMA.EightAt5E13P17

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E14P17
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 5514144897464 114440917965 2929687500000 17 18)=true := by decide +kernel
private theorem b17 : every 17 32 (line 5514144897464 114440917965 2929687500000 17 18)=true := by decide +kernel
private theorem b33 : every 33 48 (line 5514144897464 114440917965 2929687500000 17 18)=true := by decide +kernel
private theorem b49 : every 49 64 (line 5514144897464 114440917965 2929687500000 17 18)=true := by decide +kernel
private theorem b65 : every 65 80 (line 5514144897464 114440917965 2929687500000 17 18)=true := by decide +kernel
private theorem b81 : every 81 89 (line 5514144897464 114440917965 2929687500000 17 18)=true := by decide +kernel
theorem certificate : atom 5 17 14=true := by
  apply row_low (h:=48828125000) (A:=5514144897464) (S:=114440917965) (T:=2929687500000) (R:=18) (Q:=9830) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬9830≤18+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 48828125000 5514144897464 114440917965 17 9830=89 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81)))⟩
end OMA.EightAt5E14P17

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E15P17
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 29439926147464 572204589840 15625000000000 17 18)=true := by decide +kernel
private theorem b17 : every 17 32 (line 29439926147464 572204589840 15625000000000 17 18)=true := by decide +kernel
private theorem b33 : every 33 48 (line 29439926147464 572204589840 15625000000000 17 18)=true := by decide +kernel
private theorem b49 : every 49 64 (line 29439926147464 572204589840 15625000000000 17 18)=true := by decide +kernel
private theorem b65 : every 65 80 (line 29439926147464 572204589840 15625000000000 17 18)=true := by decide +kernel
private theorem b81 : every 81 96 (line 29439926147464 572204589840 15625000000000 17 18)=true := by decide +kernel
private theorem b97 : every 97 112 (line 29439926147464 572204589840 15625000000000 17 18)=true := by decide +kernel
private theorem b113 : every 113 122 (line 29439926147464 572204589840 15625000000000 17 18)=true := by decide +kernel
theorem certificate : atom 5 17 15=true := by
  apply row_high (h:=244140625000) (A:=29439926147464) (S:=572204589840) (T:=15625000000000) (R:=18) (B:=122) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 b49)) (joinEvery (joinEvery b65 b81) (joinEvery b97 b113)))
end OMA.EightAt5E15P17

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E16P17
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 156545639038089 2861022949215 83007812500000 17 18)=true := by decide +kernel
private theorem b17 : every 17 32 (line 156545639038089 2861022949215 83007812500000 17 18)=true := by decide +kernel
private theorem b33 : every 33 48 (line 156545639038089 2861022949215 83007812500000 17 18)=true := by decide +kernel
private theorem b49 : every 49 62 (line 156545639038089 2861022949215 83007812500000 17 18)=true := by decide +kernel
theorem certificate : atom 5 17 16=true := by
  apply row_high (h:=1220703125000) (A:=156545639038089) (S:=2861022949215) (T:=83007812500000) (R:=18) (B:=62) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 b17) (joinEvery b33 b49))
end OMA.EightAt5E16P17

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E17P17
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 829458236694339 14305114746090 439453125000000 17 18)=true := by decide +kernel
private theorem b17 : every 17 32 (line 829458236694339 14305114746090 439453125000000 17 18)=true := by decide +kernel
private theorem b33 : every 33 43 (line 829458236694339 14305114746090 439453125000000 17 18)=true := by decide +kernel
theorem certificate : atom 5 17 17=true := by
  apply row_high (h:=6103515625000) (A:=829458236694339) (S:=14305114746090) (T:=439453125000000) (R:=18) (B:=43) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery b1 (joinEvery b17 b33))
end OMA.EightAt5E17P17

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt17E1P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b18 : every 18 33 (quick 136 1715 270 1088 5)=true := by decide +kernel
private theorem b34 : every 34 49 (quick 136 1715 270 1088 5)=true := by decide +kernel
private theorem b50 : every 50 65 (quick 136 1715 270 1088 5)=true := by decide +kernel
private theorem b66 : every 66 67 (quick 136 1715 270 1088 5)=true := by decide +kernel
theorem certificate : atom 17 5 1=true := by
  apply row_low (h:=136) (A:=1715) (S:=270) (T:=1088) (R:=18) (Q:=67) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 67≤18+128)]
  exact (joinEvery (joinEvery b18 b34) (joinEvery b50 b66))
end OMA.EightAt17E1P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt17E2P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 44198 4605 27744 5 18)=true := by decide +kernel
private theorem b17 : every 17 32 (line 44198 4605 27744 5 18)=true := by decide +kernel
private theorem b33 : every 33 48 (line 44198 4605 27744 5 18)=true := by decide +kernel
private theorem b49 : every 49 64 (line 44198 4605 27744 5 18)=true := by decide +kernel
private theorem b65 : every 65 80 (line 44198 4605 27744 5 18)=true := by decide +kernel
private theorem b81 : every 81 96 (line 44198 4605 27744 5 18)=true := by decide +kernel
private theorem b97 : every 97 112 (line 44198 4605 27744 5 18)=true := by decide +kernel
private theorem b113 : every 113 115 (line 44198 4605 27744 5 18)=true := by decide +kernel
theorem certificate : atom 17 5 2=true := by
  apply row_low (h:=2312) (A:=44198) (S:=4605) (T:=27744) (R:=18) (Q:=230) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬230≤18+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 2312 44198 4605 5 230=115 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 b49)) (joinEvery (joinEvery b65 b81) (joinEvery b97 b113)))⟩
end OMA.EightAt17E2P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt17E3P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b17 : every 17 32 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b33 : every 33 48 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b49 : every 49 64 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b65 : every 65 80 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b81 : every 81 96 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b97 : every 97 112 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b113 : every 113 128 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b129 : every 129 144 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b145 : every 145 160 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b161 : every 161 176 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b177 : every 177 192 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b193 : every 193 208 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b209 : every 209 224 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b225 : every 225 240 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b241 : every 241 256 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b257 : every 257 272 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b273 : every 273 288 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b289 : every 289 304 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b305 : every 305 320 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b321 : every 321 336 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b337 : every 337 352 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b353 : every 353 368 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b369 : every 369 384 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b385 : every 385 400 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b401 : every 401 416 (line 1007146 78300 628864 5 18)=true := by decide +kernel
private theorem b417 : every 417 418 (line 1007146 78300 628864 5 18)=true := by decide +kernel
theorem certificate : atom 17 5 3=true := by
  apply row_high (h:=39304) (A:=1007146) (S:=78300) (T:=628864) (R:=18) (B:=418) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery (joinEvery b145 b161) (joinEvery b177 b193)))) (joinEvery (joinEvery (joinEvery b209 (joinEvery b225 b241)) (joinEvery (joinEvery b257 b273) (joinEvery b289 b305))) (joinEvery (joinEvery b321 (joinEvery b337 b353)) (joinEvery (joinEvery b369 b385) (joinEvery b401 b417)))))
end OMA.EightAt17E3P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt17E4P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 21469791 1331115 13363360 5 18)=true := by decide +kernel
private theorem b17 : every 17 32 (line 21469791 1331115 13363360 5 18)=true := by decide +kernel
private theorem b33 : every 33 48 (line 21469791 1331115 13363360 5 18)=true := by decide +kernel
private theorem b49 : every 49 64 (line 21469791 1331115 13363360 5 18)=true := by decide +kernel
private theorem b65 : every 65 80 (line 21469791 1331115 13363360 5 18)=true := by decide +kernel
private theorem b81 : every 81 96 (line 21469791 1331115 13363360 5 18)=true := by decide +kernel
private theorem b97 : every 97 97 (line 21469791 1331115 13363360 5 18)=true := by decide +kernel
theorem certificate : atom 17 5 4=true := by
  apply row_high (h:=668168) (A:=21469791) (S:=1331115) (T:=13363360) (R:=18) (B:=97) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97)))
end OMA.EightAt17E4P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt17E5P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 438907749 22628970 272612544 5 18)=true := by decide +kernel
private theorem b17 : every 17 32 (line 438907749 22628970 272612544 5 18)=true := by decide +kernel
private theorem b33 : every 33 48 (line 438907749 22628970 272612544 5 18)=true := by decide +kernel
private theorem b49 : every 49 64 (line 438907749 22628970 272612544 5 18)=true := by decide +kernel
theorem certificate : atom 17 5 5=true := by
  apply row_high (h:=11358856) (A:=438907749) (S:=22628970) (T:=272612544) (R:=18) (B:=64) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 b17) (joinEvery b33 b49))
end OMA.EightAt17E5P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt17E6P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 8718093916 384692505 5406815456 5 18)=true := by decide +kernel
private theorem b17 : every 17 32 (line 8718093916 384692505 5406815456 5 18)=true := by decide +kernel
private theorem b33 : every 33 48 (line 8718093916 384692505 5406815456 5 18)=true := by decide +kernel
private theorem b49 : every 49 51 (line 8718093916 384692505 5406815456 5 18)=true := by decide +kernel
theorem certificate : atom 17 5 6=true := by
  apply row_high (h:=193100552) (A:=8718093916) (S:=384692505) (T:=5406815456) (R:=18) (B:=51) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 b17) (joinEvery b33 b49))
end OMA.EightAt17E6P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt17E7P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 169570853732 6539772600 105046700288 5 18)=true := by decide +kernel
private theorem b17 : every 17 32 (line 169570853732 6539772600 105046700288 5 18)=true := by decide +kernel
private theorem b33 : every 33 45 (line 169570853732 6539772600 105046700288 5 18)=true := by decide +kernel
theorem certificate : atom 17 5 7=true := by
  apply row_high (h:=3282709384) (A:=169570853732) (S:=6539772600) (T:=105046700288) (R:=18) (B:=45) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery b1 (joinEvery b17 b33))
end OMA.EightAt17E7P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt17E8P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 3245879885213 111176134215 2009018143008 5 18)=true := by decide +kernel
private theorem b17 : every 17 32 (line 3245879885213 111176134215 2009018143008 5 18)=true := by decide +kernel
private theorem b33 : every 33 41 (line 3245879885213 111176134215 2009018143008 5 18)=true := by decide +kernel
theorem certificate : atom 17 5 8=true := by
  apply row_high (h:=55806059528) (A:=3245879885213) (S:=111176134215) (T:=2009018143008) (R:=18) (B:=41) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery b1 (joinEvery b17 b33))
end OMA.EightAt17E8P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt17E9P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 61353939368743 1889994281670 37948120479040 5 18)=true := by decide +kernel
private theorem b17 : every 17 32 (line 61353939368743 1889994281670 37948120479040 5 18)=true := by decide +kernel
private theorem b33 : every 33 38 (line 61353939368743 1889994281670 37948120479040 5 18)=true := by decide +kernel
theorem certificate : atom 17 5 9=true := by
  apply row_high (h:=948703011976) (A:=61353939368743) (S:=1889994281670) (T:=37948120479040) (R:=18) (B:=38) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery b1 (joinEvery b17 b33))
end OMA.EightAt17E9P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt17E10P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 1147974651710754 32129902788405 709629852958048 5 18)=true := by decide +kernel
private theorem b17 : every 17 32 (line 1147974651710754 32129902788405 709629852958048 5 18)=true := by decide +kernel
private theorem b33 : every 33 36 (line 1147974651710754 32129902788405 709629852958048 5 18)=true := by decide +kernel
theorem certificate : atom 17 5 10=true := by
  apply row_high (h:=16127951203592) (A:=1147974651710754) (S:=32129902788405) (T:=709629852958048) (R:=18) (B:=36) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery b1 (joinEvery b17 b33))
end OMA.EightAt17E10P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt17E11P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 21299849680598958 546208347402900 13160408182131072 5 18)=true := by decide +kernel
private theorem b17 : every 17 32 (line 21299849680598958 546208347402900 13160408182131072 5 18)=true := by decide +kernel
private theorem b33 : every 33 35 (line 21299849680598958 546208347402900 13160408182131072 5 18)=true := by decide +kernel
theorem certificate : atom 17 5 11=true := by
  apply row_high (h:=274175170461064) (A:=21299849680598958) (S:=546208347402900) (T:=13160408182131072) (R:=18) (B:=35) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery b1 (joinEvery b17 b33))
end OMA.EightAt17E11P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt17E12P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 392430214795956715 9285541905849315 242370850687580576 5 18)=true := by decide +kernel
private theorem b17 : every 17 32 (line 392430214795956715 9285541905849315 242370850687580576 5 18)=true := by decide +kernel
private theorem b33 : every 33 33 (line 392430214795956715 9285541905849315 242370850687580576 5 18)=true := by decide +kernel
theorem certificate : atom 17 5 12=true := by
  apply row_high (h:=4660977897838088) (A:=392430214795956715) (S:=9285541905849315) (T:=242370850687580576) (R:=18) (B:=33) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery b1 (joinEvery b17 b33))
end OMA.EightAt17E12P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt17E13P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 7186970745369429497 157854212399438370 4437250958741859776 5 18)=true := by decide +kernel
private theorem b17 : every 17 32 (line 7186970745369429497 157854212399438370 4437250958741859776 5 18)=true := by decide +kernel
theorem certificate : atom 17 5 13=true := by
  apply row_high (h:=79236624263247496) (A:=7186970745369429497) (S:=157854212399438370) (T:=4437250958741859776) (R:=18) (B:=32) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery b1 b17)
end OMA.EightAt17E13P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt17E14P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 130944673266529112312 2683521610790452305 80821356748512445920 5 18)=true := by decide +kernel
private theorem b17 : every 17 32 (line 130944673266529112312 2683521610790452305 80821356748512445920 5 18)=true := by decide +kernel
theorem certificate : atom 17 5 14=true := by
  apply row_high (h:=1347022612475207432) (A:=130944673266529112312) (S:=2683521610790452305) (T:=80821356748512445920) (R:=18) (B:=32) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery b1 b17)
end OMA.EightAt17E14P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt17E15P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 2375084345650224694024 45619867383437689200 1465560602373025686016 5 18)=true := by decide +kernel
private theorem b17 : every 17 31 (line 2375084345650224694024 45619867383437689200 1465560602373025686016 5 18)=true := by decide +kernel
theorem certificate : atom 17 5 15=true := by
  apply row_high (h:=22899384412078526344) (A:=2375084345650224694024) (S:=45619867383437689200) (T:=1465560602373025686016) (R:=18) (B:=31) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery b1 b17)
end OMA.EightAt17E15P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt17E16P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 42909857178080726138697 775537745518440716415 26471688380362776453664 5 18)=true := by decide +kernel
private theorem b17 : every 17 30 (line 42909857178080726138697 775537745518440716415 26471688380362776453664 5 18)=true := by decide +kernel
theorem certificate : atom 17 5 16=true := by
  apply row_high (h:=389289535005334947848) (A:=42909857178080726138697) (S:=775537745518440716415) (T:=26471688380362776453664) (R:=18) (B:=30) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery b1 b17)
end OMA.EightAt17E16P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt17E17P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 772535768161829752142811 13184141673813492179070 476490390846529976165952 5 18)=true := by decide +kernel
private theorem b17 : every 17 30 (line 772535768161829752142811 13184141673813492179070 476490390846529976165952 5 18)=true := by decide +kernel
theorem certificate : atom 17 5 17=true := by
  apply row_high (h:=6617922095090694113416) (A:=772535768161829752142811) (S:=13184141673813492179070) (T:=476490390846529976165952) (R:=18) (B:=30) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery b1 b17)
end OMA.EightAt17E17P5

namespace OMA.EightMoving5x17
open OMA.CofactorEulerPair245212 OMA.RankThreeEightMoving245212 OMA.Smooth245212
open OMA.RankThreeMiddle245212 (joinEvery)
open scoped ArithmeticFunction.sigma
private theorem range5 : every 1 17 (atom 5 17)=true := (joinEvery (joinEvery (joinEvery (joinEvery (single (f:=atom 5 17) OMA.EightAt5E1P17.certificate) (single (f:=atom 5 17) OMA.EightAt5E2P17.certificate)) (joinEvery (single (f:=atom 5 17) OMA.EightAt5E3P17.certificate) (single (f:=atom 5 17) OMA.EightAt5E4P17.certificate))) (joinEvery (joinEvery (single (f:=atom 5 17) OMA.EightAt5E5P17.certificate) (single (f:=atom 5 17) OMA.EightAt5E6P17.certificate)) (joinEvery (single (f:=atom 5 17) OMA.EightAt5E7P17.certificate) (single (f:=atom 5 17) OMA.EightAt5E8P17.certificate)))) (joinEvery (joinEvery (joinEvery (single (f:=atom 5 17) OMA.EightAt5E9P17.certificate) (single (f:=atom 5 17) OMA.EightAt5E10P17.certificate)) (joinEvery (single (f:=atom 5 17) OMA.EightAt5E11P17.certificate) (single (f:=atom 5 17) OMA.EightAt5E12P17.certificate))) (joinEvery (joinEvery (single (f:=atom 5 17) OMA.EightAt5E13P17.certificate) (single (f:=atom 5 17) OMA.EightAt5E14P17.certificate)) (joinEvery (single (f:=atom 5 17) OMA.EightAt5E15P17.certificate) (joinEvery (single (f:=atom 5 17) OMA.EightAt5E16P17.certificate) (single (f:=atom 5 17) OMA.EightAt5E17P17.certificate))))))
private theorem range17 : every 1 17 (atom 17 5)=true := (joinEvery (joinEvery (joinEvery (joinEvery (single (f:=atom 17 5) OMA.EightAt17E1P5.certificate) (single (f:=atom 17 5) OMA.EightAt17E2P5.certificate)) (joinEvery (single (f:=atom 17 5) OMA.EightAt17E3P5.certificate) (single (f:=atom 17 5) OMA.EightAt17E4P5.certificate))) (joinEvery (joinEvery (single (f:=atom 17 5) OMA.EightAt17E5P5.certificate) (single (f:=atom 17 5) OMA.EightAt17E6P5.certificate)) (joinEvery (single (f:=atom 17 5) OMA.EightAt17E7P5.certificate) (single (f:=atom 17 5) OMA.EightAt17E8P5.certificate)))) (joinEvery (joinEvery (joinEvery (single (f:=atom 17 5) OMA.EightAt17E9P5.certificate) (single (f:=atom 17 5) OMA.EightAt17E10P5.certificate)) (joinEvery (single (f:=atom 17 5) OMA.EightAt17E11P5.certificate) (single (f:=atom 17 5) OMA.EightAt17E12P5.certificate))) (joinEvery (joinEvery (single (f:=atom 17 5) OMA.EightAt17E13P5.certificate) (single (f:=atom 17 5) OMA.EightAt17E14P5.certificate)) (joinEvery (single (f:=atom 17 5) OMA.EightAt17E15P5.certificate) (joinEvery (single (f:=atom 17 5) OMA.EightAt17E16P5.certificate) (single (f:=atom 17 5) OMA.EightAt17E17P5.certificate))))))
theorem exclude {r a b c : ℕ} (pr : r.Prime) (large : 17<r) (ap : 0<a) (bp : 0<b) (cp : 0<c) :
    OeisA245212.a (8*5^a*17^b*r^c)≠(σ 1 (8*5^a*17^b*r^c):ℤ) :=
  close (l:=18) (u:=18) (by decide) (by decide) pr (by decide) (by decide) large ap bp cp (by decide +kernel) range5 range17
#print axioms exclude
end OMA.EightMoving5x17
