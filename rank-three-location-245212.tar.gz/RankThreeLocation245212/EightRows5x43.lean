import RankThreeEightFixed245212
/-! Kernel certificates for one ordered pair of odd bases at dyadic factor eight. -/
namespace OMA.EightRows5x43
open OMA.RankThreeEightFixed245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
theorem row47 : tests 5 43 47=true := by decide +kernel
end OMA.EightRows5x43
