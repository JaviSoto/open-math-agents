import RankThreeFiveCount245212
/-! Finite first-prime intervals; both prime powers remain unrestricted. -/
namespace OMA.RankThreeFiveRows245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFiveTail245212
open OMA.RankThreeMiddle245212 (joinEvery)
open scoped ArithmeticFunction.sigma
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem block7_1_7 : every 7 10 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_11 : every 11 14 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_15 : every 15 18 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_19 : every 19 22 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_23 : every 23 26 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_27 : every 27 30 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_31 : every 31 34 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_35 : every 35 38 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_39 : every 39 42 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_43 : every 43 46 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_47 : every 47 50 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_51 : every 51 54 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_55 : every 55 58 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_59 : every 59 62 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_63 : every 63 66 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_67 : every 67 70 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_71 : every 71 74 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_75 : every 75 78 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_79 : every 79 82 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_83 : every 83 86 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_87 : every 87 90 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_91 : every 91 94 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_95 : every 95 98 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_99 : every 99 102 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_103 : every 103 106 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
private theorem block7_1_107 : every 107 109 (OMA.RankThreeFiveCount245212.row 640 19723 1530 10240)=true := by decide +kernel
theorem c7_1 : every 7 (OMA.RankThreeFourSmallHarmonic245212.primeCut (wt 7 1) (sg 7 1) (2*ta 7 1)) (OMA.RankThreeFiveCount245212.test 7 1)=true := (joinEvery (joinEvery (joinEvery (joinEvery block7_1_7 (joinEvery block7_1_11 block7_1_15)) (joinEvery block7_1_19 (joinEvery block7_1_23 block7_1_27))) (joinEvery (joinEvery block7_1_31 (joinEvery block7_1_35 block7_1_39)) (joinEvery (joinEvery block7_1_43 block7_1_47) (joinEvery block7_1_51 block7_1_55)))) (joinEvery (joinEvery (joinEvery block7_1_59 (joinEvery block7_1_63 block7_1_67)) (joinEvery block7_1_71 (joinEvery block7_1_75 block7_1_79))) (joinEvery (joinEvery block7_1_83 (joinEvery block7_1_87 block7_1_91)) (joinEvery (joinEvery block7_1_95 block7_1_99) (joinEvery block7_1_103 block7_1_107)))))
end OMA.RankThreeFiveRows245212
