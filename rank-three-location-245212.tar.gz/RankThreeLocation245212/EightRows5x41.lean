import RankThreeEightFixed245212
/-! Kernel certificates for one ordered pair of odd bases at dyadic factor eight. -/
namespace OMA.EightRows5x41
open OMA.RankThreeEightFixed245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
theorem row43 : tests 5 41 43=true := by decide +kernel
theorem row47 : tests 5 41 47=true := by decide +kernel
end OMA.EightRows5x41
