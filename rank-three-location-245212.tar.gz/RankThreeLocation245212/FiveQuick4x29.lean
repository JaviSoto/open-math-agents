import FiveQuick4x29S7
import FiveQuick4x29S151
import FiveQuick4x29S295
import FiveQuick4x29S439
import FiveQuick4x29S583
import FiveQuick4x29S727
import FiveQuick4x29S871
import FiveQuick4x29S1015
import FiveQuick4x29S1159
import FiveQuick4x29S1303
import FiveQuick4x29S1447
import FiveQuick4x29S1591
import FiveQuick4x29S1735
import FiveQuick4x29S1879
import FiveQuick4x29S2023
import FiveQuick4x29S2167
import FiveQuick4x29S2311
import FiveQuick4x29S2455
import FiveQuick4x29S2599
import FiveQuick4x29S2743
import FiveQuick4x29S2887
import FiveQuick4x29S3031
import FiveQuick4x29S3175
import FiveQuick4x29S3319
import FiveQuick4x29S3463
import FiveQuick4x29S3607
import FiveQuick4x29S3751
import FiveQuick4x29S3895
import FiveQuick4x29S4039
import FiveQuick4x29S4183
import FiveQuick4x29S4327
import FiveQuick4x29S4471
import FiveQuick4x29S4615
import FiveQuick4x29S4759
import FiveQuick4x29S4903
import FiveQuick4x29S5047
import FiveQuick4x29S5191
import FiveQuick4x29S5335
import FiveQuick4x29S5479
import FiveQuick4x29S5623
import FiveQuick4x29S5767
import FiveQuick4x29S5911
import FiveQuick4x29S6055
import FiveQuick4x29S6199
import FiveQuick4x29S6343
import FiveQuick4x29S6487
import FiveQuick4x29S6631
import FiveQuick4x29S6775
import FiveQuick4x29Far
import FiveFastNear245212
namespace OMA.FiveQuick4x29
open OMA.CofactorEulerPair245212 OMA.FiveFastNear245212
open OMA.RankThreeFiveTail245212 (cofactor wt sg ta)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 0
theorem original {p q b c : ℕ} (pp : p.Prime) (qp : q.Prime) (gt : 5<p) (pq : p<q) (bp : 0<b) (cp : 0<c) :
    OeisA245212.a (2^4*5^29*p^b*q^c)≠(ArithmeticFunction.sigma 1 (2^4*5^29*p^b*q^c):ℤ) :=
  OMA.RankThreeFiveShort245212.final (lo:=6827) pp qp gt pq bp cp (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery span7 (joinEvery span151 span295)) (joinEvery span439 (joinEvery span583 span727))) (joinEvery (joinEvery span871 (joinEvery span1015 span1159)) (joinEvery span1303 (joinEvery span1447 span1591)))) (joinEvery (joinEvery (joinEvery span1735 (joinEvery span1879 span2023)) (joinEvery span2167 (joinEvery span2311 span2455))) (joinEvery (joinEvery span2599 (joinEvery span2743 span2887)) (joinEvery span3031 (joinEvery span3175 span3319))))) (joinEvery (joinEvery (joinEvery (joinEvery span3463 (joinEvery span3607 span3751)) (joinEvery span3895 (joinEvery span4039 span4183))) (joinEvery (joinEvery span4327 (joinEvery span4471 span4615)) (joinEvery span4759 (joinEvery span4903 span5047)))) (joinEvery (joinEvery (joinEvery span5191 (joinEvery span5335 span5479)) (joinEvery span5623 (joinEvery span5767 span5911))) (joinEvery (joinEvery span6055 (joinEvery span6199 span6343)) (joinEvery span6487 (joinEvery span6631 span6775)))))) (by decide +kernel) OMA.FiveFar4x29.scan
#print axioms original
end OMA.FiveQuick4x29
