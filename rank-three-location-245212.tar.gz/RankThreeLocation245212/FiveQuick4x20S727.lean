import FiveFastNear245212
namespace OMA.FiveQuick4x20
open OMA.CofactorEulerPair245212 OMA.FiveFastNear245212
open OMA.RankThreeFiveTail245212 (cofactor wt sg ta)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 0
theorem span727 : every 727 816 (OMA.RankThreeFiveShort245212.test 4 20)=true :=
  interval (m:=21) (by decide +kernel) (show every 727 816 (fast 1525878906250000 319093465805053719 3695487976074211 160217285156250000 21)=true by decide +kernel)
end OMA.FiveQuick4x20
