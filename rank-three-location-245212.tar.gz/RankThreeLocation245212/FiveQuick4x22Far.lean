import RankThreeFiveFar245212
/-! Check the terminal divisor counts above the middle-prime cutoff. -/
namespace OMA.FiveFar4x22
open OMA.RankThreeFiveFar245212 OMA.CofactorEulerPair245212
open OMA.RankThreeMiddle245212 (joinEvery)
open OMA.RankThreeEightMoving245212 (single)
set_option maxHeartbeats 2400000
set_option maxRecDepth 65536
private theorem local4_2 : every 2 2 (splitPair 8746236562728881844 92387199401855461 4386901855468750000 1274 4)=true := by decide +kernel
private theorem n4 : every 4 4 (bucket 8746236562728881844 92387199401855461 4386901855468750000 1274)=true := single local4_2
private theorem local5_2 : every 2 2 (splitPair 8746236562728881844 92387199401855461 4386901855468750000 1274 5)=true := by decide +kernel
private theorem n5 : every 5 5 (bucket 8746236562728881844 92387199401855461 4386901855468750000 1274)=true := single local5_2
private theorem p6_2_1274 : every 1274 1401 (fixed 8746236562728881844 92387199401855461 4386901855468750000 2 3)=true := by decide +kernel
private theorem p6_2_1402 : every 1402 1441 (fixed 8746236562728881844 92387199401855461 4386901855468750000 2 3)=true := by decide +kernel
private theorem x6_2 : every 2 2 (splitPair 8746236562728881844 92387199401855461 4386901855468750000 1274 6)=true := single (by_scan (joinEvery p6_2_1274 p6_2_1402))
private theorem p6_3_1274 : every 1274 1401 (fixed 8746236562728881844 92387199401855461 4386901855468750000 3 2)=true := by decide +kernel
private theorem p6_3_1402 : every 1402 1441 (fixed 8746236562728881844 92387199401855461 4386901855468750000 3 2)=true := by decide +kernel
private theorem x6_3 : every 3 3 (splitPair 8746236562728881844 92387199401855461 4386901855468750000 1274 6)=true := single (by_scan (joinEvery p6_3_1274 p6_3_1402))
private theorem n6 : every 6 6 (bucket 8746236562728881844 92387199401855461 4386901855468750000 1274)=true := single (joinEvery x6_2 x6_3)
theorem scan : every 4 6 (bucket 8746236562728881844 92387199401855461 4386901855468750000 1274)=true := (joinEvery n4 (joinEvery n5 n6))
end OMA.FiveFar4x22
