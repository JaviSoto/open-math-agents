import RankThreeFiveResidue245212
/-! Middle-prime limit from local obstructions to short divisor counts. -/
namespace OMA.FiveLocal4x23
open OMA.RankThreeFiveResidue245212 OMA.CofactorEulerPair245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem n4 : every 4 4 (fun n=>!(survives 45653432607650756844 461935997009277336 45776367187500000000 n))=true := by decide +kernel
private theorem n5 : every 5 5 (fun n=>!(survives 45653432607650756844 461935997009277336 45776367187500000000 n))=true := by decide +kernel
private theorem n6 : every 6 6 (fun n=>!(survives 45653432607650756844 461935997009277336 45776367187500000000 n))=true := by decide +kernel
private theorem n7 : every 7 7 (fun n=>!(survives 45653432607650756844 461935997009277336 45776367187500000000 n))=true := by decide +kernel
private theorem n8 : every 8 8 (fun n=>!(survives 45653432607650756844 461935997009277336 45776367187500000000 n))=true := by decide +kernel
private theorem n9 : every 9 9 (fun n=>!(survives 45653432607650756844 461935997009277336 45776367187500000000 n))=true := by decide +kernel
private theorem n10 : every 10 10 (fun n=>!(survives 45653432607650756844 461935997009277336 45776367187500000000 n))=true := by decide +kernel
private theorem n11 : every 11 11 (fun n=>!(survives 45653432607650756844 461935997009277336 45776367187500000000 n))=true := by decide +kernel
private theorem n12 : every 12 12 (fun n=>!(survives 45653432607650756844 461935997009277336 45776367187500000000 n))=true := by decide +kernel
private theorem n13 : every 13 13 (fun n=>!(survives 45653432607650756844 461935997009277336 45776367187500000000 n))=true := by decide +kernel
private theorem n14 : every 14 14 (fun n=>!(survives 45653432607650756844 461935997009277336 45776367187500000000 n))=true := by decide +kernel
theorem clear : every 4 14 (fun n=>!(survives 45653432607650756844 461935997009277336 45776367187500000000 n))=true := (joinEvery (joinEvery (joinEvery n4 n5) (joinEvery n6 (joinEvery n7 n8))) (joinEvery (joinEvery n9 (joinEvery n10 n11)) (joinEvery n12 (joinEvery n13 n14))))
end OMA.FiveLocal4x23
