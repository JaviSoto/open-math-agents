import FiveFastNear245212
namespace OMA.FiveQuick4x21
open OMA.CofactorEulerPair245212 OMA.FiveFastNear245212
open OMA.RankThreeFiveTail245212 (cofactor wt sg ta)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 0
theorem span277 : every 277 366 (OMA.RankThreeFiveShort245212.test 4 21)=true :=
  interval (m:=22) (by decide +kernel) (show every 277 366 (fast 7629394531250000 1672357320785522469 18477439880371086 839233398437500000 22)=true by decide +kernel)
end OMA.FiveQuick4x21
