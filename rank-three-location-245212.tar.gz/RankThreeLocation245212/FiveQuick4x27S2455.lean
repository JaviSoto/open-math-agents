import FiveFastNear245212
namespace OMA.FiveQuick4x27
open OMA.CofactorEulerPair245212 OMA.FiveFastNear245212
open OMA.RankThreeFiveTail245212 (cofactor wt sg ta)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 0
theorem span2455 : every 2455 2598 (OMA.RankThreeFiveShort245212.test 4 27)=true :=
  interval (m:=28) (by decide +kernel) (show every 2455 2598 (fast 119209289550781250000 33339019864797592163094 288709998130798339836 16689300537109375000000 28)=true by decide +kernel)
end OMA.FiveQuick4x27
