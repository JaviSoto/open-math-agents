import BoxKernel245212

/-! Integer fixed-point bounds for prime-power moments. All evaluated box
operations below are on Nat, with normalization reserved for the proof. -/
namespace OMA.FastFactor245212
open OMA.Box245212 OMA.Smooth245212 OMA.Moving245212 Finset

def scale : ℕ := 2^256
def smallQuot (p e : ℕ) :=
  let h := p^min (e+1) 32
  (scale*p*(h-1))/((p-1)*(e+1)*h)
def lowY (pb eb : Range) := smallQuot pb.hi eb.hi
def highY (pb eb : Range) :=
  let p := pb.lo
  let e := eb.lo
  min scale ((if e<32 then smallQuot p e else scale*p/((p-1)*(e+1)))+1)
def lowX (pb eb : Range) := scale+(scale-highY pb eb)/(pb.hi-1)
def highX (pb eb : Range) := scale+(scale-lowY pb eb)/(pb.lo-1)+1

theorem scale_pos : 0<scale := pow_pos (by decide) _
private theorem frac_lo (n d : ℕ) (pos : 0<d) : ((n/d:ℕ):ℚ)≤(n:ℚ)/d := by
  apply (le_div_iff₀ (by exact_mod_cast pos)).mpr
  exact_mod_cast Nat.div_mul_le_self n d
private theorem frac_hi (n d : ℕ) (pos : 0<d) : (n:ℚ)/d≤((n/d+1:ℕ):ℚ) := by
  apply (div_le_iff₀ (by exact_mod_cast pos)).mpr
  exact_mod_cast (Nat.lt_mul_div_succ n pos).le.trans_eq (Nat.mul_comm _ _)

private theorem true_form {p : ℕ} (hp : 1<p) (e : ℕ) :
    Y p (some e)=(p:ℚ)/(((p:ℚ)-1)*(e+1))*(1-(p:ℚ)⁻¹^(e+1)) := by
  have pp : (1:ℚ)<p := by exact_mod_cast hp
  simp only [Y]
  rw [show (p:ℚ)⁻¹-1=(1-p)/p by field_simp]
  generalize (p:ℚ)⁻¹^(e+1) = z
  field_simp [show 1-(p:ℚ)≠0 by linarith, show (p:ℚ)-1≠0 by linarith]; ring

private theorem raw_form {p : ℕ} (hp : 1<p) (e : ℕ) :
    let h := p^min (e+1) 32
    ((scale*p*(h-1):ℕ):ℚ)/((p-1)*(e+1)*h:ℕ) =
       (scale:ℚ)*approx false (some p) (some e) := by
  dsimp only
  have pp : (1:ℚ)<p := by exact_mod_cast hp
  have h1 : 1≤p^min (e+1) 32 := Nat.one_le_pow _ _ hp.le
  push_cast [Nat.cast_sub hp.le,Nat.cast_sub h1]
  unfold approx
  by_cases small : e<32
  · simp only [small,if_true, min_eq_left (show e+1≤32 by omega),true_form hp,inv_pow]
    field_simp
  · simp only [small,if_false, min_eq_right (show 32≤e+1 by omega),Bool.false_eq_true,inv_pow]
    field_simp

private theorem local_bounds {p : ℕ} (hp : 1<p) (e : ℕ) :
    (smallQuot p e:ℚ) ≤ scale*approx false (some p) (some e) ∧
    scale*approx true (some p) (some e)≤
      ((if e<32 then smallQuot p e else scale*p/((p-1)*(e+1)))+1:ℕ) := by
  let h := p^min (e+1) 32
  have p0 : 0<p-1 := by omega
  have dp : 0<(p-1)*(e+1)*h := Nat.mul_pos (Nat.mul_pos p0 (by omega)) (pow_pos hp.le _)
  have raw := raw_form hp e
  refine ⟨(frac_lo _ _ dp).trans_eq raw,?_⟩
  by_cases small : e<32
  · have same : approx true (some p) (some e)=approx false (some p) (some e) := by
      simp [approx,small]
    rw [same,←raw,if_pos small]
    exact frac_hi _ _ dp
  · simp only [approx,small,↓reduceIte]
    have t := frac_hi (scale*p) ((p-1)*(e+1)) (Nat.mul_pos p0 (by omega))
    push_cast [Nat.cast_sub hp.le] at t ⊢
    simpa only [mul_div_assoc'] using t

theorem bounds {pb eb : Range} {p e : ℕ} (valid : 1<pb.lo) (pi : pb.has p) (ei : eb.has e) :
    (lowX pb eb:ℚ) ≤ scale*X p (some e) ∧ scale*X p (some e)≤highX pb eb ∧
    (lowY pb eb:ℚ) ≤ scale*Y p (some e) ∧ scale*Y p (some e)≤highY pb eb := by
  have hP := valid.trans_le pi.1
  have hQ := hP.trans_le pi.2
  have S : (0:ℚ)<scale := by exact_mod_cast scale_pos
  have m := factor_bounds valid (Range.band_has pi) (Range.band_has ei)
  have l : approx false (some pb.hi) (some eb.hi)≤Y p (some e) :=
    (le_max_right _ _).trans m.2.2.2.2.1
  have u : Y p (some e)≤approx true (some pb.lo) (some eb.lo) := m.2.2.2.2.2
  have lo : (lowY pb eb:ℚ) ≤ scale*Y p (some e) :=
    (local_bounds hQ eb.hi).1.trans (mul_le_mul_of_nonneg_left l S.le)
  have hi : (scale:ℚ)*Y p (some e)≤highY pb eb := by
    unfold highY
    rw [Nat.cast_min]
    exact le_min (mul_le_of_le_one_right S.le (y_one hP _))
      ((mul_le_mul_of_nonneg_left u S.le).trans (local_bounds valid eb.lo).2)
  have yu : highY pb eb ≤ scale := min_le_left _ _
  have yl : lowY pb eb ≤ scale := by
    exact_mod_cast lo.trans (mul_le_of_le_one_right S.le (y_one hP _))
  have P1 : (1:ℚ)<p := by exact_mod_cast hP
  have L1 : (1:ℚ)<pb.lo := by exact_mod_cast valid
  have LL : (pb.lo:ℚ)≤p := by exact_mod_cast pi.1
  have HH : (p:ℚ)≤pb.hi := by exact_mod_cast pi.2
  have id : (scale:ℚ)*X p (some e)=scale+(scale-scale*Y p (some e))/((p:ℚ)-1) := by
    unfold X; ring
  rw [id]
  refine ⟨?_,?_,lo,hi⟩
  · have f := frac_lo (scale-highY pb eb) (pb.hi-1) (by omega)
    unfold lowX
    push_cast [Nat.cast_sub yu,Nat.cast_sub hQ.le] at f ⊢
    apply add_le_add_right
    exact f.trans (div_le_div₀ (sub_nonneg.mpr (mul_le_of_le_one_right S.le (y_one hP _)))
      (by linarith only [hi]) (by linarith) (by linarith))
  · have f := frac_hi (scale-lowY pb eb) (pb.lo-1) (by omega)
    unfold highX
    push_cast [Nat.cast_sub yl,Nat.cast_sub valid.le] at f ⊢
    have D := div_le_div₀ (show 0≤(scale:ℚ)-lowY pb eb by exact sub_nonneg.mpr (by exact_mod_cast yl))
      (show (scale:ℚ)-scale*Y p (some e) ≤ scale-lowY pb eb by linarith only [lo])
      (show 0<(pb.lo:ℚ)-1 by linarith) (show (pb.lo:ℚ)-1≤(p:ℚ)-1 by linarith)
    linarith only [D.trans f]

end OMA.FastFactor245212
