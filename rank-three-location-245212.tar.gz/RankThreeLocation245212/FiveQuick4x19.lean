import FiveQuick4x19S7
import FiveQuick4x19S97
import FiveQuick4x19S187
import FiveQuick4x19S277
import FiveQuick4x19S367
import FiveQuick4x19S457
import FiveQuick4x19S547
import FiveQuick4x19S637
import FiveQuick4x19S727
import FiveQuick4x19S817
import FiveQuick4x19Far
import FiveFastNear245212
namespace OMA.FiveQuick4x19
open OMA.CofactorEulerPair245212 OMA.FiveFastNear245212
open OMA.RankThreeFiveTail245212 (cofactor wt sg ta)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 0
theorem original {p q b c : ℕ} (pp : p.Prime) (qp : q.Prime) (gt : 5<p) (pq : p<q) (bp : 0<b) (cp : 0<c) :
    OeisA245212.a (2^4*5^19*p^b*q^c)≠(ArithmeticFunction.sigma 1 (2^4*5^19*p^b*q^c):ℤ) :=
  OMA.RankThreeFiveShort245212.final (lo:=836) pp qp gt pq bp cp (joinEvery (joinEvery (joinEvery span7 span97) (joinEvery span187 (joinEvery span277 span367))) (joinEvery (joinEvery span457 span547) (joinEvery span637 (joinEvery span727 span817)))) (by decide +kernel) OMA.FiveFar4x19.scan
#print axioms original
end OMA.FiveQuick4x19
