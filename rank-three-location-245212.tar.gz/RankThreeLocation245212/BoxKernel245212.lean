import Moving245212
import SmoothValue245212

/-! A bounded-box certificate engine for the four-prime divisor balance.
The five coordinates are the four exponents followed by the last prime. -/
namespace OMA.Box245212
open Finset OMA.Smooth245212 OMA.Moving245212
open scoped ArithmeticFunction.sigma

structure Range where
  lo : ℕ
  hi : ℕ
  deriving DecidableEq
def Range.has (a : Range) (n : ℕ) := a.lo ≤ n ∧ n ≤ a.hi
def Range.band (a : Range) : Band := ⟨a.lo,some a.hi⟩
theorem Range.band_has {a : Range} {n : ℕ} (h : a.has n) : a.band.Contains n :=
  ⟨h.1,by intro j hj; cases Option.some.inj hj; exact h.2⟩

abbrev Box := Fin 5 → Range
abbrev Values := Fin 5 → ℕ
def Fits (b : Box) (v : Values) := ∀ i,(b i).has (v i)
def bases (p q : ℕ) (v : Values) : Fin 4 → ℕ := ![3,p,q,v 4]
def exponents (v : Values) (i : Fin 4) := v i.castSucc
def baseBox (p q : ℕ) (b : Box) : Fin 4 → Range :=
  ![⟨3,3⟩,⟨p,p⟩,⟨q,q⟩,b 4]

structure Candidate (p q : ℕ) (v : Values) : Prop where
  prime : ∀ i,(bases p q v i).Prime
  ordered : StrictMono (bases p q v)
  pos : ∀ i,0 < exponents v i
  first : 2 ≤ v 0
  eqn : let n := total (bases p q v) (exponents v)
        OeisA245212.a n=(σ 1 n:ℤ)

theorem Candidate.score {p q : ℕ} {v : Values} (h : Candidate p q v) :
    normalized (bases p q v) (exponents v)=2 :=
  normalized_of_eq _ h.prime h.ordered.injective _ h.eqn

def Deny (p q : ℕ) (b : Box) := ∀ v,Fits b v → ¬ Candidate p q v
def clip (b : Box) (i : Fin 5) (c : Range) : Box := Function.update b i c
theorem clip_fits {b : Box} {v : Values} (h : Fits b v) {i : Fin 5} {c : Range}
    (hc : c.has (v i)) : Fits (clip b i c) v := by
  intro j
  by_cases e : j=i
  · subst j; simpa [clip] using hc
  · simpa [clip,e] using h j

theorem split (p q : ℕ) (b : Box) (i : Fin 5) (m : ℕ)
    (lower : Deny p q (clip b i ⟨(b i).lo,m⟩))
    (upper : Deny p q (clip b i ⟨m+1,(b i).hi⟩)) : Deny p q b := by
  intro v inside
  by_cases small : v i ≤ m
  · exact lower v (clip_fits inside ⟨(inside i).1,small⟩)
  · exact upper v (clip_fits inside ⟨show m+1≤v i by omega,(inside i).2⟩)

def factor (f : Band → Band → ℚ) (p q : ℕ) (b : Box) (i : Fin 4) :=
  f (baseBox p q b i).band (b i.castSucc).band

theorem inside_primes {p q : ℕ} {b : Box} {v : Values} (inside : Fits b v) (i : Fin 4) :
    (baseBox p q b i).has (bases p q v i) := by
  fin_cases i <;> simp [baseBox,bases,Range.has]
  exact inside 4

theorem moments {p q : ℕ} {b : Box} {v : Values} (inside : Fits b v)
    (start : ∀ i,1<(baseBox p q b i).lo) (i : Fin 4) :
    let P := bases p q v i; let E := some (exponents v i)
    0≤factor xl p q b i ∧ factor xl p q b i≤X P E ∧ X P E≤factor xu p q b i ∧
    0≤factor yl p q b i ∧ factor yl p q b i≤Y P E ∧ Y P E≤factor yu p q b i :=
  factor_bounds (start i) (Range.band_has (inside_primes inside i)) (Range.band_has (inside i.castSucc))

def prod4 (f : Fin 4 → ℚ) := ∏ i,f i
def interval (p q : ℕ) (b : Box) : Bool :=
  decide ((∀ i,1<(baseBox p q b i).lo) ∧
    (2 < prod4 (factor xl p q b)+prod4 (factor yl p q b) ∨
      prod4 (factor xu p q b)+prod4 (factor yu p q b)<2))

theorem interval_sound {p q : ℕ} {b : Box} (check : interval p q b=true) : Deny p q b := by
  obtain ⟨start,why⟩ := of_decide_eq_true check
  intro v inside candidate
  have m := moments inside start
  have s := candidate.score
  unfold normalized at s
  have lowerX := prod_le_prod (s:=univ) (fun i _ => (m i).1) (fun i _ => (m i).2.1)
  have lowerY := prod_le_prod (s:=univ) (fun i _ => (m i).2.2.2.1) (fun i _ => (m i).2.2.2.2.1)
  have upperX := prod_le_prod (s:=univ) (fun i _ => (m i).1.trans (m i).2.1) (fun i _ => (m i).2.2.1)
  have upperY := prod_le_prod (s:=univ) (fun i _ => (m i).2.2.2.1.trans (m i).2.2.2.2.1)
    (fun i _ => (m i).2.2.2.2.2)
  rcases why with h|h <;> unfold prod4 at h <;> linarith

end OMA.Box245212
