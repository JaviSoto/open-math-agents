import RankThreeFiveCount245212
/-! Finite first-prime intervals; both prime powers remain unrestricted. -/
namespace OMA.RankThreeFiveRows245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFiveTail245212
open OMA.RankThreeMiddle245212 (joinEvery)
open scoped ArithmeticFunction.sigma
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem block8_1_7 : every 7 10 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_11 : every 11 14 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_15 : every 15 18 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_19 : every 19 22 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_23 : every 23 26 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_27 : every 27 30 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_31 : every 31 34 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_35 : every 35 38 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_39 : every 39 42 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_43 : every 43 46 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_47 : every 47 50 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_51 : every 51 54 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_55 : every 55 58 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_59 : every 59 62 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_63 : every 63 66 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_67 : every 67 70 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_71 : every 71 74 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_75 : every 75 78 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_79 : every 79 82 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_83 : every 83 86 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_87 : every 87 90 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_91 : every 91 94 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_95 : every 95 98 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_99 : every 99 102 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_103 : every 103 106 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_107 : every 107 110 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_111 : every 111 114 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_115 : every 115 118 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_119 : every 119 122 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_123 : every 123 126 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_127 : every 127 130 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_131 : every 131 134 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_135 : every 135 138 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_139 : every 139 142 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_143 : every 143 146 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_147 : every 147 150 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_151 : every 151 154 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_155 : every 155 158 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_159 : every 159 162 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_163 : every 163 166 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_167 : every 167 170 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_171 : every 171 174 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_175 : every 175 178 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_179 : every 179 182 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_183 : every 183 186 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_187 : every 187 190 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_191 : every 191 194 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_195 : every 195 198 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_199 : every 199 202 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_203 : every 203 206 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_207 : every 207 210 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_211 : every 211 214 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_215 : every 215 218 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_219 : every 219 222 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_223 : every 223 226 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_227 : every 227 230 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_231 : every 231 234 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_235 : every 235 238 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_239 : every 239 242 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_243 : every 243 246 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_247 : every 247 250 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_251 : every 251 254 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_255 : every 255 258 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_259 : every 259 262 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_263 : every 263 266 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_267 : every 267 270 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_271 : every 271 274 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_275 : every 275 278 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_279 : every 279 282 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_283 : every 283 286 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_287 : every 287 290 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_291 : every 291 294 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_295 : every 295 298 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_299 : every 299 302 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_303 : every 303 306 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_307 : every 307 310 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_311 : every 311 314 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_315 : every 315 318 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_319 : every 319 322 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_323 : every 323 326 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_327 : every 327 330 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_331 : every 331 334 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_335 : every 335 338 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_339 : every 339 342 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_343 : every 343 346 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_347 : every 347 350 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_351 : every 351 354 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_355 : every 355 358 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_359 : every 359 362 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_363 : every 363 366 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_367 : every 367 370 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
private theorem block8_1_371 : every 371 373 (OMA.RankThreeFiveCount245212.row 1280 45067 3066 23040)=true := by decide +kernel
theorem c8_1 : every 7 (OMA.RankThreeFourSmallHarmonic245212.primeCut (wt 8 1) (sg 8 1) (2*ta 8 1)) (OMA.RankThreeFiveCount245212.test 8 1)=true := (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery block8_1_7 block8_1_11) (joinEvery block8_1_15 (joinEvery block8_1_19 block8_1_23))) (joinEvery (joinEvery block8_1_27 (joinEvery block8_1_31 block8_1_35)) (joinEvery block8_1_39 (joinEvery block8_1_43 block8_1_47)))) (joinEvery (joinEvery (joinEvery block8_1_51 (joinEvery block8_1_55 block8_1_59)) (joinEvery block8_1_63 (joinEvery block8_1_67 block8_1_71))) (joinEvery (joinEvery block8_1_75 (joinEvery block8_1_79 block8_1_83)) (joinEvery block8_1_87 (joinEvery block8_1_91 block8_1_95))))) (joinEvery (joinEvery (joinEvery (joinEvery block8_1_99 block8_1_103) (joinEvery block8_1_107 (joinEvery block8_1_111 block8_1_115))) (joinEvery (joinEvery block8_1_119 (joinEvery block8_1_123 block8_1_127)) (joinEvery block8_1_131 (joinEvery block8_1_135 block8_1_139)))) (joinEvery (joinEvery (joinEvery block8_1_143 (joinEvery block8_1_147 block8_1_151)) (joinEvery block8_1_155 (joinEvery block8_1_159 block8_1_163))) (joinEvery (joinEvery block8_1_167 (joinEvery block8_1_171 block8_1_175)) (joinEvery block8_1_179 (joinEvery block8_1_183 block8_1_187)))))) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery block8_1_191 block8_1_195) (joinEvery block8_1_199 (joinEvery block8_1_203 block8_1_207))) (joinEvery (joinEvery block8_1_211 (joinEvery block8_1_215 block8_1_219)) (joinEvery block8_1_223 (joinEvery block8_1_227 block8_1_231)))) (joinEvery (joinEvery (joinEvery block8_1_235 (joinEvery block8_1_239 block8_1_243)) (joinEvery block8_1_247 (joinEvery block8_1_251 block8_1_255))) (joinEvery (joinEvery block8_1_259 (joinEvery block8_1_263 block8_1_267)) (joinEvery block8_1_271 (joinEvery block8_1_275 block8_1_279))))) (joinEvery (joinEvery (joinEvery (joinEvery block8_1_283 block8_1_287) (joinEvery block8_1_291 (joinEvery block8_1_295 block8_1_299))) (joinEvery (joinEvery block8_1_303 (joinEvery block8_1_307 block8_1_311)) (joinEvery block8_1_315 (joinEvery block8_1_319 block8_1_323)))) (joinEvery (joinEvery (joinEvery block8_1_327 (joinEvery block8_1_331 block8_1_335)) (joinEvery block8_1_339 (joinEvery block8_1_343 block8_1_347))) (joinEvery (joinEvery block8_1_351 (joinEvery block8_1_355 block8_1_359)) (joinEvery block8_1_363 (joinEvery block8_1_367 block8_1_371)))))))
end OMA.RankThreeFiveRows245212
