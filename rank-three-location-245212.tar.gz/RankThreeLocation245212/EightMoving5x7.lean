import RankThreeEightMoving245212
/-! Complete enumeration of both short prefixes for one moving-prime family. -/
/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E1P7
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b8 : every 8 23 (quick 40 539 90 320 7)=true := by decide +kernel
private theorem b24 : every 24 39 (quick 40 539 90 320 7)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 40 539 90 320 7)=true := by decide +kernel
private theorem b56 : every 56 57 (quick 40 539 90 320 7)=true := by decide +kernel
theorem certificate : atom 5 7 1=true := by
  apply row_low (h:=40) (A:=539) (S:=90) (T:=320) (R:=8) (Q:=57) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 57≤8+128)]
  exact (joinEvery (joinEvery b8 b24) (joinEvery b40 b56))
end OMA.EightAt5E1P7

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E2P7
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 12 (line 4214 465 2400 7 8)=true := by decide +kernel
theorem certificate : atom 5 7 2=true := by
  apply row_high (h:=200) (A:=4214) (S:=465) (T:=2400) (R:=8) (B:=12) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact b1
end OMA.EightAt5E2P7

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt7E1P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 735 120 448 5 8)=true := by decide +kernel
theorem certificate : atom 7 5 1=true := by
  apply row_high (h:=56) (A:=735) (S:=120) (T:=448) (R:=8) (B:=16) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact b1
end OMA.EightAt7E1P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt7E2P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 7 (line 7938 855 4704 5 8)=true := by decide +kernel
theorem certificate : atom 7 5 2=true := by
  apply row_high (h:=392) (A:=7938) (S:=855) (T:=4704) (R:=8) (B:=7) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact b1
end OMA.EightAt7E2P5

namespace OMA.EightMoving5x7
open OMA.CofactorEulerPair245212 OMA.RankThreeEightMoving245212 OMA.Smooth245212
open OMA.RankThreeMiddle245212 (joinEvery)
open scoped ArithmeticFunction.sigma
private theorem range5 : every 1 2 (atom 5 7)=true := (joinEvery (single (f:=atom 5 7) OMA.EightAt5E1P7.certificate) (single (f:=atom 5 7) OMA.EightAt5E2P7.certificate))
private theorem range7 : every 1 2 (atom 7 5)=true := (joinEvery (single (f:=atom 7 5) OMA.EightAt7E1P5.certificate) (single (f:=atom 7 5) OMA.EightAt7E2P5.certificate))
theorem exclude {r a b c : ℕ} (pr : r.Prime) (large : 7<r) (ap : 0<a) (bp : 0<b) (cp : 0<c) :
    OeisA245212.a (8*5^a*7^b*r^c)≠(σ 1 (8*5^a*7^b*r^c):ℤ) :=
  close (l:=3) (u:=3) (by decide) (by decide) pr (by decide) (by decide) large ap bp cp (by decide +kernel) range5 range7
#print axioms exclude
end OMA.EightMoving5x7
