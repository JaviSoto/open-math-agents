import RankThreeEightMoving245212
/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E1P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 184 2303 360 1472 5)=true := by decide +kernel
private theorem b40 : every 40 45 (quick 184 2303 360 1472 5)=true := by decide +kernel
theorem certificate : atom 23 5 1=true := by
  apply row_low (h:=184) (A:=2303) (S:=360) (T:=1472) (R:=24) (Q:=45) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 45≤24+128)]
  exact (joinEvery b24 b40)
end OMA.EightAt23E1P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E2P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 4232 80066 8295 50784 5)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 4232 80066 8295 50784 5)=true := by decide +kernel
private theorem b56 : every 56 68 (quick 4232 80066 8295 50784 5)=true := by decide +kernel
theorem certificate : atom 23 5 2=true := by
  apply row_low (h:=4232) (A:=80066) (S:=8295) (T:=50784) (R:=24) (Q:=68) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 68≤24+128)]
  exact (joinEvery b24 (joinEvery b40 b56))
end OMA.EightAt23E2P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E3P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 97336 2464798 190800 1557376 5)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 97336 2464798 190800 1557376 5)=true := by decide +kernel
private theorem b56 : every 56 71 (quick 97336 2464798 190800 1557376 5)=true := by decide +kernel
private theorem b72 : every 72 87 (quick 97336 2464798 190800 1557376 5)=true := by decide +kernel
private theorem b88 : every 88 92 (quick 97336 2464798 190800 1557376 5)=true := by decide +kernel
theorem certificate : atom 23 5 3=true := by
  apply row_low (h:=97336) (A:=2464798) (S:=190800) (T:=1557376) (R:=24) (Q:=92) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 92≤24+128)]
  exact (joinEvery (joinEvery b24 b40) (joinEvery b56 (joinEvery b72 b88)))
end OMA.EightAt23E3P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E4P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 2238728 71025843 4388415 44774560 5)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 2238728 71025843 4388415 44774560 5)=true := by decide +kernel
private theorem b56 : every 56 71 (quick 2238728 71025843 4388415 44774560 5)=true := by decide +kernel
private theorem b72 : every 72 87 (quick 2238728 71025843 4388415 44774560 5)=true := by decide +kernel
private theorem b88 : every 88 103 (quick 2238728 71025843 4388415 44774560 5)=true := by decide +kernel
private theorem b104 : every 104 116 (quick 2238728 71025843 4388415 44774560 5)=true := by decide +kernel
theorem certificate : atom 23 5 4=true := by
  apply row_low (h:=2238728) (A:=71025843) (S:=4388415) (T:=44774560) (R:=24) (Q:=116) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 116≤24+128)]
  exact (joinEvery (joinEvery b24 (joinEvery b40 b56)) (joinEvery b72 (joinEvery b88 b104)))
end OMA.EightAt23E4P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E5P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 51490744 1963310685 100933560 1235777856 5)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 51490744 1963310685 100933560 1235777856 5)=true := by decide +kernel
private theorem b56 : every 56 71 (quick 51490744 1963310685 100933560 1235777856 5)=true := by decide +kernel
private theorem b72 : every 72 87 (quick 51490744 1963310685 100933560 1235777856 5)=true := by decide +kernel
private theorem b88 : every 88 103 (quick 51490744 1963310685 100933560 1235777856 5)=true := by decide +kernel
private theorem b104 : every 104 119 (quick 51490744 1963310685 100933560 1235777856 5)=true := by decide +kernel
private theorem b120 : every 120 135 (quick 51490744 1963310685 100933560 1235777856 5)=true := by decide +kernel
private theorem b136 : every 136 141 (quick 51490744 1963310685 100933560 1235777856 5)=true := by decide +kernel
theorem certificate : atom 23 5 5=true := by
  apply row_low (h:=51490744) (A:=1963310685) (S:=100933560) (T:=1235777856) (R:=24) (Q:=141) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 141≤24+128)]
  exact (joinEvery (joinEvery (joinEvery b24 b40) (joinEvery b56 b72)) (joinEvery (joinEvery b88 b104) (joinEvery b120 b136)))
end OMA.EightAt23E5P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E6P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 52739620612 2321471895 33160039136 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 52739620612 2321471895 33160039136 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 52739620612 2321471895 33160039136 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 52739620612 2321471895 33160039136 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 52739620612 2321471895 33160039136 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 52739620612 2321471895 33160039136 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 52739620612 2321471895 33160039136 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 52739620612 2321471895 33160039136 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 52739620612 2321471895 33160039136 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 52739620612 2321471895 33160039136 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 52739620612 2321471895 33160039136 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 52739620612 2321471895 33160039136 5 24)=true := by decide +kernel
private theorem b193 : every 193 196 (line 52739620612 2321471895 33160039136 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 6=true := by
  apply row_low (h:=1184287112) (A:=52739620612) (S:=2321471895) (T:=33160039136) (R:=24) (Q:=167) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬167≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 1184287112 52739620612 2321471895 5 167=196 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery (joinEvery b145 b161) (joinEvery b177 b193))))⟩
end OMA.EightAt23E6P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E7P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 1387431195836 53393853600 871635314432 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 1387431195836 53393853600 871635314432 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 1387431195836 53393853600 871635314432 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 1387431195836 53393853600 871635314432 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 1387431195836 53393853600 871635314432 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 1387431195836 53393853600 871635314432 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 1387431195836 53393853600 871635314432 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 1387431195836 53393853600 871635314432 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 1387431195836 53393853600 871635314432 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 1387431195836 53393853600 871635314432 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 1387431195836 53393853600 871635314432 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 1387431195836 53393853600 871635314432 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 1387431195836 53393853600 871635314432 5 24)=true := by decide +kernel
private theorem b209 : every 209 214 (line 1387431195836 53393853600 871635314432 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 7=true := by
  apply row_low (h:=27238603576) (A:=1387431195836) (S:=53393853600) (T:=871635314432) (R:=24) (Q:=194) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬194≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 27238603576 1387431195836 53393853600 5 194=214 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97))) (joinEvery (joinEvery b113 (joinEvery b129 b145)) (joinEvery (joinEvery b161 b177) (joinEvery b193 b209))))⟩
end OMA.EightAt23E7P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E8P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 35922575704757 1228058632815 22553563760928 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 35922575704757 1228058632815 22553563760928 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 35922575704757 1228058632815 22553563760928 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 35922575704757 1228058632815 22553563760928 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 35922575704757 1228058632815 22553563760928 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 35922575704757 1228058632815 22553563760928 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 35922575704757 1228058632815 22553563760928 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 35922575704757 1228058632815 22553563760928 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 35922575704757 1228058632815 22553563760928 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 35922575704757 1228058632815 22553563760928 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 35922575704757 1228058632815 22553563760928 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 35922575704757 1228058632815 22553563760928 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 35922575704757 1228058632815 22553563760928 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 35922575704757 1228058632815 22553563760928 5 24)=true := by decide +kernel
private theorem b225 : every 225 232 (line 35922575704757 1228058632815 22553563760928 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 8=true := by
  apply row_low (h:=626487882248) (A:=35922575704757) (S:=1228058632815) (T:=22553563760928) (R:=24) (Q:=221) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬221≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 626487882248 35922575704757 1228058632815 5 221=232 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97))) (joinEvery (joinEvery (joinEvery b113 b129) (joinEvery b145 b161)) (joinEvery (joinEvery b177 b193) (joinEvery b209 b225))))⟩
end OMA.EightAt23E8P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E9P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 918487379821627 28245348554760 576368851668160 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 918487379821627 28245348554760 576368851668160 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 918487379821627 28245348554760 576368851668160 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 918487379821627 28245348554760 576368851668160 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 918487379821627 28245348554760 576368851668160 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 918487379821627 28245348554760 576368851668160 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 918487379821627 28245348554760 576368851668160 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 918487379821627 28245348554760 576368851668160 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 918487379821627 28245348554760 576368851668160 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 918487379821627 28245348554760 576368851668160 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 918487379821627 28245348554760 576368851668160 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 918487379821627 28245348554760 576368851668160 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 918487379821627 28245348554760 576368851668160 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 918487379821627 28245348554760 576368851668160 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 918487379821627 28245348554760 576368851668160 5 24)=true := by decide +kernel
private theorem b241 : every 241 250 (line 918487379821627 28245348554760 576368851668160 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 9=true := by
  apply row_low (h:=14409221291704) (A:=918487379821627) (S:=28245348554760) (T:=576368851668160) (R:=24) (Q:=249) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬249≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 14409221291704 918487379821627 28245348554760 5 249=250 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 b49)) (joinEvery (joinEvery b65 b81) (joinEvery b97 b113))) (joinEvery (joinEvery (joinEvery b129 b145) (joinEvery b161 b177)) (joinEvery (joinEvery b193 b209) (joinEvery b225 b241))))⟩
end OMA.EightAt23E9P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E10P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 23247376923978438 649643016759495 14582131947204448 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 23247376923978438 649643016759495 14582131947204448 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 23247376923978438 649643016759495 14582131947204448 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 23247376923978438 649643016759495 14582131947204448 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 23247376923978438 649643016759495 14582131947204448 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 23247376923978438 649643016759495 14582131947204448 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 23247376923978438 649643016759495 14582131947204448 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 23247376923978438 649643016759495 14582131947204448 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 23247376923978438 649643016759495 14582131947204448 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 23247376923978438 649643016759495 14582131947204448 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 23247376923978438 649643016759495 14582131947204448 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 23247376923978438 649643016759495 14582131947204448 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 23247376923978438 649643016759495 14582131947204448 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 23247376923978438 649643016759495 14582131947204448 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 23247376923978438 649643016759495 14582131947204448 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 23247376923978438 649643016759495 14582131947204448 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 23247376923978438 649643016759495 14582131947204448 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 10=true := by
  apply row_low (h:=331412089709192) (A:=23247376923978438) (S:=649643016759495) (T:=14582131947204448) (R:=24) (Q:=277) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬277≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 331412089709192 23247376923978438 649643016759495 5 277=272 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 b49)) (joinEvery (joinEvery b65 b81) (joinEvery b97 b113))) (joinEvery (joinEvery (joinEvery b129 b145) (joinEvery b161 b177)) (joinEvery (joinEvery b193 b209) (joinEvery b225 (joinEvery b241 b257)))))⟩
end OMA.EightAt23E10P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E11P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 583499514577367514 14941789385468400 365878947038947968 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 583499514577367514 14941789385468400 365878947038947968 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 583499514577367514 14941789385468400 365878947038947968 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 583499514577367514 14941789385468400 365878947038947968 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 583499514577367514 14941789385468400 365878947038947968 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 583499514577367514 14941789385468400 365878947038947968 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 583499514577367514 14941789385468400 365878947038947968 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 583499514577367514 14941789385468400 365878947038947968 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 583499514577367514 14941789385468400 365878947038947968 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 583499514577367514 14941789385468400 365878947038947968 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 583499514577367514 14941789385468400 365878947038947968 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 583499514577367514 14941789385468400 365878947038947968 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 583499514577367514 14941789385468400 365878947038947968 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 583499514577367514 14941789385468400 365878947038947968 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 583499514577367514 14941789385468400 365878947038947968 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 583499514577367514 14941789385468400 365878947038947968 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 583499514577367514 14941789385468400 365878947038947968 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 583499514577367514 14941789385468400 365878947038947968 5 24)=true := by decide +kernel
private theorem b289 : every 289 290 (line 583499514577367514 14941789385468400 365878947038947968 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 11=true := by
  apply row_low (h:=7622478063311416) (A:=583499514577367514) (S:=14941789385468400) (T:=365878947038947968) (R:=24) (Q:=307) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬307≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 7622478063311416 583499514577367514 14941789385468400 5 307=290 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 b49)) (joinEvery (joinEvery b65 b81) (joinEvery b97 (joinEvery b113 b129)))) (joinEvery (joinEvery (joinEvery b145 b161) (joinEvery b177 (joinEvery b193 b209))) (joinEvery (joinEvery b225 b241) (joinEvery b257 (joinEvery b273 b289)))))⟩
end OMA.EightAt23E11P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E12P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 14543115277774311991 343661155865773215 9116483763720453536 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 14543115277774311991 343661155865773215 9116483763720453536 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 14543115277774311991 343661155865773215 9116483763720453536 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 14543115277774311991 343661155865773215 9116483763720453536 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 14543115277774311991 343661155865773215 9116483763720453536 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 14543115277774311991 343661155865773215 9116483763720453536 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 14543115277774311991 343661155865773215 9116483763720453536 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 14543115277774311991 343661155865773215 9116483763720453536 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 14543115277774311991 343661155865773215 9116483763720453536 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 14543115277774311991 343661155865773215 9116483763720453536 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 14543115277774311991 343661155865773215 9116483763720453536 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 14543115277774311991 343661155865773215 9116483763720453536 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 14543115277774311991 343661155865773215 9116483763720453536 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 14543115277774311991 343661155865773215 9116483763720453536 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 14543115277774311991 343661155865773215 9116483763720453536 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 14543115277774311991 343661155865773215 9116483763720453536 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 14543115277774311991 343661155865773215 9116483763720453536 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 14543115277774311991 343661155865773215 9116483763720453536 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 14543115277774311991 343661155865773215 9116483763720453536 5 24)=true := by decide +kernel
private theorem b305 : every 305 308 (line 14543115277774311991 343661155865773215 9116483763720453536 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 12=true := by
  apply row_low (h:=175316995456162568) (A:=14543115277774311991) (S:=343661155865773215) (T:=9116483763720453536) (R:=24) (Q:=337) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬337≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 175316995456162568 14543115277774311991 343661155865773215 5 337=308 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65))) (joinEvery (joinEvery b81 b97) (joinEvery b113 (joinEvery b129 b145)))) (joinEvery (joinEvery (joinEvery b161 b177) (joinEvery b193 (joinEvery b209 b225))) (joinEvery (joinEvery b241 b257) (joinEvery b273 (joinEvery b289 b305)))))⟩
end OMA.EightAt23E12P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E13P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 360312059566190936729 7904206584912783960 225808290147537387584 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 360312059566190936729 7904206584912783960 225808290147537387584 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 360312059566190936729 7904206584912783960 225808290147537387584 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 360312059566190936729 7904206584912783960 225808290147537387584 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 360312059566190936729 7904206584912783960 225808290147537387584 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 360312059566190936729 7904206584912783960 225808290147537387584 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 360312059566190936729 7904206584912783960 225808290147537387584 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 360312059566190936729 7904206584912783960 225808290147537387584 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 360312059566190936729 7904206584912783960 225808290147537387584 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 360312059566190936729 7904206584912783960 225808290147537387584 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 360312059566190936729 7904206584912783960 225808290147537387584 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 360312059566190936729 7904206584912783960 225808290147537387584 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 360312059566190936729 7904206584912783960 225808290147537387584 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 360312059566190936729 7904206584912783960 225808290147537387584 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 360312059566190936729 7904206584912783960 225808290147537387584 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 360312059566190936729 7904206584912783960 225808290147537387584 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 360312059566190936729 7904206584912783960 225808290147537387584 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 360312059566190936729 7904206584912783960 225808290147537387584 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 360312059566190936729 7904206584912783960 225808290147537387584 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 360312059566190936729 7904206584912783960 225808290147537387584 5 24)=true := by decide +kernel
private theorem b321 : every 321 326 (line 360312059566190936729 7904206584912783960 225808290147537387584 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 13=true := by
  apply row_low (h:=4032290895491739064) (A:=360312059566190936729) (S:=7904206584912783960) (T:=225808290147537387584) (R:=24) (Q:=368) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬368≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 4032290895491739064 360312059566190936729 7904206584912783960 5 368=326 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65))) (joinEvery (joinEvery b81 b97) (joinEvery b113 (joinEvery b129 b145)))) (joinEvery (joinEvery (joinEvery b161 b177) (joinEvery b193 (joinEvery b209 b225))) (joinEvery (joinEvery b241 (joinEvery b257 b273)) (joinEvery b289 (joinEvery b305 b321)))))⟩
end OMA.EightAt23E13P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E14P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 8881046758102172046344 181796751452994031095 5564561435778599908320 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 8881046758102172046344 181796751452994031095 5564561435778599908320 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 8881046758102172046344 181796751452994031095 5564561435778599908320 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 8881046758102172046344 181796751452994031095 5564561435778599908320 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 8881046758102172046344 181796751452994031095 5564561435778599908320 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 8881046758102172046344 181796751452994031095 5564561435778599908320 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 8881046758102172046344 181796751452994031095 5564561435778599908320 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 8881046758102172046344 181796751452994031095 5564561435778599908320 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 8881046758102172046344 181796751452994031095 5564561435778599908320 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 8881046758102172046344 181796751452994031095 5564561435778599908320 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 8881046758102172046344 181796751452994031095 5564561435778599908320 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 8881046758102172046344 181796751452994031095 5564561435778599908320 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 8881046758102172046344 181796751452994031095 5564561435778599908320 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 8881046758102172046344 181796751452994031095 5564561435778599908320 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 8881046758102172046344 181796751452994031095 5564561435778599908320 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 8881046758102172046344 181796751452994031095 5564561435778599908320 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 8881046758102172046344 181796751452994031095 5564561435778599908320 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 8881046758102172046344 181796751452994031095 5564561435778599908320 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 8881046758102172046344 181796751452994031095 5564561435778599908320 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 8881046758102172046344 181796751452994031095 5564561435778599908320 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 8881046758102172046344 181796751452994031095 5564561435778599908320 5 24)=true := by decide +kernel
private theorem b337 : every 337 344 (line 8881046758102172046344 181796751452994031095 5564561435778599908320 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 14=true := by
  apply row_low (h:=92742690596309998472) (A:=8881046758102172046344) (S:=181796751452994031095) (T:=5564561435778599908320) (R:=24) (Q:=400) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬400≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 92742690596309998472 8881046758102172046344 181796751452994031095 5 400=344 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65))) (joinEvery (joinEvery b81 (joinEvery b97 b113)) (joinEvery b129 (joinEvery b145 b161)))) (joinEvery (joinEvery (joinEvery b177 b193) (joinEvery b209 (joinEvery b225 b241))) (joinEvery (joinEvery b257 (joinEvery b273 b289)) (joinEvery b305 (joinEvery b321 b337)))))⟩
end OMA.EightAt23E14P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E15P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 217923071362184908602232 4181325283418862715200 136517240557768317750784 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 217923071362184908602232 4181325283418862715200 136517240557768317750784 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 217923071362184908602232 4181325283418862715200 136517240557768317750784 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 217923071362184908602232 4181325283418862715200 136517240557768317750784 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 217923071362184908602232 4181325283418862715200 136517240557768317750784 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 217923071362184908602232 4181325283418862715200 136517240557768317750784 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 217923071362184908602232 4181325283418862715200 136517240557768317750784 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 217923071362184908602232 4181325283418862715200 136517240557768317750784 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 217923071362184908602232 4181325283418862715200 136517240557768317750784 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 217923071362184908602232 4181325283418862715200 136517240557768317750784 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 217923071362184908602232 4181325283418862715200 136517240557768317750784 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 217923071362184908602232 4181325283418862715200 136517240557768317750784 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 217923071362184908602232 4181325283418862715200 136517240557768317750784 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 217923071362184908602232 4181325283418862715200 136517240557768317750784 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 217923071362184908602232 4181325283418862715200 136517240557768317750784 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 217923071362184908602232 4181325283418862715200 136517240557768317750784 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 217923071362184908602232 4181325283418862715200 136517240557768317750784 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 217923071362184908602232 4181325283418862715200 136517240557768317750784 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 217923071362184908602232 4181325283418862715200 136517240557768317750784 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 217923071362184908602232 4181325283418862715200 136517240557768317750784 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 217923071362184908602232 4181325283418862715200 136517240557768317750784 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 217923071362184908602232 4181325283418862715200 136517240557768317750784 5 24)=true := by decide +kernel
private theorem b353 : every 353 366 (line 217923071362184908602232 4181325283418862715200 136517240557768317750784 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 15=true := by
  apply row_low (h:=2133081883715129964856) (A:=217923071362184908602232) (S:=4181325283418862715200) (T:=136517240557768317750784) (R:=24) (Q:=432) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬432≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 2133081883715129964856 217923071362184908602232 4181325283418862715200 5 432=366 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65))) (joinEvery (joinEvery b81 (joinEvery b97 b113)) (joinEvery b129 (joinEvery b145 b161)))) (joinEvery (joinEvery (joinEvery b177 (joinEvery b193 b209)) (joinEvery b225 (joinEvery b241 b257))) (joinEvery (joinEvery b273 (joinEvery b289 b305)) (joinEvery b321 (joinEvery b337 b353)))))⟩
end OMA.EightAt23E15P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E16P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 5326387547624456783186745 96170481518633842449615 3336140066130463265034784 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 5326387547624456783186745 96170481518633842449615 3336140066130463265034784 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 5326387547624456783186745 96170481518633842449615 3336140066130463265034784 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 5326387547624456783186745 96170481518633842449615 3336140066130463265034784 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 5326387547624456783186745 96170481518633842449615 3336140066130463265034784 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 5326387547624456783186745 96170481518633842449615 3336140066130463265034784 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 5326387547624456783186745 96170481518633842449615 3336140066130463265034784 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 5326387547624456783186745 96170481518633842449615 3336140066130463265034784 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 5326387547624456783186745 96170481518633842449615 3336140066130463265034784 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 5326387547624456783186745 96170481518633842449615 3336140066130463265034784 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 5326387547624456783186745 96170481518633842449615 3336140066130463265034784 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 5326387547624456783186745 96170481518633842449615 3336140066130463265034784 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 5326387547624456783186745 96170481518633842449615 3336140066130463265034784 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 5326387547624456783186745 96170481518633842449615 3336140066130463265034784 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 5326387547624456783186745 96170481518633842449615 3336140066130463265034784 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 5326387547624456783186745 96170481518633842449615 3336140066130463265034784 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 5326387547624456783186745 96170481518633842449615 3336140066130463265034784 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 5326387547624456783186745 96170481518633842449615 3336140066130463265034784 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 5326387547624456783186745 96170481518633842449615 3336140066130463265034784 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 5326387547624456783186745 96170481518633842449615 3336140066130463265034784 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 5326387547624456783186745 96170481518633842449615 3336140066130463265034784 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 5326387547624456783186745 96170481518633842449615 3336140066130463265034784 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 5326387547624456783186745 96170481518633842449615 3336140066130463265034784 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 5326387547624456783186745 96170481518633842449615 3336140066130463265034784 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 16=true := by
  apply row_low (h:=49060883325447989191688) (A:=5326387547624456783186745) (S:=96170481518633842449615) (T:=3336140066130463265034784) (R:=24) (Q:=466) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬466≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 49060883325447989191688 5326387547624456783186745 96170481518633842449615 5 466=384 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery b145 (joinEvery b161 b177)))) (joinEvery (joinEvery (joinEvery b193 (joinEvery b209 b225)) (joinEvery b241 (joinEvery b257 b273))) (joinEvery (joinEvery b289 (joinEvery b305 b321)) (joinEvery b337 (joinEvery b353 b369)))))⟩
end OMA.EightAt23E16P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E17P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b385 : every 385 400 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
private theorem b401 : every 401 402 (line 129732522440129195376009591 2211921074928578376341160 81244822786941870101435328 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 17=true := by
  apply row_low (h:=1128400316485303751408824) (A:=129732522440129195376009591) (S:=2211921074928578376341160) (T:=81244822786941870101435328) (R:=24) (Q:=501) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬501≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 1128400316485303751408824 129732522440129195376009591 2211921074928578376341160 5 501=402 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery (joinEvery b145 b161) (joinEvery b177 b193)))) (joinEvery (joinEvery (joinEvery b209 (joinEvery b225 b241)) (joinEvery b257 (joinEvery b273 b289))) (joinEvery (joinEvery b305 (joinEvery b321 b337)) (joinEvery (joinEvery b353 b369) (joinEvery b385 b401)))))⟩
end OMA.EightAt23E17P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E18P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b385 : every 385 400 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b401 : every 401 416 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
private theorem b417 : every 417 420 (line 3150037019552605348990653130 50874184723357302655846695 1972443753216310957462624352 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 18=true := by
  apply row_low (h:=25953207279161986282402952) (A:=3150037019552605348990653130) (S:=50874184723357302655846695) (T:=1972443753216310957462624352) (R:=24) (Q:=537) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬537≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 25953207279161986282402952 3150037019552605348990653130 50874184723357302655846695 5 537=420 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery (joinEvery b145 b161) (joinEvery b177 b193)))) (joinEvery (joinEvery (joinEvery b209 (joinEvery b225 b241)) (joinEvery (joinEvery b257 b273) (joinEvery b289 b305))) (joinEvery (joinEvery b321 (joinEvery b337 b353)) (joinEvery (joinEvery b369 b385) (joinEvery b401 b417)))))⟩
end OMA.EightAt23E18P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E19P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b385 : every 385 400 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b401 : every 401 416 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b417 : every 417 432 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
private theorem b433 : every 433 438 (line 76273198528591501699660970390 1170106248637217961084474000 47753901393658054759621431680 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 19=true := by
  apply row_low (h:=596923767420725684495267896) (A:=76273198528591501699660970390) (S:=1170106248637217961084474000) (T:=47753901393658054759621431680) (R:=24) (Q:=574) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬574≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 596923767420725684495267896 76273198528591501699660970390 1170106248637217961084474000 5 574=438 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97))) (joinEvery (joinEvery b113 (joinEvery b129 b145)) (joinEvery (joinEvery b161 b177) (joinEvery b193 b209)))) (joinEvery (joinEvery (joinEvery b225 (joinEvery b241 b257)) (joinEvery (joinEvery b273 b289) (joinEvery b305 b321))) (joinEvery (joinEvery b337 (joinEvery b353 b369)) (joinEvery (joinEvery b385 b401) (joinEvery b417 b433)))))⟩
end OMA.EightAt23E19P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E20P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b385 : every 385 400 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b401 : every 401 416 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b417 : every 417 432 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b433 : every 433 448 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
private theorem b449 : every 449 456 (line 1842197548971880848568349132219 26912443718656013104942902015 1153256718656842022444857575072 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 20=true := by
  apply row_low (h:=13729246650676690743391161608) (A:=1842197548971880848568349132219) (S:=26912443718656013104942902015) (T:=1153256718656842022444857575072) (R:=24) (Q:=612) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬612≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 13729246650676690743391161608 1842197548971880848568349132219 26912443718656013104942902015 5 612=456 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97))) (joinEvery (joinEvery b113 (joinEvery b129 b145)) (joinEvery (joinEvery b161 b177) (joinEvery b193 b209)))) (joinEvery (joinEvery (joinEvery b225 (joinEvery b241 b257)) (joinEvery (joinEvery b273 b289) (joinEvery b305 b321))) (joinEvery (joinEvery (joinEvery b337 b353) (joinEvery b369 b385)) (joinEvery (joinEvery b401 b417) (joinEvery b433 b449)))))⟩
end OMA.EightAt23E20P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E21P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b385 : every 385 400 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b401 : every 401 416 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b417 : every 417 432 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b433 : every 433 448 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b449 : every 449 464 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b465 : every 465 480 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b481 : every 481 496 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b497 : every 497 512 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b513 : every 513 528 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b529 : every 529 544 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b545 : every 545 560 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b561 : every 561 576 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
private theorem b577 : every 577 580 (line 44392565231081614635023406745813 618986205529088301413686746360 27787995220969622064623711094592 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 21=true := by
  apply row_low (h:=315772672965563887097996716984) (A:=44392565231081614635023406745813) (S:=618986205529088301413686746360) (T:=27787995220969622064623711094592) (R:=24) (Q:=651) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬651≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 315772672965563887097996716984 44392565231081614635023406745813 618986205529088301413686746360 5 651=580 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 b49)) (joinEvery (joinEvery b65 b81) (joinEvery b97 (joinEvery b113 b129)))) (joinEvery (joinEvery (joinEvery b145 b161) (joinEvery b177 b193)) (joinEvery (joinEvery b209 b225) (joinEvery b241 (joinEvery b257 b273))))) (joinEvery (joinEvery (joinEvery (joinEvery b289 b305) (joinEvery b321 b337)) (joinEvery (joinEvery b353 b369) (joinEvery b385 (joinEvery b401 b417)))) (joinEvery (joinEvery (joinEvery b433 b449) (joinEvery b465 (joinEvery b481 b497))) (joinEvery (joinEvery b513 b529) (joinEvery b545 (joinEvery b561 b577))))))⟩
end OMA.EightAt23E21P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E22P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b385 : every 385 400 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b401 : every 401 416 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b417 : every 417 432 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b433 : every 433 448 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b449 : every 449 464 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b465 : every 465 480 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b481 : every 481 496 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b497 : every 497 512 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b513 : every 513 528 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b529 : every 529 544 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b545 : every 545 560 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b561 : every 561 576 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b577 : every 577 592 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
private theorem b593 : every 593 602 (line 1067535497223629304318420019363596 14236682727169030932514795166295 668174975995133185099361053138144 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 22=true := by
  apply row_low (h:=7262771478207969403253924490632) (A:=1067535497223629304318420019363596) (S:=14236682727169030932514795166295) (T:=668174975995133185099361053138144) (R:=24) (Q:=692) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬692≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 7262771478207969403253924490632 1067535497223629304318420019363596 14236682727169030932514795166295 5 692=602 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 b49)) (joinEvery (joinEvery b65 b81) (joinEvery b97 (joinEvery b113 b129)))) (joinEvery (joinEvery (joinEvery b145 b161) (joinEvery b177 (joinEvery b193 b209))) (joinEvery (joinEvery b225 b241) (joinEvery b257 (joinEvery b273 b289))))) (joinEvery (joinEvery (joinEvery (joinEvery b305 b321) (joinEvery b337 b353)) (joinEvery (joinEvery b369 b385) (joinEvery b401 (joinEvery b417 b433)))) (joinEvery (joinEvery (joinEvery b449 b465) (joinEvery b481 (joinEvery b497 b513))) (joinEvery (joinEvery b529 b545) (joinEvery b561 (joinEvery b577 b593))))))⟩
end OMA.EightAt23E22P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E23P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b385 : every 385 400 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b401 : every 401 416 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b417 : every 417 432 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b433 : every 433 448 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b449 : every 449 464 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b465 : every 465 480 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b481 : every 481 496 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b497 : every 497 512 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b513 : every 513 528 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b529 : every 529 544 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b545 : every 545 560 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b561 : every 561 576 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b577 : every 577 592 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b593 : every 593 608 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
private theorem b609 : every 609 624 (line 25622965865044773856719938722190388 327443702724887711447840288824800 16036199423883196442384665275315456 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 23=true := by
  apply row_low (h:=167043743998783296274840263284536) (A:=25622965865044773856719938722190388) (S:=327443702724887711447840288824800) (T:=16036199423883196442384665275315456) (R:=24) (Q:=734) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬734≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 167043743998783296274840263284536 25622965865044773856719938722190388 327443702724887711447840288824800 5 734=624 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 b49)) (joinEvery (joinEvery b65 b81) (joinEvery b97 (joinEvery b113 b129)))) (joinEvery (joinEvery (joinEvery b145 b161) (joinEvery b177 (joinEvery b193 b209))) (joinEvery (joinEvery b225 b241) (joinEvery b257 (joinEvery b273 b289))))) (joinEvery (joinEvery (joinEvery (joinEvery b305 b321) (joinEvery b337 (joinEvery b353 b369))) (joinEvery (joinEvery b385 b401) (joinEvery b417 (joinEvery b433 b449)))) (joinEvery (joinEvery (joinEvery b465 b481) (joinEvery b497 (joinEvery b513 b529))) (joinEvery (joinEvery b545 b561) (joinEvery b577 (joinEvery b593 b609))))))⟩
end OMA.EightAt23E23P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E24P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b385 : every 385 400 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b401 : every 401 416 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b417 : every 417 432 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b433 : every 433 448 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b449 : every 449 464 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b465 : every 465 480 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b481 : every 481 496 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b497 : every 497 512 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b513 : every 513 528 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b529 : every 529 544 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b545 : every 545 560 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b561 : every 561 576 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b577 : every 577 592 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b593 : every 593 608 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b609 : every 609 624 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b625 : every 625 640 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
private theorem b641 : every 641 646 (line 613930151760759695424672990977415613 7531205162672417363300326642970415 384200611197201581432132605554432800 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 24=true := by
  apply row_low (h:=3842006111972015814321326055544328) (A:=613930151760759695424672990977415613) (S:=7531205162672417363300326642970415) (T:=384200611197201581432132605554432800) (R:=24) (Q:=777) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬777≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 3842006111972015814321326055544328 613930151760759695424672990977415613 7531205162672417363300326642970415 5 777=646 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65))) (joinEvery (joinEvery b81 b97) (joinEvery b113 (joinEvery b129 b145)))) (joinEvery (joinEvery (joinEvery b161 b177) (joinEvery b193 (joinEvery b209 b225))) (joinEvery (joinEvery b241 b257) (joinEvery b273 (joinEvery b289 b305))))) (joinEvery (joinEvery (joinEvery (joinEvery b321 b337) (joinEvery b353 (joinEvery b369 b385))) (joinEvery (joinEvery b401 b417) (joinEvery b433 (joinEvery b449 b465)))) (joinEvery (joinEvery (joinEvery b481 b497) (joinEvery b513 (joinEvery b529 b545))) (joinEvery (joinEvery b561 (joinEvery b577 b593)) (joinEvery b609 (joinEvery b625 b641))))))⟩
end OMA.EightAt23E24P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E25P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b385 : every 385 400 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b401 : every 401 416 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b417 : every 417 432 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b433 : every 433 448 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b449 : every 449 464 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b465 : every 465 480 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b481 : every 481 496 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b497 : every 497 512 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b513 : every 513 528 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b529 : every 529 544 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b545 : every 545 560 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b561 : every 561 576 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b577 : every 577 592 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b593 : every 593 608 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b609 : every 609 624 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b625 : every 625 640 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b641 : every 641 656 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
private theorem b657 : every 657 668 (line 14686238038386260619330110000922402995 173217718741465599355907512788319560 9190078619837061827856611924862032576 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 25=true := by
  apply row_low (h:=88366140575356363729390499277519544) (A:=14686238038386260619330110000922402995) (S:=173217718741465599355907512788319560) (T:=9190078619837061827856611924862032576) (R:=24) (Q:=822) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬822≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 88366140575356363729390499277519544 14686238038386260619330110000922402995 173217718741465599355907512788319560 5 822=668 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65))) (joinEvery (joinEvery b81 b97) (joinEvery b113 (joinEvery b129 b145)))) (joinEvery (joinEvery (joinEvery b161 b177) (joinEvery b193 (joinEvery b209 b225))) (joinEvery (joinEvery b241 (joinEvery b257 b273)) (joinEvery b289 (joinEvery b305 b321))))) (joinEvery (joinEvery (joinEvery (joinEvery b337 b353) (joinEvery b369 (joinEvery b385 b401))) (joinEvery (joinEvery b417 b433) (joinEvery b449 (joinEvery b465 b481)))) (joinEvery (joinEvery (joinEvery b497 b513) (joinEvery b529 (joinEvery b545 b561))) (joinEvery (joinEvery b577 (joinEvery b593 b609)) (joinEvery b625 (joinEvery b641 b657))))))⟩
end OMA.EightAt23E25P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E26P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b385 : every 385 400 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b401 : every 401 416 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b417 : every 417 432 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b433 : every 433 448 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b449 : every 449 464 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b465 : every 465 480 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b481 : every 481 496 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b497 : every 497 512 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b513 : every 513 528 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b529 : every 529 544 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b545 : every 545 560 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b561 : every 561 576 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b577 : every 577 592 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b593 : every 593 608 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b609 : every 609 624 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b625 : every 625 640 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b641 : every 641 656 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b657 : every 657 672 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b673 : every 673 688 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
private theorem b689 : every 689 690 (line 350797899484326109609533047815377678542 3984007531053708785185872794131349895 219501493189185207503806000205358547296 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 26=true := by
  apply row_low (h:=2032421233233196365775981483382949512) (A:=350797899484326109609533047815377678542) (S:=3984007531053708785185872794131349895) (T:=219501493189185207503806000205358547296) (R:=24) (Q:=868) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬868≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 2032421233233196365775981483382949512 350797899484326109609533047815377678542 3984007531053708785185872794131349895 5 868=690 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65))) (joinEvery (joinEvery b81 (joinEvery b97 b113)) (joinEvery b129 (joinEvery b145 b161)))) (joinEvery (joinEvery (joinEvery b177 b193) (joinEvery b209 (joinEvery b225 b241))) (joinEvery (joinEvery b257 (joinEvery b273 b289)) (joinEvery b305 (joinEvery b321 b337))))) (joinEvery (joinEvery (joinEvery (joinEvery b353 b369) (joinEvery b385 (joinEvery b401 b417))) (joinEvery (joinEvery b433 (joinEvery b449 b465)) (joinEvery b481 (joinEvery b497 b513)))) (joinEvery (joinEvery (joinEvery b529 b545) (joinEvery b561 (joinEvery b577 b593))) (joinEvery (joinEvery b609 (joinEvery b625 b641)) (joinEvery b657 (joinEvery b673 b689))))))⟩
end OMA.EightAt23E26P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E27P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b385 : every 385 400 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b401 : every 401 416 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b417 : every 417 432 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b433 : every 433 448 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b449 : every 449 464 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b465 : every 465 480 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b481 : every 481 496 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b497 : every 497 512 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b513 : every 513 528 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b529 : every 529 544 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b545 : every 545 560 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b561 : every 561 576 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b577 : every 577 592 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b593 : every 593 608 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b609 : every 609 624 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b625 : every 625 640 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b641 : every 641 656 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b657 : every 657 672 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b673 : every 673 688 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b689 : every 689 704 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
private theorem b705 : every 705 712 (line 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5235517096808713838238928301194477942912 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 27=true := by
  apply row_low (h:=46745688364363516412847574117807838776) (A:=8367683453972669174412892009019422028626) (S:=91632173214235302059275074265021047600) (T:=5235517096808713838238928301194477942912) (R:=24) (Q:=916) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬916≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 46745688364363516412847574117807838776 8367683453972669174412892009019422028626 91632173214235302059275074265021047600 5 916=712 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65))) (joinEvery (joinEvery b81 (joinEvery b97 b113)) (joinEvery b129 (joinEvery b145 b161)))) (joinEvery (joinEvery (joinEvery b177 b193) (joinEvery b209 (joinEvery b225 b241))) (joinEvery (joinEvery b257 (joinEvery b273 b289)) (joinEvery b305 (joinEvery b321 b337))))) (joinEvery (joinEvery (joinEvery (joinEvery b353 b369) (joinEvery b385 (joinEvery b401 b417))) (joinEvery (joinEvery b433 (joinEvery b449 b465)) (joinEvery b481 (joinEvery b497 b513)))) (joinEvery (joinEvery (joinEvery b529 (joinEvery b545 b561)) (joinEvery b577 (joinEvery b593 b609))) (joinEvery (joinEvery b625 (joinEvery b641 b657)) (joinEvery b673 (joinEvery b689 b705))))))⟩
end OMA.EightAt23E27P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E28P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b385 : every 385 400 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b401 : every 401 416 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b417 : every 417 432 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b433 : every 433 448 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b449 : every 449 464 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b465 : every 465 480 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b481 : every 481 496 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b497 : every 497 512 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b513 : every 513 528 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b529 : every 529 544 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b545 : every 545 560 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b561 : every 561 576 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b577 : every 577 592 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b593 : every 593 608 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b609 : every 609 624 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b625 : every 625 640 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b641 : every 641 656 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b657 : every 657 672 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b673 : every 673 688 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b689 : every 689 704 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b705 : every 705 720 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
private theorem b721 : every 721 734 (line 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 124717496556121861789477327746311313854368 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 28=true := by
  apply row_low (h:=1075150832380360877495494204709580291848) (A:=199341350055534270039550050120558621368127) (S:=2107539983927411947363326708095484094815) (T:=124717496556121861789477327746311313854368) (R:=24) (Q:=965) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬965≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 1075150832380360877495494204709580291848 199341350055534270039550050120558621368127 2107539983927411947363326708095484094815 5 965=734 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65))) (joinEvery (joinEvery b81 (joinEvery b97 b113)) (joinEvery b129 (joinEvery b145 b161)))) (joinEvery (joinEvery (joinEvery b177 (joinEvery b193 b209)) (joinEvery b225 (joinEvery b241 b257))) (joinEvery (joinEvery b273 (joinEvery b289 b305)) (joinEvery b321 (joinEvery b337 b353))))) (joinEvery (joinEvery (joinEvery (joinEvery b369 b385) (joinEvery b401 (joinEvery b417 b433))) (joinEvery (joinEvery b449 (joinEvery b465 b481)) (joinEvery b497 (joinEvery b513 b529)))) (joinEvery (joinEvery (joinEvery b545 (joinEvery b561 b577)) (joinEvery b593 (joinEvery b609 b625))) (joinEvery (joinEvery b641 (joinEvery b657 b673)) (joinEvery b689 (joinEvery b705 b721))))))⟩
end OMA.EightAt23E28P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E29P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b385 : every 385 400 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b401 : every 401 416 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b417 : every 417 432 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b433 : every 433 448 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b449 : every 449 464 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b465 : every 465 480 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b481 : every 481 496 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b497 : every 497 512 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b513 : every 513 528 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b529 : every 529 544 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b545 : every 545 560 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b561 : every 561 576 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b577 : every 577 592 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b593 : every 593 608 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b609 : every 609 624 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b625 : every 625 640 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b641 : every 641 656 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b657 : every 657 672 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b673 : every 673 688 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b689 : every 689 704 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b705 : every 705 720 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b721 : every 721 736 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b737 : every 737 752 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
private theorem b753 : every 753 756 (line 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 2967416297369796021887564004998441605500480 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 29=true := by
  apply row_low (h:=24728469144748300182396366708320346712504) (A:=4743197555403034428554882432774422329790737) (S:=48473419630330474789356514286196134180760) (T:=2967416297369796021887564004998441605500480) (R:=24) (Q:=1016) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬1016≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 24728469144748300182396366708320346712504 4743197555403034428554882432774422329790737 48473419630330474789356514286196134180760 5 1016=756 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery b145 (joinEvery b161 b177)))) (joinEvery (joinEvery (joinEvery b193 (joinEvery b209 b225)) (joinEvery b241 (joinEvery b257 b273))) (joinEvery (joinEvery b289 (joinEvery b305 b321)) (joinEvery b337 (joinEvery b353 b369))))) (joinEvery (joinEvery (joinEvery (joinEvery b385 (joinEvery b401 b417)) (joinEvery b433 (joinEvery b449 b465))) (joinEvery (joinEvery b481 (joinEvery b497 b513)) (joinEvery b529 (joinEvery b545 b561)))) (joinEvery (joinEvery (joinEvery b577 (joinEvery b593 b609)) (joinEvery b625 (joinEvery b641 b657))) (joinEvery (joinEvery b673 (joinEvery b689 b705)) (joinEvery b721 (joinEvery b737 b753))))))⟩
end OMA.EightAt23E29P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E30P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b385 : every 385 400 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b401 : every 401 416 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b417 : every 417 432 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b433 : every 433 448 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b449 : every 449 464 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b465 : every 465 480 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b481 : every 481 496 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b497 : every 497 512 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b513 : every 513 528 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b529 : every 529 544 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b545 : every 545 560 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b561 : every 561 576 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b577 : every 577 592 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b593 : every 593 608 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b609 : every 609 624 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b625 : every 625 640 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b641 : every 641 656 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b657 : every 657 672 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b673 : every 673 688 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b689 : every 689 704 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b705 : every 705 720 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b721 : every 721 736 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b737 : every 737 752 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b753 : every 753 768 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
private theorem b769 : every 769 783 (line 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 70525594000822152120194437852129628824061408 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 30=true := by
  apply row_low (h:=568754790329210904195116434291367974387592) (A:=112735513369161954862602615393847916466634768) (S:=1114888651497600920155199828582511086157495) (T:=70525594000822152120194437852129628824061408) (R:=24) (Q:=1070) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬1070≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 568754790329210904195116434291367974387592 112735513369161954862602615393847916466634768 1114888651497600920155199828582511086157495 5 1070=783 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery b145 (joinEvery b161 b177)))) (joinEvery (joinEvery (joinEvery b193 (joinEvery b209 b225)) (joinEvery b241 (joinEvery b257 b273))) (joinEvery (joinEvery b289 (joinEvery b305 b321)) (joinEvery b337 (joinEvery b353 b369))))) (joinEvery (joinEvery (joinEvery (joinEvery b385 (joinEvery b401 b417)) (joinEvery b433 (joinEvery b449 b465))) (joinEvery (joinEvery b481 (joinEvery b497 b513)) (joinEvery b529 (joinEvery b545 b561)))) (joinEvery (joinEvery (joinEvery b577 (joinEvery b593 b609)) (joinEvery b625 (joinEvery b641 b657))) (joinEvery (joinEvery b673 (joinEvery b689 b705)) (joinEvery (joinEvery b721 b737) (joinEvery b753 b769))))))⟩
end OMA.EightAt23E30P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E31P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b385 : every 385 400 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b401 : every 401 416 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b417 : every 417 432 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b433 : every 433 448 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b449 : every 449 464 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b465 : every 465 480 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b481 : every 481 496 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b497 : every 497 512 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b513 : every 513 528 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b529 : every 529 544 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b545 : every 545 560 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b561 : every 561 576 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b577 : every 577 592 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b593 : every 593 608 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b609 : every 609 624 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b625 : every 625 640 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b641 : every 641 656 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b657 : every 657 672 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b673 : every 673 688 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b689 : every 689 704 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b705 : every 705 720 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b721 : every 721 736 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b737 : every 737 752 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b753 : every 753 768 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b769 : every 769 784 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
private theorem b785 : every 785 800 (line 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 1674414102729196901950422782553787316597070848 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 31=true := by
  apply row_low (h:=13081360177571850796487677988701463410914616) (A:=2676682108173244710974187501179334745005899504) (S:=25642438984444821163569596057397754981622400) (T:=1674414102729196901950422782553787316597070848) (R:=24) (Q:=1125) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬1125≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 13081360177571850796487677988701463410914616 2676682108173244710974187501179334745005899504 25642438984444821163569596057397754981622400 5 1125=800 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery b145 (joinEvery b161 b177)))) (joinEvery (joinEvery (joinEvery b193 (joinEvery b209 b225)) (joinEvery b241 (joinEvery b257 b273))) (joinEvery (joinEvery b289 (joinEvery b305 b321)) (joinEvery (joinEvery b337 b353) (joinEvery b369 b385))))) (joinEvery (joinEvery (joinEvery (joinEvery b401 (joinEvery b417 b433)) (joinEvery b449 (joinEvery b465 b481))) (joinEvery (joinEvery b497 (joinEvery b513 b529)) (joinEvery b545 (joinEvery b561 b577)))) (joinEvery (joinEvery (joinEvery b593 (joinEvery b609 b625)) (joinEvery b641 (joinEvery b657 b673))) (joinEvery (joinEvery b689 (joinEvery b705 b721)) (joinEvery (joinEvery b737 b753) (joinEvery b769 b785))))))⟩
end OMA.EightAt23E31P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E32P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b385 : every 385 400 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b401 : every 401 416 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b417 : every 417 432 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b433 : every 433 448 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b449 : every 449 464 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b465 : every 465 480 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b481 : every 481 496 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b497 : every 497 512 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b513 : every 513 528 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b529 : every 529 544 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b545 : every 545 560 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b561 : every 561 576 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b577 : every 577 592 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b593 : every 593 608 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b609 : every 609 624 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b625 : every 625 640 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b641 : every 641 656 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b657 : every 657 672 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b673 : every 673 688 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b689 : every 689 704 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b705 : every 705 720 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b721 : every 721 736 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b737 : every 737 752 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b753 : every 753 768 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b769 : every 769 784 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b785 : every 785 800 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b801 : every 801 816 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
private theorem b817 : every 817 822 (line 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 39715009499108139018136590373697642915536774176 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 32=true := by
  apply row_low (h:=300871284084152568319216593740133658451036168) (A:=63490290403682582582495841510903850459421584961) (S:=589776096642230886762100709320148364577315215) (T:=39715009499108139018136590373697642915536774176) (R:=24) (Q:=1182) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬1182≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 300871284084152568319216593740133658451036168 63490290403682582582495841510903850459421584961 589776096642230886762100709320148364577315215 5 1182=822 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery (joinEvery b145 b161) (joinEvery b177 b193)))) (joinEvery (joinEvery (joinEvery b209 (joinEvery b225 b241)) (joinEvery b257 (joinEvery b273 b289))) (joinEvery (joinEvery b305 (joinEvery b321 b337)) (joinEvery (joinEvery b353 b369) (joinEvery b385 b401))))) (joinEvery (joinEvery (joinEvery (joinEvery b417 (joinEvery b433 b449)) (joinEvery b465 (joinEvery b481 b497))) (joinEvery (joinEvery b513 (joinEvery b529 b545)) (joinEvery (joinEvery b561 b577) (joinEvery b593 b609)))) (joinEvery (joinEvery (joinEvery b625 (joinEvery b641 b657)) (joinEvery b673 (joinEvery b689 b705))) (joinEvery (joinEvery b721 (joinEvery b737 b753)) (joinEvery (joinEvery b769 b785) (joinEvery b801 b817))))))⟩
end OMA.EightAt23E32P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E33P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b385 : every 385 400 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b401 : every 401 416 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b417 : every 417 432 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b433 : every 433 448 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b449 : every 449 464 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b465 : every 465 480 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b481 : every 481 496 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b497 : every 497 512 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b513 : every 513 528 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b529 : every 529 544 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b545 : every 545 560 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b561 : every 561 576 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b577 : every 577 592 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b593 : every 593 608 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b609 : every 609 624 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b625 : every 625 640 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b641 : every 641 656 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b657 : every 657 672 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b673 : every 673 688 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b689 : every 689 704 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b705 : every 705 720 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b721 : every 721 736 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b737 : every 737 752 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b753 : every 753 768 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b769 : every 769 784 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b785 : every 785 800 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b801 : every 801 816 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b817 : every 817 832 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
private theorem b833 : every 833 844 (line 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 941125376615229233702509505219138083634841133504 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 33=true := by
  apply row_low (h:=6920039533935509071341981656023074144373831864) (A:=1504588523345752346689463521377709041025272070639) (S:=13564850222771310395528316314363412385278249960) (T:=941125376615229233702509505219138083634841133504) (R:=24) (Q:=1242) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬1242≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 6920039533935509071341981656023074144373831864 1504588523345752346689463521377709041025272070639 13564850222771310395528316314363412385278249960 5 1242=844 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery (joinEvery b145 b161) (joinEvery b177 b193)))) (joinEvery (joinEvery (joinEvery b209 (joinEvery b225 b241)) (joinEvery b257 (joinEvery b273 b289))) (joinEvery (joinEvery b305 (joinEvery b321 b337)) (joinEvery (joinEvery b353 b369) (joinEvery b385 b401))))) (joinEvery (joinEvery (joinEvery (joinEvery b417 (joinEvery b433 b449)) (joinEvery b465 (joinEvery b481 b497))) (joinEvery (joinEvery b513 (joinEvery b529 b545)) (joinEvery (joinEvery b561 b577) (joinEvery b593 b609)))) (joinEvery (joinEvery (joinEvery b625 (joinEvery b641 b657)) (joinEvery (joinEvery b673 b689) (joinEvery b705 b721))) (joinEvery (joinEvery b737 (joinEvery b753 b769)) (joinEvery (joinEvery b785 b801) (joinEvery b817 b833))))))⟩
end OMA.EightAt23E33P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E34P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b385 : every 385 400 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b401 : every 401 416 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b417 : every 417 432 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b433 : every 433 448 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b449 : every 449 464 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b465 : every 465 480 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b481 : every 481 496 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b497 : every 497 512 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b513 : every 513 528 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b529 : every 529 544 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b545 : every 545 560 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b561 : every 561 576 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b577 : every 577 592 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b593 : every 593 608 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b609 : every 609 624 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b625 : every 625 640 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b641 : every 641 656 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b657 : every 657 672 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b673 : every 673 688 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b689 : every 689 704 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b705 : every 705 720 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b721 : every 721 736 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b737 : every 737 752 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b753 : every 753 768 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b769 : every 769 784 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b785 : every 785 800 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b801 : every 801 816 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b817 : every 817 832 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b833 : every 833 848 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b849 : every 849 864 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
private theorem b865 : every 865 866 (line 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 22282527299272339209721180932394298744883738602080 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 34=true := by
  apply row_low (h:=159160909280516708640865578088530705320598132872) (A:=35624708450356521761575021824106478994128496805074) (S:=311991555123740139097151275230358484861399749095) (T:=22282527299272339209721180932394298744883738602080) (R:=24) (Q:=1304) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬1304≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 159160909280516708640865578088530705320598132872 35624708450356521761575021824106478994128496805074 311991555123740139097151275230358484861399749095 5 1304=866 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery (joinEvery b145 b161) (joinEvery b177 b193)))) (joinEvery (joinEvery (joinEvery b209 (joinEvery b225 b241)) (joinEvery (joinEvery b257 b273) (joinEvery b289 b305))) (joinEvery (joinEvery b321 (joinEvery b337 b353)) (joinEvery (joinEvery b369 b385) (joinEvery b401 b417))))) (joinEvery (joinEvery (joinEvery (joinEvery b433 (joinEvery b449 b465)) (joinEvery (joinEvery b481 b497) (joinEvery b513 b529))) (joinEvery (joinEvery b545 (joinEvery b561 b577)) (joinEvery (joinEvery b593 b609) (joinEvery b625 b641)))) (joinEvery (joinEvery (joinEvery b657 (joinEvery b673 b689)) (joinEvery (joinEvery b705 b721) (joinEvery b737 b753))) (joinEvery (joinEvery b769 (joinEvery b785 b801)) (joinEvery (joinEvery b817 b833) (joinEvery b849 b865))))))⟩
end OMA.EightAt23E34P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E35P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b385 : every 385 400 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b401 : every 401 416 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b417 : every 417 432 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b433 : every 433 448 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b449 : every 449 464 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b465 : every 465 480 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b481 : every 481 496 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b497 : every 497 512 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b513 : every 513 528 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b529 : every 529 544 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b545 : every 545 560 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b561 : every 561 576 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b577 : every 577 592 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b593 : every 593 608 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b609 : every 609 624 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b625 : every 625 640 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b641 : every 641 656 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b657 : every 657 672 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b673 : every 673 688 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b689 : every 689 704 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b705 : every 705 720 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b721 : every 721 736 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b737 : every 737 752 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b753 : every 753 768 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b769 : every 769 784 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b785 : every 785 800 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b801 : every 801 816 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b817 : every 817 832 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b833 : every 833 848 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b849 : every 849 864 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b865 : every 865 880 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
private theorem b881 : every 881 888 (line 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 527140931537071339018546794629213696021821016072064 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 35=true := by
  apply row_low (h:=3660700913451884298739908296036206222373757056056) (A:=842809259866497009633724801100089951027541927665422) (S:=7175805767846023199234479330298245151812194229200) (T:=527140931537071339018546794629213696021821016072064) (R:=24) (Q:=1368) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬1368≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 3660700913451884298739908296036206222373757056056 842809259866497009633724801100089951027541927665422 7175805767846023199234479330298245151812194229200 5 1368=888 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97))) (joinEvery (joinEvery b113 (joinEvery b129 b145)) (joinEvery (joinEvery b161 b177) (joinEvery b193 b209)))) (joinEvery (joinEvery (joinEvery b225 (joinEvery b241 b257)) (joinEvery (joinEvery b273 b289) (joinEvery b305 b321))) (joinEvery (joinEvery b337 (joinEvery b353 b369)) (joinEvery (joinEvery b385 b401) (joinEvery b417 b433))))) (joinEvery (joinEvery (joinEvery (joinEvery b449 (joinEvery b465 b481)) (joinEvery (joinEvery b497 b513) (joinEvery b529 b545))) (joinEvery (joinEvery b561 (joinEvery b577 b593)) (joinEvery (joinEvery b609 b625) (joinEvery b641 b657)))) (joinEvery (joinEvery (joinEvery b673 (joinEvery b689 b705)) (joinEvery (joinEvery b721 b737) (joinEvery b753 b769))) (joinEvery (joinEvery b785 (joinEvery b801 b817)) (joinEvery (joinEvery b833 b849) (joinEvery b865 b881))))))⟩
end OMA.EightAt23E35P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E36P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b385 : every 385 400 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b401 : every 401 416 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b417 : every 417 432 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b433 : every 433 448 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b449 : every 449 464 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b465 : every 465 480 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b481 : every 481 496 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b497 : every 497 512 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b513 : every 513 528 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b529 : every 529 544 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b545 : every 545 560 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b561 : every 561 576 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b577 : every 577 592 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b593 : every 593 608 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b609 : every 609 624 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b625 : every 625 640 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b641 : every 641 656 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b657 : every 657 672 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b673 : every 673 688 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b689 : every 689 704 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b705 : every 705 720 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b721 : every 721 736 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b737 : every 737 752 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b753 : every 753 768 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b769 : every 769 784 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b785 : every 785 800 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b801 : every 801 816 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b817 : every 817 832 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b833 : every 833 848 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b849 : every 849 864 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b865 : every 865 880 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b881 : every 881 896 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
private theorem b897 : every 897 910 (line 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 12461025909390214152910647839707245980960269018814624 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 36=true := by
  apply row_low (h:=84196121009393338871017890808832743114596412289288) (A:=19923755183620262431278154305651810359372953862725315) (S:=165043532660458533582393024596859638491680467271615) (T:=12461025909390214152910647839707245980960269018814624) (R:=24) (Q:=1435) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬1435≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 84196121009393338871017890808832743114596412289288 19923755183620262431278154305651810359372953862725315 165043532660458533582393024596859638491680467271615 5 1435=910 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97))) (joinEvery (joinEvery b113 (joinEvery b129 b145)) (joinEvery (joinEvery b161 b177) (joinEvery b193 b209)))) (joinEvery (joinEvery (joinEvery b225 (joinEvery b241 b257)) (joinEvery (joinEvery b273 b289) (joinEvery b305 b321))) (joinEvery (joinEvery b337 (joinEvery b353 b369)) (joinEvery (joinEvery b385 b401) (joinEvery b417 b433))))) (joinEvery (joinEvery (joinEvery (joinEvery b449 (joinEvery b465 b481)) (joinEvery (joinEvery b497 b513) (joinEvery b529 b545))) (joinEvery (joinEvery b561 (joinEvery b577 b593)) (joinEvery (joinEvery b609 b625) (joinEvery b641 b657)))) (joinEvery (joinEvery (joinEvery b673 (joinEvery b689 b705)) (joinEvery (joinEvery b721 b737) (joinEvery b753 b769))) (joinEvery (joinEvery (joinEvery b785 b801) (joinEvery b817 b833)) (joinEvery (joinEvery b849 b865) (joinEvery b881 b897))))))⟩
end OMA.EightAt23E36P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E37P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b385 : every 385 400 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b401 : every 401 416 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b417 : every 417 432 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b433 : every 433 448 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b449 : every 449 464 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b465 : every 465 480 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b481 : every 481 496 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b497 : every 497 512 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b513 : every 513 528 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b529 : every 529 544 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b545 : every 545 560 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b561 : every 561 576 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b577 : every 577 592 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b593 : every 593 608 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b609 : every 609 624 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b625 : every 625 640 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b641 : every 641 656 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b657 : every 657 672 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b673 : every 673 688 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b689 : every 689 704 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b705 : every 705 720 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b721 : every 721 736 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b737 : every 737 752 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b753 : every 753 768 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b769 : every 769 784 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b785 : every 785 800 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b801 : every 801 816 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b817 : every 817 832 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b833 : every 833 848 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b849 : every 849 864 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b865 : every 865 880 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b881 : every 881 896 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b897 : every 897 912 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b913 : every 913 928 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
private theorem b929 : every 929 932 (line 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 294349639048839112693078546267679269928629057363350848 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 37=true := by
  apply row_low (h:=1936510783216046794033411488603153091635717482653624) (A:=470646639977155153742554678278035692437586197950356301) (S:=3796001251190546272395039565727771685308650747247160) (T:=294349639048839112693078546267679269928629057363350848) (R:=24) (Q:=1505) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬1505≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 1936510783216046794033411488603153091635717482653624 470646639977155153742554678278035692437586197950356301 3796001251190546272395039565727771685308650747247160 5 1505=932 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97))) (joinEvery (joinEvery b113 (joinEvery b129 b145)) (joinEvery (joinEvery b161 b177) (joinEvery b193 b209)))) (joinEvery (joinEvery (joinEvery b225 (joinEvery b241 b257)) (joinEvery (joinEvery b273 b289) (joinEvery b305 b321))) (joinEvery (joinEvery (joinEvery b337 b353) (joinEvery b369 b385)) (joinEvery (joinEvery b401 b417) (joinEvery b433 b449))))) (joinEvery (joinEvery (joinEvery (joinEvery b465 (joinEvery b481 b497)) (joinEvery (joinEvery b513 b529) (joinEvery b545 b561))) (joinEvery (joinEvery (joinEvery b577 b593) (joinEvery b609 b625)) (joinEvery (joinEvery b641 b657) (joinEvery b673 b689)))) (joinEvery (joinEvery (joinEvery b705 (joinEvery b721 b737)) (joinEvery (joinEvery b753 b769) (joinEvery b785 b801))) (joinEvery (joinEvery (joinEvery b817 b833) (joinEvery b849 b865)) (joinEvery (joinEvery b881 b897) (joinEvery b913 b929))))))⟩
end OMA.EightAt23E37P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E38P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b385 : every 385 400 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b401 : every 401 416 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b417 : every 417 432 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b433 : every 433 448 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b449 : every 449 464 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b465 : every 465 480 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b481 : every 481 496 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b497 : every 497 512 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b513 : every 513 528 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b529 : every 529 544 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b545 : every 545 560 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b561 : every 561 576 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b577 : every 577 592 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b593 : every 593 608 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b609 : every 609 624 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b625 : every 625 640 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b641 : every 641 656 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b657 : every 657 672 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b673 : every 673 688 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b689 : every 689 704 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b705 : every 705 720 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b721 : every 721 736 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b737 : every 737 752 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b753 : every 753 768 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b769 : every 769 784 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b785 : every 785 800 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b801 : every 801 816 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b817 : every 817 832 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b833 : every 833 848 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b849 : every 849 864 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b865 : every 865 880 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b881 : every 881 896 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b897 : every 897 912 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b913 : every 913 928 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b929 : every 929 944 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
private theorem b945 : every 945 954 (line 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 6948200690179175896991880421108113292788954327761202912 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 38=true := by
  apply row_low (h:=44539748013969076262768464237872521107621502101033352) (A:=11110078946814018246011371573099834172020672512334698260) (S:=87308028777382564265085910011738748762098967186684695) (T:=6948200690179175896991880421108113292788954327761202912) (R:=24) (Q:=1578) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬1578≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 44539748013969076262768464237872521107621502101033352 11110078946814018246011371573099834172020672512334698260 87308028777382564265085910011738748762098967186684695 5 1578=954 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97))) (joinEvery (joinEvery (joinEvery b113 b129) (joinEvery b145 b161)) (joinEvery (joinEvery b177 b193) (joinEvery b209 b225)))) (joinEvery (joinEvery (joinEvery b241 (joinEvery b257 b273)) (joinEvery (joinEvery b289 b305) (joinEvery b321 b337))) (joinEvery (joinEvery (joinEvery b353 b369) (joinEvery b385 b401)) (joinEvery (joinEvery b417 b433) (joinEvery b449 b465))))) (joinEvery (joinEvery (joinEvery (joinEvery b481 (joinEvery b497 b513)) (joinEvery (joinEvery b529 b545) (joinEvery b561 b577))) (joinEvery (joinEvery (joinEvery b593 b609) (joinEvery b625 b641)) (joinEvery (joinEvery b657 b673) (joinEvery b689 b705)))) (joinEvery (joinEvery (joinEvery b721 (joinEvery b737 b753)) (joinEvery (joinEvery b769 b785) (joinEvery b801 b817))) (joinEvery (joinEvery (joinEvery b833 b849) (joinEvery b865 b881)) (joinEvery (joinEvery b897 b913) (joinEvery b929 b945))))))⟩
end OMA.EightAt23E38P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E39P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b385 : every 385 400 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b401 : every 401 416 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b417 : every 417 432 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b433 : every 433 448 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b449 : every 449 464 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b465 : every 465 480 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b481 : every 481 496 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b497 : every 497 512 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b513 : every 513 528 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b529 : every 529 544 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b545 : every 545 560 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b561 : every 561 576 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b577 : every 577 592 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b593 : every 593 608 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b609 : every 609 624 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b625 : every 625 640 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b641 : every 641 656 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b657 : every 657 672 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b673 : every 673 688 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b689 : every 689 704 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b705 : every 705 720 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b721 : every 721 736 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b737 : every 737 752 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b753 : every 753 768 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b769 : every 769 784 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b785 : every 785 800 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b801 : every 801 816 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b817 : every 817 832 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b833 : every 833 848 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b849 : every 849 864 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b865 : every 865 880 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b881 : every 881 896 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b897 : every 897 912 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b913 : every 913 928 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b929 : every 929 944 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b945 : every 945 960 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
private theorem b961 : every 961 976 (line 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 163906272691406200646987948395370877676047127731802735360 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 39=true := by
  apply row_low (h:=1024414204321288754043674677471067985475294548323767096) (A:=262091559005529762986711667553511490613467836851657636780) (S:=2008084661879798978096975930269991221528276245293748000) (T:=163906272691406200646987948395370877676047127731802735360) (R:=24) (Q:=1654) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬1654≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 1024414204321288754043674677471067985475294548323767096 262091559005529762986711667553511490613467836851657636780 2008084661879798978096975930269991221528276245293748000 5 1654=976 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97))) (joinEvery (joinEvery (joinEvery b113 b129) (joinEvery b145 b161)) (joinEvery (joinEvery b177 b193) (joinEvery b209 b225)))) (joinEvery (joinEvery (joinEvery b241 (joinEvery b257 b273)) (joinEvery (joinEvery b289 b305) (joinEvery b321 b337))) (joinEvery (joinEvery (joinEvery b353 b369) (joinEvery b385 b401)) (joinEvery (joinEvery b417 b433) (joinEvery b449 b465))))) (joinEvery (joinEvery (joinEvery (joinEvery b481 (joinEvery b497 b513)) (joinEvery (joinEvery b529 b545) (joinEvery b561 b577))) (joinEvery (joinEvery (joinEvery b593 b609) (joinEvery b625 b641)) (joinEvery (joinEvery b657 b673) (joinEvery b689 b705)))) (joinEvery (joinEvery (joinEvery (joinEvery b721 b737) (joinEvery b753 b769)) (joinEvery (joinEvery b785 b801) (joinEvery b817 b833))) (joinEvery (joinEvery (joinEvery b849 b865) (joinEvery b881 b897)) (joinEvery (joinEvery b913 b929) (joinEvery b945 b961))))))⟩
end OMA.EightAt23E39P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt23E40P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b225 : every 225 240 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b241 : every 241 256 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b257 : every 257 272 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b273 : every 273 288 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b289 : every 289 304 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b305 : every 305 320 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b321 : every 321 336 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b337 : every 337 352 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b353 : every 353 368 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b369 : every 369 384 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b385 : every 385 400 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b401 : every 401 416 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b417 : every 417 432 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b433 : every 433 448 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b449 : every 449 464 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b465 : every 465 480 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b481 : every 481 496 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b497 : every 497 512 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b513 : every 513 528 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b529 : every 529 544 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b545 : every 545 560 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b561 : every 561 576 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b577 : every 577 592 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b593 : every 593 608 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b609 : every 609 624 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b625 : every 625 640 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b641 : every 641 656 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b657 : every 657 672 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b673 : every 673 688 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b689 : every 689 704 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b705 : every 705 720 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b721 : every 721 736 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b737 : every 737 752 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b753 : every 753 768 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b769 : every 769 784 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b785 : every 785 800 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b801 : every 801 816 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b817 : every 817 832 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b833 : every 833 848 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b849 : every 849 864 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b865 : every 865 880 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b881 : every 881 896 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b897 : every 897 912 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b913 : every 913 928 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b929 : every 929 944 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b945 : every 945 960 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b961 : every 961 976 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b977 : every 977 992 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
private theorem b993 : every 993 998 (line 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 3864090378699901180252740883420868441212811036277249486112 5 24)=true := by decide +kernel
theorem certificate : atom 23 5 40=true := by
  apply row_low (h:=23561526699389641343004517581834563665931774611446643208) (A:=6178979951389753445248721145291716291220584736151195912389) (S:=46185947223235376496230446396209798095150353641756204015) (T:=3864090378699901180252740883420868441212811036277249486112) (R:=24) (Q:=1734) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬1734≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 23561526699389641343004517581834563665931774611446643208 6178979951389753445248721145291716291220584736151195912389 46185947223235376496230446396209798095150353641756204015 5 1734=998 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97))) (joinEvery (joinEvery (joinEvery b113 b129) (joinEvery b145 b161)) (joinEvery (joinEvery b177 b193) (joinEvery b209 b225)))) (joinEvery (joinEvery (joinEvery (joinEvery b241 b257) (joinEvery b273 b289)) (joinEvery (joinEvery b305 b321) (joinEvery b337 b353))) (joinEvery (joinEvery (joinEvery b369 b385) (joinEvery b401 b417)) (joinEvery (joinEvery b433 b449) (joinEvery b465 b481))))) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b497 b513) (joinEvery b529 b545)) (joinEvery (joinEvery b561 b577) (joinEvery b593 b609))) (joinEvery (joinEvery (joinEvery b625 b641) (joinEvery b657 b673)) (joinEvery (joinEvery b689 b705) (joinEvery b721 b737)))) (joinEvery (joinEvery (joinEvery (joinEvery b753 b769) (joinEvery b785 b801)) (joinEvery (joinEvery b817 b833) (joinEvery b849 b865))) (joinEvery (joinEvery (joinEvery b881 b897) (joinEvery b913 b929)) (joinEvery (joinEvery b945 b961) (joinEvery b977 b993))))))⟩
end OMA.EightAt23E40P5

namespace OMA.EightShort23To40P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeMiddle245212 (joinEvery)
theorem certificate : every 1 40 (atom 23 5)=true := (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery (single (f:=atom 23 5) OMA.EightAt23E1P5.certificate) (single (f:=atom 23 5) OMA.EightAt23E2P5.certificate)) (joinEvery (single (f:=atom 23 5) OMA.EightAt23E3P5.certificate) (joinEvery (single (f:=atom 23 5) OMA.EightAt23E4P5.certificate) (single (f:=atom 23 5) OMA.EightAt23E5P5.certificate)))) (joinEvery (joinEvery (single (f:=atom 23 5) OMA.EightAt23E6P5.certificate) (single (f:=atom 23 5) OMA.EightAt23E7P5.certificate)) (joinEvery (single (f:=atom 23 5) OMA.EightAt23E8P5.certificate) (joinEvery (single (f:=atom 23 5) OMA.EightAt23E9P5.certificate) (single (f:=atom 23 5) OMA.EightAt23E10P5.certificate))))) (joinEvery (joinEvery (joinEvery (single (f:=atom 23 5) OMA.EightAt23E11P5.certificate) (single (f:=atom 23 5) OMA.EightAt23E12P5.certificate)) (joinEvery (single (f:=atom 23 5) OMA.EightAt23E13P5.certificate) (joinEvery (single (f:=atom 23 5) OMA.EightAt23E14P5.certificate) (single (f:=atom 23 5) OMA.EightAt23E15P5.certificate)))) (joinEvery (joinEvery (single (f:=atom 23 5) OMA.EightAt23E16P5.certificate) (single (f:=atom 23 5) OMA.EightAt23E17P5.certificate)) (joinEvery (single (f:=atom 23 5) OMA.EightAt23E18P5.certificate) (joinEvery (single (f:=atom 23 5) OMA.EightAt23E19P5.certificate) (single (f:=atom 23 5) OMA.EightAt23E20P5.certificate)))))) (joinEvery (joinEvery (joinEvery (joinEvery (single (f:=atom 23 5) OMA.EightAt23E21P5.certificate) (single (f:=atom 23 5) OMA.EightAt23E22P5.certificate)) (joinEvery (single (f:=atom 23 5) OMA.EightAt23E23P5.certificate) (joinEvery (single (f:=atom 23 5) OMA.EightAt23E24P5.certificate) (single (f:=atom 23 5) OMA.EightAt23E25P5.certificate)))) (joinEvery (joinEvery (single (f:=atom 23 5) OMA.EightAt23E26P5.certificate) (single (f:=atom 23 5) OMA.EightAt23E27P5.certificate)) (joinEvery (single (f:=atom 23 5) OMA.EightAt23E28P5.certificate) (joinEvery (single (f:=atom 23 5) OMA.EightAt23E29P5.certificate) (single (f:=atom 23 5) OMA.EightAt23E30P5.certificate))))) (joinEvery (joinEvery (joinEvery (single (f:=atom 23 5) OMA.EightAt23E31P5.certificate) (single (f:=atom 23 5) OMA.EightAt23E32P5.certificate)) (joinEvery (single (f:=atom 23 5) OMA.EightAt23E33P5.certificate) (joinEvery (single (f:=atom 23 5) OMA.EightAt23E34P5.certificate) (single (f:=atom 23 5) OMA.EightAt23E35P5.certificate)))) (joinEvery (joinEvery (single (f:=atom 23 5) OMA.EightAt23E36P5.certificate) (single (f:=atom 23 5) OMA.EightAt23E37P5.certificate)) (joinEvery (single (f:=atom 23 5) OMA.EightAt23E38P5.certificate) (joinEvery (single (f:=atom 23 5) OMA.EightAt23E39P5.certificate) (single (f:=atom 23 5) OMA.EightAt23E40P5.certificate)))))))
end OMA.EightShort23To40P5
