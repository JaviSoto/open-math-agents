import RankThreeEightFixed245212
/-! Kernel certificates for one ordered pair of odd bases at dyadic factor eight. -/
namespace OMA.EightRows5x29
open OMA.RankThreeEightFixed245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
theorem row31 : tests 5 29 31=true := by decide +kernel
theorem row37 : tests 5 29 37=true := by decide +kernel
theorem row41 : tests 5 29 41=true := by decide +kernel
theorem row43 : tests 5 29 43=true := by decide +kernel
theorem row47 : tests 5 29 47=true := by decide +kernel
theorem row53 : tests 5 29 53=true := by decide +kernel
theorem row59 : tests 5 29 59=true := by decide +kernel
theorem row61 : tests 5 29 61=true := by decide +kernel
theorem row67 : tests 5 29 67=true := by decide +kernel
theorem row71 : tests 5 29 71=true := by decide +kernel
theorem row73 : tests 5 29 73=true := by decide +kernel
theorem row79 : tests 5 29 79=true := by decide +kernel
theorem row83 : tests 5 29 83=true := by decide +kernel
theorem row89 : tests 5 29 89=true := by decide +kernel
theorem row97 : tests 5 29 97=true := by decide +kernel
theorem row101 : tests 5 29 101=true := by decide +kernel
theorem row103 : tests 5 29 103=true := by decide +kernel
theorem row107 : tests 5 29 107=true := by decide +kernel
theorem row109 : tests 5 29 109=true := by decide +kernel
theorem row113 : tests 5 29 113=true := by decide +kernel
end OMA.EightRows5x29
