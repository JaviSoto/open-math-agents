import RankThreeFiveFar245212
/-! Check the terminal divisor counts above the middle-prime cutoff. -/
namespace OMA.FiveFar4x21
open OMA.RankThreeFiveFar245212 OMA.CofactorEulerPair245212
open OMA.RankThreeMiddle245212 (joinEvery)
open OMA.RankThreeEightMoving245212 (single)
set_option maxHeartbeats 2400000
set_option maxRecDepth 65536
private theorem local4_2 : every 2 2 (splitPair 1672357320785522469 18477439880371086 839233398437500000 1099 4)=true := by decide +kernel
private theorem n4 : every 4 4 (bucket 1672357320785522469 18477439880371086 839233398437500000 1099)=true := single local4_2
private theorem local5_2 : every 2 2 (splitPair 1672357320785522469 18477439880371086 839233398437500000 1099 5)=true := by decide +kernel
private theorem n5 : every 5 5 (bucket 1672357320785522469 18477439880371086 839233398437500000 1099)=true := single local5_2
private theorem local6_2 : every 2 3 (splitPair 1672357320785522469 18477439880371086 839233398437500000 1099 6)=true := by decide +kernel
private theorem n6 : every 6 6 (bucket 1672357320785522469 18477439880371086 839233398437500000 1099)=true := single local6_2
theorem scan : every 4 6 (bucket 1672357320785522469 18477439880371086 839233398437500000 1099)=true := (joinEvery n4 (joinEvery n5 n6))
end OMA.FiveFar4x21
