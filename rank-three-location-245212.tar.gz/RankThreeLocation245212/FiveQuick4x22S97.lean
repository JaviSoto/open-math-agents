import FiveFastNear245212
namespace OMA.FiveQuick4x22
open OMA.CofactorEulerPair245212 OMA.FiveFastNear245212
open OMA.RankThreeFiveTail245212 (cofactor wt sg ta)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 0
theorem span97 : every 97 186 (OMA.RankThreeFiveShort245212.test 4 22)=true :=
  interval (m:=23) (by decide +kernel) (show every 97 186 (fast 38146972656250000 8746236562728881844 92387199401855461 4386901855468750000 23)=true by decide +kernel)
end OMA.FiveQuick4x22
