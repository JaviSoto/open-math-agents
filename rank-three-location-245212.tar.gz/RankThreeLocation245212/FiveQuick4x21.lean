import FiveQuick4x21S7
import FiveQuick4x21S97
import FiveQuick4x21S187
import FiveQuick4x21S277
import FiveQuick4x21S367
import FiveQuick4x21S457
import FiveQuick4x21S547
import FiveQuick4x21S637
import FiveQuick4x21S727
import FiveQuick4x21S817
import FiveQuick4x21S907
import FiveQuick4x21S997
import FiveQuick4x21S1087
import FiveQuick4x21Far
import FiveFastNear245212
namespace OMA.FiveQuick4x21
open OMA.CofactorEulerPair245212 OMA.FiveFastNear245212
open OMA.RankThreeFiveTail245212 (cofactor wt sg ta)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 0
theorem original {p q b c : ℕ} (pp : p.Prime) (qp : q.Prime) (gt : 5<p) (pq : p<q) (bp : 0<b) (cp : 0<c) :
    OeisA245212.a (2^4*5^21*p^b*q^c)≠(ArithmeticFunction.sigma 1 (2^4*5^21*p^b*q^c):ℤ) :=
  OMA.RankThreeFiveShort245212.final (lo:=1099) pp qp gt pq bp cp (joinEvery (joinEvery (joinEvery span7 (joinEvery span97 span187)) (joinEvery span277 (joinEvery span367 span457))) (joinEvery (joinEvery span547 (joinEvery span637 span727)) (joinEvery (joinEvery span817 span907) (joinEvery span997 span1087)))) (by decide +kernel) OMA.FiveFar4x21.scan
#print axioms original
end OMA.FiveQuick4x21
