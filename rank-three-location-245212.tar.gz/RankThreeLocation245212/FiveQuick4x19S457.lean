import FiveFastNear245212
namespace OMA.FiveQuick4x19
open OMA.CofactorEulerPair245212 OMA.FiveFastNear245212
open OMA.RankThreeFiveTail245212 (cofactor wt sg ta)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 0
theorem span457 : every 457 546 (OMA.RankThreeFiveShort245212.test 4 19)=true :=
  interval (m:=20) (by decide +kernel) (show every 457 546 (fast 305175781250000 60743093490600594 739097595214836 30517578125000000 20)=true by decide +kernel)
end OMA.FiveQuick4x19
