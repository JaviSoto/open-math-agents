import ExponentParity245212
import Mathlib.NumberTheory.Multiplicity

/-! The exact two-adic valuation of the ordinary divisor sum at each prime power. -/
namespace OMA.ExactSigma245212
open Finset ArithmeticFunction OMA.WeightVal245212
open scoped ArithmeticFunction.sigma

abbrev v₂ (n : ℕ) := n.factorization 2
lemma mul_val {x y : ℕ} (hx : x≠0) (hy : y≠0) : v₂ (x*y)=v₂ x+v₂ y := by
  simp only [v₂,Nat.factorization_mul hx hy,Finsupp.add_apply]

def surplus (p e : ℕ) : ℕ := if Odd e then v₂ (p+1)-1 else 0

theorem local_sigma {p : ℕ} (hp : p.Prime) (op : Odd p) (e : ℕ) :
    v₂ (σ 1 (p^e))=v₂ (e+1)+surplus p e := by
  have sp := sigma_pos 1 _ (pow_ne_zero e hp.ne_zero)
  rcases Nat.even_or_odd e with ev|od
  · have mod : σ 1 (p^e) ≡ e+1 [MOD 2] := by
      rw [sigma_one_apply_prime_pow hp]
      have b : p ≡ 1 [MOD 2] := Nat.odd_iff.mp op
      have h := Nat.ModEq.sum (s:=range (e+1)) (fun j _ =>
        show p^j ≡ 1 [MOD 2] by simpa using b.pow j)
      simpa using h
    have od1 : Odd (e+1) := ev.add_one
    have os : Odd (σ 1 (p^e)) := Nat.odd_iff.mpr (mod.trans (show e+1 ≡ 1 [MOD 2] from Nat.odd_iff.mp od1))
    have nev : ¬ Odd e := fun h => (Nat.not_even_iff_odd.mpr h) ev
    rw [surplus,if_neg nev,
      show v₂ (e+1)=0 from val_odd od1,show v₂ (σ 1 (p^e))=0 from val_odd os]
  · have nd : ¬2∣p := by have := Nat.odd_iff.mp op; omega
    have lte := padicValNat.pow_two_sub_one hp.one_lt nd (by omega : e+1≠0) od.add_one
    simp only [←Nat.factorization_def _ Nat.prime_two] at lte
    have fg : σ 1 (p^e)*(p-1)=p^(e+1)-1 := by
      rw [sigma_one_apply_prime_pow hp]; exact geom_sum_mul_of_one_le hp.one_lt.le _
    change v₂ (p^(e+1)-1)+1 = v₂ (p+1)+v₂ (p-1)+v₂ (e+1) at lte
    rw [←fg,mul_val sp.ne' (by have := hp.one_lt; omega)] at lte
    have pos : 1 ≤ v₂ (p+1) := (Nat.prime_two.pow_dvd_iff_le_factorization
      (by omega : p+1≠0)).mp (by simpa using even_iff_two_dvd.mp op.add_one)
    rw [surplus,if_pos od]
    omega

theorem sigma_two_odd (a : ℕ) : Odd (σ 1 (2^a)) := by
  rw [sigma_one_apply_prime_pow Nat.prime_two,sum_range_succ',Nat.odd_iff]
  have h : 2 ∣ ∑ i∈range a, 2^(i+1) :=
    dvd_sum (fun i _ => dvd_pow_self 2 (by omega))
  simp only [pow_zero]
  omega

/-- Positive x is 2^v times an odd number. -/
theorem exact_units (x : ℕ) (hx : x≠0) : ∃ u, Odd u ∧ x=2^v₂ x*u := by
  obtain ⟨k,u,ou,eq⟩ := Nat.exists_eq_two_pow_mul_odd hx
  refine ⟨u,ou,?_⟩
  have v : v₂ x=k := by
    calc
      _ = v₂ (2^k*u) := congrArg v₂ eq
      _ = k := by rw [mul_val (by positivity) ou.pos.ne',
                    show v₂ (2^k)=k from Nat.factorization_pow_self Nat.prime_two,
                    show v₂ u=0 from val_odd ou,add_zero]
  simpa only [v] using eq

theorem exact_residue {x : ℕ} (hx : x≠0) : x ≡ 2^v₂ x [MOD 2^(v₂ x+1)] := by
  obtain ⟨u,ou,eu⟩ := exact_units x hx
  have o : u ≡ 1 [MOD 2] := Nat.odd_iff.mp ou
  have h := o.mul_left' (2^v₂ x)
  simpa only [←eu,mul_one,←pow_succ] using h

theorem sum_of_lt {x y : ℕ} (hx : x≠0) (hy : y≠0) (h : v₂ x < v₂ y) :
    v₂ (x+y)=v₂ x := by
  have zd : 2^(v₂ x+1)∣y := (Nat.prime_two.pow_dvd_iff_le_factorization hy).mpr h
  apply identify (by omega)
  simpa only [add_zero] using (exact_residue hx).add (Nat.modEq_zero_iff_dvd.mpr zd)

theorem sum_of_equal {x y : ℕ} (hx : x≠0) (hy : y≠0) (h : v₂ x=v₂ y) :
    v₂ x < v₂ (x+y) := by
  have ry := exact_residue hy
  rw [←h] at ry
  have sum := (exact_residue hx).add ry
  rw [←Nat.mul_two,←pow_succ] at sum
  exact (Nat.prime_two.pow_dvd_iff_le_factorization (by omega : x+y≠0)).mp
    (Nat.modEq_zero_iff_dvd.mp (sum.trans (Nat.modEq_zero_iff_dvd.mpr (dvd_refl _))))

end OMA.ExactSigma245212
