import RankThreeFiveResidue245212
/-! Middle-prime limit from local obstructions to short divisor counts. -/
namespace OMA.FiveLocal4x24
open OMA.RankThreeFiveResidue245212 OMA.CofactorEulerPair245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem n5 : every 5 5 (fun n=>!(survives 237878412008285522469 2309679985046386711 238418579101562500000 n))=true := by decide +kernel
theorem clear : every 5 5 (fun n=>!(survives 237878412008285522469 2309679985046386711 238418579101562500000 n))=true := n5
end OMA.FiveLocal4x24
