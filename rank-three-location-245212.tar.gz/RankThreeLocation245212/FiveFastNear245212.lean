import KernelPrimeWindow245212
import RankThreeFiveShort245212

/-! A kernel-friendly middle-prime interval: factor the fixed prefix once
and use bounded trial division, keeping the original arithmetic certificates. -/
namespace OMA.FiveFastNear245212
open Nat OMA.KernelPrimeWindow245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFiveShort245212 (highCap lower)
open OMA.RankThreeFiveTail245212 (cofactor wt sg ta)
open OMA.RankThreeEightMoving245212 (line)

def fast (h A S T m p : ℕ) :=
  if trial p=false ∨ ¬h.Coprime p then true else
  if m≤p then
    if 2*T*(p-1)<A*p then every 1 (highCap A S T p) (line A S T p (p+1))
    else if A*p<2*T*(p-1) then lower h A S T p || OMA.RankThreeFiveCount245212.row h A S T p
    else false
  else OMA.RankThreeFiveShort245212.run h A S T p

theorem sound {h A S T m p : ℕ} (limit : (2*T).primeFactorsList.all (fun q=>decide (q ≤ m))=true)
    (pass : fast h A S T m p=true) : OMA.RankThreeFiveShort245212.run h A S T p=true := by
  by_cases ok : p.Prime ∧ h.Coprime p
  · have prime:= (correct p).mpr ok.1
    rw [fast,if_neg (show ¬(trial p=false ∨ ¬h.Coprime p) by
      simp only [prime,Bool.true_eq_false,false_or];exact not_not.mpr ok.2)] at pass
    by_cases hi : m≤p
    · have good : (2*T).primeFactorsList.all (·≤p)=true:=by
        apply List.all_eq_true.mpr
        intro q hq
        exact decide_eq_true (le_trans (of_decide_eq_true (List.all_eq_true.mp limit q hq)) hi)
      rw [if_pos hi] at pass
      simpa only [OMA.RankThreeFiveShort245212.run,if_neg (show ¬(¬p.Prime ∨ ¬h.Coprime p) by tauto),
        good,if_true] using pass
    · simpa only [if_neg hi] using pass
  · simp [OMA.RankThreeFiveShort245212.run,show ¬p.Prime ∨ ¬h.Coprime p by tauto]

theorem interval {k a m l r : ℕ} (lim : (2*ta k a).primeFactorsList.all (fun q=>decide (q ≤ m))=true)
    (pass : every l r (fast (cofactor k a) (wt k a) (sg k a) (ta k a) m)=true) :
    every l r (OMA.RankThreeFiveShort245212.test k a)=true := by
  apply List.all_eq_true.mpr
  intro p mem
  exact sound lim (List.all_eq_true.mp pass p mem)
end OMA.FiveFastNear245212
