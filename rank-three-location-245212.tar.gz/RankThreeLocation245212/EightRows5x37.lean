import RankThreeEightFixed245212
/-! Kernel certificates for one ordered pair of odd bases at dyadic factor eight. -/
namespace OMA.EightRows5x37
open OMA.RankThreeEightFixed245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
theorem row41 : tests 5 37 41=true := by decide +kernel
theorem row43 : tests 5 37 43=true := by decide +kernel
theorem row47 : tests 5 37 47=true := by decide +kernel
theorem row53 : tests 5 37 53=true := by decide +kernel
theorem row59 : tests 5 37 59=true := by decide +kernel
theorem row61 : tests 5 37 61=true := by decide +kernel
end OMA.EightRows5x37
