import RankThreeEightMoving245212
/-! Complete enumeration of both short prefixes for one moving-prime family. -/
/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E1P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
theorem certificate : atom 5 19 1=true := by
  apply row_low (h:=40) (A:=539) (S:=90) (T:=320) (R:=20) (Q:=9) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 9≤20+128)]
  exact (by decide +kernel)
end OMA.EightAt5E1P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E2P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
theorem certificate : atom 5 19 2=true := by
  apply row_low (h:=200) (A:=4214) (S:=465) (T:=2400) (R:=20) (Q:=13) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 13≤20+128)]
  exact (by decide +kernel)
end OMA.EightAt5E2P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E3P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
theorem certificate : atom 5 19 3=true := by
  apply row_low (h:=1000) (A:=28714) (S:=2340) (T:=16000) (R:=20) (Q:=18) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 18≤20+128)]
  exact (by decide +kernel)
end OMA.EightAt5E3P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E4P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b20 : every 20 24 (quick 5000 181839 11715 100000 19)=true := by decide +kernel
theorem certificate : atom 5 19 4=true := by
  apply row_low (h:=5000) (A:=181839) (S:=11715) (T:=100000) (R:=20) (Q:=24) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 24≤20+128)]
  exact b20
end OMA.EightAt5E4P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E5P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b20 : every 20 31 (quick 25000 1100589 58590 600000 19)=true := by decide +kernel
theorem certificate : atom 5 19 5=true := by
  apply row_low (h:=25000) (A:=1100589) (S:=58590) (T:=600000) (R:=20) (Q:=31) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 31≤20+128)]
  exact b20
end OMA.EightAt5E5P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E6P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b20 : every 20 35 (quick 125000 6459964 292965 3500000 19)=true := by decide +kernel
private theorem b36 : every 36 38 (quick 125000 6459964 292965 3500000 19)=true := by decide +kernel
theorem certificate : atom 5 19 6=true := by
  apply row_low (h:=125000) (A:=6459964) (S:=292965) (T:=3500000) (R:=20) (Q:=38) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 38≤20+128)]
  exact (joinEvery b20 b36)
end OMA.EightAt5E6P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E7P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b20 : every 20 35 (quick 625000 37084964 1464840 20000000 19)=true := by decide +kernel
private theorem b36 : every 36 46 (quick 625000 37084964 1464840 20000000 19)=true := by decide +kernel
theorem certificate : atom 5 19 7=true := by
  apply row_low (h:=625000) (A:=37084964) (S:=1464840) (T:=20000000) (R:=20) (Q:=46) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 46≤20+128)]
  exact (joinEvery b20 b36)
end OMA.EightAt5E7P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E8P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b20 : every 20 35 (quick 3125000 209350589 7324215 112500000 19)=true := by decide +kernel
private theorem b36 : every 36 51 (quick 3125000 209350589 7324215 112500000 19)=true := by decide +kernel
private theorem b52 : every 52 55 (quick 3125000 209350589 7324215 112500000 19)=true := by decide +kernel
theorem certificate : atom 5 19 8=true := by
  apply row_low (h:=3125000) (A:=209350589) (S:=7324215) (T:=112500000) (R:=20) (Q:=55) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 55≤20+128)]
  exact (joinEvery b20 (joinEvery b36 b52))
end OMA.EightAt5E8P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E9P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b20 : every 20 35 (quick 15625000 1166381839 36621090 625000000 19)=true := by decide +kernel
private theorem b36 : every 36 51 (quick 15625000 1166381839 36621090 625000000 19)=true := by decide +kernel
private theorem b52 : every 52 66 (quick 15625000 1166381839 36621090 625000000 19)=true := by decide +kernel
theorem certificate : atom 5 19 9=true := by
  apply row_low (h:=15625000) (A:=1166381839) (S:=36621090) (T:=625000000) (R:=20) (Q:=66) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 66≤20+128)]
  exact (joinEvery b20 (joinEvery b36 b52))
end OMA.EightAt5E9P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E10P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b20 : every 20 35 (quick 78125000 6430053714 183105465 3437500000 19)=true := by decide +kernel
private theorem b36 : every 36 51 (quick 78125000 6430053714 183105465 3437500000 19)=true := by decide +kernel
private theorem b52 : every 52 67 (quick 78125000 6430053714 183105465 3437500000 19)=true := by decide +kernel
private theorem b68 : every 68 78 (quick 78125000 6430053714 183105465 3437500000 19)=true := by decide +kernel
theorem certificate : atom 5 19 10=true := by
  apply row_low (h:=78125000) (A:=6430053714) (S:=183105465) (T:=3437500000) (R:=20) (Q:=78) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 78≤20+128)]
  exact (joinEvery (joinEvery b20 b36) (joinEvery b52 b68))
end OMA.EightAt5E10P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E11P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b20 : every 20 35 (quick 390625000 35140991214 915527340 18750000000 19)=true := by decide +kernel
private theorem b36 : every 36 51 (quick 390625000 35140991214 915527340 18750000000 19)=true := by decide +kernel
private theorem b52 : every 52 67 (quick 390625000 35140991214 915527340 18750000000 19)=true := by decide +kernel
private theorem b68 : every 68 83 (quick 390625000 35140991214 915527340 18750000000 19)=true := by decide +kernel
private theorem b84 : every 84 92 (quick 390625000 35140991214 915527340 18750000000 19)=true := by decide +kernel
theorem certificate : atom 5 19 11=true := by
  apply row_low (h:=390625000) (A:=35140991214) (S:=915527340) (T:=18750000000) (R:=20) (Q:=92) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 92≤20+128)]
  exact (joinEvery (joinEvery b20 b36) (joinEvery b52 (joinEvery b68 b84)))
end OMA.EightAt5E11P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E12P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b20 : every 20 35 (quick 1953125000 190658569339 4577636715 101562500000 19)=true := by decide +kernel
private theorem b36 : every 36 51 (quick 1953125000 190658569339 4577636715 101562500000 19)=true := by decide +kernel
private theorem b52 : every 52 67 (quick 1953125000 190658569339 4577636715 101562500000 19)=true := by decide +kernel
private theorem b68 : every 68 83 (quick 1953125000 190658569339 4577636715 101562500000 19)=true := by decide +kernel
private theorem b84 : every 84 99 (quick 1953125000 190658569339 4577636715 101562500000 19)=true := by decide +kernel
private theorem b100 : every 100 108 (quick 1953125000 190658569339 4577636715 101562500000 19)=true := by decide +kernel
theorem certificate : atom 5 19 12=true := by
  apply row_low (h:=1953125000) (A:=190658569339) (S:=4577636715) (T:=101562500000) (R:=20) (Q:=108) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 108≤20+128)]
  exact (joinEvery (joinEvery b20 (joinEvery b36 b52)) (joinEvery b68 (joinEvery b84 b100)))
end OMA.EightAt5E12P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E13P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b20 : every 20 35 (quick 9765625000 1028060913089 22888183590 546875000000 19)=true := by decide +kernel
private theorem b36 : every 36 51 (quick 9765625000 1028060913089 22888183590 546875000000 19)=true := by decide +kernel
private theorem b52 : every 52 67 (quick 9765625000 1028060913089 22888183590 546875000000 19)=true := by decide +kernel
private theorem b68 : every 68 83 (quick 9765625000 1028060913089 22888183590 546875000000 19)=true := by decide +kernel
private theorem b84 : every 84 99 (quick 9765625000 1028060913089 22888183590 546875000000 19)=true := by decide +kernel
private theorem b100 : every 100 115 (quick 9765625000 1028060913089 22888183590 546875000000 19)=true := by decide +kernel
private theorem b116 : every 116 127 (quick 9765625000 1028060913089 22888183590 546875000000 19)=true := by decide +kernel
theorem certificate : atom 5 19 13=true := by
  apply row_low (h:=9765625000) (A:=1028060913089) (S:=22888183590) (T:=546875000000) (R:=20) (Q:=127) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 127≤20+128)]
  exact (joinEvery (joinEvery b20 (joinEvery b36 b52)) (joinEvery (joinEvery b68 b84) (joinEvery b100 b116)))
end OMA.EightAt5E13P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E14P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 5514144897464 114440917965 2929687500000 19 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 5514144897464 114440917965 2929687500000 19 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 5514144897464 114440917965 2929687500000 19 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 5514144897464 114440917965 2929687500000 19 20)=true := by decide +kernel
private theorem b65 : every 65 67 (line 5514144897464 114440917965 2929687500000 19 20)=true := by decide +kernel
theorem certificate : atom 5 19 14=true := by
  apply row_low (h:=48828125000) (A:=5514144897464) (S:=114440917965) (T:=2929687500000) (R:=20) (Q:=150) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬150≤20+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 48828125000 5514144897464 114440917965 19 150=67 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65)))⟩
end OMA.EightAt5E14P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E15P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 29439926147464 572204589840 15625000000000 19 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 29439926147464 572204589840 15625000000000 19 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 29439926147464 572204589840 15625000000000 19 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 29439926147464 572204589840 15625000000000 19 20)=true := by decide +kernel
private theorem b65 : every 65 69 (line 29439926147464 572204589840 15625000000000 19 20)=true := by decide +kernel
theorem certificate : atom 5 19 15=true := by
  apply row_low (h:=244140625000) (A:=29439926147464) (S:=572204589840) (T:=15625000000000) (R:=20) (Q:=179) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬179≤20+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 244140625000 29439926147464 572204589840 19 179=69 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65)))⟩
end OMA.EightAt5E15P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E16P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 156545639038089 2861022949215 83007812500000 19 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 156545639038089 2861022949215 83007812500000 19 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 156545639038089 2861022949215 83007812500000 19 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 156545639038089 2861022949215 83007812500000 19 20)=true := by decide +kernel
private theorem b65 : every 65 72 (line 156545639038089 2861022949215 83007812500000 19 20)=true := by decide +kernel
theorem certificate : atom 5 19 16=true := by
  apply row_low (h:=1220703125000) (A:=156545639038089) (S:=2861022949215) (T:=83007812500000) (R:=20) (Q:=214) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬214≤20+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 1220703125000 156545639038089 2861022949215 19 214=72 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65)))⟩
end OMA.EightAt5E16P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E17P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 829458236694339 14305114746090 439453125000000 19 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 829458236694339 14305114746090 439453125000000 19 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 829458236694339 14305114746090 439453125000000 19 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 829458236694339 14305114746090 439453125000000 19 20)=true := by decide +kernel
private theorem b65 : every 65 75 (line 829458236694339 14305114746090 439453125000000 19 20)=true := by decide +kernel
theorem certificate : atom 5 19 17=true := by
  apply row_low (h:=6103515625000) (A:=829458236694339) (S:=14305114746090) (T:=439453125000000) (R:=20) (Q:=261) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬261≤20+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 6103515625000 829458236694339 14305114746090 19 261=75 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65)))⟩
end OMA.EightAt5E17P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E18P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 4380941390991214 71525573730465 2319335937500000 19 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 4380941390991214 71525573730465 2319335937500000 19 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 4380941390991214 71525573730465 2319335937500000 19 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 4380941390991214 71525573730465 2319335937500000 19 20)=true := by decide +kernel
private theorem b65 : every 65 79 (line 4380941390991214 71525573730465 2319335937500000 19 20)=true := by decide +kernel
theorem certificate : atom 5 19 18=true := by
  apply row_low (h:=30517578125000) (A:=4380941390991214) (S:=71525573730465) (T:=2319335937500000) (R:=20) (Q:=323) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬323≤20+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 30517578125000 4380941390991214 71525573730465 19 323=79 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65)))⟩
end OMA.EightAt5E18P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E19P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 23072957992553714 357627868652340 12207031250000000 19 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 23072957992553714 357627868652340 12207031250000000 19 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 23072957992553714 357627868652340 12207031250000000 19 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 23072957992553714 357627868652340 12207031250000000 19 20)=true := by decide +kernel
private theorem b65 : every 65 80 (line 23072957992553714 357627868652340 12207031250000000 19 20)=true := by decide +kernel
private theorem b81 : every 81 82 (line 23072957992553714 357627868652340 12207031250000000 19 20)=true := by decide +kernel
theorem certificate : atom 5 19 19=true := by
  apply row_low (h:=152587890625000) (A:=23072957992553714) (S:=357627868652340) (T:=12207031250000000) (R:=20) (Q:=411) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬411≤20+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 152587890625000 23072957992553714 357627868652340 19 411=82 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81)))⟩
end OMA.EightAt5E19P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E20P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 121206045150756839 1788139343261715 64086914062500000 19 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 121206045150756839 1788139343261715 64086914062500000 19 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 121206045150756839 1788139343261715 64086914062500000 19 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 121206045150756839 1788139343261715 64086914062500000 19 20)=true := by decide +kernel
private theorem b65 : every 65 80 (line 121206045150756839 1788139343261715 64086914062500000 19 20)=true := by decide +kernel
private theorem b81 : every 81 84 (line 121206045150756839 1788139343261715 64086914062500000 19 20)=true := by decide +kernel
theorem certificate : atom 5 19 20=true := by
  apply row_low (h:=762939453125000) (A:=121206045150756839) (S:=1788139343261715) (T:=64086914062500000) (R:=20) (Q:=547) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬547≤20+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 762939453125000 121206045150756839 1788139343261715 19 547=84 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81)))⟩
end OMA.EightAt5E20P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E21P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 635236501693725589 8940696716308590 335693359375000000 19 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 635236501693725589 8940696716308590 335693359375000000 19 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 635236501693725589 8940696716308590 335693359375000000 19 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 635236501693725589 8940696716308590 335693359375000000 19 20)=true := by decide +kernel
private theorem b65 : every 65 80 (line 635236501693725589 8940696716308590 335693359375000000 19 20)=true := by decide +kernel
private theorem b81 : every 81 87 (line 635236501693725589 8940696716308590 335693359375000000 19 20)=true := by decide +kernel
theorem certificate : atom 5 19 21=true := by
  apply row_low (h:=3814697265625000) (A:=635236501693725589) (S:=8940696716308590) (T:=335693359375000000) (R:=20) (Q:=781) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬781≤20+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 3814697265625000 635236501693725589 8940696716308590 19 781=87 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81)))⟩
end OMA.EightAt5E21P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E22P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 3322213888168334964 44703483581542965 1754760742187500000 19 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 3322213888168334964 44703483581542965 1754760742187500000 19 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 3322213888168334964 44703483581542965 1754760742187500000 19 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 3322213888168334964 44703483581542965 1754760742187500000 19 20)=true := by decide +kernel
private theorem b65 : every 65 80 (line 3322213888168334964 44703483581542965 1754760742187500000 19 20)=true := by decide +kernel
private theorem b81 : every 81 89 (line 3322213888168334964 44703483581542965 1754760742187500000 19 20)=true := by decide +kernel
theorem certificate : atom 5 19 22=true := by
  apply row_low (h:=19073486328125000) (A:=3322213888168334964) (S:=44703483581542965) (T:=1754760742187500000) (R:=20) (Q:=1280) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬1280≤20+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 19073486328125000 3322213888168334964 44703483581542965 19 1280=89 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81)))⟩
end OMA.EightAt5E22P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E23P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 17341226339340209964 223517417907714840 9155273437500000000 19 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 17341226339340209964 223517417907714840 9155273437500000000 19 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 17341226339340209964 223517417907714840 9155273437500000000 19 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 17341226339340209964 223517417907714840 9155273437500000000 19 20)=true := by decide +kernel
private theorem b65 : every 65 80 (line 17341226339340209964 223517417907714840 9155273437500000000 19 20)=true := by decide +kernel
private theorem b81 : every 81 92 (line 17341226339340209964 223517417907714840 9155273437500000000 19 20)=true := by decide +kernel
theorem certificate : atom 5 19 23=true := by
  apply row_low (h:=95367431640625000) (A:=17341226339340209964) (S:=223517417907714840) (T:=9155273437500000000) (R:=20) (Q:=3093) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬3093≤20+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 95367431640625000 17341226339340209964 223517417907714840 19 3093=92 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81)))⟩
end OMA.EightAt5E23P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E24P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b65 : every 65 80 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b81 : every 81 96 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b97 : every 97 112 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b113 : every 113 128 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b129 : every 129 144 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b145 : every 145 160 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b161 : every 161 176 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b177 : every 177 192 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b193 : every 193 208 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b209 : every 209 224 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b225 : every 225 240 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b241 : every 241 256 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b257 : every 257 272 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b273 : every 273 288 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b289 : every 289 304 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b305 : every 305 320 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b321 : every 321 336 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b337 : every 337 352 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b353 : every 353 368 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b369 : every 369 384 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b385 : every 385 400 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b401 : every 401 416 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b417 : every 417 432 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b433 : every 433 448 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b449 : every 449 464 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b465 : every 465 480 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b481 : every 481 496 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b497 : every 497 512 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b513 : every 513 528 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b529 : every 529 544 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b545 : every 545 560 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b561 : every 561 576 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b577 : every 577 592 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b593 : every 593 608 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b609 : every 609 624 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b625 : every 625 640 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b641 : every 641 656 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b657 : every 657 672 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b673 : every 673 688 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b689 : every 689 704 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b705 : every 705 720 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b721 : every 721 736 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b737 : every 737 752 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b753 : every 753 768 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b769 : every 769 784 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b785 : every 785 800 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b801 : every 801 816 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b817 : every 817 832 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b833 : every 833 848 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b849 : every 849 864 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b865 : every 865 880 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b881 : every 881 896 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b897 : every 897 912 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b913 : every 913 928 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b929 : every 929 944 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b945 : every 945 960 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b961 : every 961 976 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b977 : every 977 992 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b993 : every 993 1008 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b1009 : every 1009 1024 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b1025 : every 1025 1040 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b1041 : every 1041 1056 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b1057 : every 1057 1072 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
private theorem b1073 : every 1073 1077 (line 90356916189193725589 1117587089538574215 47683715820312500000 19 20)=true := by decide +kernel
theorem certificate : atom 5 19 24=true := by
  apply row_high (h:=476837158203125000) (A:=90356916189193725589) (S:=1117587089538574215) (T:=47683715820312500000) (R:=20) (B:=1077) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 b49)) (joinEvery (joinEvery b65 b81) (joinEvery b97 b113))) (joinEvery (joinEvery (joinEvery b129 b145) (joinEvery b161 b177)) (joinEvery (joinEvery b193 b209) (joinEvery b225 (joinEvery b241 b257))))) (joinEvery (joinEvery (joinEvery (joinEvery b273 b289) (joinEvery b305 b321)) (joinEvery (joinEvery b337 b353) (joinEvery b369 b385))) (joinEvery (joinEvery (joinEvery b401 b417) (joinEvery b433 b449)) (joinEvery (joinEvery b465 b481) (joinEvery b497 (joinEvery b513 b529)))))) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b545 b561) (joinEvery b577 b593)) (joinEvery (joinEvery b609 b625) (joinEvery b641 b657))) (joinEvery (joinEvery (joinEvery b673 b689) (joinEvery b705 b721)) (joinEvery (joinEvery b737 b753) (joinEvery b769 (joinEvery b785 b801))))) (joinEvery (joinEvery (joinEvery (joinEvery b817 b833) (joinEvery b849 b865)) (joinEvery (joinEvery b881 b897) (joinEvery b913 b929))) (joinEvery (joinEvery (joinEvery b945 b961) (joinEvery b977 b993)) (joinEvery (joinEvery b1009 b1025) (joinEvery b1041 (joinEvery b1057 b1073)))))))
end OMA.EightAt5E24P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E25P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 470038503408432006839 5587935447692871090 247955322265625000000 19 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 470038503408432006839 5587935447692871090 247955322265625000000 19 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 470038503408432006839 5587935447692871090 247955322265625000000 19 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 470038503408432006839 5587935447692871090 247955322265625000000 19 20)=true := by decide +kernel
private theorem b65 : every 65 80 (line 470038503408432006839 5587935447692871090 247955322265625000000 19 20)=true := by decide +kernel
private theorem b81 : every 81 96 (line 470038503408432006839 5587935447692871090 247955322265625000000 19 20)=true := by decide +kernel
private theorem b97 : every 97 112 (line 470038503408432006839 5587935447692871090 247955322265625000000 19 20)=true := by decide +kernel
private theorem b113 : every 113 128 (line 470038503408432006839 5587935447692871090 247955322265625000000 19 20)=true := by decide +kernel
private theorem b129 : every 129 144 (line 470038503408432006839 5587935447692871090 247955322265625000000 19 20)=true := by decide +kernel
private theorem b145 : every 145 160 (line 470038503408432006839 5587935447692871090 247955322265625000000 19 20)=true := by decide +kernel
private theorem b161 : every 161 176 (line 470038503408432006839 5587935447692871090 247955322265625000000 19 20)=true := by decide +kernel
private theorem b177 : every 177 192 (line 470038503408432006839 5587935447692871090 247955322265625000000 19 20)=true := by decide +kernel
private theorem b193 : every 193 208 (line 470038503408432006839 5587935447692871090 247955322265625000000 19 20)=true := by decide +kernel
private theorem b209 : every 209 216 (line 470038503408432006839 5587935447692871090 247955322265625000000 19 20)=true := by decide +kernel
theorem certificate : atom 5 19 25=true := by
  apply row_high (h:=2384185791015625000) (A:=470038503408432006839) (S:=5587935447692871090) (T:=247955322265625000000) (R:=20) (B:=216) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97))) (joinEvery (joinEvery b113 (joinEvery b129 b145)) (joinEvery (joinEvery b161 b177) (joinEvery b193 b209))))
end OMA.EightAt5E25P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E26P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 2441462129354476928714 27939677238464355465 1287460327148437500000 19 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 2441462129354476928714 27939677238464355465 1287460327148437500000 19 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 2441462129354476928714 27939677238464355465 1287460327148437500000 19 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 2441462129354476928714 27939677238464355465 1287460327148437500000 19 20)=true := by decide +kernel
private theorem b65 : every 65 80 (line 2441462129354476928714 27939677238464355465 1287460327148437500000 19 20)=true := by decide +kernel
private theorem b81 : every 81 96 (line 2441462129354476928714 27939677238464355465 1287460327148437500000 19 20)=true := by decide +kernel
private theorem b97 : every 97 112 (line 2441462129354476928714 27939677238464355465 1287460327148437500000 19 20)=true := by decide +kernel
private theorem b113 : every 113 124 (line 2441462129354476928714 27939677238464355465 1287460327148437500000 19 20)=true := by decide +kernel
theorem certificate : atom 5 19 26=true := by
  apply row_high (h:=11920928955078125000) (A:=2441462129354476928714) (S:=27939677238464355465) (T:=1287460327148437500000) (R:=20) (B:=124) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 b49)) (joinEvery (joinEvery b65 b81) (joinEvery b97 b113)))
end OMA.EightAt5E26P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E27P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 12663658708333969116214 139698386192321777340 6675720214843750000000 19 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 12663658708333969116214 139698386192321777340 6675720214843750000000 19 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 12663658708333969116214 139698386192321777340 6675720214843750000000 19 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 12663658708333969116214 139698386192321777340 6675720214843750000000 19 20)=true := by decide +kernel
private theorem b65 : every 65 80 (line 12663658708333969116214 139698386192321777340 6675720214843750000000 19 20)=true := by decide +kernel
private theorem b81 : every 81 89 (line 12663658708333969116214 139698386192321777340 6675720214843750000000 19 20)=true := by decide +kernel
theorem certificate : atom 5 19 27=true := by
  apply row_high (h:=59604644775390625000) (A:=12663658708333969116214) (S:=139698386192321777340) (T:=6675720214843750000000) (R:=20) (B:=89) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81)))
end OMA.EightAt5E27P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E28P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 65600033849477767944339 698491930961608886715 34570693969726562500000 19 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 65600033849477767944339 698491930961608886715 34570693969726562500000 19 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 65600033849477767944339 698491930961608886715 34570693969726562500000 19 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 65600033849477767944339 698491930961608886715 34570693969726562500000 19 20)=true := by decide +kernel
private theorem b65 : every 65 70 (line 65600033849477767944339 698491930961608886715 34570693969726562500000 19 20)=true := by decide +kernel
theorem certificate : atom 5 19 28=true := by
  apply row_high (h:=298023223876953125000) (A:=65600033849477767944339) (S:=698491930961608886715) (T:=34570693969726562500000) (R:=20) (B:=70) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65)))
end OMA.EightAt5E28P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E29P19
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 339408870786428451538089 3492459654808044433590 178813934326171875000000 19 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 339408870786428451538089 3492459654808044433590 178813934326171875000000 19 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 339408870786428451538089 3492459654808044433590 178813934326171875000000 19 20)=true := by decide +kernel
private theorem b49 : every 49 59 (line 339408870786428451538089 3492459654808044433590 178813934326171875000000 19 20)=true := by decide +kernel
theorem certificate : atom 5 19 29=true := by
  apply row_high (h:=1490116119384765625000) (A:=339408870786428451538089) (S:=3492459654808044433590) (T:=178813934326171875000000) (R:=20) (B:=59) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 b17) (joinEvery b33 b49))
end OMA.EightAt5E29P19

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E1P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b20 : every 20 35 (quick 152 1911 300 1216 5)=true := by decide +kernel
private theorem b36 : every 36 51 (quick 152 1911 300 1216 5)=true := by decide +kernel
private theorem b52 : every 52 56 (quick 152 1911 300 1216 5)=true := by decide +kernel
theorem certificate : atom 19 5 1=true := by
  apply row_low (h:=152) (A:=1911) (S:=300) (T:=1216) (R:=20) (Q:=56) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 56≤20+128)]
  exact (joinEvery b20 (joinEvery b36 b52))
end OMA.EightAt19E1P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E2P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b20 : every 20 35 (quick 2888 54978 5715 34656 5)=true := by decide +kernel
private theorem b36 : every 36 51 (quick 2888 54978 5715 34656 5)=true := by decide +kernel
private theorem b52 : every 52 67 (quick 2888 54978 5715 34656 5)=true := by decide +kernel
private theorem b68 : every 68 83 (quick 2888 54978 5715 34656 5)=true := by decide +kernel
private theorem b84 : every 84 99 (quick 2888 54978 5715 34656 5)=true := by decide +kernel
private theorem b100 : every 100 115 (quick 2888 54978 5715 34656 5)=true := by decide +kernel
private theorem b116 : every 116 117 (quick 2888 54978 5715 34656 5)=true := by decide +kernel
theorem certificate : atom 19 5 2=true := by
  apply row_low (h:=2888) (A:=54978) (S:=5715) (T:=34656) (R:=20) (Q:=117) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 117≤20+128)]
  exact (joinEvery (joinEvery b20 (joinEvery b36 b52)) (joinEvery (joinEvery b68 b84) (joinEvery b100 b116)))
end OMA.EightAt19E2P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E3P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 1399342 108600 877952 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 1399342 108600 877952 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 1399342 108600 877952 5 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 1399342 108600 877952 5 20)=true := by decide +kernel
private theorem b65 : every 65 80 (line 1399342 108600 877952 5 20)=true := by decide +kernel
private theorem b81 : every 81 96 (line 1399342 108600 877952 5 20)=true := by decide +kernel
private theorem b97 : every 97 112 (line 1399342 108600 877952 5 20)=true := by decide +kernel
private theorem b113 : every 113 128 (line 1399342 108600 877952 5 20)=true := by decide +kernel
private theorem b129 : every 129 137 (line 1399342 108600 877952 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 3=true := by
  apply row_low (h:=54872) (A:=1399342) (S:=108600) (T:=877952) (R:=20) (Q:=261) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬261≤20+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 54872 1399342 108600 5 261=137 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 b49)) (joinEvery (joinEvery b65 b81) (joinEvery b97 (joinEvery b113 b129))))⟩
end OMA.EightAt19E3P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E4P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 33327987 2063415 20851360 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 33327987 2063415 20851360 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 33327987 2063415 20851360 5 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 33327987 2063415 20851360 5 20)=true := by decide +kernel
private theorem b65 : every 65 80 (line 33327987 2063415 20851360 5 20)=true := by decide +kernel
private theorem b81 : every 81 96 (line 33327987 2063415 20851360 5 20)=true := by decide +kernel
private theorem b97 : every 97 112 (line 33327987 2063415 20851360 5 20)=true := by decide +kernel
private theorem b113 : every 113 128 (line 33327987 2063415 20851360 5 20)=true := by decide +kernel
private theorem b129 : every 129 144 (line 33327987 2063415 20851360 5 20)=true := by decide +kernel
private theorem b145 : every 145 155 (line 33327987 2063415 20851360 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 4=true := by
  apply row_low (h:=1042568) (A:=33327987) (S:=2063415) (T:=20851360) (R:=20) (Q:=975) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬975≤20+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 1042568 33327987 2063415 5 975=155 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65))) (joinEvery (joinEvery b81 b97) (joinEvery b113 (joinEvery b129 b145))))⟩
end OMA.EightAt19E4P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E5P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b65 : every 65 80 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b81 : every 81 96 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b97 : every 97 112 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b113 : every 113 128 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b129 : every 129 144 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b145 : every 145 160 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b161 : every 161 176 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b177 : every 177 192 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b193 : every 193 208 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b209 : every 209 224 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b225 : every 225 240 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b241 : every 241 256 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b257 : every 257 272 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b273 : every 273 288 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b289 : every 289 304 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b305 : every 305 320 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b321 : every 321 336 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b337 : every 337 352 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b353 : every 353 368 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b369 : every 369 384 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b385 : every 385 400 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b401 : every 401 416 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b417 : every 417 432 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b433 : every 433 448 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b449 : every 449 464 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
private theorem b465 : every 465 473 (line 761301093 39204900 475411008 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 5=true := by
  apply row_high (h:=19808792) (A:=761301093) (S:=39204900) (T:=475411008) (R:=20) (B:=473) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97))) (joinEvery (joinEvery (joinEvery b113 b129) (joinEvery b145 b161)) (joinEvery (joinEvery b177 b193) (joinEvery b209 b225)))) (joinEvery (joinEvery (joinEvery b241 (joinEvery b257 b273)) (joinEvery (joinEvery b289 b305) (joinEvery b321 b337))) (joinEvery (joinEvery (joinEvery b353 b369) (joinEvery b385 b401)) (joinEvery (joinEvery b417 b433) (joinEvery b449 b465)))))
end OMA.EightAt19E5P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E6P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 16898038276 744893115 10538277344 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 16898038276 744893115 10538277344 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 16898038276 744893115 10538277344 5 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 16898038276 744893115 10538277344 5 20)=true := by decide +kernel
private theorem b65 : every 65 80 (line 16898038276 744893115 10538277344 5 20)=true := by decide +kernel
private theorem b81 : every 81 96 (line 16898038276 744893115 10538277344 5 20)=true := by decide +kernel
private theorem b97 : every 97 112 (line 16898038276 744893115 10538277344 5 20)=true := by decide +kernel
private theorem b113 : every 113 128 (line 16898038276 744893115 10538277344 5 20)=true := by decide +kernel
private theorem b129 : every 129 144 (line 16898038276 744893115 10538277344 5 20)=true := by decide +kernel
private theorem b145 : every 145 160 (line 16898038276 744893115 10538277344 5 20)=true := by decide +kernel
private theorem b161 : every 161 176 (line 16898038276 744893115 10538277344 5 20)=true := by decide +kernel
private theorem b177 : every 177 183 (line 16898038276 744893115 10538277344 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 6=true := by
  apply row_high (h:=376367048) (A:=16898038276) (S:=744893115) (T:=10538277344) (R:=20) (B:=183) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery b145 (joinEvery b161 b177))))
end OMA.EightAt19E6P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E7P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 367295759964 14152969200 228831165184 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 367295759964 14152969200 228831165184 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 367295759964 14152969200 228831165184 5 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 367295759964 14152969200 228831165184 5 20)=true := by decide +kernel
private theorem b65 : every 65 80 (line 367295759964 14152969200 228831165184 5 20)=true := by decide +kernel
private theorem b81 : every 81 96 (line 367295759964 14152969200 228831165184 5 20)=true := by decide +kernel
private theorem b97 : every 97 112 (line 367295759964 14152969200 228831165184 5 20)=true := by decide +kernel
private theorem b113 : every 113 126 (line 367295759964 14152969200 228831165184 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 7=true := by
  apply row_high (h:=7150973912) (A:=367295759964) (S:=14152969200) (T:=228831165184) (R:=20) (B:=126) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 b49)) (joinEvery (joinEvery b65 b81) (joinEvery b97 b113)))
end OMA.EightAt19E7P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E8P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 7857047061045 268906414815 4891266155808 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 7857047061045 268906414815 4891266155808 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 7857047061045 268906414815 4891266155808 5 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 7857047061045 268906414815 4891266155808 5 20)=true := by decide +kernel
private theorem b65 : every 65 80 (line 7857047061045 268906414815 4891266155808 5 20)=true := by decide +kernel
private theorem b81 : every 81 96 (line 7857047061045 268906414815 4891266155808 5 20)=true := by decide +kernel
private theorem b97 : every 97 101 (line 7857047061045 268906414815 4891266155808 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 8=true := by
  apply row_high (h:=135868504328) (A:=7857047061045) (S:=268906414815) (T:=4891266155808) (R:=20) (B:=101) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97)))
end OMA.EightAt19E8P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E9P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 165974018972755 5109221881500 103260063289280 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 165974018972755 5109221881500 103260063289280 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 165974018972755 5109221881500 103260063289280 5 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 165974018972755 5109221881500 103260063289280 5 20)=true := by decide +kernel
private theorem b65 : every 65 80 (line 165974018972755 5109221881500 103260063289280 5 20)=true := by decide +kernel
private theorem b81 : every 81 87 (line 165974018972755 5109221881500 103260063289280 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 9=true := by
  apply row_high (h:=2581501582232) (A:=165974018972755) (S:=5109221881500) (T:=103260063289280) (R:=20) (B:=87) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81)))
end OMA.EightAt19E9P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E10P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 3470618731927494 97075215748515 2158135322745952 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 3470618731927494 97075215748515 2158135322745952 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 3470618731927494 97075215748515 2158135322745952 5 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 3470618731927494 97075215748515 2158135322745952 5 20)=true := by decide +kernel
private theorem b65 : every 65 78 (line 3470618731927494 97075215748515 2158135322745952 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 10=true := by
  apply row_high (h:=49048530062408) (A:=3470618731927494) (S:=97075215748515) (T:=2158135322745952) (R:=20) (B:=78) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65)))
end OMA.EightAt19E10P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E11P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 71966890964080266 1844429099221800 44732259416916096 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 71966890964080266 1844429099221800 44732259416916096 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 71966890964080266 1844429099221800 44732259416916096 5 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 71966890964080266 1844429099221800 44732259416916096 5 20)=true := by decide +kernel
private theorem b65 : every 65 72 (line 71966890964080266 1844429099221800 44732259416916096 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 11=true := by
  apply row_high (h:=931922071185752) (A:=71966890964080266) (S:=1844429099221800) (T:=44732259416916096) (R:=20) (B:=72) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65)))
end OMA.EightAt19E11P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E12P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 1481848494409224823 35044152885214215 920739006331522976 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 1481848494409224823 35044152885214215 920739006331522976 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 1481848494409224823 35044152885214215 920739006331522976 5 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 1481848494409224823 35044152885214215 920739006331522976 5 20)=true := by decide +kernel
private theorem b65 : every 65 68 (line 1481848494409224823 35044152885214215 920739006331522976 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 12=true := by
  apply row_high (h:=17706519352529288) (A:=1481848494409224823) (S:=35044152885214215) (T:=920739006331522976) (R:=20) (B:=68) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65)))
end OMA.EightAt19E12P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E13P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 30330195149517567297 665838904819070100 18839736591091162432 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 30330195149517567297 665838904819070100 18839736591091162432 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 30330195149517567297 665838904819070100 18839736591091162432 5 20)=true := by decide +kernel
private theorem b49 : every 49 64 (line 30330195149517567297 665838904819070100 18839736591091162432 5 20)=true := by decide +kernel
private theorem b65 : every 65 65 (line 30330195149517567297 665838904819070100 18839736591091162432 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 13=true := by
  apply row_high (h:=336423867698056472) (A:=30330195149517567297) (S:=665838904819070100) (T:=18839736591091162432) (R:=20) (B:=65) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65)))
end OMA.EightAt19E13P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E14P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 617600109199937396232 12650939191562331915 383523209175784378080 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 617600109199937396232 12650939191562331915 383523209175784378080 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 617600109199937396232 12650939191562331915 383523209175784378080 5 20)=true := by decide +kernel
private theorem b49 : every 49 62 (line 617600109199937396232 12650939191562331915 383523209175784378080 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 14=true := by
  apply row_high (h:=6392053486263072968) (A:=617600109199937396232) (S:=12650939191562331915) (T:=383523209175784378080) (R:=20) (B:=62) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 b17) (joinEvery b33 b49))
end OMA.EightAt19E14P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E15P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 12519603700621779262648 240367844639684306400 7772737039295896729088 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 12519603700621779262648 240367844639684306400 7772737039295896729088 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 12519603700621779262648 240367844639684306400 7772737039295896729088 5 20)=true := by decide +kernel
private theorem b49 : every 49 60 (line 12519603700621779262648 240367844639684306400 7772737039295896729088 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 15=true := by
  apply row_high (h:=121449016238998386392) (A:=12519603700621779262648) (S:=240367844639684306400) (T:=7772737039295896729088) (R:=20) (B:=60) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 b17) (joinEvery b33 b49))
end OMA.EightAt19E15P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E16P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 252791301202450211940921 4566989048154001821615 156912128980785915218464 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 252791301202450211940921 4566989048154001821615 156912128980785915218464 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 252791301202450211940921 4566989048154001821615 156912128980785915218464 5 20)=true := by decide +kernel
private theorem b49 : every 49 58 (line 252791301202450211940921 4566989048154001821615 156912128980785915218464 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 16=true := by
  apply row_high (h:=2307531308540969341448) (A:=252791301202450211940921) (S:=4566989048154001821615) (T:=156912128980785915218464) (R:=20) (B:=58) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 b17) (joinEvery b33 b49))
end OMA.EightAt19E16P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E17P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 5086492509768645739939119 86772791914926034610700 3156702830084046059100864 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 5086492509768645739939119 86772791914926034610700 3156702830084046059100864 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 5086492509768645739939119 86772791914926034610700 3156702830084046059100864 5 20)=true := by decide +kernel
private theorem b49 : every 49 56 (line 5086492509768645739939119 86772791914926034610700 3156702830084046059100864 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 17=true := by
  apply row_high (h:=43843094862278417487512) (A:=5086492509768645739939119) (S:=86772791914926034610700) (T:=3156702830084046059100864) (R:=20) (B:=56) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 b17) (joinEvery b33 b49))
end OMA.EightAt19E17P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E18P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 102029055637124011607014090 1648683046383594657603315 63309428981130034851967328 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 102029055637124011607014090 1648683046383594657603315 63309428981130034851967328 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 102029055637124011607014090 1648683046383594657603315 63309428981130034851967328 5 20)=true := by decide +kernel
private theorem b49 : every 49 55 (line 102029055637124011607014090 1648683046383594657603315 63309428981130034851967328 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 18=true := by
  apply row_high (h:=833018802383289932262728) (A:=102029055637124011607014090) (S:=1648683046383594657603315) (T:=63309428981130034851967328) (R:=20) (B:=55) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 b17) (joinEvery b33 b49))
end OMA.EightAt19E18P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E19P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 2040880318184231328948513510 31324977881288298494463000 1266188579622600697039346560 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 2040880318184231328948513510 31324977881288298494463000 1266188579622600697039346560 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 2040880318184231328948513510 31324977881288298494463000 1266188579622600697039346560 5 20)=true := by decide +kernel
private theorem b49 : every 49 54 (line 2040880318184231328948513510 31324977881288298494463000 1266188579622600697039346560 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 19=true := by
  apply row_high (h:=15827357245282508712991832) (A:=2040880318184231328948513510) (S:=31324977881288298494463000) (T:=1266188579622600697039346560) (R:=20) (B:=54) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 b17) (joinEvery b33 b49))
end OMA.EightAt19E19P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E20P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 40720963005999022309911426939 595174579744477671394797015 25260462163470883905934963872 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 40720963005999022309911426939 595174579744477671394797015 25260462163470883905934963872 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 40720963005999022309911426939 595174579744477671394797015 25260462163470883905934963872 5 20)=true := by decide +kernel
private theorem b49 : every 49 53 (line 40720963005999022309911426939 595174579744477671394797015 25260462163470883905934963872 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 20=true := by
  apply row_high (h:=300719787660367665546844808) (A:=40720963005999022309911426939) (S:=595174579744477671394797015) (T:=25260462163470883905934963872) (R:=20) (B:=53) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 b17) (joinEvery b33 b49))
end OMA.EightAt19E20P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E21P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 810638799363455338026220846621 11308317015145075756501143300 502803484968134736794324518976 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 810638799363455338026220846621 11308317015145075756501143300 502803484968134736794324518976 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 810638799363455338026220846621 11308317015145075756501143300 502803484968134736794324518976 5 20)=true := by decide +kernel
private theorem b49 : every 49 52 (line 810638799363455338026220846621 11308317015145075756501143300 502803484968134736794324518976 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 21=true := by
  apply row_high (h:=5713675965546985645390051352) (A:=810638799363455338026220846621) (S:=11308317015145075756501143300) (T:=502803484968134736794324518976) (R:=20) (B:=52) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 b17) (joinEvery b33 b49))
end OMA.EightAt19E21P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E22P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 16104006730645655791118367046668 214858023287756439373521722715 9987505587776130908141809763296 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 16104006730645655791118367046668 214858023287756439373521722715 9987505587776130908141809763296 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 16104006730645655791118367046668 214858023287756439373521722715 9987505587776130908141809763296 5 20)=true := by decide +kernel
private theorem b49 : every 49 51 (line 16104006730645655791118367046668 214858023287756439373521722715 9987505587776130908141809763296 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 22=true := by
  apply row_high (h:=108559843345392727262410975688) (A:=16104006730645655791118367046668) (S:=214858023287756439373521722715) (T:=9987505587776130908141809763296) (R:=20) (B:=51) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 b17) (joinEvery b33 b49))
end OMA.EightAt19E22P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E23P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 319311649194327543035032222143252 4082302442467372348096912731600 198013154261996334526637619654912 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 319311649194327543035032222143252 4082302442467372348096912731600 198013154261996334526637619654912 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 319311649194327543035032222143252 4082302442467372348096912731600 198013154261996334526637619654912 5 20)=true := by decide +kernel
private theorem b49 : every 49 51 (line 319311649194327543035032222143252 4082302442467372348096912731600 198013154261996334526637619654912 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 23=true := by
  apply row_high (h:=2062637023562461817985808538072) (A:=319311649194327543035032222143252) (S:=4082302442467372348096912731600) (T:=198013154261996334526637619654912) (R:=20) (B:=51) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 b17) (joinEvery b33 b49))
end OMA.EightAt19E23P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E24P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 6320296239621364894737493937596477 77563746406880074613841341900415 3919010344768677454173036222336800 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 6320296239621364894737493937596477 77563746406880074613841341900415 3919010344768677454173036222336800 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 6320296239621364894737493937596477 77563746406880074613841341900415 3919010344768677454173036222336800 5 20)=true := by decide +kernel
private theorem b49 : every 49 50 (line 6320296239621364894737493937596477 77563746406880074613841341900415 3919010344768677454173036222336800 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 24=true := by
  apply row_high (h:=39190103447686774541730362223368) (A:=6320296239621364894737493937596477) (S:=77563746406880074613841341900415) (T:=3919010344768677454173036222336800) (R:=20) (B:=50) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 b17) (joinEvery b33 b49))
end OMA.EightAt19E24P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E25P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 124899751746459622964378137434952203 1473711181730721417662985496107900 77439644412629066494459195753375168 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 124899751746459622964378137434952203 1473711181730721417662985496107900 77439644412629066494459195753375168 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 124899751746459622964378137434952203 1473711181730721417662985496107900 77439644412629066494459195753375168 5 20)=true := by decide +kernel
private theorem b49 : every 49 50 (line 124899751746459622964378137434952203 1473711181730721417662985496107900 77439644412629066494459195753375168 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 25=true := by
  apply row_high (h:=744611965506048716292876882243992) (A:=124899751746459622964378137434952203) (S:=1473711181730721417662985496107900) (T:=77439644412629066494459195753375168) (R:=20) (B:=50) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 b17) (joinEvery b33 b49))
end OMA.EightAt19E25P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E26P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 2464563623862152945646133911055855566 28000512452883706935596724426050115 1527943753218411965832983362364671584 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 2464563623862152945646133911055855566 28000512452883706935596724426050115 1527943753218411965832983362364671584 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 2464563623862152945646133911055855566 28000512452883706935596724426050115 1527943753218411965832983362364671584 5 20)=true := by decide +kernel
private theorem b49 : every 49 49 (line 2464563623862152945646133911055855566 28000512452883706935596724426050115 1527943753218411965832983362364671584 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 26=true := by
  apply row_high (h:=14147627344614925609564660762635848) (A:=2464563623862152945646133911055855566) (S:=28000512452883706935596724426050115) (T:=1527943753218411965832983362364671584) (R:=20) (B:=49) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 b17) (joinEvery b33 b49))
end OMA.EightAt19E26P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E27P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 48564607326289888044412581006104766274 532009736604790431776337764094952200 30106150989340561697153598102889084544 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 48564607326289888044412581006104766274 532009736604790431776337764094952200 30106150989340561697153598102889084544 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 48564607326289888044412581006104766274 532009736604790431776337764094952200 30106150989340561697153598102889084544 5 20)=true := by decide +kernel
private theorem b49 : every 49 49 (line 48564607326289888044412581006104766274 532009736604790431776337764094952200 30106150989340561697153598102889084544 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 27=true := by
  apply row_high (h:=268804919547683586581728554490081112) (A:=48564607326289888044412581006104766274) (S:=532009736604790431776337764094952200) (T:=30106150989340561697153598102889084544) (R:=20) (B:=49) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 b17) (joinEvery b33 b49))
end OMA.EightAt19E27P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E28P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 955747610184778532309423736340817259135 10108184995491018203750417517804091815 592446042683094624826129734096138770848 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 955747610184778532309423736340817259135 10108184995491018203750417517804091815 592446042683094624826129734096138770848 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 955747610184778532309423736340817259135 10108184995491018203750417517804091815 592446042683094624826129734096138770848 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 28=true := by
  apply row_high (h:=5107293471405988145052842535311541128) (A:=955747610184778532309423736340817259135) (S:=10108184995491018203750417517804091815) (T:=592446042683094624826129734096138770848) (R:=20) (B:=48) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery b1 (joinEvery b17 b33))
end OMA.EightAt19E28P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt19E29P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 18786585942230934643725160237747235222265 192055514914329345871257932838277744500 11644629114805652970720480980510313771840 5 20)=true := by decide +kernel
private theorem b17 : every 17 32 (line 18786585942230934643725160237747235222265 192055514914329345871257932838277744500 11644629114805652970720480980510313771840 5 20)=true := by decide +kernel
private theorem b33 : every 33 48 (line 18786585942230934643725160237747235222265 192055514914329345871257932838277744500 11644629114805652970720480980510313771840 5 20)=true := by decide +kernel
theorem certificate : atom 19 5 29=true := by
  apply row_high (h:=97038575956713774756004008170919281432) (A:=18786585942230934643725160237747235222265) (S:=192055514914329345871257932838277744500) (T:=11644629114805652970720480980510313771840) (R:=20) (B:=48) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery b1 (joinEvery b17 b33))
end OMA.EightAt19E29P5

namespace OMA.EightMoving5x19
open OMA.CofactorEulerPair245212 OMA.RankThreeEightMoving245212 OMA.Smooth245212
open OMA.RankThreeMiddle245212 (joinEvery)
open scoped ArithmeticFunction.sigma
private theorem range5 : every 1 29 (atom 5 19)=true := (joinEvery (joinEvery (joinEvery (joinEvery (single (f:=atom 5 19) OMA.EightAt5E1P19.certificate) (joinEvery (single (f:=atom 5 19) OMA.EightAt5E2P19.certificate) (single (f:=atom 5 19) OMA.EightAt5E3P19.certificate))) (joinEvery (joinEvery (single (f:=atom 5 19) OMA.EightAt5E4P19.certificate) (single (f:=atom 5 19) OMA.EightAt5E5P19.certificate)) (joinEvery (single (f:=atom 5 19) OMA.EightAt5E6P19.certificate) (single (f:=atom 5 19) OMA.EightAt5E7P19.certificate)))) (joinEvery (joinEvery (single (f:=atom 5 19) OMA.EightAt5E8P19.certificate) (joinEvery (single (f:=atom 5 19) OMA.EightAt5E9P19.certificate) (single (f:=atom 5 19) OMA.EightAt5E10P19.certificate))) (joinEvery (joinEvery (single (f:=atom 5 19) OMA.EightAt5E11P19.certificate) (single (f:=atom 5 19) OMA.EightAt5E12P19.certificate)) (joinEvery (single (f:=atom 5 19) OMA.EightAt5E13P19.certificate) (single (f:=atom 5 19) OMA.EightAt5E14P19.certificate))))) (joinEvery (joinEvery (joinEvery (single (f:=atom 5 19) OMA.EightAt5E15P19.certificate) (joinEvery (single (f:=atom 5 19) OMA.EightAt5E16P19.certificate) (single (f:=atom 5 19) OMA.EightAt5E17P19.certificate))) (joinEvery (joinEvery (single (f:=atom 5 19) OMA.EightAt5E18P19.certificate) (single (f:=atom 5 19) OMA.EightAt5E19P19.certificate)) (joinEvery (single (f:=atom 5 19) OMA.EightAt5E20P19.certificate) (single (f:=atom 5 19) OMA.EightAt5E21P19.certificate)))) (joinEvery (joinEvery (joinEvery (single (f:=atom 5 19) OMA.EightAt5E22P19.certificate) (single (f:=atom 5 19) OMA.EightAt5E23P19.certificate)) (joinEvery (single (f:=atom 5 19) OMA.EightAt5E24P19.certificate) (single (f:=atom 5 19) OMA.EightAt5E25P19.certificate))) (joinEvery (joinEvery (single (f:=atom 5 19) OMA.EightAt5E26P19.certificate) (single (f:=atom 5 19) OMA.EightAt5E27P19.certificate)) (joinEvery (single (f:=atom 5 19) OMA.EightAt5E28P19.certificate) (single (f:=atom 5 19) OMA.EightAt5E29P19.certificate))))))
private theorem range19 : every 1 29 (atom 19 5)=true := (joinEvery (joinEvery (joinEvery (joinEvery (single (f:=atom 19 5) OMA.EightAt19E1P5.certificate) (joinEvery (single (f:=atom 19 5) OMA.EightAt19E2P5.certificate) (single (f:=atom 19 5) OMA.EightAt19E3P5.certificate))) (joinEvery (joinEvery (single (f:=atom 19 5) OMA.EightAt19E4P5.certificate) (single (f:=atom 19 5) OMA.EightAt19E5P5.certificate)) (joinEvery (single (f:=atom 19 5) OMA.EightAt19E6P5.certificate) (single (f:=atom 19 5) OMA.EightAt19E7P5.certificate)))) (joinEvery (joinEvery (single (f:=atom 19 5) OMA.EightAt19E8P5.certificate) (joinEvery (single (f:=atom 19 5) OMA.EightAt19E9P5.certificate) (single (f:=atom 19 5) OMA.EightAt19E10P5.certificate))) (joinEvery (joinEvery (single (f:=atom 19 5) OMA.EightAt19E11P5.certificate) (single (f:=atom 19 5) OMA.EightAt19E12P5.certificate)) (joinEvery (single (f:=atom 19 5) OMA.EightAt19E13P5.certificate) (single (f:=atom 19 5) OMA.EightAt19E14P5.certificate))))) (joinEvery (joinEvery (joinEvery (single (f:=atom 19 5) OMA.EightAt19E15P5.certificate) (joinEvery (single (f:=atom 19 5) OMA.EightAt19E16P5.certificate) (single (f:=atom 19 5) OMA.EightAt19E17P5.certificate))) (joinEvery (joinEvery (single (f:=atom 19 5) OMA.EightAt19E18P5.certificate) (single (f:=atom 19 5) OMA.EightAt19E19P5.certificate)) (joinEvery (single (f:=atom 19 5) OMA.EightAt19E20P5.certificate) (single (f:=atom 19 5) OMA.EightAt19E21P5.certificate)))) (joinEvery (joinEvery (joinEvery (single (f:=atom 19 5) OMA.EightAt19E22P5.certificate) (single (f:=atom 19 5) OMA.EightAt19E23P5.certificate)) (joinEvery (single (f:=atom 19 5) OMA.EightAt19E24P5.certificate) (single (f:=atom 19 5) OMA.EightAt19E25P5.certificate))) (joinEvery (joinEvery (single (f:=atom 19 5) OMA.EightAt19E26P5.certificate) (single (f:=atom 19 5) OMA.EightAt19E27P5.certificate)) (joinEvery (single (f:=atom 19 5) OMA.EightAt19E28P5.certificate) (single (f:=atom 19 5) OMA.EightAt19E29P5.certificate))))))
theorem exclude {r a b c : ℕ} (pr : r.Prime) (large : 19<r) (ap : 0<a) (bp : 0<b) (cp : 0<c) :
    OeisA245212.a (8*5^a*19^b*r^c)≠(σ 1 (8*5^a*19^b*r^c):ℤ) :=
  close (l:=30) (u:=30) (by decide) (by decide) pr (by decide) (by decide) large ap bp cp (by decide +kernel) range5 range19
#print axioms exclude
end OMA.EightMoving5x19
