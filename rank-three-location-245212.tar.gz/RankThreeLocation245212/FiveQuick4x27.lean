import FiveQuick4x27S7
import FiveQuick4x27S151
import FiveQuick4x27S295
import FiveQuick4x27S439
import FiveQuick4x27S583
import FiveQuick4x27S727
import FiveQuick4x27S871
import FiveQuick4x27S1015
import FiveQuick4x27S1159
import FiveQuick4x27S1303
import FiveQuick4x27S1447
import FiveQuick4x27S1591
import FiveQuick4x27S1735
import FiveQuick4x27S1879
import FiveQuick4x27S2023
import FiveQuick4x27S2167
import FiveQuick4x27S2311
import FiveQuick4x27S2455
import FiveQuick4x27S2599
import FiveQuick4x27S2743
import FiveQuick4x27S2887
import FiveQuick4x27S3031
import FiveQuick4x27S3175
import FiveQuick4x27S3319
import FiveQuick4x27Far
import FiveFastNear245212
namespace OMA.FiveQuick4x27
open OMA.CofactorEulerPair245212 OMA.FiveFastNear245212
open OMA.RankThreeFiveTail245212 (cofactor wt sg ta)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 0
theorem original {p q b c : ℕ} (pp : p.Prime) (qp : q.Prime) (gt : 5<p) (pq : p<q) (bp : 0<b) (cp : 0<c) :
    OeisA245212.a (2^4*5^27*p^b*q^c)≠(ArithmeticFunction.sigma 1 (2^4*5^27*p^b*q^c):ℤ) :=
  OMA.RankThreeFiveShort245212.final (lo:=3374) pp qp gt pq bp cp (joinEvery (joinEvery (joinEvery (joinEvery span7 (joinEvery span151 span295)) (joinEvery span439 (joinEvery span583 span727))) (joinEvery (joinEvery span871 (joinEvery span1015 span1159)) (joinEvery span1303 (joinEvery span1447 span1591)))) (joinEvery (joinEvery (joinEvery span1735 (joinEvery span1879 span2023)) (joinEvery span2167 (joinEvery span2311 span2455))) (joinEvery (joinEvery span2599 (joinEvery span2743 span2887)) (joinEvery span3031 (joinEvery span3175 span3319))))) (by decide +kernel) OMA.FiveFar4x27.scan
#print axioms original
end OMA.FiveQuick4x27
