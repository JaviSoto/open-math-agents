import RankThreeEightFixed245212
/-! Kernel certificates for one ordered pair of odd bases at dyadic factor eight. -/
namespace OMA.EightRows5x31
open OMA.RankThreeEightFixed245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
theorem row37 : tests 5 31 37=true := by decide +kernel
theorem row41 : tests 5 31 41=true := by decide +kernel
theorem row43 : tests 5 31 43=true := by decide +kernel
theorem row47 : tests 5 31 47=true := by decide +kernel
theorem row53 : tests 5 31 53=true := by decide +kernel
theorem row59 : tests 5 31 59=true := by decide +kernel
theorem row61 : tests 5 31 61=true := by decide +kernel
theorem row67 : tests 5 31 67=true := by decide +kernel
theorem row71 : tests 5 31 71=true := by decide +kernel
theorem row73 : tests 5 31 73=true := by decide +kernel
theorem row79 : tests 5 31 79=true := by decide +kernel
theorem row83 : tests 5 31 83=true := by decide +kernel
theorem row89 : tests 5 31 89=true := by decide +kernel
end OMA.EightRows5x31
