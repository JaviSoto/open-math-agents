import RankThreeEightFixed245212
/-! Kernel certificates for one ordered pair of odd bases at dyadic factor eight. -/
namespace OMA.EightRows7x11
open OMA.RankThreeEightFixed245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
theorem row13 : tests 7 11 13=true := by decide +kernel
theorem row17 : tests 7 11 17=true := by decide +kernel
theorem row19 : tests 7 11 19=true := by decide +kernel
theorem row23 : tests 7 11 23=true := by decide +kernel
theorem row29 : tests 7 11 29=true := by decide +kernel
theorem row31 : tests 7 11 31=true := by decide +kernel
theorem row37 : tests 7 11 37=true := by decide +kernel
theorem row41 : tests 7 11 41=true := by decide +kernel
theorem row43 : tests 7 11 43=true := by decide +kernel
theorem row47 : tests 7 11 47=true := by decide +kernel
theorem row53 : tests 7 11 53=true := by decide +kernel
end OMA.EightRows7x11
