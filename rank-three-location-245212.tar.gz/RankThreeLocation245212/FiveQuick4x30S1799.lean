import FiveFastNear245212
namespace OMA.FiveQuick4x30
open OMA.CofactorEulerPair245212 OMA.FiveFastNear245212
open OMA.RankThreeFiveTail245212 (cofactor wt sg ta)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 0
theorem span1799 : every 1799 2054 (OMA.RankThreeFiveShort245212.test 4 30)=true :=
  interval (m:=31) (by decide +kernel) (show every 1799 2054 (fast 14901161193847656250000 4617904778569936752319344 36088749766349792480461 2309679985046386718750000 31)=true by decide +kernel)
end OMA.FiveQuick4x30
