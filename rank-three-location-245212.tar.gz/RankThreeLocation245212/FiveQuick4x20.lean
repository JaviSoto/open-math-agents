import FiveQuick4x20S7
import FiveQuick4x20S97
import FiveQuick4x20S187
import FiveQuick4x20S277
import FiveQuick4x20S367
import FiveQuick4x20S457
import FiveQuick4x20S547
import FiveQuick4x20S637
import FiveQuick4x20S727
import FiveQuick4x20S817
import FiveQuick4x20S907
import FiveQuick4x20Far
import FiveFastNear245212
namespace OMA.FiveQuick4x20
open OMA.CofactorEulerPair245212 OMA.FiveFastNear245212
open OMA.RankThreeFiveTail245212 (cofactor wt sg ta)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 0
theorem original {p q b c : ℕ} (pp : p.Prime) (qp : q.Prime) (gt : 5<p) (pq : p<q) (bp : 0<b) (cp : 0<c) :
    OeisA245212.a (2^4*5^20*p^b*q^c)≠(ArithmeticFunction.sigma 1 (2^4*5^20*p^b*q^c):ℤ) :=
  OMA.RankThreeFiveShort245212.final (lo:=956) pp qp gt pq bp cp (joinEvery (joinEvery (joinEvery span7 span97) (joinEvery span187 (joinEvery span277 span367))) (joinEvery (joinEvery span457 (joinEvery span547 span637)) (joinEvery span727 (joinEvery span817 span907)))) (by decide +kernel) OMA.FiveFar4x20.scan
#print axioms original
end OMA.FiveQuick4x20
