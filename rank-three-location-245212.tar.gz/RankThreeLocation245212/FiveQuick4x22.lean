import FiveQuick4x22S7
import FiveQuick4x22S97
import FiveQuick4x22S187
import FiveQuick4x22S277
import FiveQuick4x22S367
import FiveQuick4x22S457
import FiveQuick4x22S547
import FiveQuick4x22S637
import FiveQuick4x22S727
import FiveQuick4x22S817
import FiveQuick4x22S907
import FiveQuick4x22S997
import FiveQuick4x22S1087
import FiveQuick4x22S1177
import FiveQuick4x22S1267
import FiveQuick4x22Far
import FiveFastNear245212
namespace OMA.FiveQuick4x22
open OMA.CofactorEulerPair245212 OMA.FiveFastNear245212
open OMA.RankThreeFiveTail245212 (cofactor wt sg ta)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 0
theorem original {p q b c : ℕ} (pp : p.Prime) (qp : q.Prime) (gt : 5<p) (pq : p<q) (bp : 0<b) (cp : 0<c) :
    OeisA245212.a (2^4*5^22*p^b*q^c)≠(ArithmeticFunction.sigma 1 (2^4*5^22*p^b*q^c):ℤ) :=
  OMA.RankThreeFiveShort245212.final (lo:=1274) pp qp gt pq bp cp (joinEvery (joinEvery (joinEvery span7 (joinEvery span97 span187)) (joinEvery (joinEvery span277 span367) (joinEvery span457 span547))) (joinEvery (joinEvery (joinEvery span637 span727) (joinEvery span817 span907)) (joinEvery (joinEvery span997 span1087) (joinEvery span1177 span1267)))) (by decide +kernel) OMA.FiveFar4x22.scan
#print axioms original
end OMA.FiveQuick4x22
