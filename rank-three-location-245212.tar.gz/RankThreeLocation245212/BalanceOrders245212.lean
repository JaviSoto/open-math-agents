import ExactSigma245212

/-! All three two-adic orders in the divisor balance in terms of the exponents. -/
namespace OMA.BalanceOrders245212
open Finset Nat ArithmeticFunction OMA.Smooth245212 OMA.Abundance245212 OMA.ExactSigma245212
open scoped ArithmeticFunction.sigma Function

theorem orders {ι : Type*} [Fintype ι] (p e : ι → ℕ)
    (hp : ∀ i, (p i).Prime) (op : ∀ i, Odd (p i)) (inj : Function.Injective p) (a : ℕ) :
    let n := 2^a*total p e
    let T := ∑ i, v₂ (e i+1)
    let E := ∑ i, v₂ (e i+2)
    let U := ∑ i, surplus (p i) (e i)
    v₂ (W n)+Fintype.card ι=T+E ∧ v₂ (σ 1 n)=T+U ∧
      v₂ (2*n*(σ 0 n))=T+(1+a+v₂ (a+1)) := by
  classical
  dsimp only
  let z (i : ι) := p i^e i
  have cop : (↑(univ : Finset ι) : Set ι).Pairwise (Coprime on z) := by
    intro i _ j _ ne
    exact (((Nat.coprime_primes (hp i) (hp j)).mpr (fun h => ne (inj h))).pow_left _).pow_right _
  have oc : (2:ℕ).Coprime (total p e) := Coprime.prod_right (fun i _ =>
    (Nat.coprime_two_left.mpr (op i)).pow_right (e i))
  have co := oc.pow_left a
  have zn : total p e ≠ 0 := prod_ne_zero_iff.mpr (fun i _ => pow_ne_zero _ (hp i).ne_zero)
  have wpos (i : ι) : W (z i) ≠ 0 := by
    rw [show z i=p i^e i from rfl,w_pow (hp i)]
    exact (sum_pos' (fun _ _ => Nat.zero_le _) ⟨0,mem_range.mpr (by omega),by simp⟩).ne'
  have wm : W (total p e) = ∏ i, W (z i) := IsMultiplicative.map_prod z w_mult univ cop
  have tm : σ 0 (total p e) = ∏ i, (e i+1) := by
    simpa only [z,total,sigma_zero_apply_prime_pow (hp _)] using
      IsMultiplicative.map_prod z (isMultiplicative_sigma (k:=0)) univ cop
  have sm : σ 1 (total p e) = ∏ i, σ 1 (z i) :=
    IsMultiplicative.map_prod z (isMultiplicative_sigma (k:=1)) univ cop
  have vp (f : ι → ℕ) (hf : ∀ i, f i≠0) :
      v₂ (∏ i, f i) = ∑ i, v₂ (f i) := Nat.factorization_prod_apply fun i _ => hf i
  have wa := OMA.DyadicPower245212.dyadic_odd a
  have sa := sigma_two_odd a
  constructor
  · rw [w_mult.map_mul_of_coprime co,wm,mul_val wa.pos.ne' (prod_ne_zero_iff.mpr (fun i _ => wpos i)),
      show v₂ (W (2^a))=0 from OMA.WeightVal245212.val_odd wa,zero_add,vp _ wpos]
    have h := sum_congr (s₁:=univ) rfl (fun i _ => OMA.WeightVal245212.weight_local (hp i) (op i) (e i))
    simp only [sum_add_distrib,sum_const,smul_eq_mul,mul_one] at h
    exact h
  constructor
  · rw [isMultiplicative_sigma.map_mul_of_coprime co,mul_val sa.pos.ne' (sigma_pos _ _ zn).ne',
      show v₂ (σ 1 (2^a))=0 from OMA.WeightVal245212.val_odd sa,zero_add,sm,
      vp _ (fun i => (sigma_pos 1 _ (pow_ne_zero _ (hp i).ne_zero)).ne'),←sum_add_distrib]
    exact sum_congr rfl (fun i _ => local_sigma (hp i) (op i) (e i))
  · have z2 : 2^a≠0 := by positivity
    have nz := mul_ne_zero z2 zn
    rw [mul_val (mul_ne_zero (by decide) nz) (sigma_pos 0 _ nz).ne',
      mul_val (by decide) nz,mul_val z2 zn,isMultiplicative_sigma.map_mul_of_coprime co,
      sigma_zero_apply_prime_pow Nat.prime_two,tm,mul_val (by omega) (prod_ne_zero_iff.mpr (fun _ _ => by omega)),
      vp _ (fun _ => by omega),show v₂ (total p e)=0 from OMA.WeightVal245212.val_odd
        (Nat.coprime_two_left.mp oc),show v₂ (2^a)=a from Nat.factorization_pow_self Nat.prime_two]
    have : v₂ 2=1 := by decide +kernel
    omega

/-- Compare the ordinary-divisor surplus U and the dyadic threshold H.
The weighted surplus equals their minimum unless they coincide, when it is larger. -/
theorem trichotomy {ι : Type*} [Fintype ι] (p e : ι → ℕ)
    (hp : ∀ i, (p i).Prime) (op : ∀ i, Odd (p i)) (inj : Function.Injective p)
    (a : ℕ) (eq : OeisA245212.a (2^a*total p e) = (σ 1 (2^a*total p e) : ℤ)) :
    let E := ∑ i, v₂ (e i+2)
    let U := ∑ i, surplus (p i) (e i)
    let H := 1+a+v₂ (a+1)
    (U<H → E=Fintype.card ι+U) ∧ (H<U → E=Fintype.card ι+H) ∧
      (U=H → Fintype.card ι+H<E) := by
  let n := 2^a*total p e
  have nz : n≠0 := mul_ne_zero (by positivity) (prod_ne_zero_iff.mpr (fun i _ => pow_ne_zero _ (hp i).ne_zero))
  have h := balance nz eq
  have ws : W n≠0 := by
    rw [w_apply]
    exact (sum_pos' (fun _ _ => Nat.zero_le _) ⟨1,one_mem_divisors.mpr nz,by simp⟩).ne'
  have ss := (sigma_pos 1 n nz).ne'
  have x := orders p e hp op inj a
  change v₂ (W n)+Fintype.card ι=_ ∧ v₂ (σ 1 n)=_ ∧ v₂ (2*n*(σ 0 n))=_ at x
  rw [←h] at x
  obtain ⟨w,s,b⟩ := x
  dsimp only
  rcases lt_trichotomy (v₂ (W n)) (v₂ (σ 1 n)) with lo|same|hi
  · have ord := sum_of_lt ws ss lo
    omega
  · have ord := sum_of_equal ws ss same
    omega
  · have ord := sum_of_lt ss ws hi
    rw [add_comm] at ord
    omega

end OMA.BalanceOrders245212
