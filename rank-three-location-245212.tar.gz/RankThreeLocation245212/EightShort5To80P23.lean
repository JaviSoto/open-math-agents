import RankThreeEightMoving245212
/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E1P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
theorem certificate : atom 5 23 1=true := by
  apply row_low (h:=40) (A:=539) (S:=90) (T:=320) (R:=24) (Q:=8) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 8≤24+128)]
  exact (by decide +kernel)
end OMA.EightAt5E1P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E2P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
theorem certificate : atom 5 23 2=true := by
  apply row_low (h:=200) (A:=4214) (S:=465) (T:=2400) (R:=24) (Q:=12) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 12≤24+128)]
  exact (by decide +kernel)
end OMA.EightAt5E2P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E3P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
theorem certificate : atom 5 23 3=true := by
  apply row_low (h:=1000) (A:=28714) (S:=2340) (T:=16000) (R:=24) (Q:=16) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 16≤24+128)]
  exact (by decide +kernel)
end OMA.EightAt5E3P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E4P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
theorem certificate : atom 5 23 4=true := by
  apply row_low (h:=5000) (A:=181839) (S:=11715) (T:=100000) (R:=24) (Q:=20) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 20≤24+128)]
  exact (by decide +kernel)
end OMA.EightAt5E4P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E5P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 24 (quick 25000 1100589 58590 600000 23)=true := by decide +kernel
theorem certificate : atom 5 23 5=true := by
  apply row_low (h:=25000) (A:=1100589) (S:=58590) (T:=600000) (R:=24) (Q:=24) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 24≤24+128)]
  exact b24
end OMA.EightAt5E5P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E6P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 28 (quick 125000 6459964 292965 3500000 23)=true := by decide +kernel
theorem certificate : atom 5 23 6=true := by
  apply row_low (h:=125000) (A:=6459964) (S:=292965) (T:=3500000) (R:=24) (Q:=28) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 28≤24+128)]
  exact b24
end OMA.EightAt5E6P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E7P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 32 (quick 625000 37084964 1464840 20000000 23)=true := by decide +kernel
theorem certificate : atom 5 23 7=true := by
  apply row_low (h:=625000) (A:=37084964) (S:=1464840) (T:=20000000) (R:=24) (Q:=32) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 32≤24+128)]
  exact b24
end OMA.EightAt5E7P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E8P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 36 (quick 3125000 209350589 7324215 112500000 23)=true := by decide +kernel
theorem certificate : atom 5 23 8=true := by
  apply row_low (h:=3125000) (A:=209350589) (S:=7324215) (T:=112500000) (R:=24) (Q:=36) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 36≤24+128)]
  exact b24
end OMA.EightAt5E8P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E9P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 15625000 1166381839 36621090 625000000 23)=true := by decide +kernel
private theorem b40 : every 40 40 (quick 15625000 1166381839 36621090 625000000 23)=true := by decide +kernel
theorem certificate : atom 5 23 9=true := by
  apply row_low (h:=15625000) (A:=1166381839) (S:=36621090) (T:=625000000) (R:=24) (Q:=40) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 40≤24+128)]
  exact (joinEvery b24 b40)
end OMA.EightAt5E9P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E10P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 78125000 6430053714 183105465 3437500000 23)=true := by decide +kernel
private theorem b40 : every 40 45 (quick 78125000 6430053714 183105465 3437500000 23)=true := by decide +kernel
theorem certificate : atom 5 23 10=true := by
  apply row_low (h:=78125000) (A:=6430053714) (S:=183105465) (T:=3437500000) (R:=24) (Q:=45) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 45≤24+128)]
  exact (joinEvery b24 b40)
end OMA.EightAt5E10P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E11P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 390625000 35140991214 915527340 18750000000 23)=true := by decide +kernel
private theorem b40 : every 40 49 (quick 390625000 35140991214 915527340 18750000000 23)=true := by decide +kernel
theorem certificate : atom 5 23 11=true := by
  apply row_low (h:=390625000) (A:=35140991214) (S:=915527340) (T:=18750000000) (R:=24) (Q:=49) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 49≤24+128)]
  exact (joinEvery b24 b40)
end OMA.EightAt5E11P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E12P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 1953125000 190658569339 4577636715 101562500000 23)=true := by decide +kernel
private theorem b40 : every 40 53 (quick 1953125000 190658569339 4577636715 101562500000 23)=true := by decide +kernel
theorem certificate : atom 5 23 12=true := by
  apply row_low (h:=1953125000) (A:=190658569339) (S:=4577636715) (T:=101562500000) (R:=24) (Q:=53) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 53≤24+128)]
  exact (joinEvery b24 b40)
end OMA.EightAt5E12P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E13P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 9765625000 1028060913089 22888183590 546875000000 23)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 9765625000 1028060913089 22888183590 546875000000 23)=true := by decide +kernel
private theorem b56 : every 56 57 (quick 9765625000 1028060913089 22888183590 546875000000 23)=true := by decide +kernel
theorem certificate : atom 5 23 13=true := by
  apply row_low (h:=9765625000) (A:=1028060913089) (S:=22888183590) (T:=546875000000) (R:=24) (Q:=57) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 57≤24+128)]
  exact (joinEvery b24 (joinEvery b40 b56))
end OMA.EightAt5E13P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E14P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 48828125000 5514144897464 114440917965 2929687500000 23)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 48828125000 5514144897464 114440917965 2929687500000 23)=true := by decide +kernel
private theorem b56 : every 56 61 (quick 48828125000 5514144897464 114440917965 2929687500000 23)=true := by decide +kernel
theorem certificate : atom 5 23 14=true := by
  apply row_low (h:=48828125000) (A:=5514144897464) (S:=114440917965) (T:=2929687500000) (R:=24) (Q:=61) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 61≤24+128)]
  exact (joinEvery b24 (joinEvery b40 b56))
end OMA.EightAt5E14P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E15P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 244140625000 29439926147464 572204589840 15625000000000 23)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 244140625000 29439926147464 572204589840 15625000000000 23)=true := by decide +kernel
private theorem b56 : every 56 66 (quick 244140625000 29439926147464 572204589840 15625000000000 23)=true := by decide +kernel
theorem certificate : atom 5 23 15=true := by
  apply row_low (h:=244140625000) (A:=29439926147464) (S:=572204589840) (T:=15625000000000) (R:=24) (Q:=66) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 66≤24+128)]
  exact (joinEvery b24 (joinEvery b40 b56))
end OMA.EightAt5E15P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E16P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 1220703125000 156545639038089 2861022949215 83007812500000 23)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 1220703125000 156545639038089 2861022949215 83007812500000 23)=true := by decide +kernel
private theorem b56 : every 56 70 (quick 1220703125000 156545639038089 2861022949215 83007812500000 23)=true := by decide +kernel
theorem certificate : atom 5 23 16=true := by
  apply row_low (h:=1220703125000) (A:=156545639038089) (S:=2861022949215) (T:=83007812500000) (R:=24) (Q:=70) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 70≤24+128)]
  exact (joinEvery b24 (joinEvery b40 b56))
end OMA.EightAt5E16P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E17P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 6103515625000 829458236694339 14305114746090 439453125000000 23)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 6103515625000 829458236694339 14305114746090 439453125000000 23)=true := by decide +kernel
private theorem b56 : every 56 71 (quick 6103515625000 829458236694339 14305114746090 439453125000000 23)=true := by decide +kernel
private theorem b72 : every 72 74 (quick 6103515625000 829458236694339 14305114746090 439453125000000 23)=true := by decide +kernel
theorem certificate : atom 5 23 17=true := by
  apply row_low (h:=6103515625000) (A:=829458236694339) (S:=14305114746090) (T:=439453125000000) (R:=24) (Q:=74) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 74≤24+128)]
  exact (joinEvery (joinEvery b24 b40) (joinEvery b56 b72))
end OMA.EightAt5E17P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E18P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 30517578125000 4380941390991214 71525573730465 2319335937500000 23)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 30517578125000 4380941390991214 71525573730465 2319335937500000 23)=true := by decide +kernel
private theorem b56 : every 56 71 (quick 30517578125000 4380941390991214 71525573730465 2319335937500000 23)=true := by decide +kernel
private theorem b72 : every 72 79 (quick 30517578125000 4380941390991214 71525573730465 2319335937500000 23)=true := by decide +kernel
theorem certificate : atom 5 23 18=true := by
  apply row_low (h:=30517578125000) (A:=4380941390991214) (S:=71525573730465) (T:=2319335937500000) (R:=24) (Q:=79) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 79≤24+128)]
  exact (joinEvery (joinEvery b24 b40) (joinEvery b56 b72))
end OMA.EightAt5E18P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E19P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 152587890625000 23072957992553714 357627868652340 12207031250000000 23)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 152587890625000 23072957992553714 357627868652340 12207031250000000 23)=true := by decide +kernel
private theorem b56 : every 56 71 (quick 152587890625000 23072957992553714 357627868652340 12207031250000000 23)=true := by decide +kernel
private theorem b72 : every 72 83 (quick 152587890625000 23072957992553714 357627868652340 12207031250000000 23)=true := by decide +kernel
theorem certificate : atom 5 23 19=true := by
  apply row_low (h:=152587890625000) (A:=23072957992553714) (S:=357627868652340) (T:=12207031250000000) (R:=24) (Q:=83) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 83≤24+128)]
  exact (joinEvery (joinEvery b24 b40) (joinEvery b56 b72))
end OMA.EightAt5E19P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E20P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 762939453125000 121206045150756839 1788139343261715 64086914062500000 23)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 762939453125000 121206045150756839 1788139343261715 64086914062500000 23)=true := by decide +kernel
private theorem b56 : every 56 71 (quick 762939453125000 121206045150756839 1788139343261715 64086914062500000 23)=true := by decide +kernel
private theorem b72 : every 72 87 (quick 762939453125000 121206045150756839 1788139343261715 64086914062500000 23)=true := by decide +kernel
theorem certificate : atom 5 23 20=true := by
  apply row_low (h:=762939453125000) (A:=121206045150756839) (S:=1788139343261715) (T:=64086914062500000) (R:=24) (Q:=87) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 87≤24+128)]
  exact (joinEvery (joinEvery b24 b40) (joinEvery b56 b72))
end OMA.EightAt5E20P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E21P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 3814697265625000 635236501693725589 8940696716308590 335693359375000000 23)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 3814697265625000 635236501693725589 8940696716308590 335693359375000000 23)=true := by decide +kernel
private theorem b56 : every 56 71 (quick 3814697265625000 635236501693725589 8940696716308590 335693359375000000 23)=true := by decide +kernel
private theorem b72 : every 72 87 (quick 3814697265625000 635236501693725589 8940696716308590 335693359375000000 23)=true := by decide +kernel
private theorem b88 : every 88 92 (quick 3814697265625000 635236501693725589 8940696716308590 335693359375000000 23)=true := by decide +kernel
theorem certificate : atom 5 23 21=true := by
  apply row_low (h:=3814697265625000) (A:=635236501693725589) (S:=8940696716308590) (T:=335693359375000000) (R:=24) (Q:=92) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 92≤24+128)]
  exact (joinEvery (joinEvery b24 b40) (joinEvery b56 (joinEvery b72 b88)))
end OMA.EightAt5E21P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E22P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 19073486328125000 3322213888168334964 44703483581542965 1754760742187500000 23)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 19073486328125000 3322213888168334964 44703483581542965 1754760742187500000 23)=true := by decide +kernel
private theorem b56 : every 56 71 (quick 19073486328125000 3322213888168334964 44703483581542965 1754760742187500000 23)=true := by decide +kernel
private theorem b72 : every 72 87 (quick 19073486328125000 3322213888168334964 44703483581542965 1754760742187500000 23)=true := by decide +kernel
private theorem b88 : every 88 96 (quick 19073486328125000 3322213888168334964 44703483581542965 1754760742187500000 23)=true := by decide +kernel
theorem certificate : atom 5 23 22=true := by
  apply row_low (h:=19073486328125000) (A:=3322213888168334964) (S:=44703483581542965) (T:=1754760742187500000) (R:=24) (Q:=96) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 96≤24+128)]
  exact (joinEvery (joinEvery b24 b40) (joinEvery b56 (joinEvery b72 b88)))
end OMA.EightAt5E22P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E23P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 95367431640625000 17341226339340209964 223517417907714840 9155273437500000000 23)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 95367431640625000 17341226339340209964 223517417907714840 9155273437500000000 23)=true := by decide +kernel
private theorem b56 : every 56 71 (quick 95367431640625000 17341226339340209964 223517417907714840 9155273437500000000 23)=true := by decide +kernel
private theorem b72 : every 72 87 (quick 95367431640625000 17341226339340209964 223517417907714840 9155273437500000000 23)=true := by decide +kernel
private theorem b88 : every 88 101 (quick 95367431640625000 17341226339340209964 223517417907714840 9155273437500000000 23)=true := by decide +kernel
theorem certificate : atom 5 23 23=true := by
  apply row_low (h:=95367431640625000) (A:=17341226339340209964) (S:=223517417907714840) (T:=9155273437500000000) (R:=24) (Q:=101) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 101≤24+128)]
  exact (joinEvery (joinEvery b24 b40) (joinEvery b56 (joinEvery b72 b88)))
end OMA.EightAt5E23P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E24P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 476837158203125000 90356916189193725589 1117587089538574215 47683715820312500000 23)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 476837158203125000 90356916189193725589 1117587089538574215 47683715820312500000 23)=true := by decide +kernel
private theorem b56 : every 56 71 (quick 476837158203125000 90356916189193725589 1117587089538574215 47683715820312500000 23)=true := by decide +kernel
private theorem b72 : every 72 87 (quick 476837158203125000 90356916189193725589 1117587089538574215 47683715820312500000 23)=true := by decide +kernel
private theorem b88 : every 88 103 (quick 476837158203125000 90356916189193725589 1117587089538574215 47683715820312500000 23)=true := by decide +kernel
private theorem b104 : every 104 105 (quick 476837158203125000 90356916189193725589 1117587089538574215 47683715820312500000 23)=true := by decide +kernel
theorem certificate : atom 5 23 24=true := by
  apply row_low (h:=476837158203125000) (A:=90356916189193725589) (S:=1117587089538574215) (T:=47683715820312500000) (R:=24) (Q:=105) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 105≤24+128)]
  exact (joinEvery (joinEvery b24 (joinEvery b40 b56)) (joinEvery b72 (joinEvery b88 b104)))
end OMA.EightAt5E24P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E25P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 2384185791015625000 470038503408432006839 5587935447692871090 247955322265625000000 23)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 2384185791015625000 470038503408432006839 5587935447692871090 247955322265625000000 23)=true := by decide +kernel
private theorem b56 : every 56 71 (quick 2384185791015625000 470038503408432006839 5587935447692871090 247955322265625000000 23)=true := by decide +kernel
private theorem b72 : every 72 87 (quick 2384185791015625000 470038503408432006839 5587935447692871090 247955322265625000000 23)=true := by decide +kernel
private theorem b88 : every 88 103 (quick 2384185791015625000 470038503408432006839 5587935447692871090 247955322265625000000 23)=true := by decide +kernel
private theorem b104 : every 104 110 (quick 2384185791015625000 470038503408432006839 5587935447692871090 247955322265625000000 23)=true := by decide +kernel
theorem certificate : atom 5 23 25=true := by
  apply row_low (h:=2384185791015625000) (A:=470038503408432006839) (S:=5587935447692871090) (T:=247955322265625000000) (R:=24) (Q:=110) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 110≤24+128)]
  exact (joinEvery (joinEvery b24 (joinEvery b40 b56)) (joinEvery b72 (joinEvery b88 b104)))
end OMA.EightAt5E25P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E26P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 11920928955078125000 2441462129354476928714 27939677238464355465 1287460327148437500000 23)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 11920928955078125000 2441462129354476928714 27939677238464355465 1287460327148437500000 23)=true := by decide +kernel
private theorem b56 : every 56 71 (quick 11920928955078125000 2441462129354476928714 27939677238464355465 1287460327148437500000 23)=true := by decide +kernel
private theorem b72 : every 72 87 (quick 11920928955078125000 2441462129354476928714 27939677238464355465 1287460327148437500000 23)=true := by decide +kernel
private theorem b88 : every 88 103 (quick 11920928955078125000 2441462129354476928714 27939677238464355465 1287460327148437500000 23)=true := by decide +kernel
private theorem b104 : every 104 114 (quick 11920928955078125000 2441462129354476928714 27939677238464355465 1287460327148437500000 23)=true := by decide +kernel
theorem certificate : atom 5 23 26=true := by
  apply row_low (h:=11920928955078125000) (A:=2441462129354476928714) (S:=27939677238464355465) (T:=1287460327148437500000) (R:=24) (Q:=114) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 114≤24+128)]
  exact (joinEvery (joinEvery b24 (joinEvery b40 b56)) (joinEvery b72 (joinEvery b88 b104)))
end OMA.EightAt5E26P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E27P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 59604644775390625000 12663658708333969116214 139698386192321777340 6675720214843750000000 23)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 59604644775390625000 12663658708333969116214 139698386192321777340 6675720214843750000000 23)=true := by decide +kernel
private theorem b56 : every 56 71 (quick 59604644775390625000 12663658708333969116214 139698386192321777340 6675720214843750000000 23)=true := by decide +kernel
private theorem b72 : every 72 87 (quick 59604644775390625000 12663658708333969116214 139698386192321777340 6675720214843750000000 23)=true := by decide +kernel
private theorem b88 : every 88 103 (quick 59604644775390625000 12663658708333969116214 139698386192321777340 6675720214843750000000 23)=true := by decide +kernel
private theorem b104 : every 104 119 (quick 59604644775390625000 12663658708333969116214 139698386192321777340 6675720214843750000000 23)=true := by decide +kernel
theorem certificate : atom 5 23 27=true := by
  apply row_low (h:=59604644775390625000) (A:=12663658708333969116214) (S:=139698386192321777340) (T:=6675720214843750000000) (R:=24) (Q:=119) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 119≤24+128)]
  exact (joinEvery (joinEvery b24 (joinEvery b40 b56)) (joinEvery b72 (joinEvery b88 b104)))
end OMA.EightAt5E27P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E28P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 298023223876953125000 65600033849477767944339 698491930961608886715 34570693969726562500000 23)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 298023223876953125000 65600033849477767944339 698491930961608886715 34570693969726562500000 23)=true := by decide +kernel
private theorem b56 : every 56 71 (quick 298023223876953125000 65600033849477767944339 698491930961608886715 34570693969726562500000 23)=true := by decide +kernel
private theorem b72 : every 72 87 (quick 298023223876953125000 65600033849477767944339 698491930961608886715 34570693969726562500000 23)=true := by decide +kernel
private theorem b88 : every 88 103 (quick 298023223876953125000 65600033849477767944339 698491930961608886715 34570693969726562500000 23)=true := by decide +kernel
private theorem b104 : every 104 119 (quick 298023223876953125000 65600033849477767944339 698491930961608886715 34570693969726562500000 23)=true := by decide +kernel
private theorem b120 : every 120 123 (quick 298023223876953125000 65600033849477767944339 698491930961608886715 34570693969726562500000 23)=true := by decide +kernel
theorem certificate : atom 5 23 28=true := by
  apply row_low (h:=298023223876953125000) (A:=65600033849477767944339) (S:=698491930961608886715) (T:=34570693969726562500000) (R:=24) (Q:=123) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 123≤24+128)]
  exact (joinEvery (joinEvery b24 (joinEvery b40 b56)) (joinEvery (joinEvery b72 b88) (joinEvery b104 b120)))
end OMA.EightAt5E28P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E29P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 1490116119384765625000 339408870786428451538089 3492459654808044433590 178813934326171875000000 23)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 1490116119384765625000 339408870786428451538089 3492459654808044433590 178813934326171875000000 23)=true := by decide +kernel
private theorem b56 : every 56 71 (quick 1490116119384765625000 339408870786428451538089 3492459654808044433590 178813934326171875000000 23)=true := by decide +kernel
private theorem b72 : every 72 87 (quick 1490116119384765625000 339408870786428451538089 3492459654808044433590 178813934326171875000000 23)=true := by decide +kernel
private theorem b88 : every 88 103 (quick 1490116119384765625000 339408870786428451538089 3492459654808044433590 178813934326171875000000 23)=true := by decide +kernel
private theorem b104 : every 104 119 (quick 1490116119384765625000 339408870786428451538089 3492459654808044433590 178813934326171875000000 23)=true := by decide +kernel
private theorem b120 : every 120 128 (quick 1490116119384765625000 339408870786428451538089 3492459654808044433590 178813934326171875000000 23)=true := by decide +kernel
theorem certificate : atom 5 23 29=true := by
  apply row_low (h:=1490116119384765625000) (A:=339408870786428451538089) (S:=3492459654808044433590) (T:=178813934326171875000000) (R:=24) (Q:=128) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 128≤24+128)]
  exact (joinEvery (joinEvery b24 (joinEvery b40 b56)) (joinEvery (joinEvery b72 b88) (joinEvery b104 b120)))
end OMA.EightAt5E29P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E30P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 7450580596923828125000 1754087861627340316772464 17462298274040222167965 923871994018554687500000 23)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 7450580596923828125000 1754087861627340316772464 17462298274040222167965 923871994018554687500000 23)=true := by decide +kernel
private theorem b56 : every 56 71 (quick 7450580596923828125000 1754087861627340316772464 17462298274040222167965 923871994018554687500000 23)=true := by decide +kernel
private theorem b72 : every 72 87 (quick 7450580596923828125000 1754087861627340316772464 17462298274040222167965 923871994018554687500000 23)=true := by decide +kernel
private theorem b88 : every 88 103 (quick 7450580596923828125000 1754087861627340316772464 17462298274040222167965 923871994018554687500000 23)=true := by decide +kernel
private theorem b104 : every 104 119 (quick 7450580596923828125000 1754087861627340316772464 17462298274040222167965 923871994018554687500000 23)=true := by decide +kernel
private theorem b120 : every 120 132 (quick 7450580596923828125000 1754087861627340316772464 17462298274040222167965 923871994018554687500000 23)=true := by decide +kernel
theorem certificate : atom 5 23 30=true := by
  apply row_low (h:=7450580596923828125000) (A:=1754087861627340316772464) (S:=17462298274040222167965) (T:=923871994018554687500000) (R:=24) (Q:=132) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 132≤24+128)]
  exact (joinEvery (joinEvery b24 (joinEvery b40 b56)) (joinEvery (joinEvery b72 b88) (joinEvery b104 b120)))
end OMA.EightAt5E30P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E31P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 37252902984619140625000 9055656846612691879272464 87311491370201110839840 4768371582031250000000000 23)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 37252902984619140625000 9055656846612691879272464 87311491370201110839840 4768371582031250000000000 23)=true := by decide +kernel
private theorem b56 : every 56 71 (quick 37252902984619140625000 9055656846612691879272464 87311491370201110839840 4768371582031250000000000 23)=true := by decide +kernel
private theorem b72 : every 72 87 (quick 37252902984619140625000 9055656846612691879272464 87311491370201110839840 4768371582031250000000000 23)=true := by decide +kernel
private theorem b88 : every 88 103 (quick 37252902984619140625000 9055656846612691879272464 87311491370201110839840 4768371582031250000000000 23)=true := by decide +kernel
private theorem b104 : every 104 119 (quick 37252902984619140625000 9055656846612691879272464 87311491370201110839840 4768371582031250000000000 23)=true := by decide +kernel
private theorem b120 : every 120 135 (quick 37252902984619140625000 9055656846612691879272464 87311491370201110839840 4768371582031250000000000 23)=true := by decide +kernel
private theorem b136 : every 136 137 (quick 37252902984619140625000 9055656846612691879272464 87311491370201110839840 4768371582031250000000000 23)=true := by decide +kernel
theorem certificate : atom 5 23 31=true := by
  apply row_low (h:=37252902984619140625000) (A:=9055656846612691879272464) (S:=87311491370201110839840) (T:=4768371582031250000000000) (R:=24) (Q:=137) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 137≤24+128)]
  exact (joinEvery (joinEvery (joinEvery b24 b40) (joinEvery b56 b72)) (joinEvery (joinEvery b88 b104) (joinEvery b120 b136)))
end OMA.EightAt5E31P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E32P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 186264514923095703125000 46704371925443410873413089 436557456851005554199215 24586915969848632812500000 23)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 186264514923095703125000 46704371925443410873413089 436557456851005554199215 24586915969848632812500000 23)=true := by decide +kernel
private theorem b56 : every 56 71 (quick 186264514923095703125000 46704371925443410873413089 436557456851005554199215 24586915969848632812500000 23)=true := by decide +kernel
private theorem b72 : every 72 87 (quick 186264514923095703125000 46704371925443410873413089 436557456851005554199215 24586915969848632812500000 23)=true := by decide +kernel
private theorem b88 : every 88 103 (quick 186264514923095703125000 46704371925443410873413089 436557456851005554199215 24586915969848632812500000 23)=true := by decide +kernel
private theorem b104 : every 104 119 (quick 186264514923095703125000 46704371925443410873413089 436557456851005554199215 24586915969848632812500000 23)=true := by decide +kernel
private theorem b120 : every 120 135 (quick 186264514923095703125000 46704371925443410873413089 436557456851005554199215 24586915969848632812500000 23)=true := by decide +kernel
private theorem b136 : every 136 141 (quick 186264514923095703125000 46704371925443410873413089 436557456851005554199215 24586915969848632812500000 23)=true := by decide +kernel
theorem certificate : atom 5 23 32=true := by
  apply row_low (h:=186264514923095703125000) (A:=46704371925443410873413089) (S:=436557456851005554199215) (T:=24586915969848632812500000) (R:=24) (Q:=141) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 141≤24+128)]
  exact (joinEvery (joinEvery (joinEvery b24 b40) (joinEvery b56 b72)) (joinEvery (joinEvery b88 b104) (joinEvery b120 b136)))
end OMA.EightAt5E32P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E33P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 931322574615478515625000 240652298089116811752319339 2182787284255027770996090 126659870147705078125000000 23)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 931322574615478515625000 240652298089116811752319339 2182787284255027770996090 126659870147705078125000000 23)=true := by decide +kernel
private theorem b56 : every 56 71 (quick 931322574615478515625000 240652298089116811752319339 2182787284255027770996090 126659870147705078125000000 23)=true := by decide +kernel
private theorem b72 : every 72 87 (quick 931322574615478515625000 240652298089116811752319339 2182787284255027770996090 126659870147705078125000000 23)=true := by decide +kernel
private theorem b88 : every 88 103 (quick 931322574615478515625000 240652298089116811752319339 2182787284255027770996090 126659870147705078125000000 23)=true := by decide +kernel
private theorem b104 : every 104 119 (quick 931322574615478515625000 240652298089116811752319339 2182787284255027770996090 126659870147705078125000000 23)=true := by decide +kernel
private theorem b120 : every 120 135 (quick 931322574615478515625000 240652298089116811752319339 2182787284255027770996090 126659870147705078125000000 23)=true := by decide +kernel
private theorem b136 : every 136 146 (quick 931322574615478515625000 240652298089116811752319339 2182787284255027770996090 126659870147705078125000000 23)=true := by decide +kernel
theorem certificate : atom 5 23 33=true := by
  apply row_low (h:=931322574615478515625000) (A:=240652298089116811752319339) (S:=2182787284255027770996090) (T:=126659870147705078125000000) (R:=24) (Q:=146) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 146≤24+128)]
  exact (joinEvery (joinEvery (joinEvery b24 b40) (joinEvery b56 b72)) (joinEvery (joinEvery b88 b104) (joinEvery b120 b136)))
end OMA.EightAt5E33P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E34P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b24 : every 24 39 (quick 4656612873077392578125000 1238913682755082845687866214 10913936421275138854980465 651925802230834960937500000 23)=true := by decide +kernel
private theorem b40 : every 40 55 (quick 4656612873077392578125000 1238913682755082845687866214 10913936421275138854980465 651925802230834960937500000 23)=true := by decide +kernel
private theorem b56 : every 56 71 (quick 4656612873077392578125000 1238913682755082845687866214 10913936421275138854980465 651925802230834960937500000 23)=true := by decide +kernel
private theorem b72 : every 72 87 (quick 4656612873077392578125000 1238913682755082845687866214 10913936421275138854980465 651925802230834960937500000 23)=true := by decide +kernel
private theorem b88 : every 88 103 (quick 4656612873077392578125000 1238913682755082845687866214 10913936421275138854980465 651925802230834960937500000 23)=true := by decide +kernel
private theorem b104 : every 104 119 (quick 4656612873077392578125000 1238913682755082845687866214 10913936421275138854980465 651925802230834960937500000 23)=true := by decide +kernel
private theorem b120 : every 120 135 (quick 4656612873077392578125000 1238913682755082845687866214 10913936421275138854980465 651925802230834960937500000 23)=true := by decide +kernel
private theorem b136 : every 136 151 (quick 4656612873077392578125000 1238913682755082845687866214 10913936421275138854980465 651925802230834960937500000 23)=true := by decide +kernel
theorem certificate : atom 5 23 34=true := by
  apply row_low (h:=4656612873077392578125000) (A:=1238913682755082845687866214) (S:=10913936421275138854980465) (T:=651925802230834960937500000) (R:=24) (Q:=151) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 151≤24+128)]
  exact (joinEvery (joinEvery (joinEvery b24 b40) (joinEvery b56 b72)) (joinEvery (joinEvery b88 b104) (joinEvery b120 b136)))
end OMA.EightAt5E34P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E35P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 6372829375322908163070678714 54569682106375694274902340 3352761268615722656250000000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 6372829375322908163070678714 54569682106375694274902340 3352761268615722656250000000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 6372829375322908163070678714 54569682106375694274902340 3352761268615722656250000000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 6372829375322908163070678714 54569682106375694274902340 3352761268615722656250000000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 6372829375322908163070678714 54569682106375694274902340 3352761268615722656250000000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 6372829375322908163070678714 54569682106375694274902340 3352761268615722656250000000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 6372829375322908163070678714 54569682106375694274902340 3352761268615722656250000000 23 24)=true := by decide +kernel
private theorem b113 : every 113 117 (line 6372829375322908163070678714 54569682106375694274902340 3352761268615722656250000000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 35=true := by
  apply row_low (h:=23283064365386962890625000) (A:=6372829375322908163070678714) (S:=54569682106375694274902340) (T:=3352761268615722656250000000) (R:=24) (Q:=155) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬155≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 23283064365386962890625000 6372829375322908163070678714 54569682106375694274902340 23 155=117 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 b49)) (joinEvery (joinEvery b65 b81) (joinEvery b97 b113)))⟩
end OMA.EightAt5E35P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E36P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 32755451684352010488510131839 272848410531878471374511715 17229467630386352539062500000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 32755451684352010488510131839 272848410531878471374511715 17229467630386352539062500000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 32755451684352010488510131839 272848410531878471374511715 17229467630386352539062500000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 32755451684352010488510131839 272848410531878471374511715 17229467630386352539062500000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 32755451684352010488510131839 272848410531878471374511715 17229467630386352539062500000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 32755451684352010488510131839 272848410531878471374511715 17229467630386352539062500000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 32755451684352010488510131839 272848410531878471374511715 17229467630386352539062500000 23 24)=true := by decide +kernel
private theorem b113 : every 113 122 (line 32755451684352010488510131839 272848410531878471374511715 17229467630386352539062500000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 36=true := by
  apply row_low (h:=116415321826934814453125000) (A:=32755451684352010488510131839) (S:=272848410531878471374511715) (T:=17229467630386352539062500000) (R:=24) (Q:=160) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬160≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 116415321826934814453125000 32755451684352010488510131839 272848410531878471374511715 23 160=122 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 b49)) (joinEvery (joinEvery b65 b81) (joinEvery b97 b113)))⟩
end OMA.EightAt5E36P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E37P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 168233782460447400808334350589 1364242052659392356872558590 88475644588470458984375000000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 168233782460447400808334350589 1364242052659392356872558590 88475644588470458984375000000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 168233782460447400808334350589 1364242052659392356872558590 88475644588470458984375000000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 168233782460447400808334350589 1364242052659392356872558590 88475644588470458984375000000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 168233782460447400808334350589 1364242052659392356872558590 88475644588470458984375000000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 168233782460447400808334350589 1364242052659392356872558590 88475644588470458984375000000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 168233782460447400808334350589 1364242052659392356872558590 88475644588470458984375000000 23 24)=true := by decide +kernel
private theorem b113 : every 113 124 (line 168233782460447400808334350589 1364242052659392356872558590 88475644588470458984375000000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 37=true := by
  apply row_low (h:=582076609134674072265625000) (A:=168233782460447400808334350589) (S:=1364242052659392356872558590) (T:=88475644588470458984375000000) (R:=24) (Q:=165) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬165≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 582076609134674072265625000 168233782460447400808334350589 1364242052659392356872558590 23 165=124 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 b49)) (joinEvery (joinEvery b65 b81) (joinEvery b97 b113)))⟩
end OMA.EightAt5E37P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E38P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 863451532495673745870590209964 6821210263296961784362792965 454019755125045776367187500000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 863451532495673745870590209964 6821210263296961784362792965 454019755125045776367187500000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 863451532495673745870590209964 6821210263296961784362792965 454019755125045776367187500000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 863451532495673745870590209964 6821210263296961784362792965 454019755125045776367187500000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 863451532495673745870590209964 6821210263296961784362792965 454019755125045776367187500000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 863451532495673745870590209964 6821210263296961784362792965 454019755125045776367187500000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 863451532495673745870590209964 6821210263296961784362792965 454019755125045776367187500000 23 24)=true := by decide +kernel
private theorem b113 : every 113 127 (line 863451532495673745870590209964 6821210263296961784362792965 454019755125045776367187500000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 38=true := by
  apply row_low (h:=2910383045673370361328125000) (A:=863451532495673745870590209964) (S:=6821210263296961784362792965) (T:=454019755125045776367187500000) (R:=24) (Q:=170) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬170≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 2910383045673370361328125000 863451532495673745870590209964 6821210263296961784362792965 23 170=127 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 b49)) (joinEvery (joinEvery b65 b81) (joinEvery b97 b113)))⟩
end OMA.EightAt5E38P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E39P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 4428670763445552438497543334964 34106051316484808921813964840 2328306436538696289062500000000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 4428670763445552438497543334964 34106051316484808921813964840 2328306436538696289062500000000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 4428670763445552438497543334964 34106051316484808921813964840 2328306436538696289062500000000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 4428670763445552438497543334964 34106051316484808921813964840 2328306436538696289062500000000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 4428670763445552438497543334964 34106051316484808921813964840 2328306436538696289062500000000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 4428670763445552438497543334964 34106051316484808921813964840 2328306436538696289062500000000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 4428670763445552438497543334964 34106051316484808921813964840 2328306436538696289062500000000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 4428670763445552438497543334964 34106051316484808921813964840 2328306436538696289062500000000 23 24)=true := by decide +kernel
private theorem b129 : every 129 129 (line 4428670763445552438497543334964 34106051316484808921813964840 2328306436538696289062500000000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 39=true := by
  apply row_low (h:=14551915228366851806640625000) (A:=4428670763445552438497543334964) (S:=34106051316484808921813964840) (T:=2328306436538696289062500000000) (R:=24) (Q:=174) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬174≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 14551915228366851806640625000 4428670763445552438497543334964 34106051316484808921813964840 23 174=129 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 b49)) (joinEvery (joinEvery b65 b81) (joinEvery b97 (joinEvery b113 b129))))⟩
end OMA.EightAt5E39P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E40P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 22700419322063680738210678100589 170530256582424044609069824215 11932570487260818481445312500000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 22700419322063680738210678100589 170530256582424044609069824215 11932570487260818481445312500000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 22700419322063680738210678100589 170530256582424044609069824215 11932570487260818481445312500000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 22700419322063680738210678100589 170530256582424044609069824215 11932570487260818481445312500000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 22700419322063680738210678100589 170530256582424044609069824215 11932570487260818481445312500000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 22700419322063680738210678100589 170530256582424044609069824215 11932570487260818481445312500000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 22700419322063680738210678100589 170530256582424044609069824215 11932570487260818481445312500000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 22700419322063680738210678100589 170530256582424044609069824215 11932570487260818481445312500000 23 24)=true := by decide +kernel
private theorem b129 : every 129 132 (line 22700419322063680738210678100589 170530256582424044609069824215 11932570487260818481445312500000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 40=true := by
  apply row_low (h:=72759576141834259033203125000) (A:=22700419322063680738210678100589) (S:=170530256582424044609069824215) (T:=11932570487260818481445312500000) (R:=24) (Q:=179) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬179≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 72759576141834259033203125000 22700419322063680738210678100589 170530256582424044609069824215 23 179=132 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 b49)) (joinEvery (joinEvery b65 b81) (joinEvery b97 (joinEvery b113 b129))))⟩
end OMA.EightAt5E40P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E41P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 116287424134497996419668197631839 852651282912120223045349121090 61118043959140777587890625000000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 116287424134497996419668197631839 852651282912120223045349121090 61118043959140777587890625000000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 116287424134497996419668197631839 852651282912120223045349121090 61118043959140777587890625000000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 116287424134497996419668197631839 852651282912120223045349121090 61118043959140777587890625000000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 116287424134497996419668197631839 852651282912120223045349121090 61118043959140777587890625000000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 116287424134497996419668197631839 852651282912120223045349121090 61118043959140777587890625000000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 116287424134497996419668197631839 852651282912120223045349121090 61118043959140777587890625000000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 116287424134497996419668197631839 852651282912120223045349121090 61118043959140777587890625000000 23 24)=true := by decide +kernel
private theorem b129 : every 129 135 (line 116287424134497996419668197631839 852651282912120223045349121090 61118043959140777587890625000000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 41=true := by
  apply row_low (h:=363797880709171295166015625000) (A:=116287424134497996419668197631839) (S:=852651282912120223045349121090) (T:=61118043959140777587890625000000) (R:=24) (Q:=184) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬184≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 363797880709171295166015625000 116287424134497996419668197631839 852651282912120223045349121090 23 184=135 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 b49)) (joinEvery (joinEvery b65 b81) (joinEvery b97 (joinEvery b113 b129))))⟩
end OMA.EightAt5E41P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E42P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 595363758293387945741415023803714 4263256414560601115226745605465 312866177409887313842773437500000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 595363758293387945741415023803714 4263256414560601115226745605465 312866177409887313842773437500000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 595363758293387945741415023803714 4263256414560601115226745605465 312866177409887313842773437500000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 595363758293387945741415023803714 4263256414560601115226745605465 312866177409887313842773437500000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 595363758293387945741415023803714 4263256414560601115226745605465 312866177409887313842773437500000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 595363758293387945741415023803714 4263256414560601115226745605465 312866177409887313842773437500000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 595363758293387945741415023803714 4263256414560601115226745605465 312866177409887313842773437500000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 595363758293387945741415023803714 4263256414560601115226745605465 312866177409887313842773437500000 23 24)=true := by decide +kernel
private theorem b129 : every 129 137 (line 595363758293387945741415023803714 4263256414560601115226745605465 312866177409887313842773437500000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 42=true := by
  apply row_low (h:=1818989403545856475830078125000) (A:=595363758293387945741415023803714) (S:=4263256414560601115226745605465) (T:=312866177409887313842773437500000) (R:=24) (Q:=189) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬189≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 1818989403545856475830078125000 595363758293387945741415023803714 4263256414560601115226745605465 23 189=137 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 b49)) (joinEvery (joinEvery b65 b81) (joinEvery b97 (joinEvery b113 b129))))⟩
end OMA.EightAt5E42P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E43P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 3046451979571429546922445297241214 21316282072803005576133728027340 1600710675120353698730468750000000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 3046451979571429546922445297241214 21316282072803005576133728027340 1600710675120353698730468750000000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 3046451979571429546922445297241214 21316282072803005576133728027340 1600710675120353698730468750000000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 3046451979571429546922445297241214 21316282072803005576133728027340 1600710675120353698730468750000000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 3046451979571429546922445297241214 21316282072803005576133728027340 1600710675120353698730468750000000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 3046451979571429546922445297241214 21316282072803005576133728027340 1600710675120353698730468750000000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 3046451979571429546922445297241214 21316282072803005576133728027340 1600710675120353698730468750000000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 3046451979571429546922445297241214 21316282072803005576133728027340 1600710675120353698730468750000000 23 24)=true := by decide +kernel
private theorem b129 : every 129 140 (line 3046451979571429546922445297241214 21316282072803005576133728027340 1600710675120353698730468750000000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 43=true := by
  apply row_low (h:=9094947017729282379150390625000) (A:=3046451979571429546922445297241214) (S:=21316282072803005576133728027340) (T:=1600710675120353698730468750000000) (R:=24) (Q:=194) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬194≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 9094947017729282379150390625000 3046451979571429546922445297241214 21316282072803005576133728027340 23 194=140 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 b49)) (joinEvery (joinEvery b65 b81) (joinEvery b97 (joinEvery b113 b129))))⟩
end OMA.EightAt5E43P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E44P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 15580425838379596825689077377319339 106581410364015027880668640136715 8185452315956354141235351562500000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 15580425838379596825689077377319339 106581410364015027880668640136715 8185452315956354141235351562500000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 15580425838379596825689077377319339 106581410364015027880668640136715 8185452315956354141235351562500000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 15580425838379596825689077377319339 106581410364015027880668640136715 8185452315956354141235351562500000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 15580425838379596825689077377319339 106581410364015027880668640136715 8185452315956354141235351562500000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 15580425838379596825689077377319339 106581410364015027880668640136715 8185452315956354141235351562500000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 15580425838379596825689077377319339 106581410364015027880668640136715 8185452315956354141235351562500000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 15580425838379596825689077377319339 106581410364015027880668640136715 8185452315956354141235351562500000 23 24)=true := by decide +kernel
private theorem b129 : every 129 142 (line 15580425838379596825689077377319339 106581410364015027880668640136715 8185452315956354141235351562500000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 44=true := by
  apply row_low (h:=45474735088646411895751953125000) (A:=15580425838379596825689077377319339) (S:=106581410364015027880668640136715) (T:=8185452315956354141235351562500000) (R:=24) (Q:=198) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬198≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 45474735088646411895751953125000 15580425838379596825689077377319339 106581410364015027880668640136715 23 198=142 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 b49)) (joinEvery (joinEvery b65 b81) (joinEvery b97 (joinEvery b113 b129))))⟩
end OMA.EightAt5E44P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E45P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 79642958894510229583829641342163089 532907051820075139403343200683590 41836756281554698944091796875000000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 79642958894510229583829641342163089 532907051820075139403343200683590 41836756281554698944091796875000000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 79642958894510229583829641342163089 532907051820075139403343200683590 41836756281554698944091796875000000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 79642958894510229583829641342163089 532907051820075139403343200683590 41836756281554698944091796875000000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 79642958894510229583829641342163089 532907051820075139403343200683590 41836756281554698944091796875000000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 79642958894510229583829641342163089 532907051820075139403343200683590 41836756281554698944091796875000000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 79642958894510229583829641342163089 532907051820075139403343200683590 41836756281554698944091796875000000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 79642958894510229583829641342163089 532907051820075139403343200683590 41836756281554698944091796875000000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 79642958894510229583829641342163089 532907051820075139403343200683590 41836756281554698944091796875000000 23 24)=true := by decide +kernel
private theorem b145 : every 145 145 (line 79642958894510229583829641342163089 532907051820075139403343200683590 41836756281554698944091796875000000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 45=true := by
  apply row_low (h:=227373675443232059478759765625000) (A:=79642958894510229583829641342163089) (S:=532907051820075139403343200683590) (T:=41836756281554698944091796875000000) (R:=24) (Q:=203) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬203≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 227373675443232059478759765625000 79642958894510229583829641342163089 532907051820075139403343200683590 23 203=145 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65))) (joinEvery (joinEvery b81 b97) (joinEvery b113 (joinEvery b129 b145))))⟩
end OMA.EightAt5E45P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E46P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 406918942985612375196069478988647464 2664535259100375697016716003417965 213731254916638135910034179687500000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 406918942985612375196069478988647464 2664535259100375697016716003417965 213731254916638135910034179687500000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 406918942985612375196069478988647464 2664535259100375697016716003417965 213731254916638135910034179687500000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 406918942985612375196069478988647464 2664535259100375697016716003417965 213731254916638135910034179687500000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 406918942985612375196069478988647464 2664535259100375697016716003417965 213731254916638135910034179687500000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 406918942985612375196069478988647464 2664535259100375697016716003417965 213731254916638135910034179687500000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 406918942985612375196069478988647464 2664535259100375697016716003417965 213731254916638135910034179687500000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 406918942985612375196069478988647464 2664535259100375697016716003417965 213731254916638135910034179687500000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 406918942985612375196069478988647464 2664535259100375697016716003417965 213731254916638135910034179687500000 23 24)=true := by decide +kernel
private theorem b145 : every 145 147 (line 406918942985612375196069478988647464 2664535259100375697016716003417965 213731254916638135910034179687500000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 46=true := by
  apply row_low (h:=1136868377216160297393798828125000) (A:=406918942985612375196069478988647464) (S:=2664535259100375697016716003417965) (T:=213731254916638135910034179687500000) (R:=24) (Q:=208) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬208≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 1136868377216160297393798828125000 406918942985612375196069478988647464 2664535259100375697016716003417965 23 208=147 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65))) (joinEvery (joinEvery b81 b97) (joinEvery b113 (joinEvery b129 b145))))⟩
end OMA.EightAt5E46P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E47P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 2078115457493368012364953756332397464 13322676295501878485083580017089840 1091393642127513885498046875000000000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 2078115457493368012364953756332397464 13322676295501878485083580017089840 1091393642127513885498046875000000000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 2078115457493368012364953756332397464 13322676295501878485083580017089840 1091393642127513885498046875000000000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 2078115457493368012364953756332397464 13322676295501878485083580017089840 1091393642127513885498046875000000000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 2078115457493368012364953756332397464 13322676295501878485083580017089840 1091393642127513885498046875000000000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 2078115457493368012364953756332397464 13322676295501878485083580017089840 1091393642127513885498046875000000000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 2078115457493368012364953756332397464 13322676295501878485083580017089840 1091393642127513885498046875000000000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 2078115457493368012364953756332397464 13322676295501878485083580017089840 1091393642127513885498046875000000000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 2078115457493368012364953756332397464 13322676295501878485083580017089840 1091393642127513885498046875000000000 23 24)=true := by decide +kernel
private theorem b145 : every 145 150 (line 2078115457493368012364953756332397464 13322676295501878485083580017089840 1091393642127513885498046875000000000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 47=true := by
  apply row_low (h:=5684341886080801486968994140625000) (A:=2078115457493368012364953756332397464) (S:=13322676295501878485083580017089840) (T:=1091393642127513885498046875000000000) (R:=24) (Q:=213) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬213≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 5684341886080801486968994140625000 2078115457493368012364953756332397464 13322676295501878485083580017089840 23 213=150 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65))) (joinEvery (joinEvery b81 b97) (joinEvery b113 (joinEvery b129 b145))))⟩
end OMA.EightAt5E47P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E48P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 10608181000293370743747800588607788089 66613381477509392425417900085449215 5570655048359185457229614257812500000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 10608181000293370743747800588607788089 66613381477509392425417900085449215 5570655048359185457229614257812500000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 10608181000293370743747800588607788089 66613381477509392425417900085449215 5570655048359185457229614257812500000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 10608181000293370743747800588607788089 66613381477509392425417900085449215 5570655048359185457229614257812500000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 10608181000293370743747800588607788089 66613381477509392425417900085449215 5570655048359185457229614257812500000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 10608181000293370743747800588607788089 66613381477509392425417900085449215 5570655048359185457229614257812500000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 10608181000293370743747800588607788089 66613381477509392425417900085449215 5570655048359185457229614257812500000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 10608181000293370743747800588607788089 66613381477509392425417900085449215 5570655048359185457229614257812500000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 10608181000293370743747800588607788089 66613381477509392425417900085449215 5570655048359185457229614257812500000 23 24)=true := by decide +kernel
private theorem b145 : every 145 154 (line 10608181000293370743747800588607788089 66613381477509392425417900085449215 5570655048359185457229614257812500000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 48=true := by
  apply row_low (h:=28421709430404007434844970703125000) (A:=10608181000293370743747800588607788089) (S:=66613381477509392425417900085449215) (T:=5570655048359185457229614257812500000) (R:=24) (Q:=218) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬218≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 28421709430404007434844970703125000 10608181000293370743747800588607788089 66613381477509392425417900085449215 23 218=154 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65))) (joinEvery (joinEvery b81 b97) (joinEvery b113 (joinEvery b129 b145))))⟩
end OMA.EightAt5E48P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E49P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 54128923565599507128354161977767944339 333066907387546962127089500427246090 28421709430404007434844970703125000000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 54128923565599507128354161977767944339 333066907387546962127089500427246090 28421709430404007434844970703125000000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 54128923565599507128354161977767944339 333066907387546962127089500427246090 28421709430404007434844970703125000000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 54128923565599507128354161977767944339 333066907387546962127089500427246090 28421709430404007434844970703125000000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 54128923565599507128354161977767944339 333066907387546962127089500427246090 28421709430404007434844970703125000000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 54128923565599507128354161977767944339 333066907387546962127089500427246090 28421709430404007434844970703125000000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 54128923565599507128354161977767944339 333066907387546962127089500427246090 28421709430404007434844970703125000000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 54128923565599507128354161977767944339 333066907387546962127089500427246090 28421709430404007434844970703125000000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 54128923565599507128354161977767944339 333066907387546962127089500427246090 28421709430404007434844970703125000000 23 24)=true := by decide +kernel
private theorem b145 : every 145 157 (line 54128923565599507128354161977767944339 333066907387546962127089500427246090 28421709430404007434844970703125000000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 49=true := by
  apply row_low (h:=142108547152020037174224853515625000) (A:=54128923565599507128354161977767944339) (S:=333066907387546962127089500427246090) (T:=28421709430404007434844970703125000000) (R:=24) (Q:=223) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬223≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 142108547152020037174224853515625000 54128923565599507128354161977767944339 333066907387546962127089500427246090 23 223=157 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65))) (joinEvery (joinEvery b81 b97) (joinEvery b113 (joinEvery b129 b145))))⟩
end OMA.EightAt5E49P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E50P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 276084710648660802689846605062484741214 1665334536937734810635447502136230465 144950718095060437917709350585937500000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 276084710648660802689846605062484741214 1665334536937734810635447502136230465 144950718095060437917709350585937500000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 276084710648660802689846605062484741214 1665334536937734810635447502136230465 144950718095060437917709350585937500000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 276084710648660802689846605062484741214 1665334536937734810635447502136230465 144950718095060437917709350585937500000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 276084710648660802689846605062484741214 1665334536937734810635447502136230465 144950718095060437917709350585937500000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 276084710648660802689846605062484741214 1665334536937734810635447502136230465 144950718095060437917709350585937500000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 276084710648660802689846605062484741214 1665334536937734810635447502136230465 144950718095060437917709350585937500000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 276084710648660802689846605062484741214 1665334536937734810635447502136230465 144950718095060437917709350585937500000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 276084710648660802689846605062484741214 1665334536937734810635447502136230465 144950718095060437917709350585937500000 23 24)=true := by decide +kernel
private theorem b145 : every 145 159 (line 276084710648660802689846605062484741214 1665334536937734810635447502136230465 144950718095060437917709350585937500000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 50=true := by
  apply row_low (h:=710542735760100185871124267578125000) (A:=276084710648660802689846605062484741214) (S:=1665334536937734810635447502136230465) (T:=144950718095060437917709350585937500000) (R:=24) (Q:=228) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬228≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 710542735760100185871124267578125000 276084710648660802689846605062484741214 1665334536937734810635447502136230465 23 228=159 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65))) (joinEvery (joinEvery b81 b97) (joinEvery b113 (joinEvery b129 b145))))⟩
end OMA.EightAt5E50P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E51P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 1407624017346620348689612001180648803714 8326672684688674053177237510681152340 738964445190504193305969238281250000000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 1407624017346620348689612001180648803714 8326672684688674053177237510681152340 738964445190504193305969238281250000000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 1407624017346620348689612001180648803714 8326672684688674053177237510681152340 738964445190504193305969238281250000000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 1407624017346620348689612001180648803714 8326672684688674053177237510681152340 738964445190504193305969238281250000000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 1407624017346620348689612001180648803714 8326672684688674053177237510681152340 738964445190504193305969238281250000000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 1407624017346620348689612001180648803714 8326672684688674053177237510681152340 738964445190504193305969238281250000000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 1407624017346620348689612001180648803714 8326672684688674053177237510681152340 738964445190504193305969238281250000000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 1407624017346620348689612001180648803714 8326672684688674053177237510681152340 738964445190504193305969238281250000000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 1407624017346620348689612001180648803714 8326672684688674053177237510681152340 738964445190504193305969238281250000000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 1407624017346620348689612001180648803714 8326672684688674053177237510681152340 738964445190504193305969238281250000000 23 24)=true := by decide +kernel
private theorem b161 : every 161 162 (line 1407624017346620348689612001180648803714 8326672684688674053177237510681152340 738964445190504193305969238281250000000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 51=true := by
  apply row_low (h:=3552713678800500929355621337890625000) (A:=1407624017346620348689612001180648803714) (S:=8326672684688674053177237510681152340) (T:=738964445190504193305969238281250000000) (R:=24) (Q:=233) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬233≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 3552713678800500929355621337890625000 1407624017346620348689612001180648803714 8326672684688674053177237510681152340 23 233=162 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65))) (joinEvery (joinEvery b81 (joinEvery b97 b113)) (joinEvery b129 (joinEvery b145 b161))))⟩
end OMA.EightAt5E51P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E52P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 7174122407249683419649954885244369506839 41633363423443370265886187553405761715 3765876499528530985116958618164062500000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 7174122407249683419649954885244369506839 41633363423443370265886187553405761715 3765876499528530985116958618164062500000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 7174122407249683419649954885244369506839 41633363423443370265886187553405761715 3765876499528530985116958618164062500000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 7174122407249683419649954885244369506839 41633363423443370265886187553405761715 3765876499528530985116958618164062500000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 7174122407249683419649954885244369506839 41633363423443370265886187553405761715 3765876499528530985116958618164062500000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 7174122407249683419649954885244369506839 41633363423443370265886187553405761715 3765876499528530985116958618164062500000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 7174122407249683419649954885244369506839 41633363423443370265886187553405761715 3765876499528530985116958618164062500000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 7174122407249683419649954885244369506839 41633363423443370265886187553405761715 3765876499528530985116958618164062500000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 7174122407249683419649954885244369506839 41633363423443370265886187553405761715 3765876499528530985116958618164062500000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 7174122407249683419649954885244369506839 41633363423443370265886187553405761715 3765876499528530985116958618164062500000 23 24)=true := by decide +kernel
private theorem b161 : every 161 164 (line 7174122407249683419649954885244369506839 41633363423443370265886187553405761715 3765876499528530985116958618164062500000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 52=true := by
  apply row_low (h:=17763568394002504646778106689453125000) (A:=7174122407249683419649954885244369506839) (S:=41633363423443370265886187553405761715) (T:=3765876499528530985116958618164062500000) (R:=24) (Q:=238) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬238≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 17763568394002504646778106689453125000 7174122407249683419649954885244369506839 41633363423443370265886187553405761715 23 238=164 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65))) (joinEvery (joinEvery b81 (joinEvery b97 b113)) (joinEvery b129 (joinEvery b145 b161))))⟩
end OMA.EightAt5E52P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E53P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 36550623638831325479259248822927474975589 208166817117216851329430937767028808590 19184653865522705018520355224609375000000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 36550623638831325479259248822927474975589 208166817117216851329430937767028808590 19184653865522705018520355224609375000000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 36550623638831325479259248822927474975589 208166817117216851329430937767028808590 19184653865522705018520355224609375000000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 36550623638831325479259248822927474975589 208166817117216851329430937767028808590 19184653865522705018520355224609375000000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 36550623638831325479259248822927474975589 208166817117216851329430937767028808590 19184653865522705018520355224609375000000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 36550623638831325479259248822927474975589 208166817117216851329430937767028808590 19184653865522705018520355224609375000000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 36550623638831325479259248822927474975589 208166817117216851329430937767028808590 19184653865522705018520355224609375000000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 36550623638831325479259248822927474975589 208166817117216851329430937767028808590 19184653865522705018520355224609375000000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 36550623638831325479259248822927474975589 208166817117216851329430937767028808590 19184653865522705018520355224609375000000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 36550623638831325479259248822927474975589 208166817117216851329430937767028808590 19184653865522705018520355224609375000000 23 24)=true := by decide +kernel
private theorem b161 : every 161 167 (line 36550623638831325479259248822927474975589 208166817117216851329430937767028808590 19184653865522705018520355224609375000000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 53=true := by
  apply row_low (h:=88817841970012523233890533447265625000) (A:=36550623638831325479259248822927474975589) (S:=208166817117216851329430937767028808590) (T:=19184653865522705018520355224609375000000) (R:=24) (Q:=243) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬243≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 88817841970012523233890533447265625000 36550623638831325479259248822927474975589 208166817117216851329430937767028808590 23 243=167 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65))) (joinEvery (joinEvery b81 (joinEvery b97 b113)) (joinEvery b129 (joinEvery b145 b161))))⟩
end OMA.EightAt5E53P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E54P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 186153176207071169301343616098165512084964 1040834085586084256647154688835144042965 97699626167013775557279586791992187500000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 186153176207071169301343616098165512084964 1040834085586084256647154688835144042965 97699626167013775557279586791992187500000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 186153176207071169301343616098165512084964 1040834085586084256647154688835144042965 97699626167013775557279586791992187500000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 186153176207071169301343616098165512084964 1040834085586084256647154688835144042965 97699626167013775557279586791992187500000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 186153176207071169301343616098165512084964 1040834085586084256647154688835144042965 97699626167013775557279586791992187500000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 186153176207071169301343616098165512084964 1040834085586084256647154688835144042965 97699626167013775557279586791992187500000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 186153176207071169301343616098165512084964 1040834085586084256647154688835144042965 97699626167013775557279586791992187500000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 186153176207071169301343616098165512084964 1040834085586084256647154688835144042965 97699626167013775557279586791992187500000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 186153176207071169301343616098165512084964 1040834085586084256647154688835144042965 97699626167013775557279586791992187500000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 186153176207071169301343616098165512084964 1040834085586084256647154688835144042965 97699626167013775557279586791992187500000 23 24)=true := by decide +kernel
private theorem b161 : every 161 169 (line 186153176207071169301343616098165512084964 1040834085586084256647154688835144042965 97699626167013775557279586791992187500000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 54=true := by
  apply row_low (h:=444089209850062616169452667236328125000) (A:=186153176207071169301343616098165512084964) (S:=1040834085586084256647154688835144042965) (T:=97699626167013775557279586791992187500000) (R:=24) (Q:=249) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬249≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 444089209850062616169452667236328125000 186153176207071169301343616098165512084964 1040834085586084256647154688835144042965 23 249=169 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65))) (joinEvery (joinEvery b81 (joinEvery b97 b113)) (joinEvery b129 (joinEvery b145 b161))))⟩
end OMA.EightAt5E54P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E55P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 947766171099928556031954940408468246459964 5204170427930421283235773444175720214840 497379915032070130109786987304687500000000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 947766171099928556031954940408468246459964 5204170427930421283235773444175720214840 497379915032070130109786987304687500000000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 947766171099928556031954940408468246459964 5204170427930421283235773444175720214840 497379915032070130109786987304687500000000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 947766171099928556031954940408468246459964 5204170427930421283235773444175720214840 497379915032070130109786987304687500000000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 947766171099928556031954940408468246459964 5204170427930421283235773444175720214840 497379915032070130109786987304687500000000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 947766171099928556031954940408468246459964 5204170427930421283235773444175720214840 497379915032070130109786987304687500000000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 947766171099928556031954940408468246459964 5204170427930421283235773444175720214840 497379915032070130109786987304687500000000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 947766171099928556031954940408468246459964 5204170427930421283235773444175720214840 497379915032070130109786987304687500000000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 947766171099928556031954940408468246459964 5204170427930421283235773444175720214840 497379915032070130109786987304687500000000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 947766171099928556031954940408468246459964 5204170427930421283235773444175720214840 497379915032070130109786987304687500000000 23 24)=true := by decide +kernel
private theorem b161 : every 161 172 (line 947766171099928556031954940408468246459964 5204170427930421283235773444175720214840 497379915032070130109786987304687500000000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 55=true := by
  apply row_low (h:=2220446049250313080847263336181640625000) (A:=947766171099928556031954940408468246459964) (S:=5204170427930421283235773444175720214840) (T:=497379915032070130109786987304687500000000) (R:=24) (Q:=254) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬254≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 2220446049250313080847263336181640625000 947766171099928556031954940408468246459964 5204170427930421283235773444175720214840 23 254=172 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65))) (joinEvery (joinEvery b81 (joinEvery b97 b113)) (joinEvery b129 (joinEvery b145 b161))))⟩
end OMA.EightAt5E55P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E56P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 4823832305822506327785959001630544662475589 26020852139652106416178867220878601074215 2531308496145356912165880203247070312500000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 4823832305822506327785959001630544662475589 26020852139652106416178867220878601074215 2531308496145356912165880203247070312500000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 4823832305822506327785959001630544662475589 26020852139652106416178867220878601074215 2531308496145356912165880203247070312500000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 4823832305822506327785959001630544662475589 26020852139652106416178867220878601074215 2531308496145356912165880203247070312500000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 4823832305822506327785959001630544662475589 26020852139652106416178867220878601074215 2531308496145356912165880203247070312500000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 4823832305822506327785959001630544662475589 26020852139652106416178867220878601074215 2531308496145356912165880203247070312500000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 4823832305822506327785959001630544662475589 26020852139652106416178867220878601074215 2531308496145356912165880203247070312500000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 4823832305822506327785959001630544662475589 26020852139652106416178867220878601074215 2531308496145356912165880203247070312500000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 4823832305822506327785959001630544662475589 26020852139652106416178867220878601074215 2531308496145356912165880203247070312500000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 4823832305822506327785959001630544662475589 26020852139652106416178867220878601074215 2531308496145356912165880203247070312500000 23 24)=true := by decide +kernel
private theorem b161 : every 161 174 (line 4823832305822506327785959001630544662475589 26020852139652106416178867220878601074215 2531308496145356912165880203247070312500000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 56=true := by
  apply row_low (h:=11102230246251565404236316680908203125000) (A:=4823832305822506327785959001630544662475589) (S:=26020852139652106416178867220878601074215) (T:=2531308496145356912165880203247070312500000) (R:=24) (Q:=259) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬259≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 11102230246251565404236316680908203125000 4823832305822506327785959001630544662475589 26020852139652106416178867220878601074215 23 259=174 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65))) (joinEvery (joinEvery b81 (joinEvery b97 b113)) (joinEvery b129 (joinEvery b145 b161))))⟩
end OMA.EightAt5E56P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E57P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 24544168780726849377060716506093740463256839 130104260698260532080894336104393005371090 12878587085651815868914127349853515625000000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 24544168780726849377060716506093740463256839 130104260698260532080894336104393005371090 12878587085651815868914127349853515625000000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 24544168780726849377060716506093740463256839 130104260698260532080894336104393005371090 12878587085651815868914127349853515625000000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 24544168780726849377060716506093740463256839 130104260698260532080894336104393005371090 12878587085651815868914127349853515625000000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 24544168780726849377060716506093740463256839 130104260698260532080894336104393005371090 12878587085651815868914127349853515625000000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 24544168780726849377060716506093740463256839 130104260698260532080894336104393005371090 12878587085651815868914127349853515625000000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 24544168780726849377060716506093740463256839 130104260698260532080894336104393005371090 12878587085651815868914127349853515625000000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 24544168780726849377060716506093740463256839 130104260698260532080894336104393005371090 12878587085651815868914127349853515625000000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 24544168780726849377060716506093740463256839 130104260698260532080894336104393005371090 12878587085651815868914127349853515625000000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 24544168780726849377060716506093740463256839 130104260698260532080894336104393005371090 12878587085651815868914127349853515625000000 23 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 24544168780726849377060716506093740463256839 130104260698260532080894336104393005371090 12878587085651815868914127349853515625000000 23 24)=true := by decide +kernel
private theorem b177 : every 177 177 (line 24544168780726849377060716506093740463256839 130104260698260532080894336104393005371090 12878587085651815868914127349853515625000000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 57=true := by
  apply row_low (h:=55511151231257827021181583404541015625000) (A:=24544168780726849377060716506093740463256839) (S:=130104260698260532080894336104393005371090) (T:=12878587085651815868914127349853515625000000) (R:=24) (Q:=264) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬264≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 55511151231257827021181583404541015625000 24544168780726849377060716506093740463256839 130104260698260532080894336104393005371090 23 264=177 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery b145 (joinEvery b161 b177))))⟩
end OMA.EightAt5E57P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E58P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 124845880161705835575958190020173788070678714 650521303491302660404471680521965026855465 65503158452884235884994268417358398437500000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 124845880161705835575958190020173788070678714 650521303491302660404471680521965026855465 65503158452884235884994268417358398437500000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 124845880161705835575958190020173788070678714 650521303491302660404471680521965026855465 65503158452884235884994268417358398437500000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 124845880161705835575958190020173788070678714 650521303491302660404471680521965026855465 65503158452884235884994268417358398437500000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 124845880161705835575958190020173788070678714 650521303491302660404471680521965026855465 65503158452884235884994268417358398437500000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 124845880161705835575958190020173788070678714 650521303491302660404471680521965026855465 65503158452884235884994268417358398437500000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 124845880161705835575958190020173788070678714 650521303491302660404471680521965026855465 65503158452884235884994268417358398437500000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 124845880161705835575958190020173788070678714 650521303491302660404471680521965026855465 65503158452884235884994268417358398437500000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 124845880161705835575958190020173788070678714 650521303491302660404471680521965026855465 65503158452884235884994268417358398437500000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 124845880161705835575958190020173788070678714 650521303491302660404471680521965026855465 65503158452884235884994268417358398437500000 23 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 124845880161705835575958190020173788070678714 650521303491302660404471680521965026855465 65503158452884235884994268417358398437500000 23 24)=true := by decide +kernel
private theorem b177 : every 177 179 (line 124845880161705835575958190020173788070678714 650521303491302660404471680521965026855465 65503158452884235884994268417358398437500000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 58=true := by
  apply row_low (h:=277555756156289135105907917022705078125000) (A:=124845880161705835575958190020173788070678714) (S:=650521303491302660404471680521965026855465) (T:=65503158452884235884994268417358398437500000) (R:=24) (Q:=269) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬269≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 277555756156289135105907917022705078125000 124845880161705835575958190020173788070678714 650521303491302660404471680521965026855465 23 269=179 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery b145 (joinEvery b161 b177))))⟩
end OMA.EightAt5E58P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E59P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 634854582098887121333063987549394369125366214 3252606517456513302022358402609825134277340 333066907387546962127089500427246093750000000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 634854582098887121333063987549394369125366214 3252606517456513302022358402609825134277340 333066907387546962127089500427246093750000000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 634854582098887121333063987549394369125366214 3252606517456513302022358402609825134277340 333066907387546962127089500427246093750000000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 634854582098887121333063987549394369125366214 3252606517456513302022358402609825134277340 333066907387546962127089500427246093750000000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 634854582098887121333063987549394369125366214 3252606517456513302022358402609825134277340 333066907387546962127089500427246093750000000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 634854582098887121333063987549394369125366214 3252606517456513302022358402609825134277340 333066907387546962127089500427246093750000000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 634854582098887121333063987549394369125366214 3252606517456513302022358402609825134277340 333066907387546962127089500427246093750000000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 634854582098887121333063987549394369125366214 3252606517456513302022358402609825134277340 333066907387546962127089500427246093750000000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 634854582098887121333063987549394369125366214 3252606517456513302022358402609825134277340 333066907387546962127089500427246093750000000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 634854582098887121333063987549394369125366214 3252606517456513302022358402609825134277340 333066907387546962127089500427246093750000000 23 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 634854582098887121333063987549394369125366214 3252606517456513302022358402609825134277340 333066907387546962127089500427246093750000000 23 24)=true := by decide +kernel
private theorem b177 : every 177 182 (line 634854582098887121333063987549394369125366214 3252606517456513302022358402609825134277340 333066907387546962127089500427246093750000000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 59=true := by
  apply row_low (h:=1387778780781445675529539585113525390625000) (A:=634854582098887121333063987549394369125366214) (S:=3252606517456513302022358402609825134277340) (T:=333066907387546962127089500427246093750000000) (R:=24) (Q:=275) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬275≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 1387778780781445675529539585113525390625000 634854582098887121333063987549394369125366214 3252606517456513302022358402609825134277340 23 275=182 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery b145 (joinEvery b161 b177))))⟩
end OMA.EightAt5E59P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E60P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 3227398816946225323931685124989598989486694339 16263032587282566510111792013049125671386715 1693090112553363724146038293838500976562500000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 3227398816946225323931685124989598989486694339 16263032587282566510111792013049125671386715 1693090112553363724146038293838500976562500000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 3227398816946225323931685124989598989486694339 16263032587282566510111792013049125671386715 1693090112553363724146038293838500976562500000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 3227398816946225323931685124989598989486694339 16263032587282566510111792013049125671386715 1693090112553363724146038293838500976562500000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 3227398816946225323931685124989598989486694339 16263032587282566510111792013049125671386715 1693090112553363724146038293838500976562500000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 3227398816946225323931685124989598989486694339 16263032587282566510111792013049125671386715 1693090112553363724146038293838500976562500000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 3227398816946225323931685124989598989486694339 16263032587282566510111792013049125671386715 1693090112553363724146038293838500976562500000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 3227398816946225323931685124989598989486694339 16263032587282566510111792013049125671386715 1693090112553363724146038293838500976562500000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 3227398816946225323931685124989598989486694339 16263032587282566510111792013049125671386715 1693090112553363724146038293838500976562500000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 3227398816946225323931685124989598989486694339 16263032587282566510111792013049125671386715 1693090112553363724146038293838500976562500000 23 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 3227398816946225323931685124989598989486694339 16263032587282566510111792013049125671386715 1693090112553363724146038293838500976562500000 23 24)=true := by decide +kernel
private theorem b177 : every 177 185 (line 3227398816946225323931685124989598989486694339 16263032587282566510111792013049125671386715 1693090112553363724146038293838500976562500000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 60=true := by
  apply row_low (h:=6938893903907228377647697925567626953125000) (A:=3227398816946225323931685124989598989486694339) (S:=16263032587282566510111792013049125671386715) (T:=1693090112553363724146038293838500976562500000) (R:=24) (Q:=280) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬280≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 6938893903907228377647697925567626953125000 3227398816946225323931685124989598989486694339 16263032587282566510111792013049125671386715 23 280=185 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery b145 (joinEvery b161 b177))))⟩
end OMA.EightAt5E60P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E61P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 16402623616990075205990251561161130666732788089 81315162936412832550558960065245628356933590 8604228440844963188283145427703857421875000000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 16402623616990075205990251561161130666732788089 81315162936412832550558960065245628356933590 8604228440844963188283145427703857421875000000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 16402623616990075205990251561161130666732788089 81315162936412832550558960065245628356933590 8604228440844963188283145427703857421875000000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 16402623616990075205990251561161130666732788089 81315162936412832550558960065245628356933590 8604228440844963188283145427703857421875000000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 16402623616990075205990251561161130666732788089 81315162936412832550558960065245628356933590 8604228440844963188283145427703857421875000000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 16402623616990075205990251561161130666732788089 81315162936412832550558960065245628356933590 8604228440844963188283145427703857421875000000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 16402623616990075205990251561161130666732788089 81315162936412832550558960065245628356933590 8604228440844963188283145427703857421875000000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 16402623616990075205990251561161130666732788089 81315162936412832550558960065245628356933590 8604228440844963188283145427703857421875000000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 16402623616990075205990251561161130666732788089 81315162936412832550558960065245628356933590 8604228440844963188283145427703857421875000000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 16402623616990075205990251561161130666732788089 81315162936412832550558960065245628356933590 8604228440844963188283145427703857421875000000 23 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 16402623616990075205990251561161130666732788089 81315162936412832550558960065245628356933590 8604228440844963188283145427703857421875000000 23 24)=true := by decide +kernel
private theorem b177 : every 177 187 (line 16402623616990075205990251561161130666732788089 81315162936412832550558960065245628356933590 8604228440844963188283145427703857421875000000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 61=true := by
  apply row_low (h:=34694469519536141888238489627838134765625000) (A:=16402623616990075205990251561161130666732788089) (S:=81315162936412832550558960065245628356933590) (T:=8604228440844963188283145427703857421875000000) (R:=24) (Q:=285) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬285≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 34694469519536141888238489627838134765625000 16402623616990075205990251561161130666732788089 81315162936412832550558960065245628356933590 23 285=187 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery b145 (joinEvery b161 b177))))⟩
end OMA.EightAt5E61P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E62P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 83341265746245118961610387486871331930160522464 406575814682064162752794800326228141784667965 43715031594615538779180496931076049804687500000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 83341265746245118961610387486871331930160522464 406575814682064162752794800326228141784667965 43715031594615538779180496931076049804687500000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 83341265746245118961610387486871331930160522464 406575814682064162752794800326228141784667965 43715031594615538779180496931076049804687500000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 83341265746245118961610387486871331930160522464 406575814682064162752794800326228141784667965 43715031594615538779180496931076049804687500000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 83341265746245118961610387486871331930160522464 406575814682064162752794800326228141784667965 43715031594615538779180496931076049804687500000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 83341265746245118961610387486871331930160522464 406575814682064162752794800326228141784667965 43715031594615538779180496931076049804687500000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 83341265746245118961610387486871331930160522464 406575814682064162752794800326228141784667965 43715031594615538779180496931076049804687500000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 83341265746245118961610387486871331930160522464 406575814682064162752794800326228141784667965 43715031594615538779180496931076049804687500000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 83341265746245118961610387486871331930160522464 406575814682064162752794800326228141784667965 43715031594615538779180496931076049804687500000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 83341265746245118961610387486871331930160522464 406575814682064162752794800326228141784667965 43715031594615538779180496931076049804687500000 23 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 83341265746245118961610387486871331930160522464 406575814682064162752794800326228141784667965 43715031594615538779180496931076049804687500000 23 24)=true := by decide +kernel
private theorem b177 : every 177 190 (line 83341265746245118961610387486871331930160522464 406575814682064162752794800326228141784667965 43715031594615538779180496931076049804687500000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 62=true := by
  apply row_low (h:=173472347597680709441192448139190673828125000) (A:=83341265746245118961610387486871331930160522464) (S:=406575814682064162752794800326228141784667965) (T:=43715031594615538779180496931076049804687500000) (R:=24) (Q:=290) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬290≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 173472347597680709441192448139190673828125000 83341265746245118961610387486871331930160522464 406575814682064162752794800326228141784667965 23 290=190 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery b145 (joinEvery b161 b177))))⟩
end OMA.EightAt5E62P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E63P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 423347067037699309466347585839685052633285522464 2032879073410320813763974001631140708923339840 222044604925031308084726333618164062500000000000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 423347067037699309466347585839685052633285522464 2032879073410320813763974001631140708923339840 222044604925031308084726333618164062500000000000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 423347067037699309466347585839685052633285522464 2032879073410320813763974001631140708923339840 222044604925031308084726333618164062500000000000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 423347067037699309466347585839685052633285522464 2032879073410320813763974001631140708923339840 222044604925031308084726333618164062500000000000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 423347067037699309466347585839685052633285522464 2032879073410320813763974001631140708923339840 222044604925031308084726333618164062500000000000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 423347067037699309466347585839685052633285522464 2032879073410320813763974001631140708923339840 222044604925031308084726333618164062500000000000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 423347067037699309466347585839685052633285522464 2032879073410320813763974001631140708923339840 222044604925031308084726333618164062500000000000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 423347067037699309466347585839685052633285522464 2032879073410320813763974001631140708923339840 222044604925031308084726333618164062500000000000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 423347067037699309466347585839685052633285522464 2032879073410320813763974001631140708923339840 222044604925031308084726333618164062500000000000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 423347067037699309466347585839685052633285522464 2032879073410320813763974001631140708923339840 222044604925031308084726333618164062500000000000 23 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 423347067037699309466347585839685052633285522464 2032879073410320813763974001631140708923339840 222044604925031308084726333618164062500000000000 23 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 423347067037699309466347585839685052633285522464 2032879073410320813763974001631140708923339840 222044604925031308084726333618164062500000000000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 63=true := by
  apply row_low (h:=867361737988403547205962240695953369140625000) (A:=423347067037699309466347585839685052633285522464) (S:=2032879073410320813763974001631140708923339840) (T:=222044604925031308084726333618164062500000000000) (R:=24) (Q:=296) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬296≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 867361737988403547205962240695953369140625000 423347067037699309466347585839685052633285522464 2032879073410320813763974001631140708923339840 23 296=192 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery b145 (joinEvery b161 b177))))⟩
end OMA.EightAt5E63P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E64P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 2149939026720865120623216171225067228078842163089 10164395367051604068819870008155703544616699215 1127570259384924611367750912904739379882812500000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 2149939026720865120623216171225067228078842163089 10164395367051604068819870008155703544616699215 1127570259384924611367750912904739379882812500000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 2149939026720865120623216171225067228078842163089 10164395367051604068819870008155703544616699215 1127570259384924611367750912904739379882812500000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 2149939026720865120623216171225067228078842163089 10164395367051604068819870008155703544616699215 1127570259384924611367750912904739379882812500000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 2149939026720865120623216171225067228078842163089 10164395367051604068819870008155703544616699215 1127570259384924611367750912904739379882812500000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 2149939026720865120623216171225067228078842163089 10164395367051604068819870008155703544616699215 1127570259384924611367750912904739379882812500000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 2149939026720865120623216171225067228078842163089 10164395367051604068819870008155703544616699215 1127570259384924611367750912904739379882812500000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 2149939026720865120623216171225067228078842163089 10164395367051604068819870008155703544616699215 1127570259384924611367750912904739379882812500000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 2149939026720865120623216171225067228078842163089 10164395367051604068819870008155703544616699215 1127570259384924611367750912904739379882812500000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 2149939026720865120623216171225067228078842163089 10164395367051604068819870008155703544616699215 1127570259384924611367750912904739379882812500000 23 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 2149939026720865120623216171225067228078842163089 10164395367051604068819870008155703544616699215 1127570259384924611367750912904739379882812500000 23 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 2149939026720865120623216171225067228078842163089 10164395367051604068819870008155703544616699215 1127570259384924611367750912904739379882812500000 23 24)=true := by decide +kernel
private theorem b193 : every 193 195 (line 2149939026720865120623216171225067228078842163089 10164395367051604068819870008155703544616699215 1127570259384924611367750912904739379882812500000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 64=true := by
  apply row_low (h:=4336808689942017736029811203479766845703125000) (A:=2149939026720865120623216171225067228078842163089) (S:=10164395367051604068819870008155703544616699215) (T:=1127570259384924611367750912904739379882812500000) (R:=24) (Q:=301) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬301≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 4336808689942017736029811203479766845703125000 2149939026720865120623216171225067228078842163089 10164395367051604068819870008155703544616699215 23 301=195 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery (joinEvery b145 b161) (joinEvery b177 b193))))⟩
end OMA.EightAt5E64P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E65P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 10915713591266168469573472066258545964956283569339 50821976835258020344099350040778517723083496090 5724587470723463411559350788593292236328125000000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 10915713591266168469573472066258545964956283569339 50821976835258020344099350040778517723083496090 5724587470723463411559350788593292236328125000000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 10915713591266168469573472066258545964956283569339 50821976835258020344099350040778517723083496090 5724587470723463411559350788593292236328125000000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 10915713591266168469573472066258545964956283569339 50821976835258020344099350040778517723083496090 5724587470723463411559350788593292236328125000000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 10915713591266168469573472066258545964956283569339 50821976835258020344099350040778517723083496090 5724587470723463411559350788593292236328125000000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 10915713591266168469573472066258545964956283569339 50821976835258020344099350040778517723083496090 5724587470723463411559350788593292236328125000000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 10915713591266168469573472066258545964956283569339 50821976835258020344099350040778517723083496090 5724587470723463411559350788593292236328125000000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 10915713591266168469573472066258545964956283569339 50821976835258020344099350040778517723083496090 5724587470723463411559350788593292236328125000000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 10915713591266168469573472066258545964956283569339 50821976835258020344099350040778517723083496090 5724587470723463411559350788593292236328125000000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 10915713591266168469573472066258545964956283569339 50821976835258020344099350040778517723083496090 5724587470723463411559350788593292236328125000000 23 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 10915713591266168469573472066258545964956283569339 50821976835258020344099350040778517723083496090 5724587470723463411559350788593292236328125000000 23 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 10915713591266168469573472066258545964956283569339 50821976835258020344099350040778517723083496090 5724587470723463411559350788593292236328125000000 23 24)=true := by decide +kernel
private theorem b193 : every 193 197 (line 10915713591266168469573472066258545964956283569339 50821976835258020344099350040778517723083496090 5724587470723463411559350788593292236328125000000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 65=true := by
  apply row_low (h:=21684043449710088680149056017398834228515625000) (A:=10915713591266168469573472066258545964956283569339) (S:=50821976835258020344099350040778517723083496090) (T:=5724587470723463411559350788593292236328125000000) (R:=24) (Q:=307) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬307≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 21684043449710088680149056017398834228515625000 10915713591266168469573472066258545964956283569339 50821976835258020344099350040778517723083496090 23 307=197 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery (joinEvery b145 b161) (joinEvery b177 b193))))⟩
end OMA.EightAt5E65P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E66P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 55408660244640056680154316381958778947591781616214 254109884176290101720496750203892588615417480465 29056618222611518831399735063314437866210937500000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 55408660244640056680154316381958778947591781616214 254109884176290101720496750203892588615417480465 29056618222611518831399735063314437866210937500000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 55408660244640056680154316381958778947591781616214 254109884176290101720496750203892588615417480465 29056618222611518831399735063314437866210937500000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 55408660244640056680154316381958778947591781616214 254109884176290101720496750203892588615417480465 29056618222611518831399735063314437866210937500000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 55408660244640056680154316381958778947591781616214 254109884176290101720496750203892588615417480465 29056618222611518831399735063314437866210937500000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 55408660244640056680154316381958778947591781616214 254109884176290101720496750203892588615417480465 29056618222611518831399735063314437866210937500000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 55408660244640056680154316381958778947591781616214 254109884176290101720496750203892588615417480465 29056618222611518831399735063314437866210937500000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 55408660244640056680154316381958778947591781616214 254109884176290101720496750203892588615417480465 29056618222611518831399735063314437866210937500000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 55408660244640056680154316381958778947591781616214 254109884176290101720496750203892588615417480465 29056618222611518831399735063314437866210937500000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 55408660244640056680154316381958778947591781616214 254109884176290101720496750203892588615417480465 29056618222611518831399735063314437866210937500000 23 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 55408660244640056680154316381958778947591781616214 254109884176290101720496750203892588615417480465 29056618222611518831399735063314437866210937500000 23 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 55408660244640056680154316381958778947591781616214 254109884176290101720496750203892588615417480465 29056618222611518831399735063314437866210937500000 23 24)=true := by decide +kernel
private theorem b193 : every 193 200 (line 55408660244640056680154316381958778947591781616214 254109884176290101720496750203892588615417480465 29056618222611518831399735063314437866210937500000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 66=true := by
  apply row_low (h:=108420217248550443400745280086994171142578125000) (A:=55408660244640056680154316381958778947591781616214) (S:=254109884176290101720496750203892588615417480465) (T:=29056618222611518831399735063314437866210937500000) (R:=24) (Q:=312) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬312≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 108420217248550443400745280086994171142578125000 55408660244640056680154316381958778947591781616214 254109884176290101720496750203892588615417480465 23 312=200 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery (joinEvery b145 b161) (joinEvery b177 b193))))⟩
end OMA.EightAt5E66P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E67P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 281193762664746355062206362163124140352010726928714 1270549420881450508602483751019462943077087402340 147451495458028603025013580918312072753906250000000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 281193762664746355062206362163124140352010726928714 1270549420881450508602483751019462943077087402340 147451495458028603025013580918312072753906250000000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 281193762664746355062206362163124140352010726928714 1270549420881450508602483751019462943077087402340 147451495458028603025013580918312072753906250000000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 281193762664746355062206362163124140352010726928714 1270549420881450508602483751019462943077087402340 147451495458028603025013580918312072753906250000000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 281193762664746355062206362163124140352010726928714 1270549420881450508602483751019462943077087402340 147451495458028603025013580918312072753906250000000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 281193762664746355062206362163124140352010726928714 1270549420881450508602483751019462943077087402340 147451495458028603025013580918312072753906250000000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 281193762664746355062206362163124140352010726928714 1270549420881450508602483751019462943077087402340 147451495458028603025013580918312072753906250000000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 281193762664746355062206362163124140352010726928714 1270549420881450508602483751019462943077087402340 147451495458028603025013580918312072753906250000000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 281193762664746355062206362163124140352010726928714 1270549420881450508602483751019462943077087402340 147451495458028603025013580918312072753906250000000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 281193762664746355062206362163124140352010726928714 1270549420881450508602483751019462943077087402340 147451495458028603025013580918312072753906250000000 23 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 281193762664746355062206362163124140352010726928714 1270549420881450508602483751019462943077087402340 147451495458028603025013580918312072753906250000000 23 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 281193762664746355062206362163124140352010726928714 1270549420881450508602483751019462943077087402340 147451495458028603025013580918312072753906250000000 23 24)=true := by decide +kernel
private theorem b193 : every 193 202 (line 281193762664746355062206362163124140352010726928714 1270549420881450508602483751019462943077087402340 147451495458028603025013580918312072753906250000000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 67=true := by
  apply row_low (h:=542101086242752217003726400434970855712890625000) (A:=281193762664746355062206362163124140352010726928714) (S:=1270549420881450508602483751019462943077087402340) (T:=147451495458028603025013580918312072753906250000000) (R:=24) (Q:=317) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬317≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 542101086242752217003726400434970855712890625000 281193762664746355062206362163124140352010726928714 1270549420881450508602483751019462943077087402340 23 317=202 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery (joinEvery b145 b161) (joinEvery b177 b193))))⟩
end OMA.EightAt5E67P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E68P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 1426721120531462133618205712082271929830312728881839 6352747104407252543012418755097314715385437011715 748099499014998059465142432600259780883789062500000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 1426721120531462133618205712082271929830312728881839 6352747104407252543012418755097314715385437011715 748099499014998059465142432600259780883789062500000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 1426721120531462133618205712082271929830312728881839 6352747104407252543012418755097314715385437011715 748099499014998059465142432600259780883789062500000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 1426721120531462133618205712082271929830312728881839 6352747104407252543012418755097314715385437011715 748099499014998059465142432600259780883789062500000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 1426721120531462133618205712082271929830312728881839 6352747104407252543012418755097314715385437011715 748099499014998059465142432600259780883789062500000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 1426721120531462133618205712082271929830312728881839 6352747104407252543012418755097314715385437011715 748099499014998059465142432600259780883789062500000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 1426721120531462133618205712082271929830312728881839 6352747104407252543012418755097314715385437011715 748099499014998059465142432600259780883789062500000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 1426721120531462133618205712082271929830312728881839 6352747104407252543012418755097314715385437011715 748099499014998059465142432600259780883789062500000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 1426721120531462133618205712082271929830312728881839 6352747104407252543012418755097314715385437011715 748099499014998059465142432600259780883789062500000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 1426721120531462133618205712082271929830312728881839 6352747104407252543012418755097314715385437011715 748099499014998059465142432600259780883789062500000 23 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 1426721120531462133618205712082271929830312728881839 6352747104407252543012418755097314715385437011715 748099499014998059465142432600259780883789062500000 23 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 1426721120531462133618205712082271929830312728881839 6352747104407252543012418755097314715385437011715 748099499014998059465142432600259780883789062500000 23 24)=true := by decide +kernel
private theorem b193 : every 193 205 (line 1426721120531462133618205712082271929830312728881839 6352747104407252543012418755097314715385437011715 748099499014998059465142432600259780883789062500000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 68=true := by
  apply row_low (h:=2710505431213761085018632002174854278564453125000) (A:=1426721120531462133618205712082271929830312728881839) (S:=6352747104407252543012418755097314715385437011715) (T:=748099499014998059465142432600259780883789062500000) (R:=24) (Q:=323) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬323≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 2710505431213761085018632002174854278564453125000 1426721120531462133618205712082271929830312728881839 6352747104407252543012418755097314715385437011715 23 323=205 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery (joinEvery b145 b161) (joinEvery b177 b193))))⟩
end OMA.EightAt5E68P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E69P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 7237367138695962459626898066744615789502859115600589 31763735522036262715062093775486573576927185058590 3794707603699265519026084803044795989990234375000000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 7237367138695962459626898066744615789502859115600589 31763735522036262715062093775486573576927185058590 3794707603699265519026084803044795989990234375000000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 7237367138695962459626898066744615789502859115600589 31763735522036262715062093775486573576927185058590 3794707603699265519026084803044795989990234375000000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 7237367138695962459626898066744615789502859115600589 31763735522036262715062093775486573576927185058590 3794707603699265519026084803044795989990234375000000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 7237367138695962459626898066744615789502859115600589 31763735522036262715062093775486573576927185058590 3794707603699265519026084803044795989990234375000000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 7237367138695962459626898066744615789502859115600589 31763735522036262715062093775486573576927185058590 3794707603699265519026084803044795989990234375000000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 7237367138695962459626898066744615789502859115600589 31763735522036262715062093775486573576927185058590 3794707603699265519026084803044795989990234375000000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 7237367138695962459626898066744615789502859115600589 31763735522036262715062093775486573576927185058590 3794707603699265519026084803044795989990234375000000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 7237367138695962459626898066744615789502859115600589 31763735522036262715062093775486573576927185058590 3794707603699265519026084803044795989990234375000000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 7237367138695962459626898066744615789502859115600589 31763735522036262715062093775486573576927185058590 3794707603699265519026084803044795989990234375000000 23 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 7237367138695962459626898066744615789502859115600589 31763735522036262715062093775486573576927185058590 3794707603699265519026084803044795989990234375000000 23 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 7237367138695962459626898066744615789502859115600589 31763735522036262715062093775486573576927185058590 3794707603699265519026084803044795989990234375000000 23 24)=true := by decide +kernel
private theorem b193 : every 193 207 (line 7237367138695962459626898066744615789502859115600589 31763735522036262715062093775486573576927185058590 3794707603699265519026084803044795989990234375000000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 69=true := by
  apply row_low (h:=13552527156068805425093160010874271392822265625000) (A:=7237367138695962459626898066744615789502859115600589) (S:=31763735522036262715062093775486573576927185058590) (T:=3794707603699265519026084803044795989990234375000000) (R:=24) (Q:=328) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬328≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 13552527156068805425093160010874271392822265625000 7237367138695962459626898066744615789502859115600589 31763735522036262715062093775486573576927185058590 23 328=207 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81))) (joinEvery (joinEvery b97 (joinEvery b113 b129)) (joinEvery (joinEvery b145 b161) (joinEvery b177 b193))))⟩
end OMA.EightAt5E69P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E70P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 36705643373673071255813837865389359649270772933959964 158818677610181313575310468877432867884635925292965 19244588561617703703632287215441465377807617187500000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 36705643373673071255813837865389359649270772933959964 158818677610181313575310468877432867884635925292965 19244588561617703703632287215441465377807617187500000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 36705643373673071255813837865389359649270772933959964 158818677610181313575310468877432867884635925292965 19244588561617703703632287215441465377807617187500000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 36705643373673071255813837865389359649270772933959964 158818677610181313575310468877432867884635925292965 19244588561617703703632287215441465377807617187500000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 36705643373673071255813837865389359649270772933959964 158818677610181313575310468877432867884635925292965 19244588561617703703632287215441465377807617187500000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 36705643373673071255813837865389359649270772933959964 158818677610181313575310468877432867884635925292965 19244588561617703703632287215441465377807617187500000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 36705643373673071255813837865389359649270772933959964 158818677610181313575310468877432867884635925292965 19244588561617703703632287215441465377807617187500000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 36705643373673071255813837865389359649270772933959964 158818677610181313575310468877432867884635925292965 19244588561617703703632287215441465377807617187500000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 36705643373673071255813837865389359649270772933959964 158818677610181313575310468877432867884635925292965 19244588561617703703632287215441465377807617187500000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 36705643373673071255813837865389359649270772933959964 158818677610181313575310468877432867884635925292965 19244588561617703703632287215441465377807617187500000 23 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 36705643373673071255813837865389359649270772933959964 158818677610181313575310468877432867884635925292965 19244588561617703703632287215441465377807617187500000 23 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 36705643373673071255813837865389359649270772933959964 158818677610181313575310468877432867884635925292965 19244588561617703703632287215441465377807617187500000 23 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 36705643373673071255813837865389359649270772933959964 158818677610181313575310468877432867884635925292965 19244588561617703703632287215441465377807617187500000 23 24)=true := by decide +kernel
private theorem b209 : every 209 212 (line 36705643373673071255813837865389359649270772933959964 158818677610181313575310468877432867884635925292965 19244588561617703703632287215441465377807617187500000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 70=true := by
  apply row_low (h:=67762635780344027125465800054371356964111328125000) (A:=36705643373673071255813837865389359649270772933959964) (S:=158818677610181313575310468877432867884635925292965) (T:=19244588561617703703632287215441465377807617187500000) (R:=24) (Q:=334) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬334≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 67762635780344027125465800054371356964111328125000 36705643373673071255813837865389359649270772933959964 158818677610181313575310468877432867884635925292965 23 334=212 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97))) (joinEvery (joinEvery b113 (joinEvery b129 b145)) (joinEvery (joinEvery b161 b177) (joinEvery b193 b209))))⟩
end OMA.EightAt5E70P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E71P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 186122255269331651067465926985278201755136251449584964 794093388050906567876552344387164339423179626464840 97578195523695399060670752078294754028320312500000000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 186122255269331651067465926985278201755136251449584964 794093388050906567876552344387164339423179626464840 97578195523695399060670752078294754028320312500000000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 186122255269331651067465926985278201755136251449584964 794093388050906567876552344387164339423179626464840 97578195523695399060670752078294754028320312500000000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 186122255269331651067465926985278201755136251449584964 794093388050906567876552344387164339423179626464840 97578195523695399060670752078294754028320312500000000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 186122255269331651067465926985278201755136251449584964 794093388050906567876552344387164339423179626464840 97578195523695399060670752078294754028320312500000000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 186122255269331651067465926985278201755136251449584964 794093388050906567876552344387164339423179626464840 97578195523695399060670752078294754028320312500000000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 186122255269331651067465926985278201755136251449584964 794093388050906567876552344387164339423179626464840 97578195523695399060670752078294754028320312500000000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 186122255269331651067465926985278201755136251449584964 794093388050906567876552344387164339423179626464840 97578195523695399060670752078294754028320312500000000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 186122255269331651067465926985278201755136251449584964 794093388050906567876552344387164339423179626464840 97578195523695399060670752078294754028320312500000000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 186122255269331651067465926985278201755136251449584964 794093388050906567876552344387164339423179626464840 97578195523695399060670752078294754028320312500000000 23 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 186122255269331651067465926985278201755136251449584964 794093388050906567876552344387164339423179626464840 97578195523695399060670752078294754028320312500000000 23 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 186122255269331651067465926985278201755136251449584964 794093388050906567876552344387164339423179626464840 97578195523695399060670752078294754028320312500000000 23 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 186122255269331651067465926985278201755136251449584964 794093388050906567876552344387164339423179626464840 97578195523695399060670752078294754028320312500000000 23 24)=true := by decide +kernel
private theorem b209 : every 209 214 (line 186122255269331651067465926985278201755136251449584964 794093388050906567876552344387164339423179626464840 97578195523695399060670752078294754028320312500000000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 71=true := by
  apply row_low (h:=338813178901720135627329000271856784820556640625000) (A:=186122255269331651067465926985278201755136251449584964) (S:=794093388050906567876552344387164339423179626464840) (T:=97578195523695399060670752078294754028320312500000000) (R:=24) (Q:=339) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬339≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 338813178901720135627329000271856784820556640625000 186122255269331651067465926985278201755136251449584964 794093388050906567876552344387164339423179626464840 23 339=214 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97))) (joinEvery (joinEvery b113 (joinEvery b129 b145)) (joinEvery (joinEvery b161 b177) (joinEvery b193 b209))))⟩
end OMA.EightAt5E71P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E72P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 943581468351489729279313323218048026319593191146850589 3970466940254532839382761721935821697115898132324215 494667241196511398015900340396910905838012695312500000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 943581468351489729279313323218048026319593191146850589 3970466940254532839382761721935821697115898132324215 494667241196511398015900340396910905838012695312500000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 943581468351489729279313323218048026319593191146850589 3970466940254532839382761721935821697115898132324215 494667241196511398015900340396910905838012695312500000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 943581468351489729279313323218048026319593191146850589 3970466940254532839382761721935821697115898132324215 494667241196511398015900340396910905838012695312500000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 943581468351489729279313323218048026319593191146850589 3970466940254532839382761721935821697115898132324215 494667241196511398015900340396910905838012695312500000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 943581468351489729279313323218048026319593191146850589 3970466940254532839382761721935821697115898132324215 494667241196511398015900340396910905838012695312500000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 943581468351489729279313323218048026319593191146850589 3970466940254532839382761721935821697115898132324215 494667241196511398015900340396910905838012695312500000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 943581468351489729279313323218048026319593191146850589 3970466940254532839382761721935821697115898132324215 494667241196511398015900340396910905838012695312500000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 943581468351489729279313323218048026319593191146850589 3970466940254532839382761721935821697115898132324215 494667241196511398015900340396910905838012695312500000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 943581468351489729279313323218048026319593191146850589 3970466940254532839382761721935821697115898132324215 494667241196511398015900340396910905838012695312500000 23 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 943581468351489729279313323218048026319593191146850589 3970466940254532839382761721935821697115898132324215 494667241196511398015900340396910905838012695312500000 23 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 943581468351489729279313323218048026319593191146850589 3970466940254532839382761721935821697115898132324215 494667241196511398015900340396910905838012695312500000 23 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 943581468351489729279313323218048026319593191146850589 3970466940254532839382761721935821697115898132324215 494667241196511398015900340396910905838012695312500000 23 24)=true := by decide +kernel
private theorem b209 : every 209 217 (line 943581468351489729279313323218048026319593191146850589 3970466940254532839382761721935821697115898132324215 494667241196511398015900340396910905838012695312500000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 72=true := by
  apply row_low (h:=1694065894508600678136645001359283924102783203125000) (A:=943581468351489729279313323218048026319593191146850589) (S:=3970466940254532839382761721935821697115898132324215) (T:=494667241196511398015900340396910905838012695312500000) (R:=24) (Q:=345) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬345≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 1694065894508600678136645001359283924102783203125000 943581468351489729279313323218048026319593191146850589 3970466940254532839382761721935821697115898132324215 23 345=217 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97))) (joinEvery (joinEvery b113 (joinEvery b129 b145)) (joinEvery (joinEvery b161 b177) (joinEvery b193 b209))))⟩
end OMA.EightAt5E72P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E73P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 4782758301781606016106485057548525219317525625228881839 19852334701272664196913808609679108485579490661621090 2507217523872729003642234602011740207672119140625000000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 4782758301781606016106485057548525219317525625228881839 19852334701272664196913808609679108485579490661621090 2507217523872729003642234602011740207672119140625000000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 4782758301781606016106485057548525219317525625228881839 19852334701272664196913808609679108485579490661621090 2507217523872729003642234602011740207672119140625000000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 4782758301781606016106485057548525219317525625228881839 19852334701272664196913808609679108485579490661621090 2507217523872729003642234602011740207672119140625000000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 4782758301781606016106485057548525219317525625228881839 19852334701272664196913808609679108485579490661621090 2507217523872729003642234602011740207672119140625000000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 4782758301781606016106485057548525219317525625228881839 19852334701272664196913808609679108485579490661621090 2507217523872729003642234602011740207672119140625000000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 4782758301781606016106485057548525219317525625228881839 19852334701272664196913808609679108485579490661621090 2507217523872729003642234602011740207672119140625000000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 4782758301781606016106485057548525219317525625228881839 19852334701272664196913808609679108485579490661621090 2507217523872729003642234602011740207672119140625000000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 4782758301781606016106485057548525219317525625228881839 19852334701272664196913808609679108485579490661621090 2507217523872729003642234602011740207672119140625000000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 4782758301781606016106485057548525219317525625228881839 19852334701272664196913808609679108485579490661621090 2507217523872729003642234602011740207672119140625000000 23 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 4782758301781606016106485057548525219317525625228881839 19852334701272664196913808609679108485579490661621090 2507217523872729003642234602011740207672119140625000000 23 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 4782758301781606016106485057548525219317525625228881839 19852334701272664196913808609679108485579490661621090 2507217523872729003642234602011740207672119140625000000 23 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 4782758301781606016106485057548525219317525625228881839 19852334701272664196913808609679108485579490661621090 2507217523872729003642234602011740207672119140625000000 23 24)=true := by decide +kernel
private theorem b209 : every 209 219 (line 4782758301781606016106485057548525219317525625228881839 19852334701272664196913808609679108485579490661621090 2507217523872729003642234602011740207672119140625000000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 73=true := by
  apply row_low (h:=8470329472543003390683225006796419620513916015625000) (A:=4782758301781606016106485057548525219317525625228881839) (S:=19852334701272664196913808609679108485579490661621090) (T:=2507217523872729003642234602011740207672119140625000000) (R:=24) (Q:=351) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬351≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 8470329472543003390683225006796419620513916015625000 4782758301781606016106485057548525219317525625228881839 19852334701272664196913808609679108485579490661621090 23 351=219 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97))) (joinEvery (joinEvery b113 (joinEvery b129 b145)) (joinEvery (joinEvery b161 b177) (joinEvery b193 b209))))⟩
end OMA.EightAt5E73P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E74P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 24238046309028816929082017495034051535185426473617553714 99261673506363320984569043048395542427897453308105465 12705494208814505086024837510194629430770874023437500000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 24238046309028816929082017495034051535185426473617553714 99261673506363320984569043048395542427897453308105465 12705494208814505086024837510194629430770874023437500000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 24238046309028816929082017495034051535185426473617553714 99261673506363320984569043048395542427897453308105465 12705494208814505086024837510194629430770874023437500000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 24238046309028816929082017495034051535185426473617553714 99261673506363320984569043048395542427897453308105465 12705494208814505086024837510194629430770874023437500000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 24238046309028816929082017495034051535185426473617553714 99261673506363320984569043048395542427897453308105465 12705494208814505086024837510194629430770874023437500000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 24238046309028816929082017495034051535185426473617553714 99261673506363320984569043048395542427897453308105465 12705494208814505086024837510194629430770874023437500000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 24238046309028816929082017495034051535185426473617553714 99261673506363320984569043048395542427897453308105465 12705494208814505086024837510194629430770874023437500000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 24238046309028816929082017495034051535185426473617553714 99261673506363320984569043048395542427897453308105465 12705494208814505086024837510194629430770874023437500000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 24238046309028816929082017495034051535185426473617553714 99261673506363320984569043048395542427897453308105465 12705494208814505086024837510194629430770874023437500000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 24238046309028816929082017495034051535185426473617553714 99261673506363320984569043048395542427897453308105465 12705494208814505086024837510194629430770874023437500000 23 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 24238046309028816929082017495034051535185426473617553714 99261673506363320984569043048395542427897453308105465 12705494208814505086024837510194629430770874023437500000 23 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 24238046309028816929082017495034051535185426473617553714 99261673506363320984569043048395542427897453308105465 12705494208814505086024837510194629430770874023437500000 23 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 24238046309028816929082017495034051535185426473617553714 99261673506363320984569043048395542427897453308105465 12705494208814505086024837510194629430770874023437500000 23 24)=true := by decide +kernel
private theorem b209 : every 209 222 (line 24238046309028816929082017495034051535185426473617553714 99261673506363320984569043048395542427897453308105465 12705494208814505086024837510194629430770874023437500000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 74=true := by
  apply row_low (h:=42351647362715016953416125033982098102569580078125000) (A:=24238046309028816929082017495034051535185426473617553714) (S:=99261673506363320984569043048395542427897453308105465) (T:=12705494208814505086024837510194629430770874023437500000) (R:=24) (Q:=356) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬356≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 42351647362715016953416125033982098102569580078125000 24238046309028816929082017495034051535185426473617553714 99261673506363320984569043048395542427897453308105465 23 356=222 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97))) (joinEvery (joinEvery b113 (joinEvery b129 b145)) (joinEvery (joinEvery b161 b177) (joinEvery b193 b209))))⟩
end OMA.EightAt5E74P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E75P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 122811505545748018888158048511627384868916124105453491214 496308367531816604922845215241977712139487266540527340 64374503991326825769192510051652789115905761718750000000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 122811505545748018888158048511627384868916124105453491214 496308367531816604922845215241977712139487266540527340 64374503991326825769192510051652789115905761718750000000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 122811505545748018888158048511627384868916124105453491214 496308367531816604922845215241977712139487266540527340 64374503991326825769192510051652789115905761718750000000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 122811505545748018888158048511627384868916124105453491214 496308367531816604922845215241977712139487266540527340 64374503991326825769192510051652789115905761718750000000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 122811505545748018888158048511627384868916124105453491214 496308367531816604922845215241977712139487266540527340 64374503991326825769192510051652789115905761718750000000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 122811505545748018888158048511627384868916124105453491214 496308367531816604922845215241977712139487266540527340 64374503991326825769192510051652789115905761718750000000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 122811505545748018888158048511627384868916124105453491214 496308367531816604922845215241977712139487266540527340 64374503991326825769192510051652789115905761718750000000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 122811505545748018888158048511627384868916124105453491214 496308367531816604922845215241977712139487266540527340 64374503991326825769192510051652789115905761718750000000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 122811505545748018888158048511627384868916124105453491214 496308367531816604922845215241977712139487266540527340 64374503991326825769192510051652789115905761718750000000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 122811505545748018888158048511627384868916124105453491214 496308367531816604922845215241977712139487266540527340 64374503991326825769192510051652789115905761718750000000 23 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 122811505545748018888158048511627384868916124105453491214 496308367531816604922845215241977712139487266540527340 64374503991326825769192510051652789115905761718750000000 23 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 122811505545748018888158048511627384868916124105453491214 496308367531816604922845215241977712139487266540527340 64374503991326825769192510051652789115905761718750000000 23 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 122811505545748018888158048511627384868916124105453491214 496308367531816604922845215241977712139487266540527340 64374503991326825769192510051652789115905761718750000000 23 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 122811505545748018888158048511627384868916124105453491214 496308367531816604922845215241977712139487266540527340 64374503991326825769192510051652789115905761718750000000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 75=true := by
  apply row_low (h:=211758236813575084767080625169910490512847900390625000) (A:=122811505545748018888158048511627384868916124105453491214) (S:=496308367531816604922845215241977712139487266540527340) (T:=64374503991326825769192510051652789115905761718750000000) (R:=24) (Q:=362) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬362≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 211758236813575084767080625169910490512847900390625000 122811505545748018888158048511627384868916124105453491214 496308367531816604922845215241977712139487266540527340 23 362=224 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97))) (joinEvery (joinEvery b113 (joinEvery b129 b145)) (joinEvery (joinEvery b161 b177) (joinEvery b193 b209))))⟩
end OMA.EightAt5E75P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E76P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 622163897731759765654530047740422560309525579214096069339 2481541837659083024614226076209888560697436332702636715 326107684692905630541304162761662155389785766601562500000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 622163897731759765654530047740422560309525579214096069339 2481541837659083024614226076209888560697436332702636715 326107684692905630541304162761662155389785766601562500000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 622163897731759765654530047740422560309525579214096069339 2481541837659083024614226076209888560697436332702636715 326107684692905630541304162761662155389785766601562500000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 622163897731759765654530047740422560309525579214096069339 2481541837659083024614226076209888560697436332702636715 326107684692905630541304162761662155389785766601562500000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 622163897731759765654530047740422560309525579214096069339 2481541837659083024614226076209888560697436332702636715 326107684692905630541304162761662155389785766601562500000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 622163897731759765654530047740422560309525579214096069339 2481541837659083024614226076209888560697436332702636715 326107684692905630541304162761662155389785766601562500000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 622163897731759765654530047740422560309525579214096069339 2481541837659083024614226076209888560697436332702636715 326107684692905630541304162761662155389785766601562500000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 622163897731759765654530047740422560309525579214096069339 2481541837659083024614226076209888560697436332702636715 326107684692905630541304162761662155389785766601562500000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 622163897731759765654530047740422560309525579214096069339 2481541837659083024614226076209888560697436332702636715 326107684692905630541304162761662155389785766601562500000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 622163897731759765654530047740422560309525579214096069339 2481541837659083024614226076209888560697436332702636715 326107684692905630541304162761662155389785766601562500000 23 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 622163897731759765654530047740422560309525579214096069339 2481541837659083024614226076209888560697436332702636715 326107684692905630541304162761662155389785766601562500000 23 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 622163897731759765654530047740422560309525579214096069339 2481541837659083024614226076209888560697436332702636715 326107684692905630541304162761662155389785766601562500000 23 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 622163897731759765654530047740422560309525579214096069339 2481541837659083024614226076209888560697436332702636715 326107684692905630541304162761662155389785766601562500000 23 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 622163897731759765654530047740422560309525579214096069339 2481541837659083024614226076209888560697436332702636715 326107684692905630541304162761662155389785766601562500000 23 24)=true := by decide +kernel
private theorem b225 : every 225 227 (line 622163897731759765654530047740422560309525579214096069339 2481541837659083024614226076209888560697436332702636715 326107684692905630541304162761662155389785766601562500000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 76=true := by
  apply row_low (h:=1058791184067875423835403125849552452564239501953125000) (A:=622163897731759765654530047740422560309525579214096069339) (S:=2481541837659083024614226076209888560697436332702636715) (T:=326107684692905630541304162761662155389785766601562500000) (R:=24) (Q:=368) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬368≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 1058791184067875423835403125849552452564239501953125000 622163897731759765654530047740422560309525579214096069339 2481541837659083024614226076209888560697436332702636715 23 368=227 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97))) (joinEvery (joinEvery (joinEvery b113 b129) (joinEvery b145 b161)) (joinEvery (joinEvery b177 b193) (joinEvery b209 b225))))⟩
end OMA.EightAt5E76P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E77P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 3151351338673897184341349264613540981372352689504623413089 12407709188295415123071130381049442803487181663513183590 1651714247145885661183228876325301826000213623046875000000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 3151351338673897184341349264613540981372352689504623413089 12407709188295415123071130381049442803487181663513183590 1651714247145885661183228876325301826000213623046875000000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 3151351338673897184341349264613540981372352689504623413089 12407709188295415123071130381049442803487181663513183590 1651714247145885661183228876325301826000213623046875000000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 3151351338673897184341349264613540981372352689504623413089 12407709188295415123071130381049442803487181663513183590 1651714247145885661183228876325301826000213623046875000000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 3151351338673897184341349264613540981372352689504623413089 12407709188295415123071130381049442803487181663513183590 1651714247145885661183228876325301826000213623046875000000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 3151351338673897184341349264613540981372352689504623413089 12407709188295415123071130381049442803487181663513183590 1651714247145885661183228876325301826000213623046875000000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 3151351338673897184341349264613540981372352689504623413089 12407709188295415123071130381049442803487181663513183590 1651714247145885661183228876325301826000213623046875000000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 3151351338673897184341349264613540981372352689504623413089 12407709188295415123071130381049442803487181663513183590 1651714247145885661183228876325301826000213623046875000000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 3151351338673897184341349264613540981372352689504623413089 12407709188295415123071130381049442803487181663513183590 1651714247145885661183228876325301826000213623046875000000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 3151351338673897184341349264613540981372352689504623413089 12407709188295415123071130381049442803487181663513183590 1651714247145885661183228876325301826000213623046875000000 23 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 3151351338673897184341349264613540981372352689504623413089 12407709188295415123071130381049442803487181663513183590 1651714247145885661183228876325301826000213623046875000000 23 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 3151351338673897184341349264613540981372352689504623413089 12407709188295415123071130381049442803487181663513183590 1651714247145885661183228876325301826000213623046875000000 23 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 3151351338673897184341349264613540981372352689504623413089 12407709188295415123071130381049442803487181663513183590 1651714247145885661183228876325301826000213623046875000000 23 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 3151351338673897184341349264613540981372352689504623413089 12407709188295415123071130381049442803487181663513183590 1651714247145885661183228876325301826000213623046875000000 23 24)=true := by decide +kernel
private theorem b225 : every 225 229 (line 3151351338673897184341349264613540981372352689504623413089 12407709188295415123071130381049442803487181663513183590 1651714247145885661183228876325301826000213623046875000000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 77=true := by
  apply row_low (h:=5293955920339377119177015629247762262821197509765625000) (A:=3151351338673897184341349264613540981372352689504623413089) (S:=12407709188295415123071130381049442803487181663513183590) (T:=1651714247145885661183228876325301826000213623046875000000) (R:=24) (Q:=373) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬373≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 5293955920339377119177015629247762262821197509765625000 3151351338673897184341349264613540981372352689504623413089 12407709188295415123071130381049442803487181663513183590 23 373=229 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97))) (joinEvery (joinEvery (joinEvery b113 b129) (joinEvery b145 b161)) (joinEvery (joinEvery b177 b193) (joinEvery b209 b225))))⟩
end OMA.EightAt5E77P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E78P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 15959415943444977702050241452624845805985387414693832397464 62038545941477075615355651905247214017435908317565917965 8364450354136215848299684694211464375257492065429687500000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 15959415943444977702050241452624845805985387414693832397464 62038545941477075615355651905247214017435908317565917965 8364450354136215848299684694211464375257492065429687500000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 15959415943444977702050241452624845805985387414693832397464 62038545941477075615355651905247214017435908317565917965 8364450354136215848299684694211464375257492065429687500000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 15959415943444977702050241452624845805985387414693832397464 62038545941477075615355651905247214017435908317565917965 8364450354136215848299684694211464375257492065429687500000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 15959415943444977702050241452624845805985387414693832397464 62038545941477075615355651905247214017435908317565917965 8364450354136215848299684694211464375257492065429687500000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 15959415943444977702050241452624845805985387414693832397464 62038545941477075615355651905247214017435908317565917965 8364450354136215848299684694211464375257492065429687500000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 15959415943444977702050241452624845805985387414693832397464 62038545941477075615355651905247214017435908317565917965 8364450354136215848299684694211464375257492065429687500000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 15959415943444977702050241452624845805985387414693832397464 62038545941477075615355651905247214017435908317565917965 8364450354136215848299684694211464375257492065429687500000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 15959415943444977702050241452624845805985387414693832397464 62038545941477075615355651905247214017435908317565917965 8364450354136215848299684694211464375257492065429687500000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 15959415943444977702050241452624845805985387414693832397464 62038545941477075615355651905247214017435908317565917965 8364450354136215848299684694211464375257492065429687500000 23 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 15959415943444977702050241452624845805985387414693832397464 62038545941477075615355651905247214017435908317565917965 8364450354136215848299684694211464375257492065429687500000 23 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 15959415943444977702050241452624845805985387414693832397464 62038545941477075615355651905247214017435908317565917965 8364450354136215848299684694211464375257492065429687500000 23 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 15959415943444977702050241452624845805985387414693832397464 62038545941477075615355651905247214017435908317565917965 8364450354136215848299684694211464375257492065429687500000 23 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 15959415943444977702050241452624845805985387414693832397464 62038545941477075615355651905247214017435908317565917965 8364450354136215848299684694211464375257492065429687500000 23 24)=true := by decide +kernel
private theorem b225 : every 225 232 (line 15959415943444977702050241452624845805985387414693832397464 62038545941477075615355651905247214017435908317565917965 8364450354136215848299684694211464375257492065429687500000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 78=true := by
  apply row_low (h:=26469779601696885595885078146238811314105987548828125000) (A:=15959415943444977702050241452624845805985387414693832397464) (S:=62038545941477075615355651905247214017435908317565917965) (T:=8364450354136215848299684694211464375257492065429687500000) (R:=24) (Q:=379) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬379≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 26469779601696885595885078146238811314105987548828125000 15959415943444977702050241452624845805985387414693832397464 62038545941477075615355651905247214017435908317565917965 23 379=232 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97))) (joinEvery (joinEvery (joinEvery b113 b129) (joinEvery b145 b161)) (joinEvery (joinEvery b177 b193) (joinEvery b209 b225))))⟩
end OMA.EightAt5E78P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E79P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 80810375967602347411968682910909933525545056909322738647464 310192729707385378076778259526236070087179541587829589840 42351647362715016953416125033982098102569580078125000000000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 80810375967602347411968682910909933525545056909322738647464 310192729707385378076778259526236070087179541587829589840 42351647362715016953416125033982098102569580078125000000000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 80810375967602347411968682910909933525545056909322738647464 310192729707385378076778259526236070087179541587829589840 42351647362715016953416125033982098102569580078125000000000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 80810375967602347411968682910909933525545056909322738647464 310192729707385378076778259526236070087179541587829589840 42351647362715016953416125033982098102569580078125000000000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 80810375967602347411968682910909933525545056909322738647464 310192729707385378076778259526236070087179541587829589840 42351647362715016953416125033982098102569580078125000000000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 80810375967602347411968682910909933525545056909322738647464 310192729707385378076778259526236070087179541587829589840 42351647362715016953416125033982098102569580078125000000000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 80810375967602347411968682910909933525545056909322738647464 310192729707385378076778259526236070087179541587829589840 42351647362715016953416125033982098102569580078125000000000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 80810375967602347411968682910909933525545056909322738647464 310192729707385378076778259526236070087179541587829589840 42351647362715016953416125033982098102569580078125000000000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 80810375967602347411968682910909933525545056909322738647464 310192729707385378076778259526236070087179541587829589840 42351647362715016953416125033982098102569580078125000000000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 80810375967602347411968682910909933525545056909322738647464 310192729707385378076778259526236070087179541587829589840 42351647362715016953416125033982098102569580078125000000000 23 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 80810375967602347411968682910909933525545056909322738647464 310192729707385378076778259526236070087179541587829589840 42351647362715016953416125033982098102569580078125000000000 23 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 80810375967602347411968682910909933525545056909322738647464 310192729707385378076778259526236070087179541587829589840 42351647362715016953416125033982098102569580078125000000000 23 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 80810375967602347411968682910909933525545056909322738647464 310192729707385378076778259526236070087179541587829589840 42351647362715016953416125033982098102569580078125000000000 23 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 80810375967602347411968682910909933525545056909322738647464 310192729707385378076778259526236070087179541587829589840 42351647362715016953416125033982098102569580078125000000000 23 24)=true := by decide +kernel
private theorem b225 : every 225 234 (line 80810375967602347411968682910909933525545056909322738647464 310192729707385378076778259526236070087179541587829589840 42351647362715016953416125033982098102569580078125000000000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 79=true := by
  apply row_low (h:=132348898008484427979425390731194056570529937744140625000) (A:=80810375967602347411968682910909933525545056909322738647464) (S:=310192729707385378076778259526236070087179541587829589840) (T:=42351647362715016953416125033982098102569580078125000000000) (R:=24) (Q:=385) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬385≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 132348898008484427979425390731194056570529937744140625000 80810375967602347411968682910909933525545056909322738647464 310192729707385378076778259526236070087179541587829589840 23 385=234 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97))) (joinEvery (joinEvery (joinEvery b113 b129) (joinEvery b145 b161)) (joinEvery (joinEvery b177 b193) (joinEvery b209 b225))))⟩
end OMA.EightAt5E79P23

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E80P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 409118361089899031568430792793478190105815883725881576538089 1550963648536926890383891297631180350435897707939147949215 214405214773744773326669132984534371644258499145507812500000 23 24)=true := by decide +kernel
private theorem b17 : every 17 32 (line 409118361089899031568430792793478190105815883725881576538089 1550963648536926890383891297631180350435897707939147949215 214405214773744773326669132984534371644258499145507812500000 23 24)=true := by decide +kernel
private theorem b33 : every 33 48 (line 409118361089899031568430792793478190105815883725881576538089 1550963648536926890383891297631180350435897707939147949215 214405214773744773326669132984534371644258499145507812500000 23 24)=true := by decide +kernel
private theorem b49 : every 49 64 (line 409118361089899031568430792793478190105815883725881576538089 1550963648536926890383891297631180350435897707939147949215 214405214773744773326669132984534371644258499145507812500000 23 24)=true := by decide +kernel
private theorem b65 : every 65 80 (line 409118361089899031568430792793478190105815883725881576538089 1550963648536926890383891297631180350435897707939147949215 214405214773744773326669132984534371644258499145507812500000 23 24)=true := by decide +kernel
private theorem b81 : every 81 96 (line 409118361089899031568430792793478190105815883725881576538089 1550963648536926890383891297631180350435897707939147949215 214405214773744773326669132984534371644258499145507812500000 23 24)=true := by decide +kernel
private theorem b97 : every 97 112 (line 409118361089899031568430792793478190105815883725881576538089 1550963648536926890383891297631180350435897707939147949215 214405214773744773326669132984534371644258499145507812500000 23 24)=true := by decide +kernel
private theorem b113 : every 113 128 (line 409118361089899031568430792793478190105815883725881576538089 1550963648536926890383891297631180350435897707939147949215 214405214773744773326669132984534371644258499145507812500000 23 24)=true := by decide +kernel
private theorem b129 : every 129 144 (line 409118361089899031568430792793478190105815883725881576538089 1550963648536926890383891297631180350435897707939147949215 214405214773744773326669132984534371644258499145507812500000 23 24)=true := by decide +kernel
private theorem b145 : every 145 160 (line 409118361089899031568430792793478190105815883725881576538089 1550963648536926890383891297631180350435897707939147949215 214405214773744773326669132984534371644258499145507812500000 23 24)=true := by decide +kernel
private theorem b161 : every 161 176 (line 409118361089899031568430792793478190105815883725881576538089 1550963648536926890383891297631180350435897707939147949215 214405214773744773326669132984534371644258499145507812500000 23 24)=true := by decide +kernel
private theorem b177 : every 177 192 (line 409118361089899031568430792793478190105815883725881576538089 1550963648536926890383891297631180350435897707939147949215 214405214773744773326669132984534371644258499145507812500000 23 24)=true := by decide +kernel
private theorem b193 : every 193 208 (line 409118361089899031568430792793478190105815883725881576538089 1550963648536926890383891297631180350435897707939147949215 214405214773744773326669132984534371644258499145507812500000 23 24)=true := by decide +kernel
private theorem b209 : every 209 224 (line 409118361089899031568430792793478190105815883725881576538089 1550963648536926890383891297631180350435897707939147949215 214405214773744773326669132984534371644258499145507812500000 23 24)=true := by decide +kernel
private theorem b225 : every 225 237 (line 409118361089899031568430792793478190105815883725881576538089 1550963648536926890383891297631180350435897707939147949215 214405214773744773326669132984534371644258499145507812500000 23 24)=true := by decide +kernel
theorem certificate : atom 5 23 80=true := by
  apply row_low (h:=661744490042422139897126953655970282852649688720703125000) (A:=409118361089899031568430792793478190105815883725881576538089) (S:=1550963648536926890383891297631180350435897707939147949215) (T:=214405214773744773326669132984534371644258499145507812500000) (R:=24) (Q:=391) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬391≤24+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 661744490042422139897126953655970282852649688720703125000 409118361089899031568430792793478190105815883725881576538089 1550963648536926890383891297631180350435897707939147949215 23 391=237 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery (joinEvery b49 b65) (joinEvery b81 b97))) (joinEvery (joinEvery (joinEvery b113 b129) (joinEvery b145 b161)) (joinEvery (joinEvery b177 b193) (joinEvery b209 b225))))⟩
end OMA.EightAt5E80P23

namespace OMA.EightShort5To80P23
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeMiddle245212 (joinEvery)
theorem certificate : every 1 80 (atom 5 23)=true := (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery (single (f:=atom 5 23) OMA.EightAt5E1P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E2P23.certificate)) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E3P23.certificate) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E4P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E5P23.certificate)))) (joinEvery (joinEvery (single (f:=atom 5 23) OMA.EightAt5E6P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E7P23.certificate)) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E8P23.certificate) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E9P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E10P23.certificate))))) (joinEvery (joinEvery (joinEvery (single (f:=atom 5 23) OMA.EightAt5E11P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E12P23.certificate)) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E13P23.certificate) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E14P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E15P23.certificate)))) (joinEvery (joinEvery (single (f:=atom 5 23) OMA.EightAt5E16P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E17P23.certificate)) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E18P23.certificate) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E19P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E20P23.certificate)))))) (joinEvery (joinEvery (joinEvery (joinEvery (single (f:=atom 5 23) OMA.EightAt5E21P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E22P23.certificate)) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E23P23.certificate) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E24P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E25P23.certificate)))) (joinEvery (joinEvery (single (f:=atom 5 23) OMA.EightAt5E26P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E27P23.certificate)) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E28P23.certificate) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E29P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E30P23.certificate))))) (joinEvery (joinEvery (joinEvery (single (f:=atom 5 23) OMA.EightAt5E31P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E32P23.certificate)) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E33P23.certificate) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E34P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E35P23.certificate)))) (joinEvery (joinEvery (single (f:=atom 5 23) OMA.EightAt5E36P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E37P23.certificate)) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E38P23.certificate) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E39P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E40P23.certificate))))))) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery (single (f:=atom 5 23) OMA.EightAt5E41P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E42P23.certificate)) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E43P23.certificate) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E44P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E45P23.certificate)))) (joinEvery (joinEvery (single (f:=atom 5 23) OMA.EightAt5E46P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E47P23.certificate)) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E48P23.certificate) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E49P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E50P23.certificate))))) (joinEvery (joinEvery (joinEvery (single (f:=atom 5 23) OMA.EightAt5E51P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E52P23.certificate)) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E53P23.certificate) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E54P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E55P23.certificate)))) (joinEvery (joinEvery (single (f:=atom 5 23) OMA.EightAt5E56P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E57P23.certificate)) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E58P23.certificate) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E59P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E60P23.certificate)))))) (joinEvery (joinEvery (joinEvery (joinEvery (single (f:=atom 5 23) OMA.EightAt5E61P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E62P23.certificate)) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E63P23.certificate) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E64P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E65P23.certificate)))) (joinEvery (joinEvery (single (f:=atom 5 23) OMA.EightAt5E66P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E67P23.certificate)) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E68P23.certificate) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E69P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E70P23.certificate))))) (joinEvery (joinEvery (joinEvery (single (f:=atom 5 23) OMA.EightAt5E71P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E72P23.certificate)) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E73P23.certificate) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E74P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E75P23.certificate)))) (joinEvery (joinEvery (single (f:=atom 5 23) OMA.EightAt5E76P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E77P23.certificate)) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E78P23.certificate) (joinEvery (single (f:=atom 5 23) OMA.EightAt5E79P23.certificate) (single (f:=atom 5 23) OMA.EightAt5E80P23.certificate))))))))
end OMA.EightShort5To80P23
