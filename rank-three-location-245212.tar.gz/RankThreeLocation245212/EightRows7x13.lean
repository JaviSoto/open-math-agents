import RankThreeEightFixed245212
/-! Kernel certificates for one ordered pair of odd bases at dyadic factor eight. -/
namespace OMA.EightRows7x13
open OMA.RankThreeEightFixed245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
theorem row17 : tests 7 13 17=true := by decide +kernel
theorem row19 : tests 7 13 19=true := by decide +kernel
theorem row23 : tests 7 13 23=true := by decide +kernel
theorem row29 : tests 7 13 29=true := by decide +kernel
end OMA.EightRows7x13
