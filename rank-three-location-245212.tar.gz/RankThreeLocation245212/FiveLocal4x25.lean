import RankThreeFiveResidue245212
/-! Middle-prime limit from local obstructions to short divisor counts. -/
namespace OMA.FiveLocal4x25
open OMA.RankThreeFiveResidue245212 OMA.CofactorEulerPair245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem n5 : every 5 5 (fun n=>!(survives 1237448304891586303719 11548399925231933586 1239776611328125000000 n))=true := by decide +kernel
private theorem n6 : every 6 6 (fun n=>!(survives 1237448304891586303719 11548399925231933586 1239776611328125000000 n))=true := by decide +kernel
private theorem n7 : every 7 7 (fun n=>!(survives 1237448304891586303719 11548399925231933586 1239776611328125000000 n))=true := by decide +kernel
private theorem n8 : every 8 8 (fun n=>!(survives 1237448304891586303719 11548399925231933586 1239776611328125000000 n))=true := by decide +kernel
private theorem n9 : every 9 9 (fun n=>!(survives 1237448304891586303719 11548399925231933586 1239776611328125000000 n))=true := by decide +kernel
private theorem n10 : every 10 10 (fun n=>!(survives 1237448304891586303719 11548399925231933586 1239776611328125000000 n))=true := by decide +kernel
private theorem n11 : every 11 11 (fun n=>!(survives 1237448304891586303719 11548399925231933586 1239776611328125000000 n))=true := by decide +kernel
private theorem n12 : every 12 12 (fun n=>!(survives 1237448304891586303719 11548399925231933586 1239776611328125000000 n))=true := by decide +kernel
private theorem n13 : every 13 13 (fun n=>!(survives 1237448304891586303719 11548399925231933586 1239776611328125000000 n))=true := by decide +kernel
private theorem n14 : every 14 14 (fun n=>!(survives 1237448304891586303719 11548399925231933586 1239776611328125000000 n))=true := by decide +kernel
private theorem n15 : every 15 15 (fun n=>!(survives 1237448304891586303719 11548399925231933586 1239776611328125000000 n))=true := by decide +kernel
private theorem n16 : every 16 16 (fun n=>!(survives 1237448304891586303719 11548399925231933586 1239776611328125000000 n))=true := by decide +kernel
private theorem n17 : every 17 17 (fun n=>!(survives 1237448304891586303719 11548399925231933586 1239776611328125000000 n))=true := by decide +kernel
private theorem n18 : every 18 18 (fun n=>!(survives 1237448304891586303719 11548399925231933586 1239776611328125000000 n))=true := by decide +kernel
private theorem n19 : every 19 19 (fun n=>!(survives 1237448304891586303719 11548399925231933586 1239776611328125000000 n))=true := by decide +kernel
private theorem n20 : every 20 20 (fun n=>!(survives 1237448304891586303719 11548399925231933586 1239776611328125000000 n))=true := by decide +kernel
private theorem n21 : every 21 21 (fun n=>!(survives 1237448304891586303719 11548399925231933586 1239776611328125000000 n))=true := by decide +kernel
private theorem n22 : every 22 22 (fun n=>!(survives 1237448304891586303719 11548399925231933586 1239776611328125000000 n))=true := by decide +kernel
private theorem n23 : every 23 23 (fun n=>!(survives 1237448304891586303719 11548399925231933586 1239776611328125000000 n))=true := by decide +kernel
private theorem n24 : every 24 24 (fun n=>!(survives 1237448304891586303719 11548399925231933586 1239776611328125000000 n))=true := by decide +kernel
private theorem n25 : every 25 25 (fun n=>!(survives 1237448304891586303719 11548399925231933586 1239776611328125000000 n))=true := by decide +kernel
private theorem n26 : every 26 26 (fun n=>!(survives 1237448304891586303719 11548399925231933586 1239776611328125000000 n))=true := by decide +kernel
theorem clear : every 5 26 (fun n=>!(survives 1237448304891586303719 11548399925231933586 1239776611328125000000 n))=true := (joinEvery (joinEvery (joinEvery (joinEvery n5 n6) (joinEvery n7 (joinEvery n8 n9))) (joinEvery (joinEvery n10 (joinEvery n11 n12)) (joinEvery n13 (joinEvery n14 n15)))) (joinEvery (joinEvery (joinEvery n16 n17) (joinEvery n18 (joinEvery n19 n20))) (joinEvery (joinEvery n21 (joinEvery n22 n23)) (joinEvery n24 (joinEvery n25 n26)))))
end OMA.FiveLocal4x25
