import FiveQuick4x28S7
import FiveQuick4x28S151
import FiveQuick4x28S295
import FiveQuick4x28S439
import FiveQuick4x28S583
import FiveQuick4x28S727
import FiveQuick4x28S871
import FiveQuick4x28S1015
import FiveQuick4x28S1159
import FiveQuick4x28S1303
import FiveQuick4x28S1447
import FiveQuick4x28S1591
import FiveQuick4x28S1735
import FiveQuick4x28S1879
import FiveQuick4x28S2023
import FiveQuick4x28S2167
import FiveQuick4x28S2311
import FiveQuick4x28S2455
import FiveQuick4x28S2599
import FiveQuick4x28S2743
import FiveQuick4x28S2887
import FiveQuick4x28S3031
import FiveQuick4x28S3175
import FiveQuick4x28S3319
import FiveQuick4x28S3463
import FiveQuick4x28S3607
import FiveQuick4x28S3751
import FiveQuick4x28S3895
import FiveQuick4x28S4039
import FiveQuick4x28S4183
import FiveQuick4x28S4327
import FiveQuick4x28S4471
import FiveQuick4x28Far
import FiveFastNear245212
namespace OMA.FiveQuick4x28
open OMA.CofactorEulerPair245212 OMA.FiveFastNear245212
open OMA.RankThreeFiveTail245212 (cofactor wt sg ta)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 0
theorem original {p q b c : ℕ} (pp : p.Prime) (qp : q.Prime) (gt : 5<p) (pq : p<q) (bp : 0<b) (cp : 0<c) :
    OeisA245212.a (2^4*5^28*p^b*q^c)≠(ArithmeticFunction.sigma 1 (2^4*5^28*p^b*q^c):ℤ) :=
  OMA.RankThreeFiveShort245212.final (lo:=4569) pp qp gt pq bp cp (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery span7 span151) (joinEvery span295 span439)) (joinEvery (joinEvery span583 span727) (joinEvery span871 span1015))) (joinEvery (joinEvery (joinEvery span1159 span1303) (joinEvery span1447 span1591)) (joinEvery (joinEvery span1735 span1879) (joinEvery span2023 span2167)))) (joinEvery (joinEvery (joinEvery (joinEvery span2311 span2455) (joinEvery span2599 span2743)) (joinEvery (joinEvery span2887 span3031) (joinEvery span3175 span3319))) (joinEvery (joinEvery (joinEvery span3463 span3607) (joinEvery span3751 span3895)) (joinEvery (joinEvery span4039 span4183) (joinEvery span4327 span4471))))) (by decide +kernel) OMA.FiveFar4x28.scan
#print axioms original
end OMA.FiveQuick4x28
