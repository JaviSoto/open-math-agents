import FiveQuick4x30S7
import FiveQuick4x30S263
import FiveQuick4x30S519
import FiveQuick4x30S775
import FiveQuick4x30S1031
import FiveQuick4x30S1287
import FiveQuick4x30S1543
import FiveQuick4x30S1799
import FiveQuick4x30S2055
import FiveQuick4x30S2311
import FiveQuick4x30S2567
import FiveQuick4x30S2823
import FiveQuick4x30S3079
import FiveQuick4x30S3335
import FiveQuick4x30S3591
import FiveQuick4x30S3847
import FiveQuick4x30S4103
import FiveQuick4x30S4359
import FiveQuick4x30S4615
import FiveQuick4x30S4871
import FiveQuick4x30S5127
import FiveQuick4x30S5383
import FiveQuick4x30S5639
import FiveQuick4x30S5895
import FiveQuick4x30S6151
import FiveQuick4x30S6407
import FiveQuick4x30S6663
import FiveQuick4x30S6919
import FiveQuick4x30S7175
import FiveQuick4x30S7431
import FiveQuick4x30S7687
import FiveQuick4x30S7943
import FiveQuick4x30S8199
import FiveQuick4x30S8455
import FiveQuick4x30S8711
import FiveQuick4x30S8967
import FiveQuick4x30S9223
import FiveQuick4x30S9479
import FiveQuick4x30S9735
import FiveQuick4x30S9991
import FiveQuick4x30S10247
import FiveQuick4x30S10503
import FiveQuick4x30S10759
import FiveQuick4x30S11015
import FiveQuick4x30S11271
import FiveQuick4x30S11527
import FiveQuick4x30S11783
import FiveQuick4x30S12039
import FiveQuick4x30S12295
import FiveQuick4x30S12551
import FiveFar4x30
import FiveFastNear245212
namespace OMA.FiveQuick4x30
open OMA.CofactorEulerPair245212 OMA.FiveFastNear245212
open OMA.RankThreeFiveTail245212 (cofactor wt sg ta)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 0
theorem original {p q b c : ℕ} (pp : p.Prime) (qp : q.Prime) (gt : 5<p) (pq : p<q) (bp : 0<b) (cp : 0<c) :
    OeisA245212.a (2^4*5^30*p^b*q^c)≠(ArithmeticFunction.sigma 1 (2^4*5^30*p^b*q^c):ℤ) :=
  OMA.RankThreeFiveShort245212.final (lo:=12698) pp qp gt pq bp cp (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery span7 (joinEvery span263 span519)) (joinEvery span775 (joinEvery span1031 span1287))) (joinEvery (joinEvery span1543 (joinEvery span1799 span2055)) (joinEvery span2311 (joinEvery span2567 span2823)))) (joinEvery (joinEvery (joinEvery span3079 (joinEvery span3335 span3591)) (joinEvery span3847 (joinEvery span4103 span4359))) (joinEvery (joinEvery span4615 (joinEvery span4871 span5127)) (joinEvery (joinEvery span5383 span5639) (joinEvery span5895 span6151))))) (joinEvery (joinEvery (joinEvery (joinEvery span6407 (joinEvery span6663 span6919)) (joinEvery span7175 (joinEvery span7431 span7687))) (joinEvery (joinEvery span7943 (joinEvery span8199 span8455)) (joinEvery span8711 (joinEvery span8967 span9223)))) (joinEvery (joinEvery (joinEvery span9479 (joinEvery span9735 span9991)) (joinEvery span10247 (joinEvery span10503 span10759))) (joinEvery (joinEvery span11015 (joinEvery span11271 span11527)) (joinEvery (joinEvery span11783 span12039) (joinEvery span12295 span12551)))))) (by decide +kernel) OMA.FiveFar4x30.scan
#print axioms original
end OMA.FiveQuick4x30
