import RankThreeEightMoving245212
/-! Complete enumeration of both short prefixes for one moving-prime family. -/
/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E1P13
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
theorem certificate : atom 5 13 1=true := by
  apply row_low (h:=40) (A:=539) (S:=90) (T:=320) (R:=14) (Q:=11) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 11≤14+128)]
  exact (by decide +kernel)
end OMA.EightAt5E1P13

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E2P13
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b14 : every 14 20 (quick 200 4214 465 2400 13)=true := by decide +kernel
theorem certificate : atom 5 13 2=true := by
  apply row_low (h:=200) (A:=4214) (S:=465) (T:=2400) (R:=14) (Q:=20) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 20≤14+128)]
  exact b14
end OMA.EightAt5E2P13

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E3P13
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b14 : every 14 29 (quick 1000 28714 2340 16000 13)=true := by decide +kernel
private theorem b30 : every 30 35 (quick 1000 28714 2340 16000 13)=true := by decide +kernel
theorem certificate : atom 5 13 3=true := by
  apply row_low (h:=1000) (A:=28714) (S:=2340) (T:=16000) (R:=14) (Q:=35) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 35≤14+128)]
  exact (joinEvery b14 b30)
end OMA.EightAt5E3P13

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E4P13
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b14 : every 14 29 (quick 5000 181839 11715 100000 13)=true := by decide +kernel
private theorem b30 : every 30 45 (quick 5000 181839 11715 100000 13)=true := by decide +kernel
private theorem b46 : every 46 61 (quick 5000 181839 11715 100000 13)=true := by decide +kernel
private theorem b62 : every 62 66 (quick 5000 181839 11715 100000 13)=true := by decide +kernel
theorem certificate : atom 5 13 4=true := by
  apply row_low (h:=5000) (A:=181839) (S:=11715) (T:=100000) (R:=14) (Q:=66) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_pos (by decide : 66≤14+128)]
  exact (joinEvery (joinEvery b14 b30) (joinEvery b46 b62))
end OMA.EightAt5E4P13

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E5P13
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 1100589 58590 600000 13 14)=true := by decide +kernel
private theorem b17 : every 17 32 (line 1100589 58590 600000 13 14)=true := by decide +kernel
private theorem b33 : every 33 44 (line 1100589 58590 600000 13 14)=true := by decide +kernel
theorem certificate : atom 5 13 5=true := by
  apply row_low (h:=25000) (A:=1100589) (S:=58590) (T:=600000) (R:=14) (Q:=155) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬155≤14+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 25000 1100589 58590 13 155=44 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery b1 (joinEvery b17 b33))⟩
end OMA.EightAt5E5P13

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E6P13
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 6459964 292965 3500000 13 14)=true := by decide +kernel
private theorem b17 : every 17 32 (line 6459964 292965 3500000 13 14)=true := by decide +kernel
private theorem b33 : every 33 48 (line 6459964 292965 3500000 13 14)=true := by decide +kernel
private theorem b49 : every 49 64 (line 6459964 292965 3500000 13 14)=true := by decide +kernel
private theorem b65 : every 65 69 (line 6459964 292965 3500000 13 14)=true := by decide +kernel
theorem certificate : atom 5 13 6=true := by
  apply row_low (h:=125000) (A:=6459964) (S:=292965) (T:=3500000) (R:=14) (Q:=4103) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬4103≤14+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 125000 6459964 292965 13 4103=69 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery b1 b17) (joinEvery b33 (joinEvery b49 b65)))⟩
end OMA.EightAt5E6P13

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E7P13
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 37084964 1464840 20000000 13 14)=true := by decide +kernel
private theorem b17 : every 17 32 (line 37084964 1464840 20000000 13 14)=true := by decide +kernel
private theorem b33 : every 33 35 (line 37084964 1464840 20000000 13 14)=true := by decide +kernel
theorem certificate : atom 5 13 7=true := by
  apply row_high (h:=625000) (A:=37084964) (S:=1464840) (T:=20000000) (R:=14) (B:=35) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery b1 (joinEvery b17 b33))
end OMA.EightAt5E7P13

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt5E8P13
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 209350589 7324215 112500000 13 14)=true := by decide +kernel
private theorem b17 : every 17 19 (line 209350589 7324215 112500000 13 14)=true := by decide +kernel
theorem certificate : atom 5 13 8=true := by
  apply row_high (h:=3125000) (A:=209350589) (S:=7324215) (T:=112500000) (R:=14) (B:=19) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery b1 b17)
end OMA.EightAt5E8P13

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt13E1P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 1323 210 832 5 14)=true := by decide +kernel
private theorem b17 : every 17 32 (line 1323 210 832 5 14)=true := by decide +kernel
private theorem b33 : every 33 48 (line 1323 210 832 5 14)=true := by decide +kernel
private theorem b49 : every 49 64 (line 1323 210 832 5 14)=true := by decide +kernel
private theorem b65 : every 65 80 (line 1323 210 832 5 14)=true := by decide +kernel
private theorem b81 : every 81 92 (line 1323 210 832 5 14)=true := by decide +kernel
theorem certificate : atom 13 5 1=true := by
  apply row_low (h:=104) (A:=1323) (S:=210) (T:=832) (R:=14) (Q:=162) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw [low,if_neg (by decide : ¬162≤14+128),Bool.and_eq_true]
  rw [show OMA.RankThreeFourSmallNear245212.nearCap 104 1323 210 5 162=92 by decide +kernel]
  exact ⟨by decide +kernel,(joinEvery (joinEvery b1 (joinEvery b17 b33)) (joinEvery b49 (joinEvery b65 b81)))⟩
end OMA.EightAt13E1P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt13E2P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 26166 2745 16224 5 14)=true := by decide +kernel
private theorem b17 : every 17 32 (line 26166 2745 16224 5 14)=true := by decide +kernel
private theorem b33 : every 33 48 (line 26166 2745 16224 5 14)=true := by decide +kernel
private theorem b49 : every 49 50 (line 26166 2745 16224 5 14)=true := by decide +kernel
theorem certificate : atom 13 5 2=true := by
  apply row_high (h:=1352) (A:=26166) (S:=2745) (T:=16224) (R:=14) (B:=50) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery (joinEvery b1 b17) (joinEvery b33 b49))
end OMA.EightAt13E2P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt13E3P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 456778 35700 281216 5 14)=true := by decide +kernel
private theorem b17 : every 17 26 (line 456778 35700 281216 5 14)=true := by decide +kernel
theorem certificate : atom 13 5 3=true := by
  apply row_high (h:=17576) (A:=456778) (S:=35700) (T:=281216) (R:=14) (B:=26) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery b1 b17)
end OMA.EightAt13E3P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt13E4P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 7454223 464115 4569760 5 14)=true := by decide +kernel
private theorem b17 : every 17 20 (line 7454223 464115 4569760 5 14)=true := by decide +kernel
theorem certificate : atom 13 5 4=true := by
  apply row_high (h:=228488) (A:=7454223) (S:=464115) (T:=4569760) (R:=14) (B:=20) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery b1 b17)
end OMA.EightAt13E4P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt13E5P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 116614365 6033510 71288256 5 14)=true := by decide +kernel
private theorem b17 : every 17 18 (line 116614365 6033510 71288256 5 14)=true := by decide +kernel
theorem certificate : atom 13 5 5=true := by
  apply row_high (h:=2970344) (A:=116614365) (S:=6033510) (T:=71288256) (R:=14) (B:=18) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact (joinEvery b1 b17)
end OMA.EightAt13E5P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt13E6P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 16 (line 1772209852 78435645 1081205216 5 14)=true := by decide +kernel
theorem certificate : atom 13 5 6=true := by
  apply row_high (h:=38614472) (A:=1772209852) (S:=78435645) (T:=1081205216) (R:=14) (B:=16) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact b1
end OMA.EightAt13E6P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt13E7P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 15 (line 26369628516 1019663400 16063620352 5 14)=true := by decide +kernel
theorem certificate : atom 13 5 7=true := by
  apply row_high (h:=501988136) (A:=26369628516) (S:=1019663400) (T:=16063620352) (R:=14) (B:=15) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact b1
end OMA.EightAt13E7P5

/- One exact initial prime power, with the last prime unrestricted. -/
namespace OMA.EightAt13E8P5
open OMA.RankThreeEightMoving245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallFast245212 (quick)
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem b1 : every 1 15 (line 386106876477 13255624215 234930447648 5 14)=true := by decide +kernel
theorem certificate : atom 13 5 8=true := by
  apply row_high (h:=6525845768) (A:=386106876477) (S:=13255624215) (T:=234930447648) (R:=14) (B:=15) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact b1
end OMA.EightAt13E8P5

namespace OMA.EightMoving5x13
open OMA.CofactorEulerPair245212 OMA.RankThreeEightMoving245212 OMA.Smooth245212
open OMA.RankThreeMiddle245212 (joinEvery)
open scoped ArithmeticFunction.sigma
private theorem range5 : every 1 8 (atom 5 13)=true := (joinEvery (joinEvery (joinEvery (single (f:=atom 5 13) OMA.EightAt5E1P13.certificate) (single (f:=atom 5 13) OMA.EightAt5E2P13.certificate)) (joinEvery (single (f:=atom 5 13) OMA.EightAt5E3P13.certificate) (single (f:=atom 5 13) OMA.EightAt5E4P13.certificate))) (joinEvery (joinEvery (single (f:=atom 5 13) OMA.EightAt5E5P13.certificate) (single (f:=atom 5 13) OMA.EightAt5E6P13.certificate)) (joinEvery (single (f:=atom 5 13) OMA.EightAt5E7P13.certificate) (single (f:=atom 5 13) OMA.EightAt5E8P13.certificate))))
private theorem range13 : every 1 8 (atom 13 5)=true := (joinEvery (joinEvery (joinEvery (single (f:=atom 13 5) OMA.EightAt13E1P5.certificate) (single (f:=atom 13 5) OMA.EightAt13E2P5.certificate)) (joinEvery (single (f:=atom 13 5) OMA.EightAt13E3P5.certificate) (single (f:=atom 13 5) OMA.EightAt13E4P5.certificate))) (joinEvery (joinEvery (single (f:=atom 13 5) OMA.EightAt13E5P5.certificate) (single (f:=atom 13 5) OMA.EightAt13E6P5.certificate)) (joinEvery (single (f:=atom 13 5) OMA.EightAt13E7P5.certificate) (single (f:=atom 13 5) OMA.EightAt13E8P5.certificate))))
theorem exclude {r a b c : ℕ} (pr : r.Prime) (large : 13<r) (ap : 0<a) (bp : 0<b) (cp : 0<c) :
    OeisA245212.a (8*5^a*13^b*r^c)≠(σ 1 (8*5^a*13^b*r^c):ℤ) :=
  close (l:=9) (u:=9) (by decide) (by decide) pr (by decide) (by decide) large ap bp cp (by decide +kernel) range5 range13
#print axioms exclude
end OMA.EightMoving5x13
