import CofactorOddBudget245212

/-! Every resonant divisor count has a prime factor three modulo four.
The condition excludes infinitely many counts at once, at arbitrary rank. -/
namespace OMA.CofactorCountResidue245212
open Nat ArithmeticFunction OMA.Smooth245212 OMA.WeightVal245212
open Finset hiding val
open OMA.CofactorEulerSeparation245212
open scoped ArithmeticFunction.sigma
open private OMA.CofactorValuationTree245212.wpos OMA.CofactorValuationTree245212.vmul
  OMA.CofactorValuationTree245212.all_odd from CofactorValuationTree245212

private theorem bad_prime {t : ℕ} (bad : t%4=3) : ∃ p : ℕ,p.Prime ∧ p∣t ∧ p%4=3 := by
  by_contra! no
  have odd : Odd t:=by rw [Nat.odd_iff];omega
  have eq : t ≡ 1 [MOD 4]:=by
    rw [←Nat.prod_primeFactorsList odd.pos.ne']
    have product_one (l : List ℕ) (ones : ∀q∈l,q ≡ 1 [MOD 4]) : l.prod ≡ 1 [MOD 4] := by
      induction l with
      | nil=>rfl
      | cons a rest ih=>simpa only [List.prod_cons,one_mul] using
          (ones a (.head _)).mul (ih (fun q mq=>ones q (.tail _ mq)))
    apply product_one
    intro p mem
    have pp:=Nat.prime_of_mem_primeFactorsList mem
    have dvd:=Nat.dvd_of_mem_primeFactorsList mem
    have op:=Nat.coprime_two_left.mp ((Nat.coprime_two_left.mpr odd).of_dvd_right dvd)
    have neg:=no p pp dvd
    change p%4=1
    rw [Nat.odd_iff] at op
    omega
  change t%4=1 at eq
  omega

private theorem small_weight {n : ℕ} (pn : 0<n)
    (miss : ∀p : ℕ,p.Prime → p∣σ 0 n → p%4≠3) : val (W n)≤val (σ 0 n) := by
  induction n using Nat.recOnPrimeCoprime with
  | zero=>omega
  | prime_pow p e pr=>
    rw [sigma_zero_apply_prime_pow pr] at miss ⊢
    by_cases two : p=2
    · rw [two,val_odd (OMA.DyadicPower245212.dyadic_odd e)];exact Nat.zero_le _
    have w:=weight_local pr (pr.odd_of_ne_two two) e
    have v : val (e+2)≤1:=by
      by_contra! large
      have dv : 4∣e+2:=(prime_two.pow_dvd_iff_le_factorization (by omega : e+2≠0)).mpr large
      obtain ⟨q,pq,dq,bad⟩:=bad_prime (t:=e+1) (by omega)
      exact miss q pq dq bad
    omega
  | coprime a b ha hb cp ia ib=>
    have ap : 0<a:=by omega
    have bp : 0<b:=by omega
    have tau : σ 0 (a*b)=σ 0 a*σ 0 b:=isMultiplicative_sigma.map_mul_of_coprime cp
    rw [tau] at miss ⊢
    rw [w_mult.map_mul_of_coprime cp,OMA.CofactorValuationTree245212.vmul
      (OMA.CofactorValuationTree245212.wpos ap) (OMA.CofactorValuationTree245212.wpos bp),
      OMA.CofactorValuationTree245212.vmul (sigma_pos 0 a ap.ne') (sigma_pos 0 b bp.ne')]
    exact Nat.add_le_add (ia ap (fun q pq dq=>miss q pq (dvd_mul_of_dvd_left dq _)))
      (ib bp (fun q pq dq=>miss q pq (dvd_mul_of_dvd_right dq _)))

theorem necessary {h : ℕ} (pos : 0<h) {T : Finset ℕ}
    (pr : ∀q∈T,q.Prime) (odd : ∀q∈T,Odd q)
    (hit : W h*num T=2*(h*σ 0 h)*den T) :
    ∃ p : ℕ,p.Prime ∧ p∣σ 0 h ∧ p%4=3 := by
  by_contra! no
  have bound:=small_weight pos no
  have op:=OMA.CofactorValuationTree245212.all_odd odd
  have de : 0<den T:=Finset.prod_pos fun q mq=>Nat.sub_pos_of_lt (pr q mq).one_lt
  have dp:=sigma_pos 0 h pos.ne'
  have v:=congrArg val hit
  rw [OMA.CofactorValuationTree245212.vmul (OMA.CofactorValuationTree245212.wpos pos) op.pos,val_odd op,
    OMA.CofactorValuationTree245212.vmul (mul_pos (by decide : 0<2) (mul_pos pos dp)) de,
    OMA.CofactorValuationTree245212.vmul (by decide : 0<2) (mul_pos pos dp),
    OMA.CofactorValuationTree245212.vmul pos dp] at v
  have two : val 2=1:=Nat.Prime.factorization_self prime_two
  omega

#print axioms necessary
end OMA.CofactorCountResidue245212
