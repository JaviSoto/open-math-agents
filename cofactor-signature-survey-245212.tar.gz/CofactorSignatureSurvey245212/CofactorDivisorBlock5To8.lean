import CofactorDivisorCertificate245212

/-! Kernel check of divisor counts 5 through 8. -/
set_option maxRecDepth 65536
set_option maxHeartbeats 0
namespace OMA.CofactorDivisorCertificate245212
theorem block5to8 : interval 5 4=true := by decide +kernel
end OMA.CofactorDivisorCertificate245212
