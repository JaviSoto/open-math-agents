import MersenneOrderSupport245212

/-! A reduced denominator reconstructs the numerator and index of a
dyadic residual fraction. Its recognition test only factors numbers
formed from that denominator and the recovered index. -/
namespace OMA.MersenneFractionInverse245212
open Nat Finset OMA.MersenneDenominator245212 OMA.MersenneOrderSupport245212

noncomputable def idx (z : ℕ) := z.primeFactors.lcm ord
def part (t z : ℕ) := (t.divisors.filter (fun d=>d.Coprime z)).sup id

theorem coprimePart {t : ℕ} (ht : 0<t) :
    part t (Q t)=t/((2^t-1).gcd t) := by
  let D:=2^t-1
  let G:=D.gcd t
  let P:=t/G
  have dp : 0<D:=Nat.sub_pos_of_lt (Nat.one_lt_two_pow ht.ne')
  have gp : 0<G:=Nat.gcd_pos_of_pos_left _ dp
  have prod : P*G=t:=Nat.div_mul_cancel (Nat.gcd_dvd_right _ _)
  have pos : 0<P:=Nat.div_pos (Nat.le_of_dvd ht (Nat.gcd_dvd_right _ _)) gp
  have cp : P.Coprime (Q t):=(Nat.coprime_div_gcd_div_gcd gp).symm
  change _=P
  apply le_antisymm
  · apply Finset.sup_le
    intro d mem
    obtain ⟨dv,free⟩:=Finset.mem_filter.mp mem
    have co : d.Coprime G:=by
      by_contra h
      obtain ⟨p,pr,dd,dg⟩:=Nat.Prime.not_coprime_iff_dvd.mp h
      have md : p∈D.primeFactors:=Nat.mem_primeFactors.mpr
        ⟨pr,dg.trans (Nat.gcd_dvd_left _ _),dp.ne'⟩
      change p∈(2^t-1).primeFactors at md
      rw [←q_primes ht] at md
      exact (pr.coprime_iff_not_dvd.mp (free.of_dvd_left dd)) (Nat.dvd_of_mem_primeFactors md)
    have dvd : d∣P*G:=prod.symm ▸ (Nat.dvd_of_mem_divisors dv)
    exact Nat.le_of_dvd pos (co.dvd_of_dvd_mul_left (by simpa only [mul_comm G P] using dvd))
  · exact Finset.le_sup (f:=id) (Finset.mem_filter.mpr
      ⟨Nat.mem_divisors.mpr ⟨⟨G,prod.symm⟩,ht.ne'⟩,cp⟩)

theorem recover {t : ℕ} (ht : 0<t) :
    idx (Q t)=t ∧ part (idx (Q t)) (Q t)=t/((2^t-1).gcd t) := by
  have ix : idx (Q t)=t:=index_of_pos ht
  exact ⟨ix,by rw [ix];exact coprimePart ht⟩

#print axioms recover
end OMA.MersenneFractionInverse245212
