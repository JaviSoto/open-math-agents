import CofactorDivisorBlock1To4
import CofactorDivisorBlock5To8
import CofactorDivisorBlock9To12
import CofactorDivisorBlock13To16
import CofactorDivisorBlock17To20
import CofactorDivisorBlock21To24
import CofactorDivisorBlock25To28
import CofactorDivisorBlock29To32
import CofactorDivisorBlock33To36
import CofactorDivisorBlock37To40
import CofactorDivisorBlock41To44

/-! Combine checked counts, independently of the cofactor's size. -/
namespace OMA.CofactorDivisorCertificate245212
open Nat Finset ArithmeticFunction OMA.Smooth245212 OMA.CofactorEulerSeparation245212
open scoped ArithmeticFunction.sigma

theorem tested_through_44 {D : ℕ} (hp : 0 < D) (le : D≤44) : test D=true := by
  by_cases a1 : D≤4
  · exact in_interval block1to4 (by omega) (by omega)
  by_cases a5 : D≤8
  · exact in_interval block5to8 (by omega) (by omega)
  by_cases a9 : D≤12
  · exact in_interval block9to12 (by omega) (by omega)
  by_cases a13 : D≤16
  · exact in_interval block13to16 (by omega) (by omega)
  by_cases a17 : D≤20
  · exact in_interval block17to20 (by omega) (by omega)
  by_cases a21 : D≤24
  · exact in_interval block21to24 (by omega) (by omega)
  by_cases a25 : D≤28
  · exact in_interval block25to28 (by omega) (by omega)
  by_cases a29 : D≤32
  · exact in_interval block29to32 (by omega) (by omega)
  by_cases a33 : D≤36
  · exact in_interval block33to36 (by omega) (by omega)
  by_cases a37 : D≤40
  · exact in_interval block37to40 (by omega) (by omega)
  exact in_interval block41to44 (by omega) (by omega)

theorem exclude_through_44 {h : ℕ} {T : Finset ℕ} (pos : 0 < h) (small : σ 0 h≤44)
    (non : T.Nonempty) (pr : ∀q∈T,q.Prime) (odd : ∀q∈T,Odd q) (fresh : ∀q∈T,h.Coprime q) :
    W h*num T≠2*(h*σ 0 h)*den T :=
  no_resonance pos non pr odd fresh (tested_through_44 (sigma_pos 0 h pos.ne') small)

#print axioms exclude_through_44
end OMA.CofactorDivisorCertificate245212
