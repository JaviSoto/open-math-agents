import CofactorDivisorCertificate245212

/-! Kernel check of divisor counts 25 through 28. -/
set_option maxRecDepth 65536
set_option maxHeartbeats 0
namespace OMA.CofactorDivisorCertificate245212
theorem block25to28 : interval 25 4=true := by decide +kernel
end OMA.CofactorDivisorCertificate245212
