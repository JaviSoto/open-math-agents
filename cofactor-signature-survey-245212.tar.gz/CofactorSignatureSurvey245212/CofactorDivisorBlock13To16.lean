import CofactorDivisorCertificate245212

/-! Kernel check of divisor counts 13 through 16. -/
set_option maxRecDepth 65536
set_option maxHeartbeats 0
namespace OMA.CofactorDivisorCertificate245212
theorem block13to16 : interval 13 4=true := by decide +kernel
end OMA.CofactorDivisorCertificate245212
