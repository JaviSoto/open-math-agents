import CofactorDivisorCertificate245212

/-! Kernel check of divisor counts 17 through 20. -/
set_option maxRecDepth 65536
set_option maxHeartbeats 0
namespace OMA.CofactorDivisorCertificate245212
theorem block17to20 : interval 17 4=true := by decide +kernel
end OMA.CofactorDivisorCertificate245212
