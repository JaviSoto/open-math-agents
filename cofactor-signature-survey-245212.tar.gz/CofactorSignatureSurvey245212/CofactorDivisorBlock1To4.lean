import CofactorDivisorCertificate245212

/-! Kernel check of divisor counts 1 through 4. -/
set_option maxRecDepth 65536
set_option maxHeartbeats 0
namespace OMA.CofactorDivisorCertificate245212
theorem block1to4 : interval 1 4=true := by decide +kernel
end OMA.CofactorDivisorCertificate245212
