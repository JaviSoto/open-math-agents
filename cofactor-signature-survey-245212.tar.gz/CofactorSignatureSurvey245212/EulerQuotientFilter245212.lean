import EulerSupportUnique245212
import WeightedRatioSearch245212

/-! Remove a forced Euler prime from the reduced quotient. A finite fuel
limit merely weakens the filter; it cannot discard any actual support. -/
namespace OMA.EulerQuotientFilter245212
open Nat Finset OMA.CofactorEulerSeparation245212

def possible : ℕ → ℕ → ℕ → Bool
  | 0,_,_=>true
  | f+1,A,B=>
    if A=B then true else if A<B then false else
    let g:=A.gcd B
    let a:=A/g
    let q:=a.minFac
    if q=2 then false else possible f (a/q*(q-1)) (B/g)

private theorem den_le_num (T : Finset ℕ) : den T≤num T :=
  prod_le_prod' (fun p (_:p∈T)=>Nat.sub_le p 1)

theorem accepts (f : ℕ) {A B : ℕ} (ap : 0 < A) (bp : 0 < B) {T : Finset ℕ}
    (pr : ∀p∈T,p.Prime) (odd : ∀p∈T,Odd p) (eqn : B*num T=A*den T) :
    possible f A B=true := by
  induction f generalizing A B T with
  | zero=>rfl
  | succ f ih=>
    by_cases same : A=B
    · simp [possible,same]
    have pos : 0 < num T:=prod_pos (fun p mp=>(pr p mp).pos)
    have ge : B≤A:=by apply Nat.le_of_mul_le_mul_right (c:=num T) _ pos;rw [eqn];exact Nat.mul_le_mul_left _ (den_le_num T)
    let g:=A.gcd B
    let a:=A/g
    let b:=B/g
    have gg : 0 < g:=Nat.gcd_pos_of_pos_right A bp
    have br : 0 < b:=Nat.div_pos (Nat.gcd_le_right _ bp) gg
    have aa : a*g=A:=Nat.div_mul_cancel (Nat.gcd_dvd_left A B)
    have bb : b*g=B:=Nat.div_mul_cancel (Nat.gcd_dvd_right A B)
    have big : 1 < a := by
      have s : b<a:=by
        apply Nat.lt_of_mul_lt_mul_right (a:=g)
        rw [aa,bb];omega
      omega
    let q:=a.minFac
    have qp : q.Prime:=Nat.minFac_prime (by omega)
    have gd : q∣a:=Nat.minFac_dvd _
    have red : b*num T=a*den T:=OMA.WeightedRatioSearch245212.reduced bp eqn
    have cop : a.Coprime b:=Nat.coprime_div_gcd_div_gcd gg
    have qb : ¬q∣b:=qp.coprime_iff_not_dvd.mp (cop.of_dvd_left gd)
    have qn : q∣num T:=(qp.dvd_mul.mp (red.symm ▸ dvd_mul_of_dvd_left gd (den T))).resolve_left qb
    obtain ⟨x,mx,dv⟩:=(qp.prime.dvd_finsetProd_iff (fun p=>p)).mp qn
    have mq : q∈T:=((prime_dvd_prime_iff_eq qp (pr x mx)).mp dv) ▸ mx
    have notTwo : q≠2 := by intro two;exact (odd q mq).not_two_dvd_nat (by rw [two])
    have id : b*num (T.erase q)=a/q*(q-1)*den (T.erase q) := by
      apply Nat.eq_of_mul_eq_mul_left qp.pos
      have n:=mul_prod_erase T (fun p=>p) mq
      have d:=mul_prod_erase T (fun p=>p-1) mq
      change q*num (T.erase q)=num T at n
      change (q-1)*den (T.erase q)=den T at d
      calc
        _ = b*num T := by rw [←n];ring
        _ = a*den T := red
        _ = (a/q*q)*((q-1)*den (T.erase q)) := by rw [Nat.div_mul_cancel gd,d]
        _ = _ := by ring
    have aPos : 0<a/q*(q-1) := Nat.mul_pos (Nat.div_pos (Nat.le_of_dvd (by omega) gd) qp.pos)
      (by have :=qp.one_lt;omega)
    have pass:=ih aPos br (fun p m=>pr p (mem_of_mem_erase m)) (fun p m=>odd p (mem_of_mem_erase m)) id
    simp only [possible,if_neg same,if_neg (not_lt.mpr ge)]
    change (if q=2 then false else possible f (a/q*(q-1)) b)=true
    rwa [if_neg notTwo]

#print axioms accepts
end OMA.EulerQuotientFilter245212
