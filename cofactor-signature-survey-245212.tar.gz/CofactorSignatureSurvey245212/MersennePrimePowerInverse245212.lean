import MersenneFractionInverse245212

/-! A denominator supported at just one prime must be an actual Mersenne
prime, to exponent one. There are no proper prime powers in this branch. -/
namespace OMA.MersennePrimePowerInverse245212
open Nat OMA.MersenneDenominator245212 OMA.MersenneOrderSupport245212

private theorem odd_quotient {p : ℕ} (odd : Odd p) (j : ℕ) :
    ∃ a : ℕ, p^(2*j+1)+1=(p+1)*(2*a+1) := by
  obtain ⟨u,hu⟩:=odd
  induction j with
  | zero=>exact ⟨0,by simp⟩
  | succ j ih=>
    obtain ⟨a,eq⟩:=ih
    let P:=p^(2*j+1)
    change P+1=(p+1)*(2*a+1) at eq
    refine ⟨a+u*P,?_⟩
    have pw : p^(2*(j+1)+1)=P*p^2:=by
      rw [show 2*(j+1)+1=2*j+1+2 by omega,pow_add]
    rw [pw]
    nlinarith only [eq,congrArg (fun z : ℕ=>P*(p+1)*z) hu]

private theorem one_exponent {t p e : ℕ} (ht : 2≤t) (pr : p.Prime) (ep : 0<e)
    (eqn : p^e=2^t-1) : e=1 := by
  have power : p^e+1=2^t:=by have:=Nat.two_pow_pos t;omega
  have four : 4∣2^t:=pow_dvd_pow 2 ht
  have po : Odd p:=pr.odd_of_ne_two (by
    intro two
    have even : 2∣p^e:=two ▸ dvd_pow_self _ ep.ne'
    omega)
  have oe : Odd e:=by
    by_contra h
    obtain ⟨j,ej⟩:=Nat.not_odd_iff_even.mp h
    obtain ⟨u,hu⟩:=po.pow (n:=j)
    rw [ej,pow_add,hu] at power
    obtain ⟨v,hv⟩:=four
    rw [show (2*u+1)*(2*u+1)=4*(u*u+u)+1 by ring,hv] at power
    omega
  obtain ⟨j,ej⟩:=oe
  obtain ⟨a,ha⟩:=odd_quotient po j
  rw [←ej,power] at ha
  have dv : 2*a+1∣2^t:=⟨p+1,by rw [ha,mul_comm]⟩
  obtain ⟨s,_,hs⟩:=(Nat.dvd_prime_pow Nat.prime_two).mp dv
  have zero : s=0:=by
    by_contra ne
    have d : 2∣2^s:=dvd_pow_self _ ne
    omega
  rw [zero,pow_zero] at hs
  rw [hs,mul_one] at ha
  have same : p^e=p^1:=by rw [pow_one];omega
  exact (Nat.pow_right_injective pr.one_lt) same

theorem classify {t : ℕ} (ht : 2≤t) (single : IsPrimePow (Q t)) :
    (2^t-1).Prime ∧ t.Prime ∧ Q t=2^t-1 := by
  have tp : 0<t:=by omega
  have cs := (isPrimePow_iff_card_primeFactors_eq_one.mp single)
  rw [q_primes tp] at cs
  obtain ⟨p,e,pr,ep,eqn⟩:=(isPrimePow_nat_iff _).mp (isPrimePow_iff_card_primeFactors_eq_one.mpr cs)
  have one:=one_exponent ht pr ep eqn
  rw [one,pow_one] at eqn
  have mp : (2^t-1).Prime:=eqn ▸ pr
  have ti : t.Prime:=Nat.Prime.of_mersenne mp
  have growing : ∀ j : ℕ, 2+j < 2^(2+j)-1:=by
    intro j
    induction j with
    | zero=>decide
    | succ j ih=>rw [Nat.add_succ,pow_succ];omega
  have lt : t<2^t-1:=by
    obtain ⟨j,rfl⟩:=Nat.exists_eq_add_of_le ht
    exact growing j
  have co : (2^t-1).Coprime t:=mp.coprime_iff_not_dvd.mpr
    (fun d=>not_le.mpr lt (Nat.le_of_dvd tp d))
  exact ⟨mp,ti,by simp [Q,co.gcd_eq_one]⟩

#print axioms classify
end OMA.MersennePrimePowerInverse245212
