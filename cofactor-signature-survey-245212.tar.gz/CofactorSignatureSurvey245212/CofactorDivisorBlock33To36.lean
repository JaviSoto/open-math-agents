import CofactorDivisorCertificate245212

/-! Kernel check of divisor counts 33 through 36. -/
set_option maxRecDepth 65536
set_option maxHeartbeats 0
namespace OMA.CofactorDivisorCertificate245212
theorem block33to36 : interval 33 4=true := by decide +kernel
end OMA.CofactorDivisorCertificate245212
