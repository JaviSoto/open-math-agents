import WeightedMultipleHeight245212
import RankThreeAnchor245212
import PrimePowerDiv245212

/-! Arithmetic constraints for a certificate that excludes a prescribed
weighted quotient at a fixed divisor count, without bounding the integer. -/
namespace OMA.WeightedRatioSearch245212
open Nat Finset ArithmeticFunction OMA.Smooth245212
open scoped ArithmeticFunction.sigma
open private OMA.WeightedMultipleHeight245212.strict_weight from WeightedMultipleHeight245212
open private OMA.CofactorHarmonic245212.divisor_bounds OMA.CofactorHarmonic245212.to_mass
  OMA.CofactorHarmonic245212.from_mass from CofactorHarmonic245212
open private OMA.RankThreeAnchor245212.weight_unit from RankThreeAnchor245212

theorem rank_bound {n : ℕ} (hn : 0 < n) : n.primeFactors.card ≤ Nat.log 2 (σ 0 n) := by
  apply Nat.le_log_of_pow_le (by decide)
  rw [sigma_zero_apply,Nat.card_divisors hn.ne']
  calc
    2^n.primeFactors.card = ∏ _p∈n.primeFactors,(2:ℕ) := by simp
    _ ≤ _ := by
      apply prod_le_prod'
      intro p mp
      have :=(prime_of_mem_primeFactors mp).factorization_pos_of_dvd hn.ne' (dvd_of_mem_primeFactors mp)
      omega

theorem least {A B n p : ℕ} (bp : 0 < B) (big : 1 < n)
    (eqn : B*W n=A*n) (small : ∀q∈n.primeFactors,p≤q) :
    B*σ 0 n<A ∧ p≤(Nat.log 2 (σ 0 n)*A)/(A-B*σ 0 n) := by
  have pos : 0 < n:=by omega
  have gap : B*σ 0 n<A := by
    apply Nat.lt_of_mul_lt_mul_right (a:=n)
    have :=Nat.mul_lt_mul_of_pos_left (OMA.WeightedMultipleHeight245212.strict_weight big) bp
    nlinarith only [this,eqn]
  have phi:=OMA.CofactorHarmonic245212.phi_sigma n
  have bound:=(OMA.CofactorHarmonic245212.divisor_bounds big).2.2
  have lim : A*n.totient≤B*σ 0 n*n := by
    apply Nat.le_of_mul_le_mul_right (c:=n) _ pos
    have a:=Nat.mul_le_mul_right n.totient (Nat.mul_le_mul_left B bound)
    have b:=Nat.mul_le_mul_left (B*σ 0 n) phi
    nlinarith only [a,b,congrArg (·*n.totient) eqn]
  have sub : (A-B*σ 0 n)*n≤A*(n-n.totient) := by
    nlinarith only [lim,congrArg (·*n) (Nat.sub_add_cancel gap.le),
      congrArg (A*·) (Nat.sub_add_cancel n.totient_le)]
  exact ⟨gap,(Nat.le_div_iff_mul_le (Nat.sub_pos_of_lt gap)).mpr
    ((OMA.CofactorHarmonic245212.from_mass small (OMA.CofactorHarmonic245212.to_mass pos sub)).trans
      (Nat.mul_le_mul_right A (rank_bound pos)))⟩

theorem reduced {A B w n : ℕ} (bp : 0 < B) (eqn : B*w=A*n) :
    (B/A.gcd B)*w=(A/A.gcd B)*n := by
  have gp:=Nat.gcd_pos_of_pos_right A bp
  apply Nat.eq_of_mul_eq_mul_left gp
  have l:=Nat.div_mul_cancel (Nat.gcd_dvd_right A B)
  have r:=Nat.div_mul_cancel (Nat.gcd_dvd_left A B)
  calc
    A.gcd B*(B/A.gcd B*w) = B*w := by rw [←mul_assoc,mul_comm (A.gcd B),l]
    _ = A*n := eqn
    _ = A.gcd B*(A/A.gcd B*n) := by rw [←mul_assoc,mul_comm (A.gcd B),r]

def mom (p e : ℕ) :=
  let power:=p^e
  let geom:=(p*power-1)/(p-1)
  (p*((e+1)*power)-geom)/(p-1)

theorem mom_eq {p : ℕ} (pr : p.Prime) (e : ℕ) : mom p e=W (p^e) := by
  have pp : 0 < p-1:=by have :=pr.one_lt;omega
  have geom : (p*p^e-1)/(p-1)=σ 1 (p^e) := by
    rw [←pow_succ',sigma_one_apply_prime_pow pr,←geom_sum_mul_of_one_le pr.pos (e+1),Nat.mul_div_cancel _ pp]
  have w:=OMA.PrimePowerDiv245212.weighted pr e
  dsimp [mom]
  rw [geom,←w,Nat.add_sub_cancel,Nat.mul_div_cancel_left _ pp]

theorem descend {n p A B : ℕ} (pos : 0 < n) (bp : 0 < B) (mp : p∈n.primeFactors)
    (eqn : B*W n=A*n) :
    let e:=n.factorization p
    let v:=ordCompl[p] n
    let a:=A*p^e
    let b:=B*mom p e
    0 < e ∧ (e+1)∣σ 0 n ∧ σ 0 v=σ 0 n/(e+1) ∧
      (b/a.gcd b)*W v=(a/a.gcd b)*v ∧ 0 < b/a.gcd b := by
  have pr:=prime_of_mem_primeFactors mp
  have epos:=pr.factorization_pos_of_dvd pos.ne' (dvd_of_mem_primeFactors mp)
  let e:=n.factorization p
  let v:=ordCompl[p] n
  have rep : p^e*v=n:=Nat.ordProj_mul_ordCompl_eq_self n p
  have cp:=(Nat.coprime_ordCompl pr pos.ne').pow_left e
  have D : σ 0 n=(e+1)*σ 0 v := by
    rw [←rep,isMultiplicative_sigma.map_mul_of_coprime cp,sigma_zero_apply_prime_pow pr]
  have Wn : W n=mom p e*W v := by rw [mom_eq pr,←rep,w_mult.map_mul_of_coprime cp]
  have newEq : B*mom p e*W v=A*p^e*v := by rw [mul_assoc,←Wn,mul_assoc,rep,eqn]
  have wp : 0 < mom p e := by
    rw [mom_eq pr,w_pow pr]
    exact sum_pos' (fun _ _=>Nat.zero_le _) ⟨0,mem_range.mpr (by omega),by simp⟩
  have bpos:=Nat.mul_pos bp wp
  exact ⟨epos,⟨_,D⟩,by rw [D,Nat.mul_div_cancel_left _ (Nat.succ_pos _)],
    reduced bpos newEq, Nat.div_pos (Nat.gcd_le_right _ bpos) (Nat.gcd_pos_of_pos_right _ bpos)⟩

/-- When one exponent accounts for the whole divisor count, the reduced
denominator determines the entire remaining integer. -/
theorem full_count {n A B : ℕ} (pos : 0 < n) (bp : 0 < B)
    (eqn : B*W n=A*n) {p : ℕ} (mem : p∈n.primeFactors) (same : n.factorization p+1=σ 0 n) :
    p^(σ 0 n-1)=B/A.gcd B ∧ p^(σ 0 n-1)=n := by
  let e:=n.factorization p
  let v:=ordCompl[p] n
  have pr:=prime_of_mem_primeFactors mem
  obtain ⟨_,_,card,_,_⟩:=descend pos bp mem eqn
  have cnt : σ 0 v=1:=by rw [card,←same];exact Nat.div_self (Nat.succ_pos _)
  have one:= (Nat.divisors_card_eq_one_iff v).mp (by simpa only [sigma_zero_apply] using cnt)
  have rep : p^e*v=n:=Nat.ordProj_mul_ordCompl_eq_self n p
  have val : p^(σ 0 n-1)=n:=by simpa only [←same,Nat.add_one_sub_one,one,mul_one] using rep
  have unit : n.Coprime (W n) := by
    rw [←val];exact (OMA.RankThreeAnchor245212.weight_unit pr _).pow_left _
  have red:=reduced bp eqn
  have gpos:=Nat.gcd_pos_of_pos_right A bp
  have cp:=Nat.coprime_div_gcd_div_gcd gpos
  have nf : n∣B/A.gcd B:=unit.dvd_of_dvd_mul_right (red.symm ▸ dvd_mul_left _ _)
  have fn : B/A.gcd B∣n:=cp.symm.dvd_of_dvd_mul_left (red ▸ dvd_mul_right _ _)
  exact ⟨val.trans (Nat.dvd_antisymm nf fn),val⟩

theorem prime_count {n A B : ℕ} (pos : 0 < n) (bp : 0 < B) (prime : (σ 0 n).Prime)
    (eqn : B*W n=A*n) {p : ℕ} (mem : p∈n.primeFactors) :
    p^(σ 0 n-1)=B/A.gcd B ∧ p^(σ 0 n-1)=n := by
  obtain ⟨ep,dvd,_,_,_⟩:=descend pos bp mem eqn
  exact full_count pos bp eqn mem (((Nat.dvd_prime prime).mp dvd).resolve_left
    (by change 0 < n.factorization p at ep;omega))

end OMA.WeightedRatioSearch245212
