import WeightVal245212
import WeightedRatioSearch245212

/-! A necessary two-adic condition computable from divisor-count partitions
alone. It sees which exponent lengths can occur before any prime search. -/
namespace OMA.WeightedValuationShapes245212
open Nat ArithmeticFunction OMA.Smooth245212 OMA.WeightVal245212
open scoped ArithmeticFunction.sigma
open private OMA.WeightedMultipleHeight245212.weight_positive from WeightedMultipleHeight245212

def offset (n : ℕ) : ℤ := (val (W n):ℤ)-(val n:ℤ)
def oddTerm (t : ℕ) : ℤ := (val t:ℤ)+(val (t+1):ℤ)-1
def shapes : ℕ → ℕ → Bool → ℤ → Bool
  | 0,_,_,_=>true
  | f+1,D,allow,z=>
    if D=1 then decide (z=0)
    else (List.range' 2 (D-1)).any fun t=>
      decide (t∣D) && (shapes f (D/t) allow (z-oddTerm t) ||
        (allow && shapes f (D/t) false (z+(t-1:ℕ))))

private theorem vmul {a b : ℕ} (ap : 0 < a) (bp : 0 < b) : val (a*b)=val a+val b := by
  simp only [val,Nat.factorization_mul ap.ne' bp.ne',Finsupp.add_apply]

private theorem product {a b : ℕ} (ap : 0 < a) (bp : 0 < b) (cp : a.Coprime b) :
    offset (a*b)=offset a+offset b := by
  unfold offset
  rw [w_mult.map_mul_of_coprime cp,vmul ap bp,vmul (OMA.WeightedMultipleHeight245212.weight_positive ap)
    (OMA.WeightedMultipleHeight245212.weight_positive bp)]
  omega

theorem eq_ratio {A B n : ℕ} (ap : 0 < A) (bp : 0 < B) (pos : 0 < n) (eqn : B*W n=A*n) :
    offset n=(val A:ℤ)-(val B:ℤ) := by
  have s:=congrArg val eqn
  rw [vmul bp (OMA.WeightedMultipleHeight245212.weight_positive pos),vmul ap pos] at s
  unfold offset;omega

theorem accepts (fuel : ℕ) {n : ℕ} (pos : 0 < n) {allow : Bool} (par : allow=false → Odd n) :
    shapes fuel (σ 0 n) allow (offset n)=true := by
  induction fuel generalizing n allow with
  | zero=>rfl
  | succ f ih=>
    by_cases unit : n=1
    · simp [shapes,unit,offset,w_mult.map_one]
    have big : 1 < n:=by omega
    let p:=n.minFac
    let e:=n.factorization p
    let v:=ordCompl[p] n
    have pr : p.Prime:=Nat.minFac_prime unit
    have mem : p∈n.primeFactors:=Nat.mem_primeFactors.mpr ⟨pr,n.minFac_dvd,pos.ne'⟩
    have ep : 0 < e:=pr.factorization_pos_of_dvd pos.ne' n.minFac_dvd
    have vp : 0 < v:=Nat.ordCompl_pos p pos.ne'
    have cp : p.Coprime v:=Nat.coprime_ordCompl pr pos.ne'
    have rep : p^e*v=n:=Nat.ordProj_mul_ordCompl_eq_self n p
    have D : σ 0 n=(e+1)*σ 0 v:=by
      rw [←rep,isMultiplicative_sigma.map_mul_of_coprime (cp.pow_left e),sigma_zero_apply_prime_pow pr]
    have du : σ 0 n≠1:=by
      intro h;apply unit;apply (Nat.divisors_card_eq_one_iff n).mp
      rwa [sigma_zero_apply] at h
    have div : e+1∣σ 0 n:=⟨_,D⟩
    have card : σ 0 n/(e+1)=σ 0 v:=by rw [D,Nat.mul_div_cancel_left _ (Nat.succ_pos _)]
    have idx : e+1∈List.range' 2 (σ 0 n-1):=by
      have cap:=Nat.le_of_dvd (sigma_pos 0 n pos.ne') div
      apply List.mem_range'_1.mpr;omega
    have off : offset n=offset (p^e)+offset v:=rep ▸ product (pow_pos pr.pos _) vp (cp.pow_left e)
    simp only [shapes,if_neg du,List.any_eq_true]
    refine ⟨e+1,idx,?_⟩
    simp only [decide_eq_true div,Bool.true_and,card,Bool.or_eq_true,Bool.and_eq_true,Nat.add_one_sub_one]
    by_cases two : p=2
    · right
      have on : allow=true:=by
        cases ha : allow
        · have bad:=(par ha).not_two_dvd_nat
          exact False.elim (bad (two ▸ dvd_of_mem_primeFactors mem))
        · rfl
      have pw : val (p^e)=e:=by rw [two];exact Nat.factorization_pow_self prime_two
      have w : val (W (p^e))=0:=by rw [two];exact val_odd (OMA.DyadicPower245212.dyadic_odd _)
      have key : offset n+(e:ℤ)=offset v:=by unfold offset at off ⊢;omega
      exact ⟨on,key ▸ ih vp (fun _=>Nat.coprime_two_left.mp (two ▸ cp))⟩
    · left
      have op:=pr.odd_of_ne_two two
      have pp : val (p^e)=0:=val_odd (op.pow (n:=e))
      have w:=weight_local pr op e
      change val (W (p^e))+1=val (e+1)+val ((e+1)+1) at w
      have atom : offset (p^e)=oddTerm (e+1):=by unfold offset oddTerm;omega
      have key : offset n-oddTerm (e+1)=offset v:=by rw [off,atom];omega
      rw [key]
      exact ih vp (fun no=>Nat.coprime_two_left.mp ((Nat.coprime_two_left.mpr (par no)).of_dvd_right
        (Nat.ordCompl_dvd n p)))

#print axioms accepts
end OMA.WeightedValuationShapes245212
