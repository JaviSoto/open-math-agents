import CofactorEffectiveTree245212
import WeightVal245212

/-! The cofactor search closes even in the presence of prime-divisor-count
edges if the possible growth in the two-adic order of its weighted moment
does not exhaust the initial gap. -/
namespace OMA.CofactorValuationTree245212
open Nat ArithmeticFunction OMA.Smooth245212 OMA.WeightVal245212
open Finset hiding val
open OMA.CofactorEulerSeparation245212 OMA.CofactorEffectiveTree245212
open scoped ArithmeticFunction.sigma

def excess (m : ℕ) := ∑p∈m.primeFactors,(val (m.factorization p+2)-1)
private def fits (h m : ℕ) := val (W h)+excess m≤val (2*(h*σ 0 h))

private theorem wpos {h : ℕ} (hh : 0 < h) : 0<W h := by
  rw [w_apply]
  exact sum_pos' (fun _ _=>Nat.zero_le _) ⟨1,Nat.one_mem_divisors.mpr hh.ne',by simp⟩

private theorem vmul {a b : ℕ} (ap : 0<a) (bp : 0<b) : val (a*b)=val a+val b := by
  simp only [val,Nat.factorization_mul ap.ne' bp.ne',Finsupp.add_apply]

private theorem all_odd {u : Finset ℕ} (odd : ∀p∈u,Odd p) : Odd (num u) := by
  induction u using Finset.induction_on with
  | empty=>simp [num]
  | @insert p u fresh ih=>
    rw [num,prod_insert fresh]
    exact (odd p (mem_insert_self ..)).mul (ih (fun q mem=>odd q (mem_insert_of_mem mem)))

theorem valuation_miss {h m : ℕ} (hh : 0 < h) (odd : Odd m) (below : W h<2*(h*σ 0 h))
    (ok : val (W h)≤val (2*(h*σ 0 h))) : miss (W h) (2*(h*σ 0 h)) m.primeFactors := by
  let H:=2*(h*σ 0 h)
  have hp : 0<H := by dsimp [H];exact mul_pos (by decide) (mul_pos hh (sigma_pos 0 h hh.ne'))
  have op (q : ℕ) (mq : q∈m.primeFactors) : Odd q :=
    Nat.coprime_two_left.mp ((Nat.coprime_two_left.mpr odd).of_dvd_right (dvd_of_mem_primeFactors mq))
  intro s sub hit
  by_cases emp : s=∅
  · exact below.ne (by simpa [emp,num,den] using hit)
  obtain ⟨p,mem⟩:=nonempty_iff_ne_empty.mpr emp
  have dv : 2∣p-1 := by obtain ⟨j,hj⟩:=op _ (sub mem);omega
  have de : 2∣den s := dv.trans (dvd_prod_of_mem (fun q=>q-1) mem)
  have hpow : 2^val H∣H := (prime_two.pow_dvd_iff_le_factorization hp.ne').mpr le_rfl
  have both : 2^(val H+1)∣W h*num s := by rw [hit,pow_succ];exact Nat.mul_dvd_mul hpow de
  have cp:=(Nat.coprime_two_left.mpr (all_odd (fun q mq=>op q (sub mq)))).pow_left (val H+1)
  have bad:=(prime_two.pow_dvd_iff_le_factorization (wpos hh).ne').mp (cp.dvd_of_dvd_mul_right both)
  change val H+1≤val (W h) at bad
  change val (W h)≤val H at ok
  omega

theorem excess_erase {m p : ℕ} (mem : p∈m.primeFactors) :
    excess (ordCompl[p] m)+(val (m.factorization p+2)-1)=excess m := by
  unfold excess
  rw [support_rest]
  have same : (∑q∈m.primeFactors.erase p,(val ((ordCompl[p] m).factorization q+2)-1))=
      ∑q∈m.primeFactors.erase p,(val (m.factorization q+2)-1) := by
    apply sum_congr rfl
    intro q mq
    rw [Nat.factorization_ordCompl,Finsupp.erase_ne (ne_of_mem_erase mq)]
  rw [same,Finset.sum_erase_add _ _ mem]

private theorem peel {h m p : ℕ} (hh : 0 < h) (cop : h.Coprime m) (odd : Odd m)
    (mem : p∈m.primeFactors) (ok : fits h m) : fits (h*ordProj[p] m) (ordCompl[p] m) := by
  let a:=m.factorization p
  have pp:=prime_of_mem_primeFactors mem
  have op:=Nat.coprime_two_left.mp ((Nat.coprime_two_left.mpr odd).of_dvd_right (dvd_of_mem_primeFactors mem))
  have pc:= (cop.of_dvd_right (dvd_of_mem_primeFactors mem)).pow_right a
  have pw : 0<p^a:=pow_pos pp.pos a
  have tau : 0<σ 0 h:=sigma_pos 0 h hh.ne'
  have H : 0<2*(h*σ 0 h):=mul_pos (by decide) (mul_pos hh tau)
  have eqn:=weight_local pp op a
  have eo:=excess_erase mem
  change val (W h)+excess m≤val (2*(h*σ 0 h)) at ok
  change val (W (h*p^a))+excess (ordCompl[p] m)≤val (2*((h*p^a)*σ 0 (h*p^a)))
  rw [w_mult.map_mul_of_coprime pc,isMultiplicative_sigma.map_mul_of_coprime pc,
    sigma_zero_apply_prime_pow pp,vmul (wpos hh) (wpos pw),
    show 2*(h*p^a*(σ 0 h*(a+1)))=2*(h*σ 0 h)*(p^a*(a+1)) by ring,
    vmul H (mul_pos pw (Nat.succ_pos a)),vmul pw (Nat.succ_pos a),val_odd (show Odd (p^a) from op.pow),zero_add]
  change excess (ordCompl[p] m)+(val (a+2)-1)=excess m at eo
  simp only [Nat.succ_eq_add_one] at *
  omega

theorem bounded {h m : ℕ} (hh : 0 < h) (hm : 0 < m) (cop : h.Coprime m) (odd : Odd m)
    (budget : val (W h)+excess m≤val (2*(h*σ 0 h)))
    (eqn : OeisA245212.a (h*m)=(σ 1 (h*m):ℤ)) : h*m≤ceiling m.primeFactors.card h := by
  exact bounded_by fits (fun hh _ odd below ok=>valuation_miss hh odd below ((Nat.le_add_right _ _).trans ok))
    (fun hh _ cop odd mem ok=>peel hh cop odd mem ok) _ hh hm cop odd rfl budget eqn

theorem dyadic {k m : ℕ} (odd : Odd m) (budget : excess m≤1+k+val (k+1))
    (eqn : OeisA245212.a (2^k*m)=(σ 1 (2^k*m):ℤ)) :
    2^k*m≤ceiling m.primeFactors.card (2^k) := by
  apply bounded (by positivity) odd.pos ((Nat.coprime_two_left.mpr odd).pow_left k) odd _ eqn
  rw [val_odd (OMA.DyadicPower245212.dyadic_odd k),zero_add,sigma_zero_apply_prime_pow prime_two,
    vmul (by decide) (mul_pos (Nat.two_pow_pos k) (Nat.succ_pos k)),
    vmul (Nat.two_pow_pos k) (Nat.succ_pos k)]
  have two : val 2=1:=by simp [val,prime_two.factorization]
  have pw : val (2^k)=k:=by simp [val,prime_two.factorization_pow]
  rw [two,pw]
  simpa only [Nat.succ_eq_add_one,add_assoc] using budget

#print axioms bounded
#print axioms dyadic
end OMA.CofactorValuationTree245212
