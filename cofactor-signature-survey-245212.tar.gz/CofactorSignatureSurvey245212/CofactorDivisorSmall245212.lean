import CofactorDivisorThrough44

/-! Certified elimination of exact Euler resonances at bounded divisor
count, without imposing a bound on the cofactor itself. -/
namespace OMA.CofactorDivisorSmall245212
open OMA.CofactorDivisorCertificate245212
open Nat Finset ArithmeticFunction OMA.Smooth245212 OMA.CofactorEulerSeparation245212
open scoped ArithmeticFunction.sigma

def through (D : ℕ) := (List.range (D+1)).all test

theorem small : through 44=true := by
  apply List.all_eq_true.mpr
  intro D mem
  have le:=List.mem_range.mp mem
  cases D with
  | zero=>decide
  | succ d=>exact tested_through_44 (Nat.succ_pos _) (by omega)

theorem original {h : ℕ} {T : Finset ℕ} (pos : 0 < h) (size : σ 0 h≤44)
    (non : T.Nonempty) (pr : ∀q∈T,q.Prime) (odd : ∀q∈T,Odd q)
    (fresh : ∀q∈T,h.Coprime q) : W h*num T≠2*(h*σ 0 h)*den T :=
  exclude_through_44 pos size non pr odd fresh

#print axioms small
#print axioms original
end OMA.CofactorDivisorSmall245212
