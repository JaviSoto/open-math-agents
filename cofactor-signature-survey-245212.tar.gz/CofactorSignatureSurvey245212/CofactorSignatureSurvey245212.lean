import PrimeMomentSignature245212
import CofactorDivisorSmall245212
import CofactorCountResidue245212
import MersennePrimePowerInverse245212

/-! Exact weighted-cofactor search: algebraic prime reconstruction, global
obstructions, and the formally excluded small divisor counts. -/
#print axioms OMA.TerminalPrimeInverse245212.recover
#print axioms OMA.PrimeMomentSignature245212.injective
#print axioms OMA.PrimeMomentSignature245212.ordinary
#print axioms OMA.CofactorCountResidue245212.necessary
#print axioms OMA.CofactorOddBudget245212.budget
#print axioms OMA.CofactorDivisorSmall245212.original
#print axioms OMA.MersennePrimePowerInverse245212.classify
