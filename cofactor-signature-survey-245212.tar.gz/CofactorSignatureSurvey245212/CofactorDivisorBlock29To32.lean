import CofactorDivisorCertificate245212

/-! Kernel check of divisor counts 29 through 32. -/
set_option maxRecDepth 65536
set_option maxHeartbeats 0
namespace OMA.CofactorDivisorCertificate245212
theorem block29to32 : interval 29 4=true := by decide +kernel
end OMA.CofactorDivisorCertificate245212
