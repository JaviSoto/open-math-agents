import CofactorDivisorCertificate245212

/-! Kernel check of divisor counts 41 through 44. -/
set_option maxRecDepth 65536
set_option maxHeartbeats 0
namespace OMA.CofactorDivisorCertificate245212
theorem block41to44 : interval 41 4=true := by decide +kernel
end OMA.CofactorDivisorCertificate245212
