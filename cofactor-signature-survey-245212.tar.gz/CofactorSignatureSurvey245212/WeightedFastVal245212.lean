import WeightVal245212

/-! A fuelled 2-adic valuation for reducing numerical goals in the kernel.
The recursion depth is at most the bit length even on large coefficients. -/
namespace OMA.WeightedFastVal245212
open Nat OMA.WeightVal245212

def strip : ℕ → ℕ → ℕ
  | 0,_ => 0
  | f+1,n => if n=0 ∨ n%2≠0 then 0 else strip f (n/2)+1

def fast (n : ℕ) := strip (Nat.log 2 n+1) n

private theorem strip_eq (f n : ℕ) (small : n<2^f) : strip f n=val n := by
  induction f generalizing n with
  | zero =>
    have : n=0:=by simpa using small
    simp [this,strip,val]
  | succ f ih =>
    by_cases zero : n=0
    · simp [zero,strip,val]
    by_cases odd : n%2≠0
    · have no : ¬2∣n:=by omega
      simp [strip,odd,val,Nat.factorization_eq_zero_of_not_dvd no]
    · have eq : 2*(n/2)=n:=by omega
      have pos : n/2≠0:=by omega
      have bound : n/2<2^f:=by rw [pow_succ] at small;omega
      have fact : val (2*(n/2))=1+val (n/2):=by
        simp only [val,Nat.factorization_mul (by decide : (2:ℕ)≠0) pos,Finsupp.add_apply,
          Nat.Prime.factorization_self Nat.prime_two]
      rw [eq] at fact
      simp [strip,zero,odd,ih (n/2) bound,fact,Nat.add_comm]

theorem fast_eq (n : ℕ) : fast n=val n:=
  strip_eq _ _ (Nat.lt_pow_succ_log_self (by decide) _)

end OMA.WeightedFastVal245212
