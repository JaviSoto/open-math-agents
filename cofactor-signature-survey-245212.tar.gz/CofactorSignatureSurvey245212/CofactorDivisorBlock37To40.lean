import CofactorDivisorCertificate245212

/-! Kernel check of divisor counts 37 through 40. -/
set_option maxRecDepth 65536
set_option maxHeartbeats 0
namespace OMA.CofactorDivisorCertificate245212
theorem block37to40 : interval 37 4=true := by decide +kernel
end OMA.CofactorDivisorCertificate245212
