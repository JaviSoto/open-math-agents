import CofactorDivisorCertificate245212

/-! Kernel check of divisor counts 9 through 12. -/
set_option maxRecDepth 65536
set_option maxHeartbeats 0
namespace OMA.CofactorDivisorCertificate245212
theorem block9to12 : interval 9 4=true := by decide +kernel
end OMA.CofactorDivisorCertificate245212
