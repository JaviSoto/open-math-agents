import CofactorDivisorCertificate245212

/-! Kernel check of divisor counts 21 through 24. -/
set_option maxRecDepth 65536
set_option maxHeartbeats 0
namespace OMA.CofactorDivisorCertificate245212
theorem block21to24 : interval 21 4=true := by decide +kernel
end OMA.CofactorDivisorCertificate245212
