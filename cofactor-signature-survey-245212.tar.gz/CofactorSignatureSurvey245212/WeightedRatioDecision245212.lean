import WeightedRatioSearch245212
import WeightedValuationShapes245212
import WeightedFastVal245212

/-! A sound terminating search in weighted quotients, using either a
prime forced by the reduced denominator or the bounded least prime. -/
namespace OMA.WeightedRatioDecision245212
open Nat Finset ArithmeticFunction OMA.Smooth245212 OMA.WeightedRatioSearch245212
open scoped ArithmeticFunction.sigma

abbrev Search := ℕ → ℕ → ℕ → ℕ → List ℕ → Bool

def branch (rec : Search) (A B D lo p nextLo : ℕ) (banned : List ℕ) :=
  if p<lo ∨ p∈banned ∨ ¬p.Prime then true else
  (List.range' 2 (D-1)).all fun t=>
    if t∣D then
      if t=D then decide (¬p∣B ∨ p^(t-1)≠B/A.gcd B ∨ B*mom p (t-1)≠A*p^(t-1)) else
      let a:=A*p^(t-1)
      let b:=B*mom p (t-1)
      let g:=a.gcd b
      rec (a/g) (b/g) (D/t) nextLo (p::banned)
    else true

def force (_A B : ℕ) :=
  -- Product of the primes through 251. The caller independently verifies
  -- the returned prime and divisibility; this only selects a cheap branch.
  let probe:=B.gcd 64266330917908644872330635228106713310880186591609208114244758680898150367880703152525200743234420230
  if 1<probe then probe.minFac else if B≤1000000 then B.minFac else 0

def validShape (A B D lo : ℕ) (banned : List ℕ) :=
  OMA.WeightedValuationShapes245212.shapes (Nat.log 2 D+1) D (decide (lo≤2 ∧ 2∉banned))
    ((OMA.WeightedFastVal245212.fast A:ℤ)-(OMA.WeightedFastVal245212.fast B:ℤ))

/-- Check a possible last prime by integer bisection on its exact power.
Exhausting fuel returns false, so insufficient fuel cannot exclude a witness. -/
def terminal (A B x e : ℕ) (banned : List ℕ) : ℕ → ℕ → ℕ → Bool
  | 0,_,_=>false
  | f+1,lo,hi=>
    if x<lo^e ∨ hi^e<x then true
    else if lo=hi then decide (¬lo.Prime ∨ lo∈banned ∨ B*mom lo e≠A*x)
    else let mid:=(lo+hi)/2
         if x ≤ mid^e then terminal A B x e banned f lo mid
         else terminal A B x e banned f (mid+1) hi

private theorem terminal_sound {p A B x e : ℕ} {ban : List ℕ} (pr : p.Prime)
    (free : p∉ban) (power : p^e=x) (ep : 0 < e) (eqn : B*mom p e=A*x) (f : ℕ) :
    ∀lo hi,lo≤p → p≤hi → terminal A B x e ban f lo hi ≠ true := by
  induction f with
  | zero=>intro lo hi _ _;simp [terminal]
  | succ f ih=>
    intro lo hi low high pass
    have l:=(Nat.pow_le_pow_left low e).trans_eq power
    have h:=power.symm.trans_le (Nat.pow_le_pow_left high e)
    simp only [terminal,if_neg (not_or.mpr ⟨not_lt.mpr l,not_lt.mpr h⟩)] at pass
    by_cases stop : lo=hi
    · have same : lo=p:=by omega
      subst lo
      subst hi
      simp [pr,free,eqn] at pass
    · simp only [if_neg stop] at pass
      let mid:=(lo+hi)/2
      by_cases ge : x ≤ mid^e
      · have pLe : p ≤ mid := by
          by_contra! lt
          have := Nat.pow_lt_pow_left lt ep.ne'
          omega
        change x≤((lo+hi)/2)^e at ge
        exact ih lo mid low pLe (by simpa only [if_pos ge] using pass)
      · have midLt : mid<p := by
          by_contra! below
          exact ge (power.symm.trans_le (Nat.pow_le_pow_left below e))
        change ¬x≤((lo+hi)/2)^e at ge
        exact ih (mid+1) hi midLt high (by simpa only [if_neg ge] using pass)

def check : ℕ → Search
  | 0,_,_,_,_,_=>false
  | f+1,A,B,D,lo,banned=>
    if D=1 then decide (A≠B)
    else if A≤B*D then true
    else if D.Prime then
      let cap:=Nat.log 2 D*A/(A-B*D)
      terminal A B (B/A.gcd B) (D-1) banned (Nat.log 2 cap+3) lo cap
    else if validShape A B D lo banned=false then true
    else
      let p:=force A B
      if p.Prime ∧ p∣B ∧ ¬p∣A then branch (check f) A B D lo p lo banned
      else
        let cap:=Nat.log 2 D*A/(A-B*D)
        (List.range' lo (cap+1-lo)).all fun q=>branch (check f) A B D lo q (q+1) banned

def Fits (v lo : ℕ) (banned : List ℕ) := ∀q∈v.primeFactors,lo≤q ∧ q∉banned

def Sound (rec : Search) := ∀{A B n lo banned}, 0 < n → 0 < B → Fits n lo banned →
  B*W n=A*n → rec A B (σ 0 n) lo banned ≠ true

private theorem branch_sound {rec : Search} (ih : Sound rec)
    {A B n lo p nextLo : ℕ} {banned : List ℕ} (pos : 0 < n) (bp : 0 < B)
    (fit : Fits n lo banned) (eqn : B*W n=A*n) (mp : p∈n.primeFactors)
    (lower : ∀q∈n.primeFactors.erase p,nextLo≤q) :
    branch rec A B (σ 0 n) lo p nextLo banned ≠ true := by
  let e:=n.factorization p
  let v:=ordCompl[p] n
  have pr:=prime_of_mem_primeFactors mp
  have entry:=fit p mp
  have no : ¬(p<lo ∨ p∈banned ∨ ¬p.Prime):=by
    simp only [not_or,not_lt,not_not];exact ⟨entry.1,entry.2,pr⟩
  intro pass
  simp only [branch,if_neg no] at pass
  obtain ⟨ep,dvd,card,sub,newPos⟩:=descend pos bp mp eqn
  have dpos:=sigma_pos 0 n pos.ne'
  have hit : e+1∈List.range' 2 (σ 0 n-1) := by
    have lim:=Nat.le_of_dvd dpos dvd
    apply List.mem_range'_1.mpr
    change 0 < e at ep
    change e+1≤σ 0 n at lim
    omega
  have ok:=List.all_eq_true.mp pass (e+1) hit
  change e+1∣σ 0 n at dvd
  simp only [if_pos dvd] at ok
  by_cases last : e+1=σ 0 n
  · obtain ⟨power,rep⟩:=full_count pos bp eqn mp last
    have de : σ 0 n-1=e:=by omega
    rw [de] at power rep
    have dp : p∣B:= (dvd_pow_self p ep.ne').trans
      (power ▸ Nat.div_dvd_of_dvd (Nat.gcd_dvd_right A B))
    have ratio : B*mom p e=A*p^e:=by rw [mom_eq pr,rep,eqn]
    simp [last,de,dp,power,ratio] at ok
  simp only [if_neg last,Nat.add_one_sub_one] at ok
  have restFit : Fits v nextLo (p::banned) := by
    intro q mq
    have erased : q∈n.primeFactors.erase p := by
      rwa [←OMA.CofactorEffectiveTree245212.support_rest n p]
    obtain ⟨diff,old⟩:=mem_erase.mp erased
    have notOld:=(fit q old).2
    exact ⟨lower q erased,by simpa only [List.mem_cons,not_or] using And.intro diff notOld⟩
  exact ih (Nat.ordCompl_pos p pos.ne') newPos restFit sub (card ▸ ok)

theorem sound (f : ℕ) : Sound (check f) := by
  induction f with
  | zero=>intro A B n lo ban _ _ _ _;simp [check]
  | succ f ih=>
    intro A B n lo ban pos bp fit eqn pass
    unfold check at pass
    by_cases unit : σ 0 n=1
    · have one:= (Nat.divisors_card_eq_one_iff n).mp (by simpa only [sigma_zero_apply] using unit)
      have w : W 1=1:=w_mult.map_one
      simp [one,w] at eqn pass
      omega
    simp only [if_neg unit] at pass
    have big : 1 < n := by
      by_contra! low
      have one : n=1:=by omega
      simp [one] at unit
    have ne:=Nat.nonempty_primeFactors.mpr big
    let q:=n.primeFactors.min' ne
    have mq : q∈n.primeFactors:=n.primeFactors.min'_mem ne
    have small : ∀p∈n.primeFactors,q≤p:=fun p mp=>n.primeFactors.min'_le _ mp
    obtain ⟨gap,cap⟩:=least bp big eqn small
    simp only [if_neg (not_le.mpr gap)] at pass
    by_cases prime : (σ 0 n).Prime
    · obtain ⟨x,rep⟩:=prime_count pos bp prime eqn mq
      have localEq : B*mom q (σ 0 n-1)=A*(B/A.gcd B) := by
        rw [mom_eq (prime_of_mem_primeFactors mq),rep,←x,rep,eqn]
      exact terminal_sound (prime_of_mem_primeFactors mq) (fit _ mq).2 x (by have :=prime.one_lt;omega) localEq
        _ _ _ (fit _ mq).1 cap (by simpa only [if_pos prime] using pass)
    simp only [if_neg prime] at pass
    have valid : validShape A B (σ 0 n) lo ban=true := by
      unfold validShape
      simp only [OMA.WeightedFastVal245212.fast_eq]
      rw [←OMA.WeightedValuationShapes245212.eq_ratio (A:=A) (by omega) bp pos eqn]
      apply OMA.WeightedValuationShapes245212.accepts
      · exact pos
      · intro no
        apply Nat.coprime_two_left.mp
        apply prime_two.coprime_iff_not_dvd.mpr
        intro dv
        have yes:=fit 2 (Nat.mem_primeFactors.mpr ⟨prime_two,dv,pos.ne'⟩)
        simp [yes.1,yes.2] at no
    simp only [valid,Bool.true_eq_false,if_false] at pass
    let z:=force A B
    by_cases forced : z.Prime ∧ z∣B ∧ ¬z∣A
    · change (force A B).Prime ∧ force A B∣B ∧ ¬force A B∣A at forced
      have d : z∣A*n := eqn ▸ dvd_mul_of_dvd_left forced.2.1 _
      have mz:=Nat.mem_primeFactors.mpr ⟨forced.1,(forced.1.dvd_mul.mp d).resolve_left forced.2.2,pos.ne'⟩
      have take:=branch_sound ih pos bp fit eqn mz (fun t mt=>(fit _ (mem_of_mem_erase mt)).1)
      exact take (by simpa only [if_pos forced] using pass)
    · change ¬((force A B).Prime ∧ force A B∣B ∧ ¬force A B∣A) at forced
      have list:=pass
      simp only [if_neg forced] at list
      have minLo:=(fit q mq).1
      have range : q∈List.range' lo (Nat.log 2 (σ 0 n)*A/(A-B*σ 0 n)+1-lo) :=
        List.mem_range'_1.mpr ⟨minLo,by omega⟩
      apply branch_sound ih pos bp fit eqn mq _ (List.all_eq_true.mp list q range)
      intro t mt
      obtain ⟨diff,old⟩:=mem_erase.mp mt
      have :=small t old
      omega

#print axioms sound
end OMA.WeightedRatioDecision245212
