import WeightedRatioDecision245212
import EulerQuotientFilter245212
import WeightedValuationShapes245212
import CofactorValuationTree245212

/-! Turn exact fixed-divisor-count exclusions into ordinary Lean theorems.
The checker ranges over integer quotients, not over integers of bounded size. -/
namespace OMA.CofactorDivisorCertificate245212
open Nat Finset ArithmeticFunction OMA.Smooth245212 OMA.CofactorEulerSeparation245212
open OMA.WeightedRatioDecision245212
open scoped ArithmeticFunction.sigma
open private OMA.CofactorValuationTree245212.all_odd from CofactorValuationTree245212
open private OMA.WeightedMultipleHeight245212.strict_weight from WeightedMultipleHeight245212

def row (D j : ℕ) :=
    if 2∣j/(2*D).gcd j ∧ OMA.EulerQuotientFilter245212.possible D (2*D) j=true ∧
      OMA.WeightedValuationShapes245212.shapes (Nat.log 2 D+1) D true (OMA.WeightVal245212.val j)=true
    then check (Nat.log 2 D+2) j 1 D 2 ((2*D)/(2*D).gcd j).primeFactorsList else true

def test (D : ℕ) := (List.range' (D+1) (D-1)).all (row D)

def interval (lo length : ℕ) := (List.range' lo length).all test

theorem in_interval {lo length D : ℕ} (check : interval lo length=true)
    (low : lo≤D) (high : D<lo+length) : test D=true :=
  List.all_eq_true.mp check D (List.mem_range'_1.mpr ⟨low,high⟩)

private theorem den_lt {T : Finset ℕ} (non : T.Nonempty) (pr : ∀q∈T,q.Prime) : den T<num T := by
  obtain ⟨p,mp⟩:=non
  have d : den T=(p-1)*den (T.erase p):=(mul_prod_erase T (fun q=>q-1) mp).symm
  have n : num T=p*num (T.erase p):=(mul_prod_erase T (fun q=>q) mp).symm
  have pos : 0 < num (T.erase p):=prod_pos fun _ h=>(pr _ (mem_of_mem_erase h)).pos
  have pp:=(pr p mp).pos
  rw [d,n]
  exact (Nat.mul_le_mul_left (p-1) (prod_le_prod' (fun q (_ : q∈T.erase p)=>Nat.sub_le q 1))).trans_lt
    (Nat.mul_lt_mul_of_pos_right (by omega) pos)

theorem no_resonance {h : ℕ} {T : Finset ℕ} (pos : 0 < h) (non : T.Nonempty)
    (pr : ∀q∈T,q.Prime) (odd : ∀q∈T,Odd q) (fresh : ∀q∈T,h.Coprime q) (pass : test (σ 0 h)=true) :
    W h*num T≠2*(h*σ 0 h)*den T := by
  intro hit
  have od:=OMA.CofactorValuationTree245212.all_odd odd
  have big : 1 < h := by
    by_contra! le
    have one : h=1:=by omega
    have w : W 1=1:=w_mult.map_one
    simp [one,w] at hit
    exact od.not_two_dvd_nat (by rw [hit];exact dvd_mul_right _ _)
  obtain ⟨j,id⟩:=OMA.EulerSupportUnique245212.cofactor_divides fresh hit
  have eqn : W h=j*h:=by rw [id,mul_comm]
  let D:=σ 0 h
  have dp : 0 < D:=sigma_pos 0 h pos.ne'
  have sum : j*num T=(2*D)*den T := by
    apply Nat.eq_of_mul_eq_mul_left pos
    rw [id] at hit
    nlinarith only [hit]
  have low : D<j := by
    have :=OMA.WeightedMultipleHeight245212.strict_weight big
    rw [id] at this
    exact Nat.lt_of_mul_lt_mul_left this
  have jp : 0 < j:=by omega
  have high : j<2*D := by
    apply Nat.lt_of_mul_lt_mul_right (a:=num T)
    rw [sum]
    exact Nat.mul_lt_mul_of_pos_left (den_lt non pr) (by omega)
  obtain ⟨q,mq⟩:=non
  have even : 2∣den T := by
    have oq:=odd q mq
    have pq:=(pr q mq).one_lt
    exact (show 2∣q-1 by obtain ⟨a,ha⟩:=oq;omega).trans (dvd_prod_of_mem (fun z=>z-1) mq)
  have red:=OMA.WeightedRatioSearch245212.reduced jp sum
  have gn:=Nat.gcd_pos_of_pos_right (2*D) jp
  have crt:=Nat.coprime_div_gcd_div_gcd gn
  have dividesNum : (2*D)/(2*D).gcd j∣num T :=
    crt.dvd_of_dvd_mul_left (red.symm ▸ dvd_mul_right _ _)
  have freshNum : h.Coprime (num T):=coprime_prod_right_iff.mpr fresh
  have fit : Fits h 2 ((2*D)/(2*D).gcd j).primeFactorsList := by
    intro p mp
    have pp:=prime_of_mem_primeFactors mp
    refine ⟨pp.two_le,?_⟩
    intro member
    have dv:=(Nat.dvd_of_mem_primeFactorsList member).trans dividesNum
    exact (pp.coprime_iff_not_dvd.mp (freshNum.of_dvd_left (dvd_of_mem_primeFactors mp))) dv
  have dv : 2∣j/(2*D).gcd j*num T := red ▸ dvd_mul_of_dvd_right even _
  have eligible:=(prime_two.dvd_mul.mp dv).resolve_right od.not_two_dvd_nat
  have eu:=OMA.EulerQuotientFilter245212.accepts D (show 0<2*D by omega) jp pr odd sum
  have sh:=OMA.WeightedValuationShapes245212.accepts (Nat.log 2 D+1) pos
    (allow:=true) (by simp)
  have off:=OMA.WeightedValuationShapes245212.eq_ratio jp (by decide : 0<1) pos (by simpa using eqn)
  rw [off] at sh
  simp only [OMA.WeightVal245212.val,Nat.factorization_one,Finsupp.zero_apply,Nat.cast_zero,sub_zero] at sh
  have atj:=List.all_eq_true.mp pass j (List.mem_range'_1.mpr ⟨by omega,by omega⟩)
  change (if 2∣j/(2*D).gcd j ∧ OMA.EulerQuotientFilter245212.possible D (2*D) j=true ∧
      OMA.WeightedValuationShapes245212.shapes (Nat.log 2 D+1) D true (OMA.WeightVal245212.val j)=true
    then check _ j 1 D 2 ((2*D)/(2*D).gcd j).primeFactorsList else true)=true at atj
  rw [if_pos ⟨eligible,eu,sh⟩] at atj
  exact sound (Nat.log 2 D+2) pos (by decide : 0<1) fit (by simpa using eqn) atj

#print axioms no_resonance
end OMA.CofactorDivisorCertificate245212
