import CofactorValuationTree245212

/-! At any exact Euler cofactor the odd part of its divisor count controls
the number of primes, the power of two in the cofactor and the Euler rank,
even when the power of two in the divisor count varies without bound. -/
namespace OMA.CofactorOddBudget245212
open Nat ArithmeticFunction OMA.Smooth245212 OMA.WeightVal245212
open Finset hiding val
open OMA.CofactorEulerSeparation245212
open scoped ArithmeticFunction.sigma
open private OMA.CofactorValuationTree245212.wpos OMA.CofactorValuationTree245212.vmul
  OMA.CofactorValuationTree245212.all_odd from CofactorValuationTree245212

private theorem powval {n : ℕ} (hp : 0<n) : 2^val n≤n:=
  Nat.le_of_dvd hp ((prime_two.pow_dvd_iff_le_factorization hp.ne').mpr le_rfl)

private theorem atom {p e : ℕ} (pr : p.Prime) (op : Odd p) (ep : 0<e) :
    3*2^val (W (p^e))≤2*(e+1) := by
  have w:=weight_local pr op e
  by_cases odd : Odd (e+1)
  · have z:=val_odd odd
    have gap : 1<e:=by obtain ⟨u,hu⟩:=odd;omega
    rw [z,zero_add] at w
    have v:=powval (n:=e+2) (by omega)
    rw [←w,pow_succ] at v
    omega
  · have od : Odd (e+2):=by rw [Nat.odd_iff] at *;omega
    have z:=val_odd od
    rw [z,add_zero] at w
    have v:=powval (n:=e+1) (by omega)
    rw [←w,pow_succ] at v
    omega

theorem odd_weight (m : ℕ) (od : Odd m) :
    3^m.primeFactors.card*2^val (W m)≤2^m.primeFactors.card*(σ 0 m) := by
  induction m using Nat.recOnPrimeCoprime with
  | zero=>simp at od
  | prime_pow p e pr=>
    by_cases ze : e=0
    · simp [ze,w_mult.map_one,val]
    have op : Odd p:=by
      apply Nat.coprime_two_left.mp
      exact (Nat.coprime_two_left.mpr od).of_dvd_right (dvd_pow_self p ze)
    simpa [Nat.primeFactors_prime_pow ze pr,sigma_zero_apply_prime_pow pr] using atom pr op (Nat.pos_of_ne_zero ze)
  | coprime a b ha hb cp ia ib=>
    have oa:= (Nat.coprime_two_left.mpr od).of_dvd_right (dvd_mul_right a b)
    have ob:= (Nat.coprime_two_left.mpr od).of_dvd_right (dvd_mul_left b a)
    have pa:=(Nat.coprime_two_left.mp oa).pos
    have pb:=(Nat.coprime_two_left.mp ob).pos
    rw [cp.primeFactors_mul,Finset.card_union_of_disjoint ((Nat.disjoint_primeFactors pa.ne' pb.ne').mpr cp),
      w_mult.map_mul_of_coprime cp,OMA.CofactorValuationTree245212.vmul
        (OMA.CofactorValuationTree245212.wpos pa) (OMA.CofactorValuationTree245212.wpos pb),
      isMultiplicative_sigma.map_mul_of_coprime cp]
    simpa only [pow_add,mul_assoc,mul_comm,mul_left_comm] using
      Nat.mul_le_mul (ia (Nat.coprime_two_left.mp oa)) (ib (Nat.coprime_two_left.mp ob))

private theorem den_val (T : Finset ℕ) (pr : ∀q∈T,q.Prime) (odd : ∀q∈T,Odd q) :
    0<den T ∧ T.card≤val (den T) := by
  induction T using Finset.induction_on with
  | empty=>simp [den,val]
  | @insert p s free ih=>
    have mem:=Finset.mem_insert_self p s
    have pp:=(pr p mem).one_lt
    have zp : 0<p-1:=by omega
    have ev : 2∣p-1:=by obtain ⟨u,hu⟩:=odd p mem;omega
    have vp : 1≤val (p-1):=prime_two.factorization_pos_of_dvd zp.ne' ev
    obtain ⟨pos,lower⟩:=ih (fun q mq=>pr q (mem_insert_of_mem mq)) (fun q mq=>odd q (mem_insert_of_mem mq))
    rw [den,prod_insert free,card_insert_of_notMem free]
    change 0<(p-1)*den s ∧ s.card+1≤val ((p-1)*den s)
    rw [OMA.CofactorValuationTree245212.vmul zp pos]
    exact ⟨Nat.mul_pos zp pos,by omega⟩

theorem budget {k m : ℕ} (od : Odd m) {T : Finset ℕ}
    (pr : ∀q∈T,q.Prime) (odd : ∀q∈T,Odd q)
    (hit : W (2^k*m)*num T=2*((2^k*m)*σ 0 (2^k*m))*den T) :
    let D:=σ 0 (2^k*m)
    let r:=m.primeFactors.card
    3^r*((k+1)*2^(1+k+T.card)) ≤ 2^r*(D/2^val D) := by
  let D:=σ 0 (2^k*m)
  have pk:=Nat.two_pow_pos k
  have pm:=od.pos
  have pd : 0<D:=sigma_pos 0 _ (Nat.mul_pos pk pm).ne'
  have cop : (2^k).Coprime m:=(Nat.coprime_two_left.mpr od).pow_left k
  have dp : D=(k+1)*(σ 0 m):=by
    dsimp [D];rw [isMultiplicative_sigma.map_mul_of_coprime cop,sigma_zero_apply_prime_pow prime_two]
  have nOdd:=OMA.CofactorValuationTree245212.all_odd odd
  obtain ⟨de,lb⟩:=den_val T pr odd
  have v:=congrArg val hit
  change val (W (2^k*m)*num T)=val (2*((2^k*m)*D)*den T) at v
  have wp : ∀ {a : ℕ}, 0<a → 0<W a:=fun h=>OMA.CofactorValuationTree245212.wpos h
  simp only [w_mult.map_mul_of_coprime cop,OMA.CofactorValuationTree245212.vmul
    (mul_pos (wp pk) (wp pm)) nOdd.pos,OMA.CofactorValuationTree245212.vmul (wp pk) (wp pm),
    val_odd nOdd,val_odd (OMA.DyadicPower245212.dyadic_odd k),zero_add,add_zero,
    OMA.CofactorValuationTree245212.vmul (mul_pos (by decide : 0<2) (mul_pos (mul_pos pk pm) pd)) de,
    OMA.CofactorValuationTree245212.vmul (by decide : 0<2) (mul_pos (mul_pos pk pm) pd),
    OMA.CofactorValuationTree245212.vmul (mul_pos pk pm) pd,OMA.CofactorValuationTree245212.vmul pk pm,
    val_odd od,add_zero] at v
  have two : val 2=1:=Nat.Prime.factorization_self prime_two
  have dy : val (2^k)=k:=Nat.factorization_pow_self prime_two
  have vlow : (1+k+T.card)+val D≤val (W m):=by omega
  let r:=m.primeFactors.card
  have pw := Nat.pow_le_pow_right (by decide : 0<2) vlow
  have all := (Nat.mul_le_mul_left (k+1) (Nat.mul_le_mul_left (3^r) pw)).trans
    (Nat.mul_le_mul_left (k+1) (odd_weight m od))
  have dv : 2^val D∣D:=(prime_two.pow_dvd_iff_le_factorization pd.ne').mpr le_rfl
  have restore : D/2^val D*2^val D=D:=Nat.div_mul_cancel dv
  change 3^r*((k+1)*2^(1+k+T.card))≤2^r*(D/2^val D)
  apply Nat.le_of_mul_le_mul_right (c:=2^val D) _ (Nat.two_pow_pos _)
  rw [mul_assoc (2^r),restore]
  rw [pow_add] at all
  simpa only [dp,mul_assoc,mul_left_comm,mul_comm] using all

#print axioms budget
end OMA.CofactorOddBudget245212
