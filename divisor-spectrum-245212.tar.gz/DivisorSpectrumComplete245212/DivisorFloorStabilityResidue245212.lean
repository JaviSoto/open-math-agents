import CriticalResidueInput245212
import DivisorFloorStability245212

/-! Dyadic residues above the divisor-count floor. The singly occurring odd
primes carry the full valuation excess, viewed in their half-successors. -/
namespace OMA.DivisorFloorStabilityResidue245212
open Nat Finset ArithmeticFunction OMA.CriticalResidueLocal245212 OMA.FixedRankInteger245212
open OMA.DivisorFloorStability245212
open OMA.Smooth245212 (W w_pow w_mult)
open scoped ArithmeticFunction.sigma
open private OMA.DivisorHeight245212.dyadic_moments from ThreeMovingDividend245212
open private OMA.CriticalResidueInput245212.local_data from CriticalResidueInput245212
open private OMA.CriticalResidueLocal245212.prod_mod OMA.CriticalResidueLocal245212.odds from CriticalResidueLocal245212

private theorem difference {M k X Y T:ℕ} (pos : 0<M)
    (bal : (1+k*M)*X+(M-1)*Y=M*(k+1)*T) : X ≡ Y [MOD M] := by
  have succ : M-1+1=M := by omega
  have eqn : X+M*(k*X+Y)=Y+M*((k+1)*T) := by
    linear_combination bal - congrArg (· * Y) succ
  simpa only [Nat.ModEq,Nat.add_mul_mod_self_left] using congrArg (· % M) eqn

private theorem factored {k m d j : ℕ} (odd : Odd m)
    (hit : OeisA245212.a (2^k*m)=(σ 1 (2^k*m):ℤ))
    (shape : ∀p∈m.primeFactors,m.factorization p=1 ∨ m.factorization p=2)
    (rank : m.primeFactors.card+d=2*(m.primeFactors.filter (fun p=>m.factorization p=2)).card)
    (small : j≤2) (enough : d+j≤k+1) :
    let P := m.primeFactors.filter (fun p=>m.factorization p=1)
    (∏p∈P,s1 p) ≡ 2^d*3^P.card [MOD 2^(d+j)] := by
  let s:=m.primeFactors
  let P:=s.filter (fun p=>m.factorization p=1)
  let Q:=s.filter (fun p=>¬m.factorization p=1)
  have qs : Q=s.filter (fun p=>m.factorization p=2):=by
    ext p
    simp only [Q,mem_filter]
    constructor
    · rintro ⟨pm,no⟩;exact ⟨pm,(shape p pm).resolve_left no⟩
    · rintro ⟨pm,two⟩;exact ⟨pm,by omega⟩
  have split:=card_filter_add_card_filter_not (s:=s) (p:=fun p=>m.factorization p=1)
  change P.card+Q.card=s.card at split
  have qr : s.card+d=2*Q.card:=by rw [qs];exact rank
  have sizes : Q.card=P.card+d:=by omega
  have prime (p) (mem : p∈s):=Nat.prime_of_mem_primeFactors mem
  have op (p) (mem : p∈s):=Nat.coprime_two_left.mp
    ((Nat.coprime_two_left.mpr odd).of_dvd_right (Nat.dvd_of_mem_primeFactors mem))
  have po p (mem : p∈P):=op p (mem_filter.mp mem).1
  have qo p (mem : p∈Q):=op p (mem_filter.mp mem).1
  have data p (mem : p∈s):=OMA.CriticalResidueInput245212.local_data p (prime p mem) (op p mem)
  have pieces (f : ℕ→ℕ) : (∏p∈s,f (p^m.factorization p))=(∏p∈P,f p)*(∏q∈Q,f (q^2)) := by
    rw [←prod_filter_mul_prod_filter_not s (fun p=>m.factorization p=1) (fun p=>f (p^m.factorization p))]
    apply congrArg₂ Nat.mul
    · apply prod_congr rfl;intro p mem;rw [(mem_filter.mp mem).2,pow_one]
    · apply prod_congr rfl;intro p mem
      rw [((shape p (mem_filter.mp mem).1).resolve_left (mem_filter.mp mem).2)]
  have mult (f : ArithmeticFunction ℕ) (mf : f.IsMultiplicative) :
      f m=(∏p∈P,f p)*(∏q∈Q,f (q^2)) := by
    rw [mf.multiplicative_factorization _ odd.pos.ne'];exact pieces f
  let A:=(∏p∈P,w1 p)*(∏q∈Q,w2 q)
  let S:=(∏p∈P,s1 p)*(∏q∈Q,s2 q)
  have wa : W m=2^Q.card*A := by
    rw [mult W w_mult,prod_congr rfl (fun p hp=>(data p (mem_filter.mp hp).1).1),
      prod_congr rfl (fun p hp=>(data p (mem_filter.mp hp).1).2.2.1),prod_mul_distrib,prod_const]
    dsimp [A];ring
  have ss : σ 1 m=2^P.card*S := by
    rw [mult _ isMultiplicative_sigma,prod_congr rfl (fun p hp=>(data p (mem_filter.mp hp).1).2.1),
      prod_congr rfl (fun p hp=>(data p (mem_filter.mp hp).1).2.2.2),prod_mul_distrib,prod_const]
    dsimp [S];ring
  have tau : σ 0 m=2^P.card*3^Q.card := by
    rw [mult _ isMultiplicative_sigma]
    have two p (hp:p∈P) : σ 0 p=2:=by
      simpa using sigma_zero_apply_prime_pow (prime p (mem_filter.mp hp).1) (i:=1)
    have three q (hq:q∈Q) : σ 0 (q^2)=3:=sigma_zero_apply_prime_pow (prime q (mem_filter.mp hq).1)
    rw [prod_congr rfl two,prod_congr rfl three,prod_const,prod_const]
  have cop:=(Nat.coprime_two_left.mpr odd).pow_left k
  have bal:=OMA.Abundance245212.balance (Nat.mul_ne_zero (Nat.two_pow_pos k).ne' odd.pos.ne') hit
  obtain ⟨wf,sigmaDy⟩:=OMA.DivisorHeight245212.dyadic_moments k
  rw [w_mult.map_mul_of_coprime cop,isMultiplicative_sigma.map_mul_of_coprime cop,
    isMultiplicative_sigma.map_mul_of_coprime cop,wf,wa,ss,tau,sigma_zero_apply_prime_pow prime_two] at bal
  have fix : σ 1 (2^k)=2^(k+1)-1:=by omega
  rw [fix] at bal
  have eqn : (1+k*2^(k+1))*(2^d*A)+(2^(k+1)-1)*S=2^(k+1)*(k+1)*(m*3^Q.card):=by
    apply Nat.eq_of_mul_eq_mul_left (Nat.two_pow_pos P.card)
    rw [sizes,pow_add (2:ℕ) P.card d] at bal
    rw [sizes] at ⊢
    rw [pow_succ (2:ℕ) k] at bal ⊢
    linear_combination bal
  have main := (difference (Nat.two_pow_pos _) eqn).of_dvd (pow_dvd_pow 2 enough)
  have units := (OMA.CriticalResidueLocal245212.prod_mod P w1 (fun _=>3) 4 (fun p hp=>(lin p (po p hp)).1)).of_dvd
    (pow_dvd_pow 2 small)
  rw [prod_const] at units
  have squares := (OMA.CriticalResidueLocal245212.prod_mod Q w2 s2 4 (fun q hq=>(sqr q (qo q hq)).1)).of_dvd
    (pow_dvd_pow 2 small)
  have scaled := (units.mul squares).mul_left' (2^d)
  rw [←pow_add] at scaled
  have joint := main.symm.trans scaled
  change (∏p∈P,s1 p)*(∏q∈Q,s2 q) ≡ 2^d*(3^P.card*(∏q∈Q,s2 q)) [MOD 2^(d+j)] at joint
  rw [←mul_assoc] at joint
  have cop := (Nat.coprime_two_left.mpr (OMA.CriticalResidueLocal245212.odds Q s2
     (fun q hq=>(sqr q (qo q hq)).2.1))).pow_left (d+j)
  exact joint.cancel_right_of_coprime cop

def singles (n : ℕ) := (support n).filter fun p=>n.factorization p=1

theorem original_units {n j : ℕ} (pos : 0<n) (hit : OeisA245212.a n=(σ 1 n:ℤ))
    (low : ratio n<(98:ℚ)/27) (small : j≤2) (enough : excess n+j≤n.factorization 2+1) :
    (∏p∈singles n,s1 p) ≡ 2^(excess n)*3^(singles n).card [MOD 2^(excess n+j)] := by
  let m:=ordCompl[2] n
  have odd : Odd m:=Nat.coprime_two_left.mp (Nat.coprime_ordCompl prime_two pos.ne')
  have ss : m.primeFactors=support n := by
    dsimp [m,support];rw [←Nat.support_factorization,Nat.factorization_ordCompl,Finsupp.support_erase,Nat.support_factorization]
  have eqp p (mem : p∈support n) : m.factorization p=n.factorization p:=by
    dsimp [m];rw [Nat.factorization_ordCompl,Finsupp.erase_ne (mem_erase.mp mem).1]
  have fi (a:ℕ) : (m.primeFactors.filter (fun p=>m.factorization p=a))=
      (support n).filter (fun p=>n.factorization p=a):=by
    rw [ss];apply filter_congr;intro p mem;rw [eqp p mem]
  have id : 2^(n.factorization 2)*m=n:=Nat.ordProj_mul_ordCompl_eq_self n 2
  have shape := (classify pos hit low).1
  have out:=factored (k:=n.factorization 2) (d:=excess n) odd (by rwa [id])
    (fun p mem=>by rw [ss] at mem;rw [eqp p mem];exact shape p mem)
    (by rw [fi,ss];exact rank_excess pos hit low) small enough
  simpa only [fi,singles] using out

theorem original_normalized {n : ℕ} (pos : 0<n) (hit : OeisA245212.a n=(σ 1 n:ℤ))
    (low : ratio n<(98:ℚ)/27) (enough : excess n+1≤n.factorization 2) :
    let M:=2^excess n
    let X:=∏p∈singles n,s1 p
    M∣X ∧ X/M ≡ 3^(singles n).card [MOD 4] := by
  dsimp only
  have h := original_units (j:=2) pos hit low (by decide) (by omega)
  rw [pow_add] at h
  have dv := Nat.modEq_zero_iff_dvd.mp ((h.of_mul_right 4).trans
     (Nat.modEq_zero_iff_dvd.mpr (dvd_mul_right _ _)))
  refine ⟨dv,Nat.ModEq.mul_left_cancel' (Nat.two_pow_pos (excess n)).ne' ?_⟩
  rwa [Nat.mul_div_cancel' dv]

private theorem unique_one (P : Finset ℕ) (v : ℕ→ℕ) (sum : (∑p∈P,v p)=1) :
    ∃p∈P, v p=1 ∧ ∀q∈P,q≠p → v q=0 := by
  obtain ⟨p,hp,nz⟩ : ∃p∈P, 0<v p := by
    by_contra! no
    have := sum_eq_zero (s:=P) (fun p mem=>Nat.eq_zero_of_le_zero (no p mem))
    omega
  have sum' := P.sum_erase_add v hp
  change (∑q∈P.erase p,v q)+v p=(∑q∈P,v q) at sum'
  refine ⟨p,hp,by omega,?_⟩
  intro q hq ne
  have le := single_le_sum (fun (q:ℕ) (_:q∈P.erase p)=>Nat.zero_le (v q)) (mem_erase.mpr ⟨ne,hq⟩)
  omega

/-- At the second level there is a unique singly occurring prime with a half-successor
of valuation one; its residue modulo eight is three, and the whole odd part is three modulo four. -/
theorem second_level {n : ℕ} (pos : 0<n) (hit : OeisA245212.a n=(σ 1 n:ℤ))
    (even : Even n) (level : 2*(σ 0 (ordCompl[2] n))^2=3*6^(support n).card) :
    ordCompl[2] n ≡ 3 [MOD 4] ∧
    ∃p∈singles n,(s1 p).factorization 2=1 ∧ p ≡ 3 [MOD 8] ∧
      ∀q∈singles n,q≠p → (s1 q).factorization 2=0 ∧ q ≡ 1 [MOD 4] := by
  rw [OMA.SparseDivisorHeight245212.odd_count pos] at level
  have lev : ratio n=3/2 := by
    apply (div_eq_div_iff (by positivity : (6:ℚ)^(support n).card≠0) (by norm_num : (2:ℚ)≠0)).mpr
    exact_mod_cast (by simpa [mul_comm] using level :
      (OMA.OddDivisorFloor245212.lengthProd n)^2*2=3*6^(support n).card)
  have low : ratio n<98/27 := by rw [lev];norm_num
  obtain ⟨shape,cap,eq⟩ := classify pos hit low
  have d : excess n=1 := by
    have vals : excess n=0 ∨ excess n=1 ∨ excess n=2 ∨ excess n=3 := by omega
    rcases vals with h|h|h|h <;> first | exact h | (rw [lev,h] at eq;norm_num at eq)
  have k : 1≤n.factorization 2 := (Nat.prime_two.pow_dvd_iff_le_factorization pos.ne').mp
    (by simpa using even.two_dvd)
  have orig := original_units (j:=1) pos hit low (by decide) (by omega)
  rw [d] at orig
  let P := singles n
  let X := ∏p∈P,s1 p
  change X%4=(2*3^P.card)%4 at orig
  have op3:=Odd.pow (n:=P.card) (by decide : Odd 3)
  rw [Nat.odd_iff] at op3
  have modX : X%4=2 := by omega
  have xpos : X≠0 := by rintro h;rw [h] at modX;contradiction
  have valX : X.factorization 2=1 := by
    have a : 1≤X.factorization 2 := (Nat.prime_two.pow_dvd_iff_le_factorization xpos).mp
      (by change 2∣X;omega)
    have b : ¬2≤X.factorization 2 := fun h=> (show ¬4∣X by omega)
      ((Nat.prime_two.pow_dvd_iff_le_factorization xpos).mpr h)
    omega
  have non p (hp:p∈P) : s1 p≠0 := Finset.prod_ne_zero_iff.mp xpos p hp
  change (∏p∈P,s1 p).factorization 2=1 at valX
  rw [Nat.factorization_prod_apply non] at valX
  obtain ⟨p,mem,vp,rest⟩ := unique_one P (fun p=>(s1 p).factorization 2) valX
  have opd q (hq:q∈support n) : Odd q :=
    (Nat.prime_of_mem_primeFactors (mem_erase.mp hq).2).odd_of_ne_two (mem_erase.mp hq).1
  have oddP q (hq:q∈P) := opd q (mem_filter.mp hq).1
  have three : p ≡ 3 [MOD 8] := by
    have dv : 2∣s1 p := (Nat.prime_two.pow_dvd_iff_le_factorization (non p mem)).mpr vp.ge
    have nd : ¬4∣s1 p := by
      intro h
      have := (Nat.prime_two.pow_dvd_iff_le_factorization (k:=2) (non p mem)).mp h
      omega
    have := (lin p (oddP p mem)).2
    change p%8=3;omega
  have ones q (hq:q∈P) (ne:q≠p) : q ≡ 1 [MOD 4] := by
    have eq := rest q hq ne
    have nd : ¬2∣s1 q := by
      intro h
      have := (Nat.prime_two.pow_dvd_iff_le_factorization (k:=1) (non q hq)).mp h
      omega
    have := (lin q (oddP q hq)).2
    change q%4=1;omega
  refine ⟨?_,p,mem,vp,three,fun q hq ne=>⟨rest q hq ne,ones q hq ne⟩⟩
  have repr : ordCompl[2] n=∏q∈support n,q^n.factorization q := by
    have id := Nat.prod_primeFactors_pow_factorization
      (Nat.ordCompl_pos 2 pos.ne').ne'
    rw [←Nat.support_factorization,Nat.factorization_ordCompl,Finsupp.support_erase,Nat.support_factorization] at id
    refine id.trans (prod_congr rfl fun q hq=>?_ )
    rw [Finsupp.erase_ne (mem_erase.mp hq).1]
  rw [repr]
  have pm := (mem_filter.mp mem).1
  rw [←mul_prod_erase _ _ pm,(mem_filter.mp mem).2,pow_one]
  have units := OMA.CriticalResidueLocal245212.prod_mod ((support n).erase p)
    (fun q=>q^n.factorization q) (fun _=>1) 4 (fun q hq=>by
      obtain ⟨ne,hq⟩:=mem_erase.mp hq
      rcases shape q hq with h|h
      · rw [h,pow_one];exact ones q (mem_filter.mpr ⟨hq,h⟩) ne
      · rw [h];exact (sqr q (opd q hq)).2.2.2.of_dvd (by decide : 4∣8))
  simpa using (three.of_dvd (by decide : 4∣8)).mul units

#print axioms original_normalized
#print axioms second_level

end OMA.DivisorFloorStabilityResidue245212

