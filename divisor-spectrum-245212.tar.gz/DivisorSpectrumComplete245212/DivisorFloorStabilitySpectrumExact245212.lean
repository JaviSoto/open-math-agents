import DivisorFloorStabilitySpectrum245212

/-! Sharpness of the finite spectrum for exponent profiles: each listed rational
is attained by some profile satisfying the valuation inequality alone. -/
namespace OMA.DivisorFloorStabilitySpectrumExact245212
open Nat Finset OMA.DivisorFloorStabilitySpectrum245212
open private OMA.DivisorFloorStabilitySpectrum245212.unit OMA.DivisorFloorStabilitySpectrum245212.large
  OMA.DivisorFloorStabilitySpectrum245212.generate OMA.DivisorFloorStabilitySpectrum245212.grows
  from DivisorFloorStabilitySpectrum245212

def raw (e : ℕ) : ℚ := ((e:ℚ)+1)^2/6
def order (e : ℕ) := (e+2).factorization 2
def feasible (x : ℚ) : Prop :=
  ∃ es : List ℕ, (∀e∈es, 0<e) ∧ es.length≤(es.map order).sum ∧ (es.map raw).prod=x

private theorem order_one : order 1=0 := Nat.factorization_eq_zero_of_not_dvd (by decide)
private theorem order_two : order 2=2 := Nat.factorization_pow_self (n:=2) Nat.prime_two

private theorem mul {x y : ℚ} (hx : feasible x) (hy : feasible y) : feasible (x*y) := by
  obtain ⟨xs,px,bx,rx⟩:=hx;obtain ⟨ys,py,by',ry⟩:=hy
  refine ⟨xs++ys,fun e he=>(List.mem_append.mp he).elim (px e) (py e),?_,?_⟩
  · simpa using Nat.add_le_add bx by'
  · simp [rx,ry]

private theorem generator_feasible {X x : ℚ} (h : x∈generators X) : feasible x := by
  rcases mem_insert.mp h with rfl|h
  · refine ⟨[2],by simp,by simp [order_two],by norm_num [raw]⟩
  obtain ⟨e,he,rfl⟩:=mem_image.mp h
  have ep : 0<e := (by omega : ∀e:ℕ,3≤e→0<e) e (mem_Ico.mp he).1
  rcases v : order e with _|j
  · refine ⟨[e,2],by simpa using ep,by simp [v,order_two],?_⟩
    change (e+2).factorization 2=0 at v
    simp [factor,v,raw]
    ring
  · refine ⟨e::List.replicate j 1,?_,?_,?_⟩
    · intro f hf
      rcases List.mem_cons.mp hf with rfl|one
      · exact ep
      · have := List.eq_of_mem_replicate one;omega
    · simp [v,order_one]
    · simp only [List.map_cons,List.map_replicate,List.prod_cons,List.prod_replicate]
      change raw e*raw 1^j = 2^(order e)*(e+1)^2/(4*3^(order e))
      rw [v,pow_succ,pow_succ]
      have one : raw 1=(2/3:ℚ) := by norm_num [raw]
      rw [one,div_pow,raw]
      field_simp
      ring

theorem every_candidate {X x : ℚ} (h : x∈spectrum X) : x≤X ∧ feasible x := by
  obtain ⟨gen,limit⟩:=mem_filter.mp h
  refine ⟨limit,?_⟩
  suffices all : ∀k,∀y∈products X k,feasible y from all _ _ gen
  intro k
  induction k with
  | zero =>
    intro y hy
    have : y=1:=mem_singleton.mp hy
    exact ⟨[],by simp,by simp,by simp [this]⟩
  | succ k ih =>
    intro y hy
    rcases mem_union.mp hy with old|new
    · exact ih _ old
    obtain ⟨f,hf,hy⟩:=mem_biUnion.mp new
    obtain ⟨a,ha,rfl⟩:=mem_image.mp hy
    exact mul (generator_feasible hf) (ih _ (mem_filter.mp ha).1)

#print axioms every_candidate

private theorem scaled (es : List ℕ) :
    (3/2:ℚ)^(es.map order).sum*(es.map factor).prod=
    (3/2:ℚ)^es.length*(es.map raw).prod := by
  induction es with
  | nil => simp
  | cons e es ih =>
    have f : (3/2:ℚ)^order e*factor e=3/2*raw e := by
      change (3/2:ℚ)^order e*(2^order e*(e+1)^2/(4*3^order e))=3/2*raw e
      rw [div_pow,raw]
      field_simp
      ring
    simp only [List.map_cons,List.sum_cons,List.prod_cons,List.length_cons,pow_add,pow_one]
    linear_combination (3/2:ℚ)^(es.map order).sum*(es.map factor).prod*f + 3/2*raw e*ih

private theorem discard_units (es : List ℕ) (pos : ∀ e∈es,0<e) :
    ((es.filter (3≤·)).map factor).prod=(es.map factor).prod := by
  induction es with
  | nil=> rfl
  | cons e es ih =>
    have eq:=ih (fun f hf=>pos f (List.mem_cons_of_mem e hf))
    by_cases h : 3≤e
    · simp [h,eq]
    · have u:=OMA.DivisorFloorStabilitySpectrum245212.unit (pos e List.mem_cons_self) (by omega)
      simp [h,eq,u]

private theorem element_le {x : ℚ} (xs : List ℚ) (h : x∈xs) (ge : ∀ y∈xs, 1≤y) :
    x≤xs.prod := by
  induction xs with
  | nil=>simp at h
  | cons y ys ih =>
    have yp:=ge y List.mem_cons_self
    have tail z (hz:z∈ys):=ge z (List.mem_cons_of_mem y hz)
    have good:=List.one_le_prod tail
    rcases List.mem_cons.mp h with rfl|h
    · exact le_mul_of_one_le_right (zero_le_one.trans yp) good
    · exact (ih h tail).trans (le_mul_of_one_le_left (zero_le_one.trans good) yp)

/-- The enumerated set is exactly the relaxation to exponent profiles and the valuation
inequality. Feasibility here does not assert the original A245212 equation. -/
theorem spectrum_iff (X x : ℚ) : x∈spectrum X ↔ x≤X ∧ feasible x := by
  refine ⟨every_candidate,?_⟩
  rintro ⟨lim,es,pos,budget,rfl⟩
  let d:=(es.map order).sum-es.length
  let ys:=(es.filter (3≤·)).map factor
  let xs:=List.replicate d (3/2:ℚ)++ys
  have split : (es.map order).sum=es.length+d := by dsimp [d];omega
  have eqn : xs.prod=(es.map raw).prod := by
    change (List.replicate d (3/2:ℚ)++(es.filter (3≤·)).map factor).prod=_
    rw [List.prod_append,List.prod_replicate,discard_units es pos]
    apply mul_left_cancel₀ (by positivity : (3/2:ℚ)^es.length≠0)
    rw [←mul_assoc,←pow_add,←split]
    exact scaled es
  have floor : ∀ y∈xs, (3/2:ℚ)≤y := by
    intro y mem
    rcases List.mem_append.mp mem with rep|other
    · rw [List.eq_of_mem_replicate rep]
    · obtain ⟨e,he,rfl⟩:=List.mem_map.mp other
      exact (by norm_num : (3/2:ℚ)≤98/27).trans
        (OMA.DivisorFloorStabilitySpectrum245212.large (by simpa using (List.mem_filter.mp he).2))
  have allow : ∀ y∈xs,y∈generators X ∧ 3/2≤y := by
    intro y hy
    refine ⟨?_,floor y hy⟩
    rcases List.mem_append.mp hy with rep|other
    · rw [List.eq_of_mem_replicate rep];exact mem_insert_self ..
    · obtain ⟨e,he,rfl⟩:=List.mem_map.mp other
      have u:=element_le xs hy (fun z hz=>by linarith only [floor z hz])
      have upper := (exponent_lt e).trans_le (mul_le_mul_of_nonneg_left
        (u.trans (eqn.trans_le (lim.trans (Nat.le_ceil X)))) (by norm_num : (0:ℚ)≤4))
      exact mem_insert_of_mem (mem_image.mpr ⟨e,mem_Ico.mpr
        ⟨by simpa using (List.mem_filter.mp he).2,by exact_mod_cast upper⟩,rfl⟩)
  obtain ⟨gen,bound⟩:=OMA.DivisorFloorStabilitySpectrum245212.generate xs allow (eqn.trans_le lim)
  have len : xs.length≤2*⌈X⌉₊ := by
    have : (xs.length:ℚ)≤2*(⌈X⌉₊:ℕ) := by linarith only [bound,eqn,lim,Nat.le_ceil X]
    exact_mod_cast this
  exact mem_filter.mpr ⟨eqn ▸ OMA.DivisorFloorStabilitySpectrum245212.grows X len gen,lim⟩

#print axioms spectrum_iff
end OMA.DivisorFloorStabilitySpectrumExact245212
