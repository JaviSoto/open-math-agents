import DivisorFloorStability245212
import SparseDivisorHeight245212

/-! Enumerating a finite set of divisor-count ratios below a rational ceiling,
independent of the number of odd prime divisors. -/
namespace OMA.DivisorFloorStabilitySpectrum245212
open Nat Finset ArithmeticFunction OMA.FixedRankInteger245212
open OMA.OddDivisorFloor245212 (lengthProd)
open OMA.DivisorFloorStability245212 (ratio valuation excess largeCount)
open scoped ArithmeticFunction.sigma

def factor (e : ℕ) : ℚ :=
  let v:=(e+2).factorization 2
  (2:ℚ)^v*(e+1)^2/(4*3^v)

private theorem unit {e : ℕ} (ep : 0<e) (sm : e<3) : factor e=1 := by
  interval_cases e
  · rw [factor,Nat.factorization_eq_zero_of_not_dvd (by decide : ¬2∣1+2)];norm_num
  · rw [factor,show (2+2:ℕ)=2^2 by decide,Nat.factorization_pow_self Nat.prime_two];norm_num

private theorem large {e : ℕ} (h : 3≤e) : 98/27≤factor e := by
  rw [factor]
  apply (div_le_div_iff₀ (by norm_num) (by positivity)).mpr
  have := OMA.DivisorFloorStability245212.sharp_local h
  dsimp only at this
  exact_mod_cast (by simpa only [mul_assoc,mul_left_comm,mul_comm] using this :
    98*(4*3^((e+2).factorization 2))≤2^((e+2).factorization 2)*(e+1)^2*27)

/-- Quantitatively, the local factor tends to infinity with the exponent. -/
theorem exponent_lt (e : ℕ) : (e:ℚ)<4*factor e := by
  let v := (e+2).factorization 2
  have mag : 2^v≤e+2 := Nat.le_of_dvd (by omega)
    ((Nat.prime_two.pow_dvd_iff_le_factorization (by omega : e+2≠0)).mpr (le_refl v))
  have p : 3^v≤2^v*(e+2) := calc
    _ ≤ 4^v := Nat.pow_le_pow_left (by decide : 3≤4) v
    _ = 2^v*2^v := by rw [show (4:ℕ)=2*2 by decide,mul_pow]
    _ ≤ _ := Nat.mul_le_mul_left _ mag
  have q : e*3^v<2^v*(e+1)^2 := calc
    _ ≤ e*(2^v*(e+2)) := Nat.mul_le_mul_left e p
    _ = 2^v*(e*(e+2)) := by ring
    _ < _ := Nat.mul_lt_mul_of_pos_left (by nlinarith) (Nat.two_pow_pos v)
  change (e:ℚ)<4*(2^v*(e+1)^2/(4*3^v))
  rw [←mul_div_assoc,lt_div_iff₀ (by positivity)]
  have qr : (e:ℚ)*3^v<2^v*(e+1)^2 := by exact_mod_cast q
  linarith only [qr]

private theorem identity {n : ℕ} (pos : 0<n) (hit : OeisA245212.a n=(σ 1 n:ℤ)) :
    ratio n=(3/2:ℚ)^excess n *
      ∏p∈(support n).filter (fun p=>3≤n.factorization p),factor (n.factorization p) := by
  rw [prod_filter_of_ne (fun p mem nz=>by
    by_contra! sm
    exact nz (unit (Nat.pos_of_ne_zero (Finsupp.mem_support_iff.mp (mem_erase.mp mem).2)) sm))]
  have h := OMA.OddDivisorFloor245212.budget pos hit
  change (support n).card≤valuation n at h
  have split : valuation n=(support n).card+excess n := by dsimp [excess];omega
  have prod : (∏p∈support n,((n.factorization p:ℚ)+1)) = (lengthProd n:ℚ) := by
    simp [lengthProd]
  simp only [factor,prod_div_distrib,prod_mul_distrib,prod_pow_eq_pow_sum,prod_pow,prod_const,prod]
  change ratio n=_ * ((2^valuation n*(lengthProd n:ℚ)^2)/(4^(support n).card*3^valuation n))
  rw [split,ratio,div_pow]
  simp only [pow_add,show (6:ℚ)=2*3 by norm_num,show (4:ℚ)=2*2 by norm_num,mul_pow]
  field_simp

/-- All generators whose exponent can occur below the ceiling. -/
def generators (X : ℚ) : Finset ℚ :=
  insert (3/2) ((Ico 3 (4*⌈X⌉₊)).image factor)

/-- At each round keep the old products and collect only new products at most X. -/
def products (X : ℚ) : ℕ → Finset ℚ
  | 0 => {1}
  | k+1 =>
    let old:=products X k
    old ∪ (generators X).biUnion (fun f=>(old.filter (fun y=>f*y≤X)).image (f*·))

/-- A computable finite set containing every divisor-count ratio at most X.
No rank parameter enters the computation. -/
def spectrum (X : ℚ) : Finset ℚ := (products X (2*⌈X⌉₊)).filter (·≤X)

private theorem grows {j k : ℕ} (X : ℚ) (h : j≤k) : products X j⊆products X k := by
  induction h with
  | refl => exact fun _ ha=>ha
  | step _ ih => exact fun _ ha=>mem_union_left _ (ih ha)

private theorem generate {X : ℚ} (xs : List ℚ)
    (allowed : ∀x∈xs, x∈generators X ∧ 3/2≤x) (lim : xs.prod≤X) :
    xs.prod∈products X xs.length ∧ (xs.length:ℚ)/2+1≤xs.prod := by
  induction xs with
  | nil => simp [products]
  | cons x xs ih =>
    obtain ⟨inGen,ge⟩:=allowed x List.mem_cons_self
    have tail y (hy:y∈xs) := allowed y (List.mem_cons_of_mem x hy)
    have one : 1≤xs.prod := List.one_le_prod (fun y hy=>by linarith only [(tail y hy).2])
    have comp : xs.prod≤x*xs.prod := le_mul_of_one_le_left (by linarith) (by linarith)
    obtain ⟨mem,bound⟩:=ih tail (comp.trans lim)
    refine ⟨mem_union_right _ (mem_biUnion.mpr ⟨x,inGen,mem_image.mpr
      ⟨xs.prod,mem_filter.mpr ⟨mem,lim⟩,rfl⟩⟩),?_⟩
    simp only [List.length_cons,List.prod_cons,Nat.cast_add,Nat.cast_one]
    nlinarith only [bound,one,mul_nonneg (show 0≤x-3/2 by linarith) (show 0≤xs.prod by linarith)]

/-- Directly on A245212's original input and divisor count, with arbitrary odd rank. -/
theorem original {n : ℕ} (pos : 0<n) (hit : OeisA245212.a n=(σ 1 n:ℤ)) (X : ℚ)
    (bound : ((σ 0 (ordCompl[2] n):ℕ):ℚ)^2/6^(support n).card≤X) :
    ((σ 0 (ordCompl[2] n):ℕ):ℚ)^2/6^(support n).card∈spectrum X := by
  rw [OMA.SparseDivisorHeight245212.odd_count pos] at bound ⊢
  change ratio n≤X at bound
  change ratio n∈spectrum X
  let s:=(support n).filter (fun p=>3≤n.factorization p)
  let f p:=factor (n.factorization p)
  let xs:=List.replicate (excess n) (3/2:ℚ) ++ s.toList.map f
  have eqn : xs.prod=ratio n := by
    rw [identity pos hit];simp only [xs,List.prod_append,List.prod_replicate,prod_map_toList,s,f]
  have ge p (hp:p∈s) : 1≤f p := by linarith only [large (mem_filter.mp hp).2]
  have prodle : (∏p∈s,f p)≤ratio n := by
    rw [identity pos hit]
    exact le_mul_of_one_le_left (by
      have h := Finset.one_le_prod ge
      linarith) (one_le_pow₀ (by norm_num))
  have spec := generate (X:=X) xs (fun x mem=>by
    rcases List.mem_append.mp mem with rep|mapped
    · obtain rfl := List.eq_of_mem_replicate rep
      exact ⟨mem_insert_self ..,le_rfl⟩
    · obtain ⟨p,pm,rfl⟩:=List.mem_map.mp mapped
      have hp : p∈s := mem_toList.mp pm
      have small := ((exponent_lt (n.factorization p)).trans_le (mul_le_mul_of_nonneg_left
        ((le_trans (by
          rw [←mul_prod_erase _ _ hp]
          exact le_mul_of_one_le_right (zero_le_one.trans (ge p hp))
            (Finset.one_le_prod (fun q hq=>ge q (mem_erase.mp hq).2))) prodle).trans
            (bound.trans (Nat.le_ceil X))) (by norm_num : (0:ℚ)≤4)))
      exact ⟨mem_insert_of_mem (mem_image.mpr ⟨_,mem_Ico.mpr ⟨(mem_filter.mp hp).2,by exact_mod_cast small⟩,rfl⟩),
        (by norm_num : (3/2:ℚ)≤98/27).trans (large (mem_filter.mp hp).2)⟩)
    (eqn.trans_le bound)
  have len : xs.length≤2*⌈X⌉₊ := by
    have : (xs.length:ℚ)≤2*(⌈X⌉₊:ℕ) := by linarith only [spec.2,eqn,bound,Nat.le_ceil X]
    exact_mod_cast this
  exact mem_filter.mpr ⟨eqn ▸ grows X len spec.1,bound⟩

#print axioms original
end OMA.DivisorFloorStabilitySpectrum245212
