import DivisorFloorStabilitySpectrumExact245212
import DivisorFloorStabilityResidue245212

/-! The locally finite candidate spectrum for a positive A245212 solution,
with its critical and second-level residue restrictions. -/
#print axioms OMA.DivisorFloorStabilitySpectrum245212.original
#print axioms OMA.DivisorFloorStabilitySpectrumExact245212.spectrum_iff
#print axioms OMA.CriticalResidueInput245212.original
#print axioms OMA.DivisorFloorStabilityResidue245212.second_level
