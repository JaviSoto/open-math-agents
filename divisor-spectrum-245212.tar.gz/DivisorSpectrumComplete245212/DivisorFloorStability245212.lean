import OddDivisorFloor245212

/-! Stability of the odd-divisor floor in the A245212 divisor equation. The two
sources of multiplicative slack are counted separately: the excess 2-adic
valuation and the number of odd prime exponents greater than two. -/
namespace OMA.DivisorFloorStability245212
open Nat Finset ArithmeticFunction OMA.FixedRankInteger245212
open OMA.OddDivisorFloor245212 (lengthProd)
open scoped ArithmeticFunction.sigma

def valuation (n : ℕ) := ∑ p ∈ support n, (n.factorization p+2).factorization 2
def excess (n : ℕ) := valuation n-(support n).card
def largeCount (n : ℕ) := ((support n).filter fun p => 3≤n.factorization p).card

/-- The next local factor after the minimizers `e=1,2` is `98/27`. -/
theorem sharp_local {e : ℕ} (he : 3≤e) :
    let v := (e+2).factorization 2
    98*4*3^v ≤ 27*2^v*(e+1)^2 := by
  dsimp only
  generalize hv : (e+2).factorization 2=v
  have div : 2^v∣e+2 := (Nat.prime_two.pow_dvd_iff_le_factorization (by omega : e+2≠0)).mpr hv.ge
  have size:=Nat.le_of_dvd (by omega : 0<e+2) div
  rcases v with _|_|_|a
  · norm_num; nlinarith only [Nat.pow_le_pow_left (by omega : 4≤e+1) 2]
  · norm_num at div ⊢; nlinarith only [Nat.pow_le_pow_left (by omega : 5≤e+1) 2]
  · norm_num at div ⊢; nlinarith only [Nat.pow_le_pow_left (by omega : 7≤e+1) 2]
  · have p2:=Nat.two_pow_pos a
    rw [show a+1+1+1=a+3 by omega,pow_add] at size
    norm_num at size
    have width : 7*2^a≤e+1 := by omega
    have power : 3^a ≤ (2^a)^3 := by
      rw [←pow_mul,Nat.mul_comm a 3,pow_mul]
      exact Nat.pow_le_pow_left (by decide : 3≤2^3) _
    calc
      _ = 10584*3^a := by rw [show a+1+1+1=a+3 by omega,pow_add];ring
      _ ≤ 10584*(2^a)^3 := Nat.mul_le_mul_left _ power
      _ = 27*2^(a+3)*(7*2^a)^2 := by rw [pow_add];ring
      _ ≤ _ := Nat.mul_le_mul_left _ (Nat.pow_le_pow_left width 2)

theorem sharp_at_six :
    98*4*3^((6+2:ℕ).factorization 2) = 27*2^((6+2:ℕ).factorization 2)*(6+1)^2 := by
  rw [show 6+2=2^3 by decide,Nat.factorization_pow_self Nat.prime_two]
  decide

private theorem small_local {e : ℕ} (ep : 0<e) (small : e<3) :
    4*3^((e+2).factorization 2)=2^((e+2).factorization 2)*(e+1)^2 := by
  interval_cases e
  · rw [Nat.factorization_eq_zero_of_not_dvd (by decide : ¬2∣1+2)]; decide
  · rw [show 2+2=2^2 by decide,Nat.factorization_pow_self Nat.prime_two]; decide

private theorem local_factor {e : ℕ} (ep : 0<e) :
    let v:=(e+2).factorization 2
    let b:ℕ:=if 3≤e then 1 else 0
    98^b*4*3^v ≤ 27^b*2^v*(e+1)^2 := by
  dsimp only
  by_cases large : 3≤e
  · simpa [large] using sharp_local large
  · simpa [large] using (small_local ep (by omega)).le

private theorem positive {p n : ℕ} (hp : p∈support n) : 0<n.factorization p :=
  Nat.pos_of_ne_zero (Finsupp.mem_support_iff.mp (mem_erase.mp hp).2)

private theorem multiply (n : ℕ) :
    98^largeCount n*4^(support n).card*3^valuation n ≤
      27^largeCount n*2^valuation n*(lengthProd n)^2 := by
  simpa only [prod_mul_distrib,prod_pow_eq_pow_sum,prod_const,prod_pow,sum_boole,Nat.cast_id,
    valuation,largeCount,lengthProd] using
    (prod_le_prod' (s:=support n) fun p mem => local_factor (positive mem))

theorem stability {n : ℕ} (pos : 0<n) (hit : OeisA245212.a n=(σ 1 n:ℤ)) :
    98^largeCount n*3^excess n*6^(support n).card ≤
      27^largeCount n*2^excess n*(lengthProd n)^2 := by
  let r:=(support n).card
  have h:=multiply n
  have budget : r≤valuation n := OMA.OddDivisorFloor245212.budget pos hit
  have split : valuation n=r+excess n := by dsimp [excess,r] at *;omega
  change 98^largeCount n*4^r*3^valuation n ≤ 27^largeCount n*2^valuation n*(lengthProd n)^2 at h
  rw [split,pow_add,pow_add] at h
  change _*6^r≤_
  apply Nat.le_of_mul_le_mul_left ?_ (Nat.two_pow_pos r)
  convert h using 1 <;> (try simp only [show (6:ℕ)=2*3 by decide,show (4:ℕ)=2*2 by decide,mul_pow]) <;> ring

def ratio (n : ℕ) : ℚ := (lengthProd n:ℚ)^2 / 6^(support n).card

theorem ratio_stability {n : ℕ} (pos : 0<n) (hit : OeisA245212.a n=(σ 1 n:ℤ)) :
    ((98:ℚ)/27)^largeCount n*((3:ℚ)/2)^excess n ≤ ratio n := by
  rw [ratio,div_pow,div_pow,_root_.div_mul_div_comm]
  apply (div_le_div_iff₀ (by positivity) (by positivity)).mpr
  have h := stability pos hit
  exact_mod_cast (by simpa only [mul_assoc,mul_left_comm,mul_comm] using h :
    98^largeCount n*3^excess n*6^(support n).card ≤ (lengthProd n)^2*(27^largeCount n*2^excess n))

private theorem small_ratio {n : ℕ} (pos : 0<n) (hit : OeisA245212.a n=(σ 1 n:ℤ))
    (small : ∀p∈support n, n.factorization p<3) : ratio n=(3/2:ℚ)^excess n := by
  let r := (support n).card
  have h : 4^r*3^valuation n=2^valuation n*(lengthProd n)^2 := by
    simpa only [r,prod_mul_distrib,prod_const,prod_pow_eq_pow_sum,prod_pow,valuation,lengthProd] using
      (Finset.prod_congr (s₁:=support n) rfl fun p hp=>small_local (positive hp) (small p hp))
  have budget : r≤valuation n := OMA.OddDivisorFloor245212.budget pos hit
  have split : valuation n=r+excess n := by dsimp [excess,r] at *;omega
  rw [split,pow_add,pow_add] at h
  have he : 3^excess n*6^r=2^excess n*(lengthProd n)^2 := by
    apply Nat.eq_of_mul_eq_mul_left (Nat.two_pow_pos r)
    convert h using 1 <;> (try simp only [show (6:ℕ)=2*3 by decide,show (4:ℕ)=2*2 by decide,mul_pow]) <;> ring
  rw [ratio,div_pow]
  apply (div_eq_div_iff (by positivity) (by positivity)).mpr
  exact_mod_cast (by simpa only [mul_comm] using he.symm :
    (lengthProd n)^2*2^excess n=3^excess n*6^r)

/-- Below the first large-exponent threshold the valuation excess determines the ratio exactly. -/
theorem classify {n : ℕ} (pos : 0<n) (hit : OeisA245212.a n=(σ 1 n:ℤ))
    (low : ratio n<(98:ℚ)/27) :
    (∀p∈support n, n.factorization p=1 ∨ n.factorization p=2) ∧
      excess n≤3 ∧ ratio n=(3/2:ℚ)^excess n := by
  have stable := ratio_stability pos hit
  have small : ∀p∈support n, n.factorization p<3 := by
    intro p hp
    by_contra! large
    have non : 1≤largeCount n := card_pos.mpr ⟨p,mem_filter.mpr ⟨hp,large⟩⟩
    have one : 1≤(3/2:ℚ)^excess n := one_le_pow₀ (by norm_num)
    have lb : (98/27:ℚ)≤(98/27:ℚ)^largeCount n := by
      simpa using pow_le_pow_right₀ (by norm_num : 1≤(98/27:ℚ)) non
    exact low.not_ge (lb.trans ((le_mul_of_one_le_right (by positivity) one).trans stable))
  have eq := small_ratio pos hit small
  refine ⟨fun p hp=>by have := small p hp;have := positive hp;omega,?_,eq⟩
  by_contra! many
  have h := pow_le_pow_right₀ (by norm_num : 1≤(3/2:ℚ)) (show 4≤excess n by omega)
  rw [←eq] at h
  norm_num at h
  linarith

theorem forbidden {n : ℕ} (pos : 0<n) (hit : OeisA245212.a n=(σ 1 n:ℤ)) :
    ratio n=1 ∨ ratio n=3/2 ∨ ratio n=9/4 ∨ ratio n=27/8 ∨ (98:ℚ)/27≤ratio n := by
  by_cases low : ratio n<(98:ℚ)/27
  · obtain ⟨_,bound,eq⟩ := classify pos hit low
    have levels : excess n=0 ∨ excess n=1 ∨ excess n=2 ∨ excess n=3 := by omega
    rcases levels with h|h|h|h <;> rw [eq,h] <;> norm_num
  · exact Or.inr (Or.inr (Or.inr (Or.inr (le_of_not_gt low))))

#print axioms stability
#print axioms forbidden

/-- The rank and the valuation excess have the same parity below the threshold. -/
theorem rank_excess {n : ℕ} (pos : 0<n) (hit : OeisA245212.a n=(σ 1 n:ℤ))
    (low : ratio n<(98:ℚ)/27) :
    (support n).card+excess n=2*((support n).filter fun p=>n.factorization p=2).card := by
  obtain ⟨small,_,_⟩ := classify pos hit low
  have budget := OMA.OddDivisorFloor245212.budget pos hit
  change (support n).card≤valuation n at budget
  have split : (support n).card+excess n=valuation n := by dsimp [excess]; omega
  rw [split,valuation]
  calc
    _=∑p∈support n,2*(if n.factorization p=2 then 1 else 0 : ℕ) := by
      apply sum_congr rfl
      intro p hp
      rcases small p hp with h|h <;> rw [h]
      · simpa using (Nat.factorization_eq_zero_of_not_dvd (by decide : ¬2∣1+2))
      · exact Nat.factorization_pow_self (n:=2) Nat.prime_two
    _=_ := by rw [←Finset.mul_sum,sum_boole,Nat.cast_id]

theorem parity_levels {n : ℕ} (pos : 0<n) (hit : OeisA245212.a n=(σ 1 n:ℤ))
    (low : ratio n<(98:ℚ)/27) :
    (Even (support n).card → ratio n=1 ∨ ratio n=9/4) ∧
    (Odd (support n).card → ratio n=3/2 ∨ ratio n=27/8) := by
  obtain ⟨_,bound,eq⟩ := classify pos hit low
  have parity := rank_excess pos hit low
  constructor
  · rintro ⟨k,hk⟩
    have h : excess n=0 ∨ excess n=2 := by omega
    rcases h with h|h <;> rw [eq,h] <;> norm_num
  · rintro ⟨k,hk⟩
    have h : excess n=1 ∨ excess n=3 := by omega
    rcases h with h|h <;> rw [eq,h] <;> norm_num

#print axioms parity_levels

end OMA.DivisorFloorStability245212
