import BernoulliList284759
import PrattRows284759

namespace OMA.SharpCubicRows284759
open OMA.BernoulliList284759 OMA.PrattRows284759
set_option maxRecDepth 65536
set_option maxHeartbeats 0
private def data:List ℤ:=[225319534991831177328890236228992001350685163362356544091910,-112659767495915588664445118114496000675342581681178272045955,37553255831971862888148372704832000225114193893726090681985,0,-7510651166394372577629674540966400045022838778745218136397,0,5364750833138837555449767529261714317873456270532298668855,0,-7510651166394372577629674540966400045022838778745218136397,0,17069661741805392221885623956741818284142815406239132128175,0,-57031428087675950012550605580305301440777819737504898156597,0,262872790823803040217038608933824001575799357256082634773895,0,-1598001486402849741958031342039733468402800462513026705843997,0,12386080252489546686574471168743348525376574011549491879298015,0,-119222028255935253650226827388425825296498445635952844001310597,0,1395206317423729237919144800222787261233174137683024475084132535,0,-19508222371020831009085329203311707782243762221732567092375724397,0,321196865116206036384210511026816695621424887135010307390357949455,0,-6150824730299880895769732162228792478196336378991707298291881309397,0,135547922767272167164424457510248870569210022439948881652883947660775,0,-3406001239430890583518907923176466100971036890135365280708700727345597,0,96800571600223604054754546103654517692803468345932395487757149118418495,0,-3089503774778824694250380872305133631296066973649730401925772912272168997,0,110030811032612589474243740826300362732304931115966090486512303905545614615,0,-4347896284258911818314915317077941993120888815681235841474953592626991171597,0,189649886085159403800373419155978831671103338221500676473223202267954898881135,0,-9088955592623749800157404566046257091111186008233477589105797026443094460801397,0,476567684786174092546231485531691057041088397457536343594764298525550093098090055,0,-27233530676237868469475553805513635732162648268835635738975994902033716127758562397,0,1690091807261751435023173429309153671415566201214801369175907278442096047028521353375,0,-113533513875273637424643501380814662224195063430818388073104840992375701030144039014597,0,8230646931379757011942647941719117672840548963078640052931303844262575729970368245023095,0,-642132944706770575078614110412872034458707953580833421331506768166389894862212580405773997,0,53773470266099751827896358635066913841667375514667737974576420368822568404910167691195691215,0,-4821826615486795181147301553161875028914408052905155638517432985293484447760593585873559512597,0,461927031689290469186957611270511640793312270213629693754470413326347846954870887644627894189735,0,-47177417556007783496949303737197635708704062911633339057064787231029276776895714574670575061958397,0,5126626992590869447461595828152708322706776782652369748644963345046882177302628818617260511271590655,0,-591637507164572359449779527718134788684316772547968356609330274751005604739490353615315429301415895397,0,72384085609588252241248372518578025663914506304153294099004525401390354622171192132057632426751837205975,0,-9372904693003027745815177316037350406575177139220881399598607196636427194193099112729168951471489521163597,0,1282534463742381508086722435061977630008510762721397697316237454242281541061162654278975525279538223278587695,0,-185175771648068368999608135214634557027361392284303124108457753886967311932744221818245840537432328543426658997,0,28171485890446207255558999302051517144740566802709473195141081341144359218382962233456849105933453933621373527815,0,-4509901906705815579762753580828316687061514693642164848420155835240807994457395210338073173994036665889517658333597,0,758763149134776019394665824282860843553645584331029133047303117196748181937250647702599853954652296230121379894058335,0,-133999714192793873098664810918748020003581322600319089194220355639378758034413541051752586032175850398141168585763195397,0,24811985134916010740075448735190330767224078547004294728181340904129825581716718901581173414374854966717543836091982451255,0,-4811757150366383016629754601570719418399383598072282136121134142293509307271443119607598420705329162452551536480390069308397,0,976284692073894861181488603290754175336677068560037569940228309806960226681290849863979513800969600480032586751313694279218575,0,-207036044958917040734424390405183173584125478812083160433639131615341959647853698815767356876993282641573843627361746360021792597,0,45845533201692558801724403381712958247454384822239398986612649510253841360895107722166934623026357902877661364466516865523883112295,0,-10590882010257854455544143778923949154301347279336696996912432720604835473433230220301214786152943789316834004602978039119421814823997,0,2550176286153853805602545104486284832800794254522903245924994175385495808176980188129876121088235384808788203350711051140383755023124415,0,-639507527529080611573748553455493776102766053129434637064301863610727780264641768129906242263050266276431513909935003969096669801399634597,0,166881221396204453570459947526692795756787190960985212085504135925456931868195123376751865393375078100306374041501466777758503766063122486935,0,-45281238511414704647916977664805212513918113013868174497190708502935820951300648135880687141399267736925578590949610125543657419514446308512397,0,12765967209800698726594766087158008706731952344400417457318448151605282706760793396293560245627309713199120303711946738777368718566410448734671855,0,-3736814341316809791427352556826286925456939639799927365815405695990367889381367661920188031676962483308440417428682545306910521575051612159094801397,0,1134908810211361121607725783006228222161689153248007022562615977903413068859369767677833095598615461874376782606313042483544483388312285161182631391175,0,-357389864759684252035143026510877866545926440199299202557049585685392038126578195724667890586429948048711232481212379138152443229230342936404246548901597,0,116618054045968068526890127100866246714508875842625815889208514057548604234280289876755922842444504354028418255163768560418874811810051325663969406122596895,0,-39405957365462012767977613971841170566269626787252340647949741755862742694332925305064020545765639373204505345805438907994655790250147658019893639544210268997,0,13780659925121219286764610648349527030378310179843053043386319989585878415854565087523055192024623082865988019322734381024678270310936074795803970731037488481015,0,-4984693806699347918460725447701152231732278927296843271430579949300458678310795976260794255820924180153520856049166802254300862741551703845017688246772675055415597,0,1863905760153211580452115451327818055695069815112478263354958663070108030967362676124495855598836368558354510203633896782091773916389450751467395143505254696203475535,0,-720097014494294408307547890446425301411613624738504776016419312010761112091776666019778378079756766013527578088782120468354274507867755795482363131181216482944601909397,0,287284259768135047872543411493008872625080199019796917445119450521318573878114440805344311002801891571164357601123880634624173262857577725261782015463493077890161432252455,0,-118294835765538417694757506775403382561042889325123901537623807173572680265761997272278840355457968028788427395860500804331933281887443436844130462122247164683675562028374397,0,50250352374030225743105852809400086848763640665775968177682497231643388886382198900127311056834262422057913682667503136427226804651635496789952746314712244072511224630077723775,0,-22010231057382161232576733482274492531908005889166422590416742506063106763903000485097801862530430926586761854884604373453902083223460930701746764026990449733912841755308270490597,0,9936222414886467976916339470510968841417524142917190471477854811853826454361960717187714980885335895916224611397902557180910214182601939541046782678457822779569162642527332461041495,0,-4620981655485095412757094388617139471659706403696531861681106704086708055383646364247906068580250107267969979559967883193288397471221586073908257591653066652941096870273136547412993997,0,2212963043608879916572833023216515971437155941675744506594866027534711429689369846127007472839406188469394883011086999777964649004256293212619881983839461581537415948358461428900513597615,0,-1090830469959757983814314986679084257332023669556150424303756819452271641624990269517132113569847808824682743211772011472667338224167692279927058563221382077619899212827588888018197057676597,0,553229055136283248453218821744202007009897756205171930857336565970574060810970786008669329945272530287471360528347024847269238587328253377675638891200078662946938531659633078670466664161024135,0,-288565079217079390425961491030303377787883699601388751273956718517636881096632306008522791282898514810326474328127363083686337941657837209474026865260137416921748370232606980709197889536707386397,0,154740820370452176125046039205645704148352682740765522273395912072131810242719423415197276642884371974222408201077684740079962874344240085005810066465625155738569850450718582460136062999576379193055,0,-85275487019722269636651514666209634951539332414963185647007971878211144688845707430014589680352762838705501328712009846877113436860327427200102674091393126189426838024180219657377607694061740566027397,0,48277191704877959112318274765214961921132483063572214923725920908136796670185893292192178689710463475302772909867607282061501074588144236811978877596670947173634905256409082852144287419536559936202216375,0,-28067439660703545735174332957723219799579705980723364855505753021716910320529430130416572363249041300588873541094628753793747769152308499920792874525069044101428944727129768309511233335844278779172514559597,0,16751558279592825601222849982678581130175400736918443056050539059207218249711141095703675928701347598254573561020447456742894813750935385700905710887098687456522093797551940190887165892498687948373091762446095]
private theorem checked:∀j:Fin 155, row data j=if (j:ℕ)=0 then (225319534991831177328890236228992001350685163362356544091910:ℤ) else 0:=by decide +kernel
theorem prime2213 : Nat.Prime 2213 := by
  apply lucas_primality 2213 (2:ZMod 2213)
  · exact eq_one [false,false,true,false,false,true,false,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 2213)^((2213-1)/2)≠1:=
    ne_one [false,true,false,false,true,false,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w7:(2:ZMod 2213)^((2213-1)/7)≠1:=
    ne_one [false,false,true,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w79:(2:ZMod 2213)^((2213-1)/79)≠1:=
    ne_one [false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (2213-1)=2*(2*(7*(79))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  have eqn:q=79:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w79
theorem prime125929 : Nat.Prime 125929 := by
  apply lucas_primality 125929 (13:ZMod 125929)
  · exact eq_one [false,false,false,true,false,true,true,true,true,true,false,true,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(13:ZMod 125929)^((125929-1)/2)≠1:=
    ne_one [false,false,true,false,true,true,true,true,true,false,true,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(13:ZMod 125929)^((125929-1)/3)≠1:=
    ne_one [false,false,false,true,true,true,true,true,true,true,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w11:(13:ZMod 125929)^((125929-1)/11)≠1:=
    ne_one [false,false,false,true,true,true,false,true,false,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w53:(13:ZMod 125929)^((125929-1)/53)≠1:=
    ne_one [false,false,false,true,false,false,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (125929-1)=2*(2*(2*(3*(3*(3*(11*(53))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w11
  have eqn:q=53:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w53
theorem prime1569473 : Nat.Prime 1569473 := by
  apply lucas_primality 1569473 (3:ZMod 1569473)
  · exact eq_one [false,false,false,false,false,false,true,true,false,true,false,false,true,true,true,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 1569473)^((1569473-1)/2)≠1:=
    ne_one [false,false,false,false,false,true,true,false,true,false,false,true,true,true,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w137:(3:ZMod 1569473)^((1569473-1)/137)≠1:=
    ne_one [false,false,false,false,false,false,true,true,false,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w179:(3:ZMod 1569473)^((1569473-1)/179)≠1:=
    ne_one [false,false,false,false,false,false,true,false,false,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (1569473-1)=2*(2*(2*(2*(2*(2*(137*(179))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=137:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w137
  have eqn:q=179:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w179
theorem prime2683 : Nat.Prime 2683 := by
  apply lucas_primality 2683 (2:ZMod 2683)
  · exact eq_one [false,true,false,true,true,true,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 2683)^((2683-1)/2)≠1:=
    ne_one [true,false,true,true,true,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(2:ZMod 2683)^((2683-1)/3)≠1:=
    ne_one [false,true,true,true,true,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w149:(2:ZMod 2683)^((2683-1)/149)≠1:=
    ne_one [false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (2683-1)=2*(3*(3*(149))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=149:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w149
theorem prime9337 : Nat.Prime 9337 := by
  apply lucas_primality 9337 (5:ZMod 9337)
  · exact eq_one [false,false,false,true,true,true,true,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 9337)^((9337-1)/2)≠1:=
    ne_one [false,false,true,true,true,true,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(5:ZMod 9337)^((9337-1)/3)≠1:=
    ne_one [false,false,false,true,false,true,false,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w389:(5:ZMod 9337)^((9337-1)/389)≠1:=
    ne_one [false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (9337-1)=2*(2*(2*(3*(389)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=389:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w389
theorem prime384785986561 : Nat.Prime 384785986561 := by
  apply lucas_primality 384785986561 (31:ZMod 384785986561)
  · exact eq_one [false,false,false,false,false,false,false,false,false,false,true,false,true,true,false,false,false,false,false,true,false,false,false,false,true,true,true,false,true,false,false,true,true,false,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(31:ZMod 384785986561)^((384785986561-1)/2)≠1:=
    ne_one [false,false,false,false,false,false,false,false,false,true,false,true,true,false,false,false,false,false,true,false,false,false,false,true,true,true,false,true,false,false,true,true,false,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(31:ZMod 384785986561)^((384785986561-1)/3)≠1:=
    ne_one [false,false,false,false,false,false,false,false,false,false,true,true,true,true,false,true,false,true,false,false,false,false,false,false,true,false,true,true,true,false,true,true,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w5:(31:ZMod 384785986561)^((384785986561-1)/5)≠1:=
    ne_one [false,false,false,false,false,false,false,false,false,false,true,false,false,true,false,true,true,false,false,false,false,false,false,false,true,true,false,true,false,true,true,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w2683:(31:ZMod 384785986561)^((384785986561-1)/2683)≠1:=
    ne_one [false,false,false,false,false,false,false,false,false,false,true,true,true,false,true,false,false,false,true,true,false,false,false,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w9337:(31:ZMod 384785986561)^((384785986561-1)/9337)≠1:=
    ne_one [false,false,false,false,false,false,false,false,false,false,true,false,true,false,true,true,false,false,true,false,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (384785986561-1)=2*(2*(2*(2*(2*(2*(2*(2*(2*(2*(3*(5*(2683*(9337))))))))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2683:=(Nat.prime_dvd_prime_iff_eq hp prime2683).mp leaf; rw [eqn]; exact w2683
  have eqn:q=9337:=(Nat.prime_dvd_prime_iff_eq hp prime9337).mp hd; rw [eqn]; exact w9337
theorem prime3449 : Nat.Prime 3449 := by
  apply lucas_primality 3449 (3:ZMod 3449)
  · exact eq_one [false,false,false,true,true,true,true,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 3449)^((3449-1)/2)≠1:=
    ne_one [false,false,true,true,true,true,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w431:(3:ZMod 3449)^((3449-1)/431)≠1:=
    ne_one [false,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (3449-1)=2*(2*(2*(431))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  have eqn:q=431:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w431
theorem prime165553 : Nat.Prime 165553 := by
  apply lucas_primality 165553 (5:ZMod 165553)
  · exact eq_one [false,false,false,false,true,true,false,true,false,true,true,false,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 165553)^((165553-1)/2)≠1:=
    ne_one [false,false,false,true,true,false,true,false,true,true,false,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(5:ZMod 165553)^((165553-1)/3)≠1:=
    ne_one [false,false,false,false,true,false,false,true,true,true,true,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3449:(5:ZMod 165553)^((165553-1)/3449)≠1:=
    ne_one [false,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (165553-1)=2*(2*(2*(2*(3*(3449))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=3449:=(Nat.prime_dvd_prime_iff_eq hp prime3449).mp hd; rw [eqn]; exact w3449
theorem prime993319 : Nat.Prime 993319 := by
  apply lucas_primality 993319 (3:ZMod 993319)
  · exact eq_one [false,true,true,false,false,true,false,false,false,false,false,true,false,true,false,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 993319)^((993319-1)/2)≠1:=
    ne_one [true,true,false,false,true,false,false,false,false,false,true,false,true,false,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 993319)^((993319-1)/3)≠1:=
    ne_one [false,true,false,false,false,true,true,false,true,false,true,true,false,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w165553:(3:ZMod 993319)^((993319-1)/165553)≠1:=
    ne_one [false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (993319-1)=2*(3*(165553)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=165553:=(Nat.prime_dvd_prime_iff_eq hp prime165553).mp hd; rw [eqn]; exact w165553
theorem prime29799571 : Nat.Prime 29799571 := by
  apply lucas_primality 29799571 (2:ZMod 29799571)
  · exact eq_one [false,true,false,false,true,false,false,true,false,false,true,false,true,true,false,true,false,true,true,false,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 29799571)^((29799571-1)/2)≠1:=
    ne_one [true,false,false,true,false,false,true,false,false,true,false,true,true,false,true,false,true,true,false,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(2:ZMod 29799571)^((29799571-1)/3)≠1:=
    ne_one [false,true,true,false,false,false,false,true,true,false,false,false,true,false,false,true,true,true,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(2:ZMod 29799571)^((29799571-1)/5)≠1:=
    ne_one [false,true,false,true,false,true,true,true,false,false,false,false,true,true,true,true,false,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w993319:(2:ZMod 29799571)^((29799571-1)/993319)≠1:=
    ne_one [false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (29799571-1)=2*(3*(5*(993319))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  have eqn:q=993319:=(Nat.prime_dvd_prime_iff_eq hp prime993319).mp hd; rw [eqn]; exact w993319
theorem prime2269 : Nat.Prime 2269 := by
  apply lucas_primality 2269 (2:ZMod 2269)
  · exact eq_one [false,false,true,true,true,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 2269)^((2269-1)/2)≠1:=
    ne_one [false,true,true,true,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(2:ZMod 2269)^((2269-1)/3)≠1:=
    ne_one [false,false,true,false,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w7:(2:ZMod 2269)^((2269-1)/7)≠1:=
    ne_one [false,false,true,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (2269-1)=2*(2*(3*(3*(3*(3*(7)))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w7
theorem prime22691 : Nat.Prime 22691 := by
  apply lucas_primality 22691 (2:ZMod 22691)
  · exact eq_one [false,true,false,false,false,true,false,true,false,false,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 22691)^((22691-1)/2)≠1:=
    ne_one [true,false,false,false,true,false,true,false,false,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(2:ZMod 22691)^((22691-1)/5)≠1:=
    ne_one [false,true,false,true,true,true,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w2269:(2:ZMod 22691)^((22691-1)/2269)≠1:=
    ne_one [false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (22691-1)=2*(5*(2269)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  have eqn:q=2269:=(Nat.prime_dvd_prime_iff_eq hp prime2269).mp hd; rw [eqn]; exact w2269
theorem prime49633 : Nat.Prime 49633 := by
  apply lucas_primality 49633 (5:ZMod 49633)
  · exact eq_one [false,false,false,false,false,true,true,true,true,false,false,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 49633)^((49633-1)/2)≠1:=
    ne_one [false,false,false,false,true,true,true,true,false,false,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(5:ZMod 49633)^((49633-1)/3)≠1:=
    ne_one [false,false,false,false,false,true,false,true,false,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w11:(5:ZMod 49633)^((49633-1)/11)≠1:=
    ne_one [false,false,false,false,false,true,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w47:(5:ZMod 49633)^((49633-1)/47)≠1:=
    ne_one [false,false,false,false,false,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (49633-1)=2*(2*(2*(2*(2*(3*(11*(47))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w11
  have eqn:q=47:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w47
theorem prime746069 : Nat.Prime 746069 := by
  apply lucas_primality 746069 (2:ZMod 746069)
  · exact eq_one [false,false,true,false,true,false,true,false,false,true,false,false,false,true,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 746069)^((746069-1)/2)≠1:=
    ne_one [false,true,false,true,false,true,false,false,true,false,false,false,true,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w37:(2:ZMod 746069)^((746069-1)/37)≠1:=
    ne_one [false,false,true,false,false,false,true,true,false,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w71:(2:ZMod 746069)^((746069-1)/71)≠1:=
    ne_one [false,false,true,true,false,false,false,false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (746069-1)=2*(2*(37*(71*(71)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=37:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w37
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=71:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w71
  have eqn:q=71:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w71
theorem prime4973 : Nat.Prime 4973 := by
  apply lucas_primality 4973 (2:ZMod 4973)
  · exact eq_one [false,false,true,true,false,true,true,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 4973)^((4973-1)/2)≠1:=
    ne_one [false,true,true,false,true,true,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w11:(2:ZMod 4973)^((4973-1)/11)≠1:=
    ne_one [false,false,true,false,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w113:(2:ZMod 4973)^((4973-1)/113)≠1:=
    ne_one [false,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (4973-1)=2*(2*(11*(113))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w11
  have eqn:q=113:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w113
theorem prime7966747 : Nat.Prime 7966747 := by
  apply lucas_primality 7966747 (5:ZMod 7966747)
  · exact eq_one [false,true,false,true,true,false,false,false,false,false,false,false,true,false,false,true,true,false,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 7966747)^((7966747-1)/2)≠1:=
    ne_one [true,false,true,true,false,false,false,false,false,false,false,true,false,false,true,true,false,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(5:ZMod 7966747)^((7966747-1)/3)≠1:=
    ne_one [false,true,true,true,true,false,true,false,true,false,true,false,false,false,false,true,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w89:(5:ZMod 7966747)^((7966747-1)/89)≠1:=
    ne_one [false,true,false,true,false,true,false,true,true,false,true,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w4973:(5:ZMod 7966747)^((7966747-1)/4973)≠1:=
    ne_one [false,true,false,false,false,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (7966747-1)=2*(3*(3*(89*(4973)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=89:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w89
  have eqn:q=4973:=(Nat.prime_dvd_prime_iff_eq hp prime4973).mp hd; rw [eqn]; exact w4973
theorem prime1566390498126627061003987 : Nat.Prime 1566390498126627061003987 := by
  apply lucas_primality 1566390498126627061003987 (3:ZMod 1566390498126627061003987)
  · exact eq_one [false,true,false,false,true,false,true,true,false,true,true,false,true,true,true,false,false,true,false,true,true,true,false,false,false,false,true,true,false,false,false,false,false,false,false,false,false,true,false,true,true,false,false,true,false,false,false,false,true,false,true,false,true,true,true,true,false,true,false,false,true,true,false,false,false,true,false,false,true,true,false,true,true,true,false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 1566390498126627061003987)^((1566390498126627061003987-1)/2)≠1:=
    ne_one [true,false,false,true,false,true,true,false,true,true,false,true,true,true,false,false,true,false,true,true,true,false,false,false,false,true,true,false,false,false,false,false,false,false,false,false,true,false,true,true,false,false,true,false,false,false,false,true,false,true,false,true,true,true,true,false,true,false,false,true,true,false,false,false,true,false,false,true,true,false,true,true,true,false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 1566390498126627061003987)^((1566390498126627061003987-1)/3)≠1:=
    ne_one [false,true,true,false,false,false,true,false,false,true,false,false,true,false,true,true,false,false,false,true,false,true,true,false,true,false,false,true,true,false,true,false,true,false,true,false,true,true,false,false,true,true,false,false,false,false,false,false,true,true,true,false,false,true,false,true,true,true,false,true,true,true,false,true,false,false,false,false,true,false,false,true,false,true,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w13:(3:ZMod 1566390498126627061003987)^((1566390498126627061003987-1)/13)≠1:=
    ne_one [false,true,false,true,true,false,false,true,true,true,false,true,false,true,true,false,true,false,false,true,false,false,true,true,false,true,false,true,false,false,false,true,true,false,true,true,true,true,false,true,false,false,false,false,false,false,false,false,true,false,false,true,false,false,false,true,false,false,true,true,true,false,true,true,true,true,false,false,false,false,false,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w22691:(3:ZMod 1566390498126627061003987)^((1566390498126627061003987-1)/22691)≠1:=
    ne_one [false,true,true,false,false,false,false,false,true,false,false,false,false,false,true,false,true,false,true,true,true,false,true,true,true,true,false,true,true,false,true,true,false,false,false,false,false,false,false,true,false,false,true,false,false,true,false,true,false,false,false,false,false,false,false,false,false,true,true,true,true,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w49633:(3:ZMod 1566390498126627061003987)^((1566390498126627061003987-1)/49633)≠1:=
    ne_one [false,true,false,false,true,false,false,false,true,false,true,false,true,true,true,false,true,false,false,false,true,true,false,true,true,true,true,false,false,false,false,true,false,false,true,true,true,false,true,false,false,true,true,false,true,true,false,true,true,false,false,true,true,true,true,true,true,false,true,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w746069:(3:ZMod 1566390498126627061003987)^((1566390498126627061003987-1)/746069)≠1:=
    ne_one [false,true,false,true,false,false,false,true,true,false,false,false,false,true,false,true,false,false,false,false,false,false,true,false,false,false,false,true,false,true,false,false,true,true,true,false,true,false,true,true,false,true,false,false,false,false,false,false,true,true,false,false,false,true,false,false,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w7966747:(3:ZMod 1566390498126627061003987)^((1566390498126627061003987-1)/7966747)≠1:=
    ne_one [false,true,true,false,true,false,false,true,true,false,true,false,false,false,false,true,false,true,true,false,false,false,false,true,true,false,true,true,true,true,true,false,false,true,true,false,false,false,true,false,true,false,true,false,false,false,false,true,false,true,false,true,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (1566390498126627061003987-1)=2*(3*(3*(13*(22691*(49633*(746069*(7966747))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=13:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w13
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=22691:=(Nat.prime_dvd_prime_iff_eq hp prime22691).mp leaf; rw [eqn]; exact w22691
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=49633:=(Nat.prime_dvd_prime_iff_eq hp prime49633).mp leaf; rw [eqn]; exact w49633
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=746069:=(Nat.prime_dvd_prime_iff_eq hp prime746069).mp leaf; rw [eqn]; exact w746069
  have eqn:q=7966747:=(Nat.prime_dvd_prime_iff_eq hp prime7966747).mp hd; rw [eqn]; exact w7966747
theorem prime15663904981266270610039871 : Nat.Prime 15663904981266270610039871 := by
  apply lucas_primality 15663904981266270610039871 (11:ZMod 15663904981266270610039871)
  · exact eq_one [false,true,true,true,true,true,false,false,false,false,true,false,false,true,false,true,false,false,false,true,false,false,true,false,false,true,false,true,true,true,true,false,false,false,false,false,false,false,true,false,false,false,false,false,false,true,true,false,false,true,false,false,true,false,false,true,true,false,true,true,true,true,true,true,true,false,true,false,true,true,true,true,false,false,true,false,true,true,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(11:ZMod 15663904981266270610039871)^((15663904981266270610039871-1)/2)≠1:=
    ne_one [true,true,true,true,true,false,false,false,false,true,false,false,true,false,true,false,false,false,true,false,false,true,false,false,true,false,true,true,true,true,false,false,false,false,false,false,false,true,false,false,false,false,false,false,true,true,false,false,true,false,false,true,false,false,true,true,false,true,true,true,true,true,true,true,false,true,false,true,true,true,true,false,false,true,false,true,true,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w5:(11:ZMod 15663904981266270610039871)^((15663904981266270610039871-1)/5)≠1:=
    ne_one [false,true,true,false,false,true,false,true,true,false,true,true,false,true,true,true,false,false,true,false,true,true,true,false,false,false,false,true,true,false,false,false,false,false,false,false,false,false,true,false,true,true,false,false,true,false,false,false,false,true,false,true,false,true,true,true,true,false,true,false,false,true,true,false,false,false,true,false,false,true,true,false,true,true,true,false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w1566390498126627061003987:(11:ZMod 15663904981266270610039871)^((15663904981266270610039871-1)/1566390498126627061003987)≠1:=
    ne_one [false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (15663904981266270610039871-1)=2*(5*(1566390498126627061003987)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  have eqn:q=1566390498126627061003987:=(Nat.prime_dvd_prime_iff_eq hp prime1566390498126627061003987).mp hd; rw [eqn]; exact w1566390498126627061003987
theorem prime83697900175217338619182484215561594711 : Nat.Prime 83697900175217338619182484215561594711 := by
  apply lucas_primality 83697900175217338619182484215561594711 (3:ZMod 83697900175217338619182484215561594711)
  · exact eq_one [false,true,true,false,true,false,true,false,true,true,true,false,false,true,false,false,false,true,true,false,true,true,false,true,false,false,true,true,true,false,false,false,false,true,true,false,true,false,false,false,true,true,true,true,true,true,false,true,false,true,true,false,false,false,false,false,false,true,false,false,false,false,true,true,true,false,true,false,false,false,true,true,false,false,false,false,true,true,true,false,false,true,false,false,true,false,true,true,true,false,false,false,false,false,true,true,false,false,true,false,true,false,false,false,true,false,false,false,false,true,false,true,true,true,true,false,true,true,true,true,false,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 83697900175217338619182484215561594711)^((83697900175217338619182484215561594711-1)/2)≠1:=
    ne_one [true,true,false,true,false,true,false,true,true,true,false,false,true,false,false,false,true,true,false,true,true,false,true,false,false,true,true,true,false,false,false,false,true,true,false,true,false,false,false,true,true,true,true,true,true,false,true,false,true,true,false,false,false,false,false,false,true,false,false,false,false,true,true,true,false,true,false,false,false,true,true,false,false,false,false,true,true,true,false,false,true,false,false,true,false,true,true,true,false,false,false,false,false,true,true,false,false,true,false,true,false,false,false,true,false,false,false,false,true,false,true,true,true,true,false,true,true,true,true,false,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 83697900175217338619182484215561594711)^((83697900175217338619182484215561594711-1)/3)≠1:=
    ne_one [false,true,false,false,true,true,true,false,false,true,false,false,false,true,true,false,true,true,true,false,false,true,true,true,false,true,true,true,true,false,true,false,true,true,true,false,false,false,false,false,true,false,true,false,true,false,false,true,true,true,true,false,true,false,true,false,true,true,false,true,false,true,true,true,true,false,false,false,false,false,true,false,false,false,false,false,true,false,true,true,false,false,false,false,true,true,true,true,true,false,true,false,true,false,false,true,true,false,false,false,true,true,false,true,true,false,true,false,true,true,false,false,true,false,true,true,true,true,true,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(3:ZMod 83697900175217338619182484215561594711)^((83697900175217338619182484215561594711-1)/5)≠1:=
    ne_one [false,true,true,true,true,false,true,true,true,true,true,false,false,false,false,false,false,true,true,true,true,true,false,true,true,false,true,false,false,false,false,false,false,true,true,true,true,false,false,true,false,false,true,true,false,false,false,true,false,false,true,false,true,true,false,false,true,false,true,true,false,false,false,true,true,true,true,false,false,true,false,false,false,false,false,false,true,true,false,true,true,true,false,false,false,false,true,true,false,true,true,false,false,true,false,false,false,false,true,false,false,false,false,false,true,false,true,true,false,true,true,true,true,true,true,false,true,false,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w43:(3:ZMod 83697900175217338619182484215561594711)^((83697900175217338619182484215561594711-1)/43)≠1:=
    ne_one [false,true,false,false,false,false,false,false,true,false,true,false,true,true,true,true,true,true,true,false,false,true,false,false,false,true,false,false,false,false,true,false,true,false,false,false,false,true,false,true,false,false,true,true,false,true,true,true,true,false,true,true,true,false,false,false,true,true,true,false,true,true,false,true,true,false,true,false,true,true,true,false,true,true,true,false,true,false,false,true,true,true,false,true,false,true,false,true,true,true,true,true,false,true,true,false,false,true,true,false,false,false,false,false,false,false,false,false,false,true,true,true,false,true,true,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w139:(3:ZMod 83697900175217338619182484215561594711)^((83697900175217338619182484215561594711-1)/139)≠1:=
    ne_one [false,true,false,false,false,false,true,true,false,true,false,true,true,true,true,true,false,true,false,true,false,false,true,false,false,false,true,true,true,false,true,false,false,false,true,true,false,true,false,false,true,false,true,false,true,false,true,true,true,false,false,true,true,false,false,false,false,false,true,true,true,false,false,true,true,true,false,false,true,true,true,false,false,true,true,false,true,false,true,true,false,true,false,true,true,false,true,true,true,false,false,false,false,false,true,false,true,true,false,false,true,true,true,true,true,true,true,false,true,true,true,true,true,true,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w29799571:(3:ZMod 83697900175217338619182484215561594711)^((83697900175217338619182484215561594711-1)/29799571)≠1:=
    ne_one [false,true,false,false,true,false,false,false,true,true,true,false,true,false,true,true,false,true,false,false,true,false,true,false,false,false,true,true,false,true,false,false,true,true,false,false,true,false,false,false,false,true,false,true,false,true,false,true,true,false,true,false,true,false,false,false,false,false,true,false,true,true,false,false,true,true,true,true,false,false,false,false,true,true,false,false,false,true,true,true,true,false,false,false,false,true,true,false,true,true,false,false,true,true,true,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w15663904981266270610039871:(3:ZMod 83697900175217338619182484215561594711)^((83697900175217338619182484215561594711-1)/15663904981266270610039871)≠1:=
    ne_one [false,true,false,true,false,true,false,false,true,true,false,true,false,false,false,true,true,true,false,false,false,true,false,false,true,false,false,true,true,false,false,false,false,false,true,true,true,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (83697900175217338619182484215561594711-1)=2*(3*(5*(43*(139*(29799571*(15663904981266270610039871)))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=43:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w43
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=139:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w139
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=29799571:=(Nat.prime_dvd_prime_iff_eq hp prime29799571).mp leaf; rw [eqn]; exact w29799571
  have eqn:q=15663904981266270610039871:=(Nat.prime_dvd_prime_iff_eq hp prime15663904981266270610039871).mp hd; rw [eqn]; exact w15663904981266270610039871
theorem prime13879 : Nat.Prime 13879 := by
  apply lucas_primality 13879 (6:ZMod 13879)
  · exact eq_one [false,true,true,false,true,true,false,false,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(6:ZMod 13879)^((13879-1)/2)≠1:=
    ne_one [true,true,false,true,true,false,false,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(6:ZMod 13879)^((13879-1)/3)≠1:=
    ne_one [false,true,false,false,true,false,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w257:(6:ZMod 13879)^((13879-1)/257)≠1:=
    ne_one [false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (13879-1)=2*(3*(3*(3*(257)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=257:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w257
theorem prime1399 : Nat.Prime 1399 := by
  apply lucas_primality 1399 (13:ZMod 1399)
  · exact eq_one [false,true,true,false,true,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(13:ZMod 1399)^((1399-1)/2)≠1:=
    ne_one [true,true,false,true,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(13:ZMod 1399)^((1399-1)/3)≠1:=
    ne_one [false,true,false,false,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w233:(13:ZMod 1399)^((1399-1)/233)≠1:=
    ne_one [false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (1399-1)=2*(3*(233)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=233:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w233
theorem prime1019 : Nat.Prime 1019 := by
  apply lucas_primality 1019 (2:ZMod 1019)
  · exact eq_one [false,true,false,true,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 1019)^((1019-1)/2)≠1:=
    ne_one [true,false,true,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w509:(2:ZMod 1019)^((1019-1)/509)≠1:=
    ne_one [false,true] (by decide +kernel) (by decide +kernel)
  rw [show (1019-1)=2*(509) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  have eqn:q=509:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w509
theorem prime2039 : Nat.Prime 2039 := by
  apply lucas_primality 2039 (7:ZMod 2039)
  · exact eq_one [false,true,true,false,true,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(7:ZMod 2039)^((2039-1)/2)≠1:=
    ne_one [true,true,false,true,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w1019:(7:ZMod 2039)^((2039-1)/1019)≠1:=
    ne_one [false,true] (by decide +kernel) (by decide +kernel)
  rw [show (2039-1)=2*(1019) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  have eqn:q=1019:=(Nat.prime_dvd_prime_iff_eq hp prime1019).mp hd; rw [eqn]; exact w1019
theorem prime4079 : Nat.Prime 4079 := by
  apply lucas_primality 4079 (11:ZMod 4079)
  · exact eq_one [false,true,true,true,false,true,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(11:ZMod 4079)^((4079-1)/2)≠1:=
    ne_one [true,true,true,false,true,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w2039:(11:ZMod 4079)^((4079-1)/2039)≠1:=
    ne_one [false,true] (by decide +kernel) (by decide +kernel)
  rw [show (4079-1)=2*(2039) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  have eqn:q=2039:=(Nat.prime_dvd_prime_iff_eq hp prime2039).mp hd; rw [eqn]; exact w2039
theorem prime1847 : Nat.Prime 1847 := by
  apply lucas_primality 1847 (5:ZMod 1847)
  · exact eq_one [false,true,true,false,true,true,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 1847)^((1847-1)/2)≠1:=
    ne_one [true,true,false,true,true,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w13:(5:ZMod 1847)^((1847-1)/13)≠1:=
    ne_one [false,true,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w71:(5:ZMod 1847)^((1847-1)/71)≠1:=
    ne_one [false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (1847-1)=2*(13*(71)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=13:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w13
  have eqn:q=71:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w71
theorem prime11083 : Nat.Prime 11083 := by
  apply lucas_primality 11083 (2:ZMod 11083)
  · exact eq_one [false,true,false,true,false,false,true,false,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 11083)^((11083-1)/2)≠1:=
    ne_one [true,false,true,false,false,true,false,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(2:ZMod 11083)^((11083-1)/3)≠1:=
    ne_one [false,true,true,true,false,true,true,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w1847:(2:ZMod 11083)^((11083-1)/1847)≠1:=
    ne_one [false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (11083-1)=2*(3*(1847)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=1847:=(Nat.prime_dvd_prime_iff_eq hp prime1847).mp hd; rw [eqn]; exact w1847
theorem prime1263463 : Nat.Prime 1263463 := by
  apply lucas_primality 1263463 (3:ZMod 1263463)
  · exact eq_one [false,true,true,false,false,true,true,false,true,true,true,false,false,false,true,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 1263463)^((1263463-1)/2)≠1:=
    ne_one [true,true,false,false,true,true,false,true,true,true,false,false,false,true,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 1263463)^((1263463-1)/3)≠1:=
    ne_one [false,true,false,false,false,true,false,false,true,false,true,true,false,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w19:(3:ZMod 1263463)^((1263463-1)/19)≠1:=
    ne_one [false,true,false,false,false,false,true,true,true,true,false,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w11083:(3:ZMod 1263463)^((1263463-1)/11083)≠1:=
    ne_one [false,true,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (1263463-1)=2*(3*(19*(11083))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=19:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w19
  have eqn:q=11083:=(Nat.prime_dvd_prime_iff_eq hp prime11083).mp hd; rw [eqn]; exact w11083
theorem prime2029 : Nat.Prime 2029 := by
  apply lucas_primality 2029 (2:ZMod 2029)
  · exact eq_one [false,false,true,true,false,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 2029)^((2029-1)/2)≠1:=
    ne_one [false,true,true,false,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(2:ZMod 2029)^((2029-1)/3)≠1:=
    ne_one [false,false,true,false,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w13:(2:ZMod 2029)^((2029-1)/13)≠1:=
    ne_one [false,false,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (2029-1)=2*(2*(3*(13*(13)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=13:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w13
  have eqn:q=13:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w13
theorem prime8117 : Nat.Prime 8117 := by
  apply lucas_primality 8117 (2:ZMod 8117)
  · exact eq_one [false,false,true,false,true,true,false,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 8117)^((8117-1)/2)≠1:=
    ne_one [false,true,false,true,true,false,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w2029:(2:ZMod 8117)^((8117-1)/2029)≠1:=
    ne_one [false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (8117-1)=2*(2*(2029)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  have eqn:q=2029:=(Nat.prime_dvd_prime_iff_eq hp prime2029).mp hd; rw [eqn]; exact w2029
theorem prime88345429 : Nat.Prime 88345429 := by
  apply lucas_primality 88345429 (2:ZMod 88345429)
  · exact eq_one [false,false,true,false,true,false,true,false,true,true,false,true,false,false,false,false,false,false,true,false,false,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 88345429)^((88345429-1)/2)≠1:=
    ne_one [false,true,false,true,false,true,false,true,true,false,true,false,false,false,false,false,false,true,false,false,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(2:ZMod 88345429)^((88345429-1)/3)≠1:=
    ne_one [false,false,true,true,true,false,false,false,true,false,false,true,true,false,true,false,true,false,false,false,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w907:(2:ZMod 88345429)^((88345429-1)/907)≠1:=
    ne_one [false,false,true,true,true,true,true,false,false,false,true,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w8117:(2:ZMod 88345429)^((88345429-1)/8117)≠1:=
    ne_one [false,false,true,false,false,false,false,true,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (88345429-1)=2*(2*(3*(907*(8117)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=907:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w907
  have eqn:q=8117:=(Nat.prime_dvd_prime_iff_eq hp prime8117).mp hd; rw [eqn]; exact w8117
theorem prime2663 : Nat.Prime 2663 := by
  apply lucas_primality 2663 (5:ZMod 2663)
  · exact eq_one [false,true,true,false,false,true,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 2663)^((2663-1)/2)≠1:=
    ne_one [true,true,false,false,true,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w11:(5:ZMod 2663)^((2663-1)/11)≠1:=
    ne_one [false,true,false,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (2663-1)=2*(11*(11*(11))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w11
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w11
  have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w11
theorem prime110839387 : Nat.Prime 110839387 := by
  apply lucas_primality 110839387 (3:ZMod 110839387)
  · exact eq_one [false,true,false,true,true,false,true,false,false,true,true,false,false,false,true,false,true,true,false,true,true,false,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 110839387)^((110839387-1)/2)≠1:=
    ne_one [true,false,true,true,false,true,false,false,true,true,false,false,false,true,false,true,true,false,true,true,false,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 110839387)^((110839387-1)/3)≠1:=
    ne_one [false,true,true,true,true,false,false,false,false,true,false,false,false,false,true,true,true,true,false,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w7:(3:ZMod 110839387)^((110839387-1)/7)≠1:=
    ne_one [false,true,true,false,true,false,true,false,false,false,true,true,true,false,false,true,true,false,false,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w991:(3:ZMod 110839387)^((110839387-1)/991)≠1:=
    ne_one [false,true,true,false,false,true,true,true,false,false,true,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w2663:(3:ZMod 110839387)^((110839387-1)/2663)≠1:=
    ne_one [false,true,true,false,true,false,false,true,false,true,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (110839387-1)=2*(3*(7*(991*(2663)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=991:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w991
  have eqn:q=2663:=(Nat.prime_dvd_prime_iff_eq hp prime2663).mp hd; rw [eqn]; exact w2663
theorem prime1973 : Nat.Prime 1973 := by
  apply lucas_primality 1973 (2:ZMod 1973)
  · exact eq_one [false,false,true,false,true,true,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 1973)^((1973-1)/2)≠1:=
    ne_one [false,true,false,true,true,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w17:(2:ZMod 1973)^((1973-1)/17)≠1:=
    ne_one [false,false,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w29:(2:ZMod 1973)^((1973-1)/29)≠1:=
    ne_one [false,false,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (1973-1)=2*(2*(17*(29))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=17:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w17
  have eqn:q=29:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w29
theorem prime106770869 : Nat.Prime 106770869 := by
  apply lucas_primality 106770869 (2:ZMod 106770869)
  · exact eq_one [false,false,true,false,true,true,false,true,true,false,false,false,true,true,false,false,true,false,true,true,true,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 106770869)^((106770869-1)/2)≠1:=
    ne_one [false,true,false,true,true,false,true,true,false,false,false,true,true,false,false,true,false,true,true,true,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w83:(2:ZMod 106770869)^((106770869-1)/83)≠1:=
    ne_one [false,false,true,true,true,true,true,true,false,false,false,false,false,true,false,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w163:(2:ZMod 106770869)^((106770869-1)/163)≠1:=
    ne_one [false,false,true,true,true,true,false,true,false,true,true,true,true,true,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w1973:(2:ZMod 106770869)^((106770869-1)/1973)≠1:=
    ne_one [false,false,true,false,false,true,true,false,true,true,false,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (106770869-1)=2*(2*(83*(163*(1973)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=83:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w83
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=163:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w163
  have eqn:q=1973:=(Nat.prime_dvd_prime_iff_eq hp prime1973).mp hd; rw [eqn]; exact w1973
theorem prime19801938906479 : Nat.Prime 19801938906479 := by
  apply lucas_primality 19801938906479 (7:ZMod 19801938906479)
  · exact eq_one [false,true,true,true,false,true,true,false,true,false,true,true,false,false,true,true,false,false,false,true,false,false,false,true,true,true,true,true,true,true,true,false,false,true,false,false,false,false,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(7:ZMod 19801938906479)^((19801938906479-1)/2)≠1:=
    ne_one [true,true,true,false,true,true,false,true,false,true,true,false,false,true,true,false,false,false,true,false,false,false,true,true,true,true,true,true,true,true,false,false,true,false,false,false,false,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w47:(7:ZMod 19801938906479)^((19801938906479-1)/47)≠1:=
    ne_one [false,true,false,false,true,true,true,true,true,true,true,true,false,true,false,false,false,false,false,false,false,false,false,true,false,false,false,true,true,false,false,false,false,true,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w1973:(7:ZMod 19801938906479)^((19801938906479-1)/1973)≠1:=
    ne_one [false,true,true,false,true,true,true,false,false,false,false,false,false,false,true,false,false,false,false,true,true,true,false,false,false,true,true,false,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w106770869:(7:ZMod 19801938906479)^((19801938906479-1)/106770869)≠1:=
    ne_one [false,true,true,false,true,true,true,false,false,false,true,false,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (19801938906479-1)=2*(47*(1973*(106770869))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=47:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w47
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=1973:=(Nat.prime_dvd_prime_iff_eq hp prime1973).mp leaf; rw [eqn]; exact w1973
  have eqn:q=106770869:=(Nat.prime_dvd_prime_iff_eq hp prime106770869).mp hd; rw [eqn]; exact w106770869
theorem prime67339 : Nat.Prime 67339 := by
  apply lucas_primality 67339 (3:ZMod 67339)
  · exact eq_one [false,true,false,true,false,false,false,false,true,true,true,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 67339)^((67339-1)/2)≠1:=
    ne_one [true,false,true,false,false,false,false,true,true,true,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 67339)^((67339-1)/3)≠1:=
    ne_one [false,true,true,true,false,true,false,true,true,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w29:(3:ZMod 67339)^((67339-1)/29)≠1:=
    ne_one [false,true,false,false,true,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w43:(3:ZMod 67339)^((67339-1)/43)≠1:=
    ne_one [false,true,true,true,true,false,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (67339-1)=2*(3*(3*(3*(29*(43))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=29:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w29
  have eqn:q=43:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w43
theorem prime2621 : Nat.Prime 2621 := by
  apply lucas_primality 2621 (2:ZMod 2621)
  · exact eq_one [false,false,true,true,true,true,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 2621)^((2621-1)/2)≠1:=
    ne_one [false,true,true,true,true,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(2:ZMod 2621)^((2621-1)/5)≠1:=
    ne_one [false,false,true,true,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w131:(2:ZMod 2621)^((2621-1)/131)≠1:=
    ne_one [false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (2621-1)=2*(2*(5*(131))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  have eqn:q=131:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w131
theorem prime4153 : Nat.Prime 4153 := by
  apply lucas_primality 4153 (5:ZMod 4153)
  · exact eq_one [false,false,false,true,true,true,false,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 4153)^((4153-1)/2)≠1:=
    ne_one [false,false,true,true,true,false,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(5:ZMod 4153)^((4153-1)/3)≠1:=
    ne_one [false,false,false,true,false,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w173:(5:ZMod 4153)^((4153-1)/173)≠1:=
    ne_one [false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (4153-1)=2*(2*(2*(3*(173)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=173:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w173
theorem prime65310079 : Nat.Prime 65310079 := by
  apply lucas_primality 65310079 (3:ZMod 65310079)
  · exact eq_one [false,true,true,true,true,true,true,false,true,false,true,true,false,false,false,true,false,false,true,false,false,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 65310079)^((65310079-1)/2)≠1:=
    ne_one [true,true,true,true,true,true,false,true,false,true,true,false,false,false,true,false,false,true,false,false,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 65310079)^((65310079-1)/3)≠1:=
    ne_one [false,true,false,true,false,true,false,false,true,true,true,true,false,true,false,false,false,false,true,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w2621:(3:ZMod 65310079)^((65310079-1)/2621)≠1:=
    ne_one [false,true,true,false,true,false,true,false,true,false,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w4153:(3:ZMod 65310079)^((65310079-1)/4153)≠1:=
    ne_one [false,true,true,true,false,true,true,false,true,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (65310079-1)=2*(3*(2621*(4153))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2621:=(Nat.prime_dvd_prime_iff_eq hp prime2621).mp leaf; rw [eqn]; exact w2621
  have eqn:q=4153:=(Nat.prime_dvd_prime_iff_eq hp prime4153).mp hd; rw [eqn]; exact w4153
theorem prime66616280581 : Nat.Prime 66616280581 := by
  apply lucas_primality 66616280581 (13:ZMod 66616280581)
  · exact eq_one [false,false,true,false,false,false,false,false,false,true,true,false,false,false,true,true,true,true,false,false,false,true,false,true,false,true,false,false,false,false,false,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(13:ZMod 66616280581)^((66616280581-1)/2)≠1:=
    ne_one [false,true,false,false,false,false,false,false,true,true,false,false,false,true,true,true,true,false,false,false,true,false,true,false,true,false,false,false,false,false,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(13:ZMod 66616280581)^((66616280581-1)/3)≠1:=
    ne_one [false,false,true,true,false,true,false,true,false,false,true,true,false,true,true,true,true,true,false,true,false,false,false,true,true,true,false,true,false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(13:ZMod 66616280581)^((66616280581-1)/5)≠1:=
    ne_one [false,false,true,false,true,true,false,false,true,false,false,false,false,false,true,true,false,false,false,false,false,true,false,false,false,true,false,true,true,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w17:(13:ZMod 66616280581)^((66616280581-1)/17)≠1:=
    ne_one [false,false,true,false,false,false,true,true,true,false,false,true,false,true,false,false,true,false,false,false,true,false,false,true,true,false,false,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w65310079:(13:ZMod 66616280581)^((66616280581-1)/65310079)≠1:=
    ne_one [false,false,true,true,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (66616280581-1)=2*(2*(3*(5*(17*(65310079))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=17:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w17
  have eqn:q=65310079:=(Nat.prime_dvd_prime_iff_eq hp prime65310079).mp hd; rw [eqn]; exact w65310079
theorem prime180663352935673 : Nat.Prime 180663352935673 := by
  apply lucas_primality 180663352935673 (7:ZMod 180663352935673)
  · exact eq_one [false,false,false,true,true,true,true,true,false,false,true,false,false,false,true,true,true,false,false,true,true,true,true,true,false,true,true,false,true,true,true,true,true,true,true,true,false,false,true,false,false,false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(7:ZMod 180663352935673)^((180663352935673-1)/2)≠1:=
    ne_one [false,false,true,true,true,true,true,false,false,true,false,false,false,true,true,true,false,false,true,true,true,true,true,false,true,true,false,true,true,true,true,true,true,true,true,false,false,true,false,false,false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(7:ZMod 180663352935673)^((180663352935673-1)/3)≠1:=
    ne_one [false,false,false,true,false,true,false,true,true,false,false,false,false,false,true,false,true,true,false,false,true,false,true,false,false,true,false,false,true,false,true,false,true,false,true,false,false,false,true,true,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w113:(7:ZMod 180663352935673)^((180663352935673-1)/113)≠1:=
    ne_one [false,false,false,true,true,true,true,false,false,false,false,false,true,false,false,true,false,true,false,true,true,false,true,false,true,true,true,true,true,true,false,false,false,false,true,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w66616280581:(7:ZMod 180663352935673)^((180663352935673-1)/66616280581)≠1:=
    ne_one [false,false,false,true,true,false,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (180663352935673-1)=2*(2*(2*(3*(113*(66616280581))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=113:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w113
  have eqn:q=66616280581:=(Nat.prime_dvd_prime_iff_eq hp prime66616280581).mp hd; rw [eqn]; exact w66616280581
theorem prime45332619568739522587873397 : Nat.Prime 45332619568739522587873397 := by
  apply lucas_primality 45332619568739522587873397 (2:ZMod 45332619568739522587873397)
  · exact eq_one [false,false,true,false,true,true,true,false,false,false,false,false,true,false,true,false,true,true,true,true,true,false,true,true,false,false,false,false,false,true,true,true,false,false,true,true,true,false,true,false,false,false,false,true,true,true,false,true,true,false,true,false,false,true,false,false,true,true,false,true,true,true,false,false,false,true,true,true,false,false,false,true,true,true,true,true,true,true,true,false,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 45332619568739522587873397)^((45332619568739522587873397-1)/2)≠1:=
    ne_one [false,true,false,true,true,true,false,false,false,false,false,true,false,true,false,true,true,true,true,true,false,true,true,false,false,false,false,false,true,true,true,false,false,true,true,true,false,true,false,false,false,false,true,true,true,false,true,true,false,true,false,false,true,false,false,true,true,false,true,true,true,false,false,false,true,true,true,false,false,false,true,true,true,true,true,true,true,true,false,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w7:(2:ZMod 45332619568739522587873397)^((45332619568739522587873397-1)/7)≠1:=
    ne_one [false,false,true,true,false,true,true,true,false,true,true,false,false,true,true,true,true,true,true,true,true,false,false,false,false,false,false,false,false,true,false,false,false,false,true,false,false,false,true,true,true,false,true,false,true,true,true,true,true,false,false,true,false,true,false,false,false,true,true,false,true,true,true,false,true,false,true,true,true,false,true,false,true,true,false,true,true,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w13:(2:ZMod 45332619568739522587873397)^((45332619568739522587873397-1)/13)≠1:=
    ne_one [false,false,true,false,false,false,true,false,true,false,false,false,false,false,true,false,false,false,true,true,false,false,true,false,true,false,false,false,true,false,false,false,false,false,true,true,false,false,true,true,false,true,true,false,false,true,true,true,false,true,false,false,false,false,false,false,true,true,true,false,false,true,true,false,true,false,true,true,false,true,true,false,false,true,false,false,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w29:(2:ZMod 45332619568739522587873397)^((45332619568739522587873397-1)/29)≠1:=
    ne_one [false,false,true,false,false,false,false,false,false,false,false,false,true,false,false,true,true,true,false,true,true,false,true,true,false,false,false,true,false,true,true,false,true,false,true,false,false,false,true,true,false,true,false,true,false,false,false,true,false,true,true,true,false,false,false,true,true,true,true,false,false,true,true,true,false,false,true,false,false,false,false,false,true,true,false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w353:(2:ZMod 45332619568739522587873397)^((45332619568739522587873397-1)/353)≠1:=
    ne_one [false,false,true,false,true,true,true,true,false,false,false,false,false,false,false,false,false,true,true,true,true,false,false,true,true,true,true,false,false,true,true,false,false,true,true,true,false,false,false,true,false,false,true,false,true,true,true,false,true,false,true,false,false,true,false,true,true,true,true,false,true,true,false,true,true,false,false,false,true,true,false,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w67339:(2:ZMod 45332619568739522587873397)^((45332619568739522587873397-1)/67339)≠1:=
    ne_one [false,false,true,true,true,false,true,true,true,false,false,true,false,true,false,true,true,false,true,false,false,true,true,false,true,false,false,false,false,true,false,false,false,false,true,false,false,true,false,true,true,false,false,true,true,false,false,false,true,true,true,false,false,false,false,true,false,true,true,true,true,true,true,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w180663352935673:(2:ZMod 45332619568739522587873397)^((45332619568739522587873397-1)/180663352935673)≠1:=
    ne_one [false,false,true,false,true,false,false,false,true,false,true,false,true,false,false,true,true,true,true,true,false,true,false,false,false,false,true,true,false,true,true,false,false,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (45332619568739522587873397-1)=2*(2*(7*(13*(29*(353*(67339*(180663352935673))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=13:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w13
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=29:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w29
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=353:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w353
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=67339:=(Nat.prime_dvd_prime_iff_eq hp prime67339).mp leaf; rw [eqn]; exact w67339
  have eqn:q=180663352935673:=(Nat.prime_dvd_prime_iff_eq hp prime180663352935673).mp hd; rw [eqn]; exact w180663352935673
theorem prime3590695052683337673944409020705100156653 : Nat.Prime 3590695052683337673944409020705100156653 := by
  apply lucas_primality 3590695052683337673944409020705100156653 (2:ZMod 3590695052683337673944409020705100156653)
  · exact eq_one [false,false,true,true,false,true,true,true,false,true,true,true,false,false,true,false,false,true,true,false,false,true,false,true,true,false,true,false,true,true,true,false,false,false,true,true,true,true,false,false,true,true,false,true,false,true,false,true,true,false,false,true,false,true,false,false,true,false,false,false,true,false,true,false,true,false,false,true,false,false,true,false,false,false,true,true,true,true,false,false,true,false,false,false,false,false,true,false,false,true,true,true,true,false,false,false,false,true,false,true,true,false,true,false,false,true,true,false,true,true,false,true,false,true,true,false,true,false,true,false,true,false,true,true,false,false,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 3590695052683337673944409020705100156653)^((3590695052683337673944409020705100156653-1)/2)≠1:=
    ne_one [false,true,true,false,true,true,true,false,true,true,true,false,false,true,false,false,true,true,false,false,true,false,true,true,false,true,false,true,true,true,false,false,false,true,true,true,true,false,false,true,true,false,true,false,true,false,true,true,false,false,true,false,true,false,false,true,false,false,false,true,false,true,false,true,false,false,true,false,false,true,false,false,false,true,true,true,true,false,false,true,false,false,false,false,false,true,false,false,true,true,true,true,false,false,false,false,true,false,true,true,false,true,false,false,true,true,false,true,true,false,true,false,true,true,false,true,false,true,false,true,false,true,true,false,false,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w19801938906479:(2:ZMod 3590695052683337673944409020705100156653)^((3590695052683337673944409020705100156653-1)/19801938906479)≠1:=
    ne_one [false,false,true,false,true,false,true,true,true,false,false,false,false,false,true,false,true,false,true,true,true,true,true,false,true,true,false,false,false,false,false,true,true,true,false,false,true,true,true,false,true,false,false,false,false,true,true,true,false,true,true,false,true,false,false,true,false,false,true,true,false,true,true,true,false,false,false,true,true,true,false,false,false,true,true,true,true,true,true,true,true,false,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w45332619568739522587873397:(2:ZMod 3590695052683337673944409020705100156653)^((3590695052683337673944409020705100156653-1)/45332619568739522587873397)≠1:=
    ne_one [false,false,true,true,true,true,false,true,true,false,true,false,true,true,false,false,true,true,false,false,false,true,false,false,false,true,true,true,true,true,true,true,true,false,false,true,false,false,false,false,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (3590695052683337673944409020705100156653-1)=2*(2*(19801938906479*(45332619568739522587873397))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=19801938906479:=(Nat.prime_dvd_prime_iff_eq hp prime19801938906479).mp leaf; rw [eqn]; exact w19801938906479
  have eqn:q=45332619568739522587873397:=(Nat.prime_dvd_prime_iff_eq hp prime45332619568739522587873397).mp hd; rw [eqn]; exact w45332619568739522587873397
theorem prime20873392864897768682156280205901274542360098265277202801541503 : Nat.Prime 20873392864897768682156280205901274542360098265277202801541503 := by
  apply lucas_primality 20873392864897768682156280205901274542360098265277202801541503 (11:ZMod 20873392864897768682156280205901274542360098265277202801541503)
  · exact eq_one [false,true,true,true,true,true,true,false,true,false,false,false,false,false,true,true,false,true,true,false,false,false,true,false,true,true,false,false,true,true,true,false,true,false,true,true,true,true,true,false,true,true,false,true,true,true,false,false,false,false,false,false,false,false,true,false,true,false,true,false,true,false,true,true,false,true,false,false,true,false,false,true,true,false,false,false,false,false,true,true,true,true,false,true,true,false,true,false,true,true,true,false,false,false,false,false,false,false,false,false,true,false,false,true,false,true,false,false,true,true,false,true,true,false,true,false,false,true,false,false,true,false,true,true,true,false,false,false,true,true,false,true,false,true,false,false,true,true,false,false,false,false,true,false,true,true,false,false,false,true,false,true,true,false,false,false,false,true,true,false,false,false,false,false,true,true,false,false,true,false,true,false,true,true,true,true,true,false,true,false,false,false,true,true,false,true,false,false,true,false,true,false,true,false,true,true,true,true,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(11:ZMod 20873392864897768682156280205901274542360098265277202801541503)^((20873392864897768682156280205901274542360098265277202801541503-1)/2)≠1:=
    ne_one [true,true,true,true,true,true,false,true,false,false,false,false,false,true,true,false,true,true,false,false,false,true,false,true,true,false,false,true,true,true,false,true,false,true,true,true,true,true,false,true,true,false,true,true,true,false,false,false,false,false,false,false,false,true,false,true,false,true,false,true,false,true,true,false,true,false,false,true,false,false,true,true,false,false,false,false,false,true,true,true,true,false,true,true,false,true,false,true,true,true,false,false,false,false,false,false,false,false,false,true,false,false,true,false,true,false,false,true,true,false,true,true,false,true,false,false,true,false,false,true,false,true,true,true,false,false,false,true,true,false,true,false,true,false,false,true,true,false,false,false,false,true,false,true,true,false,false,false,true,false,true,true,false,false,false,false,true,true,false,false,false,false,false,true,true,false,false,true,false,true,false,true,true,true,true,true,false,true,false,false,false,true,true,false,true,false,false,true,false,true,false,true,false,true,true,true,true,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(11:ZMod 20873392864897768682156280205901274542360098265277202801541503)^((20873392864897768682156280205901274542360098265277202801541503-1)/3)≠1:=
    ne_one [false,true,false,true,false,true,false,false,true,true,false,true,false,true,true,true,false,false,true,true,false,true,true,false,false,true,true,false,false,true,false,false,true,true,true,true,true,true,true,false,false,true,true,true,true,true,false,true,false,true,false,true,false,true,true,false,false,false,true,true,true,false,false,true,true,true,false,true,true,false,true,true,true,false,true,false,true,false,false,true,false,true,true,true,true,false,false,false,true,false,true,true,false,true,false,true,false,true,false,true,true,false,true,true,false,false,false,false,true,false,false,true,false,false,true,true,false,false,false,false,true,true,true,true,true,false,true,false,false,true,true,true,false,false,false,false,true,false,false,false,false,false,true,true,true,true,false,true,false,false,false,true,false,false,false,false,false,true,false,false,false,false,false,false,true,false,false,false,true,true,true,false,false,true,false,true,false,false,true,true,false,true,true,true,false,false,false,false,true,true,true,false,false,false,true,false,true,false,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w13:(11:ZMod 20873392864897768682156280205901274542360098265277202801541503)^((20873392864897768682156280205901274542360098265277202801541503-1)/13)≠1:=
    ne_one [false,true,true,false,true,true,true,true,true,false,false,true,false,false,true,false,true,true,true,true,false,false,false,true,false,false,true,true,true,false,false,false,false,false,true,true,false,true,true,false,false,true,true,true,false,false,false,true,true,false,true,true,true,false,true,true,false,true,false,false,true,true,true,false,true,false,false,false,false,false,false,true,true,true,true,false,false,true,true,true,false,false,false,false,true,false,false,true,false,false,false,false,false,false,false,false,false,false,false,false,true,false,true,true,false,false,false,true,false,false,true,false,false,true,false,true,false,true,false,false,true,true,true,false,false,false,true,true,true,false,true,false,false,true,true,false,false,true,true,false,true,true,false,true,false,true,false,false,false,false,false,true,true,true,true,false,false,false,false,false,false,false,false,false,true,true,true,true,true,false,true,true,false,false,true,false,false,true,false,true,false,false,true,false,true,true,false,true,false,false,true,true,true,true,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w43:(11:ZMod 20873392864897768682156280205901274542360098265277202801541503)^((20873392864897768682156280205901274542360098265277202801541503-1)/43)≠1:=
    ne_one [false,true,false,true,true,true,true,false,true,true,true,false,false,false,false,true,false,false,false,false,true,false,false,true,true,false,false,false,true,false,false,true,true,true,true,true,false,true,false,true,false,true,false,true,true,false,true,false,true,true,false,false,true,false,false,false,false,true,true,false,true,true,true,false,true,false,true,true,true,true,true,true,true,false,true,false,false,false,true,false,false,false,false,false,true,true,true,true,true,false,true,true,true,false,false,false,true,false,false,false,false,true,false,false,true,true,true,false,false,false,false,true,true,false,true,true,false,true,false,true,false,false,false,false,false,false,false,false,true,false,false,false,false,false,false,false,true,false,false,true,false,false,true,false,true,false,true,false,false,false,true,false,false,true,false,false,false,false,false,false,false,false,false,false,true,false,false,true,true,true,true,false,true,false,false,false,false,true,true,false,false,false,true,false,true,false,true,false,true,false,true,false,true,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w59:(11:ZMod 20873392864897768682156280205901274542360098265277202801541503)^((20873392864897768682156280205901274542360098265277202801541503-1)/59)≠1:=
    ne_one [false,true,false,true,true,false,false,true,false,true,false,true,true,true,true,true,true,true,true,false,true,false,true,false,true,false,true,true,false,true,false,false,true,false,false,true,false,true,false,false,false,true,true,false,true,true,true,false,true,true,true,true,true,false,false,false,false,true,false,true,false,false,false,true,true,false,false,true,false,true,false,false,false,false,false,true,false,true,false,true,true,true,true,true,false,false,true,false,true,true,true,true,false,false,false,true,true,false,true,true,true,false,true,false,true,true,true,false,false,false,false,false,false,false,true,true,false,true,false,false,true,false,false,true,false,false,false,false,true,true,false,true,false,true,true,true,true,true,true,false,true,false,true,false,true,false,true,true,true,true,false,true,false,true,false,false,false,false,true,false,true,true,false,false,true,false,true,false,false,true,true,false,false,false,false,true,true,false,true,false,false,false,false,true,false,false,true,true,true,false,true,false,false,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w88345429:(11:ZMod 20873392864897768682156280205901274542360098265277202801541503)^((20873392864897768682156280205901274542360098265277202801541503-1)/88345429)≠1:=
    ne_one [false,true,true,false,false,false,false,true,true,true,true,false,false,false,false,true,true,true,false,false,true,true,true,true,false,true,true,false,true,false,true,true,false,false,true,false,true,false,false,false,true,false,false,false,false,true,false,true,true,true,true,false,true,false,true,true,false,false,false,true,true,true,false,true,false,false,false,true,true,false,false,false,false,true,false,false,true,true,true,true,true,true,false,true,true,false,false,true,false,true,true,true,true,true,true,true,false,false,true,false,true,false,false,true,true,false,false,true,true,true,false,true,false,true,false,true,true,false,true,true,false,true,false,false,true,false,true,false,true,true,false,true,false,true,false,true,false,true,true,true,false,false,true,true,true,false,false,true,false,true,true,true,false,true,false,false,false,true,false,true,false,true,true,true,true,true,true,false,true,true,true,false,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w110839387:(11:ZMod 20873392864897768682156280205901274542360098265277202801541503)^((20873392864897768682156280205901274542360098265277202801541503-1)/110839387)≠1:=
    ne_one [false,true,false,true,true,false,true,true,false,false,false,true,false,false,false,false,false,true,true,true,false,true,false,true,true,false,true,false,false,true,false,false,false,true,false,true,false,false,false,false,true,true,true,false,true,true,false,false,true,true,false,true,true,false,false,true,true,true,true,false,false,true,true,false,true,true,true,true,false,false,false,true,false,true,true,true,false,false,false,false,false,true,true,true,false,true,true,false,true,false,false,false,false,false,true,true,true,true,true,false,true,false,true,true,true,true,true,true,false,true,false,false,true,true,true,true,false,false,false,true,true,true,true,false,false,false,true,true,false,true,true,false,false,true,false,false,false,false,true,false,false,false,false,false,true,false,true,false,true,true,false,true,false,true,false,false,false,false,false,true,false,true,true,false,true,false,true,false,true,true,true,false,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w3590695052683337673944409020705100156653:(11:ZMod 20873392864897768682156280205901274542360098265277202801541503)^((20873392864897768682156280205901274542360098265277202801541503-1)/3590695052683337673944409020705100156653)≠1:=
    ne_one [false,true,true,false,true,true,false,true,true,false,false,true,true,false,false,true,true,true,false,true,true,true,true,false,false,true,true,false,true,true,false,true,true,false,false,false,false,false,true,false,true,true,false,true,false,true,true,true,true,true,true,false,true,true,false,false,false,true,false,false,false,true,false,false,true,true,false,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (20873392864897768682156280205901274542360098265277202801541503-1)=2*(3*(3*(13*(43*(59*(88345429*(110839387*(3590695052683337673944409020705100156653)))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=13:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w13
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=43:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w43
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=59:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w59
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=88345429:=(Nat.prime_dvd_prime_iff_eq hp prime88345429).mp leaf; rw [eqn]; exact w88345429
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=110839387:=(Nat.prime_dvd_prime_iff_eq hp prime110839387).mp leaf; rw [eqn]; exact w110839387
  have eqn:q=3590695052683337673944409020705100156653:=(Nat.prime_dvd_prime_iff_eq hp prime3590695052683337673944409020705100156653).mp hd; rw [eqn]; exact w3590695052683337673944409020705100156653
theorem prime12231808218830092447743580200658146881823017583452440841703320759 : Nat.Prime 12231808218830092447743580200658146881823017583452440841703320759 := by
  apply lucas_primality 12231808218830092447743580200658146881823017583452440841703320759 (7:ZMod 12231808218830092447743580200658146881823017583452440841703320759)
  · exact eq_one [false,true,true,false,true,true,false,true,false,false,true,true,false,true,true,true,false,true,true,false,true,true,true,true,true,true,true,true,true,false,true,true,true,false,false,true,false,true,false,false,true,false,true,true,false,true,false,false,false,false,false,true,false,false,false,false,true,false,true,false,false,true,false,false,false,false,true,true,true,false,false,false,false,true,false,true,true,false,false,false,true,false,false,true,false,false,false,false,false,false,false,true,true,false,true,true,false,false,false,false,true,true,false,true,true,false,true,true,true,true,false,true,false,true,false,true,false,false,true,false,false,false,false,true,true,true,false,true,false,false,false,false,true,true,false,true,false,false,false,false,false,false,true,true,true,true,true,false,true,true,false,true,true,true,true,true,true,true,true,false,true,true,true,true,true,true,false,true,false,false,false,false,false,false,true,false,true,true,false,false,false,true,false,false,true,false,false,true,true,true,true,false,true,true,true,true,true,false,true,true,true,true,false,true,true,true,false,true,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(7:ZMod 12231808218830092447743580200658146881823017583452440841703320759)^((12231808218830092447743580200658146881823017583452440841703320759-1)/2)≠1:=
    ne_one [true,true,false,true,true,false,true,false,false,true,true,false,true,true,true,false,true,true,false,true,true,true,true,true,true,true,true,true,false,true,true,true,false,false,true,false,true,false,false,true,false,true,true,false,true,false,false,false,false,false,true,false,false,false,false,true,false,true,false,false,true,false,false,false,false,true,true,true,false,false,false,false,true,false,true,true,false,false,false,true,false,false,true,false,false,false,false,false,false,false,true,true,false,true,true,false,false,false,false,true,true,false,true,true,false,true,true,true,true,false,true,false,true,false,true,false,false,true,false,false,false,false,true,true,true,false,true,false,false,false,false,true,true,false,true,false,false,false,false,false,false,true,true,true,true,true,false,true,true,false,true,true,true,true,true,true,true,true,false,true,true,true,true,true,true,false,true,false,false,false,false,false,false,true,false,true,true,false,false,false,true,false,false,true,false,false,true,true,true,true,false,true,true,true,true,true,false,true,true,true,true,false,true,true,true,false,true,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w293:(7:ZMod 12231808218830092447743580200658146881823017583452440841703320759)^((12231808218830092447743580200658146881823017583452440841703320759-1)/293)≠1:=
    ne_one [false,true,true,true,true,true,true,true,false,true,false,false,false,false,false,true,true,false,true,true,false,false,false,true,false,true,true,false,false,true,true,true,false,true,false,true,true,true,true,true,false,true,true,false,true,true,true,false,false,false,false,false,false,false,false,true,false,true,false,true,false,true,false,true,true,false,true,false,false,true,false,false,true,true,false,false,false,false,false,true,true,true,true,false,true,true,false,true,false,true,true,true,false,false,false,false,false,false,false,false,false,true,false,false,true,false,true,false,false,true,true,false,true,true,false,true,false,false,true,false,false,true,false,true,true,true,false,false,false,true,true,false,true,false,true,false,false,true,true,false,false,false,false,true,false,true,true,false,false,false,true,false,true,true,false,false,false,false,true,true,false,false,false,false,false,true,true,false,false,true,false,true,false,true,true,true,true,true,false,true,false,false,false,true,true,false,true,false,false,true,false,true,false,true,false,true,true,true,true,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w20873392864897768682156280205901274542360098265277202801541503:(7:ZMod 12231808218830092447743580200658146881823017583452440841703320759)^((12231808218830092447743580200658146881823017583452440841703320759-1)/20873392864897768682156280205901274542360098265277202801541503)≠1:=
    ne_one [false,true,false,true,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (12231808218830092447743580200658146881823017583452440841703320759-1)=2*(293*(20873392864897768682156280205901274542360098265277202801541503)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=293:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w293
  have eqn:q=20873392864897768682156280205901274542360098265277202801541503:=(Nat.prime_dvd_prime_iff_eq hp prime20873392864897768682156280205901274542360098265277202801541503).mp hd; rw [eqn]; exact w20873392864897768682156280205901274542360098265277202801541503
theorem prime16227156861163664717088006599348549780712577238462933780686361101318463016535289 : Nat.Prime 16227156861163664717088006599348549780712577238462933780686361101318463016535289 := by
  apply lucas_primality 16227156861163664717088006599348549780712577238462933780686361101318463016535289 (3:ZMod 16227156861163664717088006599348549780712577238462933780686361101318463016535289)
  · exact eq_one [false,false,false,true,true,true,true,true,false,false,true,false,false,false,false,false,false,true,true,true,false,false,false,false,false,true,true,false,false,true,false,false,false,false,false,true,false,false,true,false,true,false,false,true,false,true,true,true,false,true,true,true,true,false,false,true,true,false,true,false,false,false,true,false,false,true,false,false,true,false,true,true,true,true,false,false,true,false,false,true,false,false,false,true,false,false,true,false,false,true,false,true,true,false,true,true,false,false,true,true,false,false,true,true,true,false,true,true,false,true,false,true,true,false,true,true,true,true,false,true,false,false,false,true,true,true,false,false,false,true,false,true,false,false,true,true,false,false,false,false,false,true,true,false,false,false,true,true,true,false,true,false,false,true,false,false,true,true,true,false,false,false,true,true,true,true,true,false,false,false,false,false,true,true,false,false,true,false,false,false,true,false,true,true,false,true,true,true,true,true,true,false,true,true,false,false,true,false,true,false,true,false,true,false,false,true,true,true,false,true,false,false,false,false,false,true,false,true,false,true,true,true,true,true,true,true,true,false,true,false,true,false,false,true,true,true,false,false,true,false,true,false,true,false,true,true,true,true,true,true,false,false,false,true,false,false,false,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 16227156861163664717088006599348549780712577238462933780686361101318463016535289)^((16227156861163664717088006599348549780712577238462933780686361101318463016535289-1)/2)≠1:=
    ne_one [false,false,true,true,true,true,true,false,false,true,false,false,false,false,false,false,true,true,true,false,false,false,false,false,true,true,false,false,true,false,false,false,false,false,true,false,false,true,false,true,false,false,true,false,true,true,true,false,true,true,true,true,false,false,true,true,false,true,false,false,false,true,false,false,true,false,false,true,false,true,true,true,true,false,false,true,false,false,true,false,false,false,true,false,false,true,false,false,true,false,true,true,false,true,true,false,false,true,true,false,false,true,true,true,false,true,true,false,true,false,true,true,false,true,true,true,true,false,true,false,false,false,true,true,true,false,false,false,true,false,true,false,false,true,true,false,false,false,false,false,true,true,false,false,false,true,true,true,false,true,false,false,true,false,false,true,true,true,false,false,false,true,true,true,true,true,false,false,false,false,false,true,true,false,false,true,false,false,false,true,false,true,true,false,true,true,true,true,true,true,false,true,true,false,false,true,false,true,false,true,false,true,false,false,true,true,true,false,true,false,false,false,false,false,true,false,true,false,true,true,true,true,true,true,true,true,false,true,false,true,false,false,true,true,true,false,false,true,false,true,false,true,false,true,true,true,true,true,true,false,false,false,true,false,false,false,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w23:(3:ZMod 16227156861163664717088006599348549780712577238462933780686361101318463016535289)^((16227156861163664717088006599348549780712577238462933780686361101318463016535289-1)/23)≠1:=
    ne_one [false,false,false,true,false,false,true,true,true,false,true,false,false,false,false,true,false,true,true,true,false,false,true,false,true,false,false,true,true,true,false,false,true,false,true,false,true,true,false,true,true,true,true,true,false,false,false,true,false,true,true,true,true,true,false,false,false,false,false,false,false,false,true,true,true,true,true,false,false,true,true,true,true,false,false,true,true,false,true,true,true,true,false,false,true,false,false,true,true,true,false,true,true,true,false,true,false,false,true,false,false,true,false,true,true,false,false,true,true,true,false,true,true,true,false,true,true,false,true,true,true,true,false,false,false,true,false,false,true,false,false,false,true,false,true,true,false,true,false,false,false,true,true,true,false,false,false,true,true,true,true,true,false,false,true,false,false,false,false,false,false,false,true,false,false,true,true,true,false,false,true,false,false,false,true,false,true,false,true,true,false,true,true,false,true,true,false,false,true,false,true,false,false,false,true,false,true,false,false,true,false,false,false,true,false,true,true,true,false,true,false,false,false,false,true,true,true,true,true,true,true,true,true,true,true,true,true,false,false,true,true,false,true,true,false,false,false,false,false,false,true,true,false,false,true,false,true,true,true,true,true,false,true,false,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w1399:(3:ZMod 16227156861163664717088006599348549780712577238462933780686361101318463016535289)^((16227156861163664717088006599348549780712577238462933780686361101318463016535289-1)/1399)≠1:=
    ne_one [false,false,false,true,false,false,true,true,false,false,false,false,false,false,true,false,false,false,true,false,true,true,false,true,true,true,false,true,true,false,true,false,true,false,true,false,false,false,false,false,false,false,true,false,true,false,false,true,false,true,false,true,true,true,false,true,false,true,true,false,false,false,false,true,false,true,true,true,true,false,false,false,true,true,false,true,true,true,false,true,false,true,true,false,false,false,false,true,false,true,true,false,true,false,true,false,false,false,true,true,false,true,false,true,false,false,false,false,false,false,false,false,false,true,true,false,true,false,false,true,true,true,false,false,false,true,true,false,false,true,true,false,false,true,false,false,true,false,false,true,false,true,false,true,false,false,false,false,false,false,true,false,true,true,true,false,true,true,false,true,true,false,true,false,false,false,true,true,false,false,false,true,false,false,true,true,false,false,false,true,true,true,false,true,true,true,false,true,true,false,false,false,false,false,true,false,false,true,false,false,false,false,false,false,false,true,true,true,false,true,true,false,true,false,false,true,false,true,true,true,false,false,true,true,true,false,false,true,false,false,true,false,true,false,true,true,true,false,true,true,false,false,true,false,false,true,false,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w4079:(3:ZMod 16227156861163664717088006599348549780712577238462933780686361101318463016535289)^((16227156861163664717088006599348549780712577238462933780686361101318463016535289-1)/4079)≠1:=
    ne_one [false,false,false,true,false,false,false,true,false,true,false,false,true,false,true,false,true,false,true,false,false,false,true,true,false,true,false,false,false,false,false,false,false,false,true,false,false,true,false,true,false,false,true,true,false,false,false,true,false,true,false,false,false,false,false,false,true,true,false,false,true,true,false,true,false,true,false,false,true,true,false,false,false,false,true,false,true,false,true,false,true,false,true,false,false,true,false,true,false,false,false,false,true,true,true,false,false,true,true,false,true,false,true,true,true,true,false,true,true,true,true,true,true,true,true,true,true,true,true,true,false,true,true,false,true,false,true,false,false,false,false,false,false,true,false,true,false,true,false,true,true,true,true,true,true,false,true,true,false,true,true,false,false,true,true,false,false,false,false,false,false,true,false,true,false,false,true,false,true,true,false,true,true,true,false,true,true,true,true,false,false,true,true,false,false,true,true,false,true,false,false,true,true,false,false,true,true,true,true,false,false,false,true,true,false,true,true,true,true,false,true,false,false,true,true,true,true,false,true,false,false,false,false,false,false,true,true,false,false,true,false,true,true,true,true,false,true,false,false,true,true,true,false,true,false,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w1263463:(3:ZMod 16227156861163664717088006599348549780712577238462933780686361101318463016535289)^((16227156861163664717088006599348549780712577238462933780686361101318463016535289-1)/1263463)≠1:=
    ne_one [false,false,false,true,false,false,true,false,false,false,false,false,true,false,false,true,false,false,false,true,false,false,true,true,false,false,false,false,false,false,false,true,false,true,true,false,true,true,true,false,true,true,false,true,false,true,false,false,false,false,true,true,false,true,false,false,false,true,true,false,true,true,false,false,true,false,false,true,true,true,false,true,false,true,false,true,false,true,false,false,true,false,false,true,false,false,false,false,false,false,false,false,false,true,true,true,false,true,true,true,false,false,false,false,true,false,false,false,false,false,false,true,false,false,true,true,true,true,false,true,true,true,true,false,false,false,true,true,true,false,false,false,true,false,true,true,true,false,true,true,true,true,false,true,true,true,true,true,true,true,false,true,true,true,true,false,true,true,true,false,true,false,true,true,false,true,true,false,true,true,false,false,true,true,true,true,false,false,true,false,true,false,true,false,false,false,true,false,false,true,true,true,false,true,false,true,true,true,false,false,false,true,false,true,false,false,false,true,false,true,false,true,true,true,true,true,true,false,false,false,true,false,false,false,false,false,true,false,false,true,true,true,false,false,true,false,false,false,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w12231808218830092447743580200658146881823017583452440841703320759:(3:ZMod 16227156861163664717088006599348549780712577238462933780686361101318463016535289)^((16227156861163664717088006599348549780712577238462933780686361101318463016535289-1)/12231808218830092447743580200658146881823017583452440841703320759)≠1:=
    ne_one [false,false,false,true,false,false,true,true,false,true,false,true,true,false,false,true,true,false,false,true,true,true,false,false,false,true,false,false,false,false,false,true,true,false,false,false,true,false,false,true,false,true,true,false,true,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (16227156861163664717088006599348549780712577238462933780686361101318463016535289-1)=2*(2*(2*(23*(1399*(4079*(1263463*(12231808218830092447743580200658146881823017583452440841703320759))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=23:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w23
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=1399:=(Nat.prime_dvd_prime_iff_eq hp prime1399).mp leaf; rw [eqn]; exact w1399
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=4079:=(Nat.prime_dvd_prime_iff_eq hp prime4079).mp leaf; rw [eqn]; exact w4079
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=1263463:=(Nat.prime_dvd_prime_iff_eq hp prime1263463).mp leaf; rw [eqn]; exact w1263463
  have eqn:q=12231808218830092447743580200658146881823017583452440841703320759:=(Nat.prime_dvd_prime_iff_eq hp prime12231808218830092447743580200658146881823017583452440841703320759).mp hd; rw [eqn]; exact w12231808218830092447743580200658146881823017583452440841703320759
theorem prime9459101823195801109555506630879057941073414098690336433570132240458355824672717593303 : Nat.Prime 9459101823195801109555506630879057941073414098690336433570132240458355824672717593303 := by
  apply lucas_primality 9459101823195801109555506630879057941073414098690336433570132240458355824672717593303 (3:ZMod 9459101823195801109555506630879057941073414098690336433570132240458355824672717593303)
  · exact eq_one [false,true,true,false,true,false,true,true,false,true,false,true,true,false,true,true,false,true,true,true,false,false,false,true,false,true,true,false,true,false,false,true,true,true,false,true,false,true,false,false,false,true,false,false,true,true,false,false,false,false,false,true,false,true,false,true,false,true,false,false,true,false,false,false,false,false,true,true,false,true,false,false,false,false,true,true,true,true,false,true,false,false,false,false,false,false,false,true,false,false,false,true,false,true,false,true,false,false,true,false,true,false,true,false,false,false,true,false,false,true,false,false,true,false,false,false,true,false,true,false,true,true,true,true,false,true,true,false,false,false,true,true,false,true,true,false,true,true,true,true,false,true,true,true,false,false,false,false,true,false,false,false,true,true,true,false,true,false,true,false,false,true,false,true,true,false,false,false,false,false,false,true,false,false,false,false,false,true,false,true,false,true,false,false,true,false,true,true,true,false,false,true,true,true,true,true,false,true,true,true,false,true,true,false,false,false,false,false,true,false,false,false,true,false,true,true,false,false,false,false,false,true,false,false,false,true,true,true,true,true,false,false,true,false,true,true,true,false,true,false,false,false,true,false,true,false,false,true,true,false,false,true,true,true,false,true,true,false,true,true,true,false,false,false,true,true,true,true,true,true,true,false,false,true,true,true,true,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 9459101823195801109555506630879057941073414098690336433570132240458355824672717593303)^((9459101823195801109555506630879057941073414098690336433570132240458355824672717593303-1)/2)≠1:=
    ne_one [true,true,false,true,false,true,true,false,true,false,true,true,false,true,true,false,true,true,true,false,false,false,true,false,true,true,false,true,false,false,true,true,true,false,true,false,true,false,false,false,true,false,false,true,true,false,false,false,false,false,true,false,true,false,true,false,true,false,false,true,false,false,false,false,false,true,true,false,true,false,false,false,false,true,true,true,true,false,true,false,false,false,false,false,false,false,true,false,false,false,true,false,true,false,true,false,false,true,false,true,false,true,false,false,false,true,false,false,true,false,false,true,false,false,false,true,false,true,false,true,true,true,true,false,true,true,false,false,false,true,true,false,true,true,false,true,true,true,true,false,true,true,true,false,false,false,false,true,false,false,false,true,true,true,false,true,false,true,false,false,true,false,true,true,false,false,false,false,false,false,true,false,false,false,false,false,true,false,true,false,true,false,false,true,false,true,true,true,false,false,true,true,true,true,true,false,true,true,true,false,true,true,false,false,false,false,false,true,false,false,false,true,false,true,true,false,false,false,false,false,true,false,false,false,true,true,true,true,true,false,false,true,false,true,true,true,false,true,false,false,false,true,false,true,false,false,true,true,false,false,true,true,true,false,true,true,false,true,true,true,false,false,false,true,true,true,true,true,true,true,false,false,true,true,true,true,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 9459101823195801109555506630879057941073414098690336433570132240458355824672717593303)^((9459101823195801109555506630879057941073414098690336433570132240458355824672717593303-1)/3)≠1:=
    ne_one [false,true,false,false,true,true,true,true,false,false,false,true,false,false,true,false,false,true,false,true,true,false,true,true,false,false,true,true,true,false,true,true,true,true,false,false,false,true,true,false,true,true,false,true,true,true,false,true,false,true,false,false,false,true,true,true,false,false,false,false,true,true,false,true,false,true,true,true,false,false,false,false,false,false,true,false,true,false,false,true,true,false,true,false,true,false,true,true,false,true,false,false,false,true,true,true,false,true,true,false,false,false,true,true,false,true,true,false,true,true,false,true,true,false,true,false,false,false,true,true,true,true,true,true,false,false,true,true,false,true,true,true,false,false,true,true,true,true,true,true,false,false,true,false,false,false,false,false,true,true,false,true,true,true,true,false,false,false,true,true,false,false,false,true,false,false,false,false,false,false,false,true,true,false,true,false,true,true,false,false,false,true,true,false,false,false,true,false,true,true,false,false,true,false,true,false,false,true,false,true,true,true,true,false,true,false,true,false,false,false,false,false,true,true,true,true,false,true,false,true,false,false,false,false,false,true,false,true,false,true,true,false,false,false,true,false,true,true,true,false,true,false,false,false,true,true,false,false,true,true,false,false,true,false,false,true,false,false,true,false,true,true,false,true,true,true,true,true,true,true,true,false,true,true,true,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w7:(3:ZMod 9459101823195801109555506630879057941073414098690336433570132240458355824672717593303)^((9459101823195801109555506630879057941073414098690336433570132240458355824672717593303-1)/7)≠1:=
    ne_one [false,true,false,true,true,true,true,true,false,false,true,true,false,false,false,true,true,false,true,true,true,false,true,false,false,false,true,true,false,false,true,true,false,true,false,true,false,true,false,false,true,true,true,false,false,false,false,false,false,false,false,true,true,false,false,false,false,true,true,true,true,false,true,true,false,true,false,true,false,true,false,false,true,false,true,true,false,true,false,true,false,false,true,false,false,true,false,true,false,false,true,true,true,true,false,false,true,false,true,false,true,false,true,false,false,true,true,true,false,false,true,false,true,false,false,true,true,true,true,false,false,false,true,false,true,true,false,false,true,false,true,true,true,true,true,false,false,false,true,false,true,true,false,true,false,false,true,false,true,false,false,true,true,false,true,false,true,false,true,false,false,false,false,true,false,true,false,false,true,false,false,false,false,false,false,false,false,true,true,false,false,false,false,false,true,true,false,true,true,true,false,false,false,true,false,false,false,true,false,false,false,true,false,true,false,false,true,false,true,false,false,true,true,true,true,true,false,true,true,false,true,false,false,true,false,true,true,false,true,true,true,false,false,true,true,false,true,false,true,false,false,true,true,true,true,false,true,false,true,false,false,false,true,false,true,true,false,false,false,true,false,true,false,false,false,true,false,false,true,false,false,false,false,true,false,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w13879:(3:ZMod 9459101823195801109555506630879057941073414098690336433570132240458355824672717593303)^((9459101823195801109555506630879057941073414098690336433570132240458355824672717593303-1)/13879)≠1:=
    ne_one [false,true,false,true,true,false,true,true,false,false,false,false,true,false,true,true,false,false,true,true,false,false,true,false,false,true,true,true,true,true,false,false,false,true,true,false,true,false,true,true,true,false,true,false,false,false,true,false,false,true,false,false,true,false,false,false,false,false,true,true,false,true,true,false,true,true,true,true,true,true,true,false,false,false,false,false,false,false,true,false,false,false,false,true,false,true,true,true,true,true,true,true,false,false,true,true,true,true,false,true,true,false,false,true,true,true,false,false,false,false,false,true,false,true,true,true,true,false,false,false,true,true,true,true,false,false,true,false,true,false,true,true,false,true,false,false,true,false,false,false,false,true,true,true,true,true,true,false,false,true,false,false,true,true,false,false,false,false,true,true,false,true,false,true,false,true,true,false,false,false,true,false,true,true,true,true,true,false,false,false,true,false,true,false,false,true,true,true,false,false,true,true,false,true,false,false,true,true,false,true,true,true,true,true,true,false,false,true,true,false,false,true,true,true,true,false,true,false,false,true,true,false,false,false,true,true,true,true,false,true,true,false,false,true,false,true,true,false,true,true,false,true,true,true,true,true,false,false,false,true,true,false,false,true,true,true,true,false,true,true,true,true,true,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w16227156861163664717088006599348549780712577238462933780686361101318463016535289:(3:ZMod 9459101823195801109555506630879057941073414098690336433570132240458355824672717593303)^((9459101823195801109555506630879057941073414098690336433570132240458355824672717593303-1)/16227156861163664717088006599348549780712577238462933780686361101318463016535289)≠1:=
    ne_one [false,true,true,false,false,false,false,false,true,false,true,false,false,true,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (9459101823195801109555506630879057941073414098690336433570132240458355824672717593303-1)=2*(3*(7*(13879*(16227156861163664717088006599348549780712577238462933780686361101318463016535289)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=13879:=(Nat.prime_dvd_prime_iff_eq hp prime13879).mp leaf; rw [eqn]; exact w13879
  have eqn:q=16227156861163664717088006599348549780712577238462933780686361101318463016535289:=(Nat.prime_dvd_prime_iff_eq hp prime16227156861163664717088006599348549780712577238462933780686361101318463016535289).mp hd; rw [eqn]; exact w16227156861163664717088006599348549780712577238462933780686361101318463016535289
theorem numerator154: (bernoulli 154).num.natAbs=10259718682038021051027794238379184461025738652460569233992776489750881337506863808448685054322627708245455888249006715516690124228801409697850408284121:=by
  have eqn:=sound (j:=154) 225319534991831177328890236228992001350685163362356544091910 data checked (by decide)
  rw [show coeff data 154=16751558279592825601222849982678581130175400736918443056050539059207218249711141095703675928701347598254573561020447456742894813750935385700905710887098687456522093797551940190887165892498687948373091762446095 by decide +kernel] at eqn
  have value:bernoulli 154=(10259718682038021051027794238379184461025738652460569233992776489750881337506863808448685054322627708245455888249006715516690124228801409697850408284121:ℚ)/138:=by push_cast at eqn; linarith
  rw [value]; norm_num
theorem factors154 {q:ℕ} (hp:q.Prime) (hd:q∣10259718682038021051027794238379184461025738652460569233992776489750881337506863808448685054322627708245455888249006715516690124228801409697850408284121) : q=7 ∨ q=11 ∨ q=2213 ∨ q=125929 ∨ q=1569473 ∨ q=384785986561 ∨ q=83697900175217338619182484215561594711 ∨ q=9459101823195801109555506630879057941073414098690336433570132240458355824672717593303 := by
  rw [show 10259718682038021051027794238379184461025738652460569233992776489750881337506863808448685054322627708245455888249006715516690124228801409697850408284121=7*(11*(2213*(125929*(1569473*(384785986561*(83697900175217338619182484215561594711*(9459101823195801109555506630879057941073414098690336433570132240458355824672717593303))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2213:=(Nat.prime_dvd_prime_iff_eq hp prime2213).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=125929:=(Nat.prime_dvd_prime_iff_eq hp prime125929).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=1569473:=(Nat.prime_dvd_prime_iff_eq hp prime1569473).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=384785986561:=(Nat.prime_dvd_prime_iff_eq hp prime384785986561).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=83697900175217338619182484215561594711:=(Nat.prime_dvd_prime_iff_eq hp prime83697900175217338619182484215561594711).mp leaf; rw [eqn]; decide +kernel
  have eqn:q=9459101823195801109555506630879057941073414098690336433570132240458355824672717593303:=(Nat.prime_dvd_prime_iff_eq hp prime9459101823195801109555506630879057941073414098690336433570132240458355824672717593303).mp hd; rw [eqn]; decide +kernel
end OMA.SharpCubicRows284759
