import BernoulliList284759
import PrattRows284759

namespace OMA.MediumCubicRows284759
open OMA.BernoulliList284759 OMA.PrattRows284759
set_option maxRecDepth 65536
set_option maxHeartbeats 0
private def data:List ℤ:=[10014646650599190067509233131649940057366334653200433090,-5007323325299595033754616565824970028683167326600216545,1669107775099865011251538855274990009561055775533405515,0,-333821555019973002250307771054998001912211155106681103,0,238443967871409287321648407896427144223007967933343645,0,-333821555019973002250307771054998001912211155106681103,0,758685352318120459659790388761359095255025352515184325,0,-2534842796909904885219369997791248563970746243722160903,0,11683754425699055078760771986924930066927390428733838605,0,-71025444971014255831727247523878104289203985177697973503,0,550516923085005852996776353115398396612141606806946614485,0,-5298992322144773263266226382880386919263009273121154006903,0,62011925748865693493895053123373806001741150170364215079965,0,-867070641851674785949834623908249601415341225020337219093103,0,14276050718529980727330570737669082875746694836882097310563045,0,-273382138330587177019855645238845836623687114049144730801008103,0,6024619883873601811832724010411523648571493063689447604466151725,0,-151384561066309195231739540565201391216100132900811826334890471903,0,4302438846180879330403775550186875758602758715762140339026496694005,0,-137317381873808822358788429365977760402509754817979928082393569148503,0,4890475622588230120193952656842542456656070541622565024512747406797885,0,-193248423674781626664070194989908084498017192572169244920883310041645903,0,8429258459716405342476262018577662637055128593337511732664705198806831365,0,-403971536184885986050820239390473225081611894227898021650108761564651516103,0,21181727400603319816268789080923199121787119314526705346671598672187656922445,0,-1210432938185602403194611040735749843644724133020829180806968972044700481255103,0,75118530035190516690660626219349912059005564745757650081155041488159298058959125,0,-5046158223710993263018067531037586658260147714601466201746959464526232322776302903,0,365822789074170274765218362670301687756813590074165076355895988455601392505016589405,0,-28540510454098874397911645424813193228974974602463817117716643769340410456563073043503,0,2390038235748244447659734149742962524630755834244532555872546351785526841411181283221285,0,-214312930151864313131574805687447221161580872612345243722718031258877481121854019550804903,0,20531002786314523720474581593426891897120417361377380939351545105397921994527351777618022765,0,-2096867307702910506998057857558008609658387613299850618119240287614084038263732369201767859103,0,227860215680291099491603885868381186839716288841831625789811251391034364963004081008811969921845,0,-26296169037049307055859350536385385514214710544822807974102416763011938519022638944633780581422103,0,3217213458802091303668979622142229684159940721994457269167719694270427779997830665009895214309606525,0,-416592057113784067994807649941657425066677502965504306840242108388658482341130677484740164072691653903,0,57004065235894106764154959556512628561647662683736952634172072280647208367534675064624006634941029524805,0,-8230400091029306591386645416002247078864011390919735281943986572157309744110592551590996957083973889658503,0,1252121689428250466934485946133228905495380541477820045119386699015261087976486165316540695405727096031884685,0,-200448993586640098660507292805383203122872780729906433549053550612952042066642749026093300768658014395729483903,0,33724305486233877923226180020572507380490047750167968934054985430319044488077276665745137737439543812174824654165,0,-5955807555571086408225468283868083914999836552749859513499282440969765680004157564858553092678601288863556984122103,0,1102803908392195686033843670171577882004714811636263599634710027295872064612503618008852545196446729486534683145561245,0,-213865378477549358488366354129993307186958691411719726926580476567558971833034495737926059856230461907309282033885509103,0,43392359308142355712764505235377313451116808238590051555190377785988720684532239204585959989375954508201812825072834093925,0,-9202010976439710241985172247885824862621693355797287009806619477103069454102568950431901723498523607341386000593881788524903,0,2037669816511514236264918591124625905482660777022952086164391728977014150002004876757497427575730383700504971975044084871500205,0,-470726788313163005268862784075912225178956721602591092800232575696912550488165261580568682437128040771449131277078005205538993503,0,113346205882654953802504338169975769269780623784297224139961517195675177037956361977415712746710315338850091264087783952192708788085,0,-28423820059961803261200433506177775727933066053132789771292140255599261312264623677937074637230555414748722783676385793550676465682903,0,7417272829734852818812389329600995411208817767944584740899779364658737360246905345871010506839196324294696388350658552724943498202725565,0,-2012588937793444359656739306849424975061918885900181096812778723629308900453382289696461493461899094934245014931757417020474573070556305103,0,567401538281732464847093919158985230753898055220250564794810798329049411385430170065050013139575523943247268932483520991038211412347679840645,0,-166088019081595172737781792827516197406859844428638044616000964309096754939391424593101383691584625241496973973451377630424042027425735017516103,0,50442633459769817396672109116237531541921381094626739969003776963572295162423652948034716902911927724537836464123429596139583243180242906848421325,0,-15884699975984899419313881795229915398281098724356602629319062433236678880242597258752295239185294815267844458918724349444528344781116624579058915903,0,5183254991153743212004539184002233286568686423513303519676808482934735065304248627794831896637384077249140773152752058332320316983423766641360478515605,0,-1751453725297213776966870259648925310736905052991348088712820203380716596041287404109694677353021884226165844962240051024252446342066209965771529381048503,0,612500996716352695087097677601205699381230729358773858544216186923235628954823107139119747189858352943063603685618666652948054149559361518103203285969931485,0,-221551793710802609825357813578432473964721939966080415637609669287544276559438018412409185111379358200520950088855807024947813802460185068003808535791487401903,0,82843937959607608358243275315694833356818961514399673912394269215081027199758330420218492181823030737292969029896168575585215961437817269721649635250689128236965,0,-32005734232378968323372056111223845566985804913040791858145664785579852975322310592460926178041547002690234147685769166112017178890962078113798974673595114580408103,0,12768756823331483526936459909018572942134325926476595290684894907387820519939305782716756789315164743818141144100799174835511501082607125883896262743388287385668760045,0,-5257781935443282710109671842099799216011506703636779480760202994514097527257300203221424968018932753846323276406084750625891518818056066351576979515633902159370441443103,0,2233448258768399739682023770363131110216615879184673460050779911624667269051166669635419843407896458600733974072958937571768825487872149730652595507120860663696663168588725,0,-978275970371223664721842458877038647580248272775075451816380394953691575799057757460233870951172537738866698737037396037775104814590023143328448554468663039864564725334826903,0,441629513084424551176334035757632287720233083377803034422767892433167094286944340512365659846452548820668679114534092945504698616943061448999812555156132396087344443865386571005,0,-205386090736703649618076109543408127990564309689165378980448317884648564619922946097511270215576252600914261947640689950366167272821973691004411644591007007108809141307308615823503,0,98358284528595933889187653816459219140279832067013845352898618940162292976993192858660717046953472975216448864886750512376756700486968008027907106264254481600845190824412704071314885,0,-48483509043057824072817235729547280204987940333177048949009147937787085720476033135567452489881675133325158594238499998785161039342534880658120741509461846198493231380398634962362640903,0,24589050852761600446829584503498022445881939473095334497414843591740702289478233966339363080371240067890633384965866253934363242247577820244261473452156925327656275019317884291322577188365,0,-12825684662299630669183585538481860428813889488483432653627126473071553451114818703432276602644495969168695245483237614280027465294361403150096753867289098045324164195413439739952792992431103,0,6877675468707594831994579279330001517772020211598983166958349796530148461830277941917297508461903727908902982402670551583624288828136365394275748542851911451112042777488714274418243610808319445]
private theorem checked:∀j:Fin 147, row data j=if (j:ℕ)=0 then (10014646650599190067509233131649940057366334653200433090:ℤ) else 0:=by decide +kernel
theorem prime2857 : Nat.Prime 2857 := by
  apply lucas_primality 2857 (11:ZMod 2857)
  · exact eq_one [false,false,false,true,false,true,false,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(11:ZMod 2857)^((2857-1)/2)≠1:=
    ne_one [false,false,true,false,true,false,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(11:ZMod 2857)^((2857-1)/3)≠1:=
    ne_one [false,false,false,true,true,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w7:(11:ZMod 2857)^((2857-1)/7)≠1:=
    ne_one [false,false,false,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w17:(11:ZMod 2857)^((2857-1)/17)≠1:=
    ne_one [false,false,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (2857-1)=2*(2*(2*(3*(7*(17))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  have eqn:q=17:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w17
theorem prime3221 : Nat.Prime 3221 := by
  apply lucas_primality 3221 (10:ZMod 3221)
  · exact eq_one [false,false,true,false,true,false,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(10:ZMod 3221)^((3221-1)/2)≠1:=
    ne_one [false,true,false,true,false,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w5:(10:ZMod 3221)^((3221-1)/5)≠1:=
    ne_one [false,false,true,false,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w7:(10:ZMod 3221)^((3221-1)/7)≠1:=
    ne_one [false,false,true,true,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w23:(10:ZMod 3221)^((3221-1)/23)≠1:=
    ne_one [false,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (3221-1)=2*(2*(5*(7*(23)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  have eqn:q=23:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w23
theorem prime35089 : Nat.Prime 35089 := by
  apply lucas_primality 35089 (11:ZMod 35089)
  · exact eq_one [false,false,false,false,true,false,false,false,true,false,false,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(11:ZMod 35089)^((35089-1)/2)≠1:=
    ne_one [false,false,false,true,false,false,false,true,false,false,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(11:ZMod 35089)^((35089-1)/3)≠1:=
    ne_one [false,false,false,false,true,true,false,true,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w17:(11:ZMod 35089)^((35089-1)/17)≠1:=
    ne_one [false,false,false,false,true,false,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w43:(11:ZMod 35089)^((35089-1)/43)≠1:=
    ne_one [false,false,false,false,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (35089-1)=2*(2*(2*(2*(3*(17*(43)))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=17:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w17
  have eqn:q=43:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w43
theorem prime1913 : Nat.Prime 1913 := by
  apply lucas_primality 1913 (3:ZMod 1913)
  · exact eq_one [false,false,false,true,true,true,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 1913)^((1913-1)/2)≠1:=
    ne_one [false,false,true,true,true,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w239:(3:ZMod 1913)^((1913-1)/239)≠1:=
    ne_one [false,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (1913-1)=2*(2*(2*(239))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  have eqn:q=239:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w239
theorem prime137737 : Nat.Prime 137737 := by
  apply lucas_primality 137737 (5:ZMod 137737)
  · exact eq_one [false,false,false,true,false,false,false,false,false,true,false,true,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 137737)^((137737-1)/2)≠1:=
    ne_one [false,false,true,false,false,false,false,false,true,false,true,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(5:ZMod 137737)^((137737-1)/3)≠1:=
    ne_one [false,false,false,true,true,false,true,false,true,true,false,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w1913:(5:ZMod 137737)^((137737-1)/1913)≠1:=
    ne_one [false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (137737-1)=2*(2*(2*(3*(3*(1913))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=1913:=(Nat.prime_dvd_prime_iff_eq hp prime1913).mp hd; rw [eqn]; exact w1913
theorem prime1377371 : Nat.Prime 1377371 := by
  apply lucas_primality 1377371 (2:ZMod 1377371)
  · exact eq_one [false,true,false,true,true,false,true,false,false,false,true,false,false,false,false,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 1377371)^((1377371-1)/2)≠1:=
    ne_one [true,false,true,true,false,true,false,false,false,true,false,false,false,false,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(2:ZMod 1377371)^((1377371-1)/5)≠1:=
    ne_one [false,true,false,false,true,false,false,false,false,false,true,false,true,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w137737:(2:ZMod 1377371)^((1377371-1)/137737)≠1:=
    ne_one [false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (1377371-1)=2*(5*(137737)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  have eqn:q=137737:=(Nat.prime_dvd_prime_iff_eq hp prime137737).mp hd; rw [eqn]; exact w137737
theorem prime1671211 : Nat.Prime 1671211 := by
  apply lucas_primality 1671211 (2:ZMod 1671211)
  · exact eq_one [false,true,false,true,false,true,false,false,false,false,false,false,false,false,false,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 1671211)^((1671211-1)/2)≠1:=
    ne_one [true,false,true,false,true,false,false,false,false,false,false,false,false,false,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(2:ZMod 1671211)^((1671211-1)/3)≠1:=
    ne_one [false,true,true,true,false,false,false,false,false,false,false,false,false,false,false,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(2:ZMod 1671211)^((1671211-1)/5)≠1:=
    ne_one [false,true,false,false,false,true,false,true,true,false,false,true,true,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w31:(2:ZMod 1671211)^((1671211-1)/31)≠1:=
    ne_one [false,true,true,false,true,false,false,true,false,true,false,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w599:(2:ZMod 1671211)^((1671211-1)/599)≠1:=
    ne_one [false,true,true,false,false,true,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (1671211-1)=2*(3*(3*(5*(31*(599))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=31:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w31
  have eqn:q=599:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w599
theorem prime744137 : Nat.Prime 744137 := by
  apply lucas_primality 744137 (3:ZMod 744137)
  · exact eq_one [false,false,false,true,false,false,true,true,false,true,false,true,true,false,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 744137)^((744137-1)/2)≠1:=
    ne_one [false,false,true,false,false,true,true,false,true,false,true,true,false,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w191:(3:ZMod 744137)^((744137-1)/191)≠1:=
    ne_one [false,false,false,true,true,true,false,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w487:(3:ZMod 744137)^((744137-1)/487)≠1:=
    ne_one [false,false,false,true,true,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (744137-1)=2*(2*(2*(191*(487)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=191:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w191
  have eqn:q=487:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w487
theorem prime5953097 : Nat.Prime 5953097 := by
  apply lucas_primality 5953097 (3:ZMod 5953097)
  · exact eq_one [false,false,false,true,false,false,true,false,false,true,true,false,true,false,true,true,false,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 5953097)^((5953097-1)/2)≠1:=
    ne_one [false,false,true,false,false,true,false,false,true,true,false,true,false,true,true,false,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w744137:(3:ZMod 5953097)^((5953097-1)/744137)≠1:=
    ne_one [false,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (5953097-1)=2*(2*(2*(744137))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  have eqn:q=744137:=(Nat.prime_dvd_prime_iff_eq hp prime744137).mp hd; rw [eqn]; exact w744137
theorem prime19483 : Nat.Prime 19483 := by
  apply lucas_primality 19483 (2:ZMod 19483)
  · exact eq_one [false,true,false,true,true,false,false,false,false,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 19483)^((19483-1)/2)≠1:=
    ne_one [true,false,true,true,false,false,false,false,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(2:ZMod 19483)^((19483-1)/3)≠1:=
    ne_one [false,true,true,true,true,false,true,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w17:(2:ZMod 19483)^((19483-1)/17)≠1:=
    ne_one [false,true,false,true,true,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w191:(2:ZMod 19483)^((19483-1)/191)≠1:=
    ne_one [false,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (19483-1)=2*(3*(17*(191))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=17:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w17
  have eqn:q=191:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w191
theorem prime28717943 : Nat.Prime 28717943 := by
  apply lucas_primality 28717943 (5:ZMod 28717943)
  · exact eq_one [false,true,true,false,true,true,true,false,true,true,false,false,true,true,false,false,false,true,true,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 28717943)^((28717943-1)/2)≠1:=
    ne_one [true,true,false,true,true,true,false,true,true,false,false,true,true,false,false,false,true,true,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w11:(5:ZMod 28717943)^((28717943-1)/11)≠1:=
    ne_one [false,true,false,false,false,true,false,false,false,true,true,false,true,false,true,true,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w67:(5:ZMod 28717943)^((28717943-1)/67)≠1:=
    ne_one [false,true,false,false,true,false,true,false,false,true,false,true,false,false,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w19483:(5:ZMod 28717943)^((28717943-1)/19483)≠1:=
    ne_one [false,true,false,false,false,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (28717943-1)=2*(11*(67*(19483))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w11
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=67:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w67
  have eqn:q=19483:=(Nat.prime_dvd_prime_iff_eq hp prime19483).mp hd; rw [eqn]; exact w19483
theorem prime14537 : Nat.Prime 14537 := by
  apply lucas_primality 14537 (3:ZMod 14537)
  · exact eq_one [false,false,false,true,false,false,true,true,false,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 14537)^((14537-1)/2)≠1:=
    ne_one [false,false,true,false,false,true,true,false,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w23:(3:ZMod 14537)^((14537-1)/23)≠1:=
    ne_one [false,false,false,true,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w79:(3:ZMod 14537)^((14537-1)/79)≠1:=
    ne_one [false,false,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (14537-1)=2*(2*(2*(23*(79)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=23:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w23
  have eqn:q=79:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w79
theorem prime114348043 : Nat.Prime 114348043 := by
  apply lucas_primality 114348043 (3:ZMod 114348043)
  · exact eq_one [false,true,false,true,false,false,false,false,false,false,false,false,true,false,true,true,false,false,false,false,true,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 114348043)^((114348043-1)/2)≠1:=
    ne_one [true,false,true,false,false,false,false,false,false,false,false,true,false,true,true,false,false,false,false,true,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 114348043)^((114348043-1)/3)≠1:=
    ne_one [false,true,true,true,false,true,false,true,false,true,false,true,true,false,false,true,true,false,true,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w19:(3:ZMod 114348043)^((114348043-1)/19)≠1:=
    ne_one [false,true,true,true,false,false,false,false,true,false,true,false,true,false,true,true,true,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w23:(3:ZMod 114348043)^((114348043-1)/23)≠1:=
    ne_one [false,true,true,false,false,false,false,true,false,false,true,true,true,false,true,true,true,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w14537:(3:ZMod 114348043)^((114348043-1)/14537)≠1:=
    ne_one [false,true,false,true,true,true,false,true,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (114348043-1)=2*(3*(3*(19*(23*(14537))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=19:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w19
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=23:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w23
  have eqn:q=14537:=(Nat.prime_dvd_prime_iff_eq hp prime14537).mp hd; rw [eqn]; exact w14537
theorem prime686088259 : Nat.Prime 686088259 := by
  apply lucas_primality 686088259 (2:ZMod 686088259)
  · exact eq_one [false,true,false,false,false,false,true,false,false,false,false,false,false,true,true,true,false,false,true,false,false,true,true,true,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 686088259)^((686088259-1)/2)≠1:=
    ne_one [true,false,false,false,false,true,false,false,false,false,false,false,true,true,true,false,false,true,false,false,true,true,true,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(2:ZMod 686088259)^((686088259-1)/3)≠1:=
    ne_one [false,true,true,false,true,false,false,false,false,false,false,false,false,true,false,true,true,false,false,false,false,true,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w114348043:(2:ZMod 686088259)^((686088259-1)/114348043)≠1:=
    ne_one [false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (686088259-1)=2*(3*(114348043)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=114348043:=(Nat.prime_dvd_prime_iff_eq hp prime114348043).mp hd; rw [eqn]; exact w114348043
theorem prime12349588663 : Nat.Prime 12349588663 := by
  apply lucas_primality 12349588663 (5:ZMod 12349588663)
  · exact eq_one [false,true,true,false,true,true,false,true,false,false,true,false,false,false,true,true,true,true,true,false,true,false,false,false,false,false,false,false,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 12349588663)^((12349588663-1)/2)≠1:=
    ne_one [true,true,false,true,true,false,true,false,false,true,false,false,false,true,true,true,true,true,false,true,false,false,false,false,false,false,false,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(5:ZMod 12349588663)^((12349588663-1)/3)≠1:=
    ne_one [false,true,false,false,true,false,false,true,true,false,false,false,false,false,true,false,true,false,true,true,true,false,true,false,true,false,true,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w686088259:(5:ZMod 12349588663)^((12349588663-1)/686088259)≠1:=
    ne_one [false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (12349588663-1)=2*(3*(3*(686088259))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=686088259:=(Nat.prime_dvd_prime_iff_eq hp prime686088259).mp hd; rw [eqn]; exact w686088259
theorem prime36943 : Nat.Prime 36943 := by
  apply lucas_primality 36943 (3:ZMod 36943)
  · exact eq_one [false,true,true,true,false,false,true,false,false,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 36943)^((36943-1)/2)≠1:=
    ne_one [true,true,true,false,false,true,false,false,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 36943)^((36943-1)/3)≠1:=
    ne_one [false,true,false,true,true,false,false,false,false,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w47:(3:ZMod 36943)^((36943-1)/47)≠1:=
    ne_one [false,true,false,false,true,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w131:(3:ZMod 36943)^((36943-1)/131)≠1:=
    ne_one [false,true,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (36943-1)=2*(3*(47*(131))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=47:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w47
  have eqn:q=131:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w131
theorem prime221659 : Nat.Prime 221659 := by
  apply lucas_primality 221659 (3:ZMod 221659)
  · exact eq_one [false,true,false,true,true,false,true,true,true,false,false,false,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 221659)^((221659-1)/2)≠1:=
    ne_one [true,false,true,true,false,true,true,true,false,false,false,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 221659)^((221659-1)/3)≠1:=
    ne_one [false,true,true,true,true,false,false,true,false,false,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w36943:(3:ZMod 221659)^((221659-1)/36943)≠1:=
    ne_one [false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (221659-1)=2*(3*(36943)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=36943:=(Nat.prime_dvd_prime_iff_eq hp prime36943).mp hd; rw [eqn]; exact w36943
theorem prime22639970526343 : Nat.Prime 22639970526343 := by
  apply lucas_primality 22639970526343 (3:ZMod 22639970526343)
  · exact eq_one [false,true,true,false,false,false,false,true,false,false,true,false,false,true,false,true,false,true,true,false,false,true,true,false,true,true,true,false,false,false,true,false,true,true,true,false,true,false,false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 22639970526343)^((22639970526343-1)/2)≠1:=
    ne_one [true,true,false,false,false,false,true,false,false,true,false,false,true,false,true,false,true,true,false,false,true,true,false,true,true,true,false,false,false,true,false,true,true,true,false,true,false,false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 22639970526343)^((22639970526343-1)/3)≠1:=
    ne_one [false,true,false,false,false,false,false,true,true,false,false,false,false,true,true,true,false,false,true,true,false,false,true,true,true,true,true,false,true,false,false,false,true,false,true,true,true,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w13:(3:ZMod 22639970526343)^((22639970526343-1)/13)≠1:=
    ne_one [false,true,true,true,true,false,false,false,true,true,true,true,false,true,true,false,true,false,true,false,false,true,false,true,true,true,false,true,true,true,true,false,true,false,true,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w31:(3:ZMod 22639970526343)^((22639970526343-1)/31)≠1:=
    ne_one [false,true,false,true,true,true,false,true,false,true,false,false,true,true,false,true,true,true,true,true,false,false,false,true,false,true,false,true,false,false,false,false,false,true,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w53:(3:ZMod 22639970526343)^((22639970526343-1)/53)≠1:=
    ne_one [false,true,true,true,false,true,false,false,true,true,true,true,false,false,false,true,true,false,true,false,false,false,true,false,true,false,true,false,true,true,true,false,true,true,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w797:(3:ZMod 22639970526343)^((22639970526343-1)/797)≠1:=
    ne_one [false,true,true,true,true,true,false,true,true,false,false,true,true,false,false,true,false,false,false,true,false,true,false,false,true,false,true,true,true,false,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w221659:(3:ZMod 22639970526343)^((22639970526343-1)/221659)≠1:=
    ne_one [false,true,false,false,true,true,true,false,true,true,false,false,false,false,false,true,false,true,true,false,true,false,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (22639970526343-1)=2*(3*(13*(31*(53*(797*(221659)))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=13:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w13
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=31:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w31
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=53:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w53
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=797:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w797
  have eqn:q=221659:=(Nat.prime_dvd_prime_iff_eq hp prime221659).mp hd; rw [eqn]; exact w221659
theorem prime1601 : Nat.Prime 1601 := by
  apply lucas_primality 1601 (3:ZMod 1601)
  · exact eq_one [false,false,false,false,false,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 1601)^((1601-1)/2)≠1:=
    ne_one [false,false,false,false,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w5:(3:ZMod 1601)^((1601-1)/5)≠1:=
    ne_one [false,false,false,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (1601-1)=2*(2*(2*(2*(2*(2*(5*(5))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w5
theorem prime19213 : Nat.Prime 19213 := by
  apply lucas_primality 19213 (5:ZMod 19213)
  · exact eq_one [false,false,true,true,false,false,false,false,true,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 19213)^((19213-1)/2)≠1:=
    ne_one [false,true,true,false,false,false,false,true,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(5:ZMod 19213)^((19213-1)/3)≠1:=
    ne_one [false,false,true,false,false,false,false,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w1601:(5:ZMod 19213)^((19213-1)/1601)≠1:=
    ne_one [false,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (19213-1)=2*(2*(3*(1601))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=1601:=(Nat.prime_dvd_prime_iff_eq hp prime1601).mp hd; rw [eqn]; exact w1601
theorem prime5536225951 : Nat.Prime 5536225951 := by
  apply lucas_primality 5536225951 (7:ZMod 5536225951)
  · exact eq_one [false,true,true,true,true,false,false,true,false,true,false,true,true,false,false,false,false,false,true,true,true,true,true,true,true,false,false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(7:ZMod 5536225951)^((5536225951-1)/2)≠1:=
    ne_one [true,true,true,true,false,false,true,false,true,false,true,true,false,false,false,false,false,true,true,true,true,true,true,true,false,false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(7:ZMod 5536225951)^((5536225951-1)/3)≠1:=
    ne_one [false,true,false,true,false,false,false,true,true,true,false,false,true,true,false,true,false,true,true,true,true,true,true,true,true,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w5:(7:ZMod 5536225951)^((5536225951-1)/5)≠1:=
    ne_one [false,true,true,false,false,false,false,true,false,false,false,true,true,true,false,false,true,true,true,true,true,true,true,true,true,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w17:(7:ZMod 5536225951)^((5536225951-1)/17)≠1:=
    ne_one [false,true,true,true,true,true,false,true,false,true,true,true,false,true,false,false,true,false,false,true,false,true,true,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w113:(7:ZMod 5536225951)^((5536225951-1)/113)≠1:=
    ne_one [false,true,true,true,true,true,true,false,true,true,false,false,true,false,false,true,true,true,false,true,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w19213:(7:ZMod 5536225951)^((5536225951-1)/19213)≠1:=
    ne_one [false,true,true,false,true,false,false,true,true,false,true,false,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (5536225951-1)=2*(3*(5*(5*(17*(113*(19213)))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=17:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w17
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=113:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w113
  have eqn:q=19213:=(Nat.prime_dvd_prime_iff_eq hp prime19213).mp hd; rw [eqn]; exact w19213
theorem prime33217355707 : Nat.Prime 33217355707 := by
  apply lucas_primality 33217355707 (2:ZMod 33217355707)
  · exact eq_one [false,true,false,true,true,true,false,true,true,true,true,true,true,false,false,true,false,false,false,true,false,true,true,true,true,true,false,true,true,true,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 33217355707)^((33217355707-1)/2)≠1:=
    ne_one [true,false,true,true,true,false,true,true,true,true,true,true,false,false,true,false,false,false,true,false,true,true,true,true,true,false,true,true,true,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(2:ZMod 33217355707)^((33217355707-1)/3)≠1:=
    ne_one [false,true,true,true,true,true,false,false,true,false,true,false,true,true,false,false,false,false,false,true,true,true,true,true,true,true,false,false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w5536225951:(2:ZMod 33217355707)^((33217355707-1)/5536225951)≠1:=
    ne_one [false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (33217355707-1)=2*(3*(5536225951)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=5536225951:=(Nat.prime_dvd_prime_iff_eq hp prime5536225951).mp hd; rw [eqn]; exact w5536225951
theorem prime11293900940381 : Nat.Prime 11293900940381 := by
  apply lucas_primality 11293900940381 (3:ZMod 11293900940381)
  · exact eq_one [false,false,true,true,true,false,true,false,false,false,true,false,false,true,false,false,false,false,true,false,true,true,true,true,false,false,false,false,true,false,false,true,true,false,true,false,false,false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 11293900940381)^((11293900940381-1)/2)≠1:=
    ne_one [false,true,true,true,false,true,false,false,false,true,false,false,true,false,false,false,false,true,false,true,true,true,true,false,false,false,false,true,false,false,true,true,false,true,false,false,false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(3:ZMod 11293900940381)^((11293900940381-1)/5)≠1:=
    ne_one [false,false,true,true,false,true,false,true,true,false,true,true,false,true,true,false,false,true,false,true,false,false,true,true,true,false,false,true,false,true,true,true,true,false,true,true,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w17:(3:ZMod 11293900940381)^((11293900940381-1)/17)≠1:=
    ne_one [false,false,true,true,true,false,false,true,false,true,false,true,true,true,true,false,false,false,true,true,false,true,false,false,false,true,true,true,false,true,false,true,false,true,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w33217355707:(3:ZMod 11293900940381)^((11293900940381-1)/33217355707)≠1:=
    ne_one [false,false,true,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (11293900940381-1)=2*(2*(5*(17*(33217355707)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=17:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w17
  have eqn:q=33217355707:=(Nat.prime_dvd_prime_iff_eq hp prime33217355707).mp hd; rw [eqn]; exact w33217355707
theorem prime13349390911530343 : Nat.Prime 13349390911530343 := by
  apply lucas_primality 13349390911530343 (3:ZMod 13349390911530343)
  · exact eq_one [false,true,true,false,false,true,true,false,true,false,true,false,false,true,true,true,true,true,true,true,true,true,false,false,true,true,true,false,false,false,true,false,true,true,false,false,true,true,false,false,true,false,true,true,false,true,true,false,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 13349390911530343)^((13349390911530343-1)/2)≠1:=
    ne_one [true,true,false,false,true,true,false,true,false,true,false,false,true,true,true,true,true,true,true,true,true,false,false,true,true,true,false,false,false,true,false,true,true,false,false,true,true,false,false,true,false,true,true,false,true,true,false,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 13349390911530343)^((13349390911530343-1)/3)≠1:=
    ne_one [false,true,false,false,false,true,false,false,true,true,true,false,true,true,true,true,true,true,true,true,true,true,false,true,true,true,true,false,true,false,false,false,true,false,false,false,true,false,false,false,true,true,true,true,false,false,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w197:(3:ZMod 13349390911530343)^((13349390911530343-1)/197)≠1:=
    ne_one [false,true,true,true,false,true,false,false,false,true,false,true,true,false,true,true,false,false,false,true,true,true,false,true,true,false,true,false,false,true,true,false,true,false,false,false,false,true,false,true,true,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w11293900940381:(3:ZMod 13349390911530343)^((13349390911530343-1)/11293900940381)≠1:=
    ne_one [false,true,true,true,true,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (13349390911530343-1)=2*(3*(197*(11293900940381))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=197:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w197
  have eqn:q=11293900940381:=(Nat.prime_dvd_prime_iff_eq hp prime11293900940381).mp hd; rw [eqn]; exact w11293900940381
theorem prime25621 : Nat.Prime 25621 := by
  apply lucas_primality 25621 (10:ZMod 25621)
  · exact eq_one [false,false,true,false,true,false,false,false,false,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(10:ZMod 25621)^((25621-1)/2)≠1:=
    ne_one [false,true,false,true,false,false,false,false,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(10:ZMod 25621)^((25621-1)/3)≠1:=
    ne_one [false,false,true,true,true,false,true,false,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(10:ZMod 25621)^((25621-1)/5)≠1:=
    ne_one [false,false,true,false,false,false,false,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w7:(10:ZMod 25621)^((25621-1)/7)≠1:=
    ne_one [false,false,true,true,false,false,true,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w61:(10:ZMod 25621)^((25621-1)/61)≠1:=
    ne_one [false,false,true,false,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (25621-1)=2*(2*(3*(5*(7*(61))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  have eqn:q=61:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w61
theorem prime256211 : Nat.Prime 256211 := by
  apply lucas_primality 256211 (2:ZMod 256211)
  · exact eq_one [false,true,false,false,true,false,true,true,false,false,false,true,false,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 256211)^((256211-1)/2)≠1:=
    ne_one [true,false,false,true,false,true,true,false,false,false,true,false,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w5:(2:ZMod 256211)^((256211-1)/5)≠1:=
    ne_one [false,true,false,true,false,true,false,false,false,false,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w25621:(2:ZMod 256211)^((256211-1)/25621)≠1:=
    ne_one [false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (256211-1)=2*(5*(25621)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  have eqn:q=25621:=(Nat.prime_dvd_prime_iff_eq hp prime25621).mp hd; rw [eqn]; exact w25621
theorem prime2333 : Nat.Prime 2333 := by
  apply lucas_primality 2333 (2:ZMod 2333)
  · exact eq_one [false,false,true,true,true,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 2333)^((2333-1)/2)≠1:=
    ne_one [false,true,true,true,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w11:(2:ZMod 2333)^((2333-1)/11)≠1:=
    ne_one [false,false,true,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w53:(2:ZMod 2333)^((2333-1)/53)≠1:=
    ne_one [false,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (2333-1)=2*(2*(11*(53))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w11
  have eqn:q=53:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w53
theorem prime13999 : Nat.Prime 13999 := by
  apply lucas_primality 13999 (3:ZMod 13999)
  · exact eq_one [false,true,true,true,false,true,false,true,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 13999)^((13999-1)/2)≠1:=
    ne_one [true,true,true,false,true,false,true,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 13999)^((13999-1)/3)≠1:=
    ne_one [false,true,false,true,true,true,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w2333:(3:ZMod 13999)^((13999-1)/2333)≠1:=
    ne_one [false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (13999-1)=2*(3*(2333)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=2333:=(Nat.prime_dvd_prime_iff_eq hp prime2333).mp hd; rw [eqn]; exact w2333
theorem prime322004999 : Nat.Prime 322004999 := by
  apply lucas_primality 322004999 (7:ZMod 322004999)
  · exact eq_one [false,true,true,false,false,false,false,false,false,false,false,true,false,true,true,false,true,false,false,false,true,true,false,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(7:ZMod 322004999)^((322004999-1)/2)≠1:=
    ne_one [true,true,false,false,false,false,false,false,false,false,true,false,true,true,false,true,false,false,false,true,true,false,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w7:(7:ZMod 322004999)^((322004999-1)/7)≠1:=
    ne_one [false,true,false,true,false,false,true,false,false,true,false,true,false,true,true,true,true,false,true,true,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w31:(7:ZMod 322004999)^((322004999-1)/31)≠1:=
    ne_one [false,true,false,true,true,true,false,false,true,true,true,true,true,true,true,false,false,true,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w53:(7:ZMod 322004999)^((322004999-1)/53)≠1:=
    ne_one [false,true,true,true,false,true,false,true,false,false,true,false,true,true,false,true,false,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w13999:(7:ZMod 322004999)^((322004999-1)/13999)≠1:=
    ne_one [false,true,false,true,true,false,true,true,true,false,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (322004999-1)=2*(7*(31*(53*(13999)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=31:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w31
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=53:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w53
  have eqn:q=13999:=(Nat.prime_dvd_prime_iff_eq hp prime13999).mp hd; rw [eqn]; exact w13999
theorem prime644009999 : Nat.Prime 644009999 := by
  apply lucas_primality 644009999 (29:ZMod 644009999)
  · exact eq_one [false,true,true,true,false,false,false,false,false,false,false,false,true,false,true,true,false,true,false,false,false,true,true,false,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(29:ZMod 644009999)^((644009999-1)/2)≠1:=
    ne_one [true,true,true,false,false,false,false,false,false,false,false,true,false,true,true,false,true,false,false,false,true,true,false,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w322004999:(29:ZMod 644009999)^((644009999-1)/322004999)≠1:=
    ne_one [false,true] (by decide +kernel) (by decide +kernel)
  rw [show (644009999-1)=2*(322004999) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  have eqn:q=322004999:=(Nat.prime_dvd_prime_iff_eq hp prime322004999).mp hd; rw [eqn]; exact w322004999
theorem prime6726159702783854797 : Nat.Prime 6726159702783854797 := by
  apply lucas_primality 6726159702783854797 (2:ZMod 6726159702783854797)
  · exact eq_one [false,false,true,true,false,false,true,true,false,false,false,true,false,false,false,true,false,true,false,true,true,true,true,true,false,true,false,true,false,true,true,true,false,false,true,true,true,false,false,true,false,true,true,true,true,false,false,false,false,false,false,true,true,false,true,false,true,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 6726159702783854797)^((6726159702783854797-1)/2)≠1:=
    ne_one [false,true,true,false,false,true,true,false,false,false,true,false,false,false,true,false,true,false,true,true,true,true,true,false,true,false,true,false,true,true,true,false,false,true,true,true,false,false,true,false,true,true,true,true,false,false,false,false,false,false,true,true,false,true,false,true,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(2:ZMod 6726159702783854797)^((6726159702783854797-1)/3)≠1:=
    ne_one [false,false,true,false,false,false,true,false,false,false,false,true,true,false,true,true,false,false,false,true,false,true,false,true,true,true,false,false,false,true,false,true,true,false,false,true,false,false,false,true,true,true,true,true,true,false,true,false,true,false,true,true,true,false,false,false,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w43:(2:ZMod 6726159702783854797)^((6726159702783854797-1)/43)≠1:=
    ne_one [false,false,true,false,false,true,true,false,false,false,false,true,false,true,true,false,true,true,false,true,true,true,false,false,true,true,false,false,false,true,false,false,true,false,true,false,false,false,true,false,true,false,false,true,true,true,false,true,true,true,false,true,false,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w79:(2:ZMod 6726159702783854797)^((6726159702783854797-1)/79)≠1:=
    ne_one [false,false,true,false,true,true,true,false,true,true,false,true,false,false,false,false,true,false,false,true,true,false,true,true,false,false,false,true,true,false,true,true,false,true,true,false,false,false,false,true,true,true,false,true,true,true,true,false,false,true,true,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w256211:(2:ZMod 6726159702783854797)^((6726159702783854797-1)/256211)≠1:=
    ne_one [false,false,true,false,false,false,false,true,false,false,true,false,true,false,false,false,false,true,false,false,false,true,true,false,false,true,true,true,true,false,true,false,false,false,false,false,false,true,true,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w644009999:(2:ZMod 6726159702783854797)^((6726159702783854797-1)/644009999)≠1:=
    ne_one [false,false,true,false,true,true,true,false,false,true,true,true,true,false,false,true,true,false,true,false,false,false,false,true,false,true,true,true,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (6726159702783854797-1)=2*(2*(3*(43*(79*(256211*(644009999)))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=43:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w43
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=79:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w79
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=256211:=(Nat.prime_dvd_prime_iff_eq hp prime256211).mp leaf; rw [eqn]; exact w256211
  have eqn:q=644009999:=(Nat.prime_dvd_prime_iff_eq hp prime644009999).mp hd; rw [eqn]; exact w644009999
theorem prime11035153 : Nat.Prime 11035153 := by
  apply lucas_primality 11035153 (5:ZMod 11035153)
  · exact eq_one [false,false,false,false,true,false,false,false,false,true,false,false,false,true,true,false,false,false,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 11035153)^((11035153-1)/2)≠1:=
    ne_one [false,false,false,true,false,false,false,false,true,false,false,false,true,true,false,false,false,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(5:ZMod 11035153)^((11035153-1)/3)≠1:=
    ne_one [false,false,false,false,true,true,false,true,false,false,false,false,false,true,false,false,false,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w197:(5:ZMod 11035153)^((11035153-1)/197)≠1:=
    ne_one [false,false,false,false,true,false,true,true,false,true,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w389:(5:ZMod 11035153)^((11035153-1)/389)≠1:=
    ne_one [false,false,false,false,true,false,true,true,false,true,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (11035153-1)=2*(2*(2*(2*(3*(3*(197*(389))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=197:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w197
  have eqn:q=389:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w389
theorem prime37960464301 : Nat.Prime 37960464301 := by
  apply lucas_primality 37960464301 (6:ZMod 37960464301)
  · exact eq_one [false,false,true,true,false,true,false,true,true,true,true,false,true,true,false,true,false,true,true,true,true,false,false,true,false,true,true,false,true,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(6:ZMod 37960464301)^((37960464301-1)/2)≠1:=
    ne_one [false,true,true,false,true,false,true,true,true,true,false,true,true,false,true,false,true,true,true,true,false,false,true,false,true,true,false,true,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(6:ZMod 37960464301)^((37960464301-1)/3)≠1:=
    ne_one [false,false,true,false,false,true,true,true,true,true,true,false,false,true,true,true,false,false,true,false,true,true,false,false,false,true,false,false,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(6:ZMod 37960464301)^((37960464301-1)/5)≠1:=
    ne_one [false,false,true,true,true,true,false,true,false,false,true,false,false,true,false,false,false,true,true,false,false,false,false,true,false,false,true,false,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w11:(6:ZMod 37960464301)^((37960464301-1)/11)≠1:=
    ne_one [false,false,true,false,false,false,false,true,false,true,true,false,true,false,true,false,true,false,false,false,true,true,false,true,true,false,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w59:(6:ZMod 37960464301)^((37960464301-1)/59)≠1:=
    ne_one [false,false,true,false,false,false,true,false,false,false,false,true,true,true,true,false,true,false,false,true,true,false,true,false,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w241:(6:ZMod 37960464301)^((37960464301-1)/241)≠1:=
    ne_one [false,false,true,true,false,true,true,false,false,true,false,false,true,true,true,false,true,true,false,false,false,true,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w809:(6:ZMod 37960464301)^((37960464301-1)/809)≠1:=
    ne_one [false,false,true,true,false,false,true,true,true,true,false,true,true,true,true,true,true,true,false,true,false,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (37960464301-1)=2*(2*(3*(5*(5*(11*(59*(241*(809)))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w11
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=59:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w59
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=241:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w241
  have eqn:q=809:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w809
theorem prime9215789693276607167 : Nat.Prime 9215789693276607167 := by
  apply lucas_primality 9215789693276607167 (5:ZMod 9215789693276607167)
  · exact eq_one [false,true,true,true,true,true,false,true,false,true,false,false,true,false,true,false,true,false,true,false,true,true,true,false,false,false,false,false,true,false,false,false,false,true,true,false,false,true,true,true,true,true,true,true,false,false,false,false,true,false,true,false,false,true,true,true,true,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 9215789693276607167)^((9215789693276607167-1)/2)≠1:=
    ne_one [true,true,true,true,true,false,true,false,true,false,false,true,false,true,false,true,false,true,false,true,true,true,false,false,false,false,false,true,false,false,false,false,true,true,false,false,true,true,true,true,true,true,true,false,false,false,false,true,false,true,false,false,true,true,true,true,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w11:(5:ZMod 9215789693276607167)^((9215789693276607167-1)/11)≠1:=
    ne_one [false,true,false,true,true,true,true,true,false,false,false,true,true,false,true,true,false,false,true,false,false,false,true,true,false,false,false,true,true,false,false,false,true,true,true,true,false,false,true,true,true,false,true,false,true,true,true,false,false,false,false,false,false,true,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w11035153:(5:ZMod 9215789693276607167)^((9215789693276607167-1)/11035153)≠1:=
    ne_one [false,true,true,true,true,false,true,true,false,false,false,true,false,false,true,true,true,true,false,false,false,true,false,true,true,false,false,false,true,true,true,false,false,true,false,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w37960464301:(5:ZMod 9215789693276607167)^((9215789693276607167-1)/37960464301)≠1:=
    ne_one [false,true,true,false,true,true,true,false,true,false,true,true,false,true,true,false,false,false,false,true,true,true,true,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (9215789693276607167-1)=2*(11*(11035153*(37960464301))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w11
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11035153:=(Nat.prime_dvd_prime_iff_eq hp prime11035153).mp leaf; rw [eqn]; exact w11035153
  have eqn:q=37960464301:=(Nat.prime_dvd_prime_iff_eq hp prime37960464301).mp hd; rw [eqn]; exact w37960464301
theorem prime5279 : Nat.Prime 5279 := by
  apply lucas_primality 5279 (7:ZMod 5279)
  · exact eq_one [false,true,true,true,true,false,false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(7:ZMod 5279)^((5279-1)/2)≠1:=
    ne_one [true,true,true,true,false,false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w7:(7:ZMod 5279)^((5279-1)/7)≠1:=
    ne_one [false,true,false,false,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w13:(7:ZMod 5279)^((5279-1)/13)≠1:=
    ne_one [false,true,true,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w29:(7:ZMod 5279)^((5279-1)/29)≠1:=
    ne_one [false,true,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (5279-1)=2*(7*(13*(29))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=13:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w13
  have eqn:q=29:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w29
theorem prime61543 : Nat.Prime 61543 := by
  apply lucas_primality 61543 (3:ZMod 61543)
  · exact eq_one [false,true,true,false,false,true,true,false,false,false,false,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 61543)^((61543-1)/2)≠1:=
    ne_one [true,true,false,false,true,true,false,false,false,false,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 61543)^((61543-1)/3)≠1:=
    ne_one [false,true,false,false,false,true,false,false,false,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w13:(3:ZMod 61543)^((61543-1)/13)≠1:=
    ne_one [false,true,true,true,true,true,true,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w263:(3:ZMod 61543)^((61543-1)/263)≠1:=
    ne_one [false,true,false,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (61543-1)=2*(3*(3*(13*(263)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=13:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w13
  have eqn:q=263:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w263
theorem prime1229 : Nat.Prime 1229 := by
  apply lucas_primality 1229 (2:ZMod 1229)
  · exact eq_one [false,false,true,true,false,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 1229)^((1229-1)/2)≠1:=
    ne_one [false,true,true,false,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w307:(2:ZMod 1229)^((1229-1)/307)≠1:=
    ne_one [false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (1229-1)=2*(2*(307)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  have eqn:q=307:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w307
theorem prime2459 : Nat.Prime 2459 := by
  apply lucas_primality 2459 (2:ZMod 2459)
  · exact eq_one [false,true,false,true,true,false,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 2459)^((2459-1)/2)≠1:=
    ne_one [true,false,true,true,false,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w1229:(2:ZMod 2459)^((2459-1)/1229)≠1:=
    ne_one [false,true] (by decide +kernel) (by decide +kernel)
  rw [show (2459-1)=2*(1229) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  have eqn:q=1229:=(Nat.prime_dvd_prime_iff_eq hp prime1229).mp hd; rw [eqn]; exact w1229
theorem prime440465917 : Nat.Prime 440465917 := by
  apply lucas_primality 440465917 (5:ZMod 440465917)
  · exact eq_one [false,false,true,true,true,true,true,true,true,false,false,true,true,true,true,true,false,false,false,false,false,false,true,false,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 440465917)^((440465917-1)/2)≠1:=
    ne_one [false,true,true,true,true,true,true,true,false,false,true,true,true,true,true,false,false,false,false,false,false,true,false,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(5:ZMod 440465917)^((440465917-1)/3)≠1:=
    ne_one [false,false,true,false,true,false,true,false,true,true,false,false,true,false,true,false,false,false,false,false,false,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w11:(5:ZMod 440465917)^((440465917-1)/11)≠1:=
    ne_one [false,false,true,false,true,true,true,false,true,true,true,true,true,true,true,true,false,true,false,false,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w23:(5:ZMod 440465917)^((440465917-1)/23)≠1:=
    ne_one [false,false,true,false,false,true,true,false,true,true,true,false,true,true,false,false,false,false,true,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w59:(5:ZMod 440465917)^((440465917-1)/59)≠1:=
    ne_one [false,false,true,false,true,true,false,false,false,true,false,true,false,true,true,true,true,false,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w2459:(5:ZMod 440465917)^((440465917-1)/2459)≠1:=
    ne_one [false,false,true,false,true,true,false,true,true,true,false,true,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (440465917-1)=2*(2*(3*(11*(23*(59*(2459)))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w11
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=23:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w23
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=59:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w59
  have eqn:q=2459:=(Nat.prime_dvd_prime_iff_eq hp prime2459).mp hd; rw [eqn]; exact w2459
theorem prime44998605923685461 : Nat.Prime 44998605923685461 := by
  apply lucas_primality 44998605923685461 (2:ZMod 44998605923685461)
  · exact eq_one [false,false,true,false,true,false,true,false,false,false,true,false,true,false,false,false,false,false,false,true,true,true,true,false,true,false,false,false,false,true,true,false,false,true,true,true,true,true,true,true,true,false,true,true,true,false,true,true,true,true,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 44998605923685461)^((44998605923685461-1)/2)≠1:=
    ne_one [false,true,false,true,false,true,false,false,false,true,false,true,false,false,false,false,false,false,true,true,true,true,false,true,false,false,false,false,true,true,false,false,true,true,true,true,true,true,true,true,false,true,true,true,false,true,true,true,true,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(2:ZMod 44998605923685461)^((44998605923685461-1)/5)≠1:=
    ne_one [false,false,true,false,false,false,true,false,true,true,true,false,true,true,false,false,true,true,false,true,false,false,true,false,false,false,false,false,false,true,true,true,false,true,false,false,true,true,false,false,true,false,false,true,true,true,true,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w83:(2:ZMod 44998605923685461)^((44998605923685461-1)/83)≠1:=
    ne_one [false,false,true,true,true,false,true,true,true,true,true,true,true,false,true,false,true,true,false,false,false,true,false,false,false,true,false,false,true,false,false,true,true,false,true,false,true,false,false,false,true,false,true,true,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w61543:(2:ZMod 44998605923685461)^((44998605923685461-1)/61543)≠1:=
    ne_one [false,false,true,true,false,false,false,true,false,false,true,false,false,false,false,false,true,false,true,false,true,false,true,false,true,false,true,true,true,true,false,false,false,true,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w440465917:(2:ZMod 44998605923685461)^((44998605923685461-1)/440465917)≠1:=
    ne_one [false,false,true,false,false,true,true,true,true,true,false,true,true,false,true,true,false,true,true,false,true,false,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (44998605923685461-1)=2*(2*(5*(83*(61543*(440465917))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=83:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w83
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=61543:=(Nat.prime_dvd_prime_iff_eq hp prime61543).mp leaf; rw [eqn]; exact w61543
  have eqn:q=440465917:=(Nat.prime_dvd_prime_iff_eq hp prime440465917).mp hd; rw [eqn]; exact w440465917
theorem prime5473097641062963040181761 : Nat.Prime 5473097641062963040181761 := by
  apply lucas_primality 5473097641062963040181761 (17:ZMod 5473097641062963040181761)
  · exact eq_one [false,false,false,false,false,false,false,false,false,true,true,true,true,false,true,false,true,true,true,true,false,true,false,false,false,true,true,false,true,true,false,false,true,false,true,true,false,true,false,true,false,false,false,false,true,false,true,true,false,true,true,false,true,true,false,true,true,true,true,false,true,true,false,false,true,false,false,true,true,true,true,true,false,true,true,false,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(17:ZMod 5473097641062963040181761)^((5473097641062963040181761-1)/2)≠1:=
    ne_one [false,false,false,false,false,false,false,false,true,true,true,true,false,true,false,true,true,true,true,false,true,false,false,false,true,true,false,true,true,false,false,true,false,true,true,false,true,false,true,false,false,false,false,true,false,true,true,false,true,true,false,true,true,false,true,true,true,true,false,true,true,false,false,true,false,false,true,true,true,true,true,false,true,true,false,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(17:ZMod 5473097641062963040181761)^((5473097641062963040181761-1)/3)≠1:=
    ne_one [false,false,false,false,false,false,false,false,false,true,false,true,false,false,true,true,true,true,true,true,false,false,false,false,false,true,false,false,true,false,false,false,true,true,true,true,false,false,false,true,true,false,true,false,false,false,true,false,false,true,false,false,true,false,false,true,false,true,false,false,true,false,false,false,true,true,false,false,true,false,true,false,false,true,false,false,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w5:(17:ZMod 5473097641062963040181761)^((5473097641062963040181761-1)/5)≠1:=
    ne_one [false,false,false,false,false,false,false,false,false,true,true,false,false,false,true,false,false,true,true,false,true,false,true,true,false,true,false,true,false,false,false,false,true,false,false,true,false,false,false,true,false,true,true,false,true,true,true,true,false,true,false,true,false,false,false,true,true,false,false,false,true,true,true,false,true,true,false,true,false,false,true,true,true,true,true,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w5279:(17:ZMod 5473097641062963040181761)^((5473097641062963040181761-1)/5279)≠1:=
    ne_one [false,false,false,false,false,false,false,false,false,true,false,false,false,true,true,true,true,false,true,false,false,true,false,false,true,true,true,false,true,true,false,false,false,false,true,false,false,false,true,false,false,true,true,true,false,true,true,false,true,true,false,true,false,false,false,false,false,false,true,false,true,true,false,false,false,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w44998605923685461:(17:ZMod 5473097641062963040181761)^((5473097641062963040181761-1)/44998605923685461)≠1:=
    ne_one [false,false,false,false,false,false,false,false,false,true,true,false,false,true,true,true,true,true,true,true,true,true,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (5473097641062963040181761-1)=2*(2*(2*(2*(2*(2*(2*(2*(2*(3*(3*(5*(5279*(44998605923685461))))))))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5279:=(Nat.prime_dvd_prime_iff_eq hp prime5279).mp leaf; rw [eqn]; exact w5279
  have eqn:q=44998605923685461:=(Nat.prime_dvd_prime_iff_eq hp prime44998605923685461).mp hd; rw [eqn]; exact w44998605923685461
theorem prime65677171692755556482181133 : Nat.Prime 65677171692755556482181133 := by
  apply lucas_primality 65677171692755556482181133 (5:ZMod 65677171692755556482181133)
  · exact eq_one [false,false,true,true,false,false,false,false,false,false,false,true,false,true,true,false,false,false,false,true,true,true,false,false,false,true,false,true,false,false,false,true,false,true,true,true,true,false,false,false,false,false,false,true,false,false,true,true,true,false,false,false,true,false,false,true,false,false,true,true,true,false,false,true,false,true,true,true,false,true,false,true,true,true,false,false,true,false,true,false,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 65677171692755556482181133)^((65677171692755556482181133-1)/2)≠1:=
    ne_one [false,true,true,false,false,false,false,false,false,false,true,false,true,true,false,false,false,false,true,true,true,false,false,false,true,false,true,false,false,false,true,false,true,true,true,true,false,false,false,false,false,false,true,false,false,true,true,true,false,false,false,true,false,false,true,false,false,true,true,true,false,false,true,false,true,true,true,false,true,false,true,true,true,false,false,true,false,true,false,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(5:ZMod 65677171692755556482181133)^((65677171692755556482181133-1)/3)≠1:=
    ne_one [false,false,true,false,false,false,false,false,false,false,false,true,true,true,true,false,true,false,true,true,true,true,false,true,false,false,false,true,true,false,true,true,false,false,true,false,true,true,false,true,false,true,false,false,false,false,true,false,true,true,false,true,true,false,true,true,false,true,true,true,true,false,true,true,false,false,true,false,false,true,true,true,true,true,false,true,true,false,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w5473097641062963040181761:(5:ZMod 65677171692755556482181133)^((65677171692755556482181133-1)/5473097641062963040181761)≠1:=
    ne_one [false,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (65677171692755556482181133-1)=2*(2*(3*(5473097641062963040181761))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=5473097641062963040181761:=(Nat.prime_dvd_prime_iff_eq hp prime5473097641062963040181761).mp hd; rw [eqn]; exact w5473097641062963040181761
theorem prime1489 : Nat.Prime 1489 := by
  apply lucas_primality 1489 (14:ZMod 1489)
  · exact eq_one [false,false,false,false,true,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(14:ZMod 1489)^((1489-1)/2)≠1:=
    ne_one [false,false,false,true,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(14:ZMod 1489)^((1489-1)/3)≠1:=
    ne_one [false,false,false,false,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w31:(14:ZMod 1489)^((1489-1)/31)≠1:=
    ne_one [false,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (1489-1)=2*(2*(2*(2*(3*(31))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=31:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w31
theorem prime26113 : Nat.Prime 26113 := by
  apply lucas_primality 26113 (7:ZMod 26113)
  · exact eq_one [false,false,false,false,false,false,false,false,false,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(7:ZMod 26113)^((26113-1)/2)≠1:=
    ne_one [false,false,false,false,false,false,false,false,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(7:ZMod 26113)^((26113-1)/3)≠1:=
    ne_one [false,false,false,false,false,false,false,false,false,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w17:(7:ZMod 26113)^((26113-1)/17)≠1:=
    ne_one [false,false,false,false,false,false,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (26113-1)=2*(2*(2*(2*(2*(2*(2*(2*(2*(3*(17)))))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=17:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w17
theorem prime3889 : Nat.Prime 3889 := by
  apply lucas_primality 3889 (11:ZMod 3889)
  · exact eq_one [false,false,false,false,true,true,false,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(11:ZMod 3889)^((3889-1)/2)≠1:=
    ne_one [false,false,false,true,true,false,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(11:ZMod 3889)^((3889-1)/3)≠1:=
    ne_one [false,false,false,false,true,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (3889-1)=2*(2*(2*(2*(3*(3*(3*(3*(3)))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w3
theorem prime93337 : Nat.Prime 93337 := by
  apply lucas_primality 93337 (5:ZMod 93337)
  · exact eq_one [false,false,false,true,true,false,false,true,false,false,true,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 93337)^((93337-1)/2)≠1:=
    ne_one [false,false,true,true,false,false,true,false,false,true,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(5:ZMod 93337)^((93337-1)/3)≠1:=
    ne_one [false,false,false,true,false,false,false,true,true,false,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w3889:(5:ZMod 93337)^((93337-1)/3889)≠1:=
    ne_one [false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (93337-1)=2*(2*(2*(3*(3889)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=3889:=(Nat.prime_dvd_prime_iff_eq hp prime3889).mp hd; rw [eqn]; exact w3889
theorem prime21094163 : Nat.Prime 21094163 := by
  apply lucas_primality 21094163 (2:ZMod 21094163)
  · exact eq_one [false,true,false,false,true,false,false,false,true,true,true,true,true,false,true,true,true,false,false,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 21094163)^((21094163-1)/2)≠1:=
    ne_one [true,false,false,true,false,false,false,true,true,true,true,true,false,true,true,true,false,false,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w113:(2:ZMod 21094163)^((21094163-1)/113)≠1:=
    ne_one [false,true,false,false,true,true,false,false,true,false,false,true,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w93337:(2:ZMod 21094163)^((21094163-1)/93337)≠1:=
    ne_one [false,true,false,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (21094163-1)=2*(113*(93337)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=113:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w113
  have eqn:q=93337:=(Nat.prime_dvd_prime_iff_eq hp prime93337).mp hd; rw [eqn]; exact w93337
theorem prime31543 : Nat.Prime 31543 := by
  apply lucas_primality 31543 (3:ZMod 31543)
  · exact eq_one [false,true,true,false,true,true,false,false,true,true,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 31543)^((31543-1)/2)≠1:=
    ne_one [true,true,false,true,true,false,false,true,true,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 31543)^((31543-1)/3)≠1:=
    ne_one [false,true,false,false,true,false,false,false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w7:(3:ZMod 31543)^((31543-1)/7)≠1:=
    ne_one [false,true,false,true,true,false,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w751:(3:ZMod 31543)^((31543-1)/751)≠1:=
    ne_one [false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (31543-1)=2*(3*(7*(751))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  have eqn:q=751:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w751
theorem prime126173 : Nat.Prime 126173 := by
  apply lucas_primality 126173 (2:ZMod 126173)
  · exact eq_one [false,false,true,true,true,false,true,true,false,false,true,true,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 126173)^((126173-1)/2)≠1:=
    ne_one [false,true,true,true,false,true,true,false,false,true,true,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w31543:(2:ZMod 126173)^((126173-1)/31543)≠1:=
    ne_one [false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (126173-1)=2*(2*(31543)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  have eqn:q=31543:=(Nat.prime_dvd_prime_iff_eq hp prime31543).mp hd; rw [eqn]; exact w31543
theorem prime95386789 : Nat.Prime 95386789 := by
  apply lucas_primality 95386789 (2:ZMod 95386789)
  · exact eq_one [false,false,true,false,false,true,false,true,false,false,true,true,true,true,true,false,true,true,true,true,false,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 95386789)^((95386789-1)/2)≠1:=
    ne_one [false,true,false,false,true,false,true,false,false,true,true,true,true,true,false,true,true,true,true,false,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(2:ZMod 95386789)^((95386789-1)/3)≠1:=
    ne_one [false,false,true,true,false,false,false,true,true,false,false,true,false,true,false,false,true,false,true,false,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w7:(2:ZMod 95386789)^((95386789-1)/7)≠1:=
    ne_one [false,false,true,true,true,true,false,false,true,false,true,true,false,true,true,true,true,true,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w126173:(2:ZMod 95386789)^((95386789-1)/126173)≠1:=
    ne_one [false,false,true,false,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (95386789-1)=2*(2*(3*(3*(3*(7*(126173)))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  have eqn:q=126173:=(Nat.prime_dvd_prime_iff_eq hp prime126173).mp hd; rw [eqn]; exact w126173
theorem prime37996324998547740539691528067877 : Nat.Prime 37996324998547740539691528067877 := by
  apply lucas_primality 37996324998547740539691528067877 (3:ZMod 37996324998547740539691528067877)
  · exact eq_one [false,false,true,false,false,true,false,false,true,true,false,true,true,false,false,true,true,true,true,false,false,false,false,false,false,true,false,true,true,true,false,false,true,true,true,true,true,true,false,true,false,false,true,true,false,true,true,false,true,false,true,true,true,true,true,false,true,false,false,true,false,false,false,true,false,true,true,false,true,false,false,false,true,true,false,false,false,true,true,false,true,true,true,true,true,true,false,true,false,false,true,false,true,false,false,true,true,true,true,true,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 37996324998547740539691528067877)^((37996324998547740539691528067877-1)/2)≠1:=
    ne_one [false,true,false,false,true,false,false,true,true,false,true,true,false,false,true,true,true,true,false,false,false,false,false,false,true,false,true,true,true,false,false,true,true,true,true,true,true,false,true,false,false,true,true,false,true,true,false,true,false,true,true,true,true,true,false,true,false,false,true,false,false,false,true,false,true,true,false,true,false,false,false,true,true,false,false,false,true,true,false,true,true,true,true,true,true,false,true,false,false,true,false,true,false,false,true,true,true,true,true,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w41:(3:ZMod 37996324998547740539691528067877)^((37996324998547740539691528067877-1)/41)≠1:=
    ne_one [false,false,true,false,false,false,false,true,false,true,true,false,true,false,false,false,false,false,true,false,false,true,true,false,false,true,false,true,true,false,false,false,true,true,false,false,false,false,true,false,false,true,false,false,true,false,false,true,false,true,true,false,true,true,true,true,false,true,false,false,true,false,false,true,true,true,true,false,false,true,true,true,false,true,true,true,false,false,false,false,true,false,true,false,true,true,true,false,false,true,false,false,true,true,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w73:(3:ZMod 37996324998547740539691528067877)^((37996324998547740539691528067877-1)/73)≠1:=
    ne_one [false,false,true,false,false,false,false,false,false,true,false,true,false,false,true,true,false,true,true,true,true,false,true,false,true,true,true,false,false,true,false,false,false,false,true,false,true,false,false,false,true,true,true,true,false,true,false,false,false,false,false,false,true,true,true,true,true,false,true,true,true,false,false,false,false,true,true,true,true,false,false,true,false,true,true,false,false,false,false,true,true,false,false,false,true,false,true,true,true,false,false,false,true,false,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w113:(3:ZMod 37996324998547740539691528067877)^((37996324998547740539691528067877-1)/113)≠1:=
    ne_one [false,false,true,false,false,true,true,false,true,true,true,true,true,false,true,true,true,false,true,false,true,true,true,false,false,true,true,false,false,true,true,false,false,true,false,false,true,true,false,true,false,true,true,true,true,true,true,true,true,false,true,true,true,false,true,false,false,false,false,false,false,true,true,false,false,false,true,true,false,true,false,true,true,true,true,false,false,false,false,false,false,false,true,true,true,true,true,false,false,true,true,true,true,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w359:(3:ZMod 37996324998547740539691528067877)^((37996324998547740539691528067877-1)/359)≠1:=
    ne_one [false,false,true,true,true,true,false,false,true,false,false,false,false,true,false,false,true,true,true,true,true,true,false,true,false,true,false,false,false,true,false,true,true,false,true,true,false,true,true,false,true,false,true,false,true,true,false,true,true,false,false,true,false,true,false,false,true,false,false,true,true,false,true,true,false,true,false,true,false,true,false,false,true,false,false,false,false,false,true,false,false,false,true,true,true,true,true,true,true,false,true,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w1489:(3:ZMod 37996324998547740539691528067877)^((37996324998547740539691528067877-1)/1489)≠1:=
    ne_one [false,false,true,false,false,true,true,true,true,false,true,true,true,false,true,true,true,false,true,true,false,true,true,false,true,true,false,true,false,false,true,true,false,false,false,false,false,true,false,false,false,true,true,true,false,false,true,false,true,true,true,false,false,false,false,false,true,true,true,true,false,true,false,false,true,false,true,false,true,true,true,true,true,false,false,false,false,false,false,false,false,false,true,false,true,true,true,false,false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w26113:(3:ZMod 37996324998547740539691528067877)^((37996324998547740539691528067877-1)/26113)≠1:=
    ne_one [false,false,true,false,false,true,false,false,true,true,false,false,false,false,true,false,true,true,true,false,false,false,true,false,true,false,true,false,true,false,true,true,false,false,true,false,false,false,true,true,true,true,true,true,true,true,true,true,false,false,true,false,true,false,false,true,true,true,false,true,false,true,false,false,true,false,false,true,true,true,false,true,true,true,false,true,true,false,false,true,true,true,false,false,true,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w21094163:(3:ZMod 37996324998547740539691528067877)^((37996324998547740539691528067877-1)/21094163)≠1:=
    ne_one [false,false,true,true,false,false,true,true,false,false,false,true,false,false,true,true,true,false,false,false,true,false,false,false,true,false,false,false,false,true,false,true,false,false,false,true,false,false,false,true,true,false,true,true,true,false,true,true,true,true,false,true,true,true,true,false,false,true,true,false,false,true,false,false,true,true,true,true,false,true,true,false,true,false,true,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w95386789:(3:ZMod 37996324998547740539691528067877)^((37996324998547740539691528067877-1)/95386789)≠1:=
    ne_one [false,false,true,false,true,false,true,false,true,false,false,false,true,false,true,true,false,false,false,false,true,true,true,true,true,false,false,true,true,true,false,true,true,false,true,true,false,true,false,true,true,true,false,true,true,true,false,false,true,true,true,true,false,true,true,true,false,true,true,false,false,false,false,false,false,true,false,true,true,false,true,false,false,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (37996324998547740539691528067877-1)=2*(2*(41*(73*(113*(359*(1489*(26113*(21094163*(95386789))))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=41:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w41
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=73:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w73
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=113:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w113
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=359:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w359
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=1489:=(Nat.prime_dvd_prime_iff_eq hp prime1489).mp leaf; rw [eqn]; exact w1489
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=26113:=(Nat.prime_dvd_prime_iff_eq hp prime26113).mp leaf; rw [eqn]; exact w26113
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=21094163:=(Nat.prime_dvd_prime_iff_eq hp prime21094163).mp leaf; rw [eqn]; exact w21094163
  have eqn:q=95386789:=(Nat.prime_dvd_prime_iff_eq hp prime95386789).mp hd; rw [eqn]; exact w95386789
theorem prime2897 : Nat.Prime 2897 := by
  apply lucas_primality 2897 (3:ZMod 2897)
  · exact eq_one [false,false,false,false,true,false,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 2897)^((2897-1)/2)≠1:=
    ne_one [false,false,false,true,false,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w181:(3:ZMod 2897)^((2897-1)/181)≠1:=
    ne_one [false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (2897-1)=2*(2*(2*(2*(181)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  have eqn:q=181:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w181
theorem prime17383 : Nat.Prime 17383 := by
  apply lucas_primality 17383 (5:ZMod 17383)
  · exact eq_one [false,true,true,false,false,true,true,true,true,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 17383)^((17383-1)/2)≠1:=
    ne_one [true,true,false,false,true,true,true,true,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(5:ZMod 17383)^((17383-1)/3)≠1:=
    ne_one [false,true,false,false,false,true,false,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w2897:(5:ZMod 17383)^((17383-1)/2897)≠1:=
    ne_one [false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (17383-1)=2*(3*(2897)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=2897:=(Nat.prime_dvd_prime_iff_eq hp prime2897).mp hd; rw [eqn]; exact w2897
theorem prime382427 : Nat.Prime 382427 := by
  apply lucas_primality 382427 (2:ZMod 382427)
  · exact eq_one [false,true,false,true,true,false,true,true,true,false,true,false,true,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 382427)^((382427-1)/2)≠1:=
    ne_one [true,false,true,true,false,true,true,true,false,true,false,true,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w11:(2:ZMod 382427)^((382427-1)/11)≠1:=
    ne_one [false,true,true,true,false,false,true,true,true,true,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w17383:(2:ZMod 382427)^((382427-1)/17383)≠1:=
    ne_one [false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (382427-1)=2*(11*(17383)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w11
  have eqn:q=17383:=(Nat.prime_dvd_prime_iff_eq hp prime17383).mp hd; rw [eqn]; exact w17383
theorem prime14054837 : Nat.Prime 14054837 := by
  apply lucas_primality 14054837 (2:ZMod 14054837)
  · exact eq_one [false,false,true,false,true,true,false,true,true,false,true,false,true,true,true,false,false,true,true,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 14054837)^((14054837-1)/2)≠1:=
    ne_one [false,true,false,true,true,false,true,true,false,true,false,true,true,true,false,false,true,true,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w73:(2:ZMod 14054837)^((14054837-1)/73)≠1:=
    ne_one [false,false,true,false,true,false,false,false,false,false,false,false,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w127:(2:ZMod 14054837)^((14054837-1)/127)≠1:=
    ne_one [false,false,true,true,false,false,true,false,false,false,false,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w379:(2:ZMod 14054837)^((14054837-1)/379)≠1:=
    ne_one [false,false,true,true,true,false,true,true,false,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (14054837-1)=2*(2*(73*(127*(379)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=73:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w73
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=127:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w127
  have eqn:q=379:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w379
theorem prime281096741 : Nat.Prime 281096741 := by
  apply lucas_primality 281096741 (2:ZMod 281096741)
  · exact eq_one [false,false,true,false,false,true,false,false,false,true,false,false,true,true,false,false,true,false,false,false,false,false,true,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 281096741)^((281096741-1)/2)≠1:=
    ne_one [false,true,false,false,true,false,false,false,true,false,false,true,true,false,false,true,false,false,false,false,false,true,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(2:ZMod 281096741)^((281096741-1)/5)≠1:=
    ne_one [false,false,true,false,true,false,true,true,false,true,true,false,true,false,true,true,true,false,false,true,true,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w14054837:(2:ZMod 281096741)^((281096741-1)/14054837)≠1:=
    ne_one [false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (281096741-1)=2*(2*(5*(14054837))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  have eqn:q=14054837:=(Nat.prime_dvd_prime_iff_eq hp prime14054837).mp hd; rw [eqn]; exact w14054837
theorem prime441884076853 : Nat.Prime 441884076853 := by
  apply lucas_primality 441884076853 (2:ZMod 441884076853)
  · exact eq_one [false,false,true,false,true,true,false,false,true,true,false,true,false,true,true,true,true,true,true,false,true,false,true,false,false,true,false,false,false,true,true,true,false,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 441884076853)^((441884076853-1)/2)≠1:=
    ne_one [false,true,false,true,true,false,false,true,true,false,true,false,true,true,true,true,true,true,false,true,false,true,false,false,true,false,false,false,true,true,true,false,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(2:ZMod 441884076853)^((441884076853-1)/3)≠1:=
    ne_one [false,false,true,true,true,true,false,true,true,true,false,false,false,true,false,true,false,true,false,false,true,true,true,false,true,true,false,true,false,false,true,false,false,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w131:(2:ZMod 441884076853)^((441884076853-1)/131)≠1:=
    ne_one [false,false,true,true,true,true,false,true,true,false,false,true,true,false,true,false,false,true,true,true,false,false,false,false,true,false,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w281096741:(2:ZMod 441884076853)^((441884076853-1)/281096741)≠1:=
    ne_one [false,false,true,false,false,true,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (441884076853-1)=2*(2*(3*(131*(281096741)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=131:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w131
  have eqn:q=281096741:=(Nat.prime_dvd_prime_iff_eq hp prime281096741).mp hd; rw [eqn]; exact w281096741
theorem prime1074509 : Nat.Prime 1074509 := by
  apply lucas_primality 1074509 (2:ZMod 1074509)
  · exact eq_one [false,false,true,true,false,false,true,false,true,false,true,false,false,true,true,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 1074509)^((1074509-1)/2)≠1:=
    ne_one [false,true,true,false,false,true,false,true,false,true,false,false,true,true,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w29:(2:ZMod 1074509)^((1074509-1)/29)≠1:=
    ne_one [false,false,true,true,true,true,false,true,false,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w59:(2:ZMod 1074509)^((1074509-1)/59)≠1:=
    ne_one [false,false,true,false,false,true,false,false,true,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w157:(2:ZMod 1074509)^((1074509-1)/157)≠1:=
    ne_one [false,false,true,true,true,true,false,true,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (1074509-1)=2*(2*(29*(59*(157)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=29:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w29
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=59:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w59
  have eqn:q=157:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w157
theorem prime1141128559 : Nat.Prime 1141128559 := by
  apply lucas_primality 1141128559 (3:ZMod 1141128559)
  · exact eq_one [false,true,true,true,false,true,true,false,true,false,true,true,true,true,false,false,false,false,true,false,false,false,false,false,false,false,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 1141128559)^((1141128559-1)/2)≠1:=
    ne_one [true,true,true,false,true,true,false,true,false,true,true,true,true,false,false,false,false,true,false,false,false,false,false,false,false,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 1141128559)^((1141128559-1)/3)≠1:=
    ne_one [false,true,false,true,true,true,true,false,false,false,true,false,true,false,false,false,false,false,true,true,false,true,false,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w59:(3:ZMod 1141128559)^((1141128559-1)/59)≠1:=
    ne_one [false,true,false,true,false,true,true,false,true,true,true,true,true,false,false,false,true,true,true,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w1074509:(3:ZMod 1141128559)^((1141128559-1)/1074509)≠1:=
    ne_one [false,true,true,false,false,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (1141128559-1)=2*(3*(3*(59*(1074509)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=59:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w59
  have eqn:q=1074509:=(Nat.prime_dvd_prime_iff_eq hp prime1074509).mp hd; rw [eqn]; exact w1074509
theorem prime370866781675001 : Nat.Prime 370866781675001 := by
  apply lucas_primality 370866781675001 (3:ZMod 370866781675001)
  · exact eq_one [false,false,false,true,true,true,true,true,true,false,true,true,true,false,true,true,true,true,true,false,false,false,true,true,false,true,true,false,false,true,false,false,true,false,true,true,false,false,true,false,true,false,false,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 370866781675001)^((370866781675001-1)/2)≠1:=
    ne_one [false,false,true,true,true,true,true,true,false,true,true,true,false,true,true,true,true,true,false,false,false,true,true,false,true,true,false,false,true,false,false,true,false,true,true,false,false,true,false,true,false,false,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(3:ZMod 370866781675001)^((370866781675001-1)/5)≠1:=
    ne_one [false,false,false,true,true,false,false,true,true,true,true,true,true,false,true,false,false,true,true,true,false,false,false,true,false,false,true,false,true,false,true,true,true,false,true,false,true,true,true,false,true,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w13:(3:ZMod 370866781675001)^((370866781675001-1)/13)≠1:=
    ne_one [false,false,false,true,true,false,true,true,true,true,true,true,true,false,true,false,true,true,true,true,false,false,false,false,false,true,true,true,true,true,false,false,false,true,false,false,true,true,true,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w1141128559:(3:ZMod 370866781675001)^((370866781675001-1)/1141128559)≠1:=
    ne_one [false,false,false,true,false,false,false,true,true,false,true,false,true,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (370866781675001-1)=2*(2*(2*(5*(5*(5*(5*(5*(13*(1141128559))))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=13:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w13
  have eqn:q=1141128559:=(Nat.prime_dvd_prime_iff_eq hp prime1141128559).mp hd; rw [eqn]; exact w1141128559
theorem prime1754821172656266926966923716442469 : Nat.Prime 1754821172656266926966923716442469 := by
  apply lucas_primality 1754821172656266926966923716442469 (2:ZMod 1754821172656266926966923716442469)
  · exact eq_one [false,false,true,false,false,true,true,false,true,false,false,true,true,true,false,true,true,true,true,true,false,false,false,true,false,true,false,true,true,false,false,true,false,true,true,true,false,true,false,false,true,true,false,true,false,true,true,false,true,true,false,true,false,true,true,true,false,false,false,false,false,false,true,false,false,true,false,false,true,false,true,true,false,false,true,false,false,false,false,true,false,false,true,false,false,false,false,false,true,false,true,false,true,true,true,true,false,false,true,false,false,false,false,true,false,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 1754821172656266926966923716442469)^((1754821172656266926966923716442469-1)/2)≠1:=
    ne_one [false,true,false,false,true,true,false,true,false,false,true,true,true,false,true,true,true,true,true,false,false,false,true,false,true,false,true,true,false,false,true,false,true,true,true,false,true,false,false,true,true,false,true,false,true,true,false,true,true,false,true,false,true,true,true,false,false,false,false,false,false,true,false,false,true,false,false,true,false,true,true,false,false,true,false,false,false,false,true,false,false,true,false,false,false,false,false,true,false,true,false,true,true,true,true,false,false,true,false,false,false,false,true,false,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w7:(2:ZMod 1754821172656266926966923716442469)^((1754821172656266926966923716442469-1)/7)≠1:=
    ne_one [false,false,true,true,true,true,true,false,false,true,false,true,true,false,false,false,true,false,false,true,true,true,false,false,true,true,true,true,true,false,true,false,false,false,true,false,true,true,true,false,false,false,false,true,true,false,true,false,true,true,true,true,false,false,false,true,true,true,false,true,true,false,false,true,false,true,false,false,false,false,true,false,true,false,true,false,false,true,false,true,false,false,false,false,false,false,false,false,true,true,false,false,false,true,false,false,false,false,true,true,true,false,true,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w382427:(2:ZMod 1754821172656266926966923716442469)^((1754821172656266926966923716442469-1)/382427)≠1:=
    ne_one [false,false,true,true,false,true,true,false,true,true,false,false,true,false,true,true,false,true,false,false,false,true,true,false,true,false,false,false,true,true,false,false,true,false,true,true,false,true,false,true,false,true,false,false,true,true,false,false,false,false,true,true,true,false,true,true,true,true,false,false,false,false,true,false,true,true,true,true,false,false,false,false,true,true,false,false,false,true,false,true,true,true,false,false,true,false,true,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w441884076853:(2:ZMod 1754821172656266926966923716442469)^((1754821172656266926966923716442469-1)/441884076853)≠1:=
    ne_one [false,false,true,false,true,false,true,false,false,false,true,true,true,false,true,true,true,false,false,false,false,true,true,true,false,true,true,false,true,false,false,true,false,true,false,true,false,false,true,true,false,false,true,false,false,false,false,false,false,true,false,false,true,false,true,true,true,true,true,false,false,false,true,false,true,true,true,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w370866781675001:(2:ZMod 1754821172656266926966923716442469)^((1754821172656266926966923716442469-1)/370866781675001)≠1:=
    ne_one [false,false,true,false,false,false,false,true,true,false,true,true,false,true,false,true,false,false,false,false,false,false,false,true,false,true,true,true,true,true,true,false,false,true,false,false,true,false,false,true,true,false,false,true,false,false,true,false,false,true,false,true,false,true,false,true,true,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (1754821172656266926966923716442469-1)=2*(2*(7*(382427*(441884076853*(370866781675001))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=382427:=(Nat.prime_dvd_prime_iff_eq hp prime382427).mp leaf; rw [eqn]; exact w382427
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=441884076853:=(Nat.prime_dvd_prime_iff_eq hp prime441884076853).mp leaf; rw [eqn]; exact w441884076853
  have eqn:q=370866781675001:=(Nat.prime_dvd_prime_iff_eq hp prime370866781675001).mp hd; rw [eqn]; exact w370866781675001
theorem prime2011 : Nat.Prime 2011 := by
  apply lucas_primality 2011 (3:ZMod 2011)
  · exact eq_one [false,true,false,true,true,false,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 2011)^((2011-1)/2)≠1:=
    ne_one [true,false,true,true,false,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 2011)^((2011-1)/3)≠1:=
    ne_one [false,true,true,true,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(3:ZMod 2011)^((2011-1)/5)≠1:=
    ne_one [false,true,false,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w67:(3:ZMod 2011)^((2011-1)/67)≠1:=
    ne_one [false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (2011-1)=2*(3*(5*(67))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  have eqn:q=67:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w67
theorem prime152837 : Nat.Prime 152837 := by
  apply lucas_primality 152837 (2:ZMod 152837)
  · exact eq_one [false,false,true,false,false,false,false,false,true,false,true,false,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 152837)^((152837-1)/2)≠1:=
    ne_one [false,true,false,false,false,false,false,true,false,true,false,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w19:(2:ZMod 152837)^((152837-1)/19)≠1:=
    ne_one [false,false,true,true,false,true,true,false,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w2011:(2:ZMod 152837)^((152837-1)/2011)≠1:=
    ne_one [false,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (152837-1)=2*(2*(19*(2011))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=19:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w19
  have eqn:q=2011:=(Nat.prime_dvd_prime_iff_eq hp prime2011).mp hd; rw [eqn]; exact w2011
theorem prime8093 : Nat.Prime 8093 := by
  apply lucas_primality 8093 (2:ZMod 8093)
  · exact eq_one [false,false,true,true,true,false,false,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 8093)^((8093-1)/2)≠1:=
    ne_one [false,true,true,true,false,false,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w7:(2:ZMod 8093)^((8093-1)/7)≠1:=
    ne_one [false,false,true,false,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w17:(2:ZMod 8093)^((8093-1)/17)≠1:=
    ne_one [false,false,true,true,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (8093-1)=2*(2*(7*(17*(17)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=17:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w17
  have eqn:q=17:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w17
theorem prime16187 : Nat.Prime 16187 := by
  apply lucas_primality 16187 (2:ZMod 16187)
  · exact eq_one [false,true,false,true,true,true,false,false,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 16187)^((16187-1)/2)≠1:=
    ne_one [true,false,true,true,true,false,false,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w8093:(2:ZMod 16187)^((16187-1)/8093)≠1:=
    ne_one [false,true] (by decide +kernel) (by decide +kernel)
  rw [show (16187-1)=2*(8093) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  have eqn:q=8093:=(Nat.prime_dvd_prime_iff_eq hp prime8093).mp hd; rw [eqn]; exact w8093
theorem prime11453153 : Nat.Prime 11453153 := by
  apply lucas_primality 11453153 (3:ZMod 11453153)
  · exact eq_one [false,false,false,false,false,true,true,true,false,true,false,false,false,false,true,true,false,true,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 11453153)^((11453153-1)/2)≠1:=
    ne_one [false,false,false,false,true,true,true,false,true,false,false,false,false,true,true,false,true,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w71:(3:ZMod 11453153)^((11453153-1)/71)≠1:=
    ne_one [false,false,false,false,false,true,false,false,false,true,true,false,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (11453153-1)=2*(2*(2*(2*(2*(71*(71*(71))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=71:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w71
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=71:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w71
  have eqn:q=71:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w71
theorem prime22247062513321 : Nat.Prime 22247062513321 := by
  apply lucas_primality 22247062513321 (17:ZMod 22247062513321)
  · exact eq_one [false,false,false,true,false,true,false,true,false,true,true,false,false,true,false,false,false,true,false,false,false,false,true,false,false,false,true,true,false,false,true,true,true,true,false,true,true,true,false,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(17:ZMod 22247062513321)^((22247062513321-1)/2)≠1:=
    ne_one [false,false,true,false,true,false,true,false,true,true,false,false,true,false,false,false,true,false,false,false,false,true,false,false,false,true,true,false,false,true,true,true,true,false,true,true,true,false,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(17:ZMod 22247062513321)^((22247062513321-1)/3)≠1:=
    ne_one [false,false,false,true,true,true,false,false,false,true,false,false,false,true,true,false,true,true,false,true,false,true,true,false,true,false,false,true,true,false,false,true,false,true,true,true,true,true,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w5:(17:ZMod 22247062513321)^((22247062513321-1)/5)≠1:=
    ne_one [false,false,false,true,false,false,false,true,false,false,true,false,true,false,true,true,false,true,true,false,false,true,false,true,true,false,true,false,true,true,true,true,true,true,false,true,false,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w16187:(17:ZMod 22247062513321)^((22247062513321-1)/16187)≠1:=
    ne_one [false,false,false,true,true,true,true,false,true,false,false,true,true,false,true,false,true,true,false,true,false,true,true,true,true,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w11453153:(17:ZMod 22247062513321)^((22247062513321-1)/11453153)≠1:=
    ne_one [false,false,false,true,false,true,false,true,true,true,false,false,false,true,false,true,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (22247062513321-1)=2*(2*(2*(3*(5*(16187*(11453153)))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=16187:=(Nat.prime_dvd_prime_iff_eq hp prime16187).mp leaf; rw [eqn]; exact w16187
  have eqn:q=11453153:=(Nat.prime_dvd_prime_iff_eq hp prime11453153).mp hd; rw [eqn]; exact w11453153
theorem prime3191 : Nat.Prime 3191 := by
  apply lucas_primality 3191 (11:ZMod 3191)
  · exact eq_one [false,true,true,false,true,true,true,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(11:ZMod 3191)^((3191-1)/2)≠1:=
    ne_one [true,true,false,true,true,true,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w5:(11:ZMod 3191)^((3191-1)/5)≠1:=
    ne_one [false,true,true,true,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w11:(11:ZMod 3191)^((3191-1)/11)≠1:=
    ne_one [false,true,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w29:(11:ZMod 3191)^((3191-1)/29)≠1:=
    ne_one [false,true,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (3191-1)=2*(5*(11*(29))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w11
  have eqn:q=29:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w29
theorem prime2957 : Nat.Prime 2957 := by
  apply lucas_primality 2957 (2:ZMod 2957)
  · exact eq_one [false,false,true,true,false,false,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 2957)^((2957-1)/2)≠1:=
    ne_one [false,true,true,false,false,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w739:(2:ZMod 2957)^((2957-1)/739)≠1:=
    ne_one [false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (2957-1)=2*(2*(739)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  have eqn:q=739:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w739
theorem prime41399 : Nat.Prime 41399 := by
  apply lucas_primality 41399 (7:ZMod 41399)
  · exact eq_one [false,true,true,false,true,true,false,true,true,false,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(7:ZMod 41399)^((41399-1)/2)≠1:=
    ne_one [true,true,false,true,true,false,true,true,false,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w7:(7:ZMod 41399)^((41399-1)/7)≠1:=
    ne_one [false,true,false,true,true,false,false,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w2957:(7:ZMod 41399)^((41399-1)/2957)≠1:=
    ne_one [false,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (41399-1)=2*(7*(2957)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  have eqn:q=2957:=(Nat.prime_dvd_prime_iff_eq hp prime2957).mp hd; rw [eqn]; exact w2957
theorem prime496789 : Nat.Prime 496789 := by
  apply lucas_primality 496789 (2:ZMod 496789)
  · exact eq_one [false,false,true,false,true,false,false,true,false,false,true,false,true,false,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 496789)^((496789-1)/2)≠1:=
    ne_one [false,true,false,true,false,false,true,false,false,true,false,true,false,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(2:ZMod 496789)^((496789-1)/3)≠1:=
    ne_one [false,false,true,true,true,false,true,true,false,true,true,false,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w41399:(2:ZMod 496789)^((496789-1)/41399)≠1:=
    ne_one [false,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (496789-1)=2*(2*(3*(41399))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=41399:=(Nat.prime_dvd_prime_iff_eq hp prime41399).mp hd; rw [eqn]; exact w41399
theorem prime1987157 : Nat.Prime 1987157 := by
  apply lucas_primality 1987157 (2:ZMod 1987157)
  · exact eq_one [false,false,true,false,true,false,true,false,false,true,false,false,true,false,true,false,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 1987157)^((1987157-1)/2)≠1:=
    ne_one [false,true,false,true,false,true,false,false,true,false,false,true,false,true,false,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w496789:(2:ZMod 1987157)^((1987157-1)/496789)≠1:=
    ne_one [false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (1987157-1)=2*(2*(496789)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  have eqn:q=496789:=(Nat.prime_dvd_prime_iff_eq hp prime496789).mp hd; rw [eqn]; exact w496789
theorem prime119229421 : Nat.Prime 119229421 := by
  apply lucas_primality 119229421 (6:ZMod 119229421)
  · exact eq_one [false,false,true,true,false,true,true,true,true,true,false,true,false,false,true,false,true,true,false,true,true,false,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(6:ZMod 119229421)^((119229421-1)/2)≠1:=
    ne_one [false,true,true,false,true,true,true,true,true,false,true,false,false,true,false,true,true,false,true,true,false,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(6:ZMod 119229421)^((119229421-1)/3)≠1:=
    ne_one [false,false,true,false,false,true,false,true,false,true,true,true,false,true,true,false,false,true,true,true,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(6:ZMod 119229421)^((119229421-1)/5)≠1:=
    ne_one [false,false,true,true,true,true,true,true,true,true,false,true,true,false,true,true,true,true,false,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w1987157:(6:ZMod 119229421)^((119229421-1)/1987157)≠1:=
    ne_one [false,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (119229421-1)=2*(2*(3*(5*(1987157)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  have eqn:q=1987157:=(Nat.prime_dvd_prime_iff_eq hp prime1987157).mp hd; rw [eqn]; exact w1987157
theorem prime7609221648221 : Nat.Prime 7609221648221 := by
  apply lucas_primality 7609221648221 (2:ZMod 7609221648221)
  · exact eq_one [false,false,true,true,true,false,true,false,true,true,true,true,false,false,false,false,false,false,true,false,true,true,true,true,false,false,false,true,false,true,false,true,true,true,false,true,false,true,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 7609221648221)^((7609221648221-1)/2)≠1:=
    ne_one [false,true,true,true,false,true,false,true,true,true,true,false,false,false,false,false,false,true,false,true,true,true,true,false,false,false,true,false,true,false,true,true,true,false,true,false,true,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w5:(2:ZMod 7609221648221)^((7609221648221-1)/5)≠1:=
    ne_one [false,false,true,true,false,true,false,true,false,false,true,true,true,false,false,true,true,false,true,true,true,true,true,true,false,false,true,false,true,false,true,false,false,true,false,false,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3191:(2:ZMod 7609221648221)^((7609221648221-1)/3191)≠1:=
    ne_one [false,false,true,false,false,false,false,true,false,true,true,true,false,true,true,true,true,false,false,false,false,true,false,false,false,true,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w119229421:(2:ZMod 7609221648221)^((7609221648221-1)/119229421)≠1:=
    ne_one [false,false,true,true,false,false,true,false,true,false,false,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (7609221648221-1)=2*(2*(5*(3191*(119229421)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3191:=(Nat.prime_dvd_prime_iff_eq hp prime3191).mp leaf; rw [eqn]; exact w3191
  have eqn:q=119229421:=(Nat.prime_dvd_prime_iff_eq hp prime119229421).mp hd; rw [eqn]; exact w119229421
theorem prime593519288561239 : Nat.Prime 593519288561239 := by
  apply lucas_primality 593519288561239 (3:ZMod 593519288561239)
  · exact eq_one [false,true,true,false,true,false,true,false,false,true,true,true,false,true,false,true,false,false,true,true,true,false,true,false,false,true,false,true,true,true,true,false,true,false,true,true,false,false,true,true,true,true,false,true,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 593519288561239)^((593519288561239-1)/2)≠1:=
    ne_one [true,true,false,true,false,true,false,false,true,true,true,false,true,false,true,false,false,true,true,true,false,true,false,false,true,false,true,true,true,true,false,true,false,true,true,false,false,true,true,true,true,false,true,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 593519288561239)^((593519288561239-1)/3)≠1:=
    ne_one [false,true,false,false,true,true,true,false,true,true,true,true,false,false,false,true,true,false,false,true,false,false,true,true,false,false,false,true,false,true,false,false,true,true,true,true,false,true,true,true,true,true,false,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w13:(3:ZMod 593519288561239)^((593519288561239-1)/13)≠1:=
    ne_one [false,true,true,true,false,true,false,false,false,false,true,true,true,false,true,false,false,false,false,true,true,true,false,true,true,false,true,false,true,true,true,true,true,false,true,false,false,false,false,true,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w7609221648221:(3:ZMod 593519288561239)^((593519288561239-1)/7609221648221)≠1:=
    ne_one [false,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (593519288561239-1)=2*(3*(13*(7609221648221))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=13:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w13
  have eqn:q=7609221648221:=(Nat.prime_dvd_prime_iff_eq hp prime7609221648221).mp hd; rw [eqn]; exact w7609221648221
theorem prime4036138055144761320534304068715607 : Nat.Prime 4036138055144761320534304068715607 := by
  apply lucas_primality 4036138055144761320534304068715607 (5:ZMod 4036138055144761320534304068715607)
  · exact eq_one [false,true,true,false,true,false,true,false,false,false,true,false,false,false,true,true,true,true,false,true,true,false,false,true,true,false,true,true,false,false,true,true,true,false,true,false,true,false,false,true,false,false,false,true,false,true,false,true,true,false,true,true,false,true,false,false,false,true,false,false,true,true,true,false,false,false,false,false,false,true,false,true,true,false,true,true,false,false,true,true,false,false,true,true,false,true,true,false,true,false,false,true,true,true,false,false,true,true,true,true,true,true,true,true,false,true,true,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 4036138055144761320534304068715607)^((4036138055144761320534304068715607-1)/2)≠1:=
    ne_one [true,true,false,true,false,true,false,false,false,true,false,false,false,true,true,true,true,false,true,true,false,false,true,true,false,true,true,false,false,true,true,true,false,true,false,true,false,false,true,false,false,false,true,false,true,false,true,true,false,true,true,false,true,false,false,false,true,false,false,true,true,true,false,false,false,false,false,false,true,false,true,true,false,true,true,false,false,true,true,false,false,true,true,false,true,true,false,true,false,false,true,true,true,false,false,true,true,true,true,true,true,true,true,false,true,true,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w152837:(5:ZMod 4036138055144761320534304068715607)^((4036138055144761320534304068715607-1)/152837)≠1:=
    ne_one [false,true,true,true,true,false,true,true,false,true,false,false,false,false,false,false,false,false,true,true,true,true,true,true,false,true,true,true,true,false,false,true,true,false,true,true,true,false,true,false,true,true,true,false,true,true,true,false,false,true,true,false,true,true,true,true,true,false,true,false,true,false,true,false,true,true,false,true,true,true,false,false,true,false,false,true,false,false,true,false,false,false,true,false,true,false,true,false,true,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w22247062513321:(5:ZMod 4036138055144761320534304068715607)^((4036138055144761320534304068715607-1)/22247062513321)≠1:=
    ne_one [false,true,true,false,false,true,true,false,true,false,true,false,true,false,false,true,false,false,false,false,false,false,true,true,false,false,true,true,false,false,false,false,true,true,false,true,true,true,false,true,false,true,false,false,true,true,true,false,true,false,false,false,false,false,true,true,true,false,true,false,true,false,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w593519288561239:(5:ZMod 4036138055144761320534304068715607)^((4036138055144761320534304068715607-1)/593519288561239)≠1:=
    ne_one [false,true,false,true,true,false,false,true,false,false,true,true,true,true,false,true,true,false,true,false,false,true,true,true,false,true,false,false,false,false,false,true,false,true,false,false,false,false,false,false,true,false,false,false,true,true,false,true,true,true,true,true,true,false,true,false,false,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (4036138055144761320534304068715607-1)=2*(152837*(22247062513321*(593519288561239))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=152837:=(Nat.prime_dvd_prime_iff_eq hp prime152837).mp leaf; rw [eqn]; exact w152837
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=22247062513321:=(Nat.prime_dvd_prime_iff_eq hp prime22247062513321).mp leaf; rw [eqn]; exact w22247062513321
  have eqn:q=593519288561239:=(Nat.prime_dvd_prime_iff_eq hp prime593519288561239).mp hd; rw [eqn]; exact w593519288561239
theorem prime60373 : Nat.Prime 60373 := by
  apply lucas_primality 60373 (2:ZMod 60373)
  · exact eq_one [false,false,true,false,true,false,true,true,true,true,false,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 60373)^((60373-1)/2)≠1:=
    ne_one [false,true,false,true,false,true,true,true,true,false,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(2:ZMod 60373)^((60373-1)/3)≠1:=
    ne_one [false,false,true,true,true,false,false,true,false,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w13:(2:ZMod 60373)^((60373-1)/13)≠1:=
    ne_one [false,false,true,false,false,true,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w43:(2:ZMod 60373)^((60373-1)/43)≠1:=
    ne_one [false,false,true,true,true,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (60373-1)=2*(2*(3*(3*(3*(13*(43)))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=13:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w13
  have eqn:q=43:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w43
theorem prime8623 : Nat.Prime 8623 := by
  apply lucas_primality 8623 (3:ZMod 8623)
  · exact eq_one [false,true,true,true,false,true,false,true,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 8623)^((8623-1)/2)≠1:=
    ne_one [true,true,true,false,true,false,true,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 8623)^((8623-1)/3)≠1:=
    ne_one [false,true,false,true,true,true,false,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w479:(3:ZMod 8623)^((8623-1)/479)≠1:=
    ne_one [false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (8623-1)=2*(3*(3*(479))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=479:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w479
theorem prime19332767 : Nat.Prime 19332767 := by
  apply lucas_primality 19332767 (5:ZMod 19332767)
  · exact eq_one [false,true,true,true,true,false,false,true,false,true,true,true,true,true,true,true,false,true,true,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 19332767)^((19332767-1)/2)≠1:=
    ne_one [true,true,true,true,false,false,true,false,true,true,true,true,true,true,true,false,true,true,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w19:(5:ZMod 19332767)^((19332767-1)/19)≠1:=
    ne_one [false,true,false,true,false,true,false,true,false,true,true,false,false,false,false,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w59:(5:ZMod 19332767)^((19332767-1)/59)≠1:=
    ne_one [false,true,false,true,true,true,true,true,true,true,true,true,true,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w8623:(5:ZMod 19332767)^((19332767-1)/8623)≠1:=
    ne_one [false,true,false,false,false,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (19332767-1)=2*(19*(59*(8623))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=19:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w19
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=59:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w59
  have eqn:q=8623:=(Nat.prime_dvd_prime_iff_eq hp prime8623).mp hd; rw [eqn]; exact w8623
theorem prime2729 : Nat.Prime 2729 := by
  apply lucas_primality 2729 (3:ZMod 2729)
  · exact eq_one [false,false,false,true,false,true,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 2729)^((2729-1)/2)≠1:=
    ne_one [false,false,true,false,true,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w11:(3:ZMod 2729)^((2729-1)/11)≠1:=
    ne_one [false,false,false,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w31:(3:ZMod 2729)^((2729-1)/31)≠1:=
    ne_one [false,false,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (2729-1)=2*(2*(2*(11*(31)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w11
  have eqn:q=31:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w31
theorem prime158749939 : Nat.Prime 158749939 := by
  apply lucas_primality 158749939 (2:ZMod 158749939)
  · exact eq_one [false,true,false,false,true,true,true,true,false,false,true,false,true,false,true,false,false,true,true,false,true,true,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 158749939)^((158749939-1)/2)≠1:=
    ne_one [true,false,false,true,true,true,true,false,false,true,false,true,false,true,false,false,true,true,false,true,true,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(2:ZMod 158749939)^((158749939-1)/3)≠1:=
    ne_one [false,true,true,false,false,true,false,true,true,false,false,false,true,true,true,false,true,true,true,false,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w61:(2:ZMod 158749939)^((158749939-1)/61)≠1:=
    ne_one [false,true,false,true,true,false,true,true,true,false,true,false,true,true,false,true,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w163:(2:ZMod 158749939)^((158749939-1)/163)≠1:=
    ne_one [false,true,true,false,false,true,true,false,false,false,true,true,true,false,true,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w887:(2:ZMod 158749939)^((158749939-1)/887)≠1:=
    ne_one [false,true,true,true,true,false,false,false,true,true,false,true,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (158749939-1)=2*(3*(3*(61*(163*(887))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=61:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w61
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=163:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w163
  have eqn:q=887:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w887
theorem prime13863314672993 : Nat.Prime 13863314672993 := by
  apply lucas_primality 13863314672993 (3:ZMod 13863314672993)
  · exact eq_one [false,false,false,false,false,true,true,false,true,false,true,true,false,false,true,false,false,true,false,false,true,true,true,true,true,false,true,true,false,false,true,true,true,true,false,true,true,false,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 13863314672993)^((13863314672993-1)/2)≠1:=
    ne_one [false,false,false,false,true,true,false,true,false,true,true,false,false,true,false,false,true,false,false,true,true,true,true,true,false,true,true,false,false,true,true,true,true,false,true,true,false,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w2729:(3:ZMod 13863314672993)^((13863314672993-1)/2729)≠1:=
    ne_one [false,false,false,false,false,true,true,false,false,true,true,true,true,false,false,true,false,true,false,true,false,false,true,true,false,true,true,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w158749939:(3:ZMod 13863314672993)^((13863314672993-1)/158749939)≠1:=
    ne_one [false,false,false,false,false,true,false,false,true,false,true,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (13863314672993-1)=2*(2*(2*(2*(2*(2729*(158749939)))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2729:=(Nat.prime_dvd_prime_iff_eq hp prime2729).mp leaf; rw [eqn]; exact w2729
  have eqn:q=158749939:=(Nat.prime_dvd_prime_iff_eq hp prime158749939).mp hd; rw [eqn]; exact w158749939
theorem prime3883426559983727030699607121 : Nat.Prime 3883426559983727030699607121 := by
  apply lucas_primality 3883426559983727030699607121 (17:ZMod 3883426559983727030699607121)
  · exact eq_one [false,false,false,false,true,false,true,false,false,false,true,false,false,false,true,true,false,false,false,true,false,true,true,false,true,false,false,false,false,false,true,true,true,false,true,true,false,true,true,false,false,false,true,true,true,false,true,false,true,true,true,true,false,true,false,true,false,true,true,false,false,true,false,true,true,true,true,true,false,false,false,true,true,true,false,true,false,false,true,false,false,false,true,true,false,false,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(17:ZMod 3883426559983727030699607121)^((3883426559983727030699607121-1)/2)≠1:=
    ne_one [false,false,false,true,false,true,false,false,false,true,false,false,false,true,true,false,false,false,true,false,true,true,false,true,false,false,false,false,false,true,true,true,false,true,true,false,true,true,false,false,false,true,true,true,false,true,false,true,true,true,true,false,true,false,true,false,true,true,false,false,true,false,true,true,true,true,true,false,false,false,true,true,true,false,true,false,false,true,false,false,false,true,true,false,false,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(17:ZMod 3883426559983727030699607121)^((3883426559983727030699607121-1)/3)≠1:=
    ne_one [false,false,false,false,true,true,true,false,true,false,false,false,false,false,true,false,false,false,false,true,true,true,true,false,false,false,false,false,false,false,true,false,true,true,true,true,false,false,true,true,false,true,true,true,true,false,false,false,true,false,true,false,false,true,true,true,false,false,true,true,false,false,false,true,false,true,false,true,true,false,true,true,true,true,false,false,false,false,true,true,false,true,true,true,false,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(17:ZMod 3883426559983727030699607121)^((3883426559983727030699607121-1)/5)≠1:=
    ne_one [false,false,false,false,true,false,false,false,false,false,true,false,true,true,true,true,false,false,true,false,true,false,false,false,true,false,true,true,false,false,false,true,true,true,true,true,false,true,false,true,true,false,true,false,false,false,true,false,false,true,true,false,true,false,true,false,true,false,false,false,false,true,false,false,true,true,false,false,false,false,false,true,true,false,true,false,true,true,true,false,false,true,false,false,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w60373:(17:ZMod 3883426559983727030699607121)^((3883426559983727030699607121-1)/60373)≠1:=
    ne_one [false,false,false,false,true,false,false,false,true,true,false,true,false,true,true,false,false,false,false,true,false,true,false,true,true,true,true,true,false,true,false,true,false,false,true,true,false,true,false,false,false,true,false,true,false,true,true,false,false,false,false,false,false,true,true,false,true,false,false,false,false,false,false,false,true,true,true,true,true,false,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w19332767:(17:ZMod 3883426559983727030699607121)^((3883426559983727030699607121-1)/19332767)≠1:=
    ne_one [false,false,false,false,true,true,false,true,true,false,false,true,false,true,true,true,true,false,true,false,false,false,true,false,false,false,false,true,false,true,false,false,true,true,false,true,false,false,true,true,false,false,true,false,true,true,true,false,true,true,false,true,false,true,false,true,true,true,false,false,false,true,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w13863314672993:(17:ZMod 3883426559983727030699607121)^((3883426559983727030699607121-1)/13863314672993)≠1:=
    ne_one [false,false,false,false,true,false,true,false,false,true,true,false,true,false,true,false,false,true,false,false,true,true,true,true,false,true,false,true,true,false,false,false,true,false,true,false,false,false,true,true,false,true,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (3883426559983727030699607121-1)=2*(2*(2*(2*(3*(5*(60373*(19332767*(13863314672993)))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=60373:=(Nat.prime_dvd_prime_iff_eq hp prime60373).mp leaf; rw [eqn]; exact w60373
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=19332767:=(Nat.prime_dvd_prime_iff_eq hp prime19332767).mp leaf; rw [eqn]; exact w19332767
  have eqn:q=13863314672993:=(Nat.prime_dvd_prime_iff_eq hp prime13863314672993).mp hd; rw [eqn]; exact w13863314672993
theorem prime6996505560116602097773394576621473 : Nat.Prime 6996505560116602097773394576621473 := by
  apply lucas_primality 6996505560116602097773394576621473 (11:ZMod 6996505560116602097773394576621473)
  · exact eq_one [false,false,false,false,false,true,false,true,true,true,true,true,true,true,false,false,true,false,false,false,false,true,true,true,true,false,true,true,true,true,false,true,true,false,true,false,true,false,false,false,false,true,false,false,false,false,true,true,false,true,true,true,false,false,true,false,true,false,true,true,false,false,false,true,false,true,false,true,false,true,false,true,false,true,false,false,true,true,true,true,false,true,false,true,true,true,false,true,false,false,false,false,true,false,true,false,false,false,true,false,true,true,true,true,false,false,false,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(11:ZMod 6996505560116602097773394576621473)^((6996505560116602097773394576621473-1)/2)≠1:=
    ne_one [false,false,false,false,true,false,true,true,true,true,true,true,true,false,false,true,false,false,false,false,true,true,true,true,false,true,true,true,true,false,true,true,false,true,false,true,false,false,false,false,true,false,false,false,false,true,true,false,true,true,true,false,false,true,false,true,false,true,true,false,false,false,true,false,true,false,true,false,true,false,true,false,true,false,false,true,true,true,true,false,true,false,true,true,true,false,true,false,false,false,false,true,false,true,false,false,false,true,false,true,true,true,true,false,false,false,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(11:ZMod 6996505560116602097773394576621473)^((6996505560116602097773394576621473-1)/3)≠1:=
    ne_one [false,false,false,false,false,true,true,true,true,true,true,true,true,true,false,true,true,false,true,false,true,true,true,true,true,false,false,true,false,true,true,true,true,false,false,false,true,true,false,true,false,false,false,false,false,false,true,false,false,true,false,true,true,false,false,false,true,true,true,true,false,true,false,false,false,true,true,true,false,false,false,true,true,true,false,true,true,true,true,true,false,false,false,true,false,true,true,true,false,true,false,true,true,false,false,false,false,false,true,true,true,true,true,true,false,true,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w7:(11:ZMod 6996505560116602097773394576621473)^((6996505560116602097773394576621473-1)/7)≠1:=
    ne_one [false,false,false,false,false,true,true,false,true,true,false,true,true,false,false,true,true,true,false,true,true,true,true,true,true,false,false,false,true,false,true,true,false,false,false,false,true,true,true,false,true,false,false,true,false,false,false,true,true,false,true,true,true,false,false,true,true,true,true,true,false,true,true,true,false,false,true,true,true,true,false,false,true,true,true,false,false,false,true,false,true,true,true,true,true,true,false,false,true,false,false,true,true,true,true,false,true,true,true,false,false,false,true,false,true,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w383:(11:ZMod 6996505560116602097773394576621473)^((6996505560116602097773394576621473-1)/383)≠1:=
    ne_one [false,false,false,false,false,true,true,false,false,false,false,false,true,false,true,false,true,true,true,false,true,false,false,false,true,false,true,false,false,true,true,true,true,false,false,false,false,false,true,true,false,false,false,false,false,true,true,false,false,true,false,false,false,false,true,false,false,true,true,false,true,false,true,true,false,true,true,false,true,false,false,true,true,true,true,true,false,true,true,false,false,false,true,true,false,true,true,true,true,false,false,false,true,false,false,true,false,true,true,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w3883426559983727030699607121:(11:ZMod 6996505560116602097773394576621473)^((6996505560116602097773394576621473-1)/3883426559983727030699607121)≠1:=
    ne_one [false,false,false,false,false,true,false,true,true,false,true,true,true,true,true,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (6996505560116602097773394576621473-1)=2*(2*(2*(2*(2*(3*(7*(7*(383*(3883426559983727030699607121))))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=383:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w383
  have eqn:q=3883426559983727030699607121:=(Nat.prime_dvd_prime_iff_eq hp prime3883426559983727030699607121).mp hd; rw [eqn]; exact w3883426559983727030699607121
theorem prime14621 : Nat.Prime 14621 := by
  apply lucas_primality 14621 (2:ZMod 14621)
  · exact eq_one [false,false,true,true,true,false,false,false,true,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 14621)^((14621-1)/2)≠1:=
    ne_one [false,true,true,true,false,false,false,true,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w5:(2:ZMod 14621)^((14621-1)/5)≠1:=
    ne_one [false,false,true,true,false,true,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w17:(2:ZMod 14621)^((14621-1)/17)≠1:=
    ne_one [false,false,true,true,true,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w43:(2:ZMod 14621)^((14621-1)/43)≠1:=
    ne_one [false,false,true,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (14621-1)=2*(2*(5*(17*(43)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=17:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w17
  have eqn:q=43:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w43
theorem prime5077 : Nat.Prime 5077 := by
  apply lucas_primality 5077 (2:ZMod 5077)
  · exact eq_one [false,false,true,false,true,false,true,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 5077)^((5077-1)/2)≠1:=
    ne_one [false,true,false,true,false,true,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(2:ZMod 5077)^((5077-1)/3)≠1:=
    ne_one [false,false,true,true,true,false,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w47:(2:ZMod 5077)^((5077-1)/47)≠1:=
    ne_one [false,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (5077-1)=2*(2*(3*(3*(3*(47))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=47:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w47
theorem prime294467 : Nat.Prime 294467 := by
  apply lucas_primality 294467 (2:ZMod 294467)
  · exact eq_one [false,true,false,false,false,false,true,false,false,true,true,true,true,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 294467)^((294467-1)/2)≠1:=
    ne_one [true,false,false,false,false,true,false,false,true,true,true,true,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w29:(2:ZMod 294467)^((294467-1)/29)≠1:=
    ne_one [false,true,false,true,false,true,false,true,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w5077:(2:ZMod 294467)^((294467-1)/5077)≠1:=
    ne_one [false,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (294467-1)=2*(29*(5077)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=29:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w29
  have eqn:q=5077:=(Nat.prime_dvd_prime_iff_eq hp prime5077).mp hd; rw [eqn]; exact w5077
theorem prime1567 : Nat.Prime 1567 := by
  apply lucas_primality 1567 (3:ZMod 1567)
  · exact eq_one [false,true,true,true,true,false,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 1567)^((1567-1)/2)≠1:=
    ne_one [true,true,true,true,false,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 1567)^((1567-1)/3)≠1:=
    ne_one [false,true,false,true,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w29:(3:ZMod 1567)^((1567-1)/29)≠1:=
    ne_one [false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (1567-1)=2*(3*(3*(3*(29)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=29:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w29
theorem prime6269 : Nat.Prime 6269 := by
  apply lucas_primality 6269 (2:ZMod 6269)
  · exact eq_one [false,false,true,true,true,true,true,false,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 6269)^((6269-1)/2)≠1:=
    ne_one [false,true,true,true,true,true,false,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w1567:(2:ZMod 6269)^((6269-1)/1567)≠1:=
    ne_one [false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (6269-1)=2*(2*(1567)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  have eqn:q=1567:=(Nat.prime_dvd_prime_iff_eq hp prime1567).mp hd; rw [eqn]; exact w1567
theorem prime5905399 : Nat.Prime 5905399 := by
  apply lucas_primality 5905399 (3:ZMod 5905399)
  · exact eq_one [false,true,true,false,true,true,true,true,true,true,false,true,true,false,false,false,false,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 5905399)^((5905399-1)/2)≠1:=
    ne_one [true,true,false,true,true,true,true,true,true,false,true,true,false,false,false,false,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 5905399)^((5905399-1)/3)≠1:=
    ne_one [false,true,false,false,true,false,true,false,true,false,false,true,false,false,false,false,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w157:(3:ZMod 5905399)^((5905399-1)/157)≠1:=
    ne_one [false,true,true,true,false,true,true,true,false,true,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w6269:(3:ZMod 5905399)^((5905399-1)/6269)≠1:=
    ne_one [false,true,true,true,false,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (5905399-1)=2*(3*(157*(6269))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=157:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w157
  have eqn:q=6269:=(Nat.prime_dvd_prime_iff_eq hp prime6269).mp hd; rw [eqn]; exact w6269
theorem prime868755057689 : Nat.Prime 868755057689 := by
  apply lucas_primality 868755057689 (3:ZMod 868755057689)
  · exact eq_one [false,false,false,true,true,false,false,false,false,false,true,true,false,true,false,false,false,true,true,false,true,false,true,true,true,false,true,false,false,false,true,false,false,true,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 868755057689)^((868755057689-1)/2)≠1:=
    ne_one [false,false,true,true,false,false,false,false,false,true,true,false,true,false,false,false,true,true,false,true,false,true,true,true,false,true,false,false,false,true,false,false,true,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w7:(3:ZMod 868755057689)^((868755057689-1)/7)≠1:=
    ne_one [false,false,false,true,false,true,false,false,true,false,true,true,true,true,false,true,true,true,true,false,false,true,true,false,true,false,true,false,false,true,true,true,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w37:(3:ZMod 868755057689)^((868755057689-1)/37)≠1:=
    ne_one [false,false,false,true,true,true,false,false,false,false,true,false,true,false,true,false,false,true,false,false,false,false,false,true,true,true,true,false,true,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w71:(3:ZMod 868755057689)^((868755057689-1)/71)≠1:=
    ne_one [false,false,false,true,false,true,false,false,true,true,true,false,true,false,true,false,false,true,false,false,true,false,true,false,true,false,false,true,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w5905399:(3:ZMod 868755057689)^((868755057689-1)/5905399)≠1:=
    ne_one [false,false,false,true,false,true,false,true,false,true,true,true,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (868755057689-1)=2*(2*(2*(7*(37*(71*(5905399)))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=37:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w37
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=71:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w71
  have eqn:q=5905399:=(Nat.prime_dvd_prime_iff_eq hp prime5905399).mp hd; rw [eqn]; exact w5905399
theorem prime1737510115379 : Nat.Prime 1737510115379 := by
  apply lucas_primality 1737510115379 (2:ZMod 1737510115379)
  · exact eq_one [false,true,false,false,true,true,false,false,false,false,false,true,true,false,true,false,false,false,true,true,false,true,false,true,true,true,false,true,false,false,false,true,false,false,true,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 1737510115379)^((1737510115379-1)/2)≠1:=
    ne_one [true,false,false,true,true,false,false,false,false,false,true,true,false,true,false,false,false,true,true,false,true,false,true,true,true,false,true,false,false,false,true,false,false,true,false,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w868755057689:(2:ZMod 1737510115379)^((1737510115379-1)/868755057689)≠1:=
    ne_one [false,true] (by decide +kernel) (by decide +kernel)
  rw [show (1737510115379-1)=2*(868755057689) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  have eqn:q=868755057689:=(Nat.prime_dvd_prime_iff_eq hp prime868755057689).mp hd; rw [eqn]; exact w868755057689
theorem prime78535457215130801 : Nat.Prime 78535457215130801 := by
  apply lucas_primality 78535457215130801 (3:ZMod 78535457215130801)
  · exact eq_one [false,false,false,false,true,true,false,true,false,false,true,true,false,true,false,true,false,false,true,false,true,false,false,true,true,false,true,true,false,false,false,false,true,false,true,false,true,false,false,true,true,true,false,false,false,false,false,false,true,true,true,false,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 78535457215130801)^((78535457215130801-1)/2)≠1:=
    ne_one [false,false,false,true,true,false,true,false,false,true,true,false,true,false,true,false,false,true,false,true,false,false,true,true,false,true,true,false,false,false,false,true,false,true,false,true,false,false,true,true,true,false,false,false,false,false,false,true,true,true,false,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(3:ZMod 78535457215130801)^((78535457215130801-1)/5)≠1:=
    ne_one [false,false,false,false,true,true,true,true,false,false,false,true,false,false,false,true,false,true,false,true,false,true,true,true,true,false,true,false,true,true,false,false,false,false,true,false,false,false,false,true,true,false,true,true,false,false,true,true,true,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w113:(3:ZMod 78535457215130801)^((78535457215130801-1)/113)≠1:=
    ne_one [false,false,false,false,true,true,false,true,true,true,true,true,false,false,true,true,true,false,false,true,false,false,true,false,true,false,true,true,true,true,false,false,false,true,false,true,true,false,false,false,false,false,false,true,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w1737510115379:(3:ZMod 78535457215130801)^((78535457215130801-1)/1737510115379)≠1:=
    ne_one [false,false,false,false,true,false,false,true,false,false,false,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (78535457215130801-1)=2*(2*(2*(2*(5*(5*(113*(1737510115379))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=113:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w113
  have eqn:q=1737510115379:=(Nat.prime_dvd_prime_iff_eq hp prime1737510115379).mp hd; rw [eqn]; exact w1737510115379
theorem prime49259637758132062049629 : Nat.Prime 49259637758132062049629 := by
  apply lucas_primality 49259637758132062049629 (2:ZMod 49259637758132062049629)
  · exact eq_one [false,false,true,true,true,false,true,false,true,false,true,false,true,false,true,true,false,false,false,true,true,true,true,true,false,false,false,true,true,false,true,false,false,true,true,false,false,false,true,false,false,false,false,false,false,true,true,true,false,false,true,true,false,false,true,true,false,true,true,true,true,false,true,false,false,true,true,true,false,true,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 49259637758132062049629)^((49259637758132062049629-1)/2)≠1:=
    ne_one [false,true,true,true,false,true,false,true,false,true,false,true,false,true,true,false,false,false,true,true,true,true,true,false,false,false,true,true,false,true,false,false,true,true,false,false,false,true,false,false,false,false,false,false,true,true,true,false,false,true,true,false,false,true,true,false,true,true,true,true,false,true,false,false,true,true,true,false,true,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(2:ZMod 49259637758132062049629)^((49259637758132062049629-1)/3)≠1:=
    ne_one [false,false,true,false,true,true,true,false,false,false,true,true,true,false,false,true,true,false,true,true,true,true,true,true,false,true,false,false,true,true,true,false,true,true,true,false,true,false,false,false,false,false,false,false,false,true,false,true,true,false,false,true,true,false,false,true,true,true,true,true,true,false,false,false,false,true,false,true,true,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w7:(2:ZMod 49259637758132062049629)^((49259637758132062049629-1)/7)≠1:=
    ne_one [false,false,true,false,false,false,true,true,false,false,false,false,true,true,false,true,false,false,true,true,false,true,true,false,false,true,false,true,true,true,true,false,true,false,true,false,false,true,true,true,false,true,true,false,true,false,true,true,true,false,false,false,false,false,true,false,true,true,false,true,true,true,true,false,true,false,true,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w19:(2:ZMod 49259637758132062049629)^((49259637758132062049629-1)/19)≠1:=
    ne_one [false,false,true,false,true,true,false,true,false,false,false,true,true,false,false,false,true,false,true,true,false,false,false,false,false,false,false,true,false,false,true,false,true,true,false,true,true,false,true,true,false,false,false,false,true,true,true,true,true,false,false,true,true,true,false,true,true,true,false,true,false,false,false,true,false,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w131:(2:ZMod 49259637758132062049629)^((49259637758132062049629-1)/131)≠1:=
    ne_one [false,false,true,false,true,true,true,false,false,true,true,true,true,false,true,true,true,false,true,true,false,true,false,true,false,false,false,false,false,false,false,false,false,true,false,false,false,false,true,true,true,true,true,true,true,true,true,true,false,true,true,true,false,true,true,false,false,true,false,false,false,true,true,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w78535457215130801:(2:ZMod 49259637758132062049629)^((49259637758132062049629-1)/78535457215130801)≠1:=
    ne_one [false,false,true,true,true,false,false,false,false,true,false,false,true,false,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (49259637758132062049629-1)=2*(2*(3*(3*(7*(19*(131*(78535457215130801))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=19:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w19
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=131:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w131
  have eqn:q=78535457215130801:=(Nat.prime_dvd_prime_iff_eq hp prime78535457215130801).mp hd; rw [eqn]; exact w78535457215130801
theorem prime21612953250068572134196473087071 : Nat.Prime 21612953250068572134196473087071 := by
  apply lucas_primality 21612953250068572134196473087071 (11:ZMod 21612953250068572134196473087071)
  · exact eq_one [false,true,true,true,true,false,true,false,false,false,true,false,false,false,true,true,true,false,false,false,true,true,true,false,false,false,false,false,true,false,true,false,true,true,true,false,false,true,true,false,false,true,false,false,true,false,true,true,true,true,true,false,true,true,true,false,true,false,false,true,true,false,false,true,true,false,false,false,true,false,false,true,false,false,false,true,false,true,true,true,true,true,true,false,true,true,false,false,true,true,false,true,false,false,true,true,false,false,false,false,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(11:ZMod 21612953250068572134196473087071)^((21612953250068572134196473087071-1)/2)≠1:=
    ne_one [true,true,true,true,false,true,false,false,false,true,false,false,false,true,true,true,false,false,false,true,true,true,false,false,false,false,false,true,false,true,false,true,true,true,false,false,true,true,false,false,true,false,false,true,false,true,true,true,true,true,false,true,true,true,false,true,false,false,true,true,false,false,true,true,false,false,false,true,false,false,true,false,false,false,true,false,true,true,true,true,true,true,false,true,true,false,false,true,true,false,true,false,false,true,true,false,false,false,false,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(11:ZMod 21612953250068572134196473087071)^((21612953250068572134196473087071-1)/5)≠1:=
    ne_one [false,true,true,false,false,false,true,false,true,true,true,false,false,true,false,false,true,false,true,true,true,true,true,false,false,true,true,false,true,true,true,false,true,false,false,false,false,true,true,true,false,true,true,false,true,true,true,true,true,true,true,false,true,false,false,false,true,false,true,false,false,false,false,true,true,true,false,false,false,false,false,true,false,true,true,true,false,true,false,false,true,true,false,true,false,false,false,false,true,true,true,true,false,false,false,true,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w149:(11:ZMod 21612953250068572134196473087071)^((21612953250068572134196473087071-1)/149)≠1:=
    ne_one [false,true,true,false,false,true,true,false,true,false,true,false,false,true,false,false,false,false,true,true,false,true,true,true,true,true,false,true,false,true,true,true,false,true,true,false,false,true,true,true,false,false,true,true,true,false,false,false,true,true,false,true,false,false,false,false,true,true,true,false,false,false,false,true,true,true,true,false,true,true,true,false,true,true,true,false,true,false,true,false,true,false,false,false,true,true,false,true,false,false,true,false,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w294467:(11:ZMod 21612953250068572134196473087071)^((21612953250068572134196473087071-1)/294467)≠1:=
    ne_one [false,true,false,true,false,false,true,false,true,true,true,false,true,false,true,true,true,false,false,true,false,false,true,false,false,false,false,true,true,false,true,true,true,false,false,false,true,true,true,false,true,false,false,true,true,false,true,false,true,false,false,false,true,true,true,false,false,false,true,false,false,false,true,true,true,true,false,false,false,true,true,false,false,true,true,false,true,true,false,true,false,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w49259637758132062049629:(11:ZMod 21612953250068572134196473087071)^((21612953250068572134196473087071-1)/49259637758132062049629)≠1:=
    ne_one [false,true,true,false,true,true,true,true,true,false,false,false,false,true,true,true,false,true,true,false,false,true,false,false,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (21612953250068572134196473087071-1)=2*(5*(149*(294467*(49259637758132062049629)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=149:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w149
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=294467:=(Nat.prime_dvd_prime_iff_eq hp prime294467).mp leaf; rw [eqn]; exact w294467
  have eqn:q=49259637758132062049629:=(Nat.prime_dvd_prime_iff_eq hp prime49259637758132062049629).mp hd; rw [eqn]; exact w49259637758132062049629
theorem prime9778263152874996218584617307180549616435599 : Nat.Prime 9778263152874996218584617307180549616435599 := by
  apply lucas_primality 9778263152874996218584617307180549616435599 (3:ZMod 9778263152874996218584617307180549616435599)
  · exact eq_one [false,true,true,true,false,false,false,true,true,false,false,false,false,false,false,false,false,false,false,false,true,false,true,true,false,false,true,true,true,false,false,true,true,true,true,false,false,true,true,true,false,true,false,false,false,true,false,false,false,true,false,false,true,false,false,true,true,false,true,true,true,true,false,true,false,true,true,true,true,true,false,false,true,false,true,true,false,false,true,false,true,true,false,true,true,false,true,false,false,false,false,false,false,false,true,true,true,true,false,false,false,true,false,true,true,false,true,false,false,false,false,false,true,false,true,false,true,false,false,true,true,true,false,true,true,true,false,true,true,true,true,true,true,true,false,false,false,false,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 9778263152874996218584617307180549616435599)^((9778263152874996218584617307180549616435599-1)/2)≠1:=
    ne_one [true,true,true,false,false,false,true,true,false,false,false,false,false,false,false,false,false,false,false,true,false,true,true,false,false,true,true,true,false,false,true,true,true,true,false,false,true,true,true,false,true,false,false,false,true,false,false,false,true,false,false,true,false,false,true,true,false,true,true,true,true,false,true,false,true,true,true,true,true,false,false,true,false,true,true,false,false,true,false,true,true,false,true,true,false,true,false,false,false,false,false,false,false,true,true,true,true,false,false,false,true,false,true,true,false,true,false,false,false,false,false,true,false,true,false,true,false,false,true,true,true,false,true,true,true,false,true,true,true,true,true,true,true,false,false,false,false,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 9778263152874996218584617307180549616435599)^((9778263152874996218584617307180549616435599-1)/3)≠1:=
    ne_one [false,true,false,true,true,false,true,true,true,false,true,false,true,false,true,false,true,false,true,false,false,false,true,false,false,false,true,false,true,true,false,false,true,false,true,true,false,false,true,false,false,true,true,false,true,true,false,true,false,false,false,false,true,true,false,false,true,true,true,true,true,true,false,false,false,true,false,true,false,true,true,false,false,false,true,false,false,false,true,true,true,true,false,false,true,true,true,false,true,false,true,false,true,false,false,true,false,true,true,false,true,true,false,false,true,true,true,false,true,false,true,false,false,false,true,true,true,false,true,true,true,true,false,false,true,false,false,true,false,true,false,true,false,true,true,false,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w47:(3:ZMod 9778263152874996218584617307180549616435599)^((9778263152874996218584617307180549616435599-1)/47)≠1:=
    ne_one [false,true,false,false,true,false,true,true,true,false,true,false,true,false,false,false,false,false,true,false,true,true,true,true,false,false,false,false,true,false,false,true,true,true,false,false,false,false,true,true,true,false,false,false,true,true,false,false,true,true,true,false,false,false,true,true,true,true,true,false,true,true,false,true,true,true,false,false,true,true,true,false,false,false,false,true,false,false,true,false,false,true,false,false,true,false,false,false,true,true,false,false,true,false,true,true,true,true,false,false,true,false,false,false,false,true,true,true,true,false,false,true,false,false,false,true,false,false,false,false,false,true,true,false,false,true,true,false,true,true,false,false,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w197:(3:ZMod 9778263152874996218584617307180549616435599)^((9778263152874996218584617307180549616435599-1)/197)≠1:=
    ne_one [false,true,true,false,true,true,false,false,false,false,false,true,true,true,true,true,true,false,true,true,true,false,true,true,false,true,false,true,false,false,true,false,false,true,true,false,true,false,true,true,false,true,true,false,false,true,true,false,true,true,true,false,false,true,true,false,false,true,true,false,true,false,false,true,true,true,true,true,false,false,true,false,false,false,false,false,true,false,true,true,true,true,true,true,true,true,true,false,false,true,true,false,false,false,true,true,true,true,true,true,false,false,false,true,true,true,false,true,false,true,false,true,true,false,true,true,true,false,true,true,true,false,true,true,true,false,true,true,true,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w557:(3:ZMod 9778263152874996218584617307180549616435599)^((9778263152874996218584617307180549616435599-1)/557)≠1:=
    ne_one [false,true,true,false,false,false,false,true,false,true,true,false,true,false,false,false,true,true,false,true,true,true,true,false,true,false,true,false,true,true,true,false,false,false,false,true,false,false,false,true,false,true,false,false,false,true,false,false,true,true,false,false,false,false,true,true,true,false,false,true,false,false,false,true,true,true,true,true,true,true,false,false,true,true,true,true,false,true,false,true,false,true,true,false,true,false,false,false,true,true,false,true,false,true,false,false,false,true,true,true,true,false,false,false,false,false,true,false,true,false,true,false,false,true,true,false,true,false,false,false,true,true,true,false,true,false,false,true,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w14621:(3:ZMod 9778263152874996218584617307180549616435599)^((9778263152874996218584617307180549616435599-1)/14621)≠1:=
    ne_one [false,true,true,false,false,true,true,false,false,false,false,false,false,false,true,false,false,true,false,true,true,false,false,true,true,true,true,true,false,false,false,true,false,true,true,false,true,true,true,true,true,false,true,false,true,false,true,true,false,true,true,true,false,false,true,false,true,true,false,false,true,false,false,false,false,false,false,false,true,true,false,true,true,false,false,true,false,false,false,false,false,true,false,true,true,false,true,false,false,true,false,false,true,true,false,false,false,false,false,true,false,false,false,true,true,true,true,true,true,true,false,true,false,true,false,false,false,true,false,false,true,true,true,false,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w21612953250068572134196473087071:(3:ZMod 9778263152874996218584617307180549616435599)^((9778263152874996218584617307180549616435599-1)/21612953250068572134196473087071)≠1:=
    ne_one [false,true,false,false,true,true,false,false,true,false,false,true,true,true,false,true,true,false,false,false,true,true,false,true,false,true,true,false,true,false,true,false,true,false,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (9778263152874996218584617307180549616435599-1)=2*(3*(47*(197*(557*(14621*(21612953250068572134196473087071)))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=47:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w47
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=197:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w197
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=557:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w557
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=14621:=(Nat.prime_dvd_prime_iff_eq hp prime14621).mp leaf; rw [eqn]; exact w14621
  have eqn:q=21612953250068572134196473087071:=(Nat.prime_dvd_prime_iff_eq hp prime21612953250068572134196473087071).mp hd; rw [eqn]; exact w21612953250068572134196473087071
theorem prime37181 : Nat.Prime 37181 := by
  apply lucas_primality 37181 (2:ZMod 37181)
  · exact eq_one [false,false,true,true,true,true,false,false,true,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 37181)^((37181-1)/2)≠1:=
    ne_one [false,true,true,true,true,false,false,true,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(2:ZMod 37181)^((37181-1)/5)≠1:=
    ne_one [false,false,true,true,false,false,false,false,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w11:(2:ZMod 37181)^((37181-1)/11)≠1:=
    ne_one [false,false,true,false,true,true,false,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w13:(2:ZMod 37181)^((37181-1)/13)≠1:=
    ne_one [false,false,true,true,false,true,false,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (37181-1)=2*(2*(5*(11*(13*(13))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w11
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=13:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w13
  have eqn:q=13:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w13
theorem prime74363 : Nat.Prime 74363 := by
  apply lucas_primality 74363 (2:ZMod 74363)
  · exact eq_one [false,true,false,true,true,true,true,false,false,true,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 74363)^((74363-1)/2)≠1:=
    ne_one [true,false,true,true,true,true,false,false,true,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w37181:(2:ZMod 74363)^((74363-1)/37181)≠1:=
    ne_one [false,true] (by decide +kernel) (by decide +kernel)
  rw [show (74363-1)=2*(37181) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  have eqn:q=37181:=(Nat.prime_dvd_prime_iff_eq hp prime37181).mp hd; rw [eqn]; exact w37181
theorem prime1617097799 : Nat.Prime 1617097799 := by
  apply lucas_primality 1617097799 (7:ZMod 1617097799)
  · exact eq_one [false,true,true,false,false,false,true,false,false,false,true,false,true,true,true,true,false,true,false,false,false,true,true,false,false,false,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(7:ZMod 1617097799)^((1617097799-1)/2)≠1:=
    ne_one [true,true,false,false,false,true,false,false,false,true,false,true,true,true,true,false,true,false,false,false,true,true,false,false,false,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w83:(7:ZMod 1617097799)^((1617097799-1)/83)≠1:=
    ne_one [false,true,false,false,false,true,true,true,true,false,false,true,false,false,true,false,true,false,false,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w131:(7:ZMod 1617097799)^((1617097799-1)/131)≠1:=
    ne_one [false,true,false,false,false,false,true,true,true,true,false,true,true,false,true,false,false,false,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w74363:(7:ZMod 1617097799)^((1617097799-1)/74363)≠1:=
    ne_one [false,true,false,false,true,true,true,true,false,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (1617097799-1)=2*(83*(131*(74363))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=83:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w83
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=131:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w131
  have eqn:q=74363:=(Nat.prime_dvd_prime_iff_eq hp prime74363).mp hd; rw [eqn]; exact w74363
theorem prime1327 : Nat.Prime 1327 := by
  apply lucas_primality 1327 (3:ZMod 1327)
  · exact eq_one [false,true,true,true,false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 1327)^((1327-1)/2)≠1:=
    ne_one [true,true,true,false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 1327)^((1327-1)/3)≠1:=
    ne_one [false,true,false,true,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w13:(3:ZMod 1327)^((1327-1)/13)≠1:=
    ne_one [false,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w17:(3:ZMod 1327)^((1327-1)/17)≠1:=
    ne_one [false,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (1327-1)=2*(3*(13*(17))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=13:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w13
  have eqn:q=17:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w17
theorem prime5309 : Nat.Prime 5309 := by
  apply lucas_primality 5309 (2:ZMod 5309)
  · exact eq_one [false,false,true,true,true,true,false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 5309)^((5309-1)/2)≠1:=
    ne_one [false,true,true,true,true,false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w1327:(2:ZMod 5309)^((5309-1)/1327)≠1:=
    ne_one [false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (5309-1)=2*(2*(1327)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  have eqn:q=1327:=(Nat.prime_dvd_prime_iff_eq hp prime1327).mp hd; rw [eqn]; exact w1327
theorem prime9043 : Nat.Prime 9043 := by
  apply lucas_primality 9043 (3:ZMod 9043)
  · exact eq_one [false,true,false,false,true,false,true,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 9043)^((9043-1)/2)≠1:=
    ne_one [true,false,false,true,false,true,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 9043)^((9043-1)/3)≠1:=
    ne_one [false,true,true,false,false,false,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w11:(3:ZMod 9043)^((9043-1)/11)≠1:=
    ne_one [false,true,true,false,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w137:(3:ZMod 9043)^((9043-1)/137)≠1:=
    ne_one [false,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (9043-1)=2*(3*(11*(137))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w11
  have eqn:q=137:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w137
theorem prime241291 : Nat.Prime 241291 := by
  apply lucas_primality 241291 (2:ZMod 241291)
  · exact eq_one [false,true,false,true,false,false,false,true,false,true,true,true,false,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 241291)^((241291-1)/2)≠1:=
    ne_one [true,false,true,false,false,false,true,false,true,true,true,false,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(2:ZMod 241291)^((241291-1)/3)≠1:=
    ne_one [false,true,true,true,false,true,false,false,false,true,false,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(2:ZMod 241291)^((241291-1)/5)≠1:=
    ne_one [false,true,false,false,false,false,false,true,false,false,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w7:(2:ZMod 241291)^((241291-1)/7)≠1:=
    ne_one [false,true,true,false,false,true,false,true,false,true,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w383:(2:ZMod 241291)^((241291-1)/383)≠1:=
    ne_one [false,true,true,false,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (241291-1)=2*(3*(3*(5*(7*(383))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  have eqn:q=383:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w383
theorem prime2295259 : Nat.Prime 2295259 := by
  apply lucas_primality 2295259 (3:ZMod 2295259)
  · exact eq_one [false,true,false,true,true,false,true,true,true,false,true,false,false,false,false,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 2295259)^((2295259-1)/2)≠1:=
    ne_one [true,false,true,true,false,true,true,true,false,true,false,false,false,false,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 2295259)^((2295259-1)/3)≠1:=
    ne_one [false,true,true,true,true,false,false,true,false,false,true,true,false,true,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w7:(3:ZMod 2295259)^((2295259-1)/7)≠1:=
    ne_one [false,true,true,false,true,false,true,true,false,false,false,false,false,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w37:(3:ZMod 2295259)^((2295259-1)/37)≠1:=
    ne_one [false,true,false,false,true,false,true,false,false,true,false,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w211:(3:ZMod 2295259)^((2295259-1)/211)≠1:=
    ne_one [false,true,true,true,true,true,true,false,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (2295259-1)=2*(3*(7*(7*(37*(211))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=37:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w37
  have eqn:q=211:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w211
theorem prime133125023 : Nat.Prime 133125023 := by
  apply lucas_primality 133125023 (5:ZMod 133125023)
  · exact eq_one [false,true,true,true,true,false,false,true,true,true,false,false,true,false,true,false,true,true,true,true,false,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 133125023)^((133125023-1)/2)≠1:=
    ne_one [true,true,true,true,false,false,true,true,true,false,false,true,false,true,false,true,true,true,true,false,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w29:(5:ZMod 133125023)^((133125023-1)/29)≠1:=
    ne_one [false,true,true,false,true,true,false,true,true,true,false,true,false,false,false,false,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w2295259:(5:ZMod 133125023)^((133125023-1)/2295259)≠1:=
    ne_one [false,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (133125023-1)=2*(29*(2295259)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=29:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w29
  have eqn:q=2295259:=(Nat.prime_dvd_prime_iff_eq hp prime2295259).mp hd; rw [eqn]; exact w2295259
theorem prime107950365053387823672371 : Nat.Prime 107950365053387823672371 := by
  apply lucas_primality 107950365053387823672371 (2:ZMod 107950365053387823672371)
  · exact eq_one [false,true,false,false,true,true,false,false,false,false,true,true,false,true,true,false,false,false,false,false,false,false,true,false,true,true,false,true,true,true,true,false,false,true,false,false,false,false,false,true,false,true,true,true,false,false,false,true,false,true,false,false,false,false,true,false,false,false,false,false,false,false,false,false,false,false,true,true,true,false,true,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 107950365053387823672371)^((107950365053387823672371-1)/2)≠1:=
    ne_one [true,false,false,true,true,false,false,false,false,true,true,false,true,true,false,false,false,false,false,false,false,true,false,true,true,false,true,true,true,true,false,false,true,false,false,false,false,false,true,false,true,true,true,false,false,false,true,false,true,false,false,false,false,true,false,false,false,false,false,false,false,false,false,false,false,true,true,true,false,true,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(2:ZMod 107950365053387823672371)^((107950365053387823672371-1)/5)≠1:=
    ne_one [false,true,false,true,false,false,false,false,false,false,true,true,true,true,true,false,false,true,true,false,false,true,false,true,false,false,false,true,true,false,false,false,false,true,false,true,true,false,false,false,false,true,true,false,true,true,false,true,true,true,false,false,true,true,true,false,false,true,true,false,false,true,true,false,false,true,false,false,true,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w7:(2:ZMod 107950365053387823672371)^((107950365053387823672371-1)/7)≠1:=
    ne_one [false,true,true,true,true,true,false,true,true,false,false,false,false,true,false,true,false,false,true,false,false,true,true,true,true,true,false,false,false,true,false,true,false,true,false,false,true,false,false,false,false,true,false,false,false,false,false,true,true,false,false,true,false,false,false,false,false,false,false,false,false,false,false,false,false,false,true,false,false,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w5309:(2:ZMod 107950365053387823672371)^((107950365053387823672371-1)/5309)≠1:=
    ne_one [false,true,false,true,true,false,false,false,true,false,true,false,false,true,false,false,true,true,false,true,false,true,false,true,false,true,true,false,true,true,true,true,true,true,false,false,true,false,false,true,false,true,false,true,true,true,true,true,false,true,true,true,false,true,false,false,false,true,false,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w9043:(2:ZMod 107950365053387823672371)^((107950365053387823672371-1)/9043)≠1:=
    ne_one [false,true,true,false,false,false,true,true,false,true,true,true,true,true,false,false,true,false,true,true,false,true,false,false,true,true,true,true,false,true,false,false,false,false,false,false,false,false,false,false,false,false,false,true,true,false,true,false,false,true,false,true,false,true,false,true,true,false,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w241291:(2:ZMod 107950365053387823672371)^((107950365053387823672371-1)/241291)≠1:=
    ne_one [false,true,true,false,true,false,true,true,false,false,true,true,false,false,false,false,false,true,false,true,true,true,false,true,true,false,false,false,true,false,true,true,false,true,false,false,false,false,true,true,true,true,true,true,false,true,true,false,true,false,true,false,true,true,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w133125023:(2:ZMod 107950365053387823672371)^((107950365053387823672371-1)/133125023)≠1:=
    ne_one [false,true,true,true,false,false,false,true,false,true,true,false,true,true,false,true,true,true,false,false,true,false,true,true,true,false,true,true,true,false,false,false,true,false,false,false,false,false,false,true,true,false,false,false,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (107950365053387823672371-1)=2*(5*(7*(5309*(9043*(241291*(133125023)))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5309:=(Nat.prime_dvd_prime_iff_eq hp prime5309).mp leaf; rw [eqn]; exact w5309
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=9043:=(Nat.prime_dvd_prime_iff_eq hp prime9043).mp leaf; rw [eqn]; exact w9043
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=241291:=(Nat.prime_dvd_prime_iff_eq hp prime241291).mp leaf; rw [eqn]; exact w241291
  have eqn:q=133125023:=(Nat.prime_dvd_prime_iff_eq hp prime133125023).mp hd; rw [eqn]; exact w133125023
theorem prime23042751300238555664326843839908629 : Nat.Prime 23042751300238555664326843839908629 := by
  apply lucas_primality 23042751300238555664326843839908629 (2:ZMod 23042751300238555664326843839908629)
  · exact eq_one [false,false,true,false,true,false,false,false,true,true,false,true,false,false,false,true,true,false,false,false,false,true,true,false,false,false,false,true,false,false,true,false,true,false,false,true,false,true,false,true,false,true,true,true,true,false,true,false,false,true,false,false,true,true,true,false,false,false,true,false,true,true,false,false,true,true,false,true,true,true,false,false,false,false,false,false,true,true,true,false,true,true,true,true,false,false,false,false,true,false,false,true,false,true,true,false,false,false,false,true,true,false,false,false,false,false,false,false,true,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 23042751300238555664326843839908629)^((23042751300238555664326843839908629-1)/2)≠1:=
    ne_one [false,true,false,true,false,false,false,true,true,false,true,false,false,false,true,true,false,false,false,false,true,true,false,false,false,false,true,false,false,true,false,true,false,false,true,false,true,false,true,false,true,true,true,true,false,true,false,false,true,false,false,true,true,true,false,false,false,true,false,true,true,false,false,true,true,false,true,true,true,false,false,false,false,false,false,true,true,true,false,true,true,true,true,false,false,false,false,true,false,false,true,false,true,true,false,false,false,false,true,true,false,false,false,false,false,false,false,true,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(2:ZMod 23042751300238555664326843839908629)^((23042751300238555664326843839908629-1)/3)≠1:=
    ne_one [false,false,true,true,true,false,true,false,false,true,true,true,false,true,false,false,true,true,false,true,false,false,true,true,false,true,false,false,false,false,true,true,true,false,true,true,false,false,false,true,true,true,true,true,true,false,false,false,false,true,true,false,false,true,false,false,false,false,true,true,true,true,false,true,true,true,false,false,true,false,false,false,false,false,false,false,true,false,true,true,true,true,true,true,false,true,false,true,true,false,true,true,false,false,true,true,false,true,false,false,true,true,false,true,false,true,false,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w11:(2:ZMod 23042751300238555664326843839908629)^((23042751300238555664326843839908629-1)/11)≠1:=
    ne_one [false,false,true,true,true,true,false,true,true,false,false,true,false,true,true,false,true,true,true,false,true,true,false,false,false,true,false,false,true,false,false,true,true,false,false,true,false,false,true,true,false,true,false,false,false,false,true,true,false,true,true,true,true,true,true,false,true,false,true,true,false,true,true,true,true,true,false,false,true,true,false,false,false,true,false,true,false,false,false,false,true,false,true,true,false,false,false,true,true,false,false,true,false,false,false,false,false,false,false,true,false,false,true,false,true,true,true,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w1617097799:(2:ZMod 23042751300238555664326843839908629)^((23042751300238555664326843839908629-1)/1617097799)≠1:=
    ne_one [false,false,true,true,false,false,true,false,false,true,false,true,false,false,true,true,true,true,true,false,true,true,false,false,true,false,true,true,false,false,false,true,true,true,true,false,false,false,true,false,true,true,false,true,true,true,true,false,true,false,false,false,true,false,true,false,false,true,false,false,false,true,false,false,false,false,false,false,true,true,true,false,true,false,false,true,false,false,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w107950365053387823672371:(2:ZMod 23042751300238555664326843839908629)^((23042751300238555664326843839908629-1)/107950365053387823672371)≠1:=
    ne_one [false,false,true,true,true,false,false,true,false,false,true,false,true,true,true,true,true,false,true,false,false,false,false,false,true,true,false,false,true,true,false,true,true,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (23042751300238555664326843839908629-1)=2*(2*(3*(11*(1617097799*(107950365053387823672371))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w11
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=1617097799:=(Nat.prime_dvd_prime_iff_eq hp prime1617097799).mp leaf; rw [eqn]; exact w1617097799
  have eqn:q=107950365053387823672371:=(Nat.prime_dvd_prime_iff_eq hp prime107950365053387823672371).mp hd; rw [eqn]; exact w107950365053387823672371
theorem prime92171005200954222657307375359634517 : Nat.Prime 92171005200954222657307375359634517 := by
  apply lucas_primality 92171005200954222657307375359634517 (2:ZMod 92171005200954222657307375359634517)
  · exact eq_one [false,false,true,false,true,false,true,false,false,false,true,true,false,true,false,false,false,true,true,false,false,false,false,true,true,false,false,false,false,true,false,false,true,false,true,false,false,true,false,true,false,true,false,true,true,true,true,false,true,false,false,true,false,false,true,true,true,false,false,false,true,false,true,true,false,false,true,true,false,true,true,true,false,false,false,false,false,false,true,true,true,false,true,true,true,true,false,false,false,false,true,false,false,true,false,true,true,false,false,false,false,true,true,false,false,false,false,false,false,false,true,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 92171005200954222657307375359634517)^((92171005200954222657307375359634517-1)/2)≠1:=
    ne_one [false,true,false,true,false,true,false,false,false,true,true,false,true,false,false,false,true,true,false,false,false,false,true,true,false,false,false,false,true,false,false,true,false,true,false,false,true,false,true,false,true,false,true,true,true,true,false,true,false,false,true,false,false,true,true,true,false,false,false,true,false,true,true,false,false,true,true,false,true,true,true,false,false,false,false,false,false,true,true,true,false,true,true,true,true,false,false,false,false,true,false,false,true,false,true,true,false,false,false,false,true,true,false,false,false,false,false,false,false,true,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w23042751300238555664326843839908629:(2:ZMod 92171005200954222657307375359634517)^((92171005200954222657307375359634517-1)/23042751300238555664326843839908629)≠1:=
    ne_one [false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (92171005200954222657307375359634517-1)=2*(2*(23042751300238555664326843839908629)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  have eqn:q=23042751300238555664326843839908629:=(Nat.prime_dvd_prime_iff_eq hp prime23042751300238555664326843839908629).mp hd; rw [eqn]; exact w23042751300238555664326843839908629
theorem prime5161576291253436468809213020139532953 : Nat.Prime 5161576291253436468809213020139532953 := by
  apply lucas_primality 5161576291253436468809213020139532953 (5:ZMod 5161576291253436468809213020139532953)
  · exact eq_one [false,false,false,true,true,false,false,true,false,true,false,false,true,true,false,true,true,false,false,true,true,false,true,false,true,false,true,false,true,false,true,false,true,true,true,true,true,false,false,false,false,false,true,false,true,false,true,true,false,true,false,false,true,false,false,false,false,false,true,false,false,true,true,true,true,false,true,true,false,false,true,true,true,true,false,false,true,true,false,false,false,true,false,false,false,false,false,true,true,false,true,true,false,true,true,true,true,true,false,true,true,false,true,false,true,false,true,false,true,false,false,false,false,true,false,false,false,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 5161576291253436468809213020139532953)^((5161576291253436468809213020139532953-1)/2)≠1:=
    ne_one [false,false,true,true,false,false,true,false,true,false,false,true,true,false,true,true,false,false,true,true,false,true,false,true,false,true,false,true,false,true,false,true,true,true,true,true,false,false,false,false,false,true,false,true,false,true,true,false,true,false,false,true,false,false,false,false,false,true,false,false,true,true,true,true,false,true,true,false,false,true,true,true,true,false,false,true,true,false,false,false,true,false,false,false,false,false,true,true,false,true,true,false,true,true,true,true,true,false,true,true,false,true,false,true,false,true,false,true,false,false,false,false,true,false,false,false,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w7:(5:ZMod 5161576291253436468809213020139532953)^((5161576291253436468809213020139532953-1)/7)≠1:=
    ne_one [false,false,false,true,false,true,false,true,false,true,false,false,false,true,true,false,true,false,false,false,true,true,false,false,false,false,true,true,false,false,false,false,true,false,false,true,false,true,false,false,true,false,true,false,true,false,true,true,true,true,false,true,false,false,true,false,false,true,true,true,false,false,false,true,false,true,true,false,false,true,true,false,true,true,true,false,false,false,false,false,false,true,true,true,false,true,true,true,true,false,false,false,false,true,false,false,true,false,true,true,false,false,false,false,true,true,false,false,false,false,false,false,false,true,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w92171005200954222657307375359634517:(5:ZMod 5161576291253436468809213020139532953)^((5161576291253436468809213020139532953-1)/92171005200954222657307375359634517)≠1:=
    ne_one [false,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (5161576291253436468809213020139532953-1)=2*(2*(2*(7*(92171005200954222657307375359634517)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  have eqn:q=92171005200954222657307375359634517:=(Nat.prime_dvd_prime_iff_eq hp prime92171005200954222657307375359634517).mp hd; rw [eqn]; exact w92171005200954222657307375359634517
theorem prime503175397608024323584539371320514986481668897 : Nat.Prime 503175397608024323584539371320514986481668897 := by
  apply lucas_primality 503175397608024323584539371320514986481668897 (10:ZMod 503175397608024323584539371320514986481668897)
  · exact eq_one [false,false,false,false,false,true,false,false,true,true,false,false,true,false,true,true,true,false,false,true,true,true,false,false,true,true,false,true,false,true,true,true,true,true,false,true,true,false,false,true,false,true,false,false,true,true,true,true,false,true,false,true,false,true,true,false,false,true,true,true,false,false,false,false,false,false,true,false,false,true,false,false,true,false,true,false,true,true,false,false,true,false,true,true,true,false,false,false,true,true,false,false,true,true,false,true,true,false,false,true,false,false,false,true,true,false,false,true,true,true,false,false,true,false,false,true,false,true,true,true,true,true,true,false,true,false,false,true,true,true,false,true,false,true,false,false,false,false,false,false,true,false,false,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(10:ZMod 503175397608024323584539371320514986481668897)^((503175397608024323584539371320514986481668897-1)/2)≠1:=
    ne_one [false,false,false,false,true,false,false,true,true,false,false,true,false,true,true,true,false,false,true,true,true,false,false,true,true,false,true,false,true,true,true,true,true,false,true,true,false,false,true,false,true,false,false,true,true,true,true,false,true,false,true,false,true,true,false,false,true,true,true,false,false,false,false,false,false,true,false,false,true,false,false,true,false,true,false,true,true,false,false,true,false,true,true,true,false,false,false,true,true,false,false,true,true,false,true,true,false,false,true,false,false,false,true,true,false,false,true,true,true,false,false,true,false,false,true,false,true,true,true,true,true,true,false,true,false,false,true,true,true,false,true,false,true,false,false,false,false,false,false,true,false,false,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(10:ZMod 503175397608024323584539371320514986481668897)^((503175397608024323584539371320514986481668897-1)/3)≠1:=
    ne_one [false,false,false,false,false,true,true,false,false,true,true,false,false,false,true,false,true,true,false,false,true,false,false,false,true,false,false,true,true,true,true,true,true,true,false,false,true,true,false,false,false,true,true,false,false,true,false,true,true,true,false,false,false,true,false,false,false,true,false,true,true,false,true,false,true,false,false,false,false,true,true,false,false,false,true,true,true,true,false,true,true,false,false,true,false,false,false,false,true,false,false,false,true,false,false,true,false,false,false,true,true,false,true,true,true,false,true,true,true,true,false,true,true,false,true,true,false,false,true,false,true,false,true,true,true,false,true,true,true,true,false,false,false,true,true,false,true,false,true,false,false,false,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w31:(10:ZMod 503175397608024323584539371320514986481668897)^((503175397608024323584539371320514986481668897-1)/31)≠1:=
    ne_one [false,false,false,false,false,true,true,true,false,false,false,true,false,false,true,false,true,true,true,true,false,true,false,true,false,true,false,true,false,true,true,false,true,false,false,false,true,false,false,true,true,true,true,true,true,true,true,true,false,false,true,false,true,true,false,false,false,false,false,true,true,true,true,true,false,true,false,true,true,true,false,false,false,true,false,false,true,false,false,false,true,false,true,false,false,false,false,true,true,false,true,true,true,true,true,true,true,false,true,false,true,true,false,false,true,false,true,true,false,true,true,false,false,false,true,false,false,true,false,true,false,false,true,true,true,true,true,true,true,true,false,false,true,false,true,false,false,true,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w61:(10:ZMod 503175397608024323584539371320514986481668897)^((503175397608024323584539371320514986481668897-1)/61)≠1:=
    ne_one [false,false,false,false,false,true,false,true,true,false,false,false,true,true,false,false,false,true,true,false,false,false,true,true,false,false,true,true,false,true,true,false,false,true,false,true,false,true,false,true,false,true,false,false,true,false,false,true,false,false,false,true,false,true,true,true,true,true,false,false,false,true,false,true,true,false,false,false,false,false,true,true,true,true,false,false,true,false,false,true,false,true,false,false,false,false,false,true,false,false,true,false,false,true,false,false,true,false,true,false,true,false,false,true,false,true,true,true,false,false,true,true,false,false,false,true,true,false,false,false,false,true,false,true,true,true,true,true,false,false,false,false,true,true,false,true,false,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w179:(10:ZMod 503175397608024323584539371320514986481668897)^((503175397608024323584539371320514986481668897-1)/179)≠1:=
    ne_one [false,false,false,false,false,true,true,false,false,false,false,false,true,true,false,false,false,false,false,true,false,false,false,true,false,false,true,false,false,false,true,false,false,false,true,false,false,true,true,true,true,false,false,false,false,true,true,true,true,true,true,true,true,true,true,false,true,true,true,false,true,true,true,true,true,false,true,true,false,true,false,false,true,true,true,false,true,false,false,false,true,true,true,true,true,true,false,false,true,false,true,true,true,false,true,true,true,false,true,false,true,false,true,true,false,false,true,true,false,false,true,true,false,true,true,true,true,true,false,false,false,false,true,false,false,true,true,true,false,false,true,false,false,false,true,false,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w5161576291253436468809213020139532953:(10:ZMod 503175397608024323584539371320514986481668897)^((503175397608024323584539371320514986481668897-1)/5161576291253436468809213020139532953)≠1:=
    ne_one [false,false,false,false,false,true,false,false,false,false,false,false,false,false,false,true,true,true,true,true,false,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (503175397608024323584539371320514986481668897-1)=2*(2*(2*(2*(2*(3*(3*(31*(61*(179*(5161576291253436468809213020139532953)))))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=31:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w31
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=61:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w61
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=179:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w179
  have eqn:q=5161576291253436468809213020139532953:=(Nat.prime_dvd_prime_iff_eq hp prime5161576291253436468809213020139532953).mp hd; rw [eqn]; exact w5161576291253436468809213020139532953
theorem prime1783 : Nat.Prime 1783 := by
  apply lucas_primality 1783 (10:ZMod 1783)
  · exact eq_one [false,true,true,false,true,true,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(10:ZMod 1783)^((1783-1)/2)≠1:=
    ne_one [true,true,false,true,true,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(10:ZMod 1783)^((1783-1)/3)≠1:=
    ne_one [false,true,false,false,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w11:(10:ZMod 1783)^((1783-1)/11)≠1:=
    ne_one [false,true,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (1783-1)=2*(3*(3*(3*(3*(11))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=11:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w11
theorem prime1039 : Nat.Prime 1039 := by
  apply lucas_primality 1039 (3:ZMod 1039)
  · exact eq_one [false,true,true,true,false,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 1039)^((1039-1)/2)≠1:=
    ne_one [true,true,true,false,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 1039)^((1039-1)/3)≠1:=
    ne_one [false,true,false,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w173:(3:ZMod 1039)^((1039-1)/173)≠1:=
    ne_one [false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (1039-1)=2*(3*(173)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=173:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w173
theorem prime39251 : Nat.Prime 39251 := by
  apply lucas_primality 39251 (2:ZMod 39251)
  · exact eq_one [false,true,false,false,true,false,true,false,true,false,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 39251)^((39251-1)/2)≠1:=
    ne_one [true,false,false,true,false,true,false,true,false,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(2:ZMod 39251)^((39251-1)/5)≠1:=
    ne_one [false,true,false,true,false,true,false,true,false,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w157:(2:ZMod 39251)^((39251-1)/157)≠1:=
    ne_one [false,true,false,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (39251-1)=2*(5*(5*(5*(157)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  have eqn:q=157:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w157
theorem prime343169 : Nat.Prime 343169 := by
  apply lucas_primality 343169 (6:ZMod 343169)
  · exact eq_one [false,false,false,false,false,false,false,true,false,false,true,true,true,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(6:ZMod 343169)^((343169-1)/2)≠1:=
    ne_one [false,false,false,false,false,false,true,false,false,true,true,true,true,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w7:(6:ZMod 343169)^((343169-1)/7)≠1:=
    ne_one [false,false,false,false,false,false,false,true,true,true,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w383:(6:ZMod 343169)^((343169-1)/383)≠1:=
    ne_one [false,false,false,false,false,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (343169-1)=2*(2*(2*(2*(2*(2*(2*(7*(383)))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  have eqn:q=383:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w383
theorem prime298557031 : Nat.Prime 298557031 := by
  apply lucas_primality 298557031 (3:ZMod 298557031)
  · exact eq_one [false,true,true,false,false,true,true,false,false,true,true,true,true,false,false,true,true,true,false,true,false,false,true,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 298557031)^((298557031-1)/2)≠1:=
    ne_one [true,true,false,false,true,true,false,false,true,true,true,true,false,false,true,true,true,false,true,false,false,true,true,true,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 298557031)^((298557031-1)/3)≠1:=
    ne_one [false,true,false,false,false,true,false,false,false,true,false,true,false,false,false,true,false,true,true,true,false,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w5:(3:ZMod 298557031)^((298557031-1)/5)≠1:=
    ne_one [false,true,true,true,false,true,false,true,true,true,true,true,true,false,false,false,true,true,true,true,false,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w29:(3:ZMod 298557031)^((298557031-1)/29)≠1:=
    ne_one [false,true,true,true,true,false,false,false,true,true,true,false,true,false,false,false,true,false,true,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w343169:(3:ZMod 298557031)^((298557031-1)/343169)≠1:=
    ne_one [false,true,true,false,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (298557031-1)=2*(3*(5*(29*(343169)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=29:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w29
  have eqn:q=343169:=(Nat.prime_dvd_prime_iff_eq hp prime343169).mp hd; rw [eqn]; exact w343169
theorem prime24351379685416919 : Nat.Prime 24351379685416919 := by
  apply lucas_primality 24351379685416919 (7:ZMod 24351379685416919)
  · exact eq_one [false,true,true,false,true,false,true,true,true,true,true,true,true,false,false,true,false,false,false,false,true,true,true,true,true,true,true,false,false,true,true,false,true,true,false,false,true,true,true,false,true,true,false,false,false,false,false,true,false,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(7:ZMod 24351379685416919)^((24351379685416919-1)/2)≠1:=
    ne_one [true,true,false,true,false,true,true,true,true,true,true,true,false,false,true,false,false,false,false,true,true,true,true,true,true,true,false,false,true,true,false,true,true,false,false,true,true,true,false,true,true,false,false,false,false,false,true,false,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w1039:(7:ZMod 24351379685416919)^((24351379685416919-1)/1039)≠1:=
    ne_one [false,true,false,true,false,false,true,true,false,false,true,false,true,false,true,true,true,true,true,true,true,false,true,false,true,false,true,true,false,true,true,true,false,false,false,false,true,false,true,false,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w39251:(7:ZMod 24351379685416919)^((24351379685416919-1)/39251)≠1:=
    ne_one [false,true,false,false,true,false,false,false,false,false,false,true,false,false,true,true,true,true,true,true,false,false,true,true,false,true,false,false,true,true,true,false,false,false,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w298557031:(7:ZMod 24351379685416919)^((24351379685416919-1)/298557031)≠1:=
    ne_one [false,true,false,true,true,true,false,true,true,true,true,true,false,false,false,true,false,false,true,true,true,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (24351379685416919-1)=2*(1039*(39251*(298557031))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=1039:=(Nat.prime_dvd_prime_iff_eq hp prime1039).mp leaf; rw [eqn]; exact w1039
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=39251:=(Nat.prime_dvd_prime_iff_eq hp prime39251).mp leaf; rw [eqn]; exact w39251
  have eqn:q=298557031:=(Nat.prime_dvd_prime_iff_eq hp prime298557031).mp hd; rw [eqn]; exact w298557031
theorem prime3727 : Nat.Prime 3727 := by
  apply lucas_primality 3727 (3:ZMod 3727)
  · exact eq_one [false,true,true,true,false,false,false,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 3727)^((3727-1)/2)≠1:=
    ne_one [true,true,true,false,false,false,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(3:ZMod 3727)^((3727-1)/3)≠1:=
    ne_one [false,true,false,true,true,false,true,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w23:(3:ZMod 3727)^((3727-1)/23)≠1:=
    ne_one [false,true,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (3727-1)=2*(3*(3*(3*(3*(23))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=23:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w23
theorem prime7057 : Nat.Prime 7057 := by
  apply lucas_primality 7057 (5:ZMod 7057)
  · exact eq_one [false,false,false,false,true,false,false,true,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 7057)^((7057-1)/2)≠1:=
    ne_one [false,false,false,true,false,false,true,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(5:ZMod 7057)^((7057-1)/3)≠1:=
    ne_one [false,false,false,false,true,true,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w7:(5:ZMod 7057)^((7057-1)/7)≠1:=
    ne_one [false,false,false,false,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (7057-1)=2*(2*(2*(2*(3*(3*(7*(7))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w7
theorem prime42977131 : Nat.Prime 42977131 := by
  apply lucas_primality 42977131 (10:ZMod 42977131)
  · exact eq_one [false,true,false,true,false,true,true,false,true,true,true,false,false,false,true,true,true,true,true,true,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(10:ZMod 42977131)^((42977131-1)/2)≠1:=
    ne_one [true,false,true,false,true,true,false,true,true,true,false,false,false,true,true,true,true,true,true,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(10:ZMod 42977131)^((42977131-1)/3)≠1:=
    ne_one [false,true,true,true,false,false,true,true,true,true,true,false,true,false,false,true,false,true,false,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w5:(10:ZMod 42977131)^((42977131-1)/5)≠1:=
    ne_one [false,true,false,false,false,true,true,true,true,true,true,false,false,true,false,false,true,true,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w7:(10:ZMod 42977131)^((42977131-1)/7)≠1:=
    ne_one [false,true,true,false,false,false,true,true,false,true,true,true,false,true,false,true,true,false,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w29:(10:ZMod 42977131)^((42977131-1)/29)≠1:=
    ne_one [false,true,false,false,true,true,true,true,false,false,true,true,true,false,false,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w7057:(10:ZMod 42977131)^((42977131-1)/7057)≠1:=
    ne_one [false,true,false,true,false,false,true,true,true,true,true,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (42977131-1)=2*(3*(5*(7*(29*(7057))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w5
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=29:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w29
  have eqn:q=7057:=(Nat.prime_dvd_prime_iff_eq hp prime7057).mp hd; rw [eqn]; exact w7057
theorem prime5623 : Nat.Prime 5623 := by
  apply lucas_primality 5623 (5:ZMod 5623)
  · exact eq_one [false,true,true,false,true,true,true,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 5623)^((5623-1)/2)≠1:=
    ne_one [true,true,false,true,true,true,true,true,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w3:(5:ZMod 5623)^((5623-1)/3)≠1:=
    ne_one [false,true,false,false,true,false,true,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w937:(5:ZMod 5623)^((5623-1)/937)≠1:=
    ne_one [false,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (5623-1)=2*(3*(937)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  have eqn:q=937:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w937
theorem prime53939 : Nat.Prime 53939 := by
  apply lucas_primality 53939 (2:ZMod 53939)
  · exact eq_one [false,true,false,false,true,true,false,true,false,true,false,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(2:ZMod 53939)^((53939-1)/2)≠1:=
    ne_one [true,false,false,true,true,false,true,false,true,false,false,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w149:(2:ZMod 53939)^((53939-1)/149)≠1:=
    ne_one [false,true,false,true,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w181:(2:ZMod 53939)^((53939-1)/181)≠1:=
    ne_one [false,true,false,true,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (53939-1)=2*(149*(181)) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=149:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w149
  have eqn:q=181:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp hd; rw [eqn]; exact w181
theorem prime475572827297 : Nat.Prime 475572827297 := by
  apply lucas_primality 475572827297 (3:ZMod 475572827297)
  · exact eq_one [false,false,false,false,false,true,false,true,false,false,true,false,true,true,true,false,true,false,false,true,true,false,true,false,false,true,false,true,true,true,false,true,false,true,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(3:ZMod 475572827297)^((475572827297-1)/2)≠1:=
    ne_one [false,false,false,false,true,false,true,false,false,true,false,true,true,true,false,true,false,false,true,true,false,true,false,false,true,false,true,true,true,false,true,false,true,true,true,false,true,true] (by decide +kernel) (by decide +kernel)
  have w7:(3:ZMod 475572827297)^((475572827297-1)/7)≠1:=
    ne_one [false,false,false,false,false,true,true,false,false,true,true,true,true,true,true,false,false,true,false,true,true,true,true,false,true,false,false,false,true,false,true,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w5623:(3:ZMod 475572827297)^((475572827297-1)/5623)≠1:=
    ne_one [false,false,false,false,false,true,true,false,false,false,false,true,false,false,false,true,false,true,false,true,false,false,false,false,true,false,true] (by decide +kernel) (by decide +kernel)
  have w53939:(3:ZMod 475572827297)^((475572827297-1)/53939)≠1:=
    ne_one [false,false,false,false,false,true,true,true,false,false,false,true,false,false,false,true,false,true,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (475572827297-1)=2*(2*(2*(2*(2*(7*(7*(5623*(53939)))))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5623:=(Nat.prime_dvd_prime_iff_eq hp prime5623).mp leaf; rw [eqn]; exact w5623
  have eqn:q=53939:=(Nat.prime_dvd_prime_iff_eq hp prime53939).mp hd; rw [eqn]; exact w53939
theorem prime1066453394851127806157447 : Nat.Prime 1066453394851127806157447 := by
  apply lucas_primality 1066453394851127806157447 (5:ZMod 1066453394851127806157447)
  · exact eq_one [false,true,true,false,false,false,false,true,false,true,false,false,false,true,true,false,false,false,false,false,false,false,true,false,false,true,true,false,true,true,true,false,false,true,false,true,true,false,true,true,false,false,false,false,true,true,false,true,true,true,false,true,false,true,true,true,true,false,true,true,false,false,false,true,false,false,true,false,true,false,true,true,true,false,false,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 1066453394851127806157447)^((1066453394851127806157447-1)/2)≠1:=
    ne_one [true,true,false,false,false,false,true,false,true,false,false,false,true,true,false,false,false,false,false,false,false,true,false,false,true,true,false,true,true,true,false,false,true,false,true,true,false,true,true,false,false,false,false,true,true,false,true,true,true,false,true,false,true,true,true,true,false,true,true,false,false,false,true,false,false,true,false,true,false,true,true,true,false,false,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w7:(5:ZMod 1066453394851127806157447)^((1066453394851127806157447-1)/7)≠1:=
    ne_one [false,true,false,true,false,false,true,true,true,true,false,true,true,true,true,false,true,true,false,true,true,false,false,true,false,true,true,true,true,true,true,false,true,false,false,false,true,true,false,true,false,false,true,false,true,true,true,true,true,true,false,false,true,true,false,true,true,true,true,true,false,true,true,true,false,true,false,false,false,false,true,false,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w3727:(5:ZMod 1066453394851127806157447)^((1066453394851127806157447-1)/3727)≠1:=
    ne_one [false,true,false,true,true,false,false,false,false,false,false,true,true,false,false,true,false,true,true,false,false,false,true,true,true,false,true,false,false,true,false,true,true,true,false,false,false,false,true,false,false,false,false,true,false,true,false,true,false,true,true,false,false,false,false,false,true,true,false,false,false,false,false,true,true,true,true,true] (by decide +kernel) (by decide +kernel)
  have w42977131:(5:ZMod 1066453394851127806157447)^((1066453394851127806157447-1)/42977131)≠1:=
    ne_one [false,true,false,false,true,false,false,false,true,true,true,false,true,false,true,false,true,false,true,true,true,false,true,true,false,false,true,true,false,false,true,true,true,false,false,true,true,false,false,true,false,false,false,true,false,true,false,false,false,false,false,true,true,false,true] (by decide +kernel) (by decide +kernel)
  have w475572827297:(5:ZMod 1066453394851127806157447)^((1066453394851127806157447-1)/475572827297)≠1:=
    ne_one [false,true,true,false,false,false,true,true,false,true,true,true,false,true,true,false,true,true,false,false,true,false,false,false,true,false,true,true,true,false,false,false,false,true,false,true,false,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  rw [show (1066453394851127806157447-1)=2*(7*(3727*(42977131*(475572827297)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w7
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3727:=(Nat.prime_dvd_prime_iff_eq hp prime3727).mp leaf; rw [eqn]; exact w3727
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=42977131:=(Nat.prime_dvd_prime_iff_eq hp prime42977131).mp leaf; rw [eqn]; exact w42977131
  have eqn:q=475572827297:=(Nat.prime_dvd_prime_iff_eq hp prime475572827297).mp hd; rw [eqn]; exact w475572827297
theorem prime1111291616798088557784792601957076174026774057 : Nat.Prime 1111291616798088557784792601957076174026774057 := by
  apply lucas_primality 1111291616798088557784792601957076174026774057 (5:ZMod 1111291616798088557784792601957076174026774057)
  · exact eq_one [false,false,false,true,false,true,false,false,false,true,true,false,true,false,false,false,true,true,true,true,true,false,false,true,false,false,false,false,true,true,false,false,false,true,true,false,true,false,false,true,true,true,false,true,true,true,true,false,true,false,false,false,true,true,true,false,true,true,false,false,false,false,false,false,false,true,false,true,true,true,false,true,false,true,true,true,false,false,false,true,false,false,false,true,true,false,true,false,true,false,false,true,false,false,false,true,false,true,true,true,true,false,true,false,true,true,false,true,false,false,true,true,true,false,true,true,false,false,true,false,true,true,false,true,false,false,false,true,false,false,false,false,false,false,false,false,true,false,true,false,true,false,true,true,true,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  intro q hp hd
  have w2:(5:ZMod 1111291616798088557784792601957076174026774057)^((1111291616798088557784792601957076174026774057-1)/2)≠1:=
    ne_one [false,false,true,false,true,false,false,false,true,true,false,true,false,false,false,true,true,true,true,true,false,false,true,false,false,false,false,true,true,false,false,false,true,true,false,true,false,false,true,true,true,false,true,true,true,true,false,true,false,false,false,true,true,true,false,true,true,false,false,false,false,false,false,false,true,false,true,true,true,false,true,false,true,true,true,false,false,false,true,false,false,false,true,true,false,true,false,true,false,false,true,false,false,false,true,false,true,true,true,true,false,true,false,true,true,false,true,false,false,true,true,true,false,true,true,false,false,true,false,true,true,false,true,false,false,false,true,false,false,false,false,false,false,false,false,true,false,true,false,true,false,true,true,true,false,false,false,true,true] (by decide +kernel) (by decide +kernel)
  have w3:(5:ZMod 1111291616798088557784792601957076174026774057)^((1111291616798088557784792601957076174026774057-1)/3)≠1:=
    ne_one [false,false,false,true,true,true,false,true,false,false,true,true,true,false,true,false,false,true,false,true,false,false,false,true,true,false,true,false,false,true,true,false,true,true,true,false,false,false,false,true,false,true,true,true,true,true,true,false,false,false,false,false,true,false,true,true,true,true,false,true,false,true,false,true,false,false,false,true,false,true,true,true,false,false,true,false,false,false,false,true,true,false,true,true,true,false,false,false,true,true,false,false,false,false,false,true,true,true,true,true,true,false,false,false,true,false,false,true,true,false,false,true,false,false,true,false,false,false,true,true,true,true,false,false,false,false,false,true,true,false,true,false,true,false,true,false,false,false,true,true,true,false,false,true,false,false,false,false,true] (by decide +kernel) (by decide +kernel)
  have w1783:(5:ZMod 1111291616798088557784792601957076174026774057)^((1111291616798088557784792601957076174026774057-1)/1783)≠1:=
    ne_one [false,false,false,true,true,false,false,false,true,false,false,true,false,false,true,false,false,true,true,true,false,true,true,true,true,true,false,false,true,true,false,true,true,true,true,false,true,false,false,true,true,false,true,true,true,true,false,true,true,true,true,true,true,true,false,true,false,false,true,false,true,false,false,true,false,true,false,false,false,false,true,false,true,false,false,true,true,true,true,false,false,false,true,false,true,false,true,false,true,true,false,true,false,true,true,false,true,false,true,false,false,true,true,false,true,true,true,true,true,true,true,true,true,false,true,true,true,true,false,true,false,false,false,false,false,true,false,true,true,true,true,false,false,true,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  have w24351379685416919:(5:ZMod 1111291616798088557784792601957076174026774057)^((1111291616798088557784792601957076174026774057-1)/24351379685416919)≠1:=
    ne_one [false,false,false,true,true,false,false,false,false,true,true,false,true,true,true,false,true,false,true,false,true,false,true,false,false,true,false,true,true,true,true,false,false,true,true,false,false,false,true,false,true,false,true,false,false,true,false,false,false,true,false,false,true,true,false,false,true,false,true,true,false,true,true,true,false,true,false,true,false,false,true,true,true,false,false,false,true,true,true,true,false,false,true,false,true,true,true,false,true,true,false,false,true,false,false,true] (by decide +kernel) (by decide +kernel)
  have w1066453394851127806157447:(5:ZMod 1111291616798088557784792601957076174026774057)^((1111291616798088557784792601957076174026774057-1)/1066453394851127806157447)≠1:=
    ne_one [false,false,false,true,true,false,false,true,false,true,false,true,true,true,false,false,false,true,true,true,true,false,true,true,true,false,true,false,true,true,false,false,false,true,true,false,true,false,true,true,false,true,false,false,true,false,true,true,false,false,true,false,false,false,true,false,true,false,true,true,true,true,true,false,false,false,false,true,true,true] (by decide +kernel) (by decide +kernel)
  rw [show (1111291616798088557784792601957076174026774057-1)=2*(2*(2*(3*(1783*(24351379685416919*(1066453394851127806157447)))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w2
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; exact w3
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=1783:=(Nat.prime_dvd_prime_iff_eq hp prime1783).mp leaf; rw [eqn]; exact w1783
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=24351379685416919:=(Nat.prime_dvd_prime_iff_eq hp prime24351379685416919).mp leaf; rw [eqn]; exact w24351379685416919
  have eqn:q=1066453394851127806157447:=(Nat.prime_dvd_prime_iff_eq hp prime1066453394851127806157447).mp hd; rw [eqn]; exact w1066453394851127806157447
theorem numerator98: (bernoulli 98).num.natAbs=67908260672905495624051117546403605607342195728504487509073961249992947058239:=by
  have eqn:=sound (j:=98) 10014646650599190067509233131649940057366334653200433090 data checked (by decide)
  rw [show coeff data 98=113346205882654953802504338169975769269780623784297224139961517195675177037956361977415712746710315338850091264087783952192708788085 by decide +kernel] at eqn
  have value:bernoulli 98=(67908260672905495624051117546403605607342195728504487509073961249992947058239:ℚ)/6:=by push_cast at eqn; linarith
  rw [value]; norm_num
theorem factors98 {q:ℕ} (hp:q.Prime) (hd:q∣67908260672905495624051117546403605607342195728504487509073961249992947058239) : q=7 ∨ q=2857 ∨ q=3221 ∨ q=1671211 ∨ q=9215789693276607167 ∨ q=9778263152874996218584617307180549616435599 := by
  rw [show 67908260672905495624051117546403605607342195728504487509073961249992947058239=7*(7*(2857*(3221*(1671211*(9215789693276607167*(9778263152874996218584617307180549616435599)))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=7:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=2857:=(Nat.prime_dvd_prime_iff_eq hp prime2857).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=3221:=(Nat.prime_dvd_prime_iff_eq hp prime3221).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=1671211:=(Nat.prime_dvd_prime_iff_eq hp prime1671211).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=9215789693276607167:=(Nat.prime_dvd_prime_iff_eq hp prime9215789693276607167).mp leaf; rw [eqn]; decide +kernel
  have eqn:q=9778263152874996218584617307180549616435599:=(Nat.prime_dvd_prime_iff_eq hp prime9778263152874996218584617307180549616435599).mp hd; rw [eqn]; decide +kernel
theorem numerator100: (bernoulli 100).num.natAbs=94598037819122125295227433069493721872702841533066936133385696204311395415197247711:=by
  have eqn:=sound (j:=100) 10014646650599190067509233131649940057366334653200433090 data checked (by decide)
  rw [show coeff data 100=-28423820059961803261200433506177775727933066053132789771292140255599261312264623677937074637230555414748722783676385793550676465682903 by decide +kernel] at eqn
  have value:bernoulli 100=(-94598037819122125295227433069493721872702841533066936133385696204311395415197247711:ℚ)/33330:=by push_cast at eqn; linarith
  rw [value]; norm_num
theorem factors100 {q:ℕ} (hp:q.Prime) (hd:q∣94598037819122125295227433069493721872702841533066936133385696204311395415197247711) : q=263 ∨ q=379 ∨ q=28717943 ∨ q=65677171692755556482181133 ∨ q=503175397608024323584539371320514986481668897 := by
  rw [show 94598037819122125295227433069493721872702841533066936133385696204311395415197247711=263*(379*(28717943*(65677171692755556482181133*(503175397608024323584539371320514986481668897)))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=263:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=379:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=28717943:=(Nat.prime_dvd_prime_iff_eq hp prime28717943).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=65677171692755556482181133:=(Nat.prime_dvd_prime_iff_eq hp prime65677171692755556482181133).mp leaf; rw [eqn]; decide +kernel
  have eqn:q=503175397608024323584539371320514986481668897:=(Nat.prime_dvd_prime_iff_eq hp prime503175397608024323584539371320514986481668897).mp hd; rw [eqn]; decide +kernel
theorem numerator128: (bernoulli 128).num.natAbs=267754707742548082886954405585282394779291459592551740629978686063357792734863530145362663093519862048495908453718017:=by
  have eqn:=sound (j:=128) 10014646650599190067509233131649940057366334653200433090 data checked (by decide)
  rw [show coeff data 128=-5257781935443282710109671842099799216011506703636779480760202994514097527257300203221424968018932753846323276406084750625891518818056066351576979515633902159370441443103 by decide +kernel] at eqn
  have value:bernoulli 128=(-267754707742548082886954405585282394779291459592551740629978686063357792734863530145362663093519862048495908453718017:ℚ)/510:=by push_cast at eqn; linarith
  rw [value]; norm_num
theorem factors128 {q:ℕ} (hp:q.Prime) (hd:q∣267754707742548082886954405585282394779291459592551740629978686063357792734863530145362663093519862048495908453718017) : q=35089 ∨ q=5953097 ∨ q=12349588663 ∨ q=13349390911530343 ∨ q=6996505560116602097773394576621473 ∨ q=1111291616798088557784792601957076174026774057 := by
  rw [show 267754707742548082886954405585282394779291459592551740629978686063357792734863530145362663093519862048495908453718017=35089*(5953097*(12349588663*(13349390911530343*(6996505560116602097773394576621473*(1111291616798088557784792601957076174026774057))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=35089:=(Nat.prime_dvd_prime_iff_eq hp prime35089).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=5953097:=(Nat.prime_dvd_prime_iff_eq hp prime5953097).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=12349588663:=(Nat.prime_dvd_prime_iff_eq hp prime12349588663).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=13349390911530343:=(Nat.prime_dvd_prime_iff_eq hp prime13349390911530343).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=6996505560116602097773394576621473:=(Nat.prime_dvd_prime_iff_eq hp prime6996505560116602097773394576621473).mp leaf; rw [eqn]; decide +kernel
  have eqn:q=1111291616798088557784792601957076174026774057:=(Nat.prime_dvd_prime_iff_eq hp prime1111291616798088557784792601957076174026774057).mp hd; rw [eqn]; decide +kernel
theorem numerator146: (bernoulli 146).num.natAbs=4120570026280114871526113315907864026165545608808541153973817680034790262683524284855810008621905238290240143481403022987037271683989824863:=by
  have eqn:=sound (j:=146) 10014646650599190067509233131649940057366334653200433090 data checked (by decide)
  rw [show coeff data 146=6877675468707594831994579279330001517772020211598983166958349796530148461830277941917297508461903727908902982402670551583624288828136365394275748542851911451112042777488714274418243610808319445 by decide +kernel] at eqn
  have value:bernoulli 146=(4120570026280114871526113315907864026165545608808541153973817680034790262683524284855810008621905238290240143481403022987037271683989824863:ℚ)/6:=by push_cast at eqn; linarith
  rw [value]; norm_num
theorem factors146 {q:ℕ} (hp:q.Prime) (hd:q∣4120570026280114871526113315907864026165545608808541153973817680034790262683524284855810008621905238290240143481403022987037271683989824863) : q=73 ∨ q=1377371 ∨ q=22639970526343 ∨ q=6726159702783854797 ∨ q=37996324998547740539691528067877 ∨ q=1754821172656266926966923716442469 ∨ q=4036138055144761320534304068715607 := by
  rw [show 4120570026280114871526113315907864026165545608808541153973817680034790262683524284855810008621905238290240143481403022987037271683989824863=73*(1377371*(22639970526343*(6726159702783854797*(37996324998547740539691528067877*(1754821172656266926966923716442469*(4036138055144761320534304068715607)))))) by decide +kernel] at hd
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=73:=(Nat.prime_dvd_prime_iff_eq hp (by decide +kernel)).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=1377371:=(Nat.prime_dvd_prime_iff_eq hp prime1377371).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=22639970526343:=(Nat.prime_dvd_prime_iff_eq hp prime22639970526343).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=6726159702783854797:=(Nat.prime_dvd_prime_iff_eq hp prime6726159702783854797).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=37996324998547740539691528067877:=(Nat.prime_dvd_prime_iff_eq hp prime37996324998547740539691528067877).mp leaf; rw [eqn]; decide +kernel
  rcases hp.dvd_mul.mp hd with leaf|hd
  · have eqn:q=1754821172656266926966923716442469:=(Nat.prime_dvd_prime_iff_eq hp prime1754821172656266926966923716442469).mp leaf; rw [eqn]; decide +kernel
  have eqn:q=4036138055144761320534304068715607:=(Nat.prime_dvd_prime_iff_eq hp prime4036138055144761320534304068715607).mp hd; rw [eqn]; decide +kernel
end OMA.MediumCubicRows284759
