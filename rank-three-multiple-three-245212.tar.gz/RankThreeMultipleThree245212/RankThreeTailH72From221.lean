import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b72_221_0 : every 221 222 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_221_1 : every 224 62 (quick 72 1666 195 864 223)=true := by decide +kernel
private theorem b72_221_2 : every 1 25 (far 72 1666 195 864 223 224 14)=true := by decide +kernel
private theorem b72_221_3 : every 26 50 (far 72 1666 195 864 223 224 14)=true := by decide +kernel
private theorem b72_221_4 : every 51 53 (far 72 1666 195 864 223 224 14)=true := by decide +kernel
private theorem r72_223 : every 223 223 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 223=true := by change (every 224 62 (quick 72 1666 195 864 223) && every 1 53 (far 72 1666 195 864 223 224 14))=true; rw [Bool.and_eq_true]; exact ⟨b72_221_1,(joinEvery b72_221_2 (joinEvery b72_221_3 b72_221_4))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=223 by omega] using yes
private theorem b72_221_5 : every 224 226 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_221_6 : every 228 62 (quick 72 1666 195 864 227)=true := by decide +kernel
private theorem b72_221_7 : every 1 25 (far 72 1666 195 864 227 228 14)=true := by decide +kernel
private theorem b72_221_8 : every 26 50 (far 72 1666 195 864 227 228 14)=true := by decide +kernel
private theorem b72_221_9 : every 51 54 (far 72 1666 195 864 227 228 14)=true := by decide +kernel
private theorem r72_227 : every 227 227 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 227=true := by change (every 228 62 (quick 72 1666 195 864 227) && every 1 54 (far 72 1666 195 864 227 228 14))=true; rw [Bool.and_eq_true]; exact ⟨b72_221_6,(joinEvery b72_221_7 (joinEvery b72_221_8 b72_221_9))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=227 by omega] using yes
private theorem b72_221_10 : every 228 228 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_221_11 : every 230 62 (quick 72 1666 195 864 229)=true := by decide +kernel
private theorem b72_221_12 : every 1 25 (far 72 1666 195 864 229 230 14)=true := by decide +kernel
private theorem b72_221_13 : every 26 50 (far 72 1666 195 864 229 230 14)=true := by decide +kernel
private theorem b72_221_14 : every 51 55 (far 72 1666 195 864 229 230 14)=true := by decide +kernel
private theorem r72_229 : every 229 229 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 229=true := by change (every 230 62 (quick 72 1666 195 864 229) && every 1 55 (far 72 1666 195 864 229 230 14))=true; rw [Bool.and_eq_true]; exact ⟨b72_221_11,(joinEvery b72_221_12 (joinEvery b72_221_13 b72_221_14))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=229 by omega] using yes
private theorem b72_221_15 : every 230 232 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_221_16 : every 234 62 (quick 72 1666 195 864 233)=true := by decide +kernel
private theorem b72_221_17 : every 1 25 (far 72 1666 195 864 233 234 14)=true := by decide +kernel
private theorem b72_221_18 : every 26 50 (far 72 1666 195 864 233 234 14)=true := by decide +kernel
private theorem b72_221_19 : every 51 56 (far 72 1666 195 864 233 234 14)=true := by decide +kernel
private theorem r72_233 : every 233 233 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 233=true := by change (every 234 62 (quick 72 1666 195 864 233) && every 1 56 (far 72 1666 195 864 233 234 14))=true; rw [Bool.and_eq_true]; exact ⟨b72_221_16,(joinEvery b72_221_17 (joinEvery b72_221_18 b72_221_19))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=233 by omega] using yes
private theorem b72_221_20 : every 234 238 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_221_21 : every 240 61 (quick 72 1666 195 864 239)=true := by decide +kernel
private theorem b72_221_22 : every 1 25 (far 72 1666 195 864 239 240 14)=true := by decide +kernel
private theorem b72_221_23 : every 26 50 (far 72 1666 195 864 239 240 14)=true := by decide +kernel
private theorem b72_221_24 : every 51 57 (far 72 1666 195 864 239 240 14)=true := by decide +kernel
private theorem r72_239 : every 239 239 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 239=true := by change (every 240 61 (quick 72 1666 195 864 239) && every 1 57 (far 72 1666 195 864 239 240 14))=true; rw [Bool.and_eq_true]; exact ⟨b72_221_21,(joinEvery b72_221_22 (joinEvery b72_221_23 b72_221_24))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=239 by omega] using yes
private theorem b72_221_25 : every 240 240 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_221_26 : every 242 61 (quick 72 1666 195 864 241)=true := by decide +kernel
private theorem b72_221_27 : every 1 25 (far 72 1666 195 864 241 242 14)=true := by decide +kernel
private theorem b72_221_28 : every 26 50 (far 72 1666 195 864 241 242 14)=true := by decide +kernel
private theorem b72_221_29 : every 51 58 (far 72 1666 195 864 241 242 14)=true := by decide +kernel
private theorem r72_241 : every 241 241 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 241=true := by change (every 242 61 (quick 72 1666 195 864 241) && every 1 58 (far 72 1666 195 864 241 242 14))=true; rw [Bool.and_eq_true]; exact ⟨b72_221_26,(joinEvery b72_221_27 (joinEvery b72_221_28 b72_221_29))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=241 by omega] using yes
private theorem b72_221_30 : every 242 244 (run 72 1666 195 864)=true := by decide +kernel
theorem span72_221_244 : every 221 244 (run 72 1666 195 864)=true := (joinEvery (joinEvery (joinEvery b72_221_0 (joinEvery r72_223 b72_221_5)) (joinEvery r72_227 (joinEvery b72_221_10 r72_229))) (joinEvery (joinEvery b72_221_15 (joinEvery r72_233 b72_221_20)) (joinEvery (joinEvery r72_239 b72_221_25) (joinEvery r72_241 b72_221_30))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span72_221_244
