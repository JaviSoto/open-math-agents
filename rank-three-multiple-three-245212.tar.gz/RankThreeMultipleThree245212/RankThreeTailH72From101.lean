import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b72_101_0 : every 102 75 (quick 72 1666 195 864 101)=true := by decide +kernel
private theorem b72_101_1 : every 1 25 (far 72 1666 195 864 101 102 17)=true := by decide +kernel
private theorem r72_101 : every 101 101 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 101=true := by change (every 102 75 (quick 72 1666 195 864 101) && every 1 25 (far 72 1666 195 864 101 102 17))=true; rw [Bool.and_eq_true]; exact ⟨b72_101_0,b72_101_1⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=101 by omega] using yes
private theorem b72_101_2 : every 102 102 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_101_3 : every 104 74 (quick 72 1666 195 864 103)=true := by decide +kernel
private theorem b72_101_4 : every 1 25 (far 72 1666 195 864 103 104 17)=true := by decide +kernel
private theorem r72_103 : every 103 103 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 103=true := by change (every 104 74 (quick 72 1666 195 864 103) && every 1 25 (far 72 1666 195 864 103 104 17))=true; rw [Bool.and_eq_true]; exact ⟨b72_101_3,b72_101_4⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=103 by omega] using yes
private theorem b72_101_5 : every 104 106 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_101_6 : every 108 73 (quick 72 1666 195 864 107)=true := by decide +kernel
private theorem b72_101_7 : every 1 25 (far 72 1666 195 864 107 108 16)=true := by decide +kernel
private theorem b72_101_8 : every 26 26 (far 72 1666 195 864 107 108 16)=true := by decide +kernel
private theorem r72_107 : every 107 107 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 107=true := by change (every 108 73 (quick 72 1666 195 864 107) && every 1 26 (far 72 1666 195 864 107 108 16))=true; rw [Bool.and_eq_true]; exact ⟨b72_101_6,(joinEvery b72_101_7 b72_101_8)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=107 by omega] using yes
private theorem b72_101_9 : every 108 108 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_101_10 : every 110 73 (quick 72 1666 195 864 109)=true := by decide +kernel
private theorem b72_101_11 : every 1 25 (far 72 1666 195 864 109 110 16)=true := by decide +kernel
private theorem b72_101_12 : every 26 27 (far 72 1666 195 864 109 110 16)=true := by decide +kernel
private theorem r72_109 : every 109 109 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 109=true := by change (every 110 73 (quick 72 1666 195 864 109) && every 1 27 (far 72 1666 195 864 109 110 16))=true; rw [Bool.and_eq_true]; exact ⟨b72_101_10,(joinEvery b72_101_11 b72_101_12)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=109 by omega] using yes
private theorem b72_101_13 : every 110 112 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_101_14 : every 114 72 (quick 72 1666 195 864 113)=true := by decide +kernel
private theorem b72_101_15 : every 1 25 (far 72 1666 195 864 113 114 16)=true := by decide +kernel
private theorem b72_101_16 : every 26 28 (far 72 1666 195 864 113 114 16)=true := by decide +kernel
private theorem r72_113 : every 113 113 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 113=true := by change (every 114 72 (quick 72 1666 195 864 113) && every 1 28 (far 72 1666 195 864 113 114 16))=true; rw [Bool.and_eq_true]; exact ⟨b72_101_14,(joinEvery b72_101_15 b72_101_16)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=113 by omega] using yes
private theorem b72_101_17 : every 114 124 (run 72 1666 195 864)=true := by decide +kernel
theorem span72_101_124 : every 101 124 (run 72 1666 195 864)=true := (joinEvery (joinEvery (joinEvery r72_101 b72_101_2) (joinEvery r72_103 (joinEvery b72_101_5 r72_107))) (joinEvery (joinEvery b72_101_9 r72_109) (joinEvery b72_101_13 (joinEvery r72_113 b72_101_17))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span72_101_124
