import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E9P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 14 22 (finitePair 39366 1402415 88572 787320 13)=true := by decide +kernel
private theorem b1 : every 23 28 (finitePair 39366 1402415 88572 787320 13)=true := by decide +kernel
theorem checked : test 3 9 13=true :=
  fixedTest (h:=39366) (A:=1402415) (S:=88572) (T:=787320)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery b0 b1)
#print axioms checked
end OMA.RankThreeAt3E9P13
