import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E7P11
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 12 18 (finitePair 4374 123020 9840 69984 11)=true := by decide +kernel
private theorem b1 : every 19 28 (finitePair 4374 123020 9840 69984 11)=true := by decide +kernel
private theorem b2 : every 29 30 (finitePair 4374 123020 9840 69984 11)=true := by decide +kernel
theorem checked : test 3 7 11=true :=
  fixedTest (h:=4374) (A:=123020) (S:=9840) (T:=69984)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery b0 (joinEvery b1 b2))
#print axioms checked
end OMA.RankThreeAt3E7P11
