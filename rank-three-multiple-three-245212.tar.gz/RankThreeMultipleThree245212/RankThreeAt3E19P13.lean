import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E19P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 14 28 (finitePair 2324522934 169980739550 5230176600 92980917360 13)=true := by decide +kernel
private theorem b1 : every 29 36 (finitePair 2324522934 169980739550 5230176600 92980917360 13)=true := by decide +kernel
private theorem b2 : every 37 42 (finitePair 2324522934 169980739550 5230176600 92980917360 13)=true := by decide +kernel
private theorem b3 : every 43 46 (finitePair 2324522934 169980739550 5230176600 92980917360 13)=true := by decide +kernel
private theorem b4 : every 47 52 (finitePair 2324522934 169980739550 5230176600 92980917360 13)=true := by decide +kernel
private theorem b5 : every 53 58 (finitePair 2324522934 169980739550 5230176600 92980917360 13)=true := by decide +kernel
private theorem b6 : every 59 60 (finitePair 2324522934 169980739550 5230176600 92980917360 13)=true := by decide +kernel
private theorem b7 : every 61 66 (finitePair 2324522934 169980739550 5230176600 92980917360 13)=true := by decide +kernel
private theorem b8 : every 67 70 (finitePair 2324522934 169980739550 5230176600 92980917360 13)=true := by decide +kernel
private theorem b9 : every 71 72 (finitePair 2324522934 169980739550 5230176600 92980917360 13)=true := by decide +kernel
private theorem b10 : every 73 78 (finitePair 2324522934 169980739550 5230176600 92980917360 13)=true := by decide +kernel
private theorem b11 : every 79 82 (finitePair 2324522934 169980739550 5230176600 92980917360 13)=true := by decide +kernel
private theorem b12 : every 83 88 (finitePair 2324522934 169980739550 5230176600 92980917360 13)=true := by decide +kernel
private theorem b13 : every 89 96 (finitePair 2324522934 169980739550 5230176600 92980917360 13)=true := by decide +kernel
private theorem b14 : every 97 100 (finitePair 2324522934 169980739550 5230176600 92980917360 13)=true := by decide +kernel
private theorem b15 : every 101 102 (finitePair 2324522934 169980739550 5230176600 92980917360 13)=true := by decide +kernel
theorem checked : test 3 19 13=true :=
  fixedTest (h:=2324522934) (A:=169980739550) (S:=5230176600) (T:=92980917360)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 b3)) (joinEvery (joinEvery b4 b5) (joinEvery b6 b7))) (joinEvery (joinEvery (joinEvery b8 b9) (joinEvery b10 b11)) (joinEvery (joinEvery b12 b13) (joinEvery b14 b15))))
#print axioms checked
end OMA.RankThreeAt3E19P13
