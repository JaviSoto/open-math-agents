import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt5E2P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 8 (movingRow 430 93 300 3)=true := by decide +kernel
private theorem b1 : every 9 9 (movingRow 430 93 300 3)=true := by decide +kernel
theorem checked : test 5 2 3=true :=
  movingTest (h:=50) (A:=430) (S:=93) (T:=300)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery b0 b1)
#print axioms checked
end OMA.RankThreeAt5E2P3
