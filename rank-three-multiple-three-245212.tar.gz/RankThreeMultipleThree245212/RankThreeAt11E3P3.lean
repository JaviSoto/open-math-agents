import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt11E3P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 5 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b1 : every 6 10 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b2 : every 11 15 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b3 : every 16 20 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b4 : every 21 25 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b5 : every 26 29 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b6 : every 30 33 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b7 : every 34 37 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b8 : every 38 41 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b9 : every 42 45 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b10 : every 46 49 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b11 : every 50 53 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b12 : every 54 56 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b13 : every 57 59 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b14 : every 60 62 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b15 : every 63 65 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b16 : every 66 68 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b17 : every 69 71 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b18 : every 72 74 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b19 : every 75 77 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b20 : every 78 80 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b21 : every 81 83 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b22 : every 84 86 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b23 : every 87 90 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b24 : every 91 91 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b25 : every 92 92 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b26 : every 93 93 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b27 : every 94 94 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b28 : every 95 95 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b29 : every 96 96 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b30 : every 97 97 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b31 : every 98 98 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b32 : every 99 99 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b33 : every 100 100 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b34 : every 101 101 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b35 : every 102 102 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b36 : every 103 103 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b37 : every 104 104 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b38 : every 105 105 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b39 : every 106 106 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b40 : every 107 107 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b41 : every 108 108 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b42 : every 109 109 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b43 : every 110 110 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b44 : every 111 111 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b45 : every 112 112 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b46 : every 113 113 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b47 : every 114 114 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b48 : every 115 115 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b49 : every 116 116 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b50 : every 117 117 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b51 : every 118 118 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b52 : every 119 119 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b53 : every 120 120 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b54 : every 121 121 (movingRow 28550 4392 21296 3)=true := by decide +kernel
private theorem b55 : every 122 122 (movingRow 28550 4392 21296 3)=true := by decide +kernel
theorem checked : test 11 3 3=true :=
  movingTest (h:=2662) (A:=28550) (S:=4392) (T:=21296)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 (joinEvery b1 b2)) (joinEvery (joinEvery b3 b4) (joinEvery b5 b6))) (joinEvery (joinEvery b7 (joinEvery b8 b9)) (joinEvery (joinEvery b10 b11) (joinEvery b12 b13)))) (joinEvery (joinEvery (joinEvery b14 (joinEvery b15 b16)) (joinEvery (joinEvery b17 b18) (joinEvery b19 b20))) (joinEvery (joinEvery b21 (joinEvery b22 b23)) (joinEvery (joinEvery b24 b25) (joinEvery b26 b27))))) (joinEvery (joinEvery (joinEvery (joinEvery b28 (joinEvery b29 b30)) (joinEvery (joinEvery b31 b32) (joinEvery b33 b34))) (joinEvery (joinEvery b35 (joinEvery b36 b37)) (joinEvery (joinEvery b38 b39) (joinEvery b40 b41)))) (joinEvery (joinEvery (joinEvery b42 (joinEvery b43 b44)) (joinEvery (joinEvery b45 b46) (joinEvery b47 b48))) (joinEvery (joinEvery b49 (joinEvery b50 b51)) (joinEvery (joinEvery b52 b53) (joinEvery b54 b55))))))
#print axioms checked
end OMA.RankThreeAt11E3P3
