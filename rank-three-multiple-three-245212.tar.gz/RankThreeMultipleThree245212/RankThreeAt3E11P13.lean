import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E11P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 14 22 (finitePair 354294 15278930 797160 8503056 13)=true := by decide +kernel
private theorem b1 : every 23 30 (finitePair 354294 15278930 797160 8503056 13)=true := by decide +kernel
private theorem b2 : every 31 37 (finitePair 354294 15278930 797160 8503056 13)=true := by decide +kernel
theorem checked : test 3 11 13=true :=
  fixedTest (h:=354294) (A:=15278930) (S:=797160) (T:=8503056)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery b0 (joinEvery b1 b2))
#print axioms checked
end OMA.RankThreeAt3E11P13
