import RankThreeFourSmallCompact245212
import BalanceOrders245212

/-! For the 4·3^7 cofactor, the exact dyadic balance excludes every
complementary divisor count below 30; the first free prime is at most 964. -/
namespace OMA.RankThreeFourSmallOrder245212
open Nat Finset ArithmeticFunction OMA.Smooth245212 OMA.ExactSigma245212
open OMA.RankThreeFourSmallHarmonic245212
open scoped ArithmeticFunction.sigma

open OMA.CofactorEulerPair245212
open private OMA.CofactorEulerPair245212.checked from CofactorEulerDecision245212

private theorem check : every 1 29 (fun b=>every 1 29 (fun d=>decide (
    (b+1)*(d+1)<15 ∨ 30≤(b+1)*(d+1) ∨ OMA.WeightVal245212.val (b+2)+OMA.WeightVal245212.val (d+2)<4 ∨
    b%2=0 ∧ d%2=0 ∧ OMA.WeightVal245212.val (b+2)+OMA.WeightVal245212.val (d+2)≠4)))=true := by decide +kernel

theorem first {p q b d : ℕ} (hp : p.Prime) (hq : q.Prime) (lo : 5≤p) (pq : p<q)
    (bp : 0<b) (dp : 0<d)
    (eqn : OeisA245212.a (4*3^7*p^b*q^d)=(σ 1 (4*3^7*p^b*q^d):ℤ)) : p≤964 := by
  let ps : Fin 3→ℕ:=![3,p,q]
  let es : Fin 3→ℕ:=![7,b,d]
  have pr : ∀ i,(ps i).Prime := by intro i;fin_cases i <;> first | exact hp | exact hq | exact (by decide : Nat.Prime 3)
  have odd : ∀ i,Odd (ps i) := by intro i;fin_cases i <;> first | exact hp.odd_of_ne_two (by omega) | exact hq.odd_of_ne_two (by omega) | exact (by decide : Odd 3)
  have inj : Function.Injective ps := by
    intro i j h;fin_cases i <;> fin_cases j <;> simp [ps] at * <;> omega
  have te : total ps es=3^7*p^b*q^d := by simp [total,ps,es,Fin.prod_univ_succ,mul_assoc]
  have eq : OeisA245212.a (2^2*total ps es)=(σ 1 (2^2*total ps es):ℤ) := by
    simpa only [te,show 2^2=4 by decide,←mul_assoc] using eqn
  have tri:=OMA.BalanceOrders245212.trichotomy ps es pr odd inj 2 eq
  let E:=OMA.WeightVal245212.val (b+2)+OMA.WeightVal245212.val (d+2)
  let U:=1+surplus p b+surplus q d
  have tri' : (U<3 → E=3+U) ∧ (3<U → E=6) ∧ (U=3 → 6<E) := by
    simpa [ps,es,E,U,Fin.sum_univ_succ,add_assoc,show OMA.WeightVal245212.val (7+2)=0 by decide +kernel,
      show OMA.WeightVal245212.val (2+1)=0 by decide +kernel,show surplus 3 7=1 by decide +kernel] using tri
  have E4 : 4≤E := by
    have pos : 0<U := by dsimp [U];omega
    rcases lt_trichotomy U 3 with lt|e|gt
    · have := tri'.1 lt;omega
    · have := tri'.2.2 e;omega
    · have := tri'.2.1 gt;omega
  have both (be : Even b) (de : Even d) : E=4 := by
    have nb : ¬Odd b := by rintro ⟨i,hi⟩;obtain ⟨j,hj⟩:=be;omega
    have nd : ¬Odd d := by rintro ⟨i,hi⟩;obtain ⟨j,hj⟩:=de;omega
    have u1 : U=1 := by simp [U,surplus,nb,nd]
    exact (tri'.1 (by omega)).trans (by omega)
  have hh : 0<8748 := by decide
  have cop (r : ℕ) (hr : r.Prime) (r5 : 5≤r) : (8748:ℕ).Coprime r := by
    change (2^2*3^7).Coprime r
    exact (((coprime_primes prime_two hr).mpr (by omega)).pow_left 2).mul_left
      (((coprime_primes (by decide : Nat.Prime 3) hr).mpr (by omega)).pow_left 7)
  obtain ⟨slope,cap⟩ := count_cap hh hp hq (cop p hp lo) (cop q hq (by omega)) pq bp dp eqn
  let L:=(b+1)*(d+1)
  have constants : W 8748=418268 ∧ σ 1 8748=22960 ∧ 2*(8748*σ 0 8748)=419904 := by decide +kernel
  rw [constants.1,constants.2.1,constants.2.2] at slope cap
  change 22960<1636*L at slope
  change p*(1636*L-22960)≤2*419904*L at cap
  have lt : 30≤L := by
    by_contra! small
    have bL : b<L := by dsimp [L]; nlinarith
    have dL : d<L := by dsimp [L]; nlinarith
    have re:=of_decide_eq_true (OMA.CofactorEulerPair245212.checked (OMA.CofactorEulerPair245212.checked check bp (by omega)) dp (by omega))
    change L<15 ∨ 30≤L ∨ E<4 ∨ b%2=0 ∧ d%2=0 ∧ E≠4 at re
    rcases re with r|r|r|⟨eb,ed,off⟩ <;> try omega
    exact off (both (Nat.even_iff.mpr eb) (Nat.even_iff.mpr ed))
  by_contra! big
  have rest:=Nat.sub_add_cancel slope.le
  have mult:=Nat.mul_le_mul_right (1636*L-22960) (show 965≤p by omega)
  nlinarith only [cap,mult,rest,lt]


/-- The complementary divisor count is a product of two integers ≥2 and
cannot be five, improving the harmonic first-prime bound on this cofactor. -/
theorem first_six {p q b d : ℕ} (hp : p.Prime) (hq : q.Prime) (lo : 5≤p) (pq : p<q)
    (bp : 0<b) (dp : 0<d)
    (eqn : OeisA245212.a (4*3^6*p^b*q^d)=(σ 1 (4*3^6*p^b*q^d):ℤ)) : p≤678 := by
  have cop (r : ℕ) (hr : r.Prime) (r5 : 5≤r) : (2916:ℕ).Coprime r := by
    change (2^2*3^6).Coprime r
    exact (((coprime_primes prime_two hr).mpr (by omega)).pow_left 2).mul_left
      (((coprime_primes (by decide : Nat.Prime 3) hr).mpr (by omega)).pow_left 6)
  obtain ⟨slope,cap⟩ := count_cap (by decide : 0<2916) hp hq (cop p hp lo) (cop q hq (by omega)) pq bp dp eqn
  let L:=(b+1)*(d+1)
  have constants : W 2916=120836 ∧ σ 1 2916=7651 ∧ 2*(2916*σ 0 2916)=122472 := by decide +kernel
  rw [constants.1,constants.2.1,constants.2.2] at slope cap
  change 7651<1636*L at slope
  change p*(1636*L-7651)≤2*122472*L at cap
  have lt : 6≤L := by
    by_contra! small
    by_cases be : b=1
    · dsimp [L] at *;subst b;omega
    · have := Nat.mul_le_mul (show 3≤b+1 by omega) (show 2≤d+1 by omega)
      omega
  by_contra! big
  have rest:=Nat.sub_add_cancel slope.le
  have mult:=Nat.mul_le_mul_right (1636*L-7651) (show 679≤p by omega)
  nlinarith only [cap,mult,rest,lt]

end OMA.RankThreeFourSmallOrder245212
