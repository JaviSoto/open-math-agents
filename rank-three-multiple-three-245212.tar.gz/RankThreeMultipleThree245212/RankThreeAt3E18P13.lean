import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E18P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 14 28 (finitePair 774840978 53754592850 1743392199 29443957164 13)=true := by decide +kernel
private theorem b1 : every 29 36 (finitePair 774840978 53754592850 1743392199 29443957164 13)=true := by decide +kernel
private theorem b2 : every 37 42 (finitePair 774840978 53754592850 1743392199 29443957164 13)=true := by decide +kernel
private theorem b3 : every 43 46 (finitePair 774840978 53754592850 1743392199 29443957164 13)=true := by decide +kernel
private theorem b4 : every 47 52 (finitePair 774840978 53754592850 1743392199 29443957164 13)=true := by decide +kernel
private theorem b5 : every 53 58 (finitePair 774840978 53754592850 1743392199 29443957164 13)=true := by decide +kernel
private theorem b6 : every 59 60 (finitePair 774840978 53754592850 1743392199 29443957164 13)=true := by decide +kernel
private theorem b7 : every 61 66 (finitePair 774840978 53754592850 1743392199 29443957164 13)=true := by decide +kernel
private theorem b8 : every 67 70 (finitePair 774840978 53754592850 1743392199 29443957164 13)=true := by decide +kernel
private theorem b9 : every 71 72 (finitePair 774840978 53754592850 1743392199 29443957164 13)=true := by decide +kernel
private theorem b10 : every 73 78 (finitePair 774840978 53754592850 1743392199 29443957164 13)=true := by decide +kernel
private theorem b11 : every 79 82 (finitePair 774840978 53754592850 1743392199 29443957164 13)=true := by decide +kernel
private theorem b12 : every 83 88 (finitePair 774840978 53754592850 1743392199 29443957164 13)=true := by decide +kernel
private theorem b13 : every 89 90 (finitePair 774840978 53754592850 1743392199 29443957164 13)=true := by decide +kernel
theorem checked : test 3 18 13=true :=
  fixedTest (h:=774840978) (A:=53754592850) (S:=1743392199) (T:=29443957164)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery b0 (joinEvery b1 b2)) (joinEvery (joinEvery b3 b4) (joinEvery b5 b6))) (joinEvery (joinEvery b7 (joinEvery b8 b9)) (joinEvery (joinEvery b10 b11) (joinEvery b12 b13))))
#print axioms checked
end OMA.RankThreeAt3E18P13
