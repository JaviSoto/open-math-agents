import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_101_0 : every 102 132 (quick 96 2247 252 1152 101)=true := by decide +kernel
private theorem b96_101_1 : every 1 24 (far 96 2247 252 1152 101 133 29)=true := by decide +kernel
private theorem r96_101 : every 101 101 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 101=true := by change (every 102 132 (quick 96 2247 252 1152 101) && every 1 24 (far 96 2247 252 1152 101 133 29))=true; rw [Bool.and_eq_true]; exact ⟨b96_101_0,b96_101_1⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=101 by omega] using yes
private theorem b96_101_2 : every 102 102 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_101_3 : every 104 130 (quick 96 2247 252 1152 103)=true := by decide +kernel
private theorem b96_101_4 : every 1 24 (far 96 2247 252 1152 103 131 28)=true := by decide +kernel
private theorem r96_103 : every 103 103 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 103=true := by change (every 104 130 (quick 96 2247 252 1152 103) && every 1 24 (far 96 2247 252 1152 103 131 28))=true; rw [Bool.and_eq_true]; exact ⟨b96_101_3,b96_101_4⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=103 by omega] using yes
private theorem b96_101_5 : every 104 106 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_101_6 : every 108 127 (quick 96 2247 252 1152 107)=true := by decide +kernel
private theorem b96_101_7 : every 1 25 (far 96 2247 252 1152 107 128 28)=true := by decide +kernel
private theorem r96_107 : every 107 107 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 107=true := by change (every 108 127 (quick 96 2247 252 1152 107) && every 1 25 (far 96 2247 252 1152 107 128 28))=true; rw [Bool.and_eq_true]; exact ⟨b96_101_6,b96_101_7⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=107 by omega] using yes
private theorem b96_101_8 : every 108 108 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_101_9 : every 110 126 (quick 96 2247 252 1152 109)=true := by decide +kernel
private theorem b96_101_10 : every 1 25 (far 96 2247 252 1152 109 127 27)=true := by decide +kernel
private theorem b96_101_11 : every 26 26 (far 96 2247 252 1152 109 127 27)=true := by decide +kernel
private theorem r96_109 : every 109 109 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 109=true := by change (every 110 126 (quick 96 2247 252 1152 109) && every 1 26 (far 96 2247 252 1152 109 127 27))=true; rw [Bool.and_eq_true]; exact ⟨b96_101_9,(joinEvery b96_101_10 b96_101_11)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=109 by omega] using yes
private theorem b96_101_12 : every 110 112 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_101_13 : every 114 123 (quick 96 2247 252 1152 113)=true := by decide +kernel
private theorem b96_101_14 : every 1 25 (far 96 2247 252 1152 113 124 27)=true := by decide +kernel
private theorem b96_101_15 : every 26 27 (far 96 2247 252 1152 113 124 27)=true := by decide +kernel
private theorem r96_113 : every 113 113 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 113=true := by change (every 114 123 (quick 96 2247 252 1152 113) && every 1 27 (far 96 2247 252 1152 113 124 27))=true; rw [Bool.and_eq_true]; exact ⟨b96_101_13,(joinEvery b96_101_14 b96_101_15)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=113 by omega] using yes
private theorem b96_101_16 : every 114 124 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_101_124 : every 101 124 (run 96 2247 252 1152)=true := (joinEvery (joinEvery (joinEvery r96_101 b96_101_2) (joinEvery r96_103 (joinEvery b96_101_5 r96_107))) (joinEvery (joinEvery b96_101_8 r96_109) (joinEvery b96_101_12 (joinEvery r96_113 b96_101_16))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_101_124
