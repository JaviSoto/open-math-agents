import RankThreeFourSmallOriginal245212
/-! Certified prime and exponent intervals for one power of three. -/
namespace OMA.RankThreeFourSmallTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallDecision245212
open OMA.RankThreeFourSmallOriginal245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem c4_0 : every 1 2 (movingRow 9299 847 4860 5)=true := by decide +kernel
private theorem p4_5 : every 5 5 (atPrime 324 9299 847 4860)=true := by
  have localTest : atPrime 324 9299 847 4860 5=true := c4_0
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=5 by omega] using localTest
private theorem c4_1 : every 6 6 (atPrime 324 9299 847 4860)=true := by decide +kernel
private theorem c4_2 : every 1 2 (movingRow 9299 847 4860 7)=true := by decide +kernel
private theorem p4_7 : every 7 7 (atPrime 324 9299 847 4860)=true := by
  have localTest : atPrime 324 9299 847 4860 7=true := c4_2
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=7 by omega] using localTest
private theorem c4_3 : every 8 10 (atPrime 324 9299 847 4860)=true := by decide +kernel
private theorem c4_4 : every 1 3 (movingRow 9299 847 4860 11)=true := by decide +kernel
private theorem p4_11 : every 11 11 (atPrime 324 9299 847 4860)=true := by
  have localTest : atPrime 324 9299 847 4860 11=true := c4_4
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=11 by omega] using localTest
private theorem c4_5 : every 12 12 (atPrime 324 9299 847 4860)=true := by decide +kernel
private theorem c4_6 : every 1 4 (movingRow 9299 847 4860 13)=true := by decide +kernel
private theorem p4_13 : every 13 13 (atPrime 324 9299 847 4860)=true := by
  have localTest : atPrime 324 9299 847 4860 13=true := c4_6
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=13 by omega] using localTest
private theorem c4_7 : every 14 16 (atPrime 324 9299 847 4860)=true := by decide +kernel
private theorem c4_8 : every 1 7 (movingRow 9299 847 4860 17)=true := by decide +kernel
private theorem p4_17 : every 17 17 (atPrime 324 9299 847 4860)=true := by
  have localTest : atPrime 324 9299 847 4860 17=true := c4_8
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=17 by omega] using localTest
private theorem c4_9 : every 18 18 (atPrime 324 9299 847 4860)=true := by decide +kernel
private theorem c4_10 : every 1 10 (movingRow 9299 847 4860 19)=true := by decide +kernel
private theorem p4_19 : every 19 19 (atPrime 324 9299 847 4860)=true := by
  have localTest : atPrime 324 9299 847 4860 19=true := c4_10
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=19 by omega] using localTest
private theorem c4_11 : every 20 22 (atPrime 324 9299 847 4860)=true := by decide +kernel
private theorem c4_12 : every 1 11 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_13 : every 12 16 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_14 : every 17 20 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_15 : every 21 23 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_16 : every 24 26 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_17 : every 27 28 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_18 : every 29 30 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_19 : every 31 32 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_20 : every 33 34 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_21 : every 35 36 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_22 : every 37 38 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_23 : every 39 39 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_24 : every 40 40 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_25 : every 41 41 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_26 : every 42 42 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_27 : every 43 43 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_28 : every 44 44 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_29 : every 45 45 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_30 : every 46 46 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_31 : every 47 47 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_32 : every 48 48 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_33 : every 49 49 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_34 : every 50 50 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_35 : every 51 51 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_36 : every 52 52 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_37 : every 53 53 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_38 : every 54 54 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_39 : every 55 55 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_40 : every 56 56 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_41 : every 57 57 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_42 : every 58 58 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_43 : every 59 59 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_44 : every 60 60 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_45 : every 61 61 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_46 : every 62 62 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_47 : every 63 63 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_48 : every 64 64 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_49 : every 65 65 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_50 : every 66 66 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_51 : every 67 67 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_52 : every 68 68 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_53 : every 69 69 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_54 : every 70 70 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_55 : every 71 71 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_56 : every 72 72 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_57 : every 73 73 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_58 : every 74 74 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_59 : every 75 75 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_60 : every 76 76 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_61 : every 77 77 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_62 : every 78 78 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_63 : every 79 79 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_64 : every 80 80 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_65 : every 81 81 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_66 : every 82 82 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_67 : every 83 83 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_68 : every 84 84 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_69 : every 85 85 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_70 : every 86 86 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_71 : every 87 87 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_72 : every 88 88 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_73 : every 89 89 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_74 : every 90 90 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_75 : every 91 91 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_76 : every 92 92 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_77 : every 93 93 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_78 : every 94 94 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_79 : every 95 95 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_80 : every 96 96 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_81 : every 97 97 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_82 : every 98 98 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_83 : every 99 99 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_84 : every 100 100 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_85 : every 101 101 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_86 : every 102 102 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_87 : every 103 103 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_88 : every 104 104 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_89 : every 105 105 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_90 : every 106 106 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_91 : every 107 107 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_92 : every 108 108 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_93 : every 109 109 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_94 : every 110 110 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_95 : every 111 111 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_96 : every 112 112 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_97 : every 113 113 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_98 : every 114 114 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_99 : every 115 115 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_100 : every 116 116 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_101 : every 117 117 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_102 : every 118 118 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_103 : every 119 119 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_104 : every 120 120 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_105 : every 121 121 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_106 : every 122 122 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_107 : every 123 123 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_108 : every 124 124 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_109 : every 125 125 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_110 : every 126 126 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_111 : every 127 127 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_112 : every 128 128 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_113 : every 129 129 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_114 : every 130 130 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_115 : every 131 131 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_116 : every 132 132 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_117 : every 133 133 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_118 : every 134 134 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_119 : every 135 135 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_120 : every 136 136 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_121 : every 137 137 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_122 : every 138 138 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_123 : every 139 139 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_124 : every 140 140 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_125 : every 141 141 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_126 : every 142 142 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_127 : every 143 143 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_128 : every 144 144 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_129 : every 145 145 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_130 : every 146 146 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_131 : every 147 147 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_132 : every 148 148 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_133 : every 149 149 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_134 : every 150 150 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_135 : every 151 151 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_136 : every 152 152 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_137 : every 153 153 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_138 : every 154 154 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_139 : every 155 155 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_140 : every 156 156 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_141 : every 157 157 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_142 : every 158 158 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_143 : every 159 159 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_144 : every 160 160 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_145 : every 161 161 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_146 : every 162 162 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_147 : every 163 163 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_148 : every 164 164 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_149 : every 165 165 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_150 : every 166 166 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_151 : every 167 167 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_152 : every 168 168 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_153 : every 169 169 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_154 : every 170 170 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_155 : every 171 171 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_156 : every 172 172 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_157 : every 173 173 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_158 : every 174 174 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_159 : every 175 175 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_160 : every 176 176 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_161 : every 177 177 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_162 : every 178 178 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_163 : every 179 179 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_164 : every 180 180 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_165 : every 181 181 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_166 : every 182 182 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_167 : every 183 183 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_168 : every 184 184 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_169 : every 185 185 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_170 : every 186 186 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_171 : every 187 187 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_172 : every 188 188 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_173 : every 189 189 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_174 : every 190 190 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_175 : every 191 191 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_176 : every 192 192 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_177 : every 193 193 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_178 : every 194 194 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_179 : every 195 195 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_180 : every 196 196 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_181 : every 197 197 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_182 : every 198 198 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_183 : every 199 199 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_184 : every 200 200 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_185 : every 201 201 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_186 : every 202 202 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_187 : every 203 203 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_188 : every 204 204 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_189 : every 205 205 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_190 : every 206 206 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_191 : every 207 207 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_192 : every 208 208 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_193 : every 209 209 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_194 : every 210 210 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_195 : every 211 211 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_196 : every 212 212 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_197 : every 213 213 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_198 : every 214 214 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_199 : every 215 215 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_200 : every 216 216 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_201 : every 217 217 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_202 : every 218 218 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_203 : every 219 219 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_204 : every 220 220 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_205 : every 221 221 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_206 : every 222 222 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_207 : every 223 223 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_208 : every 224 224 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_209 : every 225 225 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_210 : every 226 226 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_211 : every 227 227 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_212 : every 228 228 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_213 : every 229 229 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_214 : every 230 230 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_215 : every 231 231 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_216 : every 232 232 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_217 : every 233 233 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_218 : every 234 234 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_219 : every 235 235 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_220 : every 236 236 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_221 : every 237 237 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_222 : every 238 238 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_223 : every 239 239 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_224 : every 240 240 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_225 : every 241 241 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_226 : every 242 242 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_227 : every 243 243 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_228 : every 244 244 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_229 : every 245 245 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_230 : every 246 246 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_231 : every 247 247 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_232 : every 248 248 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_233 : every 249 249 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_234 : every 250 250 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_235 : every 251 251 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_236 : every 252 252 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_237 : every 253 253 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_238 : every 254 254 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_239 : every 255 255 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_240 : every 256 256 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_241 : every 257 257 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_242 : every 258 258 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_243 : every 259 259 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_244 : every 260 260 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_245 : every 261 261 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_246 : every 262 262 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_247 : every 263 263 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_248 : every 264 264 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_249 : every 265 265 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_250 : every 266 266 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_251 : every 267 267 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_252 : every 268 268 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_253 : every 269 269 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_254 : every 270 270 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_255 : every 271 271 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_256 : every 272 272 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_257 : every 273 273 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_258 : every 274 274 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_259 : every 275 275 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_260 : every 276 276 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_261 : every 277 277 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_262 : every 278 278 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_263 : every 279 279 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_264 : every 280 280 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_265 : every 281 281 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_266 : every 282 282 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_267 : every 283 283 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_268 : every 284 284 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_269 : every 285 285 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_270 : every 286 286 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_271 : every 287 287 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_272 : every 288 288 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_273 : every 289 289 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_274 : every 290 290 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_275 : every 291 291 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_276 : every 292 292 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_277 : every 293 293 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_278 : every 294 294 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_279 : every 295 295 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_280 : every 296 296 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_281 : every 297 297 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_282 : every 298 298 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_283 : every 299 299 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_284 : every 300 300 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_285 : every 301 301 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_286 : every 302 302 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_287 : every 303 303 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_288 : every 304 304 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_289 : every 305 305 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_290 : every 306 306 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_291 : every 307 307 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_292 : every 308 308 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_293 : every 309 309 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_294 : every 310 310 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_295 : every 311 311 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_296 : every 312 312 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_297 : every 313 313 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_298 : every 314 314 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_299 : every 315 315 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_300 : every 316 316 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_301 : every 317 317 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_302 : every 318 318 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_303 : every 319 319 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_304 : every 320 320 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_305 : every 321 321 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_306 : every 322 322 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_307 : every 323 323 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_308 : every 324 324 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_309 : every 325 325 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_310 : every 326 326 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_311 : every 327 327 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_312 : every 328 328 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_313 : every 329 329 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_314 : every 330 330 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_315 : every 331 331 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_316 : every 332 332 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_317 : every 333 333 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_318 : every 334 334 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_319 : every 335 335 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_320 : every 336 336 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_321 : every 337 337 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_322 : every 338 338 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_323 : every 339 339 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_324 : every 340 340 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_325 : every 341 341 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_326 : every 342 342 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_327 : every 343 343 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_328 : every 344 344 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_329 : every 345 345 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_330 : every 346 346 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_331 : every 347 347 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_332 : every 348 348 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_333 : every 349 349 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_334 : every 350 350 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_335 : every 351 351 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_336 : every 352 352 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_337 : every 353 353 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_338 : every 354 354 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_339 : every 355 355 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_340 : every 356 356 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_341 : every 357 357 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_342 : every 358 358 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_343 : every 359 359 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_344 : every 360 360 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_345 : every 361 361 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_346 : every 362 362 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_347 : every 363 363 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_348 : every 364 364 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_349 : every 365 365 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_350 : every 366 366 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_351 : every 367 367 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_352 : every 368 368 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_353 : every 369 369 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_354 : every 370 370 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_355 : every 371 371 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_356 : every 372 372 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_357 : every 373 373 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_358 : every 374 374 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_359 : every 375 375 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_360 : every 376 376 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_361 : every 377 377 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_362 : every 378 378 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_363 : every 379 379 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_364 : every 380 380 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_365 : every 381 381 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_366 : every 382 382 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_367 : every 383 383 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_368 : every 384 384 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_369 : every 385 385 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_370 : every 386 386 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_371 : every 387 387 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_372 : every 388 388 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_373 : every 389 389 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_374 : every 390 390 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_375 : every 391 391 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_376 : every 392 392 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_377 : every 393 393 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_378 : every 394 394 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_379 : every 395 395 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_380 : every 396 396 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_381 : every 397 397 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_382 : every 398 398 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_383 : every 399 399 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_384 : every 400 400 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_385 : every 401 401 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_386 : every 402 402 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_387 : every 403 403 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_388 : every 404 404 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_389 : every 405 405 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_390 : every 406 406 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_391 : every 407 407 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_392 : every 408 408 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_393 : every 409 409 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_394 : every 410 410 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_395 : every 411 411 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_396 : every 412 412 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_397 : every 413 413 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_398 : every 414 414 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_399 : every 415 415 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_400 : every 416 416 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_401 : every 417 417 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_402 : every 418 418 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_403 : every 419 419 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_404 : every 420 420 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_405 : every 421 421 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_406 : every 422 422 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_407 : every 423 423 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_408 : every 424 424 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_409 : every 425 425 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_410 : every 426 426 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_411 : every 427 427 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_412 : every 428 428 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_413 : every 429 429 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_414 : every 430 430 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_415 : every 431 431 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_416 : every 432 432 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_417 : every 433 433 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_418 : every 434 434 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_419 : every 435 435 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_420 : every 436 436 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_421 : every 437 437 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_422 : every 438 438 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_423 : every 439 439 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_424 : every 440 440 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_425 : every 441 441 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_426 : every 442 442 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_427 : every 443 443 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_428 : every 444 444 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_429 : every 445 445 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_430 : every 446 446 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_431 : every 447 447 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_432 : every 448 448 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_433 : every 449 449 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_434 : every 450 450 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_435 : every 451 451 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_436 : every 452 452 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_437 : every 453 453 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_438 : every 454 454 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_439 : every 455 455 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_440 : every 456 456 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_441 : every 457 457 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_442 : every 458 458 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_443 : every 459 459 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_444 : every 460 460 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_445 : every 461 461 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_446 : every 462 462 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_447 : every 463 463 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_448 : every 464 464 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_449 : every 465 465 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_450 : every 466 466 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_451 : every 467 467 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_452 : every 468 468 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_453 : every 469 469 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_454 : every 470 470 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_455 : every 471 471 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_456 : every 472 472 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_457 : every 473 473 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_458 : every 474 474 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_459 : every 475 475 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_460 : every 476 476 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_461 : every 477 477 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_462 : every 478 478 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_463 : every 479 479 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_464 : every 480 480 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_465 : every 481 481 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_466 : every 482 482 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_467 : every 483 483 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_468 : every 484 484 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_469 : every 485 485 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_470 : every 486 486 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_471 : every 487 487 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_472 : every 488 488 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_473 : every 489 489 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_474 : every 490 490 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_475 : every 491 491 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_476 : every 492 492 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_477 : every 493 493 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_478 : every 494 494 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_479 : every 495 495 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_480 : every 496 496 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_481 : every 497 497 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_482 : every 498 498 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_483 : every 499 499 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_484 : every 500 500 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_485 : every 501 501 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem c4_486 : every 502 502 (movingRow 9299 847 4860 23)=true := by decide +kernel
private theorem p4_23 : every 23 23 (atPrime 324 9299 847 4860)=true := by
  have localTest : atPrime 324 9299 847 4860 23=true := (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery c4_12 (joinEvery c4_13 c4_14)) (joinEvery (joinEvery c4_15 c4_16) (joinEvery c4_17 c4_18))) (joinEvery (joinEvery c4_19 (joinEvery c4_20 c4_21)) (joinEvery (joinEvery c4_22 c4_23) (joinEvery c4_24 c4_25)))) (joinEvery (joinEvery (joinEvery c4_26 (joinEvery c4_27 c4_28)) (joinEvery (joinEvery c4_29 c4_30) (joinEvery c4_31 c4_32))) (joinEvery (joinEvery (joinEvery c4_33 c4_34) (joinEvery c4_35 c4_36)) (joinEvery (joinEvery c4_37 c4_38) (joinEvery c4_39 c4_40))))) (joinEvery (joinEvery (joinEvery (joinEvery c4_41 (joinEvery c4_42 c4_43)) (joinEvery (joinEvery c4_44 c4_45) (joinEvery c4_46 c4_47))) (joinEvery (joinEvery (joinEvery c4_48 c4_49) (joinEvery c4_50 c4_51)) (joinEvery (joinEvery c4_52 c4_53) (joinEvery c4_54 c4_55)))) (joinEvery (joinEvery (joinEvery c4_56 (joinEvery c4_57 c4_58)) (joinEvery (joinEvery c4_59 c4_60) (joinEvery c4_61 c4_62))) (joinEvery (joinEvery (joinEvery c4_63 c4_64) (joinEvery c4_65 c4_66)) (joinEvery (joinEvery c4_67 c4_68) (joinEvery c4_69 c4_70)))))) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery c4_71 (joinEvery c4_72 c4_73)) (joinEvery (joinEvery c4_74 c4_75) (joinEvery c4_76 c4_77))) (joinEvery (joinEvery c4_78 (joinEvery c4_79 c4_80)) (joinEvery (joinEvery c4_81 c4_82) (joinEvery c4_83 c4_84)))) (joinEvery (joinEvery (joinEvery c4_85 (joinEvery c4_86 c4_87)) (joinEvery (joinEvery c4_88 c4_89) (joinEvery c4_90 c4_91))) (joinEvery (joinEvery (joinEvery c4_92 c4_93) (joinEvery c4_94 c4_95)) (joinEvery (joinEvery c4_96 c4_97) (joinEvery c4_98 c4_99))))) (joinEvery (joinEvery (joinEvery (joinEvery c4_100 (joinEvery c4_101 c4_102)) (joinEvery (joinEvery c4_103 c4_104) (joinEvery c4_105 c4_106))) (joinEvery (joinEvery (joinEvery c4_107 c4_108) (joinEvery c4_109 c4_110)) (joinEvery (joinEvery c4_111 c4_112) (joinEvery c4_113 c4_114)))) (joinEvery (joinEvery (joinEvery c4_115 (joinEvery c4_116 c4_117)) (joinEvery (joinEvery c4_118 c4_119) (joinEvery c4_120 c4_121))) (joinEvery (joinEvery (joinEvery c4_122 c4_123) (joinEvery c4_124 c4_125)) (joinEvery (joinEvery c4_126 c4_127) (joinEvery c4_128 c4_129))))))) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery c4_130 (joinEvery c4_131 c4_132)) (joinEvery (joinEvery c4_133 c4_134) (joinEvery c4_135 c4_136))) (joinEvery (joinEvery c4_137 (joinEvery c4_138 c4_139)) (joinEvery (joinEvery c4_140 c4_141) (joinEvery c4_142 c4_143)))) (joinEvery (joinEvery (joinEvery c4_144 (joinEvery c4_145 c4_146)) (joinEvery (joinEvery c4_147 c4_148) (joinEvery c4_149 c4_150))) (joinEvery (joinEvery (joinEvery c4_151 c4_152) (joinEvery c4_153 c4_154)) (joinEvery (joinEvery c4_155 c4_156) (joinEvery c4_157 c4_158))))) (joinEvery (joinEvery (joinEvery (joinEvery c4_159 (joinEvery c4_160 c4_161)) (joinEvery (joinEvery c4_162 c4_163) (joinEvery c4_164 c4_165))) (joinEvery (joinEvery (joinEvery c4_166 c4_167) (joinEvery c4_168 c4_169)) (joinEvery (joinEvery c4_170 c4_171) (joinEvery c4_172 c4_173)))) (joinEvery (joinEvery (joinEvery c4_174 (joinEvery c4_175 c4_176)) (joinEvery (joinEvery c4_177 c4_178) (joinEvery c4_179 c4_180))) (joinEvery (joinEvery (joinEvery c4_181 c4_182) (joinEvery c4_183 c4_184)) (joinEvery (joinEvery c4_185 c4_186) (joinEvery c4_187 c4_188)))))) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery c4_189 (joinEvery c4_190 c4_191)) (joinEvery (joinEvery c4_192 c4_193) (joinEvery c4_194 c4_195))) (joinEvery (joinEvery (joinEvery c4_196 c4_197) (joinEvery c4_198 c4_199)) (joinEvery (joinEvery c4_200 c4_201) (joinEvery c4_202 c4_203)))) (joinEvery (joinEvery (joinEvery c4_204 (joinEvery c4_205 c4_206)) (joinEvery (joinEvery c4_207 c4_208) (joinEvery c4_209 c4_210))) (joinEvery (joinEvery (joinEvery c4_211 c4_212) (joinEvery c4_213 c4_214)) (joinEvery (joinEvery c4_215 c4_216) (joinEvery c4_217 c4_218))))) (joinEvery (joinEvery (joinEvery (joinEvery c4_219 (joinEvery c4_220 c4_221)) (joinEvery (joinEvery c4_222 c4_223) (joinEvery c4_224 c4_225))) (joinEvery (joinEvery (joinEvery c4_226 c4_227) (joinEvery c4_228 c4_229)) (joinEvery (joinEvery c4_230 c4_231) (joinEvery c4_232 c4_233)))) (joinEvery (joinEvery (joinEvery c4_234 (joinEvery c4_235 c4_236)) (joinEvery (joinEvery c4_237 c4_238) (joinEvery c4_239 c4_240))) (joinEvery (joinEvery (joinEvery c4_241 c4_242) (joinEvery c4_243 c4_244)) (joinEvery (joinEvery c4_245 c4_246) (joinEvery c4_247 c4_248)))))))) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery c4_249 (joinEvery c4_250 c4_251)) (joinEvery (joinEvery c4_252 c4_253) (joinEvery c4_254 c4_255))) (joinEvery (joinEvery c4_256 (joinEvery c4_257 c4_258)) (joinEvery (joinEvery c4_259 c4_260) (joinEvery c4_261 c4_262)))) (joinEvery (joinEvery (joinEvery c4_263 (joinEvery c4_264 c4_265)) (joinEvery (joinEvery c4_266 c4_267) (joinEvery c4_268 c4_269))) (joinEvery (joinEvery (joinEvery c4_270 c4_271) (joinEvery c4_272 c4_273)) (joinEvery (joinEvery c4_274 c4_275) (joinEvery c4_276 c4_277))))) (joinEvery (joinEvery (joinEvery (joinEvery c4_278 (joinEvery c4_279 c4_280)) (joinEvery (joinEvery c4_281 c4_282) (joinEvery c4_283 c4_284))) (joinEvery (joinEvery (joinEvery c4_285 c4_286) (joinEvery c4_287 c4_288)) (joinEvery (joinEvery c4_289 c4_290) (joinEvery c4_291 c4_292)))) (joinEvery (joinEvery (joinEvery c4_293 (joinEvery c4_294 c4_295)) (joinEvery (joinEvery c4_296 c4_297) (joinEvery c4_298 c4_299))) (joinEvery (joinEvery (joinEvery c4_300 c4_301) (joinEvery c4_302 c4_303)) (joinEvery (joinEvery c4_304 c4_305) (joinEvery c4_306 c4_307)))))) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery c4_308 (joinEvery c4_309 c4_310)) (joinEvery (joinEvery c4_311 c4_312) (joinEvery c4_313 c4_314))) (joinEvery (joinEvery (joinEvery c4_315 c4_316) (joinEvery c4_317 c4_318)) (joinEvery (joinEvery c4_319 c4_320) (joinEvery c4_321 c4_322)))) (joinEvery (joinEvery (joinEvery c4_323 (joinEvery c4_324 c4_325)) (joinEvery (joinEvery c4_326 c4_327) (joinEvery c4_328 c4_329))) (joinEvery (joinEvery (joinEvery c4_330 c4_331) (joinEvery c4_332 c4_333)) (joinEvery (joinEvery c4_334 c4_335) (joinEvery c4_336 c4_337))))) (joinEvery (joinEvery (joinEvery (joinEvery c4_338 (joinEvery c4_339 c4_340)) (joinEvery (joinEvery c4_341 c4_342) (joinEvery c4_343 c4_344))) (joinEvery (joinEvery (joinEvery c4_345 c4_346) (joinEvery c4_347 c4_348)) (joinEvery (joinEvery c4_349 c4_350) (joinEvery c4_351 c4_352)))) (joinEvery (joinEvery (joinEvery c4_353 (joinEvery c4_354 c4_355)) (joinEvery (joinEvery c4_356 c4_357) (joinEvery c4_358 c4_359))) (joinEvery (joinEvery (joinEvery c4_360 c4_361) (joinEvery c4_362 c4_363)) (joinEvery (joinEvery c4_364 c4_365) (joinEvery c4_366 c4_367))))))) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery c4_368 (joinEvery c4_369 c4_370)) (joinEvery (joinEvery c4_371 c4_372) (joinEvery c4_373 c4_374))) (joinEvery (joinEvery c4_375 (joinEvery c4_376 c4_377)) (joinEvery (joinEvery c4_378 c4_379) (joinEvery c4_380 c4_381)))) (joinEvery (joinEvery (joinEvery c4_382 (joinEvery c4_383 c4_384)) (joinEvery (joinEvery c4_385 c4_386) (joinEvery c4_387 c4_388))) (joinEvery (joinEvery (joinEvery c4_389 c4_390) (joinEvery c4_391 c4_392)) (joinEvery (joinEvery c4_393 c4_394) (joinEvery c4_395 c4_396))))) (joinEvery (joinEvery (joinEvery (joinEvery c4_397 (joinEvery c4_398 c4_399)) (joinEvery (joinEvery c4_400 c4_401) (joinEvery c4_402 c4_403))) (joinEvery (joinEvery (joinEvery c4_404 c4_405) (joinEvery c4_406 c4_407)) (joinEvery (joinEvery c4_408 c4_409) (joinEvery c4_410 c4_411)))) (joinEvery (joinEvery (joinEvery c4_412 (joinEvery c4_413 c4_414)) (joinEvery (joinEvery c4_415 c4_416) (joinEvery c4_417 c4_418))) (joinEvery (joinEvery (joinEvery c4_419 c4_420) (joinEvery c4_421 c4_422)) (joinEvery (joinEvery c4_423 c4_424) (joinEvery c4_425 c4_426)))))) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery c4_427 (joinEvery c4_428 c4_429)) (joinEvery (joinEvery c4_430 c4_431) (joinEvery c4_432 c4_433))) (joinEvery (joinEvery (joinEvery c4_434 c4_435) (joinEvery c4_436 c4_437)) (joinEvery (joinEvery c4_438 c4_439) (joinEvery c4_440 c4_441)))) (joinEvery (joinEvery (joinEvery c4_442 (joinEvery c4_443 c4_444)) (joinEvery (joinEvery c4_445 c4_446) (joinEvery c4_447 c4_448))) (joinEvery (joinEvery (joinEvery c4_449 c4_450) (joinEvery c4_451 c4_452)) (joinEvery (joinEvery c4_453 c4_454) (joinEvery c4_455 c4_456))))) (joinEvery (joinEvery (joinEvery (joinEvery c4_457 (joinEvery c4_458 c4_459)) (joinEvery (joinEvery c4_460 c4_461) (joinEvery c4_462 c4_463))) (joinEvery (joinEvery (joinEvery c4_464 c4_465) (joinEvery c4_466 c4_467)) (joinEvery (joinEvery c4_468 c4_469) (joinEvery c4_470 c4_471)))) (joinEvery (joinEvery (joinEvery c4_472 (joinEvery c4_473 c4_474)) (joinEvery (joinEvery c4_475 c4_476) (joinEvery c4_477 c4_478))) (joinEvery (joinEvery (joinEvery c4_479 c4_480) (joinEvery c4_481 c4_482)) (joinEvery (joinEvery c4_483 c4_484) (joinEvery c4_485 c4_486)))))))))
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=23 by omega] using localTest
private theorem c4_487 : every 24 28 (atPrime 324 9299 847 4860)=true := by decide +kernel
private theorem c4_488 : every 30 58 (fixedPair 324 9299 847 4860 29)=true := by decide +kernel
private theorem c4_489 : every 59 82 (fixedPair 324 9299 847 4860 29)=true := by decide +kernel
private theorem c4_490 : every 83 108 (fixedPair 324 9299 847 4860 29)=true := by decide +kernel
private theorem c4_491 : every 109 138 (fixedPair 324 9299 847 4860 29)=true := by decide +kernel
private theorem c4_492 : every 139 168 (fixedPair 324 9299 847 4860 29)=true := by decide +kernel
private theorem c4_493 : every 169 198 (fixedPair 324 9299 847 4860 29)=true := by decide +kernel
private theorem c4_494 : every 199 217 (fixedPair 324 9299 847 4860 29)=true := by decide +kernel
private theorem c4_495 : every 1 28 (moving 218 7 9299 847 4860 29)=true := by decide +kernel
private theorem c4_496 : every 29 38 (moving 218 7 9299 847 4860 29)=true := by decide +kernel
private theorem p4_29 : every 29 29 (atPrime 324 9299 847 4860)=true := by
  have localTest : atPrime 324 9299 847 4860 29=true := by change (every 30 217 (fixedPair 324 9299 847 4860 29) && every 1 38 (moving 218 7 9299 847 4860 29)) = true; rw [Bool.and_eq_true]; exact ⟨(joinEvery (joinEvery c4_488 (joinEvery c4_489 c4_490)) (joinEvery (joinEvery c4_491 c4_492) (joinEvery c4_493 c4_494))),(joinEvery c4_495 c4_496)⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=29 by omega] using localTest
private theorem c4_497 : every 30 30 (atPrime 324 9299 847 4860)=true := by decide +kernel
private theorem c4_498 : every 32 60 (fixedPair 324 9299 847 4860 31)=true := by decide +kernel
private theorem c4_499 : every 61 88 (fixedPair 324 9299 847 4860 31)=true := by decide +kernel
private theorem c4_500 : every 89 112 (fixedPair 324 9299 847 4860 31)=true := by decide +kernel
private theorem c4_501 : every 113 148 (fixedPair 324 9299 847 4860 31)=true := by decide +kernel
private theorem c4_502 : every 149 174 (fixedPair 324 9299 847 4860 31)=true := by decide +kernel
private theorem c4_503 : every 1 28 (moving 175 7 9299 847 4860 31)=true := by decide +kernel
private theorem c4_504 : every 29 30 (moving 175 7 9299 847 4860 31)=true := by decide +kernel
private theorem p4_31 : every 31 31 (atPrime 324 9299 847 4860)=true := by
  have localTest : atPrime 324 9299 847 4860 31=true := by change (every 32 174 (fixedPair 324 9299 847 4860 31) && every 1 30 (moving 175 7 9299 847 4860 31)) = true; rw [Bool.and_eq_true]; exact ⟨(joinEvery (joinEvery c4_498 c4_499) (joinEvery c4_500 (joinEvery c4_501 c4_502))),(joinEvery c4_503 c4_504)⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=31 by omega] using localTest
private theorem c4_505 : every 32 36 (atPrime 324 9299 847 4860)=true := by decide +kernel
private theorem c4_506 : every 38 66 (fixedPair 324 9299 847 4860 37)=true := by decide +kernel
private theorem c4_507 : every 67 96 (fixedPair 324 9299 847 4860 37)=true := by decide +kernel
private theorem c4_508 : every 97 118 (fixedPair 324 9299 847 4860 37)=true := by decide +kernel
private theorem c4_509 : every 1 20 (moving 119 8 9299 847 4860 37)=true := by decide +kernel
private theorem p4_37 : every 37 37 (atPrime 324 9299 847 4860)=true := by
  have localTest : atPrime 324 9299 847 4860 37=true := by change (every 38 118 (fixedPair 324 9299 847 4860 37) && every 1 20 (moving 119 8 9299 847 4860 37)) = true; rw [Bool.and_eq_true]; exact ⟨(joinEvery c4_506 (joinEvery c4_507 c4_508)),c4_509⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=37 by omega] using localTest
private theorem c4_510 : every 38 40 (atPrime 324 9299 847 4860)=true := by decide +kernel
private theorem c4_511 : every 42 70 (fixedPair 324 9299 847 4860 41)=true := by decide +kernel
private theorem c4_512 : every 71 100 (fixedPair 324 9299 847 4860 41)=true := by decide +kernel
private theorem c4_513 : every 101 102 (fixedPair 324 9299 847 4860 41)=true := by decide +kernel
private theorem c4_514 : every 1 17 (moving 103 9 9299 847 4860 41)=true := by decide +kernel
private theorem p4_41 : every 41 41 (atPrime 324 9299 847 4860)=true := by
  have localTest : atPrime 324 9299 847 4860 41=true := by change (every 42 102 (fixedPair 324 9299 847 4860 41) && every 1 17 (moving 103 9 9299 847 4860 41)) = true; rw [Bool.and_eq_true]; exact ⟨(joinEvery c4_511 (joinEvery c4_512 c4_513)),c4_514⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=41 by omega] using localTest
private theorem c4_515 : every 42 42 (atPrime 324 9299 847 4860)=true := by decide +kernel
private theorem c4_516 : every 44 72 (fixedPair 324 9299 847 4860 43)=true := by decide +kernel
private theorem c4_517 : every 73 96 (fixedPair 324 9299 847 4860 43)=true := by decide +kernel
private theorem c4_518 : every 1 16 (moving 97 9 9299 847 4860 43)=true := by decide +kernel
private theorem p4_43 : every 43 43 (atPrime 324 9299 847 4860)=true := by
  have localTest : atPrime 324 9299 847 4860 43=true := by change (every 44 96 (fixedPair 324 9299 847 4860 43) && every 1 16 (moving 97 9 9299 847 4860 43)) = true; rw [Bool.and_eq_true]; exact ⟨(joinEvery c4_516 c4_517),c4_518⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=43 by omega] using localTest
private theorem c4_519 : every 44 46 (atPrime 324 9299 847 4860)=true := by decide +kernel
private theorem c4_520 : every 48 77 (fixedPair 324 9299 847 4860 47)=true := by decide +kernel
private theorem c4_521 : every 78 87 (fixedPair 324 9299 847 4860 47)=true := by decide +kernel
private theorem c4_522 : every 1 15 (moving 88 10 9299 847 4860 47)=true := by decide +kernel
private theorem p4_47 : every 47 47 (atPrime 324 9299 847 4860)=true := by
  have localTest : atPrime 324 9299 847 4860 47=true := by change (every 48 87 (fixedPair 324 9299 847 4860 47) && every 1 15 (moving 88 10 9299 847 4860 47)) = true; rw [Bool.and_eq_true]; exact ⟨(joinEvery c4_520 c4_521),c4_522⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=47 by omega] using localTest
private theorem c4_523 : every 48 52 (atPrime 324 9299 847 4860)=true := by decide +kernel
private theorem c4_524 : every 54 79 (fixedPair 324 9299 847 4860 53)=true := by decide +kernel
private theorem c4_525 : every 1 13 (moving 80 11 9299 847 4860 53)=true := by decide +kernel
private theorem p4_53 : every 53 53 (atPrime 324 9299 847 4860)=true := by
  have localTest : atPrime 324 9299 847 4860 53=true := by change (every 54 79 (fixedPair 324 9299 847 4860 53) && every 1 13 (moving 80 11 9299 847 4860 53)) = true; rw [Bool.and_eq_true]; exact ⟨c4_524,c4_525⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=53 by omega] using localTest
private theorem c4_526 : every 54 58 (atPrime 324 9299 847 4860)=true := by decide +kernel
private theorem c4_527 : every 60 73 (fixedPair 324 9299 847 4860 59)=true := by decide +kernel
private theorem c4_528 : every 1 12 (moving 74 12 9299 847 4860 59)=true := by decide +kernel
private theorem p4_59 : every 59 59 (atPrime 324 9299 847 4860)=true := by
  have localTest : atPrime 324 9299 847 4860 59=true := by change (every 60 73 (fixedPair 324 9299 847 4860 59) && every 1 12 (moving 74 12 9299 847 4860 59)) = true; rw [Bool.and_eq_true]; exact ⟨c4_527,c4_528⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=59 by omega] using localTest
private theorem c4_529 : every 60 60 (atPrime 324 9299 847 4860)=true := by decide +kernel
private theorem c4_530 : every 62 72 (fixedPair 324 9299 847 4860 61)=true := by decide +kernel
private theorem c4_531 : every 1 12 (moving 73 12 9299 847 4860 61)=true := by decide +kernel
private theorem p4_61 : every 61 61 (atPrime 324 9299 847 4860)=true := by
  have localTest : atPrime 324 9299 847 4860 61=true := by change (every 62 72 (fixedPair 324 9299 847 4860 61) && every 1 12 (moving 73 12 9299 847 4860 61)) = true; rw [Bool.and_eq_true]; exact ⟨c4_530,c4_531⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=61 by omega] using localTest
private theorem c4_532 : every 62 66 (atPrime 324 9299 847 4860)=true := by decide +kernel
private theorem c4_533 : every 68 68 (fixedPair 324 9299 847 4860 67)=true := by decide +kernel
private theorem c4_534 : every 1 12 (moving 69 14 9299 847 4860 67)=true := by decide +kernel
private theorem p4_67 : every 67 67 (atPrime 324 9299 847 4860)=true := by
  have localTest : atPrime 324 9299 847 4860 67=true := by change (every 68 68 (fixedPair 324 9299 847 4860 67) && every 1 12 (moving 69 14 9299 847 4860 67)) = true; rw [Bool.and_eq_true]; exact ⟨c4_533,c4_534⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=67 by omega] using localTest
private theorem c4_535 : every 68 70 (atPrime 324 9299 847 4860)=true := by decide +kernel
private theorem c4_536 : every 72 66 (fixedPair 324 9299 847 4860 71)=true := by decide +kernel
private theorem c4_537 : every 1 11 (moving 72 14 9299 847 4860 71)=true := by decide +kernel
private theorem p4_71 : every 71 71 (atPrime 324 9299 847 4860)=true := by
  have localTest : atPrime 324 9299 847 4860 71=true := by change (every 72 66 (fixedPair 324 9299 847 4860 71) && every 1 11 (moving 72 14 9299 847 4860 71)) = true; rw [Bool.and_eq_true]; exact ⟨c4_536,c4_537⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=71 by omega] using localTest
private theorem c4_538 : every 72 72 (atPrime 324 9299 847 4860)=true := by decide +kernel
private theorem c4_539 : every 74 65 (fixedPair 324 9299 847 4860 73)=true := by decide +kernel
private theorem c4_540 : every 1 11 (moving 74 15 9299 847 4860 73)=true := by decide +kernel
private theorem p4_73 : every 73 73 (atPrime 324 9299 847 4860)=true := by
  have localTest : atPrime 324 9299 847 4860 73=true := by change (every 74 65 (fixedPair 324 9299 847 4860 73) && every 1 11 (moving 74 15 9299 847 4860 73)) = true; rw [Bool.and_eq_true]; exact ⟨c4_539,c4_540⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=73 by omega] using localTest
private theorem c4_541 : every 74 78 (atPrime 324 9299 847 4860)=true := by decide +kernel
private theorem c4_542 : every 80 63 (fixedPair 324 9299 847 4860 79)=true := by decide +kernel
private theorem c4_543 : every 1 11 (moving 80 16 9299 847 4860 79)=true := by decide +kernel
private theorem p4_79 : every 79 79 (atPrime 324 9299 847 4860)=true := by
  have localTest : atPrime 324 9299 847 4860 79=true := by change (every 80 63 (fixedPair 324 9299 847 4860 79) && every 1 11 (moving 80 16 9299 847 4860 79)) = true; rw [Bool.and_eq_true]; exact ⟨c4_542,c4_543⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=79 by omega] using localTest
private theorem c4_544 : every 80 82 (atPrime 324 9299 847 4860)=true := by decide +kernel
private theorem c4_545 : every 84 62 (fixedPair 324 9299 847 4860 83)=true := by decide +kernel
private theorem c4_546 : every 1 11 (moving 84 16 9299 847 4860 83)=true := by decide +kernel
private theorem p4_83 : every 83 83 (atPrime 324 9299 847 4860)=true := by
  have localTest : atPrime 324 9299 847 4860 83=true := by change (every 84 62 (fixedPair 324 9299 847 4860 83) && every 1 11 (moving 84 16 9299 847 4860 83)) = true; rw [Bool.and_eq_true]; exact ⟨c4_545,c4_546⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=83 by omega] using localTest
private theorem c4_547 : every 84 88 (atPrime 324 9299 847 4860)=true := by decide +kernel
private theorem c4_548 : every 90 60 (fixedPair 324 9299 847 4860 89)=true := by decide +kernel
private theorem c4_549 : every 1 10 (moving 90 18 9299 847 4860 89)=true := by decide +kernel
private theorem p4_89 : every 89 89 (atPrime 324 9299 847 4860)=true := by
  have localTest : atPrime 324 9299 847 4860 89=true := by change (every 90 60 (fixedPair 324 9299 847 4860 89) && every 1 10 (moving 90 18 9299 847 4860 89)) = true; rw [Bool.and_eq_true]; exact ⟨c4_548,c4_549⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=89 by omega] using localTest
private theorem c4_550 : every 90 92 (atPrime 324 9299 847 4860)=true := by decide +kernel
theorem at4 : cert 4=true := (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery p4_5 c4_1) (joinEvery p4_7 (joinEvery c4_3 p4_11))) (joinEvery (joinEvery c4_5 (joinEvery p4_13 c4_7)) (joinEvery p4_17 (joinEvery c4_9 p4_19)))) (joinEvery (joinEvery (joinEvery c4_11 p4_23) (joinEvery c4_487 (joinEvery p4_29 c4_497))) (joinEvery (joinEvery p4_31 (joinEvery c4_505 p4_37)) (joinEvery c4_510 (joinEvery p4_41 c4_515))))) (joinEvery (joinEvery (joinEvery (joinEvery p4_43 c4_519) (joinEvery p4_47 (joinEvery c4_523 p4_53))) (joinEvery (joinEvery c4_526 (joinEvery p4_59 c4_529)) (joinEvery p4_61 (joinEvery c4_532 p4_67)))) (joinEvery (joinEvery (joinEvery c4_535 p4_71) (joinEvery c4_538 (joinEvery p4_73 c4_541))) (joinEvery (joinEvery p4_79 (joinEvery c4_544 p4_83)) (joinEvery c4_547 (joinEvery p4_89 c4_550))))))
end OMA.RankThreeFourSmallTables245212
#print axioms OMA.RankThreeFourSmallTables245212.at4
