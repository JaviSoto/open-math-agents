import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E24P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 14 29 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b1 : every 30 40 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b2 : every 41 46 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b3 : every 47 58 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b4 : every 59 60 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b5 : every 61 66 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b6 : every 67 70 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b7 : every 71 72 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b8 : every 73 78 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b9 : every 79 82 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b10 : every 83 88 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b11 : every 89 96 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b12 : every 97 100 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b13 : every 101 102 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b14 : every 103 106 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b15 : every 107 108 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b16 : every 109 112 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b17 : every 113 126 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b18 : every 127 130 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b19 : every 131 136 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b20 : every 137 138 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b21 : every 139 148 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b22 : every 149 150 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b23 : every 151 156 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b24 : every 157 162 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b25 : every 163 166 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b26 : every 167 172 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b27 : every 173 178 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b28 : every 179 180 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b29 : every 181 190 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b30 : every 191 192 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b31 : every 193 196 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b32 : every 197 198 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b33 : every 199 210 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
private theorem b34 : every 211 213 (finitePair 564859072962 51896427328385 1270932914163 28242953648100 13)=true := by decide +kernel
theorem checked : test 3 24 13=true :=
  fixedTest (h:=564859072962) (A:=51896427328385) (S:=1270932914163) (T:=28242953648100)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 b3)) (joinEvery (joinEvery b4 b5) (joinEvery b6 b7))) (joinEvery (joinEvery (joinEvery b8 b9) (joinEvery b10 b11)) (joinEvery (joinEvery b12 b13) (joinEvery b14 (joinEvery b15 b16))))) (joinEvery (joinEvery (joinEvery (joinEvery b17 b18) (joinEvery b19 b20)) (joinEvery (joinEvery b21 b22) (joinEvery b23 (joinEvery b24 b25)))) (joinEvery (joinEvery (joinEvery b26 b27) (joinEvery b28 b29)) (joinEvery (joinEvery b30 b31) (joinEvery b32 (joinEvery b33 b34))))))
#print axioms checked
end OMA.RankThreeAt3E24P13
