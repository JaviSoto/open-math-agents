import CapOrder245212

/-! Finitely many non-dyadic A245212 solutions on any fixed set of primes.
Truncate each exponent at twice the largest prime. The solutions of each
truncated pattern form an antichain, which is finite by Dickson's lemma. -/
namespace OMA.FixedPrimes245212
open Finset OMA.Smooth245212 OMA.Abundance245212 OMA.CapOrder245212
open scoped ArithmeticFunction.sigma

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

def Exception (n : ℕ) : Prop :=
  OeisA245212.a n = (σ 1 n:ℤ) ∧ ¬∃ u : ℕ, n=2^u

private theorem axis (p : ι → ℕ) (hp : ∀ i,Nat.Prime (p i)) (hinj : Function.Injective p)
    {e f : ι → ℕ} (i : ι) (other : ∀ j,j≠i → e j=f j)
    (he : Exception (total p e)) (hf : Exception (total p f)) : e i=f i := by
  let m := ∏ j∈univ.erase i,(p j)^(e j)
  have em : total p e=m*(p i)^(e i) := (prod_erase_mul _ _ (mem_univ i)).symm
  have fm : total p f=m*(p i)^(f i) := by
    rw [total,←prod_erase_mul _ _ (mem_univ i)]
    congr 1
    exact prod_congr rfl fun j hj => by rw [other j (mem_erase.mp hj).1]
  have hm : m≠0 := prod_ne_zero_iff.mpr (fun j _ => pow_ne_zero _ (hp j).ne_zero)
  have cp : (p i).Coprime m := Nat.Coprime.prod_right (fun j hj =>
    ((Nat.coprime_primes (hp i) (hp j)).mpr (fun h => (mem_erase.mp hj).1 (hinj h).symm)).pow_right _)
  rcases unique_exponent hm (hp i) ((hp i).coprime_iff_not_dvd.mp cp)
      (em ▸ he.1) (fm ▸ hf.1) with yes|⟨p2,m1⟩
  · exact yes
  · exact (he.2 ⟨e i,by simpa [m1,p2] using em⟩).elim

theorem finite_vectors (p : ι → ℕ) (hp : ∀ i,Nat.Prime (p i)) (hinj : Function.Injective p) :
    {e : ι → ℕ | Exception (total p e)}.Finite := by
  classical
  let H := 2*(∑ i,p i)
  let cap (e : ι → ℕ) (i : ι) : Fin (H+1) := ⟨min H (e i),by omega⟩
  apply Set.Finite.of_finite_fibers cap (Set.toFinite _)
  intro pat _
  apply WellQuasiOrderedLE.finite_of_isAntichain
  intro e he f hf ne ef
  have hE : Exception (total p e) := he.1
  have hF : Exception (total p f) := hf.1
  have capped : cap e=cap f := he.2.trans hf.2.symm
  have bound (i : ι) : 2*p i≤H := Nat.mul_le_mul_left 2
    (single_le_sum (f:=p) (fun _ _ => Nat.zero_le _) (mem_univ i))
  have high (i : ι) (lt : e i<f i) : H≤e i := by
    have hh := congrArg Fin.val (congrFun capped i)
    change min H (e i)=min H (f i) at hh
    omega
  obtain ⟨i,lt⟩ : ∃ i,e i<f i := by
    by_contra! h; exact ne (funext fun j => Nat.le_antisymm (ef j) (h j))
  by_cases only : ∀ j,j≠i → e j=f j
  · exact lt.ne (axis p hp hinj i only hE hF)
  · push Not at only
    obtain ⟨j,ji,ej⟩ := only
    have lj := (ef j).lt_of_ne ej
    have rise := strict_of_changes p hp ef lt (fun l _ => by
      by_cases li : l=i
      · exact ⟨j,li ▸ ji,(bound l).trans (high j lj)⟩
      · exact ⟨i,Ne.symm li,(bound l).trans (high i lt)⟩)
    rw [normalized_of_eq p hp hinj _ hE.1,normalized_of_eq p hp hinj _ hF.1] at rise
    exact rise.false

theorem finite (P : Finset ℕ) :
    {n : ℕ | 0<n ∧ n.primeFactors⊆P ∧ Exception n}.Finite := by
  classical
  let S := P.filter Nat.Prime
  let p (i : S) := i.val
  have hp (i : S) : Nat.Prime (p i) := (mem_filter.mp i.property).2
  have h := (finite_vectors p hp Subtype.val_injective).image (total p)
  refine h.subset ?_
  intro n hn
  let e (i : S) := n.factorization i.val
  have prod : total p e=n := by
    unfold total
    change (∏ i:S,i.val^(n.factorization i.val))=n
    rw [Finset.prod_coe_sort S (fun q => q^n.factorization q)]
    apply Eq.symm
    refine (Nat.prod_primeFactors_pow_factorization hn.1.ne').trans (prod_subset ?_ ?_)
    · intro q hq; exact mem_filter.mpr ⟨hn.2.1 hq,Nat.prime_of_mem_primeFactors hq⟩
    · intro q hq hnq
      have h0 : n.factorization q=0 := Finsupp.notMem_support_iff.mp hnq
      simp [h0]
  exact ⟨e,show Exception (total p e) from prod.symm ▸ hn.2.2,prod⟩

end OMA.FixedPrimes245212
