import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E5P7
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 8 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b1 : every 9 14 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b2 : every 15 19 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b3 : every 20 23 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b4 : every 24 27 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b5 : every 28 31 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b6 : every 32 35 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b7 : every 36 38 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b8 : every 39 41 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b9 : every 42 44 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b10 : every 45 47 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b11 : every 48 50 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b12 : every 51 53 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b13 : every 54 56 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b14 : every 57 60 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b15 : every 61 61 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b16 : every 62 62 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b17 : every 63 63 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b18 : every 64 64 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b19 : every 65 65 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b20 : every 66 66 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b21 : every 67 67 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b22 : every 68 68 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b23 : every 69 69 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b24 : every 70 70 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b25 : every 71 71 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b26 : every 72 72 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b27 : every 73 73 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b28 : every 74 74 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b29 : every 75 75 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b30 : every 76 76 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b31 : every 77 77 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b32 : every 78 78 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b33 : every 79 79 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b34 : every 80 80 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b35 : every 81 81 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b36 : every 82 82 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b37 : every 83 83 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b38 : every 84 84 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b39 : every 85 85 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b40 : every 86 86 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b41 : every 87 87 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b42 : every 88 88 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b43 : every 89 89 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b44 : every 90 90 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b45 : every 91 91 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b46 : every 92 92 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b47 : every 93 93 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b48 : every 94 94 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b49 : every 95 95 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b50 : every 96 96 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b51 : every 97 97 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b52 : every 98 98 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b53 : every 99 99 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b54 : every 100 100 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b55 : every 101 101 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b56 : every 102 102 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b57 : every 103 103 (movingRow 10025 1092 5832 7)=true := by decide +kernel
private theorem b58 : every 104 104 (movingRow 10025 1092 5832 7)=true := by decide +kernel
theorem checked : test 3 5 7=true :=
  movingTest (h:=486) (A:=10025) (S:=1092) (T:=5832)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 (joinEvery b1 b2)) (joinEvery (joinEvery b3 b4) (joinEvery b5 b6))) (joinEvery (joinEvery b7 (joinEvery b8 b9)) (joinEvery (joinEvery b10 b11) (joinEvery b12 b13)))) (joinEvery (joinEvery (joinEvery b14 (joinEvery b15 b16)) (joinEvery (joinEvery b17 b18) (joinEvery b19 b20))) (joinEvery (joinEvery (joinEvery b21 b22) (joinEvery b23 b24)) (joinEvery (joinEvery b25 b26) (joinEvery b27 b28))))) (joinEvery (joinEvery (joinEvery (joinEvery b29 (joinEvery b30 b31)) (joinEvery (joinEvery b32 b33) (joinEvery b34 b35))) (joinEvery (joinEvery (joinEvery b36 b37) (joinEvery b38 b39)) (joinEvery (joinEvery b40 b41) (joinEvery b42 b43)))) (joinEvery (joinEvery (joinEvery b44 (joinEvery b45 b46)) (joinEvery (joinEvery b47 b48) (joinEvery b49 b50))) (joinEvery (joinEvery (joinEvery b51 b52) (joinEvery b53 b54)) (joinEvery (joinEvery b55 b56) (joinEvery b57 b58))))))
#print axioms checked
end OMA.RankThreeAt3E5P7
