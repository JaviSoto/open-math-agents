import RankThreeAt3E1P5
import RankThreeAt3E2P5
import RankThreeAt3E3P5
import RankThreeAt5E1P3
import RankThreeAt5E2P3
import RankThreeAt5E3P3
/-! Both ordered short-cofactor certificates. -/
namespace OMA.RankThreeMiddle5
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212 OMA.Smooth245212
theorem range0 : rangeCheck 3 5 4=true := range_from_every (joinEvery (singleTest OMA.RankThreeAt3E1P5.checked) (joinEvery (singleTest OMA.RankThreeAt3E2P5.checked) (singleTest OMA.RankThreeAt3E3P5.checked)))
theorem range1 : rangeCheck 5 3 4=true := range_from_every (joinEvery (singleTest OMA.RankThreeAt5E1P3.checked) (joinEvery (singleTest OMA.RankThreeAt5E2P3.checked) (singleTest OMA.RankThreeAt5E3P3.checked)))
theorem mass : 8≤5*X 3 (some 4)*X 5 (some 4) := by decide +kernel
end OMA.RankThreeMiddle5
