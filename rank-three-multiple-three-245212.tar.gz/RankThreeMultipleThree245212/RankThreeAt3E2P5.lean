import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E2P5
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 6 16 (finitePair 18 170 39 108 5)=true := by decide +kernel
private theorem b1 : every 17 22 (finitePair 18 170 39 108 5)=true := by decide +kernel
private theorem b2 : every 23 30 (finitePair 18 170 39 108 5)=true := by decide +kernel
private theorem b3 : every 31 40 (finitePair 18 170 39 108 5)=true := by decide +kernel
private theorem b4 : every 41 46 (finitePair 18 170 39 108 5)=true := by decide +kernel
private theorem b5 : every 47 52 (finitePair 18 170 39 108 5)=true := by decide +kernel
private theorem b6 : every 53 58 (finitePair 18 170 39 108 5)=true := by decide +kernel
private theorem b7 : every 59 60 (finitePair 18 170 39 108 5)=true := by decide +kernel
private theorem b8 : every 61 61 (finitePair 18 170 39 108 5)=true := by decide +kernel
theorem checked : test 3 2 5=true :=
  fixedTest (h:=18) (A:=170) (S:=39) (T:=108)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 b3)) (joinEvery (joinEvery b4 b5) (joinEvery b6 (joinEvery b7 b8))))
#print axioms checked
end OMA.RankThreeAt3E2P5
