import TriSupport245212
import BoxPrefix245212

/-! At each odd prime, screen the two other exponents by a necessary congruence. -/
namespace OMA.TriSupport245212
open Nat Finset ArithmeticFunction OMA.Smooth245212
open scoped ArithmeticFunction.sigma
open private OMA.Large245212.moments from LargeExact245212

def next (i : I3) : I3 := i+1
def last (i : I3) : I3 := i+2
def residue (p u v a b mod : ℕ) : Bool :=
  decide ((OMA.Large245212.wt u a * OMA.Large245212.wt v b) % mod =
    ((p-1)*OMA.Large245212.sig u a*OMA.Large245212.sig v b) % mod)
def modTest (q : ℕ) (box : Box) (i : I3) : Bool :=
  let j := next i
  let k := last i
  let p := P q i
  let mod := p^(min 8 (box i).lo)
  (box j).entries.all fun a => (box k).entries.all fun b => !residue p (P q j) (P q k) a b mod

theorem mod_sound {q : ℕ} (ok : supported q) {box : Box} {i : I3}
    (yes : modTest q box i=true) : Deny q box := by
  intro e fit eq
  let j := next i
  let k := last i
  let p := P q i
  let u := P q j
  let v := P q k
  let m := u^(e j)*v^(e k)
  let h := min 8 (box i).lo
  have hp := primes ok
  have neq : j≠i ∧ k≠i ∧ j≠k := by fin_cases i <;> decide
  have cju : u.Coprime p := (Nat.coprime_primes (hp.1 j) (hp.1 i)).mpr (fun z => neq.1 (hp.2 z))
  have cku : v.Coprime p := (Nat.coprime_primes (hp.1 k) (hp.1 i)).mpr (fun z => neq.2.1 (hp.2 z))
  have cjk : u.Coprime v := (Nat.coprime_primes (hp.1 j) (hp.1 k)).mpr (fun z => neq.2.2 (hp.2 z))
  have cop : m.Coprime p := Nat.coprime_mul_iff_left.mpr ⟨cju.pow_left _,cku.pow_left _⟩
  have cp := (cjk.pow_left (e j)).pow_right (e k)
  have posm : 0 < m := Nat.mul_pos (pow_pos (hp.1 j).pos _) (pow_pos (hp.1 k).pos _)
  have ident : total (P q) e=m*p^(e i) := by
    fin_cases i <;> simp [total,Fin.prod_univ_three,m,p,u,v,j,k,next,last] <;> ring
  rw [ident] at eq
  have div := OMA.PrimePowerDiv245212.power_divides posm (hp.1 i) cop (e i) eq
  have hh : h ≤ e i := (min_le_right _ _).trans (fit i).1
  have full := (pow_dvd_pow (p:ℤ) hh).trans div
  have hu := OMA.Large245212.moments (hp.1 j) (e j)
  have hv := OMA.Large245212.moments (hp.1 k) (e k)
  change _ ∣ (W (u^(e j)*v^(e k)) : ℤ)-((p:ℤ)-1)*(σ 1 (u^(e j)*v^(e k)):ℤ) at full
  rw [w_mult.map_mul_of_coprime cp,isMultiplicative_sigma.map_mul_of_coprime cp,
    ←hu.2,←hv.2,←hu.1,←hv.1] at full
  have cong : (p-1)*OMA.Large245212.sig u (e j)*OMA.Large245212.sig v (e k) ≡
    OMA.Large245212.wt u (e j)*OMA.Large245212.wt v (e k) [MOD p^h] := by
    apply Nat.modEq_iff_dvd.mpr
    have z : ((p-1:ℕ):ℤ)=(p:ℤ)-1 := by rw [Nat.cast_sub (show 1≤p from (hp.1 i).pos),Nat.cast_one]
    simp only [Nat.cast_pow,Nat.cast_mul,z,mul_assoc]
    exact full
  have actual : residue p u v (e j) (e k) (p^h)=true := decide_eq_true cong.symm
  have no := List.all_eq_true.mp (List.all_eq_true.mp yes _ ((box j).mem_entries (fit j)))
    _ ((box k).mem_entries (fit k))
  change (!residue p u v (e j) (e k) (p^h))=true at no
  simp [actual] at no

inductive Trace
  | score
  | sieve (i : I3)
  | branch (i : I3) (cut : ℕ) (left right : Trace)
def leftB (b : Box) (i : I3) (c : ℕ) := Function.update b i ⟨(b i).lo,c⟩
def rightB (b : Box) (i : I3) (c : ℕ) := Function.update b i ⟨c+1,(b i).hi⟩
def Trace.check (q : ℕ) : Trace → Box → Bool
  | .score,b => scoreTest q b
  | .sieve i,b => modTest q b i
  | .branch i c l r,b => l.check q (leftB b i c) && r.check q (rightB b i c)
theorem Trace.sound {q : ℕ} (ok : supported q) (t : Trace) (b : Box)
    (cert : t.check q b=true) : Deny q b := by
  induction t generalizing b with
  | score => exact score_sound ok cert
  | sieve i => exact mod_sound ok cert
  | branch i c l r il ir =>
    obtain ⟨cl,cr⟩ := Bool.and_eq_true_iff.mp cert
    intro e he eq
    by_cases small : e i≤c
    · apply il _ cl e _ eq
      intro j; by_cases ij : j=i
      · subst j; simpa [leftB,OMA.Box245212.Range.has] using And.intro (he i).1 small
      · simpa [leftB,ij] using he j
    · apply ir _ cr e _ eq
      intro j; by_cases ij : j=i
      · subst j; simpa [rightB,OMA.Box245212.Range.has] using And.intro (by omega : c+1≤e i) (he i).2
      · simpa [rightB,ij] using he j

end OMA.TriSupport245212
