import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E1P7
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 8 6 (finitePair 6 35 12 24 7)=true := by decide +kernel
theorem checked : test 3 1 7=true :=
  fixedTest (h:=6) (A:=35) (S:=12) (T:=24)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) b0
#print axioms checked
end OMA.RankThreeAt3E1P7
