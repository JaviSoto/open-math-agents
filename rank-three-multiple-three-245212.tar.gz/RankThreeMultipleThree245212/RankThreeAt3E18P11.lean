import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E18P11
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 5 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b1 : every 6 10 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b2 : every 11 15 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b3 : every 16 20 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b4 : every 21 23 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b5 : every 24 24 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b6 : every 25 25 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b7 : every 26 26 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b8 : every 27 27 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b9 : every 28 28 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b10 : every 29 29 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b11 : every 30 30 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b12 : every 31 31 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b13 : every 32 32 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b14 : every 33 33 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b15 : every 34 34 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b16 : every 35 35 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b17 : every 36 36 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b18 : every 37 37 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b19 : every 38 38 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b20 : every 39 39 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b21 : every 40 40 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b22 : every 41 41 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b23 : every 42 42 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b24 : every 43 43 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
private theorem b25 : every 44 44 (movingRow 53754592850 1743392199 29443957164 11)=true := by decide +kernel
theorem checked : test 3 18 11=true :=
  movingTest (h:=774840978) (A:=53754592850) (S:=1743392199) (T:=29443957164)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery b0 (joinEvery b1 b2)) (joinEvery b3 (joinEvery b4 b5))) (joinEvery (joinEvery b6 (joinEvery b7 b8)) (joinEvery (joinEvery b9 b10) (joinEvery b11 b12)))) (joinEvery (joinEvery (joinEvery b13 (joinEvery b14 b15)) (joinEvery b16 (joinEvery b17 b18))) (joinEvery (joinEvery b19 (joinEvery b20 b21)) (joinEvery (joinEvery b22 b23) (joinEvery b24 b25)))))
#print axioms checked
end OMA.RankThreeAt3E18P11
