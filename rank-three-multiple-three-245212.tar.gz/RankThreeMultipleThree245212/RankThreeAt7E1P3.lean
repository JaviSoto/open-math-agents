import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt7E1P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 8 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b1 : every 9 15 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b2 : every 16 21 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b3 : every 22 26 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b4 : every 27 31 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b5 : every 32 35 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b6 : every 36 39 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b7 : every 40 43 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b8 : every 44 47 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b9 : every 48 51 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b10 : every 52 55 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b11 : every 56 58 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b12 : every 59 61 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b13 : every 62 64 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b14 : every 65 67 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b15 : every 68 70 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b16 : every 71 73 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b17 : every 74 76 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b18 : every 77 79 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b19 : every 80 82 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b20 : every 83 85 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b21 : every 86 88 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b22 : every 89 91 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b23 : every 92 94 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b24 : every 95 97 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b25 : every 98 100 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b26 : every 101 103 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b27 : every 104 106 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b28 : every 107 109 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b29 : every 110 111 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b30 : every 112 112 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b31 : every 113 113 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b32 : every 114 114 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b33 : every 115 115 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b34 : every 116 116 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b35 : every 117 117 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b36 : every 118 118 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b37 : every 119 119 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b38 : every 120 120 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b39 : every 121 121 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b40 : every 122 122 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b41 : every 123 123 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b42 : every 124 124 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b43 : every 125 125 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b44 : every 126 126 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b45 : every 127 127 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b46 : every 128 128 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b47 : every 129 129 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b48 : every 130 130 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b49 : every 131 131 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b50 : every 132 132 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b51 : every 133 133 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b52 : every 134 134 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b53 : every 135 135 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b54 : every 136 136 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b55 : every 137 137 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b56 : every 138 138 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b57 : every 139 139 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b58 : every 140 140 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b59 : every 141 141 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b60 : every 142 142 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b61 : every 143 143 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b62 : every 144 144 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b63 : every 145 145 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b64 : every 146 146 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b65 : every 147 147 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b66 : every 148 148 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b67 : every 149 149 (movingRow 75 24 56 3)=true := by decide +kernel
private theorem b68 : every 150 150 (movingRow 75 24 56 3)=true := by decide +kernel
theorem checked : test 7 1 3=true :=
  movingTest (h:=14) (A:=75) (S:=24) (T:=56)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 b3)) (joinEvery (joinEvery b4 b5) (joinEvery b6 b7))) (joinEvery (joinEvery (joinEvery b8 b9) (joinEvery b10 b11)) (joinEvery (joinEvery b12 b13) (joinEvery b14 (joinEvery b15 b16))))) (joinEvery (joinEvery (joinEvery (joinEvery b17 b18) (joinEvery b19 b20)) (joinEvery (joinEvery b21 b22) (joinEvery b23 b24))) (joinEvery (joinEvery (joinEvery b25 b26) (joinEvery b27 b28)) (joinEvery (joinEvery b29 b30) (joinEvery b31 (joinEvery b32 b33)))))) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b34 b35) (joinEvery b36 b37)) (joinEvery (joinEvery b38 b39) (joinEvery b40 b41))) (joinEvery (joinEvery (joinEvery b42 b43) (joinEvery b44 b45)) (joinEvery (joinEvery b46 b47) (joinEvery b48 (joinEvery b49 b50))))) (joinEvery (joinEvery (joinEvery (joinEvery b51 b52) (joinEvery b53 b54)) (joinEvery (joinEvery b55 b56) (joinEvery b57 (joinEvery b58 b59)))) (joinEvery (joinEvery (joinEvery b60 b61) (joinEvery b62 b63)) (joinEvery (joinEvery b64 b65) (joinEvery b66 (joinEvery b67 b68)))))))
#print axioms checked
end OMA.RankThreeAt7E1P3
