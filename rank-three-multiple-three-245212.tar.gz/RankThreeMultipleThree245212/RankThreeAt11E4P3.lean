import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt11E4P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 5 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b1 : every 6 10 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b2 : every 11 15 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b3 : every 16 20 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b4 : every 21 25 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b5 : every 26 30 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b6 : every 31 35 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b7 : every 36 40 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b8 : every 41 45 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b9 : every 46 47 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b10 : every 48 48 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b11 : every 49 49 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b12 : every 50 50 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b13 : every 51 51 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b14 : every 52 52 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b15 : every 53 53 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b16 : every 54 54 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b17 : every 55 55 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b18 : every 56 56 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b19 : every 57 57 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b20 : every 58 58 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b21 : every 59 59 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b22 : every 60 60 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b23 : every 61 61 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b24 : every 62 62 (movingRow 394575 48315 292820 3)=true := by decide +kernel
private theorem b25 : every 63 63 (movingRow 394575 48315 292820 3)=true := by decide +kernel
theorem checked : test 11 4 3=true :=
  movingTest (h:=29282) (A:=394575) (S:=48315) (T:=292820)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery b0 (joinEvery b1 b2)) (joinEvery b3 (joinEvery b4 b5))) (joinEvery (joinEvery b6 (joinEvery b7 b8)) (joinEvery (joinEvery b9 b10) (joinEvery b11 b12)))) (joinEvery (joinEvery (joinEvery b13 (joinEvery b14 b15)) (joinEvery b16 (joinEvery b17 b18))) (joinEvery (joinEvery b19 (joinEvery b20 b21)) (joinEvery (joinEvery b22 b23) (joinEvery b24 b25)))))
#print axioms checked
end OMA.RankThreeAt11E4P3
