import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E39P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 3 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b1 : every 4 6 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b2 : every 7 9 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b3 : every 10 12 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b4 : every 13 15 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b5 : every 16 18 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b6 : every 19 21 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b7 : every 22 24 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b8 : every 25 27 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b9 : every 28 28 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b10 : every 29 29 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b11 : every 30 30 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b12 : every 31 31 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b13 : every 32 32 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b14 : every 33 33 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b15 : every 34 34 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b16 : every 35 35 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b17 : every 36 36 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b18 : every 37 37 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b19 : every 38 38 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b20 : every 39 39 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b21 : every 40 40 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b22 : every 41 41 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b23 : every 42 42 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b24 : every 43 43 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b25 : every 44 44 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b26 : every 45 45 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b27 : every 46 46 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b28 : every 47 47 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b29 : every 48 48 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b30 : every 49 49 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b31 : every 50 50 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b32 : every 51 51 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
private theorem b33 : every 52 52 (movingRow 1200569464081871719100 18236498188585393200 648408824483036202720 13)=true := by decide +kernel
theorem checked : test 3 39 13=true :=
  movingTest (h:=8105110306037952534) (A:=1200569464081871719100) (S:=18236498188585393200) (T:=648408824483036202720)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 b3)) (joinEvery (joinEvery b4 b5) (joinEvery b6 b7))) (joinEvery (joinEvery (joinEvery b8 b9) (joinEvery b10 b11)) (joinEvery (joinEvery b12 b13) (joinEvery b14 (joinEvery b15 b16))))) (joinEvery (joinEvery (joinEvery (joinEvery b17 b18) (joinEvery b19 b20)) (joinEvery (joinEvery b21 b22) (joinEvery b23 b24))) (joinEvery (joinEvery (joinEvery b25 b26) (joinEvery b27 b28)) (joinEvery (joinEvery b29 b30) (joinEvery b31 (joinEvery b32 b33))))))
#print axioms checked
end OMA.RankThreeAt3E39P13
