import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt13E7P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 3 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b1 : every 4 6 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b2 : every 7 9 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b3 : every 10 13 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b4 : every 14 17 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b5 : every 18 21 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b6 : every 22 25 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b7 : every 26 28 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b8 : every 29 31 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b9 : every 32 34 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b10 : every 35 37 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b11 : every 38 40 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b12 : every 41 43 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b13 : every 44 46 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b14 : every 47 49 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b15 : every 50 52 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b16 : every 53 55 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b17 : every 56 58 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b18 : every 59 61 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b19 : every 62 64 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b20 : every 65 67 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b21 : every 68 70 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b22 : every 71 73 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b23 : every 74 76 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b24 : every 77 79 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b25 : every 80 82 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b26 : every 83 85 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b27 : every 86 88 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b28 : every 89 91 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b29 : every 92 94 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b30 : every 95 97 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b31 : every 98 98 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b32 : every 99 99 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b33 : every 100 100 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b34 : every 101 101 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b35 : every 102 102 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b36 : every 103 103 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b37 : every 104 104 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b38 : every 105 105 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b39 : every 106 106 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b40 : every 107 107 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b41 : every 108 108 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b42 : every 109 109 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b43 : every 110 110 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b44 : every 111 111 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b45 : every 112 112 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b46 : every 113 113 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b47 : every 114 114 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b48 : every 115 115 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b49 : every 116 116 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b50 : every 117 117 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b51 : every 118 118 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b52 : every 119 119 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b53 : every 120 120 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b54 : every 121 121 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b55 : every 122 122 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b56 : every 123 123 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b57 : every 124 124 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b58 : every 125 125 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b59 : every 126 126 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b60 : every 127 127 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b61 : every 128 128 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b62 : every 129 129 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b63 : every 130 130 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b64 : every 131 131 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
private theorem b65 : every 132 132 (movingRow 2690778420 203932680 2007952544 3)=true := by decide +kernel
theorem checked : test 13 7 3=true :=
  movingTest (h:=125497034) (A:=2690778420) (S:=203932680) (T:=2007952544)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 b3)) (joinEvery (joinEvery b4 b5) (joinEvery b6 b7))) (joinEvery (joinEvery (joinEvery b8 b9) (joinEvery b10 b11)) (joinEvery (joinEvery b12 b13) (joinEvery b14 b15)))) (joinEvery (joinEvery (joinEvery (joinEvery b16 b17) (joinEvery b18 b19)) (joinEvery (joinEvery b20 b21) (joinEvery b22 b23))) (joinEvery (joinEvery (joinEvery b24 b25) (joinEvery b26 b27)) (joinEvery (joinEvery b28 b29) (joinEvery b30 (joinEvery b31 b32)))))) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b33 b34) (joinEvery b35 b36)) (joinEvery (joinEvery b37 b38) (joinEvery b39 b40))) (joinEvery (joinEvery (joinEvery b41 b42) (joinEvery b43 b44)) (joinEvery (joinEvery b45 b46) (joinEvery b47 b48)))) (joinEvery (joinEvery (joinEvery (joinEvery b49 b50) (joinEvery b51 b52)) (joinEvery (joinEvery b53 b54) (joinEvery b55 b56))) (joinEvery (joinEvery (joinEvery b57 b58) (joinEvery b59 b60)) (joinEvery (joinEvery b61 b62) (joinEvery b63 (joinEvery b64 b65)))))))
#print axioms checked
end OMA.RankThreeAt13E7P3
