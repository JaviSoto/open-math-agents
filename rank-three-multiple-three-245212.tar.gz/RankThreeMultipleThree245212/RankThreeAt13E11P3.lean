import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt13E11P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 2 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b1 : every 3 4 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b2 : every 5 6 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b3 : every 7 9 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b4 : every 10 12 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b5 : every 13 15 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b6 : every 16 18 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b7 : every 19 21 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b8 : every 22 24 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b9 : every 25 27 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b10 : every 28 30 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b11 : every 31 33 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b12 : every 34 36 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b13 : every 37 39 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b14 : every 40 42 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b15 : every 43 45 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b16 : every 46 48 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b17 : every 49 51 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b18 : every 52 55 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b19 : every 56 57 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b20 : every 58 58 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b21 : every 59 59 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b22 : every 60 60 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b23 : every 61 61 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b24 : every 62 62 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b25 : every 63 63 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b26 : every 64 64 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b27 : every 65 65 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b28 : every 66 66 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b29 : every 67 67 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b30 : every 68 68 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b31 : every 69 69 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b32 : every 70 70 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b33 : every 71 71 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b34 : every 72 72 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b35 : every 73 73 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b36 : every 74 74 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b37 : every 75 75 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b38 : every 76 76 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b39 : every 77 77 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
private theorem b40 : every 78 78 (movingRow 115681464323430 5824521280620 86023698913776 3)=true := by decide +kernel
theorem checked : test 13 11 3=true :=
  movingTest (h:=3584320788074) (A:=115681464323430) (S:=5824521280620) (T:=86023698913776)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 (joinEvery b3 b4))) (joinEvery (joinEvery b5 b6) (joinEvery b7 (joinEvery b8 b9)))) (joinEvery (joinEvery (joinEvery b10 b11) (joinEvery b12 (joinEvery b13 b14))) (joinEvery (joinEvery b15 b16) (joinEvery b17 (joinEvery b18 b19))))) (joinEvery (joinEvery (joinEvery (joinEvery b20 b21) (joinEvery b22 (joinEvery b23 b24))) (joinEvery (joinEvery b25 b26) (joinEvery b27 (joinEvery b28 b29)))) (joinEvery (joinEvery (joinEvery b30 b31) (joinEvery b32 (joinEvery b33 b34))) (joinEvery (joinEvery b35 (joinEvery b36 b37)) (joinEvery b38 (joinEvery b39 b40))))))
#print axioms checked
end OMA.RankThreeAt13E11P3
