import RankThreeFourSmallRow1245212
import RankThreeFourSmallRow2245212
import RankThreeFourSmallRow3245212
import RankThreeFourSmallRow4245212
import RankThreeFourSmallCompact5From5
import RankThreeFourSmallCompact6From5
import RankThreeFourSmallCompact6From260
import RankThreeFourSmallCompact6From460
import RankThreeFourSmallSeven5
import RankThreeFourSmallSeven252
import RankThreeFourSmallSeven400
import RankThreeFourSmallSeven600
import RankThreeFourSmallSeven800
import RankThreeFourSmallOrder245212

/-! Every 4·3^a·p^b·q^d with 5≤p<q and positive exponents fails the OEIS balance. -/
namespace OMA.RankThreeFourSmallSolution245212
open Nat ArithmeticFunction OMA.Smooth245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallHarmonic245212
open scoped ArithmeticFunction.sigma
open private OMA.CofactorEulerPair245212.checked from CofactorEulerDecision245212
open private OMA.Large245212.moments from LargeExact245212
open OMA.RankThreeFourSmallCompactTables245212
open OMA.RankThreeMiddle245212 (joinEvery)

private theorem checked_row {p q a b c L : ℕ} (hp : p.Prime) (hq : q.Prime) (lo : 5≤p) (pq : p<q)
    (bp : 0<b) (cp : 0<c) (cap : OeisA245212.a (4*3^a*p^b*q^c)=(σ 1 (4*3^a*p^b*q^c):ℤ) → p≤L ∨
      OMA.RankThreeFourSmallHarmonic245212.primeCut (17*OMA.Large245212.wt 3 a)
        (7*OMA.Large245212.sig 3 a) (2*(12*OMA.Large245212.tax 3 a))≤L)
    (ok : every 5 L (OMA.RankThreeFourSmallCompact245212.run (4*3^a)
      (17*OMA.Large245212.wt 3 a) (7*OMA.Large245212.sig 3 a) (12*OMA.Large245212.tax 3 a))=true) :
    OeisA245212.a (4*3^a*p^b*q^c)≠(σ 1 (4*3^a*p^b*q^c):ℤ) := by
  intro eqn
  have cop (r : ℕ) (hr : r.Prime) (low : 5≤r) : (4*3^a).Coprime r :=
    (((coprime_primes prime_two hr).mpr (by omega)).pow_left 2).mul_left
      (((coprime_primes (by decide : Nat.Prime 3) hr).mpr (by omega)).pow_left a)
  have c3 : (4:ℕ).Coprime (3^a) := (by decide : Nat.Coprime 4 3).pow_right a
  have base : W 4=17 ∧ σ 1 4=7 ∧ σ 0 4=3 := by decide +kernel
  obtain ⟨y,x⟩:=OMA.Large245212.moments (by decide : Nat.Prime 3) a
  have w : W (4*3^a)=17*OMA.Large245212.wt 3 a := by rw [w_mult.map_mul_of_coprime c3,base.1,x]
  have s : σ 1 (4*3^a)=7*OMA.Large245212.sig 3 a := by rw [isMultiplicative_sigma.map_mul_of_coprime c3,base.2.1,y]
  have t : (4*3^a)*σ 0 (4*3^a)=12*OMA.Large245212.tax 3 a := by
    rw [isMultiplicative_sigma.map_mul_of_coprime c3,base.2.2,sigma_zero_apply_prime_pow (by decide : Nat.Prime 3)]
    unfold OMA.Large245212.tax;ring
  have good:=cop p hp lo
  have other:=cop q hq (by omega)
  have pos : 0<4*3^a := by positivity
  have pm:=first_prime pos hp hq good other pq bp cp eqn
  have lim : p≤L := (cap eqn).elim id (fun bound=>pm.trans (by simpa [w,s,t,mul_assoc] using bound))
  apply OMA.RankThreeFourSmallCompact245212.sound pos hp hq (by omega) good other pq bp cp _ eqn
  apply OMA.CofactorEulerPair245212.checked _ lo lim
  simpa only [w,s,t] using ok


theorem no_least_three {p q a b c : ℕ} (hp : p.Prime) (hq : q.Prime) (lo : 5≤p) (pq : p<q)
    (ap : 0<a) (bp : 0<b) (cp : 0<c) :
    OeisA245212.a (4*3^a*p^b*q^c)≠(σ 1 (4*3^a*p^b*q^c):ℤ) := by
  intro eqn
  have small:=OMA.RankThreeFourSmallOriginal245212.exponent hp hq lo pq eqn
  interval_cases a
  · exact OMA.RankThreeFourSmallOriginal245212.checked_row hp hq lo pq bp cp OMA.RankThreeFourSmallTables245212.at1 eqn
  · exact OMA.RankThreeFourSmallOriginal245212.checked_row hp hq lo pq bp cp OMA.RankThreeFourSmallTables245212.at2 eqn
  · exact OMA.RankThreeFourSmallOriginal245212.checked_row hp hq lo pq bp cp OMA.RankThreeFourSmallTables245212.at3 eqn
  · exact OMA.RankThreeFourSmallOriginal245212.checked_row hp hq lo pq bp cp OMA.RankThreeFourSmallTables245212.at4 eqn
  · exact checked_row hp hq lo pq bp cp (fun _=>Or.inr (by decide +kernel)) span5_5_259 eqn
  · exact checked_row hp hq lo pq bp cp (fun e=>Or.inl (OMA.RankThreeFourSmallOrder245212.first_six hp hq lo pq bp cp e))
      (joinEvery span6_5_259 (joinEvery span6_260_459 span6_460_678)) eqn
  · exact checked_row hp hq lo pq bp cp (fun e=>Or.inl (OMA.RankThreeFourSmallOrder245212.first hp hq lo pq bp cp e))
      (joinEvery span7_5_251 (joinEvery span7_252_399 (joinEvery span7_400_599 (joinEvery span7_600_799 span7_800_964)))) eqn

end OMA.RankThreeFourSmallSolution245212
#print axioms OMA.RankThreeFourSmallSolution245212.no_least_three
