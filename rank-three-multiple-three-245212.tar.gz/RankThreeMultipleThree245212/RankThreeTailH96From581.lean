import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_581_0 : every 581 586 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_581_1 : every 588 85 (quick 96 2247 252 1152 587)=true := by decide +kernel
private theorem b96_581_2 : every 1 25 (far 96 2247 252 1152 587 588 18)=true := by decide +kernel
private theorem b96_581_3 : every 26 50 (far 96 2247 252 1152 587 588 18)=true := by decide +kernel
private theorem b96_581_4 : every 51 75 (far 96 2247 252 1152 587 588 18)=true := by decide +kernel
private theorem b96_581_5 : every 76 100 (far 96 2247 252 1152 587 588 18)=true := by decide +kernel
private theorem b96_581_6 : every 101 125 (far 96 2247 252 1152 587 588 18)=true := by decide +kernel
private theorem b96_581_7 : every 126 133 (far 96 2247 252 1152 587 588 18)=true := by decide +kernel
private theorem r96_587 : every 587 587 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 587=true := by change (every 588 85 (quick 96 2247 252 1152 587) && every 1 133 (far 96 2247 252 1152 587 588 18))=true; rw [Bool.and_eq_true]; exact ⟨b96_581_1,(joinEvery (joinEvery b96_581_2 (joinEvery b96_581_3 b96_581_4)) (joinEvery b96_581_5 (joinEvery b96_581_6 b96_581_7)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=587 by omega] using yes
private theorem b96_581_8 : every 588 592 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_581_9 : every 594 85 (quick 96 2247 252 1152 593)=true := by decide +kernel
private theorem b96_581_10 : every 1 25 (far 96 2247 252 1152 593 594 18)=true := by decide +kernel
private theorem b96_581_11 : every 26 50 (far 96 2247 252 1152 593 594 18)=true := by decide +kernel
private theorem b96_581_12 : every 51 75 (far 96 2247 252 1152 593 594 18)=true := by decide +kernel
private theorem b96_581_13 : every 76 100 (far 96 2247 252 1152 593 594 18)=true := by decide +kernel
private theorem b96_581_14 : every 101 125 (far 96 2247 252 1152 593 594 18)=true := by decide +kernel
private theorem b96_581_15 : every 126 134 (far 96 2247 252 1152 593 594 18)=true := by decide +kernel
private theorem r96_593 : every 593 593 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 593=true := by change (every 594 85 (quick 96 2247 252 1152 593) && every 1 134 (far 96 2247 252 1152 593 594 18))=true; rw [Bool.and_eq_true]; exact ⟨b96_581_9,(joinEvery (joinEvery b96_581_10 (joinEvery b96_581_11 b96_581_12)) (joinEvery b96_581_13 (joinEvery b96_581_14 b96_581_15)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=593 by omega] using yes
private theorem b96_581_16 : every 594 598 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_581_17 : every 600 85 (quick 96 2247 252 1152 599)=true := by decide +kernel
private theorem b96_581_18 : every 1 25 (far 96 2247 252 1152 599 600 18)=true := by decide +kernel
private theorem b96_581_19 : every 26 50 (far 96 2247 252 1152 599 600 18)=true := by decide +kernel
private theorem b96_581_20 : every 51 75 (far 96 2247 252 1152 599 600 18)=true := by decide +kernel
private theorem b96_581_21 : every 76 100 (far 96 2247 252 1152 599 600 18)=true := by decide +kernel
private theorem b96_581_22 : every 101 125 (far 96 2247 252 1152 599 600 18)=true := by decide +kernel
private theorem b96_581_23 : every 126 136 (far 96 2247 252 1152 599 600 18)=true := by decide +kernel
private theorem r96_599 : every 599 599 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 599=true := by change (every 600 85 (quick 96 2247 252 1152 599) && every 1 136 (far 96 2247 252 1152 599 600 18))=true; rw [Bool.and_eq_true]; exact ⟨b96_581_17,(joinEvery (joinEvery b96_581_18 (joinEvery b96_581_19 b96_581_20)) (joinEvery b96_581_21 (joinEvery b96_581_22 b96_581_23)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=599 by omega] using yes
private theorem b96_581_24 : every 600 600 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_581_25 : every 602 85 (quick 96 2247 252 1152 601)=true := by decide +kernel
private theorem b96_581_26 : every 1 25 (far 96 2247 252 1152 601 602 18)=true := by decide +kernel
private theorem b96_581_27 : every 26 50 (far 96 2247 252 1152 601 602 18)=true := by decide +kernel
private theorem b96_581_28 : every 51 75 (far 96 2247 252 1152 601 602 18)=true := by decide +kernel
private theorem b96_581_29 : every 76 100 (far 96 2247 252 1152 601 602 18)=true := by decide +kernel
private theorem b96_581_30 : every 101 125 (far 96 2247 252 1152 601 602 18)=true := by decide +kernel
private theorem b96_581_31 : every 126 136 (far 96 2247 252 1152 601 602 18)=true := by decide +kernel
private theorem r96_601 : every 601 601 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 601=true := by change (every 602 85 (quick 96 2247 252 1152 601) && every 1 136 (far 96 2247 252 1152 601 602 18))=true; rw [Bool.and_eq_true]; exact ⟨b96_581_25,(joinEvery (joinEvery b96_581_26 (joinEvery b96_581_27 b96_581_28)) (joinEvery b96_581_29 (joinEvery b96_581_30 b96_581_31)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=601 by omega] using yes
private theorem b96_581_32 : every 602 604 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_581_604 : every 581 604 (run 96 2247 252 1152)=true := (joinEvery (joinEvery (joinEvery b96_581_0 r96_587) (joinEvery b96_581_8 r96_593)) (joinEvery (joinEvery b96_581_16 r96_599) (joinEvery b96_581_24 (joinEvery r96_601 b96_581_32))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_581_604
