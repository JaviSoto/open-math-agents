import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b24_5_0 : every 1 3 (movingRow 343 60 192 5)=true := by decide +kernel
private theorem r24_5 : every 5 5 (run 24 343 60 192)=true := by
  have yes : run 24 343 60 192 5=true := b24_5_0
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=5 by omega] using yes
private theorem b24_5_1 : every 6 6 (run 24 343 60 192)=true := by decide +kernel
private theorem b24_5_2 : every 1 7 (movingRow 343 60 192 7)=true := by decide +kernel
private theorem r24_7 : every 7 7 (run 24 343 60 192)=true := by
  have yes : run 24 343 60 192 7=true := b24_5_2
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=7 by omega] using yes
private theorem b24_5_3 : every 8 10 (run 24 343 60 192)=true := by decide +kernel
private theorem b24_5_4 : every 12 113 (quick 24 343 60 192 11)=true := by decide +kernel
private theorem b24_5_5 : every 1 5 (far 24 343 60 192 11 114 35)=true := by decide +kernel
private theorem r24_11 : every 11 11 (run 24 343 60 192)=true := by
  have yes : run 24 343 60 192 11=true := by change (every 12 113 (quick 24 343 60 192 11) && every 1 5 (far 24 343 60 192 11 114 35))=true; rw [Bool.and_eq_true]; exact ⟨b24_5_4,b24_5_5⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=11 by omega] using yes
private theorem b24_5_6 : every 12 12 (run 24 343 60 192)=true := by decide +kernel
private theorem b24_5_7 : every 14 60 (quick 24 343 60 192 13)=true := by decide +kernel
private theorem b24_5_8 : every 1 6 (far 24 343 60 192 13 61 19)=true := by decide +kernel
private theorem r24_13 : every 13 13 (run 24 343 60 192)=true := by
  have yes : run 24 343 60 192 13=true := by change (every 14 60 (quick 24 343 60 192 13) && every 1 6 (far 24 343 60 192 13 61 19))=true; rw [Bool.and_eq_true]; exact ⟨b24_5_7,b24_5_8⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=13 by omega] using yes
private theorem b24_5_9 : every 14 16 (run 24 343 60 192)=true := by decide +kernel
private theorem b24_5_10 : every 18 38 (quick 24 343 60 192 17)=true := by decide +kernel
private theorem b24_5_11 : every 1 7 (far 24 343 60 192 17 39 12)=true := by decide +kernel
private theorem r24_17 : every 17 17 (run 24 343 60 192)=true := by
  have yes : run 24 343 60 192 17=true := by change (every 18 38 (quick 24 343 60 192 17) && every 1 7 (far 24 343 60 192 17 39 12))=true; rw [Bool.and_eq_true]; exact ⟨b24_5_10,b24_5_11⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=17 by omega] using yes
private theorem b24_5_12 : every 18 18 (run 24 343 60 192)=true := by decide +kernel
private theorem b24_5_13 : every 20 33 (quick 24 343 60 192 19)=true := by decide +kernel
private theorem b24_5_14 : every 1 8 (far 24 343 60 192 19 34 10)=true := by decide +kernel
private theorem r24_19 : every 19 19 (run 24 343 60 192)=true := by
  have yes : run 24 343 60 192 19=true := by change (every 20 33 (quick 24 343 60 192 19) && every 1 8 (far 24 343 60 192 19 34 10))=true; rw [Bool.and_eq_true]; exact ⟨b24_5_13,b24_5_14⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=19 by omega] using yes
private theorem b24_5_15 : every 20 22 (run 24 343 60 192)=true := by decide +kernel
private theorem b24_5_16 : every 24 29 (quick 24 343 60 192 23)=true := by decide +kernel
private theorem b24_5_17 : every 1 9 (far 24 343 60 192 23 30 9)=true := by decide +kernel
private theorem r24_23 : every 23 23 (run 24 343 60 192)=true := by
  have yes : run 24 343 60 192 23=true := by change (every 24 29 (quick 24 343 60 192 23) && every 1 9 (far 24 343 60 192 23 30 9))=true; rw [Bool.and_eq_true]; exact ⟨b24_5_16,b24_5_17⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=23 by omega] using yes
private theorem b24_5_18 : every 24 28 (run 24 343 60 192)=true := by decide +kernel
theorem span24_5_28 : every 5 28 (run 24 343 60 192)=true := (joinEvery (joinEvery (joinEvery r24_5 (joinEvery b24_5_1 r24_7)) (joinEvery (joinEvery b24_5_3 r24_11) (joinEvery b24_5_6 r24_13))) (joinEvery (joinEvery b24_5_9 (joinEvery r24_17 b24_5_12)) (joinEvery (joinEvery r24_19 b24_5_15) (joinEvery r24_23 b24_5_18))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span24_5_28
