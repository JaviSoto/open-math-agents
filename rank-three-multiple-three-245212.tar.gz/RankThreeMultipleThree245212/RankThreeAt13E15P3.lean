import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt13E15P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 1 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b1 : every 2 2 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b2 : every 3 3 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b3 : every 4 5 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b4 : every 6 7 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b5 : every 8 9 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b6 : every 10 11 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b7 : every 12 13 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b8 : every 14 15 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b9 : every 16 18 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b10 : every 19 21 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b11 : every 22 24 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b12 : every 25 27 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b13 : every 28 30 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b14 : every 31 33 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b15 : every 34 36 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b16 : every 37 39 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b17 : every 40 42 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b18 : every 43 45 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b19 : every 46 47 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b20 : every 48 48 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b21 : every 49 49 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b22 : every 50 50 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b23 : every 51 51 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b24 : every 52 52 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b25 : every 53 53 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b26 : every 54 54 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b27 : every 55 55 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b28 : every 56 56 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b29 : every 57 57 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b30 : every 58 58 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b31 : every 59 59 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b32 : every 60 60 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b33 : every 61 61 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b34 : every 62 62 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b35 : every 63 63 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b36 : every 64 64 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
private theorem b37 : every 65 65 (movingRow 4413005984513449640 166354152295794960 3275897152901808448 3)=true := by decide +kernel
theorem checked : test 13 15 3=true :=
  movingTest (h:=102371786028181514) (A:=4413005984513449640) (S:=166354152295794960) (T:=3275897152901808448)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 b3)) (joinEvery (joinEvery b4 b5) (joinEvery b6 (joinEvery b7 b8)))) (joinEvery (joinEvery (joinEvery b9 b10) (joinEvery b11 (joinEvery b12 b13))) (joinEvery (joinEvery b14 b15) (joinEvery b16 (joinEvery b17 b18))))) (joinEvery (joinEvery (joinEvery (joinEvery b19 b20) (joinEvery b21 b22)) (joinEvery (joinEvery b23 b24) (joinEvery b25 (joinEvery b26 b27)))) (joinEvery (joinEvery (joinEvery b28 b29) (joinEvery b30 (joinEvery b31 b32))) (joinEvery (joinEvery b33 b34) (joinEvery b35 (joinEvery b36 b37))))))
#print axioms checked
end OMA.RankThreeAt13E15P3
