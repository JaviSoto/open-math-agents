import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt13E6P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 3 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b1 : every 4 6 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b2 : every 7 10 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b3 : every 11 14 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b4 : every 15 18 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b5 : every 19 22 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b6 : every 23 26 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b7 : every 27 29 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b8 : every 30 32 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b9 : every 33 35 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b10 : every 36 38 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b11 : every 39 41 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b12 : every 42 44 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b13 : every 45 47 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b14 : every 48 50 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b15 : every 51 53 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b16 : every 54 56 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b17 : every 57 59 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b18 : every 60 62 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b19 : every 63 65 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b20 : every 66 67 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b21 : every 68 69 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b22 : every 70 71 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b23 : every 72 73 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b24 : every 74 75 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b25 : every 76 77 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b26 : every 78 79 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b27 : every 80 81 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b28 : every 82 83 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b29 : every 84 85 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b30 : every 86 87 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b31 : every 88 89 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b32 : every 90 91 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b33 : every 92 93 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b34 : every 94 95 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b35 : every 96 97 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b36 : every 98 99 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b37 : every 100 101 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b38 : every 102 103 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b39 : every 104 105 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b40 : every 106 107 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b41 : every 108 109 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b42 : every 110 111 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b43 : every 112 113 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b44 : every 114 115 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b45 : every 116 117 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b46 : every 118 119 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b47 : every 120 121 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b48 : every 122 123 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b49 : every 124 125 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b50 : every 126 127 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b51 : every 128 129 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b52 : every 130 131 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b53 : every 132 133 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b54 : every 134 135 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b55 : every 136 137 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b56 : every 138 140 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b57 : every 141 141 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b58 : every 142 142 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b59 : every 143 143 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b60 : every 144 144 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b61 : every 145 145 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b62 : every 146 146 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b63 : every 147 147 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b64 : every 148 148 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b65 : every 149 149 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b66 : every 150 150 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b67 : every 151 151 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b68 : every 152 152 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b69 : every 153 153 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b70 : every 154 154 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b71 : every 155 155 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b72 : every 156 156 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b73 : every 157 157 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b74 : every 158 158 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b75 : every 159 159 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b76 : every 160 160 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b77 : every 161 161 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b78 : every 162 162 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b79 : every 163 163 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b80 : every 164 164 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b81 : every 165 165 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b82 : every 166 166 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b83 : every 167 167 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b84 : every 168 168 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b85 : every 169 169 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b86 : every 170 170 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b87 : every 171 171 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b88 : every 172 172 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b89 : every 173 173 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b90 : every 174 174 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b91 : every 175 175 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b92 : every 176 176 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b93 : every 177 177 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b94 : every 178 178 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b95 : every 179 179 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b96 : every 180 180 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b97 : every 181 181 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b98 : every 182 182 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b99 : every 183 183 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b100 : every 184 184 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b101 : every 185 185 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b102 : every 186 186 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b103 : every 187 187 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b104 : every 188 188 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
private theorem b105 : every 189 189 (movingRow 180837740 15687129 135150652 3)=true := by decide +kernel
theorem checked : test 13 6 3=true :=
  movingTest (h:=9653618) (A:=180837740) (S:=15687129) (T:=135150652)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 (joinEvery b1 b2)) (joinEvery b3 (joinEvery b4 b5))) (joinEvery (joinEvery b6 (joinEvery b7 b8)) (joinEvery (joinEvery b9 b10) (joinEvery b11 b12)))) (joinEvery (joinEvery (joinEvery b13 (joinEvery b14 b15)) (joinEvery b16 (joinEvery b17 b18))) (joinEvery (joinEvery b19 (joinEvery b20 b21)) (joinEvery (joinEvery b22 b23) (joinEvery b24 b25))))) (joinEvery (joinEvery (joinEvery (joinEvery b26 (joinEvery b27 b28)) (joinEvery b29 (joinEvery b30 b31))) (joinEvery (joinEvery b32 (joinEvery b33 b34)) (joinEvery (joinEvery b35 b36) (joinEvery b37 b38)))) (joinEvery (joinEvery (joinEvery b39 (joinEvery b40 b41)) (joinEvery (joinEvery b42 b43) (joinEvery b44 b45))) (joinEvery (joinEvery b46 (joinEvery b47 b48)) (joinEvery (joinEvery b49 b50) (joinEvery b51 b52)))))) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b53 (joinEvery b54 b55)) (joinEvery b56 (joinEvery b57 b58))) (joinEvery (joinEvery b59 (joinEvery b60 b61)) (joinEvery (joinEvery b62 b63) (joinEvery b64 b65)))) (joinEvery (joinEvery (joinEvery b66 (joinEvery b67 b68)) (joinEvery b69 (joinEvery b70 b71))) (joinEvery (joinEvery b72 (joinEvery b73 b74)) (joinEvery (joinEvery b75 b76) (joinEvery b77 b78))))) (joinEvery (joinEvery (joinEvery (joinEvery b79 (joinEvery b80 b81)) (joinEvery b82 (joinEvery b83 b84))) (joinEvery (joinEvery b85 (joinEvery b86 b87)) (joinEvery (joinEvery b88 b89) (joinEvery b90 b91)))) (joinEvery (joinEvery (joinEvery b92 (joinEvery b93 b94)) (joinEvery (joinEvery b95 b96) (joinEvery b97 b98))) (joinEvery (joinEvery b99 (joinEvery b100 b101)) (joinEvery (joinEvery b102 b103) (joinEvery b104 b105)))))))
#print axioms checked
end OMA.RankThreeAt13E6P3
