import RankThreeAt3E31P13Split

/-! Connect the parallel certificate for the near-resonant (3^31,13)
cofactor row to the middle-prime table. -/
namespace OMA.RankThreeAt3E31P13
theorem checked : OMA.RankThreeMiddle245212.test 3 31 13=true :=
  OMA.RankThreeAt3E31P13Split.checked
end OMA.RankThreeAt3E31P13
