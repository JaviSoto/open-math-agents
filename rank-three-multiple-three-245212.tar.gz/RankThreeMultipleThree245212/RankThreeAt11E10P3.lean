import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt11E10P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 2 (movingRow 1554948604830 85593501183 1141246682444 3)=true := by decide +kernel
private theorem b1 : every 3 4 (movingRow 1554948604830 85593501183 1141246682444 3)=true := by decide +kernel
private theorem b2 : every 5 7 (movingRow 1554948604830 85593501183 1141246682444 3)=true := by decide +kernel
private theorem b3 : every 8 11 (movingRow 1554948604830 85593501183 1141246682444 3)=true := by decide +kernel
private theorem b4 : every 12 15 (movingRow 1554948604830 85593501183 1141246682444 3)=true := by decide +kernel
private theorem b5 : every 16 20 (movingRow 1554948604830 85593501183 1141246682444 3)=true := by decide +kernel
private theorem b6 : every 21 23 (movingRow 1554948604830 85593501183 1141246682444 3)=true := by decide +kernel
private theorem b7 : every 24 24 (movingRow 1554948604830 85593501183 1141246682444 3)=true := by decide +kernel
private theorem b8 : every 25 25 (movingRow 1554948604830 85593501183 1141246682444 3)=true := by decide +kernel
private theorem b9 : every 26 26 (movingRow 1554948604830 85593501183 1141246682444 3)=true := by decide +kernel
private theorem b10 : every 27 27 (movingRow 1554948604830 85593501183 1141246682444 3)=true := by decide +kernel
private theorem b11 : every 28 28 (movingRow 1554948604830 85593501183 1141246682444 3)=true := by decide +kernel
private theorem b12 : every 29 29 (movingRow 1554948604830 85593501183 1141246682444 3)=true := by decide +kernel
private theorem b13 : every 30 30 (movingRow 1554948604830 85593501183 1141246682444 3)=true := by decide +kernel
private theorem b14 : every 31 31 (movingRow 1554948604830 85593501183 1141246682444 3)=true := by decide +kernel
theorem checked : test 11 10 3=true :=
  movingTest (h:=51874849202) (A:=1554948604830) (S:=85593501183) (T:=1141246682444)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery b0 (joinEvery b1 b2)) (joinEvery (joinEvery b3 b4) (joinEvery b5 b6))) (joinEvery (joinEvery (joinEvery b7 b8) (joinEvery b9 b10)) (joinEvery (joinEvery b11 b12) (joinEvery b13 b14))))
#print axioms checked
end OMA.RankThreeAt11E10P3
