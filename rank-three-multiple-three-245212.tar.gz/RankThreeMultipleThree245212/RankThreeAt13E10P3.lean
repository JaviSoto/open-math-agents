import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt13E10P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 2 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b1 : every 3 4 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b2 : every 5 6 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b3 : every 7 9 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b4 : every 10 12 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b5 : every 13 15 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b6 : every 16 18 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b7 : every 19 21 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b8 : every 22 24 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b9 : every 25 27 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b10 : every 28 30 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b11 : every 31 33 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b12 : every 34 36 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b13 : every 37 39 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b14 : every 40 42 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b15 : every 43 45 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b16 : every 46 48 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b17 : every 49 51 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b18 : every 52 54 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b19 : every 55 57 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b20 : every 58 61 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b21 : every 62 62 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b22 : every 63 63 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b23 : every 64 64 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b24 : every 65 65 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b25 : every 66 66 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b26 : every 67 67 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b27 : every 68 68 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b28 : every 69 69 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b29 : every 70 70 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b30 : every 71 71 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b31 : every 72 72 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b32 : every 73 73 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b33 : every 74 74 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b34 : every 75 75 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b35 : every 76 76 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b36 : every 77 77 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b37 : every 78 78 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b38 : every 79 79 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b39 : every 80 80 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b40 : every 81 81 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b41 : every 82 82 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b42 : every 83 83 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
private theorem b43 : every 84 84 (movingRow 8151840681210 448040098509 6065773641356 3)=true := by decide +kernel
theorem checked : test 13 10 3=true :=
  movingTest (h:=275716983698) (A:=8151840681210) (S:=448040098509) (T:=6065773641356)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 (joinEvery b3 b4))) (joinEvery (joinEvery b5 (joinEvery b6 b7)) (joinEvery b8 (joinEvery b9 b10)))) (joinEvery (joinEvery (joinEvery b11 b12) (joinEvery b13 (joinEvery b14 b15))) (joinEvery (joinEvery b16 (joinEvery b17 b18)) (joinEvery b19 (joinEvery b20 b21))))) (joinEvery (joinEvery (joinEvery (joinEvery b22 b23) (joinEvery b24 (joinEvery b25 b26))) (joinEvery (joinEvery b27 (joinEvery b28 b29)) (joinEvery b30 (joinEvery b31 b32)))) (joinEvery (joinEvery (joinEvery b33 b34) (joinEvery b35 (joinEvery b36 b37))) (joinEvery (joinEvery b38 (joinEvery b39 b40)) (joinEvery b41 (joinEvery b42 b43))))))
#print axioms checked
end OMA.RankThreeAt13E10P3
