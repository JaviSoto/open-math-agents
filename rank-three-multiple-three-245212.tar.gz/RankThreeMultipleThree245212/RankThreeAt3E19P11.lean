import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E19P11
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 5 (movingRow 169980739550 5230176600 92980917360 11)=true := by decide +kernel
private theorem b1 : every 6 10 (movingRow 169980739550 5230176600 92980917360 11)=true := by decide +kernel
private theorem b2 : every 11 15 (movingRow 169980739550 5230176600 92980917360 11)=true := by decide +kernel
private theorem b3 : every 16 18 (movingRow 169980739550 5230176600 92980917360 11)=true := by decide +kernel
private theorem b4 : every 19 19 (movingRow 169980739550 5230176600 92980917360 11)=true := by decide +kernel
private theorem b5 : every 20 20 (movingRow 169980739550 5230176600 92980917360 11)=true := by decide +kernel
private theorem b6 : every 21 21 (movingRow 169980739550 5230176600 92980917360 11)=true := by decide +kernel
private theorem b7 : every 22 22 (movingRow 169980739550 5230176600 92980917360 11)=true := by decide +kernel
private theorem b8 : every 23 23 (movingRow 169980739550 5230176600 92980917360 11)=true := by decide +kernel
private theorem b9 : every 24 24 (movingRow 169980739550 5230176600 92980917360 11)=true := by decide +kernel
private theorem b10 : every 25 25 (movingRow 169980739550 5230176600 92980917360 11)=true := by decide +kernel
private theorem b11 : every 26 26 (movingRow 169980739550 5230176600 92980917360 11)=true := by decide +kernel
private theorem b12 : every 27 27 (movingRow 169980739550 5230176600 92980917360 11)=true := by decide +kernel
private theorem b13 : every 28 28 (movingRow 169980739550 5230176600 92980917360 11)=true := by decide +kernel
private theorem b14 : every 29 29 (movingRow 169980739550 5230176600 92980917360 11)=true := by decide +kernel
private theorem b15 : every 30 30 (movingRow 169980739550 5230176600 92980917360 11)=true := by decide +kernel
private theorem b16 : every 31 31 (movingRow 169980739550 5230176600 92980917360 11)=true := by decide +kernel
private theorem b17 : every 32 32 (movingRow 169980739550 5230176600 92980917360 11)=true := by decide +kernel
private theorem b18 : every 33 33 (movingRow 169980739550 5230176600 92980917360 11)=true := by decide +kernel
theorem checked : test 3 19 11=true :=
  movingTest (h:=2324522934) (A:=169980739550) (S:=5230176600) (T:=92980917360)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 b3)) (joinEvery (joinEvery b4 b5) (joinEvery b6 (joinEvery b7 b8)))) (joinEvery (joinEvery (joinEvery b9 b10) (joinEvery b11 (joinEvery b12 b13))) (joinEvery (joinEvery b14 b15) (joinEvery b16 (joinEvery b17 b18)))))
#print axioms checked
end OMA.RankThreeAt3E19P11
