import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_653_0 : every 654 85 (quick 96 2247 252 1152 653)=true := by decide +kernel
private theorem b96_653_1 : every 1 25 (far 96 2247 252 1152 653 654 18)=true := by decide +kernel
private theorem b96_653_2 : every 26 50 (far 96 2247 252 1152 653 654 18)=true := by decide +kernel
private theorem b96_653_3 : every 51 75 (far 96 2247 252 1152 653 654 18)=true := by decide +kernel
private theorem b96_653_4 : every 76 100 (far 96 2247 252 1152 653 654 18)=true := by decide +kernel
private theorem b96_653_5 : every 101 125 (far 96 2247 252 1152 653 654 18)=true := by decide +kernel
private theorem b96_653_6 : every 126 148 (far 96 2247 252 1152 653 654 18)=true := by decide +kernel
private theorem r96_653 : every 653 653 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 653=true := by change (every 654 85 (quick 96 2247 252 1152 653) && every 1 148 (far 96 2247 252 1152 653 654 18))=true; rw [Bool.and_eq_true]; exact ⟨b96_653_0,(joinEvery (joinEvery b96_653_1 (joinEvery b96_653_2 b96_653_3)) (joinEvery b96_653_4 (joinEvery b96_653_5 b96_653_6)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=653 by omega] using yes
private theorem b96_653_7 : every 654 658 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_653_8 : every 660 84 (quick 96 2247 252 1152 659)=true := by decide +kernel
private theorem b96_653_9 : every 1 25 (far 96 2247 252 1152 659 660 18)=true := by decide +kernel
private theorem b96_653_10 : every 26 50 (far 96 2247 252 1152 659 660 18)=true := by decide +kernel
private theorem b96_653_11 : every 51 75 (far 96 2247 252 1152 659 660 18)=true := by decide +kernel
private theorem b96_653_12 : every 76 100 (far 96 2247 252 1152 659 660 18)=true := by decide +kernel
private theorem b96_653_13 : every 101 125 (far 96 2247 252 1152 659 660 18)=true := by decide +kernel
private theorem b96_653_14 : every 126 149 (far 96 2247 252 1152 659 660 18)=true := by decide +kernel
private theorem r96_659 : every 659 659 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 659=true := by change (every 660 84 (quick 96 2247 252 1152 659) && every 1 149 (far 96 2247 252 1152 659 660 18))=true; rw [Bool.and_eq_true]; exact ⟨b96_653_8,(joinEvery (joinEvery b96_653_9 (joinEvery b96_653_10 b96_653_11)) (joinEvery b96_653_12 (joinEvery b96_653_13 b96_653_14)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=659 by omega] using yes
private theorem b96_653_15 : every 660 660 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_653_16 : every 662 84 (quick 96 2247 252 1152 661)=true := by decide +kernel
private theorem b96_653_17 : every 1 25 (far 96 2247 252 1152 661 662 18)=true := by decide +kernel
private theorem b96_653_18 : every 26 50 (far 96 2247 252 1152 661 662 18)=true := by decide +kernel
private theorem b96_653_19 : every 51 75 (far 96 2247 252 1152 661 662 18)=true := by decide +kernel
private theorem b96_653_20 : every 76 100 (far 96 2247 252 1152 661 662 18)=true := by decide +kernel
private theorem b96_653_21 : every 101 125 (far 96 2247 252 1152 661 662 18)=true := by decide +kernel
private theorem b96_653_22 : every 126 150 (far 96 2247 252 1152 661 662 18)=true := by decide +kernel
private theorem r96_661 : every 661 661 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 661=true := by change (every 662 84 (quick 96 2247 252 1152 661) && every 1 150 (far 96 2247 252 1152 661 662 18))=true; rw [Bool.and_eq_true]; exact ⟨b96_653_16,(joinEvery (joinEvery b96_653_17 (joinEvery b96_653_18 b96_653_19)) (joinEvery b96_653_20 (joinEvery b96_653_21 b96_653_22)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=661 by omega] using yes
private theorem b96_653_23 : every 662 672 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_653_24 : every 674 84 (quick 96 2247 252 1152 673)=true := by decide +kernel
private theorem b96_653_25 : every 1 25 (far 96 2247 252 1152 673 674 18)=true := by decide +kernel
private theorem b96_653_26 : every 26 50 (far 96 2247 252 1152 673 674 18)=true := by decide +kernel
private theorem b96_653_27 : every 51 75 (far 96 2247 252 1152 673 674 18)=true := by decide +kernel
private theorem b96_653_28 : every 76 100 (far 96 2247 252 1152 673 674 18)=true := by decide +kernel
private theorem b96_653_29 : every 101 125 (far 96 2247 252 1152 673 674 18)=true := by decide +kernel
private theorem b96_653_30 : every 126 150 (far 96 2247 252 1152 673 674 18)=true := by decide +kernel
private theorem b96_653_31 : every 151 152 (far 96 2247 252 1152 673 674 18)=true := by decide +kernel
private theorem r96_673 : every 673 673 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 673=true := by change (every 674 84 (quick 96 2247 252 1152 673) && every 1 152 (far 96 2247 252 1152 673 674 18))=true; rw [Bool.and_eq_true]; exact ⟨b96_653_24,(joinEvery (joinEvery b96_653_25 (joinEvery b96_653_26 b96_653_27)) (joinEvery (joinEvery b96_653_28 b96_653_29) (joinEvery b96_653_30 b96_653_31)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=673 by omega] using yes
private theorem b96_653_32 : every 674 676 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_653_676 : every 653 676 (run 96 2247 252 1152)=true := (joinEvery (joinEvery (joinEvery r96_653 b96_653_7) (joinEvery r96_659 b96_653_15)) (joinEvery (joinEvery r96_661 b96_653_23) (joinEvery r96_673 b96_653_32)))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_653_676
