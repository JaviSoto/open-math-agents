import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E22P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 14 28 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
private theorem b1 : every 29 38 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
private theorem b2 : every 39 46 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
private theorem b3 : every 47 52 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
private theorem b4 : every 53 58 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
private theorem b5 : every 59 60 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
private theorem b6 : every 61 66 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
private theorem b7 : every 67 70 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
private theorem b8 : every 71 72 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
private theorem b9 : every 73 78 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
private theorem b10 : every 79 82 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
private theorem b11 : every 83 88 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
private theorem b12 : every 89 96 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
private theorem b13 : every 97 100 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
private theorem b14 : every 101 102 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
private theorem b15 : every 103 106 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
private theorem b16 : every 107 108 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
private theorem b17 : every 109 112 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
private theorem b18 : every 113 126 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
private theorem b19 : every 127 130 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
private theorem b20 : every 131 136 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
private theorem b21 : every 137 138 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
private theorem b22 : every 139 148 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
private theorem b23 : every 149 150 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
private theorem b24 : every 151 154 (finitePair 62762119218 5295553809020 141214768239 2887057484028 13)=true := by decide +kernel
theorem checked : test 3 22 13=true :=
  fixedTest (h:=62762119218) (A:=5295553809020) (S:=141214768239) (T:=2887057484028)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery b0 (joinEvery b1 b2)) (joinEvery b3 (joinEvery b4 b5))) (joinEvery (joinEvery b6 (joinEvery b7 b8)) (joinEvery b9 (joinEvery b10 b11)))) (joinEvery (joinEvery (joinEvery b12 (joinEvery b13 b14)) (joinEvery b15 (joinEvery b16 b17))) (joinEvery (joinEvery b18 (joinEvery b19 b20)) (joinEvery (joinEvery b21 b22) (joinEvery b23 b24)))))
#print axioms checked
end OMA.RankThreeAt3E22P13
