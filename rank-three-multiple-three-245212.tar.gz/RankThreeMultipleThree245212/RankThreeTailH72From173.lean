import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b72_173_0 : every 174 65 (quick 72 1666 195 864 173)=true := by decide +kernel
private theorem b72_173_1 : every 1 25 (far 72 1666 195 864 173 174 14)=true := by decide +kernel
private theorem b72_173_2 : every 26 42 (far 72 1666 195 864 173 174 14)=true := by decide +kernel
private theorem r72_173 : every 173 173 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 173=true := by change (every 174 65 (quick 72 1666 195 864 173) && every 1 42 (far 72 1666 195 864 173 174 14))=true; rw [Bool.and_eq_true]; exact ⟨b72_173_0,(joinEvery b72_173_1 b72_173_2)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=173 by omega] using yes
private theorem b72_173_3 : every 174 178 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_173_4 : every 180 64 (quick 72 1666 195 864 179)=true := by decide +kernel
private theorem b72_173_5 : every 1 25 (far 72 1666 195 864 179 180 14)=true := by decide +kernel
private theorem b72_173_6 : every 26 43 (far 72 1666 195 864 179 180 14)=true := by decide +kernel
private theorem r72_179 : every 179 179 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 179=true := by change (every 180 64 (quick 72 1666 195 864 179) && every 1 43 (far 72 1666 195 864 179 180 14))=true; rw [Bool.and_eq_true]; exact ⟨b72_173_4,(joinEvery b72_173_5 b72_173_6)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=179 by omega] using yes
private theorem b72_173_7 : every 180 180 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_173_8 : every 182 64 (quick 72 1666 195 864 181)=true := by decide +kernel
private theorem b72_173_9 : every 1 25 (far 72 1666 195 864 181 182 14)=true := by decide +kernel
private theorem b72_173_10 : every 26 44 (far 72 1666 195 864 181 182 14)=true := by decide +kernel
private theorem r72_181 : every 181 181 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 181=true := by change (every 182 64 (quick 72 1666 195 864 181) && every 1 44 (far 72 1666 195 864 181 182 14))=true; rw [Bool.and_eq_true]; exact ⟨b72_173_8,(joinEvery b72_173_9 b72_173_10)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=181 by omega] using yes
private theorem b72_173_11 : every 182 190 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_173_12 : every 192 63 (quick 72 1666 195 864 191)=true := by decide +kernel
private theorem b72_173_13 : every 1 25 (far 72 1666 195 864 191 192 14)=true := by decide +kernel
private theorem b72_173_14 : every 26 46 (far 72 1666 195 864 191 192 14)=true := by decide +kernel
private theorem r72_191 : every 191 191 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 191=true := by change (every 192 63 (quick 72 1666 195 864 191) && every 1 46 (far 72 1666 195 864 191 192 14))=true; rw [Bool.and_eq_true]; exact ⟨b72_173_12,(joinEvery b72_173_13 b72_173_14)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=191 by omega] using yes
private theorem b72_173_15 : every 192 192 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_173_16 : every 194 63 (quick 72 1666 195 864 193)=true := by decide +kernel
private theorem b72_173_17 : every 1 25 (far 72 1666 195 864 193 194 14)=true := by decide +kernel
private theorem b72_173_18 : every 26 46 (far 72 1666 195 864 193 194 14)=true := by decide +kernel
private theorem r72_193 : every 193 193 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 193=true := by change (every 194 63 (quick 72 1666 195 864 193) && every 1 46 (far 72 1666 195 864 193 194 14))=true; rw [Bool.and_eq_true]; exact ⟨b72_173_16,(joinEvery b72_173_17 b72_173_18)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=193 by omega] using yes
private theorem b72_173_19 : every 194 196 (run 72 1666 195 864)=true := by decide +kernel
theorem span72_173_196 : every 173 196 (run 72 1666 195 864)=true := (joinEvery (joinEvery (joinEvery r72_173 b72_173_3) (joinEvery r72_179 (joinEvery b72_173_7 r72_181))) (joinEvery (joinEvery b72_173_11 r72_191) (joinEvery b72_173_15 (joinEvery r72_193 b72_173_19))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span72_173_196
