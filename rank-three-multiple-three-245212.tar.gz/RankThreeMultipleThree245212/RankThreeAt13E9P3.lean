import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt13E9P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 2 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b1 : every 3 4 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b2 : every 5 7 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b3 : every 8 10 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b4 : every 11 13 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b5 : every 14 16 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b6 : every 17 19 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b7 : every 20 22 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b8 : every 23 25 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b9 : every 26 28 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b10 : every 29 31 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b11 : every 32 34 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b12 : every 35 37 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b13 : every 38 40 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b14 : every 41 43 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b15 : every 44 46 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b16 : every 47 49 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b17 : every 50 52 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b18 : every 53 55 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b19 : every 56 58 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b20 : every 59 61 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b21 : every 62 64 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b22 : every 65 68 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b23 : every 69 69 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b24 : every 70 70 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b25 : every 71 71 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b26 : every 72 72 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b27 : every 73 73 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b28 : every 74 74 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b29 : every 75 75 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b30 : every 76 76 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b31 : every 77 77 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b32 : every 78 78 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b33 : every 79 79 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b34 : every 80 80 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b35 : every 81 81 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b36 : every 82 82 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b37 : every 83 83 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b38 : every 84 84 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b39 : every 85 85 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b40 : every 86 86 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b41 : every 87 87 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b42 : every 88 88 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b43 : every 89 89 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b44 : every 90 90 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b45 : every 91 91 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b46 : every 92 92 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
private theorem b47 : every 93 93 (movingRow 569623629515 34464622962 424179974920 3)=true := by decide +kernel
theorem checked : test 13 9 3=true :=
  movingTest (h:=21208998746) (A:=569623629515) (S:=34464622962) (T:=424179974920)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 (joinEvery b1 b2)) (joinEvery b3 (joinEvery b4 b5))) (joinEvery (joinEvery b6 (joinEvery b7 b8)) (joinEvery b9 (joinEvery b10 b11)))) (joinEvery (joinEvery (joinEvery b12 (joinEvery b13 b14)) (joinEvery b15 (joinEvery b16 b17))) (joinEvery (joinEvery b18 (joinEvery b19 b20)) (joinEvery b21 (joinEvery b22 b23))))) (joinEvery (joinEvery (joinEvery (joinEvery b24 (joinEvery b25 b26)) (joinEvery b27 (joinEvery b28 b29))) (joinEvery (joinEvery b30 (joinEvery b31 b32)) (joinEvery b33 (joinEvery b34 b35)))) (joinEvery (joinEvery (joinEvery b36 (joinEvery b37 b38)) (joinEvery b39 (joinEvery b40 b41))) (joinEvery (joinEvery b42 (joinEvery b43 b44)) (joinEvery b45 (joinEvery b46 b47))))))
#print axioms checked
end OMA.RankThreeAt13E9P3
