import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E10P11
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 12 22 (finitePair 118098 4650110 265719 2598156 11)=true := by decide +kernel
private theorem b1 : every 23 30 (finitePair 118098 4650110 265719 2598156 11)=true := by decide +kernel
private theorem b2 : every 31 40 (finitePair 118098 4650110 265719 2598156 11)=true := by decide +kernel
private theorem b3 : every 41 46 (finitePair 118098 4650110 265719 2598156 11)=true := by decide +kernel
private theorem b4 : every 47 54 (finitePair 118098 4650110 265719 2598156 11)=true := by decide +kernel
private theorem b5 : every 55 60 (finitePair 118098 4650110 265719 2598156 11)=true := by decide +kernel
private theorem b6 : every 61 64 (finitePair 118098 4650110 265719 2598156 11)=true := by decide +kernel
theorem checked : test 3 10 11=true :=
  fixedTest (h:=118098) (A:=4650110) (S:=265719) (T:=2598156)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery b0 (joinEvery b1 b2)) (joinEvery (joinEvery b3 b4) (joinEvery b5 b6)))
#print axioms checked
end OMA.RankThreeAt3E10P11
