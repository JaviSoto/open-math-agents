import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E6P7
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 9 (movingRow 35540 3279 20412 7)=true := by decide +kernel
private theorem b1 : every 10 12 (movingRow 35540 3279 20412 7)=true := by decide +kernel
private theorem b2 : every 13 15 (movingRow 35540 3279 20412 7)=true := by decide +kernel
private theorem b3 : every 16 17 (movingRow 35540 3279 20412 7)=true := by decide +kernel
private theorem b4 : every 18 18 (movingRow 35540 3279 20412 7)=true := by decide +kernel
theorem checked : test 3 6 7=true :=
  movingTest (h:=1458) (A:=35540) (S:=3279) (T:=20412)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery b0 b1) (joinEvery b2 (joinEvery b3 b4)))
#print axioms checked
end OMA.RankThreeAt3E6P7
