import RankThreeFourSmallOriginal245212
/-! Certified prime and exponent intervals for one power of three. -/
namespace OMA.RankThreeFourSmallTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallDecision245212
open OMA.RankThreeFourSmallOriginal245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem c2_0 : every 1 3 (movingRow 578 91 324 5)=true := by decide +kernel
private theorem p2_5 : every 5 5 (atPrime 36 578 91 324)=true := by
  have localTest : atPrime 36 578 91 324 5=true := c2_0
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=5 by omega] using localTest
private theorem c2_1 : every 6 6 (atPrime 36 578 91 324)=true := by decide +kernel
private theorem c2_2 : every 1 7 (movingRow 578 91 324 7)=true := by decide +kernel
private theorem p2_7 : every 7 7 (atPrime 36 578 91 324)=true := by
  have localTest : atPrime 36 578 91 324 7=true := c2_2
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=7 by omega] using localTest
private theorem c2_3 : every 8 10 (atPrime 36 578 91 324)=true := by decide +kernel
private theorem c2_4 : every 12 36 (fixedPair 36 578 91 324 11)=true := by decide +kernel
private theorem c2_5 : every 37 60 (fixedPair 36 578 91 324 11)=true := by decide +kernel
private theorem c2_6 : every 61 88 (fixedPair 36 578 91 324 11)=true := by decide +kernel
private theorem c2_7 : every 89 105 (fixedPair 36 578 91 324 11)=true := by decide +kernel
private theorem c2_8 : every 1 29 (moving 106 5 578 91 324 11)=true := by decide +kernel
private theorem p2_11 : every 11 11 (atPrime 36 578 91 324)=true := by
  have localTest : atPrime 36 578 91 324 11=true := by change (every 12 105 (fixedPair 36 578 91 324 11) && every 1 29 (moving 106 5 578 91 324 11)) = true; rw [Bool.and_eq_true]; exact ⟨(joinEvery (joinEvery c2_4 c2_5) (joinEvery c2_6 c2_7)),c2_8⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=11 by omega] using localTest
private theorem c2_9 : every 12 12 (atPrime 36 578 91 324)=true := by decide +kernel
private theorem c2_10 : every 14 40 (fixedPair 36 578 91 324 13)=true := by decide +kernel
private theorem c2_11 : every 41 58 (fixedPair 36 578 91 324 13)=true := by decide +kernel
private theorem c2_12 : every 1 16 (moving 59 5 578 91 324 13)=true := by decide +kernel
private theorem p2_13 : every 13 13 (atPrime 36 578 91 324)=true := by
  have localTest : atPrime 36 578 91 324 13=true := by change (every 14 58 (fixedPair 36 578 91 324 13) && every 1 16 (moving 59 5 578 91 324 13)) = true; rw [Bool.and_eq_true]; exact ⟨(joinEvery c2_10 c2_11),c2_12⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=13 by omega] using localTest
private theorem c2_13 : every 14 16 (atPrime 36 578 91 324)=true := by decide +kernel
private theorem c2_14 : every 18 37 (fixedPair 36 578 91 324 17)=true := by decide +kernel
private theorem c2_15 : every 1 10 (moving 38 7 578 91 324 17)=true := by decide +kernel
private theorem p2_17 : every 17 17 (atPrime 36 578 91 324)=true := by
  have localTest : atPrime 36 578 91 324 17=true := by change (every 18 37 (fixedPair 36 578 91 324 17) && every 1 10 (moving 38 7 578 91 324 17)) = true; rw [Bool.and_eq_true]; exact ⟨c2_14,c2_15⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=17 by omega] using localTest
private theorem c2_16 : every 18 18 (atPrime 36 578 91 324)=true := by decide +kernel
private theorem c2_17 : every 20 33 (fixedPair 36 578 91 324 19)=true := by decide +kernel
private theorem c2_18 : every 1 9 (moving 34 7 578 91 324 19)=true := by decide +kernel
private theorem p2_19 : every 19 19 (atPrime 36 578 91 324)=true := by
  have localTest : atPrime 36 578 91 324 19=true := by change (every 20 33 (fixedPair 36 578 91 324 19) && every 1 9 (moving 34 7 578 91 324 19)) = true; rw [Bool.and_eq_true]; exact ⟨c2_17,c2_18⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=19 by omega] using localTest
private theorem c2_19 : every 20 22 (atPrime 36 578 91 324)=true := by decide +kernel
private theorem c2_20 : every 24 28 (fixedPair 36 578 91 324 23)=true := by decide +kernel
private theorem c2_21 : every 1 8 (moving 29 8 578 91 324 23)=true := by decide +kernel
private theorem p2_23 : every 23 23 (atPrime 36 578 91 324)=true := by
  have localTest : atPrime 36 578 91 324 23=true := by change (every 24 28 (fixedPair 36 578 91 324 23) && every 1 8 (moving 29 8 578 91 324 23)) = true; rw [Bool.and_eq_true]; exact ⟨c2_20,c2_21⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=23 by omega] using localTest
private theorem c2_22 : every 24 27 (atPrime 36 578 91 324)=true := by decide +kernel
theorem at2 : cert 2=true := (joinEvery (joinEvery (joinEvery p2_5 (joinEvery c2_1 p2_7)) (joinEvery (joinEvery c2_3 p2_11) (joinEvery c2_9 p2_13))) (joinEvery (joinEvery c2_13 (joinEvery p2_17 c2_16)) (joinEvery (joinEvery p2_19 c2_19) (joinEvery p2_23 c2_22))))
end OMA.RankThreeFourSmallTables245212
#print axioms OMA.RankThreeFourSmallTables245212.at2
