import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt13E1P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 4 15 (finitePair 26 135 42 104 3)=true := by decide +kernel
private theorem b1 : every 16 18 (finitePair 26 135 42 104 3)=true := by decide +kernel
private theorem b2 : every 19 22 (finitePair 26 135 42 104 3)=true := by decide +kernel
private theorem b3 : every 23 28 (finitePair 26 135 42 104 3)=true := by decide +kernel
private theorem b4 : every 29 30 (finitePair 26 135 42 104 3)=true := by decide +kernel
private theorem b5 : every 31 36 (finitePair 26 135 42 104 3)=true := by decide +kernel
private theorem b6 : every 37 37 (finitePair 26 135 42 104 3)=true := by decide +kernel
theorem checked : test 13 1 3=true :=
  fixedTest (h:=26) (A:=135) (S:=42) (T:=104)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery b0 (joinEvery b1 b2)) (joinEvery (joinEvery b3 b4) (joinEvery b5 b6)))
#print axioms checked
end OMA.RankThreeAt13E1P3
