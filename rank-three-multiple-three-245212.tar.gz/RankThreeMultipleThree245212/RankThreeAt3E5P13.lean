import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E5P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 14 14 (finitePair 486 10025 1092 5832 13)=true := by decide +kernel
theorem checked : test 3 5 13=true :=
  fixedTest (h:=486) (A:=10025) (S:=1092) (T:=5832)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) b0
#print axioms checked
end OMA.RankThreeAt3E5P13
