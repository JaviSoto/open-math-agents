import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_605_0 : every 605 606 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_605_1 : every 608 85 (quick 96 2247 252 1152 607)=true := by decide +kernel
private theorem b96_605_2 : every 1 25 (far 96 2247 252 1152 607 608 18)=true := by decide +kernel
private theorem b96_605_3 : every 26 50 (far 96 2247 252 1152 607 608 18)=true := by decide +kernel
private theorem b96_605_4 : every 51 75 (far 96 2247 252 1152 607 608 18)=true := by decide +kernel
private theorem b96_605_5 : every 76 100 (far 96 2247 252 1152 607 608 18)=true := by decide +kernel
private theorem b96_605_6 : every 101 125 (far 96 2247 252 1152 607 608 18)=true := by decide +kernel
private theorem b96_605_7 : every 126 137 (far 96 2247 252 1152 607 608 18)=true := by decide +kernel
private theorem r96_607 : every 607 607 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 607=true := by change (every 608 85 (quick 96 2247 252 1152 607) && every 1 137 (far 96 2247 252 1152 607 608 18))=true; rw [Bool.and_eq_true]; exact ⟨b96_605_1,(joinEvery (joinEvery b96_605_2 (joinEvery b96_605_3 b96_605_4)) (joinEvery b96_605_5 (joinEvery b96_605_6 b96_605_7)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=607 by omega] using yes
private theorem b96_605_8 : every 608 612 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_605_9 : every 614 85 (quick 96 2247 252 1152 613)=true := by decide +kernel
private theorem b96_605_10 : every 1 25 (far 96 2247 252 1152 613 614 18)=true := by decide +kernel
private theorem b96_605_11 : every 26 50 (far 96 2247 252 1152 613 614 18)=true := by decide +kernel
private theorem b96_605_12 : every 51 75 (far 96 2247 252 1152 613 614 18)=true := by decide +kernel
private theorem b96_605_13 : every 76 100 (far 96 2247 252 1152 613 614 18)=true := by decide +kernel
private theorem b96_605_14 : every 101 125 (far 96 2247 252 1152 613 614 18)=true := by decide +kernel
private theorem b96_605_15 : every 126 139 (far 96 2247 252 1152 613 614 18)=true := by decide +kernel
private theorem r96_613 : every 613 613 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 613=true := by change (every 614 85 (quick 96 2247 252 1152 613) && every 1 139 (far 96 2247 252 1152 613 614 18))=true; rw [Bool.and_eq_true]; exact ⟨b96_605_9,(joinEvery (joinEvery b96_605_10 (joinEvery b96_605_11 b96_605_12)) (joinEvery b96_605_13 (joinEvery b96_605_14 b96_605_15)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=613 by omega] using yes
private theorem b96_605_16 : every 614 616 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_605_17 : every 618 85 (quick 96 2247 252 1152 617)=true := by decide +kernel
private theorem b96_605_18 : every 1 25 (far 96 2247 252 1152 617 618 18)=true := by decide +kernel
private theorem b96_605_19 : every 26 50 (far 96 2247 252 1152 617 618 18)=true := by decide +kernel
private theorem b96_605_20 : every 51 75 (far 96 2247 252 1152 617 618 18)=true := by decide +kernel
private theorem b96_605_21 : every 76 100 (far 96 2247 252 1152 617 618 18)=true := by decide +kernel
private theorem b96_605_22 : every 101 125 (far 96 2247 252 1152 617 618 18)=true := by decide +kernel
private theorem b96_605_23 : every 126 140 (far 96 2247 252 1152 617 618 18)=true := by decide +kernel
private theorem r96_617 : every 617 617 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 617=true := by change (every 618 85 (quick 96 2247 252 1152 617) && every 1 140 (far 96 2247 252 1152 617 618 18))=true; rw [Bool.and_eq_true]; exact ⟨b96_605_17,(joinEvery (joinEvery b96_605_18 (joinEvery b96_605_19 b96_605_20)) (joinEvery b96_605_21 (joinEvery b96_605_22 b96_605_23)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=617 by omega] using yes
private theorem b96_605_24 : every 618 618 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_605_25 : every 620 85 (quick 96 2247 252 1152 619)=true := by decide +kernel
private theorem b96_605_26 : every 1 25 (far 96 2247 252 1152 619 620 18)=true := by decide +kernel
private theorem b96_605_27 : every 26 50 (far 96 2247 252 1152 619 620 18)=true := by decide +kernel
private theorem b96_605_28 : every 51 75 (far 96 2247 252 1152 619 620 18)=true := by decide +kernel
private theorem b96_605_29 : every 76 100 (far 96 2247 252 1152 619 620 18)=true := by decide +kernel
private theorem b96_605_30 : every 101 125 (far 96 2247 252 1152 619 620 18)=true := by decide +kernel
private theorem b96_605_31 : every 126 140 (far 96 2247 252 1152 619 620 18)=true := by decide +kernel
private theorem r96_619 : every 619 619 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 619=true := by change (every 620 85 (quick 96 2247 252 1152 619) && every 1 140 (far 96 2247 252 1152 619 620 18))=true; rw [Bool.and_eq_true]; exact ⟨b96_605_25,(joinEvery (joinEvery b96_605_26 (joinEvery b96_605_27 b96_605_28)) (joinEvery b96_605_29 (joinEvery b96_605_30 b96_605_31)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=619 by omega] using yes
private theorem b96_605_32 : every 620 628 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_605_628 : every 605 628 (run 96 2247 252 1152)=true := (joinEvery (joinEvery (joinEvery b96_605_0 r96_607) (joinEvery b96_605_8 r96_613)) (joinEvery (joinEvery b96_605_16 r96_617) (joinEvery b96_605_24 (joinEvery r96_619 b96_605_32))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_605_628
