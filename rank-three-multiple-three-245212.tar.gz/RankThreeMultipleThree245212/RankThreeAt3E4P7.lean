import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E4P7
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 8 18 (finitePair 162 2735 363 1620 7)=true := by decide +kernel
private theorem b1 : every 19 28 (finitePair 162 2735 363 1620 7)=true := by decide +kernel
private theorem b2 : every 29 36 (finitePair 162 2735 363 1620 7)=true := by decide +kernel
private theorem b3 : every 37 42 (finitePair 162 2735 363 1620 7)=true := by decide +kernel
private theorem b4 : every 43 52 (finitePair 162 2735 363 1620 7)=true := by decide +kernel
private theorem b5 : every 53 60 (finitePair 162 2735 363 1620 7)=true := by decide +kernel
private theorem b6 : every 61 65 (finitePair 162 2735 363 1620 7)=true := by decide +kernel
theorem checked : test 3 4 7=true :=
  fixedTest (h:=162) (A:=2735) (S:=363) (T:=1620)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery b0 (joinEvery b1 b2)) (joinEvery (joinEvery b3 b4) (joinEvery b5 b6)))
#print axioms checked
end OMA.RankThreeAt3E4P7
