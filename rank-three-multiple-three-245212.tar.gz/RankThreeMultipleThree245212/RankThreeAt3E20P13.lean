import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E20P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 14 28 (finitePair 6973568802 536093101655 15690529803 292889889684 13)=true := by decide +kernel
private theorem b1 : every 29 36 (finitePair 6973568802 536093101655 15690529803 292889889684 13)=true := by decide +kernel
private theorem b2 : every 37 42 (finitePair 6973568802 536093101655 15690529803 292889889684 13)=true := by decide +kernel
private theorem b3 : every 43 46 (finitePair 6973568802 536093101655 15690529803 292889889684 13)=true := by decide +kernel
private theorem b4 : every 47 52 (finitePair 6973568802 536093101655 15690529803 292889889684 13)=true := by decide +kernel
private theorem b5 : every 53 58 (finitePair 6973568802 536093101655 15690529803 292889889684 13)=true := by decide +kernel
private theorem b6 : every 59 60 (finitePair 6973568802 536093101655 15690529803 292889889684 13)=true := by decide +kernel
private theorem b7 : every 61 66 (finitePair 6973568802 536093101655 15690529803 292889889684 13)=true := by decide +kernel
private theorem b8 : every 67 70 (finitePair 6973568802 536093101655 15690529803 292889889684 13)=true := by decide +kernel
private theorem b9 : every 71 72 (finitePair 6973568802 536093101655 15690529803 292889889684 13)=true := by decide +kernel
private theorem b10 : every 73 78 (finitePair 6973568802 536093101655 15690529803 292889889684 13)=true := by decide +kernel
private theorem b11 : every 79 82 (finitePair 6973568802 536093101655 15690529803 292889889684 13)=true := by decide +kernel
private theorem b12 : every 83 88 (finitePair 6973568802 536093101655 15690529803 292889889684 13)=true := by decide +kernel
private theorem b13 : every 89 96 (finitePair 6973568802 536093101655 15690529803 292889889684 13)=true := by decide +kernel
private theorem b14 : every 97 100 (finitePair 6973568802 536093101655 15690529803 292889889684 13)=true := by decide +kernel
private theorem b15 : every 101 102 (finitePair 6973568802 536093101655 15690529803 292889889684 13)=true := by decide +kernel
private theorem b16 : every 103 106 (finitePair 6973568802 536093101655 15690529803 292889889684 13)=true := by decide +kernel
private theorem b17 : every 107 108 (finitePair 6973568802 536093101655 15690529803 292889889684 13)=true := by decide +kernel
private theorem b18 : every 109 112 (finitePair 6973568802 536093101655 15690529803 292889889684 13)=true := by decide +kernel
private theorem b19 : every 113 116 (finitePair 6973568802 536093101655 15690529803 292889889684 13)=true := by decide +kernel
theorem checked : test 3 20 13=true :=
  fixedTest (h:=6973568802) (A:=536093101655) (S:=15690529803) (T:=292889889684)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 (joinEvery b3 b4))) (joinEvery (joinEvery b5 b6) (joinEvery b7 (joinEvery b8 b9)))) (joinEvery (joinEvery (joinEvery b10 b11) (joinEvery b12 (joinEvery b13 b14))) (joinEvery (joinEvery b15 b16) (joinEvery b17 (joinEvery b18 b19)))))
#print axioms checked
end OMA.RankThreeAt3E20P13
