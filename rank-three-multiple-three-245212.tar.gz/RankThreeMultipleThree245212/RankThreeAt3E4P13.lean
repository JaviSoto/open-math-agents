import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E4P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 14 11 (finitePair 162 2735 363 1620 13)=true := by decide +kernel
theorem checked : test 3 4 13=true :=
  fixedTest (h:=162) (A:=2735) (S:=363) (T:=1620)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) b0
#print axioms checked
end OMA.RankThreeAt3E4P13
