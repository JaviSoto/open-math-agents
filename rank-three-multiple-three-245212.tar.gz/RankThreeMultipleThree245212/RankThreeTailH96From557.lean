import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_557_0 : every 558 86 (quick 96 2247 252 1152 557)=true := by decide +kernel
private theorem b96_557_1 : every 1 25 (far 96 2247 252 1152 557 558 19)=true := by decide +kernel
private theorem b96_557_2 : every 26 50 (far 96 2247 252 1152 557 558 19)=true := by decide +kernel
private theorem b96_557_3 : every 51 75 (far 96 2247 252 1152 557 558 19)=true := by decide +kernel
private theorem b96_557_4 : every 76 100 (far 96 2247 252 1152 557 558 19)=true := by decide +kernel
private theorem b96_557_5 : every 101 125 (far 96 2247 252 1152 557 558 19)=true := by decide +kernel
private theorem b96_557_6 : every 126 126 (far 96 2247 252 1152 557 558 19)=true := by decide +kernel
private theorem r96_557 : every 557 557 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 557=true := by change (every 558 86 (quick 96 2247 252 1152 557) && every 1 126 (far 96 2247 252 1152 557 558 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_557_0,(joinEvery (joinEvery b96_557_1 (joinEvery b96_557_2 b96_557_3)) (joinEvery b96_557_4 (joinEvery b96_557_5 b96_557_6)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=557 by omega] using yes
private theorem b96_557_7 : every 558 562 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_557_8 : every 564 85 (quick 96 2247 252 1152 563)=true := by decide +kernel
private theorem b96_557_9 : every 1 25 (far 96 2247 252 1152 563 564 19)=true := by decide +kernel
private theorem b96_557_10 : every 26 50 (far 96 2247 252 1152 563 564 19)=true := by decide +kernel
private theorem b96_557_11 : every 51 75 (far 96 2247 252 1152 563 564 19)=true := by decide +kernel
private theorem b96_557_12 : every 76 100 (far 96 2247 252 1152 563 564 19)=true := by decide +kernel
private theorem b96_557_13 : every 101 125 (far 96 2247 252 1152 563 564 19)=true := by decide +kernel
private theorem b96_557_14 : every 126 128 (far 96 2247 252 1152 563 564 19)=true := by decide +kernel
private theorem r96_563 : every 563 563 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 563=true := by change (every 564 85 (quick 96 2247 252 1152 563) && every 1 128 (far 96 2247 252 1152 563 564 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_557_8,(joinEvery (joinEvery b96_557_9 (joinEvery b96_557_10 b96_557_11)) (joinEvery b96_557_12 (joinEvery b96_557_13 b96_557_14)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=563 by omega] using yes
private theorem b96_557_15 : every 564 568 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_557_16 : every 570 85 (quick 96 2247 252 1152 569)=true := by decide +kernel
private theorem b96_557_17 : every 1 25 (far 96 2247 252 1152 569 570 19)=true := by decide +kernel
private theorem b96_557_18 : every 26 50 (far 96 2247 252 1152 569 570 19)=true := by decide +kernel
private theorem b96_557_19 : every 51 75 (far 96 2247 252 1152 569 570 19)=true := by decide +kernel
private theorem b96_557_20 : every 76 100 (far 96 2247 252 1152 569 570 19)=true := by decide +kernel
private theorem b96_557_21 : every 101 125 (far 96 2247 252 1152 569 570 19)=true := by decide +kernel
private theorem b96_557_22 : every 126 129 (far 96 2247 252 1152 569 570 19)=true := by decide +kernel
private theorem r96_569 : every 569 569 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 569=true := by change (every 570 85 (quick 96 2247 252 1152 569) && every 1 129 (far 96 2247 252 1152 569 570 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_557_16,(joinEvery (joinEvery b96_557_17 (joinEvery b96_557_18 b96_557_19)) (joinEvery b96_557_20 (joinEvery b96_557_21 b96_557_22)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=569 by omega] using yes
private theorem b96_557_23 : every 570 570 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_557_24 : every 572 85 (quick 96 2247 252 1152 571)=true := by decide +kernel
private theorem b96_557_25 : every 1 25 (far 96 2247 252 1152 571 572 18)=true := by decide +kernel
private theorem b96_557_26 : every 26 50 (far 96 2247 252 1152 571 572 18)=true := by decide +kernel
private theorem b96_557_27 : every 51 75 (far 96 2247 252 1152 571 572 18)=true := by decide +kernel
private theorem b96_557_28 : every 76 100 (far 96 2247 252 1152 571 572 18)=true := by decide +kernel
private theorem b96_557_29 : every 101 125 (far 96 2247 252 1152 571 572 18)=true := by decide +kernel
private theorem b96_557_30 : every 126 129 (far 96 2247 252 1152 571 572 18)=true := by decide +kernel
private theorem r96_571 : every 571 571 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 571=true := by change (every 572 85 (quick 96 2247 252 1152 571) && every 1 129 (far 96 2247 252 1152 571 572 18))=true; rw [Bool.and_eq_true]; exact ⟨b96_557_24,(joinEvery (joinEvery b96_557_25 (joinEvery b96_557_26 b96_557_27)) (joinEvery b96_557_28 (joinEvery b96_557_29 b96_557_30)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=571 by omega] using yes
private theorem b96_557_31 : every 572 576 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_557_32 : every 578 85 (quick 96 2247 252 1152 577)=true := by decide +kernel
private theorem b96_557_33 : every 1 25 (far 96 2247 252 1152 577 578 18)=true := by decide +kernel
private theorem b96_557_34 : every 26 50 (far 96 2247 252 1152 577 578 18)=true := by decide +kernel
private theorem b96_557_35 : every 51 75 (far 96 2247 252 1152 577 578 18)=true := by decide +kernel
private theorem b96_557_36 : every 76 100 (far 96 2247 252 1152 577 578 18)=true := by decide +kernel
private theorem b96_557_37 : every 101 125 (far 96 2247 252 1152 577 578 18)=true := by decide +kernel
private theorem b96_557_38 : every 126 131 (far 96 2247 252 1152 577 578 18)=true := by decide +kernel
private theorem r96_577 : every 577 577 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 577=true := by change (every 578 85 (quick 96 2247 252 1152 577) && every 1 131 (far 96 2247 252 1152 577 578 18))=true; rw [Bool.and_eq_true]; exact ⟨b96_557_32,(joinEvery (joinEvery b96_557_33 (joinEvery b96_557_34 b96_557_35)) (joinEvery b96_557_36 (joinEvery b96_557_37 b96_557_38)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=577 by omega] using yes
private theorem b96_557_39 : every 578 580 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_557_580 : every 557 580 (run 96 2247 252 1152)=true := (joinEvery (joinEvery (joinEvery r96_557 b96_557_7) (joinEvery r96_563 (joinEvery b96_557_15 r96_569))) (joinEvery (joinEvery b96_557_23 r96_571) (joinEvery b96_557_31 (joinEvery r96_577 b96_557_39))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_557_580
