import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E6P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 14 17 (finitePair 1458 35540 3279 20412 13)=true := by decide +kernel
theorem checked : test 3 6 13=true :=
  fixedTest (h:=1458) (A:=35540) (S:=3279) (T:=20412)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) b0
#print axioms checked
end OMA.RankThreeAt3E6P13
