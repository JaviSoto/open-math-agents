import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b72_245_0 : every 245 250 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_245_1 : every 252 61 (quick 72 1666 195 864 251)=true := by decide +kernel
private theorem b72_245_2 : every 1 25 (far 72 1666 195 864 251 252 14)=true := by decide +kernel
private theorem b72_245_3 : every 26 50 (far 72 1666 195 864 251 252 14)=true := by decide +kernel
private theorem b72_245_4 : every 51 60 (far 72 1666 195 864 251 252 14)=true := by decide +kernel
private theorem r72_251 : every 251 251 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 251=true := by change (every 252 61 (quick 72 1666 195 864 251) && every 1 60 (far 72 1666 195 864 251 252 14))=true; rw [Bool.and_eq_true]; exact ⟨b72_245_1,(joinEvery b72_245_2 (joinEvery b72_245_3 b72_245_4))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=251 by omega] using yes
private theorem b72_245_5 : every 252 256 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_245_6 : every 258 61 (quick 72 1666 195 864 257)=true := by decide +kernel
private theorem b72_245_7 : every 1 25 (far 72 1666 195 864 257 258 14)=true := by decide +kernel
private theorem b72_245_8 : every 26 50 (far 72 1666 195 864 257 258 14)=true := by decide +kernel
private theorem b72_245_9 : every 51 61 (far 72 1666 195 864 257 258 14)=true := by decide +kernel
private theorem r72_257 : every 257 257 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 257=true := by change (every 258 61 (quick 72 1666 195 864 257) && every 1 61 (far 72 1666 195 864 257 258 14))=true; rw [Bool.and_eq_true]; exact ⟨b72_245_6,(joinEvery b72_245_7 (joinEvery b72_245_8 b72_245_9))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=257 by omega] using yes
private theorem b72_245_10 : every 258 260 (run 72 1666 195 864)=true := by decide +kernel
theorem span72_245_260 : every 245 260 (run 72 1666 195 864)=true := (joinEvery (joinEvery b72_245_0 r72_251) (joinEvery b72_245_5 (joinEvery r72_257 b72_245_10)))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span72_245_260
