import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E36P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 3 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b1 : every 4 6 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b2 : every 7 9 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b3 : every 10 12 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b4 : every 13 15 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b5 : every 16 18 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b6 : every 19 21 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b7 : every 22 24 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b8 : every 25 27 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b9 : every 28 30 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b10 : every 31 33 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b11 : every 34 36 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b12 : every 37 39 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b13 : every 40 42 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b14 : every 43 43 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b15 : every 44 44 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b16 : every 45 45 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b17 : every 46 46 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b18 : every 47 47 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b19 : every 48 48 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b20 : every 49 49 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b21 : every 50 50 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b22 : every 51 51 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b23 : every 52 52 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b24 : every 53 53 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b25 : every 54 54 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b26 : every 55 55 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b27 : every 56 56 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b28 : every 57 57 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b29 : every 58 58 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b30 : every 59 59 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b31 : every 60 60 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b32 : every 61 61 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b33 : every 62 62 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b34 : every 63 63 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b35 : every 64 64 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b36 : every 65 65 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b37 : every 66 66 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b38 : every 67 67 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b39 : every 68 68 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b40 : every 69 69 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b41 : every 70 70 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b42 : every 71 71 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b43 : every 72 72 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b44 : every 73 73 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b45 : every 74 74 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b46 : every 75 75 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b47 : every 76 76 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b48 : every 77 77 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b49 : every 78 78 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b50 : every 79 79 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b51 : every 80 80 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
private theorem b52 : every 81 81 (movingRow 41088406412553509375 675425858836496043 22214006023955869908 13)=true := by decide +kernel
theorem checked : test 3 36 13=true :=
  movingTest (h:=300189270593998242) (A:=41088406412553509375) (S:=675425858836496043) (T:=22214006023955869908)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 (joinEvery b1 b2)) (joinEvery b3 (joinEvery b4 b5))) (joinEvery (joinEvery b6 (joinEvery b7 b8)) (joinEvery (joinEvery b9 b10) (joinEvery b11 b12)))) (joinEvery (joinEvery (joinEvery b13 (joinEvery b14 b15)) (joinEvery b16 (joinEvery b17 b18))) (joinEvery (joinEvery b19 (joinEvery b20 b21)) (joinEvery (joinEvery b22 b23) (joinEvery b24 b25))))) (joinEvery (joinEvery (joinEvery (joinEvery b26 (joinEvery b27 b28)) (joinEvery b29 (joinEvery b30 b31))) (joinEvery (joinEvery b32 (joinEvery b33 b34)) (joinEvery (joinEvery b35 b36) (joinEvery b37 b38)))) (joinEvery (joinEvery (joinEvery b39 (joinEvery b40 b41)) (joinEvery (joinEvery b42 b43) (joinEvery b44 b45))) (joinEvery (joinEvery b46 (joinEvery b47 b48)) (joinEvery (joinEvery b49 b50) (joinEvery b51 b52))))))
#print axioms checked
end OMA.RankThreeAt3E36P13
