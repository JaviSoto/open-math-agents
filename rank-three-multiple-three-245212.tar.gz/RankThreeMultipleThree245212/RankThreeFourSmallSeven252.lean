import RankThreeFourSmallCompact245212
/-! Independently checked consecutive interval for the compressed two-prime decision. -/
namespace OMA.RankThreeFourSmallCompactTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallCompact245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem r7_252_256 : every 252 256 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_257_261 : every 257 261 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_262_266 : every 262 266 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_267_271 : every 267 271 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_272_276 : every 272 276 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_277_281 : every 277 281 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_282_286 : every 282 286 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_287_291 : every 287 291 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_292_296 : every 292 296 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_297_301 : every 297 301 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_302_306 : every 302 306 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_307_311 : every 307 311 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_312_316 : every 312 316 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_317_321 : every 317 321 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_322_326 : every 322 326 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_327_331 : every 327 331 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_332_336 : every 332 336 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_337_341 : every 337 341 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_342_346 : every 342 346 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_347_351 : every 347 351 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_352_356 : every 352 356 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_357_361 : every 357 361 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_362_366 : every 362 366 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_367_371 : every 367 371 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_372_376 : every 372 376 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_377_381 : every 377 381 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_382_386 : every 382 386 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_387_391 : every 387 391 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_392_396 : every 392 396 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_397_399 : every 397 399 (run 8748 418268 22960 209952)=true := by decide +kernel
theorem span7_252_399 : every 252 399 (run 8748 418268 22960 209952)=true := (joinEvery (joinEvery (joinEvery (joinEvery r7_252_256 (joinEvery r7_257_261 r7_262_266)) (joinEvery (joinEvery r7_267_271 r7_272_276) (joinEvery r7_277_281 r7_282_286))) (joinEvery (joinEvery (joinEvery r7_287_291 r7_292_296) (joinEvery r7_297_301 r7_302_306)) (joinEvery (joinEvery r7_307_311 r7_312_316) (joinEvery r7_317_321 r7_322_326)))) (joinEvery (joinEvery (joinEvery r7_327_331 (joinEvery r7_332_336 r7_337_341)) (joinEvery (joinEvery r7_342_346 r7_347_351) (joinEvery r7_352_356 r7_357_361))) (joinEvery (joinEvery (joinEvery r7_362_366 r7_367_371) (joinEvery r7_372_376 r7_377_381)) (joinEvery (joinEvery r7_382_386 r7_387_391) (joinEvery r7_392_396 r7_397_399)))))
end OMA.RankThreeFourSmallCompactTables245212
#print axioms OMA.RankThreeFourSmallCompactTables245212.span7_252_399
