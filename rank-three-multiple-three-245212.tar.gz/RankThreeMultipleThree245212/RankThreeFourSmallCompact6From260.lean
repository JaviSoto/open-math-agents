import RankThreeFourSmallCompact245212
/-! Independently checked consecutive interval for the compressed two-prime decision. -/
namespace OMA.RankThreeFourSmallCompactTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallCompact245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem r6_260_267 : every 260 267 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_268_275 : every 268 275 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_276_283 : every 276 283 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_284_291 : every 284 291 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_292_299 : every 292 299 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_300_307 : every 300 307 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_308_315 : every 308 315 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_316_323 : every 316 323 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_324_331 : every 324 331 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_332_339 : every 332 339 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_340_347 : every 340 347 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_348_355 : every 348 355 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_356_363 : every 356 363 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_364_371 : every 364 371 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_372_379 : every 372 379 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_380_387 : every 380 387 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_388_395 : every 388 395 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_396_403 : every 396 403 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_404_411 : every 404 411 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_412_419 : every 412 419 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_420_427 : every 420 427 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_428_435 : every 428 435 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_436_443 : every 436 443 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_444_451 : every 444 451 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_452_459 : every 452 459 (run 2916 120836 7651 61236)=true := by decide +kernel
theorem span6_260_459 : every 260 459 (run 2916 120836 7651 61236)=true := (joinEvery (joinEvery (joinEvery (joinEvery r6_260_267 (joinEvery r6_268_275 r6_276_283)) (joinEvery r6_284_291 (joinEvery r6_292_299 r6_300_307))) (joinEvery (joinEvery r6_308_315 (joinEvery r6_316_323 r6_324_331)) (joinEvery r6_332_339 (joinEvery r6_340_347 r6_348_355)))) (joinEvery (joinEvery (joinEvery r6_356_363 (joinEvery r6_364_371 r6_372_379)) (joinEvery r6_380_387 (joinEvery r6_388_395 r6_396_403))) (joinEvery (joinEvery r6_404_411 (joinEvery r6_412_419 r6_420_427)) (joinEvery (joinEvery r6_428_435 r6_436_443) (joinEvery r6_444_451 r6_452_459)))))
end OMA.RankThreeFourSmallCompactTables245212
#print axioms OMA.RankThreeFourSmallCompactTables245212.span6_260_459
