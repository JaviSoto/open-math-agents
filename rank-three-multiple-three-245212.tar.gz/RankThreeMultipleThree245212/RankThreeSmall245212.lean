import RankThreeOne245212

/-! Pick two bounded exponents in a three-prime dyadic solution. When
a group contains only large prime powers the integer rounding error is
below one denominator unit. The product of the other two Euler factors
controls the sign, allowing much shorter thresholds than a scalar bound. -/
namespace OMA.RankThreeSmall245212
open Finset Nat OMA.Smooth245212 OMA.Height245212
open scoped ArithmeticFunction.sigma

def height (B : ℕ) := OMA.HeightLog245212.ceiling 4 B
def budget (B : ℕ) := 2*coefficientBound B (height B)
def first (B p : ℕ) := Nat.log p (budget B)
def next (B p e q r : ℕ) := max (Nat.log q (budget B*p^e)) (4*(r-1)/(e+1))
def seed (B p q r : ℕ) := 4*(p-1)<(first B q+2)*(first B r+2)

abbrev PP (p q r : ℕ) : Fin 4 → ℕ := ![2,p,q,r]
abbrev EE (a b c : ℕ) : Fin 4 → ℕ := ![1,a,b,c]
def Bal (p q r a b c : ℕ) :=
  5*(X p (some a)*X q (some b)*X r (some c))+3*(Y p (some a)*Y q (some b)*Y r (some c))=8

theorem normal {p q r a b c : ℕ} (h : Bal p q r a b c) : normalized (PP p q r) (EE a b c)=2 := by
  have x : X 2 (some 1)=5/4 := by decide +kernel
  have y : Y 2 (some 1)=3/4 := by decide +kernel
  simp [normalized,Fin.prod_univ_four,PP,EE,x,y]
  unfold Bal at h
  linarith

theorem exponent_height {p q r a b c : ℕ} (pp : p.Prime) (qp : q.Prime) (rp : r.Prime)
    (op : 2<p) (pq : p<q) (qr : q<r) (ap : 0<a) (bp : 0<b) (cp : 0<c)
    (sol : OeisA245212.a (2*p^a*q^b*r^c)=(σ 1 (2*p^a*q^b*r^c):ℤ)) :
    a≤height r ∧ b≤height r ∧ c≤height r := by
  let P := PP p q r
  let E := EE a b c
  have primes (i : Fin 4) : (P i).Prime := by fin_cases i <;> simp [P,PP,pp,qp,rp,prime_two]
  have inj : P.Injective := by intro i j hit; fin_cases i <;> fin_cases j <;> simp_all [P,PP] <;> omega
  have ps (i : Fin 4) : 0<E i := by fin_cases i <;> simp [E,EE,ap,bp,cp]
  have bnd (i : Fin 4) : P i≤r := by fin_cases i <;> simp [P,PP] <;> omega
  have dt (i : Fin 4) : P i=2 → P i^E i≤r^(2*r) := by
    fin_cases i <;> simp [P,E,PP,EE]
    · exact (by omega : 2≤r).trans (Nat.le_pow (by omega : 0<2*r))
    all_goals omega
  have repr : total P E=2*p^a*q^b*r^c := by simp [total,Fin.prod_univ_four,P,E,PP,EE,mul_assoc]
  have power := OMA.GuardedHeight245212.max_power P E primes dt ps inj bnd (repr ▸ sol)
  have top := OMA.HeightLog245212.four (lt_of_lt_of_le (ps 0) (le_sup (f:=E) (mem_univ 0))) power
  exact ⟨(le_sup (f:=E) (mem_univ 1)).trans top,(le_sup (f:=E) (mem_univ 2)).trans top,
    (le_sup (f:=E) (mem_univ 3)).trans top⟩

private theorem control {p q r b c : ℕ} (pg : 1<p) (qg : 1<q) (rg : 1<r)
    (bp : 0<b) (cp : 0<c) (enough : 4*(p-1)<(b+1)*(c+1)) :
    ((p:ℚ)-1)*(yr q b*yr r c)<1 := by
  have h : (4:ℚ)*((p:ℚ)-1)<((b:ℚ)+1)*((c:ℚ)+1) := by
    simpa [Nat.cast_sub (show 1≤p by omega)] using
      (show (4:ℚ)*((p-1:ℕ):ℚ)<((b:ℚ)+1)*((c:ℚ)+1) by exact_mod_cast enough)
  obtain ⟨q0,_,q2⟩ := y_range qg bp
  obtain ⟨r0,_,r2⟩ := y_range rg cp
  have z := mul_le_mul q2 r2 (mul_nonneg r0 (by positivity)) (by norm_num : (0:ℚ)≤2)
  have pr : (1:ℚ)<p := by exact_mod_cast pg
  have m := mul_le_mul_of_nonneg_left z (sub_nonneg.mpr pr.le)
  apply (mul_lt_mul_iff_left₀ (show (0:ℚ)<((b:ℚ)+1)*((c:ℚ)+1) by positivity)).mp
  nlinarith only [m,h]

structure Context (B p q r a b c : ℕ) : Prop where
  prime : ∀ i, (PP p q r i).Prime
  pos : ∀ i, 0<EE a b c i
  bound : ∀ i, PP p q r i≤B
  exponents : ∀ i, EE a b c i≤height B
  bal : Bal p q r a b c

theorem context {B p q r a b c : ℕ} (hp : p.Prime) (hq : q.Prime) (hr : r.Prime)
    (pB : p≤B) (qB : q≤B) (rB : r≤B) (ap : 0<a) (bp : 0<b) (cp : 0<c)
    (ae : a≤height B) (be : b≤height B) (ce : c≤height B) (h : Bal p q r a b c) :
    Context B p q r a b c where
  prime i := by fin_cases i <;> simp [PP,hp,hq,hr,prime_two]
  pos i := by fin_cases i <;> simp [EE,ap,bp,cp]
  bound i := by have := hp.two_le; fin_cases i <;> simp [PP,pB,qB,rB]; omega
  exponents i := by fin_cases i <;> simp [EE,ae,be,ce]; omega
  bal := h

private theorem no_round {B p q r a b c : ℕ} (h : Context B p q r a b c)
    (s : Finset (Fin 4)) (sn : s.Nonempty)
    (large : ∀ i∈s,coefficientBound B (height B)*outside (PP p q r) (EE a b c) s<
      (PP p q r i)^(EE a b c i))
    (strict : ∀ i∈s, ((PP p q r i:ℚ)-1)*
      (∏ j∈univ.erase i,yr (PP p q r j) (EE a b c j))<1) : False := by
  have n := normal h.bal
  have eq := gap_eq _ _ h.prime h.pos s n (enough _ _ h.prime h.bound h.exponents s large)
  have lt := strict_prod _ _ (fun i=>(h.prime i).one_lt) h.pos s sn strict
  linarith

private theorem pow_big {p u e : ℕ} (hp : 1<p) (big : Nat.log p u<e) : u<p^e :=
  (Nat.lt_pow_succ_log_self hp u).trans_le (Nat.pow_le_pow_right (by omega) big)

private theorem erase0 (i : Fin 4) (z : Fin 4 → ℚ) :
    (∏ j∈univ.erase i,z j)=∏ j,if j=i then 1 else z j := by
  rw [← Finset.prod_erase_mul univ (fun j => if j=i then 1 else z j) (mem_univ i)]
  simp only [ite_true,mul_one]
  apply Finset.prod_congr rfl
  intro j hj
  rw [if_neg (mem_erase.mp hj).1]

private theorem three_ctl {p q r a b c : ℕ} (pg : 1<p) (qg : 1<q) (rg : 1<r)
    (ap : 0<a) (bp : 0<b) (cp : 0<c)
    (v : 4*(p-1)<(b+1)*(c+1)) (w : 4*(q-1)<(a+1)*(c+1)) (x : 4*(r-1)<(a+1)*(b+1))
    (i : Fin 4) (hi : i≠0) : ((PP p q r i:ℚ)-1)*
      (∏ j∈univ.erase i,yr (PP p q r j) (EE a b c j))<1 := by
  rw [erase0]
  have z : yr 2 1=1 := by decide +kernel
  fin_cases i <;> simp_all [Fin.prod_univ_four,PP,EE]
  · exact control pg qg rg bp cp v
  · exact control qg pg rg ap cp w
  · exact control rg pg qg ap bp x

theorem small_one {B p q r a b c : ℕ} (h : Context B p q r a b c)
    (sp : seed B p q r) (sq : seed B q p r) (sr : seed B r p q) :
    a≤first B p ∨ b≤first B q ∨ c≤first B r := by
  by_contra! far
  obtain ⟨aa,bb,cc⟩ := far
  let s : Finset (Fin 4) := {1,2,3}
  have out : outside (PP p q r) (EE a b c) s=2 := by simp [outside,Fin.prod_univ_four,PP,EE,s]
  have v := three_ctl (p:=p) (q:=q) (r:=r) (a:=a) (b:=b) (c:=c) (h.prime 1).one_lt (h.prime 2).one_lt (h.prime 3).one_lt (h.pos 1) (h.pos 2) (h.pos 3)
    (sp.trans_le (Nat.mul_le_mul (by omega) (by omega))) (sq.trans_le (Nat.mul_le_mul (by omega) (by omega)))
    (sr.trans_le (Nat.mul_le_mul (by omega) (by omega)))
  apply no_round h s (by decide) _ (fun i hi=> v i (by rintro rfl; simp [s] at hi))
  intro i hi
  rw [out,mul_comm]
  fin_cases i
  · simp [s] at hi
  · exact pow_big (h.prime 1).one_lt aa
  · exact pow_big (h.prime 2).one_lt bb
  · exact pow_big (h.prime 3).one_lt cc

theorem small_two {B p q r a b c : ℕ} (h : Context B p q r a b c) :
    b≤next B p a q r ∨ c≤next B p a r q := by
  by_contra! far
  obtain ⟨bb,cc⟩ := far
  have bigq := pow_big (h.prime 2).one_lt ((le_max_left ..).trans_lt bb)
  have bigr := pow_big (h.prime 3).one_lt ((le_max_left ..).trans_lt cc)
  have w := (Nat.div_lt_iff_lt_mul (Nat.succ_pos a)).mp ((le_max_right ..).trans_lt cc)
  have x := (Nat.div_lt_iff_lt_mul (Nat.succ_pos a)).mp ((le_max_right ..).trans_lt bb)
  let s : Finset (Fin 4) := {2,3}
  have out : outside (PP p q r) (EE a b c) s=2*p^a := by simp [outside,Fin.prod_univ_four,PP,EE,s]
  apply no_round h s (by decide)
  · intro i hi
    rw [out]
    have val : coefficientBound B (height B)*(2*p^a)=budget B*p^a := by unfold budget;ring
    rw [val]
    fin_cases i
    · simp [s] at hi
    · simp [s] at hi
    · exact bigq
    · exact bigr
  · intro i hi
    rw [erase0]
    have z : yr 2 1=1 := by decide +kernel
    fin_cases i <;> simp_all [Fin.prod_univ_four,PP,EE,s]
    · exact control (h.prime 2).one_lt (h.prime 1).one_lt (h.prime 3).one_lt
        (h.pos 1) (h.pos 3) (w.trans_le (by nlinarith only [Nat.zero_le a]))
    · exact control (h.prime 3).one_lt (h.prime 1).one_lt (h.prime 2).one_lt
        (h.pos 1) (h.pos 2) (x.trans_le (by nlinarith only [Nat.zero_le a]))
end OMA.RankThreeSmall245212
