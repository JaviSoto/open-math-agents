import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E40P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 3 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b1 : every 4 6 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b2 : every 7 9 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b3 : every 10 12 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b4 : every 13 15 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b5 : every 16 18 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b6 : every 19 21 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b7 : every 22 24 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b8 : every 25 25 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b9 : every 26 26 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b10 : every 27 27 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b11 : every 28 28 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b12 : every 29 29 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b13 : every 30 30 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b14 : every 31 31 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b15 : every 32 32 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b16 : every 33 33 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b17 : every 34 34 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b18 : every 35 35 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b19 : every 36 36 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b20 : every 37 37 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b21 : every 38 38 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b22 : every 39 39 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b23 : every 40 40 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b24 : every 41 41 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b25 : every 42 42 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b26 : every 43 43 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b27 : every 44 44 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b28 : every 45 45 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b29 : every 46 46 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
private theorem b30 : every 47 47 (movingRow 3692890883188542123305 54709494565756179603 1993857135285336323364 13)=true := by decide +kernel
theorem checked : test 3 40 13=true :=
  movingTest (h:=24315330918113857602) (A:=3692890883188542123305) (S:=54709494565756179603) (T:=1993857135285336323364)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery b0 (joinEvery b1 b2)) (joinEvery (joinEvery b3 b4) (joinEvery b5 b6))) (joinEvery (joinEvery (joinEvery b7 b8) (joinEvery b9 b10)) (joinEvery (joinEvery b11 b12) (joinEvery b13 b14)))) (joinEvery (joinEvery (joinEvery (joinEvery b15 b16) (joinEvery b17 b18)) (joinEvery (joinEvery b19 b20) (joinEvery b21 b22))) (joinEvery (joinEvery (joinEvery b23 b24) (joinEvery b25 b26)) (joinEvery (joinEvery b27 b28) (joinEvery b29 b30)))))
#print axioms checked
end OMA.RankThreeAt3E40P13
