import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E17P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 14 28 (finitePair 258280326 16949646395 581130732 9298091736 13)=true := by decide +kernel
private theorem b1 : every 29 36 (finitePair 258280326 16949646395 581130732 9298091736 13)=true := by decide +kernel
private theorem b2 : every 37 40 (finitePair 258280326 16949646395 581130732 9298091736 13)=true := by decide +kernel
private theorem b3 : every 41 42 (finitePair 258280326 16949646395 581130732 9298091736 13)=true := by decide +kernel
private theorem b4 : every 43 46 (finitePair 258280326 16949646395 581130732 9298091736 13)=true := by decide +kernel
private theorem b5 : every 47 52 (finitePair 258280326 16949646395 581130732 9298091736 13)=true := by decide +kernel
private theorem b6 : every 53 58 (finitePair 258280326 16949646395 581130732 9298091736 13)=true := by decide +kernel
private theorem b7 : every 59 60 (finitePair 258280326 16949646395 581130732 9298091736 13)=true := by decide +kernel
private theorem b8 : every 61 66 (finitePair 258280326 16949646395 581130732 9298091736 13)=true := by decide +kernel
private theorem b9 : every 67 70 (finitePair 258280326 16949646395 581130732 9298091736 13)=true := by decide +kernel
private theorem b10 : every 71 72 (finitePair 258280326 16949646395 581130732 9298091736 13)=true := by decide +kernel
private theorem b11 : every 73 78 (finitePair 258280326 16949646395 581130732 9298091736 13)=true := by decide +kernel
private theorem b12 : every 79 79 (finitePair 258280326 16949646395 581130732 9298091736 13)=true := by decide +kernel
theorem checked : test 3 17 13=true :=
  fixedTest (h:=258280326) (A:=16949646395) (S:=581130732) (T:=9298091736)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery b0 (joinEvery b1 b2)) (joinEvery b3 (joinEvery b4 b5))) (joinEvery (joinEvery b6 (joinEvery b7 b8)) (joinEvery (joinEvery b9 b10) (joinEvery b11 b12))))
#print axioms checked
end OMA.RankThreeAt3E17P13
