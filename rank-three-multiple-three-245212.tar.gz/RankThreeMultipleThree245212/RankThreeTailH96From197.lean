import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_197_0 : every 198 100 (quick 96 2247 252 1152 197)=true := by decide +kernel
private theorem b96_197_1 : every 1 25 (far 96 2247 252 1152 197 198 22)=true := by decide +kernel
private theorem b96_197_2 : every 26 45 (far 96 2247 252 1152 197 198 22)=true := by decide +kernel
private theorem r96_197 : every 197 197 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 197=true := by change (every 198 100 (quick 96 2247 252 1152 197) && every 1 45 (far 96 2247 252 1152 197 198 22))=true; rw [Bool.and_eq_true]; exact ⟨b96_197_0,(joinEvery b96_197_1 b96_197_2)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=197 by omega] using yes
private theorem b96_197_3 : every 198 198 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_197_4 : every 200 99 (quick 96 2247 252 1152 199)=true := by decide +kernel
private theorem b96_197_5 : every 1 25 (far 96 2247 252 1152 199 200 22)=true := by decide +kernel
private theorem b96_197_6 : every 26 46 (far 96 2247 252 1152 199 200 22)=true := by decide +kernel
private theorem r96_199 : every 199 199 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 199=true := by change (every 200 99 (quick 96 2247 252 1152 199) && every 1 46 (far 96 2247 252 1152 199 200 22))=true; rw [Bool.and_eq_true]; exact ⟨b96_197_4,(joinEvery b96_197_5 b96_197_6)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=199 by omega] using yes
private theorem b96_197_7 : every 200 210 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_197_8 : every 212 98 (quick 96 2247 252 1152 211)=true := by decide +kernel
private theorem b96_197_9 : every 1 25 (far 96 2247 252 1152 211 212 21)=true := by decide +kernel
private theorem b96_197_10 : every 26 49 (far 96 2247 252 1152 211 212 21)=true := by decide +kernel
private theorem r96_211 : every 211 211 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 211=true := by change (every 212 98 (quick 96 2247 252 1152 211) && every 1 49 (far 96 2247 252 1152 211 212 21))=true; rw [Bool.and_eq_true]; exact ⟨b96_197_8,(joinEvery b96_197_9 b96_197_10)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=211 by omega] using yes
private theorem b96_197_11 : every 212 220 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_197_220 : every 197 220 (run 96 2247 252 1152)=true := (joinEvery (joinEvery r96_197 (joinEvery b96_197_3 r96_199)) (joinEvery b96_197_7 (joinEvery r96_211 b96_197_11)))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_197_220
