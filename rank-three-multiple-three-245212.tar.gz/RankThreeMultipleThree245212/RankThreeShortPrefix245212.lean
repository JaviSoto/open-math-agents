import CofactorEulerDecision245212

/-! Three odd primes at dyadic exponent one. A pair of large exponents
already contributes too much weighted divisor mass; each remaining short
prime power gives a two-free-prime cofactor certificate. -/
namespace OMA.RankThreeMiddle245212
open Nat Finset ArithmeticFunction OMA.Smooth245212 OMA.CofactorEulerPair245212
open scoped ArithmeticFunction.sigma
open private OMA.Large245212.moments from LargeExact245212
open private OMA.FixedExponents245212.y_pos from FixedExponents245212

def test (s b p : ℕ) : Bool :=
  let h:=2*s^b
  let A:=5*OMA.Large245212.wt s b
  let S:=3*OMA.Large245212.sig s b
  let T:=4*OMA.Large245212.tax s b
  decide (A+S≤2*T) && nextPrime h A S T p

def rangeCheck (s p limit : ℕ) := (List.range (limit-1)).all fun i=>test s (i+1) p

private theorem base (s b : ℕ) (hs : s.Prime) (os : 3 ≤ s) :
    W (2*s^b)=5*OMA.Large245212.wt s b ∧ σ 1 (2*s^b)=3*OMA.Large245212.sig s b ∧
    2*s^b*σ 0 (2*s^b)=4*OMA.Large245212.tax s b := by
  obtain ⟨y,x⟩:=OMA.Large245212.moments hs b
  have two : W 2=5 ∧ σ 1 2=3 ∧ σ 0 2=2 := by decide +kernel
  have cop := ((coprime_primes prime_two hs).mpr (by omega)).pow_right b
  simp only [w_mult.map_mul_of_coprime cop,isMultiplicative_sigma.map_mul_of_coprime cop,
    sigma_zero_apply_prime_pow hs,two.1,two.2.1,two.2.2,x,y,OMA.Large245212.tax]
  constructor
  · trivial
  constructor
  · trivial
  ring

private theorem of_range {s p q a e f L : ℕ} (hs : s.Prime) (hp : p.Prime) (hq : q.Prime)
    (os : 3 ≤ s) (op : 3≤p) (sp : s≠p) (sq : s≠q) (pq : p<q)
    (aa : 0<a) (ee : 0<e) (ff : 0<f) (short : a<L) (cert : rangeCheck s p L=true) :
    OeisA245212.a (2*s^a*p^e*q^f)≠(σ 1 (2*s^a*p^e*q^f):ℤ) := by
  obtain ⟨i,rfl⟩ := Nat.exists_eq_succ_of_ne_zero aa.ne'
  have t:=List.all_eq_true.mp cert i (List.mem_range.mpr (by omega))
  simp only [test,Bool.and_eq_true,decide_eq_true_eq] at t
  obtain ⟨w,y,tau⟩:=base s (i+1) hs os
  have cs (r : ℕ) (hr : r.Prime) (lo : 3≤r) (different : s≠r) : (2*s^(i+1)).Coprime r :=
    ((coprime_primes prime_two hr).mpr (by omega)).mul_left
      (((coprime_primes hs hr).mpr different).pow_left _)
  have s0:=hs.pos
  apply original_at_prime (by positivity) hp hq op (cs p hp op sp) (cs q hq (by omega) sq) pq ee ff
  · simpa only [w,y,tau] using t.1
  · simpa only [w,y,tau] using t.2

private theorem weighted {p q a e f : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 5≤p) (pq : p<q)
    (eqn : OeisA245212.a (2*3^a*p^e*q^f)=(σ 1 (2*3^a*p^e*q^f):ℤ)) :
    5*X 3 (some a)*X p (some e)<8 := by
  let P : Fin 4→ℕ := ![2,3,p,q]
  let E : Fin 4→ℕ := ![1,a,e,f]
  have pr (i : Fin 4) : (P i).Prime := by fin_cases i <;> simp [P,prime_two,prime_three,hp,hq]
  have inj : P.Injective := by intro i j h;fin_cases i <;> fin_cases j <;> simp_all [P] <;> omega
  have id : total P E=2*3^a*p^e*q^f := by simp [total,P,E,Fin.prod_univ_four,mul_assoc]
  have eq := OMA.Smooth245212.normalized_of_eq P pr inj E (id ▸ eqn)
  have pos : (0:ℚ)<∏ i,Y (P i) (some (E i)) :=
    prod_pos (fun i _ => OMA.FixedExponents245212.y_pos (pr i) _)
  have xprod : (∏ i,X (P i) (some (E i)))<2 := by unfold OMA.Smooth245212.normalized at eq;linarith
  have half : X 2 (some 1)=5/4 := by decide +kernel
  rw [Fin.prod_univ_four] at xprod
  change X 2 (some 1)*X 3 (some a)*X p (some e)*X q (some f)<2 at xprod
  rw [half] at xprod
  have unit : 1≤X q (some f) := le_add_of_nonneg_right (div_nonneg (sub_nonneg.mpr (y_one hq.one_lt _))
    (sub_nonneg.mpr (by exact_mod_cast hq.one_le)))
  have no := mul_le_mul_of_nonneg_left unit (mul_nonneg (x_nonneg (by decide : 1<3) (some a)) (x_nonneg hp.one_lt (some e)))
  nlinarith only [xprod,no]

private theorem rises {p n a : ℕ} (hp : 1<p) (lo : n≤a) : X p (some n)≤X p (some a) := by
  exact add_le_add_right (div_le_div_of_nonneg_right (sub_le_sub_left (y_anti hp lo) 1)
    (sub_nonneg.mpr (by exact_mod_cast hp.le))) 1

theorem close_short_prefix {p q a e f L M : ℕ} (hp : p.Prime) (hq : q.Prime) (op : 5≤p) (pq : p<q)
    (aa : 0<a) (ee : 0<e) (ff : 0<f)
    (above : 8≤5*X 3 (some L)*X p (some M))
    (left : rangeCheck 3 p L=true) (right : rangeCheck p 3 M=true) :
    OeisA245212.a (2*3^a*p^e*q^f)≠(σ 1 (2*3^a*p^e*q^f):ℤ) := by
  by_cases first : a<L
  · exact of_range prime_three hp hq le_rfl (by omega) (by omega) (by omega) pq aa ee ff first left
  by_cases second : e<M
  · have kill := of_range hp prime_three hq (by omega) le_rfl (by omega) pq.ne (by omega) ee aa ff second right
    rwa [mul_right_comm 2 (p^e) (3^a)] at kill
  intro eqn
  have stop := weighted hp hq op pq eqn
  have mono := mul_le_mul (rises (by decide : 1<3) (by omega : L≤a))
    (rises hp.one_lt (by omega : M≤e)) (x_nonneg hp.one_lt _) (x_nonneg (by decide : 1<3) _)
  nlinarith only [stop,above,mono]

#print axioms close_short_prefix
end OMA.RankThreeMiddle245212
