import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E41P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 3 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b1 : every 4 6 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b2 : every 7 9 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b3 : every 10 12 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b4 : every 13 15 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b5 : every 16 18 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b6 : every 19 22 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b7 : every 23 23 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b8 : every 24 24 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b9 : every 25 25 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b10 : every 26 26 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b11 : every 27 27 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b12 : every 28 28 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b13 : every 29 29 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b14 : every 30 30 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b15 : every 31 31 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b16 : every 32 32 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b17 : every 33 33 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b18 : every 34 34 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b19 : every 35 35 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b20 : every 36 36 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b21 : every 37 37 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b22 : every 38 38 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b23 : every 39 39 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b24 : every 40 40 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b25 : every 41 41 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b26 : every 42 42 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
private theorem b27 : every 43 43 (movingRow 11352220122394407267935 164128483697268538812 6127463391364692115704 13)=true := by decide +kernel
theorem checked : test 3 41 13=true :=
  movingTest (h:=72945992754341572806) (A:=11352220122394407267935) (S:=164128483697268538812) (T:=6127463391364692115704)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery b0 (joinEvery b1 b2)) (joinEvery (joinEvery b3 b4) (joinEvery b5 b6))) (joinEvery (joinEvery b7 (joinEvery b8 b9)) (joinEvery (joinEvery b10 b11) (joinEvery b12 b13)))) (joinEvery (joinEvery (joinEvery b14 (joinEvery b15 b16)) (joinEvery (joinEvery b17 b18) (joinEvery b19 b20))) (joinEvery (joinEvery b21 (joinEvery b22 b23)) (joinEvery (joinEvery b24 b25) (joinEvery b26 b27)))))
#print axioms checked
end OMA.RankThreeAt3E41P13
