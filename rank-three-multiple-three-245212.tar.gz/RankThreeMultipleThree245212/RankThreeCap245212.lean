import DyadicEuler245212

/-! Dyadic exponent one, with three odd bases. Keeping one actual
Euler factor also gives a lower bound for each exponent near the cap. -/
namespace OMA.RankThreeCap245212
open Finset Nat OMA.Smooth245212 OMA.OddFaces245212
open scoped ArithmeticFunction.sigma
open private OMA.OddFaces245212.envelope from OddAbundancy245212

theorem norm {p q r a b c : ℕ} (hp : p.Prime) (hq : q.Prime) (hr : r.Prime)
    (po : 2<p) (pq : p<q) (qr : q<r)
    (eq : OeisA245212.a (2*p^a*q^b*r^c)=(σ 1 (2*p^a*q^b*r^c):ℤ)) :
    5*(X p (some a)*X q (some b)*X r (some c))+
      3*(Y p (some a)*Y q (some b)*Y r (some c))=8 := by
  let P : Fin 4 → ℕ := ![2,p,q,r]
  let E : Fin 4 → ℕ := ![1,a,b,c]
  have pr (i : Fin 4) : (P i).Prime := by fin_cases i <;> simp [P,hp,hq,hr,prime_two]
  have inj : P.Injective := by intro i j h; fin_cases i <;> fin_cases j <;> simp_all [P] <;> omega
  have repr : total P E=2*p^a*q^b*r^c := by simp [total,Fin.prod_univ_four,P,E,mul_assoc]
  have n := normalized_of_eq P pr inj E (repr ▸ eq)
  have x : X 2 (some 1)=5/4 := by decide +kernel
  have y : Y 2 (some 1)=3/4 := by decide +kernel
  simp [normalized,Fin.prod_univ_four,P,E,x,y] at n
  linarith

theorem caps {p q r a b c : ℕ} (hp : 1<p) (hq : 1<q) (hr : 1<r) (ap : 0<a)
    (eq : 5*(X p (some a)*X q (some b)*X r (some c))+
      3*(Y p (some a)*Y q (some b)*Y r (some c))=8) :
    8≤5*(limitX p*limitX q*limitX r) := by
  let P : Fin 3 → ℕ := ![p,q,r]
  let E : Fin 3 → ℕ := ![a,b,c]
  have pr (i : Fin 3) : 1<P i := by fin_cases i <;> simp [P,hp,hq,hr]
  have x : X 2 (some 1)=5/4 := by decide +kernel
  have y : Y 2 (some 1)=3/4 := by decide +kernel
  have val : X 2 (some 1)*(∏ i,X (P i) (some (E i)))+
      Y 2 (some 1)*(∏ i,Y (P i) (some (E i)))=2 := by
    rw [x,y]; simp [Fin.prod_univ_three,P,E]; linarith
  have t := OMA.DyadicEuler245212.cap_needed_at_two 1 P E pr 0 ap val
  simp [Fin.prod_univ_three,P,x] at t
  linarith

theorem one_cap {p q r a b c : ℕ} (hp : 3≤p) (hq : 1<q) (hr : 1<r) (bp : 0<b)
    (eq : 5*(X p (some a)*X q (some b)*X r (some c))+
      3*(Y p (some a)*Y q (some b)*Y r (some c))=8) :
    8≤5*X p (some a)*(limitX q*limitX r) := by
  have pg : 1<p := by omega
  have p' : (3:ℚ)≤p := by exact_mod_cast hp
  have sp : (0:ℚ)<p-1 := by linarith
  have yp := y_one pg (some a)
  have sum_bound : 5*X p (some a)+3*Y p (some a)≤8 := by
    unfold X; apply (le_of_mul_le_mul_right · sp)
    field_simp
    nlinarith only [mul_nonneg (sub_nonneg.mpr (show (8:ℚ)≤3*p by linarith)) (sub_nonneg.mpr yp)]
  let P : Fin 2 → ℕ := ![q,r]
  let E : Fin 2 → ℕ := ![b,c]
  have pr (i : Fin 2) : 1<P i := by fin_cases i <;> simp [P,hq,hr]
  have env := OMA.OddFaces245212.envelope univ P E pr
  simp [Fin.prod_univ_two,P,E] at env
  let T := Y q (some b)*Y r (some c)
  let U := limitX q*limitX r
  change X q (some b)*X r (some c)≤T+(1-T)*U at env
  have qb : Y q (some b)<1 := by simpa [y_avg hq] using OMA.Abundance245212.y_strict hq bp
  have ltT : T<1 := (mul_le_of_le_one_right (y_nonneg hq _) (y_one hr _)).trans_lt qb
  have T0 : 0≤T := mul_nonneg (y_nonneg hq _) (y_nonneg hr _)
  have W := mul_le_mul_of_nonneg_left env (mul_nonneg (by decide : (0:ℚ)≤5) (x_nonneg pg (some a)))
  change 8≤5*X p (some a)*U
  by_contra! bad
  have h : 5*(X p (some a)*(X q (some b)*X r (some c)))+3*(Y p (some a)*T)=8 := by
    simpa only [T,mul_assoc] using eq
  nlinarith only [W,h,mul_le_mul_of_nonneg_right sum_bound T0,mul_pos (sub_pos.mpr ltT) (sub_pos.mpr bad)]

theorem ordered {p q r : ℕ} (_hp : p.Prime) (hq : q.Prime) (hr : r.Prime)
    (p5 : 5≤p) (pq : p<q) (qr : q<r) (cap : 8≤5*(limitX p*limitX q*limitX r)) :
    p=5 ∧ q=7 ∧ r=11 := by
  have veto (u v w : ℕ) (hu : 1<u) (hv : 1<v) (hw : 1<w) (up : u≤p) (vq : v≤q) (wr : w≤r)
      (bad : 5*(limitX u*limitX v*limitX w)<8) : False := by
    have l := mul_le_mul (mul_le_mul (cap_anti hu up) (cap_anti hv vq)
      (x_nonneg hq.one_lt none) (x_nonneg hu none)) (cap_anti hw wr)
      (x_nonneg hr.one_lt none) (mul_nonneg (x_nonneg hu none) (x_nonneg hv none))
    linarith
  have q7 : 7≤q := by by_contra! h; interval_cases q <;> norm_num at * <;> omega
  have r11 : 11≤r := by by_contra! h; interval_cases r <;> norm_num at * <;> omega
  have pp : p=5 := by
    by_contra h
    exact veto 6 7 11 (by decide +kernel) (by decide +kernel) (by decide +kernel) (by omega) q7 r11 (by decide +kernel)
  have qq : q=7 := by
    by_contra h
    exact veto 5 8 11 (by decide +kernel) (by decide +kernel) (by decide +kernel) p5 (by omega) r11 (by decide +kernel)
  have rr : r=11 := by
    by_contra h
    exact veto 5 7 12 (by decide +kernel) (by decide +kernel) (by decide +kernel) p5 q7 (by omega) (by decide +kernel)
  exact ⟨pp,qq,rr⟩
end OMA.RankThreeCap245212
