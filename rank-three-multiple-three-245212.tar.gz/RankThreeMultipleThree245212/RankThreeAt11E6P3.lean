import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt11E6P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 3 (movingRow 67230740 5846151 49603708 3)=true := by decide +kernel
private theorem b1 : every 4 7 (movingRow 67230740 5846151 49603708 3)=true := by decide +kernel
private theorem b2 : every 8 12 (movingRow 67230740 5846151 49603708 3)=true := by decide +kernel
private theorem b3 : every 13 17 (movingRow 67230740 5846151 49603708 3)=true := by decide +kernel
private theorem b4 : every 18 22 (movingRow 67230740 5846151 49603708 3)=true := by decide +kernel
private theorem b5 : every 23 28 (movingRow 67230740 5846151 49603708 3)=true := by decide +kernel
private theorem b6 : every 29 30 (movingRow 67230740 5846151 49603708 3)=true := by decide +kernel
private theorem b7 : every 31 31 (movingRow 67230740 5846151 49603708 3)=true := by decide +kernel
private theorem b8 : every 32 32 (movingRow 67230740 5846151 49603708 3)=true := by decide +kernel
private theorem b9 : every 33 33 (movingRow 67230740 5846151 49603708 3)=true := by decide +kernel
private theorem b10 : every 34 34 (movingRow 67230740 5846151 49603708 3)=true := by decide +kernel
private theorem b11 : every 35 35 (movingRow 67230740 5846151 49603708 3)=true := by decide +kernel
private theorem b12 : every 36 36 (movingRow 67230740 5846151 49603708 3)=true := by decide +kernel
private theorem b13 : every 37 37 (movingRow 67230740 5846151 49603708 3)=true := by decide +kernel
private theorem b14 : every 38 38 (movingRow 67230740 5846151 49603708 3)=true := by decide +kernel
private theorem b15 : every 39 39 (movingRow 67230740 5846151 49603708 3)=true := by decide +kernel
private theorem b16 : every 40 40 (movingRow 67230740 5846151 49603708 3)=true := by decide +kernel
private theorem b17 : every 41 41 (movingRow 67230740 5846151 49603708 3)=true := by decide +kernel
theorem checked : test 11 6 3=true :=
  movingTest (h:=3543122) (A:=67230740) (S:=5846151) (T:=49603708)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 b3)) (joinEvery (joinEvery b4 b5) (joinEvery b6 (joinEvery b7 b8)))) (joinEvery (joinEvery (joinEvery b9 b10) (joinEvery b11 b12)) (joinEvery (joinEvery b13 b14) (joinEvery b15 (joinEvery b16 b17)))))
#print axioms checked
end OMA.RankThreeAt11E6P3
