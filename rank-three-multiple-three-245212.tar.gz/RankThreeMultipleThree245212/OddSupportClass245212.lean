import OddFinite245212
import TriSupport245212

/-! Reduction of arbitrary odd support of cardinality at most four to
three ternary supports and the classified four-prime branch. -/
namespace OMA.OddSupportClass245212
open Finset Nat ArithmeticFunction OMA.Smooth245212 OMA.OddFaces245212
open scoped ArithmeticFunction.sigma
open private OMA.OddFaces245212.envelope from OddAbundancy245212

private theorem skip {p l u : ℕ} (hp : p.Prime) (low : l≤p)
    (empty : ∀ j∈Ico l u, ¬ Nat.Prime j) : u≤p := by
  by_contra! bad
  exact empty p (mem_Ico.mpr ⟨low,bad⟩) hp

private theorem tiny {k : ℕ} (p z : Fin k → ℕ) (gz : ∀ i,1<z i)
    (lz : ∀ i,z i≤p i) (cap : 2≤∏ i,limitX (p i)) (small : (∏ i,limitX (z i))<2) : False := by
  have le := prod_le_prod (s:=univ) (fun i _ => x_nonneg ((gz i).trans_le (lz i)) none)
    (fun i _ => cap_anti (gz i) (lz i))
  exact (cap.trans le).not_gt small

private theorem first_one (p e : Fin 4 → ℕ) (hp : ∀ i, (p i).Prime)
    (p0 : p 0=3) (e0 : e 0=1) (p1 : 5≤p 1) (p2 : 7≤p 2) (p3 : 11≤p 3)
    (norm : normalized p e=2) : False := by
  let z : Fin 3 → ℕ := ![5,7,11]
  let T := ∏ i : Fin 3, Y (p i.succ) (some (e i.succ))
  let C := ∏ i : Fin 3, limitX (p i.succ)
  let B := ∏ i : Fin 3, X (p i.succ) (some (e i.succ))
  have env : B≤T+(1-T)*C := OMA.OddFaces245212.envelope univ
    (fun i : Fin 3 => p i.succ) (fun i => e i.succ) (fun i => (hp _).one_lt)
  have tz : 0≤T := prod_nonneg (fun i _ => y_nonneg (hp _).one_lt _)
  have tone : T≤1 := prod_le_one (fun i _ => y_nonneg (hp _).one_lt _) (fun i _ => y_one (hp _).one_lt _)
  have lo (i : Fin 3) : z i ≤ p i.succ := by fin_cases i <;> first | exact p1 | exact p2 | exact p3
  have gc : ∀ i, 1<z i := by decide
  have c : C≤(∏ i,limitX (z i)) := prod_le_prod (s:=univ)
    (fun i _ => x_nonneg (hp _).one_lt _) (fun i _ => cap_anti (gc i) (lo i))
  have vc : (∏ i,limitX (z i))=77/48 := by decide +kernel
  rw [vc] at c
  have ca := mul_le_mul_of_nonneg_left c (sub_nonneg.mpr tone)
  unfold normalized at norm
  rw [Fin.prod_univ_succ (fun i => X (p i) (some (e i))),
    Fin.prod_univ_succ (fun i => Y (p i) (some (e i))),p0,e0] at norm
  change X 3 (some 1)*B+Y 3 (some 1)*T=2 at norm
  have x : X 3 (some 1)=7/6 := by decide +kernel
  have y : Y 3 (some 1)=2/3 := by decide +kernel
  rw [x,y] at norm
  linarith only [tz,tone,ca,env,norm]

def ThreeExcluded := ∀ q, OMA.TriSupport245212.supported q → ∀ e : Fin 3 → ℕ,
  (∀ i,0<e i) → OeisA245212.a (total (bases q) e) ≠ (σ 1 (total (bases q) e) : ℤ)
def FourExcluded := ∀ k p q r e f g : ℕ, 2≤k → p.Prime → q.Prime → r.Prime →
  5≤p → p<q → q<r → 0<e → 0<f → 0<g →
  OeisA245212.a (3^k*p^e*q^f*r^g) ≠ (σ 1 (3^k*p^e*q^f*r^g) : ℤ)

private theorem sorted (three : ThreeExcluded) {k : ℕ} (four : k=4 → FourExcluded) (few : k≤4)
    (p e : Fin k → ℕ) (hp : ∀ i, (p i).Prime) (ord : StrictMono p) (odd : ∀ i,3≤p i)
    (pos : ∀ i,0 < e i) (eq : OeisA245212.a (total p e)=(σ 1 (total p e):ℤ)) : total p e=1 := by
  have norm := normalized_of_eq p hp ord.injective e eq
  have cap (i : Fin k) := cap_needed p e (fun j => (hp j).one_lt) i (pos i) norm
  interval_cases k
  · simp [total]
  · exfalso
    exact tiny p ![3] (by decide) (fun j => by fin_cases j; exact odd 0) (cap 0) (by decide +kernel)
  · exfalso
    have h5 : 5≤p 1 := skip (hp 1) (show 4≤p 1 by have := ord (by decide : (0:Fin 2)<1); have := odd 0; omega) (by decide)
    exact tiny p ![3,5] (by decide) (fun j => by fin_cases j; exact odd 0; exact h5) (cap 0) (by decide +kernel)
  · exfalso
    have a := ord (by decide : (0:Fin 3)<1)
    have b := ord (by decide : (1:Fin 3)<2)
    have p0 := odd 0
    have p5 : 5≤p 1 := skip (hp 1) (show 4≤p 1 by omega) (by decide)
    have p7 : 7≤p 2 := skip (hp 2) (show 6≤p 2 by omega) (by decide)
    have first : p 0=3 := by
      by_contra! bad
      have a5 : 5≤p 0 := skip (hp 0) (show 4≤p 0 by omega) (by decide)
      have a7 : 7≤p 1 := skip (hp 1) (show 6≤p 1 by omega) (by decide)
      have a11 : 11≤p 2 := skip (hp 2) (show 8≤p 2 by omega) (by decide)
      exact tiny p ![5,7,11] (by decide) (fun i => by fin_cases i <;> first | exact a5 | exact a7 | exact a11) (cap 0) (by decide +kernel)
    have second : p 1=5 := by
      by_contra! bad
      have a7 : 7≤p 1 := skip (hp 1) (show 6≤p 1 by omega) (by decide)
      have a11 : 11≤p 2 := skip (hp 2) (show 8≤p 2 by omega) (by decide)
      exact tiny p ![3,7,11] (by decide) (fun i => by fin_cases i <;> first | exact p0 | exact a7 | exact a11) (cap 0) (by decide +kernel)
    have mx : p 2<17 := by
      by_contra! bad
      exact tiny p ![3,5,17] (by decide) (fun i => by fin_cases i <;> first | exact p0 | exact p5 | exact bad) (cap 0) (by decide +kernel)
    have last : OMA.TriSupport245212.supported (p 2) := by
      have pr := hp 2
      generalize p 2=z at p7 mx pr ⊢
      interval_cases z <;> norm_num [OMA.TriSupport245212.supported] at *
    have same : bases (p 2)=p := by
      funext i
      fin_cases i <;> simp [bases,first,second]
    exact three (p 2) last e pos (same ▸ eq)
  · exfalso
    have a := ord (by decide : (0:Fin 4)<1)
    have b := ord (by decide : (1:Fin 4)<2)
    have c := ord (by decide : (2:Fin 4)<3)
    have p0 := odd 0
    have p5 : 5≤p 1 := skip (hp 1) (show 4≤p 1 by omega) (by decide)
    have p7 : 7≤p 2 := skip (hp 2) (show 6≤p 2 by omega) (by decide)
    have p11 : 11≤p 3 := skip (hp 3) (show 8≤p 3 by omega) (by decide)
    have first : p 0=3 := by
      by_contra! bad
      have a5 : 5≤p 0 := skip (hp 0) (show 4≤p 0 by omega) (by decide)
      have a7 : 7≤p 1 := skip (hp 1) (show 6≤p 1 by omega) (by decide)
      have a11 : 11≤p 2 := skip (hp 2) (show 8≤p 2 by omega) (by decide)
      have a13 : 13≤p 3 := skip (hp 3) (show 12≤p 3 by omega) (by decide)
      exact tiny p ![5,7,11,13] (by decide)
        (fun i => by fin_cases i <;> first | exact a5 | exact a7 | exact a11 | exact a13) (cap 0) (by decide +kernel)
    by_cases one : e 0=1
    · exact first_one p e hp first one p5 p7 p11 norm
    · have ge : 2≤e 0 := by have := pos 0; omega
      apply four rfl (e 0) (p 1) (p 2) (p 3) (e 1) (e 2) (e 3) ge (hp 1) (hp 2) (hp 3)
        p5 b c (pos 1) (pos 2) (pos 3)
      simpa only [total,Fin.prod_univ_four,first,mul_assoc] using eq

theorem classify (three : ThreeExcluded) (n : ℕ) (odd : Odd n) (few : n.primeFactors.card≤4)
    (four : n.primeFactors.card=4 → FourExcluded) (eq : OeisA245212.a n=(σ 1 n:ℤ)) : n=1 := by
  let S := n.primeFactors
  let p := S.orderEmbOfFin rfl
  let e (i : Fin S.card) := n.factorization (p i)
  have mem (i) : p i∈n.primeFactors := orderEmbOfFin_mem S rfl i
  have hp (i) := Nat.prime_of_mem_primeFactors (mem i)
  have op (i) : 3≤p i := by
    have h := (hp i).two_le
    have a := Nat.dvd_of_mem_primeFactors (mem i)
    have non : ¬2∣n := fun d => (Nat.not_even_iff_odd.mpr odd) (even_iff_two_dvd.mpr d)
    by_contra! lt
    have same : p i=2 := by omega
    exact non (same ▸ a)
  have ep (i) : 0<e i := (hp i).factorization_pos_of_dvd odd.pos.ne' (Nat.dvd_of_mem_primeFactors (mem i))
  have repr : total p e=n := by
    unfold total e
    exact (Fintype.prod_equiv (S.orderIsoOfFin rfl).toEquiv _
      (fun j : S => j.val^(n.factorization j.val)) (fun _ => rfl)).trans
      (Nat.prod_primeFactors_coe_pow_factorization odd.pos.ne').symm
  simpa only [repr] using sorted three four few p e hp p.strictMono op ep (by rw [repr]; exact eq)

end OMA.OddSupportClass245212
