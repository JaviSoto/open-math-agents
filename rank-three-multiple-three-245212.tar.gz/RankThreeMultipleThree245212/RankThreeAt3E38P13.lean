import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E38P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 3 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b1 : every 4 6 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b2 : every 7 9 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b3 : every 10 12 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b4 : every 13 15 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b5 : every 16 18 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b6 : every 19 21 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b7 : every 22 24 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b8 : every 25 27 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b9 : every 28 31 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b10 : every 32 32 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b11 : every 33 33 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b12 : every 34 34 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b13 : every 35 35 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b14 : every 36 36 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b15 : every 37 37 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b16 : every 38 38 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b17 : every 39 39 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b18 : every 40 40 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b19 : every 41 41 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b20 : every 42 42 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b21 : every 43 43 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b22 : every 44 44 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b23 : every 45 45 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b24 : every 46 46 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b25 : every 47 47 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b26 : every 48 48 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b27 : every 49 49 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b28 : every 50 50 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b29 : every 51 51 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b30 : every 52 52 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b31 : every 53 53 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b32 : every 54 54 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b33 : every 55 55 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b34 : every 56 56 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b35 : every 57 57 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b36 : every 58 58 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
private theorem b37 : every 59 59 (movingRow 390058433478076465700 6078832729528464399 210732867956986765884 13)=true := by decide +kernel
theorem checked : test 3 38 13=true :=
  movingTest (h:=2701703435345984178) (A:=390058433478076465700) (S:=6078832729528464399) (T:=210732867956986765884)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 b3)) (joinEvery (joinEvery b4 b5) (joinEvery b6 (joinEvery b7 b8)))) (joinEvery (joinEvery (joinEvery b9 b10) (joinEvery b11 (joinEvery b12 b13))) (joinEvery (joinEvery b14 b15) (joinEvery b16 (joinEvery b17 b18))))) (joinEvery (joinEvery (joinEvery (joinEvery b19 b20) (joinEvery b21 b22)) (joinEvery (joinEvery b23 b24) (joinEvery b25 (joinEvery b26 b27)))) (joinEvery (joinEvery (joinEvery b28 b29) (joinEvery b30 (joinEvery b31 b32))) (joinEvery (joinEvery b33 b34) (joinEvery b35 (joinEvery b36 b37))))))
#print axioms checked
end OMA.RankThreeAt3E38P13
