import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b48_29_0 : every 30 76 (quick 48 903 124 480 29)=true := by decide +kernel
private theorem b48_29_1 : every 1 9 (far 48 903 124 480 29 77 20)=true := by decide +kernel
private theorem r48_29 : every 29 29 (run 48 903 124 480)=true := by
  have yes : run 48 903 124 480 29=true := by change (every 30 76 (quick 48 903 124 480 29) && every 1 9 (far 48 903 124 480 29 77 20))=true; rw [Bool.and_eq_true]; exact ⟨b48_29_0,b48_29_1⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=29 by omega] using yes
private theorem b48_29_2 : every 30 30 (run 48 903 124 480)=true := by decide +kernel
private theorem b48_29_3 : every 32 70 (quick 48 903 124 480 31)=true := by decide +kernel
private theorem b48_29_4 : every 1 10 (far 48 903 124 480 31 71 18)=true := by decide +kernel
private theorem r48_31 : every 31 31 (run 48 903 124 480)=true := by
  have yes : run 48 903 124 480 31=true := by change (every 32 70 (quick 48 903 124 480 31) && every 1 10 (far 48 903 124 480 31 71 18))=true; rw [Bool.and_eq_true]; exact ⟨b48_29_3,b48_29_4⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=31 by omega] using yes
private theorem b48_29_5 : every 32 36 (run 48 903 124 480)=true := by decide +kernel
private theorem b48_29_6 : every 38 59 (quick 48 903 124 480 37)=true := by decide +kernel
private theorem b48_29_7 : every 1 11 (far 48 903 124 480 37 60 15)=true := by decide +kernel
private theorem r48_37 : every 37 37 (run 48 903 124 480)=true := by
  have yes : run 48 903 124 480 37=true := by change (every 38 59 (quick 48 903 124 480 37) && every 1 11 (far 48 903 124 480 37 60 15))=true; rw [Bool.and_eq_true]; exact ⟨b48_29_6,b48_29_7⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=37 by omega] using yes
private theorem b48_29_8 : every 38 40 (run 48 903 124 480)=true := by decide +kernel
private theorem b48_29_9 : every 42 54 (quick 48 903 124 480 41)=true := by decide +kernel
private theorem b48_29_10 : every 1 12 (far 48 903 124 480 41 55 14)=true := by decide +kernel
private theorem r48_41 : every 41 41 (run 48 903 124 480)=true := by
  have yes : run 48 903 124 480 41=true := by change (every 42 54 (quick 48 903 124 480 41) && every 1 12 (far 48 903 124 480 41 55 14))=true; rw [Bool.and_eq_true]; exact ⟨b48_29_9,b48_29_10⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=41 by omega] using yes
private theorem b48_29_11 : every 42 42 (run 48 903 124 480)=true := by decide +kernel
private theorem b48_29_12 : every 44 53 (quick 48 903 124 480 43)=true := by decide +kernel
private theorem b48_29_13 : every 1 13 (far 48 903 124 480 43 54 13)=true := by decide +kernel
private theorem r48_43 : every 43 43 (run 48 903 124 480)=true := by
  have yes : run 48 903 124 480 43=true := by change (every 44 53 (quick 48 903 124 480 43) && every 1 13 (far 48 903 124 480 43 54 13))=true; rw [Bool.and_eq_true]; exact ⟨b48_29_12,b48_29_13⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=43 by omega] using yes
private theorem b48_29_14 : every 44 46 (run 48 903 124 480)=true := by decide +kernel
private theorem b48_29_15 : every 48 50 (quick 48 903 124 480 47)=true := by decide +kernel
private theorem b48_29_16 : every 1 14 (far 48 903 124 480 47 51 13)=true := by decide +kernel
private theorem r48_47 : every 47 47 (run 48 903 124 480)=true := by
  have yes : run 48 903 124 480 47=true := by change (every 48 50 (quick 48 903 124 480 47) && every 1 14 (far 48 903 124 480 47 51 13))=true; rw [Bool.and_eq_true]; exact ⟨b48_29_15,b48_29_16⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=47 by omega] using yes
private theorem b48_29_17 : every 48 52 (run 48 903 124 480)=true := by decide +kernel
theorem span48_29_52 : every 29 52 (run 48 903 124 480)=true := (joinEvery (joinEvery (joinEvery r48_29 (joinEvery b48_29_2 r48_31)) (joinEvery b48_29_5 (joinEvery r48_37 b48_29_8))) (joinEvery (joinEvery r48_41 (joinEvery b48_29_11 r48_43)) (joinEvery b48_29_14 (joinEvery r48_47 b48_29_17))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span48_29_52
