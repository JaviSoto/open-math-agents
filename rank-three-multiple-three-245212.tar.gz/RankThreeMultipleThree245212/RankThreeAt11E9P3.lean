import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt11E9P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 2 (movingRow 128390251775 7781227380 94317907640 3)=true := by decide +kernel
private theorem b1 : every 3 4 (movingRow 128390251775 7781227380 94317907640 3)=true := by decide +kernel
private theorem b2 : every 5 7 (movingRow 128390251775 7781227380 94317907640 3)=true := by decide +kernel
private theorem b3 : every 8 11 (movingRow 128390251775 7781227380 94317907640 3)=true := by decide +kernel
private theorem b4 : every 12 15 (movingRow 128390251775 7781227380 94317907640 3)=true := by decide +kernel
private theorem b5 : every 16 20 (movingRow 128390251775 7781227380 94317907640 3)=true := by decide +kernel
private theorem b6 : every 21 23 (movingRow 128390251775 7781227380 94317907640 3)=true := by decide +kernel
private theorem b7 : every 24 24 (movingRow 128390251775 7781227380 94317907640 3)=true := by decide +kernel
private theorem b8 : every 25 25 (movingRow 128390251775 7781227380 94317907640 3)=true := by decide +kernel
private theorem b9 : every 26 26 (movingRow 128390251775 7781227380 94317907640 3)=true := by decide +kernel
private theorem b10 : every 27 27 (movingRow 128390251775 7781227380 94317907640 3)=true := by decide +kernel
private theorem b11 : every 28 28 (movingRow 128390251775 7781227380 94317907640 3)=true := by decide +kernel
private theorem b12 : every 29 29 (movingRow 128390251775 7781227380 94317907640 3)=true := by decide +kernel
private theorem b13 : every 30 30 (movingRow 128390251775 7781227380 94317907640 3)=true := by decide +kernel
private theorem b14 : every 31 31 (movingRow 128390251775 7781227380 94317907640 3)=true := by decide +kernel
private theorem b15 : every 32 32 (movingRow 128390251775 7781227380 94317907640 3)=true := by decide +kernel
theorem checked : test 11 9 3=true :=
  movingTest (h:=4715895382) (A:=128390251775) (S:=7781227380) (T:=94317907640)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 b3)) (joinEvery (joinEvery b4 b5) (joinEvery b6 b7))) (joinEvery (joinEvery (joinEvery b8 b9) (joinEvery b10 b11)) (joinEvery (joinEvery b12 b13) (joinEvery b14 b15))))
#print axioms checked
end OMA.RankThreeAt11E9P3
