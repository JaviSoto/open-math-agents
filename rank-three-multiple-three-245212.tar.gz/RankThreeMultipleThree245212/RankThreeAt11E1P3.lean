import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt11E1P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 4 12 (finitePair 22 115 36 88 3)=true := by decide +kernel
private theorem b1 : every 13 16 (finitePair 22 115 36 88 3)=true := by decide +kernel
private theorem b2 : every 17 18 (finitePair 22 115 36 88 3)=true := by decide +kernel
private theorem b3 : every 19 22 (finitePair 22 115 36 88 3)=true := by decide +kernel
private theorem b4 : every 23 28 (finitePair 22 115 36 88 3)=true := by decide +kernel
private theorem b5 : every 29 30 (finitePair 22 115 36 88 3)=true := by decide +kernel
private theorem b6 : every 31 36 (finitePair 22 115 36 88 3)=true := by decide +kernel
private theorem b7 : every 37 40 (finitePair 22 115 36 88 3)=true := by decide +kernel
private theorem b8 : every 41 42 (finitePair 22 115 36 88 3)=true := by decide +kernel
private theorem b9 : every 43 46 (finitePair 22 115 36 88 3)=true := by decide +kernel
private theorem b10 : every 47 50 (finitePair 22 115 36 88 3)=true := by decide +kernel
theorem checked : test 11 1 3=true :=
  fixedTest (h:=22) (A:=115) (S:=36) (T:=88)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 (joinEvery b3 b4))) (joinEvery (joinEvery b5 (joinEvery b6 b7)) (joinEvery b8 (joinEvery b9 b10))))
#print axioms checked
end OMA.RankThreeAt11E1P3
