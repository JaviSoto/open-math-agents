import LargeExact245212
import PrimePowerDiv245212

/-! Exact-prefix leaves for the final prime and exponent. The two top
digit inequalities first cut the exponent interval by signed linear
inequalities. Power divisibility supplies an independent finite cap. -/

namespace OMA.PrefixLeaf245212
open OMA.LastDigit245212 OMA.Large245212 OMA.Smooth245212 ArithmeticFunction
open scoped ArithmeticFunction.sigma
open private OMA.Large245212.force OMA.Large245212.moments from LargeExact245212

/-- Intersect the natural interval with the single half-space v*d ≤ w. -/
def trim (B : ℕ×ℕ) (v w : ℤ) : ℕ×ℕ :=
  if 0<v then
    if w<0 then (1,0) else (B.1,min B.2 (w/v).toNat)
  else if v<0 then (max B.1 (-(w/(-v))).toNat,B.2)
  else if w<0 then (1,0) else B

private theorem trim_sound {B : ℕ×ℕ} {v w : ℤ} {d : ℕ} (blo : B.1≤d) (bhi : d≤B.2)
    (eq : v*(d:ℤ)≤w) : (trim B v w).1≤d ∧ d≤(trim B v w).2 := by
  unfold trim
  split_ifs with pos neg vn wn
  · have := mul_nonneg pos.le (Int.natCast_nonneg d); omega
  · have v1 : (d:ℤ)≤w/v := (Int.le_ediv_iff_mul_le pos).2 (by simpa [mul_comm] using eq)
    exact ⟨blo,le_min bhi (by omega)⟩
  · have v1 : -(d:ℤ)≤w/(-v) := (Int.le_ediv_iff_mul_le (by omega)).2 (by nlinarith only [eq])
    exact ⟨max_le blo (by omega),bhi⟩
  · have : v=0 := by omega
    simp [this] at eq
    omega
  · exact ⟨blo,bhi⟩

private def slope (A T u : ℕ) : ℤ := ((u:ℤ)+1)*A-2*u*T
private def offset (A S u : ℕ) : ℤ := (A:ℤ)-((u:ℤ)+1)*S

def bounds (A S T rl rh gl gh : ℕ) : ℕ×ℕ :=
  let cap := Nat.log rl (A+rh*S)
  let v := slope A T rh
  let w := offset A S rh
  let B := trim (gl,min gh cap) v (w-v)
  let u := rl-1
  let v' := slope A T u
  let w' := offset A S u
  trim B (-v') (v'-w'-1)

private theorem bounds_sound {A S T rl rh gl gh r d : ℕ} (base : 1<rl)
    (lo : rl≤r) (hi : r≤rh) (dlo : gl≤d) (dhi : d≤gh)
    (positive : 0<denom A S T d)
    (lower : denom A S T d*(r-1)<A*d+S) (upper : A*d+S≤denom A S T d*r)
    (power : r^d≤A+rh*S) :
    (bounds A S T rl rh gl gh).1≤d ∧ d≤(bounds A S T rl rh gl gh).2 := by
  have cap : d≤Nat.log rl (A+rh*S) :=
    Nat.le_log_of_pow_le base ((Nat.pow_le_pow_left lo d).trans power)
  have eq : denom A S T d+(A*(d+1)+S)=2*T*(d+1) := by
    apply Nat.sub_add_cancel
    exact (Nat.sub_pos_iff_lt.mp positive).le
  have lm : denom A S T d*(rl-1)<A*d+S :=
    lt_of_le_of_lt (Nat.mul_le_mul_left _ (Nat.sub_le_sub_right lo 1)) lower
  have um : A*d+S≤denom A S T d*rh := upper.trans (Nat.mul_le_mul_left _ hi)
  have eq' : (denom A S T d:ℤ)+(A*(d+1)+S)=2*T*(d+1) := by exact_mod_cast eq
  have um' : (A:ℤ)*d+S≤denom A S T d*rh := by exact_mod_cast um
  have lm' : (denom A S T d:ℤ)*((rl-1:ℕ):ℤ)<(A:ℤ)*d+S := by exact_mod_cast lm
  have cm := congrArg (fun z:ℤ=>z*(rh:ℤ)) eq'
  have f := trim_sound (B:=(gl,min gh (Nat.log rl (A+rh*S)))) dlo (le_min dhi cap)
    (v:=slope A T rh) (w:=offset A S rh-slope A T rh) (by
      unfold slope offset; nlinarith only [um',cm])
  apply trim_sound f.1 f.2
  unfold slope offset
  have c := congrArg (fun z:ℤ=>z*((rl-1:ℕ):ℤ)) eq'
  have lm'' : (denom A S T d:ℤ)*((rl-1:ℕ):ℤ)+1≤(A:ℤ)*d+S := by omega
  nlinarith only [lm'',c]

/-- Exclude one exponent using the only possible last prime. Full
    divisor moments are needed only after the inexpensive tests pass. -/
def rejects (A S T rl rh d : ℕ) : Bool :=
  let D := denom A S T d
  let r := candidate A S T d
  D==0 || r<rl || rh<r || (A+S)%r != 0 ||
    (1<d && A*d+S==D*r) ||
    A*wt r d+S*sig r d != 2*T*tax r d

/-- True certifies that the given prime and exponent window contains no
    solution with the specified cofactor moments. -/
def exact (A S T rl rh gl gh : ℕ) : Bool :=
  let B := bounds A S T rl rh gl gh
  (List.range' B.1 (B.2+1-B.1)).all (rejects A S T rl rh)

theorem sound {A S T rl rh gl gh r d : ℕ} (base : 1<rl)
    (lo : rl≤r) (hi : r≤rh) (dlo : gl≤d) (dhi : d≤gh) (hs : 0<S)
    (positive : 0<denom A S T d)
    (lower : denom A S T d*(r-1)<A*d+S) (upper : A*d+S≤denom A S T d*r)
    (strict : 1<d → A*d+S<denom A S T d*r)
    (powBound : r^d≤A+rh*S) (dvd : r∣A+S)
    (eq : A*wt r d+S*sig r d=2*T*tax r d) : exact A S T rl rh gl gh=false := by
  have fit := bounds_sound base lo hi dlo dhi positive lower upper powBound
  have cand := OMA.Large245212.force hs (lt_of_lt_of_le base lo) positive lower upper
  have no : rejects A S T rl rh d=false := by
    simp [rejects,cand,Nat.mod_eq_zero_of_dvd dvd,eq,positive.ne',not_lt.mpr lo,not_lt.mpr hi]
    exact fun gt=>(strict gt).ne
  cases h : exact A S T rl rh gl gh with
  | false => rfl
  | true =>
    have hit : d∈List.range' (bounds A S T rl rh gl gh).1
          ((bounds A S T rl rh gl gh).2+1-(bounds A S T rl rh gl gh).1) := by
      exact List.mem_range'.mpr ⟨d-(bounds A S T rl rh gl gh).1,by omega,by simp; omega⟩
    have bad := List.all_eq_true.mp h d hit
    simp [no] at bad

/-- A genuine odd prime-power extension satisfying the divisor equality
    must survive the exact-prefix test. No primality of the other factors
    of the cofactor is needed. -/
theorem extension {m rl rh gl gh r d : ℕ} (hm : 0 < m) (hp : r.Prime) (hp2 : r ≠ 2)
    (cop : m.Coprime r) (base : 1<rl) (lo : rl≤r) (hi : r≤rh)
    (dlo : gl≤d) (dhi : d≤gh) (dp : 0<d)
    (eq : OeisA245212.a (m*r^d)=(σ 1 (m*r^d):ℤ)) :
    exact (W m) (σ 1 m) (m*(σ 0 m)) rl rh gl gh=false := by
  obtain ⟨pos,lower,upper,strict⟩ := balance_digits hm hp cop dp eq
  have sp : 0<σ 1 m := by
    rw [sigma_one_apply]
    exact Finset.sum_pos' (fun _ _=>Nat.zero_le _)
      ⟨1,Nat.one_mem_divisors.mpr hm.ne',by decide⟩
  apply sound base lo hi dlo dhi sp pos lower upper strict
  · have h := OMA.PrimePowerDiv245212.cofactor_bound hm hp hp2 cop d eq
    have le := Int.natAbs_sub_le (W m:ℤ) (((r:ℤ)-1)*(σ 1 m:ℤ))
    rw [Int.natAbs_mul] at le
    have sub : (r:ℤ)-1=((r-1:ℕ):ℤ) := by omega
    rw [sub] at le h
    simp only [Int.natAbs_natCast] at le
    exact (h.trans le).trans (Nat.add_le_add_left (Nat.mul_le_mul_right _ (by omega : r-1≤rh)) _)
  · exact OMA.OddCofactor245212.last_dvd hm hp cop dp eq
  · have b := OMA.Abundance245212.balance (mul_ne_zero hm.ne' (pow_ne_zero _ hp.ne_zero)) eq
    rw [w_mult.map_mul_of_coprime (cop.pow_right d),
      isMultiplicative_sigma.map_mul_of_coprime (cop.pow_right d),
      isMultiplicative_sigma.map_mul_of_coprime (cop.pow_right d),sigma_zero_apply_prime_pow hp] at b
    obtain ⟨ss,ww⟩ := OMA.Large245212.moments hp d
    rw [ss,ww,tax]
    nlinarith only [b]

/-- Closed products for a cofactor consisting of three distinct prime
    powers; these are the arguments passed to the arithmetic leaf. -/
theorem triple {p q z : ℕ} (hp : p.Prime) (hq : q.Prime) (hz : z.Prime)
    (pq : p≠q) (pz : p≠z) (qz : q≠z) (i j k : ℕ) :
    let m := p^i*q^j*z^k
    W m=wt p i*wt q j*wt z k ∧ (σ 1 m)=sig p i*sig q j*sig z k ∧
      m*(σ 0 m)=tax p i*tax q j*tax z k := by
  let m := p^i*q^j*z^k
  have c1 := (((Nat.coprime_primes hp hq).mpr pq).pow_left i).pow_right j
  have c2 := ((((Nat.coprime_primes hp hz).mpr pz).pow_left i).pow_right k).mul_left
    ((((Nat.coprime_primes hq hz).mpr qz).pow_left j).pow_right k)
  obtain ⟨s1,w1⟩ := OMA.Large245212.moments hp i
  obtain ⟨s2,w2⟩ := OMA.Large245212.moments hq j
  obtain ⟨s3,w3⟩ := OMA.Large245212.moments hz k
  dsimp only
  rw [w_mult.map_mul_of_coprime c2,w_mult.map_mul_of_coprime c1,
    isMultiplicative_sigma.map_mul_of_coprime c2,isMultiplicative_sigma.map_mul_of_coprime c1,
    isMultiplicative_sigma.map_mul_of_coprime c2,isMultiplicative_sigma.map_mul_of_coprime c1]
  simp only [s1,s2,s3,w1,w2,w3,sigma_zero_apply_prime_pow hp,sigma_zero_apply_prime_pow hq,
    sigma_zero_apply_prime_pow hz,tax,true_and]
  ring

end OMA.PrefixLeaf245212
