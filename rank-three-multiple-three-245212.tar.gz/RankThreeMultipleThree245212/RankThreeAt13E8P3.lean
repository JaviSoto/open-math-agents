import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt13E8P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 2 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b1 : every 3 4 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b2 : every 5 7 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b3 : every 8 10 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b4 : every 11 13 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b5 : every 14 16 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b6 : every 17 19 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b7 : every 20 22 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b8 : every 23 25 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b9 : every 26 28 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b10 : every 29 31 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b11 : every 32 34 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b12 : every 35 37 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b13 : every 38 40 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b14 : every 41 43 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b15 : every 44 46 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b16 : every 47 49 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b17 : every 50 52 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b18 : every 53 55 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b19 : every 56 58 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b20 : every 59 61 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b21 : every 62 64 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b22 : every 65 67 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b23 : every 68 70 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b24 : every 71 73 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b25 : every 74 76 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b26 : every 77 79 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b27 : every 80 80 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b28 : every 81 81 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b29 : every 82 82 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b30 : every 83 83 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b31 : every 84 84 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b32 : every 85 85 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b33 : every 86 86 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b34 : every 87 87 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b35 : every 88 88 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b36 : every 89 89 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b37 : every 90 90 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b38 : every 91 91 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b39 : every 92 92 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b40 : every 93 93 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b41 : every 94 94 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b42 : every 95 95 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b43 : every 96 96 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b44 : every 97 97 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b45 : every 98 98 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b46 : every 99 99 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b47 : every 100 100 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b48 : every 101 101 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b49 : every 102 102 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b50 : every 103 103 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b51 : every 104 104 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b52 : every 105 105 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b53 : every 106 106 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
private theorem b54 : every 107 107 (movingRow 39398660865 2651124843 29366305956 3)=true := by decide +kernel
theorem checked : test 13 8 3=true :=
  movingTest (h:=1631461442) (A:=39398660865) (S:=2651124843) (T:=29366305956)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 (joinEvery b1 b2)) (joinEvery b3 (joinEvery b4 b5))) (joinEvery (joinEvery b6 (joinEvery b7 b8)) (joinEvery (joinEvery b9 b10) (joinEvery b11 b12)))) (joinEvery (joinEvery (joinEvery b13 (joinEvery b14 b15)) (joinEvery (joinEvery b16 b17) (joinEvery b18 b19))) (joinEvery (joinEvery b20 (joinEvery b21 b22)) (joinEvery (joinEvery b23 b24) (joinEvery b25 b26))))) (joinEvery (joinEvery (joinEvery (joinEvery b27 (joinEvery b28 b29)) (joinEvery (joinEvery b30 b31) (joinEvery b32 b33))) (joinEvery (joinEvery b34 (joinEvery b35 b36)) (joinEvery (joinEvery b37 b38) (joinEvery b39 b40)))) (joinEvery (joinEvery (joinEvery b41 (joinEvery b42 b43)) (joinEvery (joinEvery b44 b45) (joinEvery b46 b47))) (joinEvery (joinEvery b48 (joinEvery b49 b50)) (joinEvery (joinEvery b51 b52) (joinEvery b53 b54))))))
#print axioms checked
end OMA.RankThreeAt13E8P3
