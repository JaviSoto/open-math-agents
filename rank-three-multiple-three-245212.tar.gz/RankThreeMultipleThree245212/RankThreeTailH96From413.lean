import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_413_0 : every 413 418 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_413_1 : every 420 88 (quick 96 2247 252 1152 419)=true := by decide +kernel
private theorem b96_413_2 : every 1 25 (far 96 2247 252 1152 419 420 19)=true := by decide +kernel
private theorem b96_413_3 : every 26 50 (far 96 2247 252 1152 419 420 19)=true := by decide +kernel
private theorem b96_413_4 : every 51 75 (far 96 2247 252 1152 419 420 19)=true := by decide +kernel
private theorem b96_413_5 : every 76 95 (far 96 2247 252 1152 419 420 19)=true := by decide +kernel
private theorem r96_419 : every 419 419 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 419=true := by change (every 420 88 (quick 96 2247 252 1152 419) && every 1 95 (far 96 2247 252 1152 419 420 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_413_1,(joinEvery (joinEvery b96_413_2 b96_413_3) (joinEvery b96_413_4 b96_413_5))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=419 by omega] using yes
private theorem b96_413_6 : every 420 420 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_413_7 : every 422 88 (quick 96 2247 252 1152 421)=true := by decide +kernel
private theorem b96_413_8 : every 1 25 (far 96 2247 252 1152 421 422 19)=true := by decide +kernel
private theorem b96_413_9 : every 26 50 (far 96 2247 252 1152 421 422 19)=true := by decide +kernel
private theorem b96_413_10 : every 51 75 (far 96 2247 252 1152 421 422 19)=true := by decide +kernel
private theorem b96_413_11 : every 76 96 (far 96 2247 252 1152 421 422 19)=true := by decide +kernel
private theorem r96_421 : every 421 421 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 421=true := by change (every 422 88 (quick 96 2247 252 1152 421) && every 1 96 (far 96 2247 252 1152 421 422 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_413_7,(joinEvery (joinEvery b96_413_8 b96_413_9) (joinEvery b96_413_10 b96_413_11))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=421 by omega] using yes
private theorem b96_413_12 : every 422 430 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_413_13 : every 432 88 (quick 96 2247 252 1152 431)=true := by decide +kernel
private theorem b96_413_14 : every 1 25 (far 96 2247 252 1152 431 432 19)=true := by decide +kernel
private theorem b96_413_15 : every 26 50 (far 96 2247 252 1152 431 432 19)=true := by decide +kernel
private theorem b96_413_16 : every 51 75 (far 96 2247 252 1152 431 432 19)=true := by decide +kernel
private theorem b96_413_17 : every 76 98 (far 96 2247 252 1152 431 432 19)=true := by decide +kernel
private theorem r96_431 : every 431 431 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 431=true := by change (every 432 88 (quick 96 2247 252 1152 431) && every 1 98 (far 96 2247 252 1152 431 432 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_413_13,(joinEvery (joinEvery b96_413_14 b96_413_15) (joinEvery b96_413_16 b96_413_17))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=431 by omega] using yes
private theorem b96_413_18 : every 432 432 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_413_19 : every 434 87 (quick 96 2247 252 1152 433)=true := by decide +kernel
private theorem b96_413_20 : every 1 25 (far 96 2247 252 1152 433 434 19)=true := by decide +kernel
private theorem b96_413_21 : every 26 50 (far 96 2247 252 1152 433 434 19)=true := by decide +kernel
private theorem b96_413_22 : every 51 75 (far 96 2247 252 1152 433 434 19)=true := by decide +kernel
private theorem b96_413_23 : every 76 98 (far 96 2247 252 1152 433 434 19)=true := by decide +kernel
private theorem r96_433 : every 433 433 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 433=true := by change (every 434 87 (quick 96 2247 252 1152 433) && every 1 98 (far 96 2247 252 1152 433 434 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_413_19,(joinEvery (joinEvery b96_413_20 b96_413_21) (joinEvery b96_413_22 b96_413_23))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=433 by omega] using yes
private theorem b96_413_24 : every 434 436 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_413_436 : every 413 436 (run 96 2247 252 1152)=true := (joinEvery (joinEvery (joinEvery b96_413_0 r96_419) (joinEvery b96_413_6 r96_421)) (joinEvery (joinEvery b96_413_12 r96_431) (joinEvery b96_413_18 (joinEvery r96_433 b96_413_24))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_413_436
