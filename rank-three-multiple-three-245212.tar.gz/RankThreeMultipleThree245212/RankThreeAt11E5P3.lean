import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt11E5P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 4 (movingRow 5226105 531468 3865224 3)=true := by decide +kernel
private theorem b1 : every 5 9 (movingRow 5226105 531468 3865224 3)=true := by decide +kernel
private theorem b2 : every 10 14 (movingRow 5226105 531468 3865224 3)=true := by decide +kernel
private theorem b3 : every 15 19 (movingRow 5226105 531468 3865224 3)=true := by decide +kernel
private theorem b4 : every 20 24 (movingRow 5226105 531468 3865224 3)=true := by decide +kernel
private theorem b5 : every 25 29 (movingRow 5226105 531468 3865224 3)=true := by decide +kernel
private theorem b6 : every 30 35 (movingRow 5226105 531468 3865224 3)=true := by decide +kernel
private theorem b7 : every 36 36 (movingRow 5226105 531468 3865224 3)=true := by decide +kernel
private theorem b8 : every 37 37 (movingRow 5226105 531468 3865224 3)=true := by decide +kernel
private theorem b9 : every 38 38 (movingRow 5226105 531468 3865224 3)=true := by decide +kernel
private theorem b10 : every 39 39 (movingRow 5226105 531468 3865224 3)=true := by decide +kernel
private theorem b11 : every 40 40 (movingRow 5226105 531468 3865224 3)=true := by decide +kernel
private theorem b12 : every 41 41 (movingRow 5226105 531468 3865224 3)=true := by decide +kernel
private theorem b13 : every 42 42 (movingRow 5226105 531468 3865224 3)=true := by decide +kernel
private theorem b14 : every 43 43 (movingRow 5226105 531468 3865224 3)=true := by decide +kernel
private theorem b15 : every 44 44 (movingRow 5226105 531468 3865224 3)=true := by decide +kernel
private theorem b16 : every 45 45 (movingRow 5226105 531468 3865224 3)=true := by decide +kernel
private theorem b17 : every 46 46 (movingRow 5226105 531468 3865224 3)=true := by decide +kernel
private theorem b18 : every 47 47 (movingRow 5226105 531468 3865224 3)=true := by decide +kernel
private theorem b19 : every 48 48 (movingRow 5226105 531468 3865224 3)=true := by decide +kernel
theorem checked : test 11 5 3=true :=
  movingTest (h:=322102) (A:=5226105) (S:=531468) (T:=3865224)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 (joinEvery b3 b4))) (joinEvery (joinEvery b5 b6) (joinEvery b7 (joinEvery b8 b9)))) (joinEvery (joinEvery (joinEvery b10 b11) (joinEvery b12 (joinEvery b13 b14))) (joinEvery (joinEvery b15 b16) (joinEvery b17 (joinEvery b18 b19)))))
#print axioms checked
end OMA.RankThreeAt11E5P3
