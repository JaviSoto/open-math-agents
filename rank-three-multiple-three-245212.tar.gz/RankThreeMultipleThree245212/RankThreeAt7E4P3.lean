import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt7E4P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 7 (movingRow 67695 8403 48020 3)=true := by decide +kernel
private theorem b1 : every 8 11 (movingRow 67695 8403 48020 3)=true := by decide +kernel
private theorem b2 : every 12 12 (movingRow 67695 8403 48020 3)=true := by decide +kernel
theorem checked : test 7 4 3=true :=
  movingTest (h:=4802) (A:=67695) (S:=8403) (T:=48020)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery b0 (joinEvery b1 b2))
#print axioms checked
end OMA.RankThreeAt7E4P3
