import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b48_5_0 : every 1 2 (movingRow 903 124 480 5)=true := by decide +kernel
private theorem r48_5 : every 5 5 (run 48 903 124 480)=true := by
  have yes : run 48 903 124 480 5=true := b48_5_0
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=5 by omega] using yes
private theorem b48_5_1 : every 6 6 (run 48 903 124 480)=true := by decide +kernel
private theorem b48_5_2 : every 1 3 (movingRow 903 124 480 7)=true := by decide +kernel
private theorem r48_7 : every 7 7 (run 48 903 124 480)=true := by
  have yes : run 48 903 124 480 7=true := b48_5_2
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=7 by omega] using yes
private theorem b48_5_3 : every 8 10 (run 48 903 124 480)=true := by decide +kernel
private theorem b48_5_4 : every 1 5 (movingRow 903 124 480 11)=true := by decide +kernel
private theorem r48_11 : every 11 11 (run 48 903 124 480)=true := by
  have yes : run 48 903 124 480 11=true := b48_5_4
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=11 by omega] using yes
private theorem b48_5_5 : every 12 12 (run 48 903 124 480)=true := by decide +kernel
private theorem b48_5_6 : every 1 8 (movingRow 903 124 480 13)=true := by decide +kernel
private theorem r48_13 : every 13 13 (run 48 903 124 480)=true := by
  have yes : run 48 903 124 480 13=true := b48_5_6
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=13 by omega] using yes
private theorem b48_5_7 : every 14 16 (run 48 903 124 480)=true := by decide +kernel
private theorem b48_5_8 : every 18 172 (quick 48 903 124 480 17)=true := by decide +kernel
private theorem b48_5_9 : every 173 329 (quick 48 903 124 480 17)=true := by decide +kernel
private theorem b48_5_10 : every 330 486 (quick 48 903 124 480 17)=true := by decide +kernel
private theorem b48_5_11 : every 487 642 (quick 48 903 124 480 17)=true := by decide +kernel
private theorem b48_5_12 : every 643 808 (quick 48 903 124 480 17)=true := by decide +kernel
private theorem b48_5_13 : every 809 966 (quick 48 903 124 480 17)=true := by decide +kernel
private theorem b48_5_14 : every 967 1116 (quick 48 903 124 480 17)=true := by decide +kernel
private theorem b48_5_15 : every 1117 1288 (quick 48 903 124 480 17)=true := by decide +kernel
private theorem b48_5_16 : every 1289 1450 (quick 48 903 124 480 17)=true := by decide +kernel
private theorem b48_5_17 : every 1451 1600 (quick 48 903 124 480 17)=true := by decide +kernel
private theorem b48_5_18 : every 1601 1786 (quick 48 903 124 480 17)=true := by decide +kernel
private theorem b48_5_19 : every 1787 2041 (quick 48 903 124 480 17)=true := by decide +kernel
private theorem b48_5_20 : every 2042 2296 (quick 48 903 124 480 17)=true := by decide +kernel
private theorem b48_5_21 : every 2297 2551 (quick 48 903 124 480 17)=true := by decide +kernel
private theorem b48_5_22 : every 2552 2801 (quick 48 903 124 480 17)=true := by decide +kernel
private theorem b48_5_23 : every 2802 3066 (quick 48 903 124 480 17)=true := by decide +kernel
private theorem b48_5_24 : every 3067 3330 (quick 48 903 124 480 17)=true := by decide +kernel
private theorem b48_5_25 : every 3331 3412 (quick 48 903 124 480 17)=true := by decide +kernel
private theorem b48_5_26 : every 1 6 (far 48 903 124 480 17 3413 881)=true := by decide +kernel
private theorem r48_17 : every 17 17 (run 48 903 124 480)=true := by
  have yes : run 48 903 124 480 17=true := by change (every 18 3412 (quick 48 903 124 480 17) && every 1 6 (far 48 903 124 480 17 3413 881))=true; rw [Bool.and_eq_true]; exact ⟨(joinEvery (joinEvery (joinEvery (joinEvery b48_5_8 b48_5_9) (joinEvery b48_5_10 b48_5_11)) (joinEvery (joinEvery b48_5_12 b48_5_13) (joinEvery b48_5_14 (joinEvery b48_5_15 b48_5_16)))) (joinEvery (joinEvery (joinEvery b48_5_17 b48_5_18) (joinEvery b48_5_19 b48_5_20)) (joinEvery (joinEvery b48_5_21 b48_5_22) (joinEvery b48_5_23 (joinEvery b48_5_24 b48_5_25))))),b48_5_26⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=17 by omega] using yes
private theorem b48_5_27 : every 18 18 (run 48 903 124 480)=true := by decide +kernel
private theorem b48_5_28 : every 20 187 (quick 48 903 124 480 19)=true := by decide +kernel
private theorem b48_5_29 : every 188 279 (quick 48 903 124 480 19)=true := by decide +kernel
private theorem b48_5_30 : every 1 6 (far 48 903 124 480 19 280 72)=true := by decide +kernel
private theorem r48_19 : every 19 19 (run 48 903 124 480)=true := by
  have yes : run 48 903 124 480 19=true := by change (every 20 279 (quick 48 903 124 480 19) && every 1 6 (far 48 903 124 480 19 280 72))=true; rw [Bool.and_eq_true]; exact ⟨(joinEvery b48_5_28 b48_5_29),b48_5_30⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=19 by omega] using yes
private theorem b48_5_31 : every 20 22 (run 48 903 124 480)=true := by decide +kernel
private theorem b48_5_32 : every 24 119 (quick 48 903 124 480 23)=true := by decide +kernel
private theorem b48_5_33 : every 1 8 (far 48 903 124 480 23 120 31)=true := by decide +kernel
private theorem r48_23 : every 23 23 (run 48 903 124 480)=true := by
  have yes : run 48 903 124 480 23=true := by change (every 24 119 (quick 48 903 124 480 23) && every 1 8 (far 48 903 124 480 23 120 31))=true; rw [Bool.and_eq_true]; exact ⟨b48_5_32,b48_5_33⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=23 by omega] using yes
private theorem b48_5_34 : every 24 28 (run 48 903 124 480)=true := by decide +kernel
theorem span48_5_28 : every 5 28 (run 48 903 124 480)=true := (joinEvery (joinEvery (joinEvery r48_5 (joinEvery b48_5_1 r48_7)) (joinEvery (joinEvery b48_5_3 r48_11) (joinEvery b48_5_5 r48_13))) (joinEvery (joinEvery b48_5_7 (joinEvery r48_17 b48_5_27)) (joinEvery (joinEvery r48_19 b48_5_31) (joinEvery r48_23 b48_5_34))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span48_5_28
