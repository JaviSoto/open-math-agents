import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E25P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 14 29 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b1 : every 30 41 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b2 : every 42 52 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b3 : every 53 60 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b4 : every 61 66 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b5 : every 67 70 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b6 : every 71 72 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b7 : every 73 78 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b8 : every 79 82 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b9 : every 83 88 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b10 : every 89 96 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b11 : every 97 100 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b12 : every 101 102 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b13 : every 103 106 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b14 : every 107 108 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b15 : every 109 112 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b16 : every 113 126 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b17 : every 127 130 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b18 : every 131 136 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b19 : every 137 138 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b20 : every 139 148 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b21 : every 149 150 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b22 : every 151 156 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b23 : every 157 162 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b24 : every 163 166 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b25 : every 167 172 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b26 : every 173 178 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b27 : every 179 180 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b28 : every 181 190 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b29 : every 191 192 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b30 : every 193 196 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b31 : every 197 198 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b32 : every 199 210 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b33 : every 211 222 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b34 : every 223 226 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b35 : every 227 228 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b36 : every 229 232 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b37 : every 233 238 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b38 : every 239 240 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b39 : every 241 250 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
private theorem b40 : every 251 256 (finitePair 1694577218886 162043946555975 3812798742492 88118015382072 13)=true := by decide +kernel
theorem checked : test 3 25 13=true :=
  fixedTest (h:=1694577218886) (A:=162043946555975) (S:=3812798742492) (T:=88118015382072)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 (joinEvery b3 b4))) (joinEvery (joinEvery b5 b6) (joinEvery b7 (joinEvery b8 b9)))) (joinEvery (joinEvery (joinEvery b10 b11) (joinEvery b12 (joinEvery b13 b14))) (joinEvery (joinEvery b15 b16) (joinEvery b17 (joinEvery b18 b19))))) (joinEvery (joinEvery (joinEvery (joinEvery b20 b21) (joinEvery b22 (joinEvery b23 b24))) (joinEvery (joinEvery b25 b26) (joinEvery b27 (joinEvery b28 b29)))) (joinEvery (joinEvery (joinEvery b30 b31) (joinEvery b32 (joinEvery b33 b34))) (joinEvery (joinEvery b35 (joinEvery b36 b37)) (joinEvery b38 (joinEvery b39 b40))))))
#print axioms checked
end OMA.RankThreeAt3E25P13
