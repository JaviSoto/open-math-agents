import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_149_0 : every 150 109 (quick 96 2247 252 1152 149)=true := by decide +kernel
private theorem b96_149_1 : every 1 25 (far 96 2247 252 1152 149 150 24)=true := by decide +kernel
private theorem b96_149_2 : every 26 35 (far 96 2247 252 1152 149 150 24)=true := by decide +kernel
private theorem r96_149 : every 149 149 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 149=true := by change (every 150 109 (quick 96 2247 252 1152 149) && every 1 35 (far 96 2247 252 1152 149 150 24))=true; rw [Bool.and_eq_true]; exact ⟨b96_149_0,(joinEvery b96_149_1 b96_149_2)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=149 by omega] using yes
private theorem b96_149_3 : every 150 150 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_149_4 : every 152 108 (quick 96 2247 252 1152 151)=true := by decide +kernel
private theorem b96_149_5 : every 1 25 (far 96 2247 252 1152 151 152 23)=true := by decide +kernel
private theorem b96_149_6 : every 26 35 (far 96 2247 252 1152 151 152 23)=true := by decide +kernel
private theorem r96_151 : every 151 151 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 151=true := by change (every 152 108 (quick 96 2247 252 1152 151) && every 1 35 (far 96 2247 252 1152 151 152 23))=true; rw [Bool.and_eq_true]; exact ⟨b96_149_4,(joinEvery b96_149_5 b96_149_6)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=151 by omega] using yes
private theorem b96_149_7 : every 152 156 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_149_8 : every 158 107 (quick 96 2247 252 1152 157)=true := by decide +kernel
private theorem b96_149_9 : every 1 25 (far 96 2247 252 1152 157 158 23)=true := by decide +kernel
private theorem b96_149_10 : every 26 36 (far 96 2247 252 1152 157 158 23)=true := by decide +kernel
private theorem r96_157 : every 157 157 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 157=true := by change (every 158 107 (quick 96 2247 252 1152 157) && every 1 36 (far 96 2247 252 1152 157 158 23))=true; rw [Bool.and_eq_true]; exact ⟨b96_149_8,(joinEvery b96_149_9 b96_149_10)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=157 by omega] using yes
private theorem b96_149_11 : every 158 162 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_149_12 : every 164 105 (quick 96 2247 252 1152 163)=true := by decide +kernel
private theorem b96_149_13 : every 1 25 (far 96 2247 252 1152 163 164 23)=true := by decide +kernel
private theorem b96_149_14 : every 26 38 (far 96 2247 252 1152 163 164 23)=true := by decide +kernel
private theorem r96_163 : every 163 163 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 163=true := by change (every 164 105 (quick 96 2247 252 1152 163) && every 1 38 (far 96 2247 252 1152 163 164 23))=true; rw [Bool.and_eq_true]; exact ⟨b96_149_12,(joinEvery b96_149_13 b96_149_14)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=163 by omega] using yes
private theorem b96_149_15 : every 164 166 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_149_16 : every 168 105 (quick 96 2247 252 1152 167)=true := by decide +kernel
private theorem b96_149_17 : every 1 25 (far 96 2247 252 1152 167 168 23)=true := by decide +kernel
private theorem b96_149_18 : every 26 39 (far 96 2247 252 1152 167 168 23)=true := by decide +kernel
private theorem r96_167 : every 167 167 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 167=true := by change (every 168 105 (quick 96 2247 252 1152 167) && every 1 39 (far 96 2247 252 1152 167 168 23))=true; rw [Bool.and_eq_true]; exact ⟨b96_149_16,(joinEvery b96_149_17 b96_149_18)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=167 by omega] using yes
private theorem b96_149_19 : every 168 172 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_149_172 : every 149 172 (run 96 2247 252 1152)=true := (joinEvery (joinEvery (joinEvery r96_149 b96_149_3) (joinEvery r96_151 (joinEvery b96_149_7 r96_157))) (joinEvery (joinEvery b96_149_11 r96_163) (joinEvery b96_149_15 (joinEvery r96_167 b96_149_19))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_149_172
