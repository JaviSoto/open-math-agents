import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt13E3P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 4 16 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b1 : every 17 18 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b2 : every 19 22 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b3 : every 23 28 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b4 : every 29 30 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b5 : every 31 36 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b6 : every 37 40 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b7 : every 41 42 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b8 : every 43 46 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b9 : every 47 52 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b10 : every 53 58 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b11 : every 59 60 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b12 : every 61 66 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b13 : every 67 70 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b14 : every 71 72 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b15 : every 73 78 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b16 : every 79 82 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b17 : every 83 88 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b18 : every 89 96 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b19 : every 97 100 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b20 : every 101 102 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b21 : every 103 106 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b22 : every 107 108 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b23 : every 109 112 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b24 : every 113 118 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b25 : every 119 126 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b26 : every 127 130 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b27 : every 131 134 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b28 : every 135 138 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b29 : every 139 142 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b30 : every 143 148 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b31 : every 149 150 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b32 : every 151 152 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b33 : every 153 156 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b34 : every 157 158 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b35 : every 159 162 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b36 : every 163 164 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b37 : every 165 166 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b38 : every 167 167 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b39 : every 168 172 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b40 : every 173 173 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b41 : every 174 178 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b42 : every 179 179 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
private theorem b43 : every 180 180 (finitePair 4394 46610 7140 35152 3)=true := by decide +kernel
theorem checked : test 13 3 3=true :=
  fixedTest (h:=4394) (A:=46610) (S:=7140) (T:=35152)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 (joinEvery b3 b4))) (joinEvery (joinEvery b5 (joinEvery b6 b7)) (joinEvery b8 (joinEvery b9 b10)))) (joinEvery (joinEvery (joinEvery b11 b12) (joinEvery b13 (joinEvery b14 b15))) (joinEvery (joinEvery b16 (joinEvery b17 b18)) (joinEvery b19 (joinEvery b20 b21))))) (joinEvery (joinEvery (joinEvery (joinEvery b22 b23) (joinEvery b24 (joinEvery b25 b26))) (joinEvery (joinEvery b27 (joinEvery b28 b29)) (joinEvery b30 (joinEvery b31 b32)))) (joinEvery (joinEvery (joinEvery b33 b34) (joinEvery b35 (joinEvery b36 b37))) (joinEvery (joinEvery b38 (joinEvery b39 b40)) (joinEvery b41 (joinEvery b42 b43))))))
#print axioms checked
end OMA.RankThreeAt13E3P3
