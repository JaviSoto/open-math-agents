import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_269_0 : every 270 93 (quick 96 2247 252 1152 269)=true := by decide +kernel
private theorem b96_269_1 : every 1 25 (far 96 2247 252 1152 269 270 20)=true := by decide +kernel
private theorem b96_269_2 : every 26 50 (far 96 2247 252 1152 269 270 20)=true := by decide +kernel
private theorem b96_269_3 : every 51 62 (far 96 2247 252 1152 269 270 20)=true := by decide +kernel
private theorem r96_269 : every 269 269 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 269=true := by change (every 270 93 (quick 96 2247 252 1152 269) && every 1 62 (far 96 2247 252 1152 269 270 20))=true; rw [Bool.and_eq_true]; exact ⟨b96_269_0,(joinEvery b96_269_1 (joinEvery b96_269_2 b96_269_3))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=269 by omega] using yes
private theorem b96_269_4 : every 270 270 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_269_5 : every 272 93 (quick 96 2247 252 1152 271)=true := by decide +kernel
private theorem b96_269_6 : every 1 25 (far 96 2247 252 1152 271 272 20)=true := by decide +kernel
private theorem b96_269_7 : every 26 50 (far 96 2247 252 1152 271 272 20)=true := by decide +kernel
private theorem b96_269_8 : every 51 62 (far 96 2247 252 1152 271 272 20)=true := by decide +kernel
private theorem r96_271 : every 271 271 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 271=true := by change (every 272 93 (quick 96 2247 252 1152 271) && every 1 62 (far 96 2247 252 1152 271 272 20))=true; rw [Bool.and_eq_true]; exact ⟨b96_269_5,(joinEvery b96_269_6 (joinEvery b96_269_7 b96_269_8))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=271 by omega] using yes
private theorem b96_269_9 : every 272 276 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_269_10 : every 278 93 (quick 96 2247 252 1152 277)=true := by decide +kernel
private theorem b96_269_11 : every 1 25 (far 96 2247 252 1152 277 278 20)=true := by decide +kernel
private theorem b96_269_12 : every 26 50 (far 96 2247 252 1152 277 278 20)=true := by decide +kernel
private theorem b96_269_13 : every 51 63 (far 96 2247 252 1152 277 278 20)=true := by decide +kernel
private theorem r96_277 : every 277 277 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 277=true := by change (every 278 93 (quick 96 2247 252 1152 277) && every 1 63 (far 96 2247 252 1152 277 278 20))=true; rw [Bool.and_eq_true]; exact ⟨b96_269_10,(joinEvery b96_269_11 (joinEvery b96_269_12 b96_269_13))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=277 by omega] using yes
private theorem b96_269_14 : every 278 280 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_269_15 : every 282 93 (quick 96 2247 252 1152 281)=true := by decide +kernel
private theorem b96_269_16 : every 1 25 (far 96 2247 252 1152 281 282 20)=true := by decide +kernel
private theorem b96_269_17 : every 26 50 (far 96 2247 252 1152 281 282 20)=true := by decide +kernel
private theorem b96_269_18 : every 51 64 (far 96 2247 252 1152 281 282 20)=true := by decide +kernel
private theorem r96_281 : every 281 281 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 281=true := by change (every 282 93 (quick 96 2247 252 1152 281) && every 1 64 (far 96 2247 252 1152 281 282 20))=true; rw [Bool.and_eq_true]; exact ⟨b96_269_15,(joinEvery b96_269_16 (joinEvery b96_269_17 b96_269_18))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=281 by omega] using yes
private theorem b96_269_19 : every 282 282 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_269_20 : every 284 92 (quick 96 2247 252 1152 283)=true := by decide +kernel
private theorem b96_269_21 : every 1 25 (far 96 2247 252 1152 283 284 20)=true := by decide +kernel
private theorem b96_269_22 : every 26 50 (far 96 2247 252 1152 283 284 20)=true := by decide +kernel
private theorem b96_269_23 : every 51 65 (far 96 2247 252 1152 283 284 20)=true := by decide +kernel
private theorem r96_283 : every 283 283 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 283=true := by change (every 284 92 (quick 96 2247 252 1152 283) && every 1 65 (far 96 2247 252 1152 283 284 20))=true; rw [Bool.and_eq_true]; exact ⟨b96_269_20,(joinEvery b96_269_21 (joinEvery b96_269_22 b96_269_23))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=283 by omega] using yes
private theorem b96_269_24 : every 284 292 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_269_292 : every 269 292 (run 96 2247 252 1152)=true := (joinEvery (joinEvery (joinEvery r96_269 b96_269_4) (joinEvery r96_271 (joinEvery b96_269_9 r96_277))) (joinEvery (joinEvery b96_269_14 r96_281) (joinEvery b96_269_19 (joinEvery r96_283 b96_269_24))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_269_292
