import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_5_0 : every 1 2 (movingRow 2247 252 1152 5)=true := by decide +kernel
private theorem r96_5 : every 5 5 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 5=true := b96_5_0
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=5 by omega] using yes
private theorem b96_5_1 : every 6 6 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_5_2 : every 1 2 (movingRow 2247 252 1152 7)=true := by decide +kernel
private theorem r96_7 : every 7 7 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 7=true := b96_5_2
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=7 by omega] using yes
private theorem b96_5_3 : every 8 10 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_5_4 : every 1 2 (movingRow 2247 252 1152 11)=true := by decide +kernel
private theorem r96_11 : every 11 11 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 11=true := b96_5_4
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=11 by omega] using yes
private theorem b96_5_5 : every 12 12 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_5_6 : every 1 2 (movingRow 2247 252 1152 13)=true := by decide +kernel
private theorem r96_13 : every 13 13 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 13=true := b96_5_6
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=13 by omega] using yes
private theorem b96_5_7 : every 14 16 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_5_8 : every 1 3 (movingRow 2247 252 1152 17)=true := by decide +kernel
private theorem r96_17 : every 17 17 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 17=true := b96_5_8
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=17 by omega] using yes
private theorem b96_5_9 : every 18 18 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_5_10 : every 1 3 (movingRow 2247 252 1152 19)=true := by decide +kernel
private theorem r96_19 : every 19 19 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 19=true := b96_5_10
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=19 by omega] using yes
private theorem b96_5_11 : every 20 22 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_5_12 : every 1 4 (movingRow 2247 252 1152 23)=true := by decide +kernel
private theorem r96_23 : every 23 23 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 23=true := b96_5_12
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=23 by omega] using yes
private theorem b96_5_13 : every 24 28 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_5_28 : every 5 28 (run 96 2247 252 1152)=true := (joinEvery (joinEvery (joinEvery r96_5 (joinEvery b96_5_1 r96_7)) (joinEvery (joinEvery b96_5_3 r96_11) (joinEvery b96_5_5 r96_13))) (joinEvery (joinEvery b96_5_7 (joinEvery r96_17 b96_5_9)) (joinEvery (joinEvery r96_19 b96_5_11) (joinEvery r96_23 b96_5_13))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_5_28
