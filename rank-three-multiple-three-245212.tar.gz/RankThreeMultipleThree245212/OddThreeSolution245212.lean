import OddSupportClass245212
import Triple7Proof245212
import Triple11Proof245212
import Triple13Proof245212

/-! Classify all odd solutions supported on at most three different primes. -/
namespace OMA.OddSupportClass245212
open scoped ArithmeticFunction.sigma

theorem three_excluded : ThreeExcluded := by
  intro q h
  rcases h with rfl|rfl|rfl
  · exact OMA.TriSupport245212.exclude7
  · exact OMA.TriSupport245212.exclude11
  · exact OMA.TriSupport245212.exclude13

/-- The only odd solution with at most three distinct prime divisors is one. -/
theorem odd_three {n : ℕ} (odd : Odd n) (few : n.primeFactors.card≤3)
    (eq : OeisA245212.a n=(σ 1 n:ℤ)) : n=1 :=
  classify three_excluded n odd (by omega) (fun h => False.elim (by omega)) eq

#print axioms odd_three
end OMA.OddSupportClass245212
