import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_221_0 : every 221 222 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_221_1 : every 224 97 (quick 96 2247 252 1152 223)=true := by decide +kernel
private theorem b96_221_2 : every 1 25 (far 96 2247 252 1152 223 224 21)=true := by decide +kernel
private theorem b96_221_3 : every 26 50 (far 96 2247 252 1152 223 224 21)=true := by decide +kernel
private theorem b96_221_4 : every 51 51 (far 96 2247 252 1152 223 224 21)=true := by decide +kernel
private theorem r96_223 : every 223 223 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 223=true := by change (every 224 97 (quick 96 2247 252 1152 223) && every 1 51 (far 96 2247 252 1152 223 224 21))=true; rw [Bool.and_eq_true]; exact ⟨b96_221_1,(joinEvery b96_221_2 (joinEvery b96_221_3 b96_221_4))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=223 by omega] using yes
private theorem b96_221_5 : every 224 226 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_221_6 : every 228 96 (quick 96 2247 252 1152 227)=true := by decide +kernel
private theorem b96_221_7 : every 1 25 (far 96 2247 252 1152 227 228 21)=true := by decide +kernel
private theorem b96_221_8 : every 26 50 (far 96 2247 252 1152 227 228 21)=true := by decide +kernel
private theorem b96_221_9 : every 51 52 (far 96 2247 252 1152 227 228 21)=true := by decide +kernel
private theorem r96_227 : every 227 227 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 227=true := by change (every 228 96 (quick 96 2247 252 1152 227) && every 1 52 (far 96 2247 252 1152 227 228 21))=true; rw [Bool.and_eq_true]; exact ⟨b96_221_6,(joinEvery b96_221_7 (joinEvery b96_221_8 b96_221_9))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=227 by omega] using yes
private theorem b96_221_10 : every 228 228 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_221_11 : every 230 96 (quick 96 2247 252 1152 229)=true := by decide +kernel
private theorem b96_221_12 : every 1 25 (far 96 2247 252 1152 229 230 21)=true := by decide +kernel
private theorem b96_221_13 : every 26 50 (far 96 2247 252 1152 229 230 21)=true := by decide +kernel
private theorem b96_221_14 : every 51 53 (far 96 2247 252 1152 229 230 21)=true := by decide +kernel
private theorem r96_229 : every 229 229 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 229=true := by change (every 230 96 (quick 96 2247 252 1152 229) && every 1 53 (far 96 2247 252 1152 229 230 21))=true; rw [Bool.and_eq_true]; exact ⟨b96_221_11,(joinEvery b96_221_12 (joinEvery b96_221_13 b96_221_14))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=229 by omega] using yes
private theorem b96_221_15 : every 230 232 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_221_16 : every 234 96 (quick 96 2247 252 1152 233)=true := by decide +kernel
private theorem b96_221_17 : every 1 25 (far 96 2247 252 1152 233 234 21)=true := by decide +kernel
private theorem b96_221_18 : every 26 50 (far 96 2247 252 1152 233 234 21)=true := by decide +kernel
private theorem b96_221_19 : every 51 54 (far 96 2247 252 1152 233 234 21)=true := by decide +kernel
private theorem r96_233 : every 233 233 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 233=true := by change (every 234 96 (quick 96 2247 252 1152 233) && every 1 54 (far 96 2247 252 1152 233 234 21))=true; rw [Bool.and_eq_true]; exact ⟨b96_221_16,(joinEvery b96_221_17 (joinEvery b96_221_18 b96_221_19))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=233 by omega] using yes
private theorem b96_221_20 : every 234 238 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_221_21 : every 240 95 (quick 96 2247 252 1152 239)=true := by decide +kernel
private theorem b96_221_22 : every 1 25 (far 96 2247 252 1152 239 240 21)=true := by decide +kernel
private theorem b96_221_23 : every 26 50 (far 96 2247 252 1152 239 240 21)=true := by decide +kernel
private theorem b96_221_24 : every 51 55 (far 96 2247 252 1152 239 240 21)=true := by decide +kernel
private theorem r96_239 : every 239 239 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 239=true := by change (every 240 95 (quick 96 2247 252 1152 239) && every 1 55 (far 96 2247 252 1152 239 240 21))=true; rw [Bool.and_eq_true]; exact ⟨b96_221_21,(joinEvery b96_221_22 (joinEvery b96_221_23 b96_221_24))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=239 by omega] using yes
private theorem b96_221_25 : every 240 240 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_221_26 : every 242 95 (quick 96 2247 252 1152 241)=true := by decide +kernel
private theorem b96_221_27 : every 1 25 (far 96 2247 252 1152 241 242 21)=true := by decide +kernel
private theorem b96_221_28 : every 26 50 (far 96 2247 252 1152 241 242 21)=true := by decide +kernel
private theorem b96_221_29 : every 51 55 (far 96 2247 252 1152 241 242 21)=true := by decide +kernel
private theorem r96_241 : every 241 241 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 241=true := by change (every 242 95 (quick 96 2247 252 1152 241) && every 1 55 (far 96 2247 252 1152 241 242 21))=true; rw [Bool.and_eq_true]; exact ⟨b96_221_26,(joinEvery b96_221_27 (joinEvery b96_221_28 b96_221_29))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=241 by omega] using yes
private theorem b96_221_30 : every 242 244 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_221_244 : every 221 244 (run 96 2247 252 1152)=true := (joinEvery (joinEvery (joinEvery b96_221_0 (joinEvery r96_223 b96_221_5)) (joinEvery r96_227 (joinEvery b96_221_10 r96_229))) (joinEvery (joinEvery b96_221_15 (joinEvery r96_233 b96_221_20)) (joinEvery (joinEvery r96_239 b96_221_25) (joinEvery r96_241 b96_221_30))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_221_244
