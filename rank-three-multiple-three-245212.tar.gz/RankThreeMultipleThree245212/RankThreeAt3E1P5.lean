import RankThreeMiddleBlocks245212
namespace OMA.RankThreeAt3E1P5
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 6 11 (finitePair 6 35 12 24 5)=true := by decide +kernel
theorem checked : test 3 1 5=true :=
  fixedTest (h:=6) (A:=35) (S:=12) (T:=24)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) b0
#print axioms checked
end OMA.RankThreeAt3E1P5
