import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt13E2P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 4 16 (finitePair 338 2670 549 2028 3)=true := by decide +kernel
private theorem b1 : every 17 18 (finitePair 338 2670 549 2028 3)=true := by decide +kernel
private theorem b2 : every 19 22 (finitePair 338 2670 549 2028 3)=true := by decide +kernel
private theorem b3 : every 23 28 (finitePair 338 2670 549 2028 3)=true := by decide +kernel
private theorem b4 : every 29 30 (finitePair 338 2670 549 2028 3)=true := by decide +kernel
private theorem b5 : every 31 36 (finitePair 338 2670 549 2028 3)=true := by decide +kernel
private theorem b6 : every 37 40 (finitePair 338 2670 549 2028 3)=true := by decide +kernel
private theorem b7 : every 41 42 (finitePair 338 2670 549 2028 3)=true := by decide +kernel
private theorem b8 : every 43 46 (finitePair 338 2670 549 2028 3)=true := by decide +kernel
private theorem b9 : every 47 52 (finitePair 338 2670 549 2028 3)=true := by decide +kernel
private theorem b10 : every 53 58 (finitePair 338 2670 549 2028 3)=true := by decide +kernel
private theorem b11 : every 59 60 (finitePair 338 2670 549 2028 3)=true := by decide +kernel
private theorem b12 : every 61 66 (finitePair 338 2670 549 2028 3)=true := by decide +kernel
private theorem b13 : every 67 70 (finitePair 338 2670 549 2028 3)=true := by decide +kernel
private theorem b14 : every 71 72 (finitePair 338 2670 549 2028 3)=true := by decide +kernel
private theorem b15 : every 73 78 (finitePair 338 2670 549 2028 3)=true := by decide +kernel
private theorem b16 : every 79 79 (finitePair 338 2670 549 2028 3)=true := by decide +kernel
theorem checked : test 13 2 3=true :=
  fixedTest (h:=338) (A:=2670) (S:=549) (T:=2028)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 b3)) (joinEvery (joinEvery b4 b5) (joinEvery b6 b7))) (joinEvery (joinEvery (joinEvery b8 b9) (joinEvery b10 b11)) (joinEvery (joinEvery b12 b13) (joinEvery b14 (joinEvery b15 b16)))))
#print axioms checked
end OMA.RankThreeAt13E2P3
