import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E8P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 14 22 (finitePair 13122 418265 29523 236196 13)=true := by decide +kernel
private theorem b1 : every 23 24 (finitePair 13122 418265 29523 236196 13)=true := by decide +kernel
theorem checked : test 3 8 13=true :=
  fixedTest (h:=13122) (A:=418265) (S:=29523) (T:=236196)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery b0 b1)
#print axioms checked
end OMA.RankThreeAt3E8P13
