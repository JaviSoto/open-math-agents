import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b72_29_0 : every 30 195 (quick 72 1666 195 864 29)=true := by decide +kernel
private theorem b72_29_1 : every 196 366 (quick 72 1666 195 864 29)=true := by decide +kernel
private theorem b72_29_2 : every 367 540 (quick 72 1666 195 864 29)=true := by decide +kernel
private theorem b72_29_3 : every 541 712 (quick 72 1666 195 864 29)=true := by decide +kernel
private theorem b72_29_4 : every 713 922 (quick 72 1666 195 864 29)=true := by decide +kernel
private theorem b72_29_5 : every 923 1125 (quick 72 1666 195 864 29)=true := by decide +kernel
private theorem b72_29_6 : every 1126 1342 (quick 72 1666 195 864 29)=true := by decide +kernel
private theorem b72_29_7 : every 1343 1381 (quick 72 1666 195 864 29)=true := by decide +kernel
private theorem b72_29_8 : every 1 8 (far 72 1666 195 864 29 1382 312)=true := by decide +kernel
private theorem r72_29 : every 29 29 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 29=true := by change (every 30 1381 (quick 72 1666 195 864 29) && every 1 8 (far 72 1666 195 864 29 1382 312))=true; rw [Bool.and_eq_true]; exact ⟨(joinEvery (joinEvery (joinEvery b72_29_0 b72_29_1) (joinEvery b72_29_2 b72_29_3)) (joinEvery (joinEvery b72_29_4 b72_29_5) (joinEvery b72_29_6 b72_29_7))),b72_29_8⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=29 by omega] using yes
private theorem b72_29_9 : every 30 30 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_29_10 : every 32 196 (quick 72 1666 195 864 31)=true := by decide +kernel
private theorem b72_29_11 : every 197 376 (quick 72 1666 195 864 31)=true := by decide +kernel
private theorem b72_29_12 : every 377 533 (quick 72 1666 195 864 31)=true := by decide +kernel
private theorem b72_29_13 : every 1 9 (far 72 1666 195 864 31 534 120)=true := by decide +kernel
private theorem r72_31 : every 31 31 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 31=true := by change (every 32 533 (quick 72 1666 195 864 31) && every 1 9 (far 72 1666 195 864 31 534 120))=true; rw [Bool.and_eq_true]; exact ⟨(joinEvery b72_29_10 (joinEvery b72_29_11 b72_29_12)),b72_29_13⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=31 by omega] using yes
private theorem b72_29_14 : every 32 36 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_29_15 : every 38 196 (quick 72 1666 195 864 37)=true := by decide +kernel
private theorem b72_29_16 : every 197 218 (quick 72 1666 195 864 37)=true := by decide +kernel
private theorem b72_29_17 : every 1 10 (far 72 1666 195 864 37 219 49)=true := by decide +kernel
private theorem r72_37 : every 37 37 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 37=true := by change (every 38 218 (quick 72 1666 195 864 37) && every 1 10 (far 72 1666 195 864 37 219 49))=true; rw [Bool.and_eq_true]; exact ⟨(joinEvery b72_29_15 b72_29_16),b72_29_17⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=37 by omega] using yes
private theorem b72_29_18 : every 38 40 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_29_19 : every 42 168 (quick 72 1666 195 864 41)=true := by decide +kernel
private theorem b72_29_20 : every 1 11 (far 72 1666 195 864 41 169 38)=true := by decide +kernel
private theorem r72_41 : every 41 41 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 41=true := by change (every 42 168 (quick 72 1666 195 864 41) && every 1 11 (far 72 1666 195 864 41 169 38))=true; rw [Bool.and_eq_true]; exact ⟨b72_29_19,b72_29_20⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=41 by omega] using yes
private theorem b72_29_21 : every 42 42 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_29_22 : every 44 153 (quick 72 1666 195 864 43)=true := by decide +kernel
private theorem b72_29_23 : every 1 11 (far 72 1666 195 864 43 154 34)=true := by decide +kernel
private theorem r72_43 : every 43 43 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 43=true := by change (every 44 153 (quick 72 1666 195 864 43) && every 1 11 (far 72 1666 195 864 43 154 34))=true; rw [Bool.and_eq_true]; exact ⟨b72_29_22,b72_29_23⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=43 by omega] using yes
private theorem b72_29_24 : every 44 46 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_29_25 : every 48 133 (quick 72 1666 195 864 47)=true := by decide +kernel
private theorem b72_29_26 : every 1 12 (far 72 1666 195 864 47 134 30)=true := by decide +kernel
private theorem r72_47 : every 47 47 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 47=true := by change (every 48 133 (quick 72 1666 195 864 47) && every 1 12 (far 72 1666 195 864 47 134 30))=true; rw [Bool.and_eq_true]; exact ⟨b72_29_25,b72_29_26⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=47 by omega] using yes
private theorem b72_29_27 : every 48 52 (run 72 1666 195 864)=true := by decide +kernel
theorem span72_29_52 : every 29 52 (run 72 1666 195 864)=true := (joinEvery (joinEvery (joinEvery r72_29 (joinEvery b72_29_9 r72_31)) (joinEvery b72_29_14 (joinEvery r72_37 b72_29_18))) (joinEvery (joinEvery r72_41 (joinEvery b72_29_21 r72_43)) (joinEvery b72_29_24 (joinEvery r72_47 b72_29_27))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span72_29_52
