import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E12P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 14 22 (finitePair 1062882 49822595 2391483 27634932 13)=true := by decide +kernel
private theorem b1 : every 23 30 (finitePair 1062882 49822595 2391483 27634932 13)=true := by decide +kernel
private theorem b2 : every 31 38 (finitePair 1062882 49822595 2391483 27634932 13)=true := by decide +kernel
private theorem b3 : every 39 42 (finitePair 1062882 49822595 2391483 27634932 13)=true := by decide +kernel
theorem checked : test 3 12 13=true :=
  fixedTest (h:=1062882) (A:=49822595) (S:=2391483) (T:=27634932)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery b0 b1) (joinEvery b2 b3))
#print axioms checked
end OMA.RankThreeAt3E12P13
