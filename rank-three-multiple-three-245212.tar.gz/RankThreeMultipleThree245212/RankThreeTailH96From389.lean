import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_389_0 : every 390 88 (quick 96 2247 252 1152 389)=true := by decide +kernel
private theorem b96_389_1 : every 1 25 (far 96 2247 252 1152 389 390 19)=true := by decide +kernel
private theorem b96_389_2 : every 26 50 (far 96 2247 252 1152 389 390 19)=true := by decide +kernel
private theorem b96_389_3 : every 51 75 (far 96 2247 252 1152 389 390 19)=true := by decide +kernel
private theorem b96_389_4 : every 76 89 (far 96 2247 252 1152 389 390 19)=true := by decide +kernel
private theorem r96_389 : every 389 389 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 389=true := by change (every 390 88 (quick 96 2247 252 1152 389) && every 1 89 (far 96 2247 252 1152 389 390 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_389_0,(joinEvery (joinEvery b96_389_1 b96_389_2) (joinEvery b96_389_3 b96_389_4))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=389 by omega] using yes
private theorem b96_389_5 : every 390 396 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_389_6 : every 398 88 (quick 96 2247 252 1152 397)=true := by decide +kernel
private theorem b96_389_7 : every 1 25 (far 96 2247 252 1152 397 398 19)=true := by decide +kernel
private theorem b96_389_8 : every 26 50 (far 96 2247 252 1152 397 398 19)=true := by decide +kernel
private theorem b96_389_9 : every 51 75 (far 96 2247 252 1152 397 398 19)=true := by decide +kernel
private theorem b96_389_10 : every 76 90 (far 96 2247 252 1152 397 398 19)=true := by decide +kernel
private theorem r96_397 : every 397 397 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 397=true := by change (every 398 88 (quick 96 2247 252 1152 397) && every 1 90 (far 96 2247 252 1152 397 398 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_389_6,(joinEvery (joinEvery b96_389_7 b96_389_8) (joinEvery b96_389_9 b96_389_10))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=397 by omega] using yes
private theorem b96_389_11 : every 398 400 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_389_12 : every 402 88 (quick 96 2247 252 1152 401)=true := by decide +kernel
private theorem b96_389_13 : every 1 25 (far 96 2247 252 1152 401 402 19)=true := by decide +kernel
private theorem b96_389_14 : every 26 50 (far 96 2247 252 1152 401 402 19)=true := by decide +kernel
private theorem b96_389_15 : every 51 75 (far 96 2247 252 1152 401 402 19)=true := by decide +kernel
private theorem b96_389_16 : every 76 91 (far 96 2247 252 1152 401 402 19)=true := by decide +kernel
private theorem r96_401 : every 401 401 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 401=true := by change (every 402 88 (quick 96 2247 252 1152 401) && every 1 91 (far 96 2247 252 1152 401 402 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_389_12,(joinEvery (joinEvery b96_389_13 b96_389_14) (joinEvery b96_389_15 b96_389_16))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=401 by omega] using yes
private theorem b96_389_17 : every 402 408 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_389_18 : every 410 88 (quick 96 2247 252 1152 409)=true := by decide +kernel
private theorem b96_389_19 : every 1 25 (far 96 2247 252 1152 409 410 19)=true := by decide +kernel
private theorem b96_389_20 : every 26 50 (far 96 2247 252 1152 409 410 19)=true := by decide +kernel
private theorem b96_389_21 : every 51 75 (far 96 2247 252 1152 409 410 19)=true := by decide +kernel
private theorem b96_389_22 : every 76 93 (far 96 2247 252 1152 409 410 19)=true := by decide +kernel
private theorem r96_409 : every 409 409 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 409=true := by change (every 410 88 (quick 96 2247 252 1152 409) && every 1 93 (far 96 2247 252 1152 409 410 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_389_18,(joinEvery (joinEvery b96_389_19 b96_389_20) (joinEvery b96_389_21 b96_389_22))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=409 by omega] using yes
private theorem b96_389_23 : every 410 412 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_389_412 : every 389 412 (run 96 2247 252 1152)=true := (joinEvery (joinEvery (joinEvery r96_389 b96_389_5) (joinEvery r96_397 b96_389_11)) (joinEvery (joinEvery r96_401 b96_389_17) (joinEvery r96_409 b96_389_23)))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_389_412
