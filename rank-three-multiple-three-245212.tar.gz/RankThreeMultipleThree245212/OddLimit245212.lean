import OddFaces245212
import CapOrder245212
import FixedPrimes245212

/-! A large fourth prime and a large exponent in the first three positions
force the normalized divisor score to approach one of the certified faces. -/
namespace OMA.OddFaces245212
open Finset OMA.Smooth245212

def threshold : ℕ := 10000000000

private theorem xbounds {p : ℕ} (hp : 3≤p) (e : Option ℕ) : 1≤X p e ∧ X p e≤3/2 := by
  have h : 1<p := by omega
  have h' : (3:ℚ)≤p := by exact_mod_cast hp
  have yl := y_nonneg h e
  have yu := y_one h e
  constructor
  · exact le_add_of_nonneg_right (div_nonneg (by linarith only [yu]) (by linarith only [h']))
  · unfold X
    have rhs : (1-Y p e)/((p:ℚ)-1) ≤ 1/2 :=
      (div_le_iff₀ (by linarith only [h'])).2 (by linarith only [yl,h'])
    linarith only [rhs]

private theorem diff {p : ℕ} (hp : 3≤p) (e : ℕ) :
    0≤limitX p-X p (some e) ∧ limitX p-X p (some e)≤Y p (some e) := by
  have h : (3:ℚ)≤p := by exact_mod_cast hp
  have yl := y_nonneg (show 1<p by omega) (some e)
  have hv : limitX p-X p (some e) = Y p (some e)/((p:ℚ)-1) := by
    simp only [limitX,X,Y]; ring
  rw [hv]
  exact ⟨div_nonneg yl (by linarith),div_le_self yl (by linarith)⟩

private theorem xlarge {p : ℕ} (hp : threshold<p) (e : ℕ) :
    1≤X p (some e) ∧ X p (some e)≤1+1/10000000000 := by
  have hp' : (10000000001:ℚ)≤p := by
    exact_mod_cast (show 10000000001≤p from hp)
  have zl := y_nonneg (by dsimp [threshold] at hp; omega : 1<p) (some e)
  refine ⟨(xbounds (by dsimp [threshold] at hp; omega) _).1,?_⟩
  unfold X
  exact add_le_add_right ((div_le_iff₀ (by linarith only [hp'])).2
    (by linarith only [zl,hp'])) 1

private theorem ysmall {p e : ℕ} (hp : Nat.Prime p) (he : threshold≤e) :
    Y p (some e)<2/10000000000 := by
  have h := OMA.CapOrder245212.y_short hp e
  have h' : (10000000000:ℚ)≤e := by exact_mod_cast he
  have z := y_nonneg hp.one_lt (some e)
  nlinarith only [h,mul_nonneg z (show 0≤(e:ℚ)+1-10000000000 by linarith only [h'])]

def preScore (q r d : ℕ) (e : I → ℕ) : ℚ :=
  (∏ i : Fin 3, X (bases q i) (some (e i.castSucc))) * X r (some d) +
  (∏ i : Fin 3, Y (bases q i) (some (e i.castSucc))) * Y r (some d)

theorem near_face {q r : ℕ} (hq : Nat.Prime q) (hq' : 3≤q) (hr : threshold<r)
    (e : I → ℕ) (d : ℕ) (k : Fin 3) (large : threshold≤e k.castSucc)
    (eq : preScore q r d e=2) : ¬Separated (face q k e) := by
  let p := bases q
  let x (i : Fin 3) := X (p i) (some (e i.castSucc))
  let y (i : Fin 3) := Y (p i) (some (e i.castSucc))
  let U := ∏ i∈univ.erase k, x i
  let V := ∏ i∈univ.erase k, y i
  have pp (i : Fin 3) : Nat.Prime (p i) := by fin_cases i <;> simp [p,bases,hq] <;> decide
  have h3 (i : Fin 3) : 3≤p i := by fin_cases i <;> simp [p,bases,hq']
  have x0 (i : Fin 3) : 0≤x i := x_nonneg (pp i).one_lt _
  have x1 (i : Fin 3) : x i≤3/2 := (xbounds (h3 i) _).2
  have y0 (i : Fin 3) : 0≤y i := y_nonneg (pp i).one_lt _
  have y1 (i : Fin 3) : y i≤1 := y_one (pp i).one_lt _
  have u0 : 0≤U := prod_nonneg (fun i _ => x0 i)
  have u3 : U≤3 := by
    have h := prod_le_prod (s:=univ.erase k) (fun i _ => x0 i) (fun i _ => x1 i)
    have hc : (univ.erase k).card=2 := by simp
    simp only [prod_const,hc] at h
    norm_num at h ⊢
    linarith
  have v0 : 0≤V := prod_nonneg (fun i _ => y0 i)
  have v1 : V≤1 := prod_le_one (fun i _ => y0 i) (fun i _ => y1 i)
  have r1 : 1<r := by dsimp [threshold] at hr; omega
  have zr := y_nonneg r1 (some d)
  have ur := y_one r1 (some d)
  have xk0 := x0 k
  have xk1 := x1 k
  have yk0 := y0 k
  have yk1 : y k<2/10000000000 := ysmall (pp k) large
  have a := xlarge hr d
  have b := diff (h3 k) (e k.castSucc)
  change 0≤limitX (p k)-x k ∧ limitX (p k)-x k≤y k at b
  have f : face q k e=U*limitX (p k) := by
    rw [face,←prod_erase_mul _ _ (mem_univ k)]
    simp only [if_pos]
    congr 1
    exact prod_congr rfl fun i hi => if_neg (mem_erase.mp hi).1
  have xx : U*x k≤5 := (mul_le_mul u3 xk1 xk0 (by norm_num)).trans (by norm_num)
  have delta1 : U*x k*(X r (some d)-1) ≤ 5*(1/10000000000) :=
    mul_le_mul xx (by linarith only [a.2]) (by linarith only [a.1]) (by norm_num)
  have delta2 : V*y k*Y r (some d) ≤ y k :=
    (mul_le_of_le_one_right (mul_nonneg v0 yk0) ur).trans
      (mul_le_of_le_one_left yk0 v1)
  have delta3 : U*(limitX (p k)-x k)≤3*y k :=
    mul_le_mul u3 b.2 b.1 (by norm_num)
  have total : U*x k*X r (some d)+V*y k*Y r (some d)=2 := by
    change (∏ i,x i)*X r (some d)+(∏ i,y i)*Y r (some d)=2 at eq
    dsimp only [U,V]
    rw [prod_erase_mul _ _ (mem_univ k),prod_erase_mul _ _ (mem_univ k)]
    exact eq
  rw [f]
  unfold Separated gap
  push Not
  constructor
  · nlinarith only [total,delta1,delta2,yk1,mul_nonneg u0 b.1]
  · nlinarith only [total,delta3,yk1,mul_nonneg (mul_nonneg u0 xk0)
      (show 0≤X r (some d)-1 by linarith only [a.1]),mul_nonneg (mul_nonneg v0 yk0) zr]

end OMA.OddFaces245212
