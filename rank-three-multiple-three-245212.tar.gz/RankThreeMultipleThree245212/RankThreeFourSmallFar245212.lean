import RankThreeFourSmallNear245212

/-! A positive integral leading denominator bounds the candidate last prime
uniformly without computing the entire large prime power. -/
namespace OMA.RankThreeFourSmallFar245212
open Nat ArithmeticFunction OMA.Smooth245212 OMA.RankThreeFourSmallAffine245212
open OMA.RankThreeFourSmallDegree245212 OMA.CofactorEulerPair245212
open scoped ArithmeticFunction.sigma

def leading (A S H p d b : ℕ) := du A H p d*((b:ℤ)+1)+dc A S p d

def top (A S p d BB : ℕ) :=
  2*((nu A p d).natAbs*(BB+1)+(nc A S p d).natAbs+(nr A S p d).natAbs)+2

def little (A S p d : ℕ) := Nat.log p (2*(dr A S p d).natAbs)+1

theorem limited {h p q b d BB : ℕ} (hh : 0<h) (hp : p.Prime) (hq : q.Prime)
    (cp : h.Coprime p) (cq : h.Coprime q) (pq : p<q) (dp : 0<d) (bb : b≤BB)
    (large : little (W h) (σ 1 h) p d ≤ b)
    (nonzero : leading (W h) (σ 1 h) (2*(h*σ 0 h)) p d b≠0)
    (eqn : OeisA245212.a (h*p^b*q^d)=(σ 1 (h*p^b*q^d):ℤ)) :
    q ≤ top (W h) (σ 1 h) p d BB := by
  let A:ℤ:=W h
  let S:ℤ:=σ 1 h
  let H:ℤ:=2*(h*σ 0 h:ℕ)
  let P:ℤ:=(p:ℤ)^b
  let v:ℤ:=(p:ℤ)-1
  let D:=du A H p d*(b+1)+dc A S p d
  let N:=nu A p d*(b+1)+nc A S p d
  let D1:=dr A S p d
  let N1:=nr A S p d
  let V:=W (h*p^b)
  let Y:=σ 1 (h*p^b)
  let T:=(h*p^b)*σ 0 (h*p^b)
  let delta:=OMA.LastDigit245212.denom V Y T d
  have pp:=hp.pos
  have pos : 0<h*p^b := by positivity
  have cop:=(cq.mul_left (((coprime_primes hp hq).mpr pq.ne).pow_left b))
  obtain ⟨dpos,dlo,_,_⟩:=OMA.LastDigit245212.balance_digits pos hq cop dp eqn
  change 0<delta at dpos
  change delta*(q-1)<V*d+Y at dlo
  have subtract : delta+(V*(d+1)+Y)=2*T*(d+1) := Nat.sub_add_cancel
    (Nat.sub_pos_iff_lt.mp dpos).le
  have w : (V:ℤ)=A*W (p^b) := by
    simp only [V,A,w_mult.map_mul_of_coprime (cp.pow_right b),Nat.cast_mul]
  have s : (Y:ℤ)=S*σ 1 (p^b) := by
    simp only [Y,S,isMultiplicative_sigma.map_mul_of_coprime (cp.pow_right b),Nat.cast_mul]
  have t : (2:ℤ)*T=H*(b+1)*P := by
    dsimp [T,H,P]
    rw [isMultiplicative_sigma.map_mul_of_coprime (cp.pow_right b),sigma_zero_apply_prime_pow hp]
    push_cast;ring
  have loc:=OMA.ComplementaryLocal245212.moments hp b
  have sub : (delta:ℤ)+((V:ℤ)*(d+1)+Y)=2*T*(d+1) := by exact_mod_cast subtract
  have de : v^2*(delta:ℤ)=D*P+D1 := by
    rw [w,s,t] at sub
    dsimp [D,P,D1,v,du,dc,dr] at *
    linear_combination ((p:ℤ)-1)^2*sub - A*((d:ℤ)+1)*loc.2 - S*((p:ℤ)-1)*loc.1
  have ne : v^2*((V:ℤ)*d+Y)=N*P+N1 := by
    rw [w,s]
    dsimp [N,P,N1,v,nu,nc,nr]
    linear_combination A*(d:ℤ)*loc.2 + S*((p:ℤ)-1)*loc.1
  have qpos:=hq.pos
  have lower : (delta:ℤ)*((q:ℤ)-1)<V*d+Y := by
    zify [Nat.sub_le_sub_left qpos 0] at dlo
    simpa only [Nat.cast_sub (by omega : 1≤q),Nat.cast_one] using dlo
  have vpos : 0<v := sub_pos.mpr (by exact_mod_cast hp.one_lt)
  have mag : 2*D1.natAbs < p^b :=
    (Nat.lt_pow_succ_log_self hp.one_lt _).trans_le (Nat.pow_le_pow_right hp.pos large)
  have magZ : 2*|D1| <P := by simpa [P] using (show 2*(D1.natAbs:ℤ)<(p:ℤ)^b by exact_mod_cast mag)
  have Ppos : 1≤P := by dsimp [P]; exact_mod_cast Nat.one_le_pow b p hp.pos
  have positive : 0<D*P+D1 := by rw [←de]; exact mul_pos (sq_pos_of_pos vpos) (by exact_mod_cast dpos)
  have dd : 1≤D := by
    change D≠0 at nonzero
    by_contra! bad
    have mul:=mul_le_mul_of_nonneg_right (show D≤ -1 by omega) (by omega : 0≤P)
    linarith only [positive, le_abs_self D1, magZ, mul, abs_nonneg D1]
  have lowD : P≤2*(D*P+D1) := by
    have mul:=mul_le_mul_of_nonneg_right dd (by omega : 0≤P)
    linarith only [mul,neg_abs_le D1,magZ]
  have capq := mul_lt_mul_of_pos_left lower (sq_pos_of_pos vpos)
  have lm : ((q:ℤ)-1)*P < 2*(N*P+N1) := by
    have mult := mul_le_mul_of_nonneg_left lowD (show 0≤(q:ℤ)-1 by omega)
    nlinarith only [capq,mult,ne,congrArg (((q:ℤ)-1)*·) de]
  let Z:=top (W h) (σ 1 h) p d BB
  have nn : N ≤ (nu A p d).natAbs*(BB+1:ℤ)+(nc A S p d).natAbs := by
    have cmp := mul_le_mul (le_abs_self (nu A p d)) (show (b:ℤ)+1≤(BB:ℤ)+1 by omega)
      (by positivity) (abs_nonneg _)
    dsimp [N];simpa using add_le_add cmp (le_abs_self (nc A S p d))
  have nn1 : N1≤(N1.natAbs:ℤ)*P := by
    simpa using (le_abs_self N1).trans (le_mul_of_one_le_right (abs_nonneg _) Ppos)
  have zx : (Z:ℤ)=2*((nu A p d).natAbs*((BB:ℤ)+1)+(nc A S p d).natAbs+N1.natAbs)+2 := by
    simp [Z,top,A,S,N1]
  have largeq : ((q:ℤ)-1)*P < ((Z:ℤ)-1)*P := by
    nlinarith only [lm,mul_le_mul_of_nonneg_right nn (show 0≤P by omega),nn1,congrArg (·*P) zx,Ppos]
  have order := lt_of_mul_lt_mul_right largeq (by omega : 0≤P)
  change q≤Z
  omega


open OMA.RankThreeFourSmallBand245212

def exceptional (A S H p d : ℕ) :=
  ((-dc A S p d)/du A H p d).toNat-1

def clipped (A S T p R BB d : ℕ) :=
  let E:=max (little A S p d) (degree A S p (top A S p d BB) d)
  let ex:=exceptional A S (2*T) p d
  band A S T p R (min BB E) d &&
    (if E<ex ∧ ex≤BB ∧ leading A S (2*T) p d ex=0 then bit A S T p R d ex else true)

theorem clipped_sound {h p q b d R BB : ℕ} (hh : 0<h) (hp : p.Prime) (hq : q.Prime)
    (op : 3≤p) (cp : h.Coprime p) (cq : h.Coprime q) (pq : p<q) (bp : 0<b) (dp : 0<d)
    (rq : R≤q) (bb : b≤BB)
    (ck : clipped (W h) (σ 1 h) (h*σ 0 h) p R BB d=true)
    (eqn : OeisA245212.a (h*p^b*q^d)=(σ 1 (h*p^b*q^d):ℤ)) : False := by
  let A:=W h
  let S:=σ 1 h
  let T:=h*σ 0 h
  let H:=2*T
  let E:=max (little A S p d) (degree A S p (top A S p d BB) d)
  let ex:=exceptional A S H p d
  change (band A S T p R (min BB E) d && (if E<ex ∧ ex≤BB ∧ leading A S H p d ex=0 then _ else true))=true at ck
  rw [Bool.and_eq_true] at ck
  obtain ⟨bandOK,excOK⟩:=ck
  by_cases small : b≤E
  · exact band_sound hh hp hq cp cq pq bp dp rq (le_min bb small) bandOK eqn
  have init : little A S p d≤b := (le_max_left ..).trans (le_of_not_ge small)
  by_cases vanish : leading A S H p d b=0
  · have ds : 0<du A H p d := by
      simp only [band,Bool.and_eq_true,decide_eq_true_eq] at bandOK;exact bandOK.1.1.1
    have id : (-dc A S p d)/du A H p d=(b:ℤ)+1 := by
      have eq : -dc A S p d=((b:ℤ)+1)*du A H p d := by
        unfold leading at vanish; linarith only [vanish,mul_comm (du A H p d) ((b:ℤ)+1)]
      rw [eq,Int.mul_ediv_cancel _ ds.ne']
    have exb : ex=b := by change ((-dc A S p d)/du A H p d).toNat-1=b;rw [id];omega
    rw [exb,if_pos ⟨lt_of_not_ge small,bb,vanish⟩] at excOK
    change bit A S T p R d ex = true at excOK
    rw [exb] at excOK
    exact bit_sound hh hp hq cp cq pq dp rq eqn excOK
  · have largeq:=limited hh hp hq cp cq pq dp bb init vanish eqn
    have flipped : OeisA245212.a (h*q^d*p^b)=(σ 1 (h*q^d*p^b):ℤ) := by rwa [mul_right_comm]
    have t:=one hh hq hp cq cp pq.ne.symm (by omega) bp hp.one_lt le_rfl largeq (show d≤d from le_rfl) flipped
    exact small (t.trans (le_max_right _ _))

end OMA.RankThreeFourSmallFar245212
