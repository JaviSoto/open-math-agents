import RankThreeSmall245212
import RankThreeLast245212
import RankThreeRanges245212

/-! A bounded two-coordinate scan; the third coordinate is recovered rather
than iterated. All discarded prefixes fail a necessary Euler inequality. -/
namespace OMA.RankThreeScan245212
open OMA.RankThreeSmall245212 OMA.RankThreeRanges245212 OMA.RankThreeLast245212 OMA.Large245212
open scoped ArithmeticFunction.sigma

def interval (lo hi : ℕ) := List.range' lo (hi+1-lo)

theorem mem_interval {lo hi i : ℕ} (lower : lo ≤ i) (upper : i ≤ hi) : i∈interval lo hi := by
  exact List.mem_range'_1.mpr ⟨lower,by omega⟩

def row (B p q r a : ℕ) : Bool :=
  let w := wt p a
  let t := tax p a
  if 5*w*q*r < 8*t*(q-1)*(r-1) then true else
    let s := sig p a
    let H := height B
    (interval (leastExp q p r) (next B p a q r)).all fun b =>
      reject r (5*w*wt q b) (3*s*sig q b) (4*t*tax q b) H

def check (B p q r : ℕ) : Bool :=
  (interval (leastExp p q r) (first B p)).all (row B p q r)

theorem check_false {B p q r a b c : ℕ} (pp : p.Prime) (qp : q.Prime) (rp : r.Prime)
    (po : 3≤p) (qo : 3≤q) (ro : 3≤r) (pq : p≠q) (pr : p≠r) (qr : q≠r)
    (ap : 0<a) (bp : 0<b) (cp : 0<c) (a1 : a≤first B p) (b2 : b≤next B p a q r)
    (cb : c≤height B) (h : Bal p q r a b c)
    (hit : OeisA245212.a (2*p^a*q^b*r^c)=(σ 1 (2*p^a*q^b*r^c):ℤ)) : check B p q r=false := by
  have f := first_tests pp qp.one_lt rp.one_lt ap
    (OMA.RankThreeCap245212.one_cap po qp.one_lt rp.one_lt bp h)
  have g := first_tests qp pp.one_lt rp.one_lt bp
    (OMA.RankThreeCap245212.one_cap qo pp.one_lt rp.one_lt ap
      (by unfold Bal at h; convert h using 1; ring))
  have zz := prefix_false pp qp rp (by omega) (by omega) (by omega) pq pr qr cp cb hit
  apply Bool.eq_false_iff.mpr
  intro passed
  obtain rr := List.all_eq_true.mp passed a (mem_interval f.1 a1)
  simp only [row,not_lt.mpr f.2,if_false] at rr
  have y := List.all_eq_true.mp rr b (mem_interval g.1 b2)
  simp [zz] at y

end OMA.RankThreeScan245212
