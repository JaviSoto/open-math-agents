import RankThreeFourSmallCompact245212
/-! Independently checked consecutive interval for the compressed two-prime decision. -/
namespace OMA.RankThreeFourSmallCompactTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallCompact245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem r7_800_804 : every 800 804 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_805_809 : every 805 809 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_810_814 : every 810 814 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_815_819 : every 815 819 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_820_824 : every 820 824 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_825_829 : every 825 829 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_830_834 : every 830 834 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_835_839 : every 835 839 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_840_844 : every 840 844 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_845_849 : every 845 849 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_850_854 : every 850 854 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_855_859 : every 855 859 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_860_864 : every 860 864 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_865_869 : every 865 869 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_870_874 : every 870 874 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_875_879 : every 875 879 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_880_884 : every 880 884 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_885_889 : every 885 889 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_890_894 : every 890 894 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_895_899 : every 895 899 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_900_904 : every 900 904 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_905_909 : every 905 909 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_910_914 : every 910 914 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_915_919 : every 915 919 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_920_924 : every 920 924 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_925_929 : every 925 929 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_930_934 : every 930 934 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_935_939 : every 935 939 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_940_944 : every 940 944 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_945_949 : every 945 949 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_950_954 : every 950 954 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_955_959 : every 955 959 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_960_964 : every 960 964 (run 8748 418268 22960 209952)=true := by decide +kernel
theorem span7_800_964 : every 800 964 (run 8748 418268 22960 209952)=true := (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery r7_800_804 r7_805_809) (joinEvery r7_810_814 r7_815_819)) (joinEvery (joinEvery r7_820_824 r7_825_829) (joinEvery r7_830_834 r7_835_839))) (joinEvery (joinEvery (joinEvery r7_840_844 r7_845_849) (joinEvery r7_850_854 r7_855_859)) (joinEvery (joinEvery r7_860_864 r7_865_869) (joinEvery r7_870_874 r7_875_879)))) (joinEvery (joinEvery (joinEvery (joinEvery r7_880_884 r7_885_889) (joinEvery r7_890_894 r7_895_899)) (joinEvery (joinEvery r7_900_904 r7_905_909) (joinEvery r7_910_914 r7_915_919))) (joinEvery (joinEvery (joinEvery r7_920_924 r7_925_929) (joinEvery r7_930_934 r7_935_939)) (joinEvery (joinEvery r7_940_944 r7_945_949) (joinEvery r7_950_954 (joinEvery r7_955_959 r7_960_964))))))
end OMA.RankThreeFourSmallCompactTables245212
#print axioms OMA.RankThreeFourSmallCompactTables245212.span7_800_964
