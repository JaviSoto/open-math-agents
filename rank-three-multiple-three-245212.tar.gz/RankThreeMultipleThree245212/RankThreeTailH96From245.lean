import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_245_0 : every 245 250 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_245_1 : every 252 94 (quick 96 2247 252 1152 251)=true := by decide +kernel
private theorem b96_245_2 : every 1 25 (far 96 2247 252 1152 251 252 20)=true := by decide +kernel
private theorem b96_245_3 : every 26 50 (far 96 2247 252 1152 251 252 20)=true := by decide +kernel
private theorem b96_245_4 : every 51 58 (far 96 2247 252 1152 251 252 20)=true := by decide +kernel
private theorem r96_251 : every 251 251 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 251=true := by change (every 252 94 (quick 96 2247 252 1152 251) && every 1 58 (far 96 2247 252 1152 251 252 20))=true; rw [Bool.and_eq_true]; exact ⟨b96_245_1,(joinEvery b96_245_2 (joinEvery b96_245_3 b96_245_4))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=251 by omega] using yes
private theorem b96_245_5 : every 252 256 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_245_6 : every 258 94 (quick 96 2247 252 1152 257)=true := by decide +kernel
private theorem b96_245_7 : every 1 25 (far 96 2247 252 1152 257 258 20)=true := by decide +kernel
private theorem b96_245_8 : every 26 50 (far 96 2247 252 1152 257 258 20)=true := by decide +kernel
private theorem b96_245_9 : every 51 59 (far 96 2247 252 1152 257 258 20)=true := by decide +kernel
private theorem r96_257 : every 257 257 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 257=true := by change (every 258 94 (quick 96 2247 252 1152 257) && every 1 59 (far 96 2247 252 1152 257 258 20))=true; rw [Bool.and_eq_true]; exact ⟨b96_245_6,(joinEvery b96_245_7 (joinEvery b96_245_8 b96_245_9))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=257 by omega] using yes
private theorem b96_245_10 : every 258 262 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_245_11 : every 264 94 (quick 96 2247 252 1152 263)=true := by decide +kernel
private theorem b96_245_12 : every 1 25 (far 96 2247 252 1152 263 264 20)=true := by decide +kernel
private theorem b96_245_13 : every 26 50 (far 96 2247 252 1152 263 264 20)=true := by decide +kernel
private theorem b96_245_14 : every 51 60 (far 96 2247 252 1152 263 264 20)=true := by decide +kernel
private theorem r96_263 : every 263 263 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 263=true := by change (every 264 94 (quick 96 2247 252 1152 263) && every 1 60 (far 96 2247 252 1152 263 264 20))=true; rw [Bool.and_eq_true]; exact ⟨b96_245_11,(joinEvery b96_245_12 (joinEvery b96_245_13 b96_245_14))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=263 by omega] using yes
private theorem b96_245_15 : every 264 268 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_245_268 : every 245 268 (run 96 2247 252 1152)=true := (joinEvery (joinEvery b96_245_0 (joinEvery r96_251 b96_245_5)) (joinEvery (joinEvery r96_257 b96_245_10) (joinEvery r96_263 b96_245_15)))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_245_268
