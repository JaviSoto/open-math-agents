import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt11E11P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 2 (movingRow 18673648841490 941528513016 13694960189328 3)=true := by decide +kernel
private theorem b1 : every 3 4 (movingRow 18673648841490 941528513016 13694960189328 3)=true := by decide +kernel
private theorem b2 : every 5 7 (movingRow 18673648841490 941528513016 13694960189328 3)=true := by decide +kernel
private theorem b3 : every 8 10 (movingRow 18673648841490 941528513016 13694960189328 3)=true := by decide +kernel
private theorem b4 : every 11 14 (movingRow 18673648841490 941528513016 13694960189328 3)=true := by decide +kernel
private theorem b5 : every 15 18 (movingRow 18673648841490 941528513016 13694960189328 3)=true := by decide +kernel
private theorem b6 : every 19 21 (movingRow 18673648841490 941528513016 13694960189328 3)=true := by decide +kernel
private theorem b7 : every 22 22 (movingRow 18673648841490 941528513016 13694960189328 3)=true := by decide +kernel
private theorem b8 : every 23 23 (movingRow 18673648841490 941528513016 13694960189328 3)=true := by decide +kernel
private theorem b9 : every 24 24 (movingRow 18673648841490 941528513016 13694960189328 3)=true := by decide +kernel
private theorem b10 : every 25 25 (movingRow 18673648841490 941528513016 13694960189328 3)=true := by decide +kernel
private theorem b11 : every 26 26 (movingRow 18673648841490 941528513016 13694960189328 3)=true := by decide +kernel
private theorem b12 : every 27 27 (movingRow 18673648841490 941528513016 13694960189328 3)=true := by decide +kernel
private theorem b13 : every 28 28 (movingRow 18673648841490 941528513016 13694960189328 3)=true := by decide +kernel
private theorem b14 : every 29 29 (movingRow 18673648841490 941528513016 13694960189328 3)=true := by decide +kernel
private theorem b15 : every 30 30 (movingRow 18673648841490 941528513016 13694960189328 3)=true := by decide +kernel
theorem checked : test 11 11 3=true :=
  movingTest (h:=570623341222) (A:=18673648841490) (S:=941528513016) (T:=13694960189328)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 b3)) (joinEvery (joinEvery b4 b5) (joinEvery b6 b7))) (joinEvery (joinEvery (joinEvery b8 b9) (joinEvery b10 b11)) (joinEvery (joinEvery b12 b13) (joinEvery b14 b15))))
#print axioms checked
end OMA.RankThreeAt11E11P3
