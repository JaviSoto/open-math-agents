import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b72_53_0 : every 54 114 (quick 72 1666 195 864 53)=true := by decide +kernel
private theorem b72_53_1 : every 1 14 (far 72 1666 195 864 53 115 26)=true := by decide +kernel
private theorem r72_53 : every 53 53 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 53=true := by change (every 54 114 (quick 72 1666 195 864 53) && every 1 14 (far 72 1666 195 864 53 115 26))=true; rw [Bool.and_eq_true]; exact ⟨b72_53_0,b72_53_1⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=53 by omega] using yes
private theorem b72_53_2 : every 54 58 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_53_3 : every 60 102 (quick 72 1666 195 864 59)=true := by decide +kernel
private theorem b72_53_4 : every 1 15 (far 72 1666 195 864 59 103 23)=true := by decide +kernel
private theorem r72_59 : every 59 59 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 59=true := by change (every 60 102 (quick 72 1666 195 864 59) && every 1 15 (far 72 1666 195 864 59 103 23))=true; rw [Bool.and_eq_true]; exact ⟨b72_53_3,b72_53_4⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=59 by omega] using yes
private theorem b72_53_5 : every 60 60 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_53_6 : every 62 99 (quick 72 1666 195 864 61)=true := by decide +kernel
private theorem b72_53_7 : every 1 16 (far 72 1666 195 864 61 100 22)=true := by decide +kernel
private theorem r72_61 : every 61 61 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 61=true := by change (every 62 99 (quick 72 1666 195 864 61) && every 1 16 (far 72 1666 195 864 61 100 22))=true; rw [Bool.and_eq_true]; exact ⟨b72_53_6,b72_53_7⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=61 by omega] using yes
private theorem b72_53_8 : every 62 66 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_53_9 : every 68 93 (quick 72 1666 195 864 67)=true := by decide +kernel
private theorem b72_53_10 : every 1 17 (far 72 1666 195 864 67 94 21)=true := by decide +kernel
private theorem r72_67 : every 67 67 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 67=true := by change (every 68 93 (quick 72 1666 195 864 67) && every 1 17 (far 72 1666 195 864 67 94 21))=true; rw [Bool.and_eq_true]; exact ⟨b72_53_9,b72_53_10⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=67 by omega] using yes
private theorem b72_53_11 : every 68 70 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_53_12 : every 72 89 (quick 72 1666 195 864 71)=true := by decide +kernel
private theorem b72_53_13 : every 1 18 (far 72 1666 195 864 71 90 20)=true := by decide +kernel
private theorem r72_71 : every 71 71 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 71=true := by change (every 72 89 (quick 72 1666 195 864 71) && every 1 18 (far 72 1666 195 864 71 90 20))=true; rw [Bool.and_eq_true]; exact ⟨b72_53_12,b72_53_13⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=71 by omega] using yes
private theorem b72_53_14 : every 72 72 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_53_15 : every 74 87 (quick 72 1666 195 864 73)=true := by decide +kernel
private theorem b72_53_16 : every 1 18 (far 72 1666 195 864 73 88 20)=true := by decide +kernel
private theorem r72_73 : every 73 73 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 73=true := by change (every 74 87 (quick 72 1666 195 864 73) && every 1 18 (far 72 1666 195 864 73 88 20))=true; rw [Bool.and_eq_true]; exact ⟨b72_53_15,b72_53_16⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=73 by omega] using yes
private theorem b72_53_17 : every 74 76 (run 72 1666 195 864)=true := by decide +kernel
theorem span72_53_76 : every 53 76 (run 72 1666 195 864)=true := (joinEvery (joinEvery (joinEvery r72_53 (joinEvery b72_53_2 r72_59)) (joinEvery b72_53_5 (joinEvery r72_61 b72_53_8))) (joinEvery (joinEvery r72_67 (joinEvery b72_53_11 r72_71)) (joinEvery b72_53_14 (joinEvery r72_73 b72_53_17))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span72_53_76
