import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E3P7
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 8 16 (finitePair 54 710 120 432 7)=true := by decide +kernel
private theorem b1 : every 17 22 (finitePair 54 710 120 432 7)=true := by decide +kernel
private theorem b2 : every 23 24 (finitePair 54 710 120 432 7)=true := by decide +kernel
theorem checked : test 3 3 7=true :=
  fixedTest (h:=54) (A:=710) (S:=120) (T:=432)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery b0 (joinEvery b1 b2))
#print axioms checked
end OMA.RankThreeAt3E3P7
