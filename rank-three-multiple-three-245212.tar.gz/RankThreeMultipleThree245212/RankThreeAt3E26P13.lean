import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E26P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 14 30 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b1 : every 31 42 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b2 : every 43 52 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b3 : every 53 60 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b4 : every 61 66 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b5 : every 67 70 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b6 : every 71 72 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b7 : every 73 78 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b8 : every 79 82 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b9 : every 83 88 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b10 : every 89 96 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b11 : every 97 100 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b12 : every 101 102 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b13 : every 103 106 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b14 : every 107 108 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b15 : every 109 112 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b16 : every 113 126 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b17 : every 127 130 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b18 : every 131 136 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b19 : every 137 138 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b20 : every 139 148 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b21 : every 149 150 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b22 : every 151 156 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b23 : every 157 162 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b24 : every 163 166 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b25 : every 167 172 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b26 : every 173 178 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b27 : every 179 180 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b28 : every 181 190 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b29 : every 191 192 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b30 : every 193 196 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b31 : every 197 198 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b32 : every 199 210 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b33 : every 211 222 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b34 : every 223 226 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b35 : every 227 228 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b36 : every 229 232 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b37 : every 233 238 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b38 : every 239 240 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b39 : every 241 250 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b40 : every 251 256 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b41 : every 257 262 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b42 : every 263 268 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b43 : every 269 270 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b44 : every 271 276 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b45 : every 277 280 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b46 : every 281 282 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b47 : every 283 292 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b48 : every 293 306 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b49 : every 307 310 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b50 : every 311 312 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
private theorem b51 : every 313 314 (finitePair 5083731656658 505195833380390 11438396227479 274521509459532 13)=true := by decide +kernel
theorem checked : test 3 26 13=true :=
  fixedTest (h:=5083731656658) (A:=505195833380390) (S:=11438396227479) (T:=274521509459532)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 (joinEvery b1 b2)) (joinEvery b3 (joinEvery b4 b5))) (joinEvery (joinEvery b6 (joinEvery b7 b8)) (joinEvery (joinEvery b9 b10) (joinEvery b11 b12)))) (joinEvery (joinEvery (joinEvery b13 (joinEvery b14 b15)) (joinEvery b16 (joinEvery b17 b18))) (joinEvery (joinEvery b19 (joinEvery b20 b21)) (joinEvery (joinEvery b22 b23) (joinEvery b24 b25))))) (joinEvery (joinEvery (joinEvery (joinEvery b26 (joinEvery b27 b28)) (joinEvery b29 (joinEvery b30 b31))) (joinEvery (joinEvery b32 (joinEvery b33 b34)) (joinEvery (joinEvery b35 b36) (joinEvery b37 b38)))) (joinEvery (joinEvery (joinEvery b39 (joinEvery b40 b41)) (joinEvery b42 (joinEvery b43 b44))) (joinEvery (joinEvery b45 (joinEvery b46 b47)) (joinEvery (joinEvery b48 b49) (joinEvery b50 b51))))))
#print axioms checked
end OMA.RankThreeAt3E26P13
