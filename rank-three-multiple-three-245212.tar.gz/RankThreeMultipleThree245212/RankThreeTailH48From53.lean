import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b48_53_0 : every 54 47 (quick 48 903 124 480 53)=true := by decide +kernel
private theorem b48_53_1 : every 1 16 (far 48 903 124 480 53 54 12)=true := by decide +kernel
private theorem r48_53 : every 53 53 (run 48 903 124 480)=true := by
  have yes : run 48 903 124 480 53=true := by change (every 54 47 (quick 48 903 124 480 53) && every 1 16 (far 48 903 124 480 53 54 12))=true; rw [Bool.and_eq_true]; exact ⟨b48_53_0,b48_53_1⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=53 by omega] using yes
private theorem b48_53_2 : every 54 58 (run 48 903 124 480)=true := by decide +kernel
private theorem b48_53_3 : every 60 45 (quick 48 903 124 480 59)=true := by decide +kernel
private theorem b48_53_4 : every 1 17 (far 48 903 124 480 59 60 11)=true := by decide +kernel
private theorem r48_59 : every 59 59 (run 48 903 124 480)=true := by
  have yes : run 48 903 124 480 59=true := by change (every 60 45 (quick 48 903 124 480 59) && every 1 17 (far 48 903 124 480 59 60 11))=true; rw [Bool.and_eq_true]; exact ⟨b48_53_3,b48_53_4⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=59 by omega] using yes
private theorem b48_53_5 : every 60 60 (run 48 903 124 480)=true := by decide +kernel
private theorem b48_53_6 : every 62 44 (quick 48 903 124 480 61)=true := by decide +kernel
private theorem b48_53_7 : every 1 18 (far 48 903 124 480 61 62 11)=true := by decide +kernel
private theorem r48_61 : every 61 61 (run 48 903 124 480)=true := by
  have yes : run 48 903 124 480 61=true := by change (every 62 44 (quick 48 903 124 480 61) && every 1 18 (far 48 903 124 480 61 62 11))=true; rw [Bool.and_eq_true]; exact ⟨b48_53_6,b48_53_7⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=61 by omega] using yes
private theorem b48_53_8 : every 62 66 (run 48 903 124 480)=true := by decide +kernel
private theorem b48_53_9 : every 68 43 (quick 48 903 124 480 67)=true := by decide +kernel
private theorem b48_53_10 : every 1 20 (far 48 903 124 480 67 68 11)=true := by decide +kernel
private theorem r48_67 : every 67 67 (run 48 903 124 480)=true := by
  have yes : run 48 903 124 480 67=true := by change (every 68 43 (quick 48 903 124 480 67) && every 1 20 (far 48 903 124 480 67 68 11))=true; rw [Bool.and_eq_true]; exact ⟨b48_53_9,b48_53_10⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=67 by omega] using yes
private theorem b48_53_11 : every 68 70 (run 48 903 124 480)=true := by decide +kernel
private theorem b48_53_12 : every 72 42 (quick 48 903 124 480 71)=true := by decide +kernel
private theorem b48_53_13 : every 1 21 (far 48 903 124 480 71 72 11)=true := by decide +kernel
private theorem r48_71 : every 71 71 (run 48 903 124 480)=true := by
  have yes : run 48 903 124 480 71=true := by change (every 72 42 (quick 48 903 124 480 71) && every 1 21 (far 48 903 124 480 71 72 11))=true; rw [Bool.and_eq_true]; exact ⟨b48_53_12,b48_53_13⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=71 by omega] using yes
private theorem b48_53_14 : every 72 72 (run 48 903 124 480)=true := by decide +kernel
private theorem b48_53_15 : every 74 42 (quick 48 903 124 480 73)=true := by decide +kernel
private theorem b48_53_16 : every 1 21 (far 48 903 124 480 73 74 11)=true := by decide +kernel
private theorem r48_73 : every 73 73 (run 48 903 124 480)=true := by
  have yes : run 48 903 124 480 73=true := by change (every 74 42 (quick 48 903 124 480 73) && every 1 21 (far 48 903 124 480 73 74 11))=true; rw [Bool.and_eq_true]; exact ⟨b48_53_15,b48_53_16⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=73 by omega] using yes
theorem span48_53_73 : every 53 73 (run 48 903 124 480)=true := (joinEvery (joinEvery (joinEvery r48_53 b48_53_2) (joinEvery r48_59 (joinEvery b48_53_5 r48_61))) (joinEvery (joinEvery b48_53_8 (joinEvery r48_67 b48_53_11)) (joinEvery r48_71 (joinEvery b48_53_14 r48_73))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span48_53_73
