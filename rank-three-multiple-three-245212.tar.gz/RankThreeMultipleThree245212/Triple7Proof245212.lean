import TriResidue245212

/-! Fixed three-prime support (3,5,7) with unrestricted positive exponents. -/
namespace OMA.TriSupport245212
open OMA.Smooth245212
open scoped ArithmeticFunction.sigma
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def witness7 : Trace := (.branch 0 2 (.branch 1 2 .score .score) (.branch 0 6 (.branch 1 2 .score (.branch 2 2 .score (.branch 1 6 .score (.branch 0 4 .score (.branch 2 6 .score (.branch 1 14 (.sieve 2) (.branch 2 14 (.sieve 1) (.branch 1 30 (.sieve 2) (.branch 0 5 (.branch 2 30 .score (.branch 1 62 .score (.branch 2 62 (.sieve 1) (.branch 1 126 (.sieve 2) (.branch 2 126 (.sieve 1) (.branch 1 254 (.branch 2 254 (.branch 1 169 (.sieve 2) (.sieve 2)) .score) .score)))))) (.branch 2 30 (.sieve 1) .score)))))))))) (.branch 1 2 (.branch 2 2 .score (.branch 0 14 .score (.branch 2 6 .score (.branch 1 1 .score (.branch 0 30 .score (.branch 2 14 .score (.branch 0 62 .score (.branch 2 30 .score (.branch 0 126 .score (.branch 2 62 (.sieve 0) (.branch 0 254 (.branch 2 126 (.sieve 0) (.branch 0 169 (.sieve 2) (.sieve 2))) (.branch 2 126 (.sieve 0) .score)))))))))))) (.branch 2 2 (.branch 0 14 (.branch 1 6 .score (.sieve 1)) (.branch 1 6 (.sieve 0) (.branch 0 30 (.sieve 1) (.branch 1 14 (.sieve 0) (.branch 2 1 (.branch 1 30 .score (.branch 0 62 .score (.branch 1 62 (.sieve 0) (.branch 0 126 (.sieve 1) (.branch 1 126 (.sieve 0) (.branch 0 254 (.branch 1 254 (.branch 0 169 (.sieve 1) (.sieve 1)) (.branch 0 169 (.sieve 1) .score)) .score)))))) .score))))) (.branch 0 14 (.branch 1 6 (.sieve 2) (.branch 2 6 (.sieve 1) (.branch 1 14 (.sieve 2) (.branch 0 9 (.branch 2 14 (.sieve 1) (.branch 1 30 (.sieve 2) .score)) .score)))) (.branch 1 6 (.branch 2 6 (.sieve 0) (.branch 0 30 (.sieve 2) (.branch 1 4 (.branch 2 14 (.sieve 0) (.branch 0 62 (.sieve 2) .score)) .score))) (.branch 2 6 (.branch 0 30 (.sieve 1) (.branch 1 14 (.sieve 0) .score)) .score)))))))
theorem exclude7 (e : I3 → ℕ) (pos : ∀ i, 0<e i) :
    OeisA245212.a (total (P 7) e) ≠ (σ 1 (total (P 7) e) : ℤ) := by
  intro eq
  have ok : supported 7 := by unfold supported; decide +kernel
  exact Trace.sound ok witness7 initial (by decide +kernel) e (initial_fits ok e pos eq) eq
end OMA.TriSupport245212
