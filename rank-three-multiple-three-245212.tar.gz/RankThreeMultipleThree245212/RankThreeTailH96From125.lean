import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_125_0 : every 125 126 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_125_1 : every 128 116 (quick 96 2247 252 1152 127)=true := by decide +kernel
private theorem b96_125_2 : every 1 25 (far 96 2247 252 1152 127 128 25)=true := by decide +kernel
private theorem b96_125_3 : every 26 30 (far 96 2247 252 1152 127 128 25)=true := by decide +kernel
private theorem r96_127 : every 127 127 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 127=true := by change (every 128 116 (quick 96 2247 252 1152 127) && every 1 30 (far 96 2247 252 1152 127 128 25))=true; rw [Bool.and_eq_true]; exact ⟨b96_125_1,(joinEvery b96_125_2 b96_125_3)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=127 by omega] using yes
private theorem b96_125_4 : every 128 130 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_125_5 : every 132 115 (quick 96 2247 252 1152 131)=true := by decide +kernel
private theorem b96_125_6 : every 1 25 (far 96 2247 252 1152 131 132 25)=true := by decide +kernel
private theorem b96_125_7 : every 26 31 (far 96 2247 252 1152 131 132 25)=true := by decide +kernel
private theorem r96_131 : every 131 131 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 131=true := by change (every 132 115 (quick 96 2247 252 1152 131) && every 1 31 (far 96 2247 252 1152 131 132 25))=true; rw [Bool.and_eq_true]; exact ⟨b96_125_5,(joinEvery b96_125_6 b96_125_7)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=131 by omega] using yes
private theorem b96_125_8 : every 132 136 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_125_9 : every 138 112 (quick 96 2247 252 1152 137)=true := by decide +kernel
private theorem b96_125_10 : every 1 25 (far 96 2247 252 1152 137 138 24)=true := by decide +kernel
private theorem b96_125_11 : every 26 32 (far 96 2247 252 1152 137 138 24)=true := by decide +kernel
private theorem r96_137 : every 137 137 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 137=true := by change (every 138 112 (quick 96 2247 252 1152 137) && every 1 32 (far 96 2247 252 1152 137 138 24))=true; rw [Bool.and_eq_true]; exact ⟨b96_125_9,(joinEvery b96_125_10 b96_125_11)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=137 by omega] using yes
private theorem b96_125_12 : every 138 138 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_125_13 : every 140 112 (quick 96 2247 252 1152 139)=true := by decide +kernel
private theorem b96_125_14 : every 1 25 (far 96 2247 252 1152 139 140 24)=true := by decide +kernel
private theorem b96_125_15 : every 26 32 (far 96 2247 252 1152 139 140 24)=true := by decide +kernel
private theorem r96_139 : every 139 139 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 139=true := by change (every 140 112 (quick 96 2247 252 1152 139) && every 1 32 (far 96 2247 252 1152 139 140 24))=true; rw [Bool.and_eq_true]; exact ⟨b96_125_13,(joinEvery b96_125_14 b96_125_15)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=139 by omega] using yes
private theorem b96_125_16 : every 140 148 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_125_148 : every 125 148 (run 96 2247 252 1152)=true := (joinEvery (joinEvery (joinEvery b96_125_0 r96_127) (joinEvery b96_125_4 r96_131)) (joinEvery (joinEvery b96_125_8 r96_137) (joinEvery b96_125_12 (joinEvery r96_139 b96_125_16))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_125_148
