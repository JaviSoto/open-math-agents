import OddLimit245212
import OddTable245212
import FastFactor245212
import LargeExact245212
import PrimePowerDiv245212

/-! Score and modular exclusions for the three possible odd three-prime supports. -/
namespace OMA.TriSupport245212
open Finset Nat ArithmeticFunction OMA.Smooth245212 OMA.FastFactor245212
open scoped ArithmeticFunction.sigma
open private OMA.Large245212.moments from LargeExact245212

abbrev I3 := Fin 3
abbrev R := OMA.Box245212.Range
abbrev Box := I3 → R
abbrev P := OMA.OddFaces245212.bases
def Fits (b : Box) (e : I3 → ℕ) := ∀ i, (b i).has (e i)
def Deny (q : ℕ) (b : Box) :=
  ∀ e : I3 → ℕ, Fits b e →
    OeisA245212.a (total (P q) e) ≠ (σ 1 (total (P q) e) : ℤ)
def initial : Box := fun _ => ⟨1,10000000000⟩
def supported (q : ℕ) := q=7 ∨ q=11 ∨ q=13

theorem primes {q : ℕ} (ok : supported q) :
    (∀ i, (P q i).Prime) ∧ Function.Injective (P q) := by
  rcases ok with rfl|rfl|rfl <;> decide +kernel

theorem initial_fits {q : ℕ} (ok : supported q) (e : I3 → ℕ) (pos : ∀ i, 0<e i)
    (eq : OeisA245212.a (total (P q) e) = (σ 1 (total (P q) e) : ℤ)) : Fits initial e := by
  let v : Fin 4 → ℕ := Fin.snoc e 1
  have vpos (i : Fin 4) : 0 < v i := by
    refine Fin.lastCases ?_ (fun j => ?_) i
    · dsimp only [v]
      rw [Fin.snoc_last]; decide
    · simpa [v] using pos j
  have hp := primes ok
  have norm := normalized_of_eq (P q) hp.1 hp.2 e eq
  let r := OMA.OddFaces245212.threshold+1
  have rx : X r (some 0)=1 := by norm_num [X,Y,r,OMA.OddFaces245212.threshold]
  have ry : Y r (some 0)=1 := by norm_num [Y,r,OMA.OddFaces245212.threshold]
  have ps : OMA.OddFaces245212.preScore q r 0 v=2 := by
    simpa only [OMA.OddFaces245212.preScore,rx,ry,mul_one,v,Fin.snoc_castSucc,normalized]
      using norm
  intro i
  refine ⟨pos i,?_⟩
  change e i ≤ 10000000000
  by_contra! fail
  have qq : q.Prime ∧ 3≤q := by rcases ok with rfl|rfl|rfl <;> decide
  have hlarge : OMA.OddFaces245212.threshold ≤ v i.castSucc := by
    simpa only [v,Fin.snoc_castSucc,OMA.OddFaces245212.threshold] using fail.le
  exact OMA.OddFaces245212.near_face qq.1 qq.2 (by dsimp only [r];omega) v 0 i hlarge ps
    (OMA.OddFaces245212.separation ok i v vpos)

def scaledProd (f : R → R → ℕ) (q : ℕ) (b : Box) :=
  ∏ i, f ⟨P q i,P q i⟩ (b i)
def scoreTest (q : ℕ) (b : Box) : Bool :=
  decide (2*scale^3 < scaledProd lowX q b+scaledProd lowY q b ∨
    scaledProd highX q b+scaledProd highY q b < 2*scale^3)

theorem score_sound {q : ℕ} (ok : supported q) {b : Box} (test : scoreTest q b=true) : Deny q b := by
  intro e fit eq
  obtain ⟨prime,inj⟩ := primes ok
  have norm := normalized_of_eq (P q) prime inj e eq
  have h (i : I3) := OMA.FastFactor245212.bounds (pb:=⟨P q i,P q i⟩)
    (eb:=b i) (p:=P q i) (e:=e i) (prime i).one_lt ⟨le_rfl,le_rfl⟩ (fit i)
  have enclose (f F : R → R → ℕ) (u : I3 → ℚ) (hu : ∀ i, 0≤u i)
      (v : ∀ i, (f ⟨P q i,P q i⟩ (b i) : ℚ)≤ scale*u i ∧
        scale*u i ≤ (F ⟨P q i,P q i⟩ (b i) : ℚ)) :
      (scaledProd f q b:ℚ)≤(scale:ℚ)^3*∏ i,u i ∧
      (scale:ℚ)^3*(∏ i,u i) ≤ scaledProd F q b := by
    have lo := prod_le_prod (s:=(univ:Finset I3)) (fun i _ =>
      show (0:ℚ)≤f ⟨P q i,P q i⟩ (b i) by positivity) (fun i _ => (v i).1)
    have hi := prod_le_prod (s:=(univ:Finset I3)) (fun i _ => mul_nonneg
      (Nat.cast_nonneg scale) (hu i)) (fun i _ => (v i).2)
    have size : (univ : Finset I3).card=3 := by decide
    simpa only [scaledProd,Nat.cast_prod,prod_mul_distrib,prod_const,size] using And.intro lo hi
  have x := enclose lowX highX _ (fun i => x_nonneg (prime i).one_lt (some (e i)))
    (fun i => ⟨(h i).1,(h i).2.1⟩)
  have y := enclose lowY highY _ (fun i => y_nonneg (prime i).one_lt (some (e i)))
    (fun i => (h i).2.2)
  rw [scoreTest,decide_eq_true_eq] at test
  unfold normalized at norm
  have sn := congrArg (fun z : ℚ => (scale:ℚ)^3*z) norm
  rw [mul_add] at sn
  rcases test with t|t
  · have bad : 2*(scale:ℚ)^3 < (scaledProd lowX q b:ℚ)+scaledProd lowY q b := by exact_mod_cast t
    linarith only [bad,sn,x.1,y.1]
  · have bad : (scaledProd highX q b:ℚ)+scaledProd highY q b < 2*(scale:ℚ)^3 := by exact_mod_cast t
    linarith only [bad,sn,x.2,y.2]

end OMA.TriSupport245212
