import RankThreeMiddle5
import RankThreeMiddle7
import RankThreeMiddle11
import RankThreeMiddle13

/-! The four middle primes for which the Euler product leaves the largest
prime unrestricted when 2 and 3 divide the integer exactly to these roles. -/
namespace OMA.RankThreeFront245212
open Nat OMA.Smooth245212 OMA.RankThreeMiddle245212
open scoped ArithmeticFunction.sigma

theorem original {p q a e f : ℕ} (hp : p.Prime) (hq : q.Prime) (lo : 5≤p) (hi : p≤13)
    (pq : p<q) (aa : 0<a) (ee : 0<e) (ff : 0<f) :
    OeisA245212.a (2*3^a*p^e*q^f)≠(σ 1 (2*3^a*p^e*q^f):ℤ) := by
  have which : p=5 ∨ p=7 ∨ p=11 ∨ p=13 := by interval_cases p <;> norm_num at *
  rcases which with rfl|rfl|rfl|rfl
  · exact close_short_prefix hp hq lo pq aa ee ff RankThreeMiddle5.mass RankThreeMiddle5.range0 RankThreeMiddle5.range1
  · exact close_short_prefix hp hq lo pq aa ee ff RankThreeMiddle7.mass RankThreeMiddle7.range0 RankThreeMiddle7.range1
  · exact close_short_prefix hp hq lo pq aa ee ff RankThreeMiddle11.mass RankThreeMiddle11.range0 RankThreeMiddle11.range1
  · exact close_short_prefix hp hq lo pq aa ee ff RankThreeMiddle13.mass RankThreeMiddle13.range0 RankThreeMiddle13.range1

#print axioms original
end OMA.RankThreeFront245212
