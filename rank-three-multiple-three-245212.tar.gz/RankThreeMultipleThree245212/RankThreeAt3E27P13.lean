import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E27P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 14 30 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b1 : every 31 42 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b2 : every 43 52 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b3 : every 53 60 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b4 : every 61 66 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b5 : every 67 70 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b6 : every 71 72 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b7 : every 73 78 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b8 : every 79 82 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b9 : every 83 88 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b10 : every 89 96 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b11 : every 97 100 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b12 : every 101 102 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b13 : every 103 106 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b14 : every 107 108 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b15 : every 109 112 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b16 : every 113 126 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b17 : every 127 130 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b18 : every 131 136 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b19 : every 137 138 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b20 : every 139 148 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b21 : every 149 150 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b22 : every 151 156 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b23 : every 157 162 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b24 : every 163 166 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b25 : every 167 172 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b26 : every 173 178 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b27 : every 179 180 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b28 : every 181 190 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b29 : every 191 192 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b30 : every 193 196 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b31 : every 197 198 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b32 : every 199 210 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b33 : every 211 222 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b34 : every 223 226 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b35 : every 227 228 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b36 : every 229 232 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b37 : every 233 238 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b38 : every 239 240 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b39 : every 241 250 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b40 : every 251 256 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b41 : every 257 262 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b42 : every 263 268 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b43 : every 269 270 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b44 : every 271 276 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b45 : every 277 280 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b46 : every 281 282 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b47 : every 283 292 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b48 : every 293 306 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b49 : every 307 310 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b50 : every 311 312 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b51 : every 313 316 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b52 : every 317 330 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b53 : every 331 336 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b54 : every 337 346 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b55 : every 347 348 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b56 : every 349 352 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b57 : every 353 358 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b58 : every 359 366 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b59 : every 367 372 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b60 : every 373 378 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b61 : every 379 382 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b62 : every 383 388 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b63 : every 389 396 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
private theorem b64 : every 397 398 (finitePair 15251194969974 1572779481278570 34315188682440 854066918318544 13)=true := by decide +kernel
theorem checked : test 3 27 13=true :=
  fixedTest (h:=15251194969974) (A:=1572779481278570) (S:=34315188682440) (T:=854066918318544)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 b3)) (joinEvery (joinEvery b4 b5) (joinEvery b6 b7))) (joinEvery (joinEvery (joinEvery b8 b9) (joinEvery b10 b11)) (joinEvery (joinEvery b12 b13) (joinEvery b14 b15)))) (joinEvery (joinEvery (joinEvery (joinEvery b16 b17) (joinEvery b18 b19)) (joinEvery (joinEvery b20 b21) (joinEvery b22 b23))) (joinEvery (joinEvery (joinEvery b24 b25) (joinEvery b26 b27)) (joinEvery (joinEvery b28 b29) (joinEvery b30 b31))))) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b32 b33) (joinEvery b34 b35)) (joinEvery (joinEvery b36 b37) (joinEvery b38 b39))) (joinEvery (joinEvery (joinEvery b40 b41) (joinEvery b42 b43)) (joinEvery (joinEvery b44 b45) (joinEvery b46 b47)))) (joinEvery (joinEvery (joinEvery (joinEvery b48 b49) (joinEvery b50 b51)) (joinEvery (joinEvery b52 b53) (joinEvery b54 b55))) (joinEvery (joinEvery (joinEvery b56 b57) (joinEvery b58 b59)) (joinEvery (joinEvery b60 b61) (joinEvery b62 (joinEvery b63 b64)))))))
#print axioms checked
end OMA.RankThreeAt3E27P13
