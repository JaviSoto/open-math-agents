import RankThreeAt3E1P7
import RankThreeAt3E2P7
import RankThreeAt3E3P7
import RankThreeAt3E4P7
import RankThreeAt3E5P7
import RankThreeAt3E6P7
import RankThreeAt7E1P3
import RankThreeAt7E2P3
import RankThreeAt7E3P3
import RankThreeAt7E4P3
import RankThreeAt7E5P3
/-! Both ordered short-cofactor certificates. -/
namespace OMA.RankThreeMiddle7
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212 OMA.Smooth245212
theorem range0 : rangeCheck 3 7 7=true := range_from_every (joinEvery (joinEvery (singleTest OMA.RankThreeAt3E1P7.checked) (joinEvery (singleTest OMA.RankThreeAt3E2P7.checked) (singleTest OMA.RankThreeAt3E3P7.checked))) (joinEvery (singleTest OMA.RankThreeAt3E4P7.checked) (joinEvery (singleTest OMA.RankThreeAt3E5P7.checked) (singleTest OMA.RankThreeAt3E6P7.checked))))
theorem range1 : rangeCheck 7 3 6=true := range_from_every (joinEvery (joinEvery (singleTest OMA.RankThreeAt7E1P3.checked) (singleTest OMA.RankThreeAt7E2P3.checked)) (joinEvery (singleTest OMA.RankThreeAt7E3P3.checked) (joinEvery (singleTest OMA.RankThreeAt7E4P3.checked) (singleTest OMA.RankThreeAt7E5P3.checked))))
theorem mass : 8≤5*X 3 (some 7)*X 7 (some 6) := by decide +kernel
end OMA.RankThreeMiddle7
