import RankThreeCap245212
import LargeExact245212

/-! Integer endpoint tests for a dyadic rank-three support. -/
namespace OMA.RankThreeRanges245212
open OMA.Smooth245212 OMA.OddFaces245212 OMA.Large245212
open private OMA.Large245212.moments from LargeExact245212
open private OMA.Moving245212.y_infty from Moving245212

def den (p q r : ℕ) := 5*p*q*r-8*(p-1)*(q-1)*(r-1)
def leastExp (p q r : ℕ) := max 1 ((5*q*r-1)/den p q r)

private theorem lim {p : ℕ} (hp : 1<p) : limitX p=(p:ℚ)/((p:ℚ)-1) := by
  have pr : (1:ℚ)<p := by exact_mod_cast hp
  change 1+(1-0)/((p:ℚ)-1)=_
  field_simp [(sub_pos.mpr pr).ne'];ring

theorem capNat {p q r : ℕ} (hp : 1<p) (hq : 1<q) (hr : 1<r)
    (cap : 8≤5*(limitX p*limitX q*limitX r)) :
    8*(p-1)*(q-1)*(r-1)≤5*p*q*r := by
  have h (v : ℕ) (x : 1<v) : (0:ℚ)<(v:ℚ)-1 := sub_pos.mpr (by exact_mod_cast x)
  rw [lim hp,lim hq,lim hr] at cap
  have u := mul_le_mul_of_nonneg_right cap (mul_nonneg (mul_nonneg (h p hp).le (h q hq).le) (h r hr).le)
  have v : (8:ℚ)*((p:ℚ)-1)*((q:ℚ)-1)*((r:ℚ)-1)≤5*p*q*r := by
    calc
      _ = 8*(((p:ℚ)-1)*((q:ℚ)-1)*((r:ℚ)-1)) := by ring
      _ ≤ _ := u
      _ = _ := by field_simp [(h p hp).ne',(h q hq).ne',(h r hr).ne']
  have z : (8:ℚ)*((p-1:ℕ):ℚ)*((q-1:ℕ):ℚ)*((r-1:ℕ):ℚ)≤5*p*q*r := by
    simpa [Nat.cast_sub (show 1≤p by omega),Nat.cast_sub (show 1≤q by omega),Nat.cast_sub (show 1≤r by omega)] using v
  exact_mod_cast z

theorem first_tests {p q r a : ℕ} (hp : p.Prime) (hq : 1<q) (hr : 1<r) (ap : 0<a)
    (cap : 8≤5*X p (some a)*(limitX q*limitX r)) :
    leastExp p q r≤a ∧ 8*tax p a*(q-1)*(r-1)≤5*wt p a*q*r := by
  have pg := hp.one_lt
  have h (v : ℕ) (x : 1<v) : (0:ℚ)<(v:ℚ)-1 := sub_pos.mpr (by exact_mod_cast x)
  let U := Y p (some a)
  have lx : X p (some a)*((p:ℚ)-1)=(p:ℚ)-U := by
    unfold X U;field_simp [(h p pg).ne'];ring
  rw [lim hq,lim hr] at cap
  have t := mul_le_mul_of_nonneg_right cap (mul_nonneg (h q hq).le (h r hr).le)
  have one : (8:ℚ)*((q:ℚ)-1)*((r:ℚ)-1)≤5*X p (some a)*q*r := by
    calc
      _ = 8*(((q:ℚ)-1)*((r:ℚ)-1)) := by ring
      _ ≤ _ := t
      _ = _ := by field_simp [(h q hq).ne',(h r hr).ne']
  have gap := mul_le_mul_of_nonneg_right one (h p pg).le
  have gap' : (5:ℚ)*q*r*U ≤ 5*p*q*r-8*((p:ℚ)-1)*((q:ℚ)-1)*((r:ℚ)-1) := by
    linear_combination (norm := linarith) gap + (5*(q:ℚ)*r)*lx
  have u0 := y_nonneg pg (some a)
  have pos : (0:ℚ)<(a:ℚ)+1 := by positivity
  have flat : (1:ℚ) ≤ U*((a:ℚ)+1) := (div_le_iff₀ pos).mp (OMA.Moving245212.y_infty (e:=a) pg)
  have e_bound : (5:ℚ)*q*r ≤ (5*p*q*r-8*((p:ℚ)-1)*((q:ℚ)-1)*((r:ℚ)-1))*((a:ℚ)+1) := by
    nlinarith only [mul_le_mul_of_nonneg_right gap' pos.le,
      mul_le_mul_of_nonneg_left flat (show (0:ℚ)≤5*q*r by positivity)]
  have base : 8*(p-1)*(q-1)*(r-1)≤5*p*q*r := by
    have le : (8:ℚ)*((p-1:ℕ):ℚ)*((q-1:ℕ):ℚ)*((r-1:ℕ):ℚ)≤5*p*q*r := by
      simp only [Nat.cast_sub (show 1≤p by omega),Nat.cast_sub (show 1≤q by omega),Nat.cast_sub (show 1≤r by omega),Nat.cast_one]
      nlinarith only [gap',mul_nonneg (by positivity : (0:ℚ)≤5*q*r) u0]
    exact_mod_cast le
  have len : 5*q*r≤den p q r*(a+1) := by
    have dc : (den p q r:ℚ)=5*p*q*r-8*((p:ℚ)-1)*((q:ℚ)-1)*((r:ℚ)-1) := by
      unfold den; push_cast [Nat.cast_sub base,Nat.cast_sub (show 1≤p by omega),
        Nat.cast_sub (show 1≤q by omega),Nat.cast_sub (show 1≤r by omega)];ring
    rw [← dc] at e_bound
    exact_mod_cast e_bound
  have dpos : 0<den p q r := by
    by_contra! h0
    have z : den p q r=0 := by omega
    rw [z,zero_mul] at len
    have w : 0<5*q*r := by positivity
    omega
  constructor
  · apply max_le ap
    apply Nat.le_of_lt_succ
    apply (Nat.div_lt_iff_lt_mul dpos).mpr
    have positive : 0<5*q*r := by positivity
    exact (by omega : 5*q*r-1 <5*q*r).trans_le (by simpa only [mul_comm (den p q r)] using len)
  · have ww := (OMA.Large245212.moments hp a).2
    have xf := x_factor hp a
    rw [← ww] at xf
    have t0 : (0:ℚ)≤((a:ℚ)+1)*(p:ℚ)^a := by positivity
    have cmp := mul_le_mul_of_nonneg_right one t0
    have ru : (8:ℚ)*(tax p a:ℚ)*((q-1:ℕ):ℚ)*((r-1:ℕ):ℚ)≤5*wt p a*q*r := by
      simp only [tax,Nat.cast_mul,Nat.cast_add,Nat.cast_one,Nat.cast_pow,
        Nat.cast_sub (show 1≤q by omega),Nat.cast_sub (show 1≤r by omega)]
      nlinarith only [cmp,congrArg ((5*(q:ℚ)*r)*·) xf]
    exact_mod_cast ru
end OMA.RankThreeRanges245212
