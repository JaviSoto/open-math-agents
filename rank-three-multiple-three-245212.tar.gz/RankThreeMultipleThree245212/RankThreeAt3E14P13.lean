import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E14P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 14 28 (finitePair 9565938 520147880 21523359 286978140 13)=true := by decide +kernel
private theorem b1 : every 29 36 (finitePair 9565938 520147880 21523359 286978140 13)=true := by decide +kernel
private theorem b2 : every 37 40 (finitePair 9565938 520147880 21523359 286978140 13)=true := by decide +kernel
private theorem b3 : every 41 44 (finitePair 9565938 520147880 21523359 286978140 13)=true := by decide +kernel
private theorem b4 : every 45 52 (finitePair 9565938 520147880 21523359 286978140 13)=true := by decide +kernel
private theorem b5 : every 53 54 (finitePair 9565938 520147880 21523359 286978140 13)=true := by decide +kernel
theorem checked : test 3 14 13=true :=
  fixedTest (h:=9565938) (A:=520147880) (S:=21523359) (T:=286978140)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery b0 (joinEvery b1 b2)) (joinEvery b3 (joinEvery b4 b5)))
#print axioms checked
end OMA.RankThreeAt3E14P13
