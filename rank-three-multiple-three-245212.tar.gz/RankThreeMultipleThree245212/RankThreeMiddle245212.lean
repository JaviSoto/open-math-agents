import RankThreeScan245212

/-! Reindex the three odd powers, check each possible order of the two
small exponents, and extract one of the finitely many supports. -/
namespace OMA.RankThreeMiddle245212
open OMA.RankThreeSmall245212 OMA.RankThreeScan245212 OMA.RankThreeRanges245212
open OMA.Smooth245212 OMA.OddFaces245212
open scoped ArithmeticFunction.sigma

structure State (B p q r a b c : ℕ) : Prop where
  pp : p.Prime
  qp : q.Prime
  rp : r.Prime
  po : 3≤p
  qo : 3≤q
  ro : 3≤r
  pq : p≠q
  pr : p≠r
  qr : q≠r
  pB : p≤B
  qB : q≤B
  rB : r≤B
  ap : 0<a
  bp : 0<b
  cp : 0<c
  ab : a≤height B
  bb : b≤height B
  cb : c≤height B
  h : Bal p q r a b c
  hit : OeisA245212.a (2*p^a*q^b*r^c)=(σ 1 (2*p^a*q^b*r^c):ℤ)

namespace State
variable {B p q r a b c : ℕ} (s : State B p q r a b c)
include s

theorem ctx : Context B p q r a b c :=
  context s.pp s.qp s.rp s.pB s.qB s.rB s.ap s.bp s.cp s.ab s.bb s.cb s.h

theorem swap : State B p r q a c b := by
  refine ⟨s.pp,s.rp,s.qp,s.po,s.ro,s.qo,s.pr,s.pq,s.qr.symm,s.pB,s.rB,s.qB,s.ap,s.cp,s.bp,
    s.ab,s.cb,s.bb,?_,?_⟩
  · have u:=s.h;unfold Bal at *;convert u using 1;ring
  · rw [mul_right_comm _ (r^c) (q^b)]; exact s.hit

theorem cycle : State B q r p b c a := by
  refine ⟨s.qp,s.rp,s.pp,s.qo,s.ro,s.po,s.qr,s.pq.symm,s.pr.symm,s.qB,s.rB,s.pB,s.bp,s.cp,s.ap,
    s.bb,s.cb,s.ab,?_,?_⟩
  · have u := s.h;unfold Bal at *;convert u using 1;ring
  · rw [show 2*q^b*r^c*p^a=2*p^a*q^b*r^c by ring]; exact s.hit

theorem after_first (a1 : a≤first B p) (ck : check B p q r=true) (ck' : check B p r q=true) : False := by
  rcases small_two s.ctx with h|h
  · simp [check_false s.pp s.qp s.rp s.po s.qo s.ro s.pq s.pr s.qr s.ap s.bp s.cp a1 h s.cb s.h s.hit] at ck
  · let t := s.swap
    simp [check_false t.pp t.qp t.rp t.po t.qo t.ro t.pq t.pr t.qr t.ap t.bp t.cp a1 h t.cb t.h t.hit] at ck'
end State

structure Facts (B p q r : ℕ) : Prop where
  v : seed B p q r
  w : seed B q p r
  x : seed B r p q
  pq : check B p q r=true
  pr : check B p r q=true
  qr : check B q r p=true
  qp : check B q p r=true
  rp : check B r p q=true
  rq : check B r q p=true

theorem exclude {B p q r a b c : ℕ} (s : State B p q r a b c) (ok : Facts B p q r) : False := by
  rcases small_one s.ctx ok.v ok.w ok.x with aa|bb|cc
  · exact s.after_first aa ok.pq ok.pr
  · exact s.cycle.after_first bb ok.qr ok.qp
  · exact s.cycle.cycle.after_first cc ok.rp ok.rq

def lastBase (q : ℕ) := 16*(q-1)/(q-16)

def supports : List (ℕ×ℕ) :=
  [17,19,23,29,31].flatMap fun q =>
    ((interval (q+1) (lastBase q)).filter (fun r => decide (Nat.Prime r))).map (q,·)

theorem close (ok : ∀ z∈supports,Facts z.2 3 z.1 z.2) {q r a b c : ℕ}
    (qp : q.Prime) (rp : r.Prime) (middle : 17≤q) (qr : q<r) (ap : 0<a) (bp : 0<b) (cp : 0<c) :
    OeisA245212.a (2*3^a*q^b*r^c)≠(σ 1 (2*3^a*q^b*r^c):ℤ) := by
  intro hit
  have n := OMA.RankThreeCap245212.norm (by decide : Nat.Prime 3) qp rp (by decide) (by omega) qr hit
  have cap := OMA.RankThreeCap245212.caps (by decide : 1<3) qp.one_lt rp.one_lt ap n
  have bound (u v : ℕ) (up : u≤q) (vr : v≤r) (ug : 1<u) (vg : 1<v)
      (bad : 5*(limitX 3*limitX u*limitX v)<8) : False := by
    have h := mul_le_mul (mul_le_mul_of_nonneg_left (cap_anti ug up)
      (x_nonneg (by decide : 1<3) none)) (cap_anti vg vr) (x_nonneg rp.one_lt none)
      (mul_nonneg (x_nonneg (by decide : 1<3) none) (x_nonneg ug none))
    change limitX 3*limitX q*limitX r≤limitX 3*limitX u*limitX v at h
    linarith
  have q32 : q<32 := by by_contra! hi; exact bound 32 32 hi (by omega) (by decide) (by decide) (by decide +kernel)
  have num := capNat (by decide : 1<3) qp.one_lt rp.one_lt cap
  have boundR : r≤lastBase q := by
    apply (Nat.le_div_iff_mul_le (by omega : 0<q-16)).mpr
    have qq : q-16+16=q := by omega
    have qs : q-1+1=q := by omega
    have rs : r-1+1=r := by omega
    have x := congrArg (·*(r-1)) qs
    have y := congrArg (·*q) rs
    have z := congrArg (·*r) qq
    norm_num at num
    nlinarith only [num,x,y,z,qs]
  have qmem : q∈([17,19,23,29,31]:List ℕ) := by interval_cases q <;> norm_num at *
  have mem : (q,r)∈supports := by
    apply List.mem_flatMap.mpr
    refine ⟨q,qmem,List.mem_map.mpr ⟨r,?_,rfl⟩⟩
    simpa [rp] using (mem_interval qr boundR)
  obtain ⟨aa,bb,cc⟩ := exponent_height (by decide : Nat.Prime 3) qp rp (by decide) (by omega)
    qr ap bp cp hit
  apply exclude (B:=r) (a:=a) (b:=b) (c:=c) _ (ok _ mem)
  exact ⟨by decide,qp,rp,by decide,by omega,by omega,by omega,by omega,qr.ne,by omega,qr.le,le_rfl,
    ap,bp,cp,aa,bb,cc,n,hit⟩
end OMA.RankThreeMiddle245212
