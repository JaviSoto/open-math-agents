import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt13E17P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 1 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b1 : every 2 2 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b2 : every 3 3 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b3 : every 4 4 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b4 : every 5 5 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b5 : every 6 7 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b6 : every 8 9 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b7 : every 10 11 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b8 : every 12 13 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b9 : every 14 15 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b10 : every 16 17 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b11 : every 18 19 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b12 : every 20 21 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b13 : every 22 23 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b14 : every 24 26 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b15 : every 27 29 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b16 : every 30 32 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b17 : every 33 35 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b18 : every 36 38 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b19 : every 39 41 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b20 : every 42 45 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b21 : every 46 46 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b22 : every 47 47 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b23 : every 48 48 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b24 : every 49 49 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b25 : every 50 50 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b26 : every 51 51 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b27 : every 52 52 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b28 : every 53 53 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b29 : every 54 54 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b30 : every 55 55 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b31 : every 56 56 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b32 : every 57 57 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b33 : every 58 58 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b34 : every 59 59 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b35 : every 60 60 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
private theorem b36 : every 61 61 (movingRow 839510850509404150095 28113851737989348282 622829946195456331176 3)=true := by decide +kernel
theorem checked : test 13 17 3=true :=
  movingTest (h:=17300831838762675866) (A:=839510850509404150095) (S:=28113851737989348282) (T:=622829946195456331176)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 b3)) (joinEvery (joinEvery b4 b5) (joinEvery b6 (joinEvery b7 b8)))) (joinEvery (joinEvery (joinEvery b9 b10) (joinEvery b11 b12)) (joinEvery (joinEvery b13 b14) (joinEvery b15 (joinEvery b16 b17))))) (joinEvery (joinEvery (joinEvery (joinEvery b18 b19) (joinEvery b20 b21)) (joinEvery (joinEvery b22 b23) (joinEvery b24 (joinEvery b25 b26)))) (joinEvery (joinEvery (joinEvery b27 b28) (joinEvery b29 (joinEvery b30 b31))) (joinEvery (joinEvery b32 b33) (joinEvery b34 (joinEvery b35 b36))))))
#print axioms checked
end OMA.RankThreeAt13E17P3
