import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E23P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 14 28 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b1 : every 29 40 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b2 : every 41 46 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b3 : every 47 54 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b4 : every 55 60 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b5 : every 61 66 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b6 : every 67 70 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b7 : every 71 72 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b8 : every 73 78 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b9 : every 79 82 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b10 : every 83 88 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b11 : every 89 96 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b12 : every 97 100 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b13 : every 101 102 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b14 : every 103 106 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b15 : every 107 108 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b16 : every 109 112 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b17 : every 113 126 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b18 : every 127 130 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b19 : every 131 136 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b20 : every 137 138 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b21 : every 139 148 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b22 : every 149 150 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b23 : every 151 156 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b24 : every 157 162 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b25 : every 163 166 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b26 : every 167 172 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b27 : every 173 178 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
private theorem b28 : every 179 180 (finitePair 188286357654 16592735268260 423644304720 9037745167392 13)=true := by decide +kernel
theorem checked : test 3 23 13=true :=
  fixedTest (h:=188286357654) (A:=16592735268260) (S:=423644304720) (T:=9037745167392)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery b0 (joinEvery b1 b2)) (joinEvery (joinEvery b3 b4) (joinEvery b5 b6))) (joinEvery (joinEvery b7 (joinEvery b8 b9)) (joinEvery (joinEvery b10 b11) (joinEvery b12 b13)))) (joinEvery (joinEvery (joinEvery b14 (joinEvery b15 b16)) (joinEvery (joinEvery b17 b18) (joinEvery b19 b20))) (joinEvery (joinEvery (joinEvery b21 b22) (joinEvery b23 b24)) (joinEvery (joinEvery b25 b26) (joinEvery b27 b28)))))
#print axioms checked
end OMA.RankThreeAt3E23P13
