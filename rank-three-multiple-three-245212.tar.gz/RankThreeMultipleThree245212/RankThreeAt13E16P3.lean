import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt13E16P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 1 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b1 : every 2 2 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b2 : every 3 3 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b3 : every 4 4 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b4 : every 5 6 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b5 : every 7 8 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b6 : every 9 10 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b7 : every 11 12 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b8 : every 13 14 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b9 : every 15 16 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b10 : every 17 18 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b11 : every 19 21 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b12 : every 22 24 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b13 : every 25 27 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b14 : every 28 30 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b15 : every 31 33 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b16 : every 34 36 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b17 : every 37 39 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b18 : every 40 42 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b19 : every 43 46 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b20 : every 47 47 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b21 : every 48 48 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b22 : every 49 49 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b23 : every 50 50 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b24 : every 51 51 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b25 : every 52 52 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b26 : every 53 53 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b27 : every 54 54 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b28 : every 55 55 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b29 : every 56 56 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b30 : every 57 57 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b31 : every 58 58 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b32 : every 59 59 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b33 : every 60 60 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b34 : every 61 61 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b35 : every 62 62 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
private theorem b36 : every 63 63 (movingRow 60973417765083736125 2162603979845334483 45248329424456229188 3)=true := by decide +kernel
theorem checked : test 13 16 3=true :=
  movingTest (h:=1330833218366359682) (A:=60973417765083736125) (S:=2162603979845334483) (T:=45248329424456229188)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 b3)) (joinEvery (joinEvery b4 b5) (joinEvery b6 (joinEvery b7 b8)))) (joinEvery (joinEvery (joinEvery b9 b10) (joinEvery b11 b12)) (joinEvery (joinEvery b13 b14) (joinEvery b15 (joinEvery b16 b17))))) (joinEvery (joinEvery (joinEvery (joinEvery b18 b19) (joinEvery b20 b21)) (joinEvery (joinEvery b22 b23) (joinEvery b24 (joinEvery b25 b26)))) (joinEvery (joinEvery (joinEvery b27 b28) (joinEvery b29 (joinEvery b30 b31))) (joinEvery (joinEvery b32 b33) (joinEvery b34 (joinEvery b35 b36))))))
#print axioms checked
end OMA.RankThreeAt13E16P3
