import RankThreeMiddleBlocks245212
namespace OMA.RankThreeAt3E3P5
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 9 (movingRow 710 120 432 5)=true := by decide +kernel
private theorem b1 : every 10 12 (movingRow 710 120 432 5)=true := by decide +kernel
private theorem b2 : every 13 15 (movingRow 710 120 432 5)=true := by decide +kernel
theorem checked : test 3 3 5=true :=
  movingTest (h:=54) (A:=710) (S:=120) (T:=432)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery b0 (joinEvery b1 b2))
#print axioms checked
end OMA.RankThreeAt3E3P5
