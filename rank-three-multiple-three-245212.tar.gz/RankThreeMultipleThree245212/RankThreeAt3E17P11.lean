import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E17P11
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 5 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b1 : every 6 10 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b2 : every 11 14 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b3 : every 15 18 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b4 : every 19 22 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b5 : every 23 26 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b6 : every 27 30 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b7 : every 31 34 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b8 : every 35 37 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b9 : every 38 38 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b10 : every 39 39 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b11 : every 40 40 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b12 : every 41 41 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b13 : every 42 42 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b14 : every 43 43 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b15 : every 44 44 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b16 : every 45 45 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b17 : every 46 46 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b18 : every 47 47 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b19 : every 48 48 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b20 : every 49 49 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b21 : every 50 50 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b22 : every 51 51 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b23 : every 52 52 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b24 : every 53 53 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b25 : every 54 54 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b26 : every 55 55 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b27 : every 56 56 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b28 : every 57 57 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b29 : every 58 58 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b30 : every 59 59 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b31 : every 60 60 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b32 : every 61 61 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b33 : every 62 62 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b34 : every 63 63 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b35 : every 64 64 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b36 : every 65 65 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b37 : every 66 66 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b38 : every 67 67 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b39 : every 68 68 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
private theorem b40 : every 69 69 (movingRow 16949646395 581130732 9298091736 11)=true := by decide +kernel
theorem checked : test 3 17 11=true :=
  movingTest (h:=258280326) (A:=16949646395) (S:=581130732) (T:=9298091736)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 (joinEvery b3 b4))) (joinEvery (joinEvery b5 b6) (joinEvery b7 (joinEvery b8 b9)))) (joinEvery (joinEvery (joinEvery b10 b11) (joinEvery b12 (joinEvery b13 b14))) (joinEvery (joinEvery b15 b16) (joinEvery b17 (joinEvery b18 b19))))) (joinEvery (joinEvery (joinEvery (joinEvery b20 b21) (joinEvery b22 (joinEvery b23 b24))) (joinEvery (joinEvery b25 b26) (joinEvery b27 (joinEvery b28 b29)))) (joinEvery (joinEvery (joinEvery b30 b31) (joinEvery b32 (joinEvery b33 b34))) (joinEvery (joinEvery b35 (joinEvery b36 b37)) (joinEvery b38 (joinEvery b39 b40))))))
#print axioms checked
end OMA.RankThreeAt3E17P11
