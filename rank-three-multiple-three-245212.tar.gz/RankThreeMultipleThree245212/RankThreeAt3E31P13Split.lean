import RankThreeAt3E31P13SplitPart0
import RankThreeAt3E31P13SplitPart1
import RankThreeAt3E31P13SplitPart2
import RankThreeAt3E31P13SplitPart3
import RankThreeAt3E31P13SplitPart4
import RankThreeAt3E31P13SplitPart5
import RankThreeAt3E31P13SplitPart6
import RankThreeAt3E31P13SplitPart7
import RankThreeAt3E31P13SplitPart8
import RankThreeAt3E31P13SplitPart9
import RankThreeAt3E31P13SplitPart10
import RankThreeAt3E31P13SplitPart11
import RankThreeAt3E31P13SplitPart12
import RankThreeAt3E31P13SplitPart13
import RankThreeAt3E31P13SplitPart14
import RankThreeAt3E31P13SplitPart15
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E31P13Split
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212 OMA.CofactorGuardFast245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
theorem checked : test 3 31 13=true :=
  fixedTest (h:=1235346792567894) (A:=145925339872082480) (S:=2779530283277760) (T:=79062194724345216)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (restore (by decide) (joinEvery (joinEvery (joinEvery (joinEvery OMA.RankThreeAt3E31P13SplitPart0.checked OMA.RankThreeAt3E31P13SplitPart1.checked) (joinEvery OMA.RankThreeAt3E31P13SplitPart2.checked OMA.RankThreeAt3E31P13SplitPart3.checked)) (joinEvery (joinEvery OMA.RankThreeAt3E31P13SplitPart4.checked OMA.RankThreeAt3E31P13SplitPart5.checked) (joinEvery OMA.RankThreeAt3E31P13SplitPart6.checked OMA.RankThreeAt3E31P13SplitPart7.checked))) (joinEvery (joinEvery (joinEvery OMA.RankThreeAt3E31P13SplitPart8.checked OMA.RankThreeAt3E31P13SplitPart9.checked) (joinEvery OMA.RankThreeAt3E31P13SplitPart10.checked OMA.RankThreeAt3E31P13SplitPart11.checked)) (joinEvery (joinEvery OMA.RankThreeAt3E31P13SplitPart12.checked OMA.RankThreeAt3E31P13SplitPart13.checked) (joinEvery OMA.RankThreeAt3E31P13SplitPart14.checked OMA.RankThreeAt3E31P13SplitPart15.checked)))))
#print axioms checked
end OMA.RankThreeAt3E31P13Split
