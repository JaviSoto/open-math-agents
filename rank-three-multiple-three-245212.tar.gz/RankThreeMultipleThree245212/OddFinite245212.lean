import OddPrimeBound245212

/-! Odd solutions with at most four distinct prime factors form a finite set,
with no prescribed set of primes or exponents. -/
namespace OMA.OddFaces245212
open Finset OMA.Smooth245212 OMA.FixedPrimes245212
open scoped ArithmeticFunction.sigma

private theorem tiny {k : ℕ} (p u : Fin k → ℕ) (hu : ∀ i,1<u i) (pu : ∀ i,u i≤p i)
    (cap : 2≤∏ i,limitX (p i)) (small : (∏ i,limitX (u i))<2) : False := by
  have b := prod_le_prod (f:=fun i => limitX (p i)) (g:=fun i => limitX (u i))
    (s:=univ) (fun i _ => x_nonneg ((hu i).trans_le (pu i)) none)
    (fun i _ => cap_anti (hu i) (pu i))
  exact (cap.trans b).not_gt small

private theorem support_bound {k : ℕ} (hk : k≤4) (p e : Fin k → ℕ)
    (hp : ∀ i,Nat.Prime (p i)) (ord : StrictMono p) (odd : ∀ i,3≤p i)
    (positive : ∀ i,0<e i) (eq : OeisA245212.a (total p e)=(σ 1 (total p e):ℤ))
    (i : Fin k) : p i≤primeBound := by
  have norm := normalized_of_eq p hp ord.injective _ eq
  have cap := cap_needed p e (fun j => (hp j).one_lt) i (positive i) norm
  interval_cases k
  · exact Fin.elim0 i
  · exfalso
    exact tiny p ![3] (by decide) (by intro j; fin_cases j; exact odd 0) cap (by decide +kernel)
  · have last : p 1≤threshold := by
      by_contra! h
      have lastBig : 257≤p 1 := by unfold threshold at h; omega
      exact tiny p ![3,257] (by decide) (by intro j; fin_cases j; exact odd 0; exact lastBig)
        cap (by decide +kernel)
    exact (ord.monotone (Fin.le_last i)).trans (last.trans primeBound_ge)
  · have next : 5≤p 1 := by
      have a := odd 0
      have b := ord (by decide : (0:Fin 3)<1)
      have c : p 1≠4 := by intro e; have := hp 1; rw [e] at this; norm_num at this
      omega
    have last : p 2≤threshold := by
      by_contra! h
      have lastBig : 257≤p 2 := by unfold threshold at h; omega
      exact tiny p ![3,5,257] (by decide) (by intro j; fin_cases j; exact odd 0; exact next; exact lastBig)
        cap (by decide +kernel)
    exact (ord.monotone (Fin.le_last i)).trans (last.trans primeBound_ge)
  · exact (ord.monotone (Fin.le_last i)).trans (last_prime_le hp ord (odd 0) positive eq)

theorem odd_support {n : ℕ} (odd : Odd n) (few : n.primeFactors.card≤4)
    (eq : OeisA245212.a n=(σ 1 n:ℤ)) : ∀ p∈n.primeFactors, p≤primeBound := by
  let S := n.primeFactors
  let p := S.orderEmbOfFin rfl
  let e (i : Fin S.card) := n.factorization (p i)
  have mem (i) : p i∈n.primeFactors := orderEmbOfFin_mem S rfl i
  have hp (i) := Nat.prime_of_mem_primeFactors (mem i)
  have op (i) : 3≤p i := by
    have h := (hp i).two_le
    have a := Nat.dvd_of_mem_primeFactors (mem i)
    have non : ¬2∣n := fun d => (Nat.not_even_iff_odd.mpr odd) (even_iff_two_dvd.mpr d)
    by_contra! lt
    have same : p i=2 := by omega
    exact non (same ▸ a)
  have ep (i) : 0<e i := (hp i).factorization_pos_of_dvd odd.pos.ne' (Nat.dvd_of_mem_primeFactors (mem i))
  have repr : total p e=n := by
    unfold total e
    exact (Fintype.prod_equiv (S.orderIsoOfFin rfl).toEquiv _
      (fun j : S => j.val^(n.factorization j.val)) (fun _ => rfl)).trans
      (Nat.prod_primeFactors_coe_pow_factorization odd.pos.ne').symm
  intro q hq
  have image : q∈Set.range p := by rw [show Set.range p=(S:Set ℕ) from range_orderEmbOfFin S rfl]; exact hq
  obtain ⟨i,rfl⟩ := image
  exact support_bound few p e hp p.strictMono op ep (by rw [repr]; exact eq) i

private theorem finite_by_bound (B : ℕ)
    (bound : ∀ n : ℕ, Odd n → n.primeFactors.card≤4 → OeisA245212.a n=(σ 1 n:ℤ) →
      ∀ p∈n.primeFactors,p≤B) : {n : ℕ | Odd n ∧ n.primeFactors.card≤4 ∧
    OeisA245212.a n=(σ 1 n:ℤ)}.Finite := by
  apply (Set.finite_singleton 1 |>.union (OMA.FixedPrimes245212.finite (range (B+1)))).subset
  intro n hn
  obtain ⟨ho,hf,he⟩ := hn
  by_cases one : n=1
  · exact Or.inl one
  · refine Or.inr ⟨ho.pos,fun p hp => mem_range.mpr (Nat.lt_succ_of_le (bound n ho hf he p hp)),he,?_⟩
    rintro ⟨i,rfl⟩
    cases i with
    | zero => simp at one
    | succ j => exact (Nat.not_even_iff_odd.mpr ho) (by simp [pow_succ])

theorem odd_finite : {n : ℕ | Odd n ∧ n.primeFactors.card≤4 ∧
    OeisA245212.a n=(σ 1 n:ℤ)}.Finite :=
  finite_by_bound primeBound (fun _ => odd_support)

end OMA.OddFaces245212
