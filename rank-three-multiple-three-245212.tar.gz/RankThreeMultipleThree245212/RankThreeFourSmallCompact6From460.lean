import RankThreeFourSmallCompact245212
/-! Independently checked consecutive interval for the compressed two-prime decision. -/
namespace OMA.RankThreeFourSmallCompactTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallCompact245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem r6_460_467 : every 460 467 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_468_475 : every 468 475 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_476_483 : every 476 483 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_484_491 : every 484 491 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_492_499 : every 492 499 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_500_507 : every 500 507 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_508_515 : every 508 515 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_516_523 : every 516 523 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_524_531 : every 524 531 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_532_539 : every 532 539 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_540_547 : every 540 547 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_548_555 : every 548 555 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_556_563 : every 556 563 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_564_571 : every 564 571 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_572_579 : every 572 579 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_580_587 : every 580 587 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_588_595 : every 588 595 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_596_603 : every 596 603 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_604_611 : every 604 611 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_612_619 : every 612 619 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_620_627 : every 620 627 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_628_635 : every 628 635 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_636_643 : every 636 643 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_644_651 : every 644 651 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_652_659 : every 652 659 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_660_667 : every 660 667 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_668_675 : every 668 675 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_676_678 : every 676 678 (run 2916 120836 7651 61236)=true := by decide +kernel
theorem span6_460_678 : every 460 678 (run 2916 120836 7651 61236)=true := (joinEvery (joinEvery (joinEvery (joinEvery r6_460_467 (joinEvery r6_468_475 r6_476_483)) (joinEvery (joinEvery r6_484_491 r6_492_499) (joinEvery r6_500_507 r6_508_515))) (joinEvery (joinEvery r6_516_523 (joinEvery r6_524_531 r6_532_539)) (joinEvery (joinEvery r6_540_547 r6_548_555) (joinEvery r6_556_563 r6_564_571)))) (joinEvery (joinEvery (joinEvery r6_572_579 (joinEvery r6_580_587 r6_588_595)) (joinEvery (joinEvery r6_596_603 r6_604_611) (joinEvery r6_612_619 r6_620_627))) (joinEvery (joinEvery r6_628_635 (joinEvery r6_636_643 r6_644_651)) (joinEvery (joinEvery r6_652_659 r6_660_667) (joinEvery r6_668_675 r6_676_678)))))
end OMA.RankThreeFourSmallCompactTables245212
#print axioms OMA.RankThreeFourSmallCompactTables245212.span6_460_678
