import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E35P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 3 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b1 : every 4 6 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b2 : every 7 9 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b3 : every 10 12 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b4 : every 13 15 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b5 : every 16 18 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b6 : every 19 21 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b7 : every 22 24 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b8 : every 25 26 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b9 : every 27 28 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b10 : every 29 30 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b11 : every 31 32 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b12 : every 33 34 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b13 : every 35 36 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b14 : every 37 38 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b15 : every 39 40 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b16 : every 41 42 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b17 : every 43 44 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b18 : every 45 46 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b19 : every 47 48 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b20 : every 49 50 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b21 : every 51 53 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b22 : every 54 54 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b23 : every 55 55 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b24 : every 56 56 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b25 : every 57 57 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b26 : every 58 58 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b27 : every 59 59 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b28 : every 60 60 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b29 : every 61 61 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b30 : every 62 62 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b31 : every 63 63 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b32 : every 64 64 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b33 : every 65 65 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b34 : every 66 66 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b35 : every 67 67 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b36 : every 68 68 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b37 : every 69 69 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b38 : every 70 70 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b39 : every 71 71 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b40 : every 72 72 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b41 : every 73 73 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b42 : every 74 74 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b43 : every 75 75 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b44 : every 76 76 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b45 : every 77 77 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b46 : every 78 78 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b47 : every 79 79 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b48 : every 80 80 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b49 : every 81 81 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b50 : every 82 82 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b51 : every 83 83 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b52 : every 84 84 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b53 : every 85 85 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b54 : every 86 86 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b55 : every 87 87 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b56 : every 88 88 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b57 : every 89 89 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b58 : every 90 90 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b59 : every 91 91 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b60 : every 92 92 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b61 : every 93 93 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b62 : every 94 94 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b63 : every 95 95 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b64 : every 96 96 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b65 : every 97 97 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b66 : every 98 98 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b67 : every 99 99 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b68 : every 100 100 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
private theorem b69 : every 101 101 (movingRow 13320898882608671990 225141952945498680 7204542494255957808 13)=true := by decide +kernel
theorem checked : test 3 35 13=true :=
  movingTest (h:=100063090197999414) (A:=13320898882608671990) (S:=225141952945498680) (T:=7204542494255957808)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 b3)) (joinEvery (joinEvery b4 b5) (joinEvery b6 b7))) (joinEvery (joinEvery (joinEvery b8 b9) (joinEvery b10 b11)) (joinEvery (joinEvery b12 b13) (joinEvery b14 (joinEvery b15 b16))))) (joinEvery (joinEvery (joinEvery (joinEvery b17 b18) (joinEvery b19 b20)) (joinEvery (joinEvery b21 b22) (joinEvery b23 (joinEvery b24 b25)))) (joinEvery (joinEvery (joinEvery b26 b27) (joinEvery b28 b29)) (joinEvery (joinEvery b30 b31) (joinEvery b32 (joinEvery b33 b34)))))) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b35 b36) (joinEvery b37 b38)) (joinEvery (joinEvery b39 b40) (joinEvery b41 b42))) (joinEvery (joinEvery (joinEvery b43 b44) (joinEvery b45 b46)) (joinEvery (joinEvery b47 b48) (joinEvery b49 (joinEvery b50 b51))))) (joinEvery (joinEvery (joinEvery (joinEvery b52 b53) (joinEvery b54 b55)) (joinEvery (joinEvery b56 b57) (joinEvery b58 (joinEvery b59 b60)))) (joinEvery (joinEvery (joinEvery b61 b62) (joinEvery b63 b64)) (joinEvery (joinEvery b65 b66) (joinEvery b67 (joinEvery b68 b69)))))))
#print axioms checked
end OMA.RankThreeAt3E35P13
