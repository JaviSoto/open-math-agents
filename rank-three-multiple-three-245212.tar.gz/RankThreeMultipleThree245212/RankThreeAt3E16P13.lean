import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E16P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 14 28 (finitePair 86093442 5327031725 193710243 2927177028 13)=true := by decide +kernel
private theorem b1 : every 29 36 (finitePair 86093442 5327031725 193710243 2927177028 13)=true := by decide +kernel
private theorem b2 : every 37 40 (finitePair 86093442 5327031725 193710243 2927177028 13)=true := by decide +kernel
private theorem b3 : every 41 42 (finitePair 86093442 5327031725 193710243 2927177028 13)=true := by decide +kernel
private theorem b4 : every 43 46 (finitePair 86093442 5327031725 193710243 2927177028 13)=true := by decide +kernel
private theorem b5 : every 47 52 (finitePair 86093442 5327031725 193710243 2927177028 13)=true := by decide +kernel
private theorem b6 : every 53 58 (finitePair 86093442 5327031725 193710243 2927177028 13)=true := by decide +kernel
private theorem b7 : every 59 60 (finitePair 86093442 5327031725 193710243 2927177028 13)=true := by decide +kernel
private theorem b8 : every 61 66 (finitePair 86093442 5327031725 193710243 2927177028 13)=true := by decide +kernel
private theorem b9 : every 67 70 (finitePair 86093442 5327031725 193710243 2927177028 13)=true := by decide +kernel
theorem checked : test 3 16 13=true :=
  fixedTest (h:=86093442) (A:=5327031725) (S:=193710243) (T:=2927177028)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 (joinEvery b3 b4))) (joinEvery (joinEvery b5 b6) (joinEvery b7 (joinEvery b8 b9))))
#print axioms checked
end OMA.RankThreeAt3E16P13
