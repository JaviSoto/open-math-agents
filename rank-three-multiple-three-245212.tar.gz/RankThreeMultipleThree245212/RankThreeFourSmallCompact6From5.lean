import RankThreeFourSmallCompact245212
/-! Independently checked consecutive interval for the compressed two-prime decision. -/
namespace OMA.RankThreeFourSmallCompactTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallCompact245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem r6_5_12 : every 5 12 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_13_20 : every 13 20 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_21_28 : every 21 28 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_29_36 : every 29 36 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_37_44 : every 37 44 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_45_52 : every 45 52 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_53_60 : every 53 60 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_61_68 : every 61 68 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_69_76 : every 69 76 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_77_84 : every 77 84 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_85_92 : every 85 92 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_93_100 : every 93 100 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_101_108 : every 101 108 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_109_116 : every 109 116 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_117_124 : every 117 124 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_125_132 : every 125 132 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_133_140 : every 133 140 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_141_148 : every 141 148 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_149_156 : every 149 156 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_157_164 : every 157 164 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_165_172 : every 165 172 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_173_180 : every 173 180 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_181_188 : every 181 188 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_189_196 : every 189 196 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_197_204 : every 197 204 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_205_212 : every 205 212 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_213_220 : every 213 220 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_221_228 : every 221 228 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_229_236 : every 229 236 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_237_244 : every 237 244 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_245_252 : every 245 252 (run 2916 120836 7651 61236)=true := by decide +kernel
private theorem r6_253_259 : every 253 259 (run 2916 120836 7651 61236)=true := by decide +kernel
theorem span6_5_259 : every 5 259 (run 2916 120836 7651 61236)=true := (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery r6_5_12 r6_13_20) (joinEvery r6_21_28 r6_29_36)) (joinEvery (joinEvery r6_37_44 r6_45_52) (joinEvery r6_53_60 r6_61_68))) (joinEvery (joinEvery (joinEvery r6_69_76 r6_77_84) (joinEvery r6_85_92 r6_93_100)) (joinEvery (joinEvery r6_101_108 r6_109_116) (joinEvery r6_117_124 r6_125_132)))) (joinEvery (joinEvery (joinEvery (joinEvery r6_133_140 r6_141_148) (joinEvery r6_149_156 r6_157_164)) (joinEvery (joinEvery r6_165_172 r6_173_180) (joinEvery r6_181_188 r6_189_196))) (joinEvery (joinEvery (joinEvery r6_197_204 r6_205_212) (joinEvery r6_213_220 r6_221_228)) (joinEvery (joinEvery r6_229_236 r6_237_244) (joinEvery r6_245_252 r6_253_259)))))
end OMA.RankThreeFourSmallCompactTables245212
#print axioms OMA.RankThreeFourSmallCompactTables245212.span6_5_259
