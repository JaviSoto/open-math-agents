import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E12P11
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 12 27 (finitePair 1062882 49822595 2391483 27634932 11)=true := by decide +kernel
private theorem b1 : every 28 36 (finitePair 1062882 49822595 2391483 27634932 11)=true := by decide +kernel
private theorem b2 : every 37 42 (finitePair 1062882 49822595 2391483 27634932 11)=true := by decide +kernel
private theorem b3 : every 43 46 (finitePair 1062882 49822595 2391483 27634932 11)=true := by decide +kernel
private theorem b4 : every 47 52 (finitePair 1062882 49822595 2391483 27634932 11)=true := by decide +kernel
private theorem b5 : every 53 58 (finitePair 1062882 49822595 2391483 27634932 11)=true := by decide +kernel
private theorem b6 : every 59 62 (finitePair 1062882 49822595 2391483 27634932 11)=true := by decide +kernel
private theorem b7 : every 63 70 (finitePair 1062882 49822595 2391483 27634932 11)=true := by decide +kernel
private theorem b8 : every 71 72 (finitePair 1062882 49822595 2391483 27634932 11)=true := by decide +kernel
private theorem b9 : every 73 78 (finitePair 1062882 49822595 2391483 27634932 11)=true := by decide +kernel
private theorem b10 : every 79 82 (finitePair 1062882 49822595 2391483 27634932 11)=true := by decide +kernel
private theorem b11 : every 83 88 (finitePair 1062882 49822595 2391483 27634932 11)=true := by decide +kernel
private theorem b12 : every 89 96 (finitePair 1062882 49822595 2391483 27634932 11)=true := by decide +kernel
private theorem b13 : every 97 100 (finitePair 1062882 49822595 2391483 27634932 11)=true := by decide +kernel
private theorem b14 : every 101 102 (finitePair 1062882 49822595 2391483 27634932 11)=true := by decide +kernel
private theorem b15 : every 103 106 (finitePair 1062882 49822595 2391483 27634932 11)=true := by decide +kernel
private theorem b16 : every 107 108 (finitePair 1062882 49822595 2391483 27634932 11)=true := by decide +kernel
private theorem b17 : every 109 112 (finitePair 1062882 49822595 2391483 27634932 11)=true := by decide +kernel
private theorem b18 : every 113 118 (finitePair 1062882 49822595 2391483 27634932 11)=true := by decide +kernel
theorem checked : test 3 12 11=true :=
  fixedTest (h:=1062882) (A:=49822595) (S:=2391483) (T:=27634932)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 b3)) (joinEvery (joinEvery b4 b5) (joinEvery b6 (joinEvery b7 b8)))) (joinEvery (joinEvery (joinEvery b9 b10) (joinEvery b11 (joinEvery b12 b13))) (joinEvery (joinEvery b14 b15) (joinEvery b16 (joinEvery b17 b18)))))
#print axioms checked
end OMA.RankThreeAt3E12P11
