import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt5E1P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 10 (movingRow 55 18 40 3)=true := by decide +kernel
private theorem b1 : every 11 16 (movingRow 55 18 40 3)=true := by decide +kernel
private theorem b2 : every 17 19 (movingRow 55 18 40 3)=true := by decide +kernel
private theorem b3 : every 20 21 (movingRow 55 18 40 3)=true := by decide +kernel
private theorem b4 : every 22 22 (movingRow 55 18 40 3)=true := by decide +kernel
theorem checked : test 5 1 3=true :=
  movingTest (h:=10) (A:=55) (S:=18) (T:=40)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery b0 b1) (joinEvery b2 (joinEvery b3 b4)))
#print axioms checked
end OMA.RankThreeAt5E1P3
