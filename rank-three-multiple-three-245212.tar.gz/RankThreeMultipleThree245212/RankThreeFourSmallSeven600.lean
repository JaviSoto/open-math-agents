import RankThreeFourSmallCompact245212
/-! Independently checked consecutive interval for the compressed two-prime decision. -/
namespace OMA.RankThreeFourSmallCompactTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallCompact245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem r7_600_604 : every 600 604 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_605_609 : every 605 609 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_610_614 : every 610 614 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_615_619 : every 615 619 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_620_624 : every 620 624 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_625_629 : every 625 629 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_630_634 : every 630 634 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_635_639 : every 635 639 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_640_644 : every 640 644 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_645_649 : every 645 649 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_650_654 : every 650 654 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_655_659 : every 655 659 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_660_664 : every 660 664 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_665_669 : every 665 669 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_670_674 : every 670 674 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_675_679 : every 675 679 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_680_684 : every 680 684 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_685_689 : every 685 689 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_690_694 : every 690 694 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_695_699 : every 695 699 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_700_704 : every 700 704 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_705_709 : every 705 709 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_710_714 : every 710 714 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_715_719 : every 715 719 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_720_724 : every 720 724 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_725_729 : every 725 729 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_730_734 : every 730 734 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_735_739 : every 735 739 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_740_744 : every 740 744 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_745_749 : every 745 749 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_750_754 : every 750 754 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_755_759 : every 755 759 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_760_764 : every 760 764 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_765_769 : every 765 769 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_770_774 : every 770 774 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_775_779 : every 775 779 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_780_784 : every 780 784 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_785_789 : every 785 789 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_790_794 : every 790 794 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_795_799 : every 795 799 (run 8748 418268 22960 209952)=true := by decide +kernel
theorem span7_600_799 : every 600 799 (run 8748 418268 22960 209952)=true := (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery r7_600_604 r7_605_609) (joinEvery r7_610_614 (joinEvery r7_615_619 r7_620_624))) (joinEvery (joinEvery r7_625_629 r7_630_634) (joinEvery r7_635_639 (joinEvery r7_640_644 r7_645_649)))) (joinEvery (joinEvery (joinEvery r7_650_654 r7_655_659) (joinEvery r7_660_664 (joinEvery r7_665_669 r7_670_674))) (joinEvery (joinEvery r7_675_679 r7_680_684) (joinEvery r7_685_689 (joinEvery r7_690_694 r7_695_699))))) (joinEvery (joinEvery (joinEvery (joinEvery r7_700_704 r7_705_709) (joinEvery r7_710_714 (joinEvery r7_715_719 r7_720_724))) (joinEvery (joinEvery r7_725_729 r7_730_734) (joinEvery r7_735_739 (joinEvery r7_740_744 r7_745_749)))) (joinEvery (joinEvery (joinEvery r7_750_754 r7_755_759) (joinEvery r7_760_764 (joinEvery r7_765_769 r7_770_774))) (joinEvery (joinEvery r7_775_779 r7_780_784) (joinEvery r7_785_789 (joinEvery r7_790_794 r7_795_799))))))
end OMA.RankThreeFourSmallCompactTables245212
#print axioms OMA.RankThreeFourSmallCompactTables245212.span7_600_799
