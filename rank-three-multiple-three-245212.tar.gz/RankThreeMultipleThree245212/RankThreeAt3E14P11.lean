import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E14P11
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 12 28 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b1 : every 29 40 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b2 : every 41 46 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b3 : every 47 56 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b4 : every 57 60 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b5 : every 61 66 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b6 : every 67 70 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b7 : every 71 72 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b8 : every 73 78 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b9 : every 79 82 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b10 : every 83 88 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b11 : every 89 96 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b12 : every 97 100 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b13 : every 101 102 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b14 : every 103 106 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b15 : every 107 108 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b16 : every 109 112 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b17 : every 113 126 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b18 : every 127 130 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b19 : every 131 136 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b20 : every 137 138 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b21 : every 139 148 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b22 : every 149 150 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b23 : every 151 156 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b24 : every 157 162 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b25 : every 163 166 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b26 : every 167 172 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b27 : every 173 178 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b28 : every 179 180 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b29 : every 181 190 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b30 : every 191 192 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b31 : every 193 196 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b32 : every 197 198 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b33 : every 199 210 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b34 : every 211 222 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b35 : every 223 226 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b36 : every 227 228 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b37 : every 229 232 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b38 : every 233 238 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b39 : every 239 240 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b40 : every 241 250 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b41 : every 251 256 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b42 : every 257 262 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b43 : every 263 268 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b44 : every 269 270 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b45 : every 271 276 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b46 : every 277 280 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b47 : every 281 282 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b48 : every 283 292 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b49 : every 293 306 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b50 : every 307 310 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b51 : every 311 312 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b52 : every 313 316 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
private theorem b53 : every 317 320 (finitePair 9565938 520147880 21523359 286978140 11)=true := by decide +kernel
theorem checked : test 3 14 11=true :=
  fixedTest (h:=9565938) (A:=520147880) (S:=21523359) (T:=286978140)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 (joinEvery b1 b2)) (joinEvery b3 (joinEvery b4 b5))) (joinEvery (joinEvery b6 (joinEvery b7 b8)) (joinEvery (joinEvery b9 b10) (joinEvery b11 b12)))) (joinEvery (joinEvery (joinEvery b13 (joinEvery b14 b15)) (joinEvery (joinEvery b16 b17) (joinEvery b18 b19))) (joinEvery (joinEvery b20 (joinEvery b21 b22)) (joinEvery (joinEvery b23 b24) (joinEvery b25 b26))))) (joinEvery (joinEvery (joinEvery (joinEvery b27 (joinEvery b28 b29)) (joinEvery b30 (joinEvery b31 b32))) (joinEvery (joinEvery b33 (joinEvery b34 b35)) (joinEvery (joinEvery b36 b37) (joinEvery b38 b39)))) (joinEvery (joinEvery (joinEvery b40 (joinEvery b41 b42)) (joinEvery (joinEvery b43 b44) (joinEvery b45 b46))) (joinEvery (joinEvery b47 (joinEvery b48 b49)) (joinEvery (joinEvery b50 b51) (joinEvery b52 b53))))))
#print axioms checked
end OMA.RankThreeAt3E14P11
