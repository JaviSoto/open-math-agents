import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E13P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 14 27 (finitePair 3188646 161425205 7174452 89282088 13)=true := by decide +kernel
private theorem b1 : every 28 35 (finitePair 3188646 161425205 7174452 89282088 13)=true := by decide +kernel
private theorem b2 : every 36 41 (finitePair 3188646 161425205 7174452 89282088 13)=true := by decide +kernel
private theorem b3 : every 42 46 (finitePair 3188646 161425205 7174452 89282088 13)=true := by decide +kernel
private theorem b4 : every 47 48 (finitePair 3188646 161425205 7174452 89282088 13)=true := by decide +kernel
theorem checked : test 3 13 13=true :=
  fixedTest (h:=3188646) (A:=161425205) (S:=7174452) (T:=89282088)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery b0 b1) (joinEvery b2 (joinEvery b3 b4)))
#print axioms checked
end OMA.RankThreeAt3E13P13
