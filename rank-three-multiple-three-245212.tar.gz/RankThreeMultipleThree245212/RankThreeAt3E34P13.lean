import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E34P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 3 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b1 : every 4 6 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b2 : every 7 9 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b3 : every 10 12 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b4 : every 13 15 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b5 : every 16 18 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b6 : every 19 21 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b7 : every 22 24 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b8 : every 25 26 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b9 : every 27 28 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b10 : every 29 30 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b11 : every 31 32 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b12 : every 33 34 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b13 : every 35 36 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b14 : every 37 38 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b15 : every 39 40 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b16 : every 41 42 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b17 : every 43 44 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b18 : every 45 46 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b19 : every 47 48 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b20 : every 49 50 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b21 : every 51 52 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b22 : every 53 54 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b23 : every 55 56 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b24 : every 57 58 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b25 : every 59 60 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b26 : every 61 62 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b27 : every 63 64 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b28 : every 65 66 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b29 : every 67 68 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b30 : every 69 70 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b31 : every 71 72 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b32 : every 73 73 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b33 : every 74 74 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b34 : every 75 75 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b35 : every 76 76 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b36 : every 77 77 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b37 : every 78 78 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b38 : every 79 79 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b39 : every 80 80 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b40 : every 81 81 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b41 : every 82 82 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b42 : every 83 83 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b43 : every 84 84 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b44 : every 85 85 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b45 : every 86 86 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b46 : every 87 87 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b47 : every 88 88 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b48 : every 89 89 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b49 : every 90 90 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b50 : every 91 91 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b51 : every 92 92 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b52 : every 93 93 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b53 : every 94 94 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b54 : every 95 95 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b55 : every 96 96 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b56 : every 97 97 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b57 : every 98 98 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b58 : every 99 99 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b59 : every 100 100 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b60 : every 101 101 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b61 : every 102 102 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b62 : every 103 103 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b63 : every 104 104 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b64 : every 105 105 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b65 : every 106 106 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b66 : every 107 107 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b67 : every 108 108 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b68 : every 109 109 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b69 : every 110 110 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b70 : every 111 111 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b71 : every 112 112 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b72 : every 113 113 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b73 : every 114 114 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b74 : every 115 115 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b75 : every 116 116 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b76 : every 117 117 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b77 : every 118 118 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b78 : every 119 119 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b79 : every 120 120 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b80 : every 121 121 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b81 : every 122 122 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b82 : every 123 123 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b83 : every 124 124 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b84 : every 125 125 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b85 : every 126 126 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b86 : every 127 127 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b87 : every 128 128 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b88 : every 129 129 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b89 : every 130 130 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b90 : every 131 131 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b91 : every 132 132 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b92 : every 133 133 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b93 : every 134 134 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b94 : every 135 135 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b95 : every 136 136 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
private theorem b96 : every 137 137 (movingRow 4315220764788724730 75047317648499559 2334805437953319660 13)=true := by decide +kernel
theorem checked : test 3 34 13=true :=
  movingTest (h:=33354363399333138) (A:=4315220764788724730) (S:=75047317648499559) (T:=2334805437953319660)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 (joinEvery b1 b2)) (joinEvery b3 (joinEvery b4 b5))) (joinEvery (joinEvery b6 (joinEvery b7 b8)) (joinEvery b9 (joinEvery b10 b11)))) (joinEvery (joinEvery (joinEvery b12 (joinEvery b13 b14)) (joinEvery b15 (joinEvery b16 b17))) (joinEvery (joinEvery b18 (joinEvery b19 b20)) (joinEvery b21 (joinEvery b22 b23))))) (joinEvery (joinEvery (joinEvery (joinEvery b24 (joinEvery b25 b26)) (joinEvery b27 (joinEvery b28 b29))) (joinEvery (joinEvery b30 (joinEvery b31 b32)) (joinEvery b33 (joinEvery b34 b35)))) (joinEvery (joinEvery (joinEvery b36 (joinEvery b37 b38)) (joinEvery b39 (joinEvery b40 b41))) (joinEvery (joinEvery b42 (joinEvery b43 b44)) (joinEvery b45 (joinEvery b46 b47)))))) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b48 (joinEvery b49 b50)) (joinEvery b51 (joinEvery b52 b53))) (joinEvery (joinEvery b54 (joinEvery b55 b56)) (joinEvery b57 (joinEvery b58 b59)))) (joinEvery (joinEvery (joinEvery b60 (joinEvery b61 b62)) (joinEvery b63 (joinEvery b64 b65))) (joinEvery (joinEvery b66 (joinEvery b67 b68)) (joinEvery b69 (joinEvery b70 b71))))) (joinEvery (joinEvery (joinEvery (joinEvery b72 (joinEvery b73 b74)) (joinEvery b75 (joinEvery b76 b77))) (joinEvery (joinEvery b78 (joinEvery b79 b80)) (joinEvery b81 (joinEvery b82 b83)))) (joinEvery (joinEvery (joinEvery b84 (joinEvery b85 b86)) (joinEvery b87 (joinEvery b88 b89))) (joinEvery (joinEvery b90 (joinEvery b91 b92)) (joinEvery (joinEvery b93 b94) (joinEvery b95 b96)))))))
#print axioms checked
end OMA.RankThreeAt3E34P13
