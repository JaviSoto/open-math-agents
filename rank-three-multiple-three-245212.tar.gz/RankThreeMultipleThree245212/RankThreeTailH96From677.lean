import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_677_0 : every 678 84 (quick 96 2247 252 1152 677)=true := by decide +kernel
private theorem b96_677_1 : every 1 25 (far 96 2247 252 1152 677 678 18)=true := by decide +kernel
private theorem b96_677_2 : every 26 50 (far 96 2247 252 1152 677 678 18)=true := by decide +kernel
private theorem b96_677_3 : every 51 75 (far 96 2247 252 1152 677 678 18)=true := by decide +kernel
private theorem b96_677_4 : every 76 100 (far 96 2247 252 1152 677 678 18)=true := by decide +kernel
private theorem b96_677_5 : every 101 125 (far 96 2247 252 1152 677 678 18)=true := by decide +kernel
private theorem b96_677_6 : every 126 150 (far 96 2247 252 1152 677 678 18)=true := by decide +kernel
private theorem b96_677_7 : every 151 153 (far 96 2247 252 1152 677 678 18)=true := by decide +kernel
private theorem r96_677 : every 677 677 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 677=true := by change (every 678 84 (quick 96 2247 252 1152 677) && every 1 153 (far 96 2247 252 1152 677 678 18))=true; rw [Bool.and_eq_true]; exact ⟨b96_677_0,(joinEvery (joinEvery b96_677_1 (joinEvery b96_677_2 b96_677_3)) (joinEvery (joinEvery b96_677_4 b96_677_5) (joinEvery b96_677_6 b96_677_7)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=677 by omega] using yes
private theorem b96_677_8 : every 678 682 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_677_9 : every 684 84 (quick 96 2247 252 1152 683)=true := by decide +kernel
private theorem b96_677_10 : every 1 25 (far 96 2247 252 1152 683 684 18)=true := by decide +kernel
private theorem b96_677_11 : every 26 50 (far 96 2247 252 1152 683 684 18)=true := by decide +kernel
private theorem b96_677_12 : every 51 75 (far 96 2247 252 1152 683 684 18)=true := by decide +kernel
private theorem b96_677_13 : every 76 100 (far 96 2247 252 1152 683 684 18)=true := by decide +kernel
private theorem b96_677_14 : every 101 125 (far 96 2247 252 1152 683 684 18)=true := by decide +kernel
private theorem b96_677_15 : every 126 150 (far 96 2247 252 1152 683 684 18)=true := by decide +kernel
private theorem b96_677_16 : every 151 154 (far 96 2247 252 1152 683 684 18)=true := by decide +kernel
private theorem r96_683 : every 683 683 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 683=true := by change (every 684 84 (quick 96 2247 252 1152 683) && every 1 154 (far 96 2247 252 1152 683 684 18))=true; rw [Bool.and_eq_true]; exact ⟨b96_677_9,(joinEvery (joinEvery b96_677_10 (joinEvery b96_677_11 b96_677_12)) (joinEvery (joinEvery b96_677_13 b96_677_14) (joinEvery b96_677_15 b96_677_16)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=683 by omega] using yes
private theorem b96_677_17 : every 684 690 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_677_18 : every 692 84 (quick 96 2247 252 1152 691)=true := by decide +kernel
private theorem b96_677_19 : every 1 25 (far 96 2247 252 1152 691 692 18)=true := by decide +kernel
private theorem b96_677_20 : every 26 50 (far 96 2247 252 1152 691 692 18)=true := by decide +kernel
private theorem b96_677_21 : every 51 75 (far 96 2247 252 1152 691 692 18)=true := by decide +kernel
private theorem b96_677_22 : every 76 100 (far 96 2247 252 1152 691 692 18)=true := by decide +kernel
private theorem b96_677_23 : every 101 125 (far 96 2247 252 1152 691 692 18)=true := by decide +kernel
private theorem b96_677_24 : every 126 150 (far 96 2247 252 1152 691 692 18)=true := by decide +kernel
private theorem b96_677_25 : every 151 156 (far 96 2247 252 1152 691 692 18)=true := by decide +kernel
private theorem r96_691 : every 691 691 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 691=true := by change (every 692 84 (quick 96 2247 252 1152 691) && every 1 156 (far 96 2247 252 1152 691 692 18))=true; rw [Bool.and_eq_true]; exact ⟨b96_677_18,(joinEvery (joinEvery b96_677_19 (joinEvery b96_677_20 b96_677_21)) (joinEvery (joinEvery b96_677_22 b96_677_23) (joinEvery b96_677_24 b96_677_25)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=691 by omega] using yes
private theorem b96_677_26 : every 692 698 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_677_698 : every 677 698 (run 96 2247 252 1152)=true := (joinEvery (joinEvery r96_677 (joinEvery b96_677_8 r96_683)) (joinEvery b96_677_17 (joinEvery r96_691 b96_677_26)))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_677_698
