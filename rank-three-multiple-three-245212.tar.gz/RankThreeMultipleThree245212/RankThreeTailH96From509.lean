import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_509_0 : every 510 86 (quick 96 2247 252 1152 509)=true := by decide +kernel
private theorem b96_509_1 : every 1 25 (far 96 2247 252 1152 509 510 19)=true := by decide +kernel
private theorem b96_509_2 : every 26 50 (far 96 2247 252 1152 509 510 19)=true := by decide +kernel
private theorem b96_509_3 : every 51 75 (far 96 2247 252 1152 509 510 19)=true := by decide +kernel
private theorem b96_509_4 : every 76 100 (far 96 2247 252 1152 509 510 19)=true := by decide +kernel
private theorem b96_509_5 : every 101 115 (far 96 2247 252 1152 509 510 19)=true := by decide +kernel
private theorem r96_509 : every 509 509 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 509=true := by change (every 510 86 (quick 96 2247 252 1152 509) && every 1 115 (far 96 2247 252 1152 509 510 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_509_0,(joinEvery (joinEvery b96_509_1 b96_509_2) (joinEvery b96_509_3 (joinEvery b96_509_4 b96_509_5)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=509 by omega] using yes
private theorem b96_509_6 : every 510 520 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_509_7 : every 522 86 (quick 96 2247 252 1152 521)=true := by decide +kernel
private theorem b96_509_8 : every 1 25 (far 96 2247 252 1152 521 522 19)=true := by decide +kernel
private theorem b96_509_9 : every 26 50 (far 96 2247 252 1152 521 522 19)=true := by decide +kernel
private theorem b96_509_10 : every 51 75 (far 96 2247 252 1152 521 522 19)=true := by decide +kernel
private theorem b96_509_11 : every 76 100 (far 96 2247 252 1152 521 522 19)=true := by decide +kernel
private theorem b96_509_12 : every 101 118 (far 96 2247 252 1152 521 522 19)=true := by decide +kernel
private theorem r96_521 : every 521 521 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 521=true := by change (every 522 86 (quick 96 2247 252 1152 521) && every 1 118 (far 96 2247 252 1152 521 522 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_509_7,(joinEvery (joinEvery b96_509_8 b96_509_9) (joinEvery b96_509_10 (joinEvery b96_509_11 b96_509_12)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=521 by omega] using yes
private theorem b96_509_13 : every 522 522 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_509_14 : every 524 86 (quick 96 2247 252 1152 523)=true := by decide +kernel
private theorem b96_509_15 : every 1 25 (far 96 2247 252 1152 523 524 19)=true := by decide +kernel
private theorem b96_509_16 : every 26 50 (far 96 2247 252 1152 523 524 19)=true := by decide +kernel
private theorem b96_509_17 : every 51 75 (far 96 2247 252 1152 523 524 19)=true := by decide +kernel
private theorem b96_509_18 : every 76 100 (far 96 2247 252 1152 523 524 19)=true := by decide +kernel
private theorem b96_509_19 : every 101 119 (far 96 2247 252 1152 523 524 19)=true := by decide +kernel
private theorem r96_523 : every 523 523 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 523=true := by change (every 524 86 (quick 96 2247 252 1152 523) && every 1 119 (far 96 2247 252 1152 523 524 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_509_14,(joinEvery (joinEvery b96_509_15 b96_509_16) (joinEvery b96_509_17 (joinEvery b96_509_18 b96_509_19)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=523 by omega] using yes
private theorem b96_509_20 : every 524 532 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_509_532 : every 509 532 (run 96 2247 252 1152)=true := (joinEvery (joinEvery r96_509 (joinEvery b96_509_6 r96_521)) (joinEvery b96_509_13 (joinEvery r96_523 b96_509_20)))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_509_532
