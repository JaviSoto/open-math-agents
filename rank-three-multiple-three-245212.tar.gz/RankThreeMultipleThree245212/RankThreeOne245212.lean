import RankThreeCap245212
import GuardedHeight245212

/-! At dyadic exponent one there is no solution with three distinct odd
primes all at least five. The Euler cap leaves 5,7,11. For that support
the height bound and the three one-factor caps make rounding simultaneous. -/
namespace OMA.RankThreeOne245212
open Finset Nat OMA.Smooth245212 OMA.OddFaces245212 OMA.Height245212
open OMA.RankThreeCap245212
open scoped ArithmeticFunction.sigma

private theorem cut {p q r a t : ℕ} (hp : 1<p) (hq : 1<q) (hr : 1<r)
    (h : 8≤5*X p (some a)*(limitX q*limitX r))
    (small : 5*X p (some t)*(limitX q*limitX r)<8) : t<a := by
  by_contra! le
  have rat : (1:ℚ)<p := by exact_mod_cast hp
  have x : X p (some a)≤X p (some t) := by
    unfold X
    gcongr
    exact y_anti hp le
  have m := mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left x (by decide : (0:ℚ)≤5))
    (mul_nonneg (x_nonneg hq none) (x_nonneg hr none))
  exact small.not_ge (h.trans m)

theorem fixed {a b c : ℕ} (ap : 0<a) (bp : 0<b) (cp : 0<c) :
    OeisA245212.a (2*5^a*7^b*11^c)≠(σ 1 (2*5^a*7^b*11^c):ℤ) := by
  intro eq
  have n := OMA.RankThreeCap245212.norm (by decide : Nat.Prime 5) (by decide : Nat.Prime 7)
    (by decide : Nat.Prime 11) (by decide) (by decide) (by decide) eq
  have aa : 59<a := cut (by decide : 1<5) (by decide : 1<7) (by decide : 1<11)
    (one_cap (by decide) (by decide) (by decide) bp n) (by decide +kernel)
  have bb : 44<b := cut (by decide : 1<7) (by decide : 1<5) (by decide : 1<11)
    (one_cap (by decide) (by decide) (by decide) ap (by convert n using 1; ring)) (by decide +kernel)
  have cc : 29<c := cut (by decide : 1<11) (by decide : 1<5) (by decide : 1<7)
    (one_cap (by decide) (by decide) (by decide) ap (by convert n using 1; ring)) (by decide +kernel)
  let P : Fin 4 → ℕ := ![2,5,7,11]
  let E : Fin 4 → ℕ := ![1,a,b,c]
  have pr (i : Fin 4) : (P i).Prime := by fin_cases i <;> decide
  have distinct : P.Injective := by intro i j hit; fin_cases i <;> fin_cases j <;> simp_all [P]
  have pos (i : Fin 4) : 0<E i := by fin_cases i <;> simp [E,ap,bp,cp]
  have prime_bound (i : Fin 4) : P i≤11 := by fin_cases i <;> decide
  have two (i : Fin 4) : P i=2 → P i^E i ≤ 11^(2*11) := by fin_cases i <;> simp [P,E]
  have repr : total P E=2*5^a*7^b*11^c := by simp [total,Fin.prod_univ_four,P,E,mul_assoc]
  have bal := normalized_of_eq P pr distinct E (repr ▸ eq)
  have height := OMA.GuardedHeight245212.max_power P E pr two pos distinct prime_bound (repr ▸ eq)
  have top : univ.sup E≤3000 := (OMA.HeightLog245212.four
    (lt_of_lt_of_le (pos 0) (le_sup (f:=E) (mem_univ 0))) height).trans (by decide +kernel)
  have be (i : Fin 4) : E i≤3000 := (le_sup (f:=E) (mem_univ i)).trans top
  let S : Finset (Fin 4) := {1,2,3}
  have out : outside P E S=2 := by simp [outside,Fin.prod_univ_four,P,E,S]
  have large (i : Fin 4) (hi : i∈S) : coefficientBound 11 3000*outside P E S<P i^E i := by
    rw [out]; fin_cases i
    · simp [S] at hi
    · exact lt_of_lt_of_le (by decide +kernel : coefficientBound 11 3000*2<5^60) (Nat.pow_le_pow_right (by decide) aa)
    · exact lt_of_lt_of_le (by decide +kernel : coefficientBound 11 3000*2<7^45) (Nat.pow_le_pow_right (by decide) bb)
    · exact lt_of_lt_of_le (by decide +kernel : coefficientBound 11 3000*2<11^30) (Nat.pow_le_pow_right (by decide) cc)
  have same := gap_eq P E pr pos S bal (enough P E pr prime_bound be S large)
  have ctl {i j : Fin 4} (eb : 29<E j) : ((P i:ℚ)-1)*yr (P j) (E j)<1 := by
    have h := (y_range (pr j).one_lt (pos j)).2.2
    have r : (P i : ℚ) ≤11 := by exact_mod_cast prime_bound i
    have low : (29:ℚ)<E j := by exact_mod_cast eb
    have yy := (y_range (pr j).one_lt (pos j)).1
    nlinarith only [h, yy, mul_nonneg (sub_nonneg.mpr r) yy, mul_nonneg (sub_nonneg.mpr low.le) yy]
  have signs (i : Fin 4) (_ : i∈S) : ∃ j, j≠i ∧ ((P i:ℚ)-1)*yr (P j) (E j)<1 := by
    by_cases one : i=1
    · exact ⟨2,by simp [one],ctl (show 29<E 2 from by simpa [E] using (show 29<b by omega))⟩
    · exact ⟨1,Ne.symm one,ctl (show 29<E 1 from by simpa [E] using (show 29<a by omega))⟩
  have strict := strict_rounding P E (fun i=>(pr i).one_lt) pos S (by decide) signs
  linarith

theorem no_least_ge_five {p q r a b c : ℕ} (hp : p.Prime) (hq : q.Prime) (hr : r.Prime)
    (least : 5≤p) (pq : p<q) (qr : q<r) (ap : 0<a) (bp : 0<b) (cp : 0<c) :
    OeisA245212.a (2*p^a*q^b*r^c)≠(σ 1 (2*p^a*q^b*r^c):ℤ) := by
  intro hit
  have n := OMA.RankThreeCap245212.norm hp hq hr (by omega) pq qr hit
  obtain ⟨rfl,rfl,rfl⟩ := ordered hp hq hr least pq qr (caps hp.one_lt hq.one_lt hr.one_lt ap n)
  exact fixed ap bp cp hit
end OMA.RankThreeOne245212
