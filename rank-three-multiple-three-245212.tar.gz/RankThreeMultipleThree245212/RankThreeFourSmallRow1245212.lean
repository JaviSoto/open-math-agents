import RankThreeFourSmallOriginal245212
/-! Certified prime and exponent intervals for one power of three. -/
namespace OMA.RankThreeFourSmallTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallDecision245212
open OMA.RankThreeFourSmallOriginal245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem c1_0 : every 1 11 (movingRow 119 28 72 5)=true := by decide +kernel
private theorem c1_1 : every 12 12 (movingRow 119 28 72 5)=true := by decide +kernel
private theorem p1_5 : every 5 5 (atPrime 12 119 28 72)=true := by
  have localTest : atPrime 12 119 28 72 5=true := (joinEvery c1_0 c1_1)
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=5 by omega] using localTest
private theorem c1_2 : every 6 6 (atPrime 12 119 28 72)=true := by decide +kernel
private theorem c1_3 : every 8 30 (fixedPair 12 119 28 72 7)=true := by decide +kernel
private theorem c1_4 : every 31 54 (fixedPair 12 119 28 72 7)=true := by decide +kernel
private theorem c1_5 : every 1 21 (moving 55 4 119 28 72 7)=true := by decide +kernel
private theorem p1_7 : every 7 7 (atPrime 12 119 28 72)=true := by
  have localTest : atPrime 12 119 28 72 7=true := by change (every 8 54 (fixedPair 12 119 28 72 7) && every 1 21 (moving 55 4 119 28 72 7)) = true; rw [Bool.and_eq_true]; exact ⟨(joinEvery c1_3 c1_4),c1_5⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=7 by omega] using localTest
private theorem c1_6 : every 8 10 (atPrime 12 119 28 72)=true := by decide +kernel
private theorem c1_7 : every 12 20 (fixedPair 12 119 28 72 11)=true := by decide +kernel
private theorem c1_8 : every 1 8 (moving 21 6 119 28 72 11)=true := by decide +kernel
private theorem p1_11 : every 11 11 (atPrime 12 119 28 72)=true := by
  have localTest : atPrime 12 119 28 72 11=true := by change (every 12 20 (fixedPair 12 119 28 72 11) && every 1 8 (moving 21 6 119 28 72 11)) = true; rw [Bool.and_eq_true]; exact ⟨c1_7,c1_8⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=11 by omega] using localTest
private theorem c1_9 : every 12 12 (atPrime 12 119 28 72)=true := by decide +kernel
private theorem c1_10 : every 14 18 (fixedPair 12 119 28 72 13)=true := by decide +kernel
private theorem c1_11 : every 1 7 (moving 19 7 119 28 72 13)=true := by decide +kernel
private theorem p1_13 : every 13 13 (atPrime 12 119 28 72)=true := by
  have localTest : atPrime 12 119 28 72 13=true := by change (every 14 18 (fixedPair 12 119 28 72 13) && every 1 7 (moving 19 7 119 28 72 13)) = true; rw [Bool.and_eq_true]; exact ⟨c1_10,c1_11⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=13 by omega] using localTest
private theorem c1_12 : every 14 16 (atPrime 12 119 28 72)=true := by decide +kernel
theorem at1 : cert 1=true := (joinEvery (joinEvery (joinEvery p1_5 c1_2) (joinEvery p1_7 c1_6)) (joinEvery (joinEvery p1_11 c1_9) (joinEvery p1_13 c1_12)))
end OMA.RankThreeFourSmallTables245212
#print axioms OMA.RankThreeFourSmallTables245212.at1
