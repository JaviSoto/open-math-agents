import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_437_0 : every 437 438 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_437_1 : every 440 87 (quick 96 2247 252 1152 439)=true := by decide +kernel
private theorem b96_437_2 : every 1 25 (far 96 2247 252 1152 439 440 19)=true := by decide +kernel
private theorem b96_437_3 : every 26 50 (far 96 2247 252 1152 439 440 19)=true := by decide +kernel
private theorem b96_437_4 : every 51 75 (far 96 2247 252 1152 439 440 19)=true := by decide +kernel
private theorem b96_437_5 : every 76 100 (far 96 2247 252 1152 439 440 19)=true := by decide +kernel
private theorem r96_439 : every 439 439 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 439=true := by change (every 440 87 (quick 96 2247 252 1152 439) && every 1 100 (far 96 2247 252 1152 439 440 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_437_1,(joinEvery (joinEvery b96_437_2 b96_437_3) (joinEvery b96_437_4 b96_437_5))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=439 by omega] using yes
private theorem b96_437_6 : every 440 442 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_437_7 : every 444 87 (quick 96 2247 252 1152 443)=true := by decide +kernel
private theorem b96_437_8 : every 1 25 (far 96 2247 252 1152 443 444 19)=true := by decide +kernel
private theorem b96_437_9 : every 26 50 (far 96 2247 252 1152 443 444 19)=true := by decide +kernel
private theorem b96_437_10 : every 51 75 (far 96 2247 252 1152 443 444 19)=true := by decide +kernel
private theorem b96_437_11 : every 76 100 (far 96 2247 252 1152 443 444 19)=true := by decide +kernel
private theorem b96_437_12 : every 101 101 (far 96 2247 252 1152 443 444 19)=true := by decide +kernel
private theorem r96_443 : every 443 443 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 443=true := by change (every 444 87 (quick 96 2247 252 1152 443) && every 1 101 (far 96 2247 252 1152 443 444 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_437_7,(joinEvery (joinEvery b96_437_8 b96_437_9) (joinEvery b96_437_10 (joinEvery b96_437_11 b96_437_12)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=443 by omega] using yes
private theorem b96_437_13 : every 444 448 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_437_14 : every 450 87 (quick 96 2247 252 1152 449)=true := by decide +kernel
private theorem b96_437_15 : every 1 25 (far 96 2247 252 1152 449 450 19)=true := by decide +kernel
private theorem b96_437_16 : every 26 50 (far 96 2247 252 1152 449 450 19)=true := by decide +kernel
private theorem b96_437_17 : every 51 75 (far 96 2247 252 1152 449 450 19)=true := by decide +kernel
private theorem b96_437_18 : every 76 100 (far 96 2247 252 1152 449 450 19)=true := by decide +kernel
private theorem b96_437_19 : every 101 102 (far 96 2247 252 1152 449 450 19)=true := by decide +kernel
private theorem r96_449 : every 449 449 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 449=true := by change (every 450 87 (quick 96 2247 252 1152 449) && every 1 102 (far 96 2247 252 1152 449 450 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_437_14,(joinEvery (joinEvery b96_437_15 b96_437_16) (joinEvery b96_437_17 (joinEvery b96_437_18 b96_437_19)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=449 by omega] using yes
private theorem b96_437_20 : every 450 456 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_437_21 : every 458 87 (quick 96 2247 252 1152 457)=true := by decide +kernel
private theorem b96_437_22 : every 1 25 (far 96 2247 252 1152 457 458 19)=true := by decide +kernel
private theorem b96_437_23 : every 26 50 (far 96 2247 252 1152 457 458 19)=true := by decide +kernel
private theorem b96_437_24 : every 51 75 (far 96 2247 252 1152 457 458 19)=true := by decide +kernel
private theorem b96_437_25 : every 76 100 (far 96 2247 252 1152 457 458 19)=true := by decide +kernel
private theorem b96_437_26 : every 101 104 (far 96 2247 252 1152 457 458 19)=true := by decide +kernel
private theorem r96_457 : every 457 457 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 457=true := by change (every 458 87 (quick 96 2247 252 1152 457) && every 1 104 (far 96 2247 252 1152 457 458 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_437_21,(joinEvery (joinEvery b96_437_22 b96_437_23) (joinEvery b96_437_24 (joinEvery b96_437_25 b96_437_26)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=457 by omega] using yes
private theorem b96_437_27 : every 458 460 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_437_460 : every 437 460 (run 96 2247 252 1152)=true := (joinEvery (joinEvery (joinEvery b96_437_0 r96_439) (joinEvery b96_437_6 r96_443)) (joinEvery (joinEvery b96_437_13 r96_449) (joinEvery b96_437_20 (joinEvery r96_457 b96_437_27))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_437_460
