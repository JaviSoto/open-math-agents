import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E9P11
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 12 22 (finitePair 39366 1402415 88572 787320 11)=true := by decide +kernel
private theorem b1 : every 23 30 (finitePair 39366 1402415 88572 787320 11)=true := by decide +kernel
private theorem b2 : every 31 40 (finitePair 39366 1402415 88572 787320 11)=true := by decide +kernel
private theorem b3 : every 41 46 (finitePair 39366 1402415 88572 787320 11)=true := by decide +kernel
private theorem b4 : every 47 49 (finitePair 39366 1402415 88572 787320 11)=true := by decide +kernel
theorem checked : test 3 9 11=true :=
  fixedTest (h:=39366) (A:=1402415) (S:=88572) (T:=787320)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery b0 b1) (joinEvery b2 (joinEvery b3 b4)))
#print axioms checked
end OMA.RankThreeAt3E9P11
