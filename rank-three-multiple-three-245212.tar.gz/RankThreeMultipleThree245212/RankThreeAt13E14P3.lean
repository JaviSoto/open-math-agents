import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt13E14P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 1 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b1 : every 2 2 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b2 : every 3 3 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b3 : every 4 5 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b4 : every 6 7 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b5 : every 8 9 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b6 : every 10 11 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b7 : every 12 13 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b8 : every 14 16 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b9 : every 17 19 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b10 : every 20 22 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b11 : every 23 25 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b12 : every 26 28 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b13 : every 29 31 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b14 : every 32 34 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b15 : every 35 37 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b16 : every 38 40 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b17 : every 41 43 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b18 : every 44 46 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b19 : every 47 49 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b20 : every 50 50 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b21 : every 51 51 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b22 : every 52 52 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b23 : every 53 53 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b24 : every 54 54 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b25 : every 55 55 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b26 : every 56 56 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b27 : every 57 57 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b28 : every 58 58 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b29 : every 59 59 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b30 : every 60 60 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b31 : every 61 61 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b32 : every 62 62 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b33 : every 63 63 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b34 : every 64 64 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b35 : every 65 65 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b36 : every 66 66 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
private theorem b37 : every 67 67 (movingRow 318134543386189080 12796473253522689 236242583141957340 3)=true := by decide +kernel
theorem checked : test 13 14 3=true :=
  movingTest (h:=7874752771398578) (A:=318134543386189080) (S:=12796473253522689) (T:=236242583141957340)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 b3)) (joinEvery (joinEvery b4 b5) (joinEvery b6 (joinEvery b7 b8)))) (joinEvery (joinEvery (joinEvery b9 b10) (joinEvery b11 (joinEvery b12 b13))) (joinEvery (joinEvery b14 b15) (joinEvery b16 (joinEvery b17 b18))))) (joinEvery (joinEvery (joinEvery (joinEvery b19 b20) (joinEvery b21 b22)) (joinEvery (joinEvery b23 b24) (joinEvery b25 (joinEvery b26 b27)))) (joinEvery (joinEvery (joinEvery b28 b29) (joinEvery b30 (joinEvery b31 b32))) (joinEvery (joinEvery b33 b34) (joinEvery b35 (joinEvery b36 b37))))))
#print axioms checked
end OMA.RankThreeAt13E14P3
