import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_53_0 : every 54 218 (quick 96 2247 252 1152 53)=true := by decide +kernel
private theorem b96_53_1 : every 219 333 (quick 96 2247 252 1152 53)=true := by decide +kernel
private theorem b96_53_2 : every 1 13 (far 96 2247 252 1152 53 334 73)=true := by decide +kernel
private theorem r96_53 : every 53 53 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 53=true := by change (every 54 333 (quick 96 2247 252 1152 53) && every 1 13 (far 96 2247 252 1152 53 334 73))=true; rw [Bool.and_eq_true]; exact ⟨(joinEvery b96_53_0 b96_53_1),b96_53_2⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=53 by omega] using yes
private theorem b96_53_3 : every 54 58 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_53_4 : every 60 196 (quick 96 2247 252 1152 59)=true := by decide +kernel
private theorem b96_53_5 : every 197 251 (quick 96 2247 252 1152 59)=true := by decide +kernel
private theorem b96_53_6 : every 1 15 (far 96 2247 252 1152 59 252 55)=true := by decide +kernel
private theorem r96_59 : every 59 59 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 59=true := by change (every 60 251 (quick 96 2247 252 1152 59) && every 1 15 (far 96 2247 252 1152 59 252 55))=true; rw [Bool.and_eq_true]; exact ⟨(joinEvery b96_53_4 b96_53_5),b96_53_6⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=59 by omega] using yes
private theorem b96_53_7 : every 60 60 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_53_8 : every 62 196 (quick 96 2247 252 1152 61)=true := by decide +kernel
private theorem b96_53_9 : every 197 234 (quick 96 2247 252 1152 61)=true := by decide +kernel
private theorem b96_53_10 : every 1 15 (far 96 2247 252 1152 61 235 51)=true := by decide +kernel
private theorem r96_61 : every 61 61 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 61=true := by change (every 62 234 (quick 96 2247 252 1152 61) && every 1 15 (far 96 2247 252 1152 61 235 51))=true; rw [Bool.and_eq_true]; exact ⟨(joinEvery b96_53_8 b96_53_9),b96_53_10⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=61 by omega] using yes
private theorem b96_53_11 : every 62 66 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_53_12 : every 68 190 (quick 96 2247 252 1152 67)=true := by decide +kernel
private theorem b96_53_13 : every 191 199 (quick 96 2247 252 1152 67)=true := by decide +kernel
private theorem b96_53_14 : every 1 16 (far 96 2247 252 1152 67 200 43)=true := by decide +kernel
private theorem r96_67 : every 67 67 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 67=true := by change (every 68 199 (quick 96 2247 252 1152 67) && every 1 16 (far 96 2247 252 1152 67 200 43))=true; rw [Bool.and_eq_true]; exact ⟨(joinEvery b96_53_12 b96_53_13),b96_53_14⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=67 by omega] using yes
private theorem b96_53_15 : every 68 70 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_53_16 : every 72 180 (quick 96 2247 252 1152 71)=true := by decide +kernel
private theorem b96_53_17 : every 181 184 (quick 96 2247 252 1152 71)=true := by decide +kernel
private theorem b96_53_18 : every 1 17 (far 96 2247 252 1152 71 185 40)=true := by decide +kernel
private theorem r96_71 : every 71 71 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 71=true := by change (every 72 184 (quick 96 2247 252 1152 71) && every 1 17 (far 96 2247 252 1152 71 185 40))=true; rw [Bool.and_eq_true]; exact ⟨(joinEvery b96_53_16 b96_53_17),b96_53_18⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=71 by omega] using yes
private theorem b96_53_19 : every 72 72 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_53_20 : every 74 177 (quick 96 2247 252 1152 73)=true := by decide +kernel
private theorem b96_53_21 : every 1 18 (far 96 2247 252 1152 73 178 39)=true := by decide +kernel
private theorem r96_73 : every 73 73 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 73=true := by change (every 74 177 (quick 96 2247 252 1152 73) && every 1 18 (far 96 2247 252 1152 73 178 39))=true; rw [Bool.and_eq_true]; exact ⟨b96_53_20,b96_53_21⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=73 by omega] using yes
private theorem b96_53_22 : every 74 76 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_53_76 : every 53 76 (run 96 2247 252 1152)=true := (joinEvery (joinEvery (joinEvery r96_53 (joinEvery b96_53_3 r96_59)) (joinEvery b96_53_7 (joinEvery r96_61 b96_53_11))) (joinEvery (joinEvery r96_67 (joinEvery b96_53_15 r96_71)) (joinEvery b96_53_19 (joinEvery r96_73 b96_53_22))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_53_76
