import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt11E7P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 3 (movingRow 846717580 64307664 623589472 3)=true := by decide +kernel
private theorem b1 : every 4 6 (movingRow 846717580 64307664 623589472 3)=true := by decide +kernel
private theorem b2 : every 7 10 (movingRow 846717580 64307664 623589472 3)=true := by decide +kernel
private theorem b3 : every 11 15 (movingRow 846717580 64307664 623589472 3)=true := by decide +kernel
private theorem b4 : every 16 20 (movingRow 846717580 64307664 623589472 3)=true := by decide +kernel
private theorem b5 : every 21 26 (movingRow 846717580 64307664 623589472 3)=true := by decide +kernel
private theorem b6 : every 27 27 (movingRow 846717580 64307664 623589472 3)=true := by decide +kernel
private theorem b7 : every 28 28 (movingRow 846717580 64307664 623589472 3)=true := by decide +kernel
private theorem b8 : every 29 29 (movingRow 846717580 64307664 623589472 3)=true := by decide +kernel
private theorem b9 : every 30 30 (movingRow 846717580 64307664 623589472 3)=true := by decide +kernel
private theorem b10 : every 31 31 (movingRow 846717580 64307664 623589472 3)=true := by decide +kernel
private theorem b11 : every 32 32 (movingRow 846717580 64307664 623589472 3)=true := by decide +kernel
private theorem b12 : every 33 33 (movingRow 846717580 64307664 623589472 3)=true := by decide +kernel
private theorem b13 : every 34 34 (movingRow 846717580 64307664 623589472 3)=true := by decide +kernel
private theorem b14 : every 35 35 (movingRow 846717580 64307664 623589472 3)=true := by decide +kernel
private theorem b15 : every 36 36 (movingRow 846717580 64307664 623589472 3)=true := by decide +kernel
theorem checked : test 11 7 3=true :=
  movingTest (h:=38974342) (A:=846717580) (S:=64307664) (T:=623589472)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 b3)) (joinEvery (joinEvery b4 b5) (joinEvery b6 b7))) (joinEvery (joinEvery (joinEvery b8 b9) (joinEvery b10 b11)) (joinEvery (joinEvery b12 b13) (joinEvery b14 b15))))
#print axioms checked
end OMA.RankThreeAt11E7P3
