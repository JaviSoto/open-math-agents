import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E15P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 14 28 (finitePair 28697814 1668060440 64570080 918330048 13)=true := by decide +kernel
private theorem b1 : every 29 36 (finitePair 28697814 1668060440 64570080 918330048 13)=true := by decide +kernel
private theorem b2 : every 37 40 (finitePair 28697814 1668060440 64570080 918330048 13)=true := by decide +kernel
private theorem b3 : every 41 44 (finitePair 28697814 1668060440 64570080 918330048 13)=true := by decide +kernel
private theorem b4 : every 45 52 (finitePair 28697814 1668060440 64570080 918330048 13)=true := by decide +kernel
private theorem b5 : every 53 58 (finitePair 28697814 1668060440 64570080 918330048 13)=true := by decide +kernel
private theorem b6 : every 59 60 (finitePair 28697814 1668060440 64570080 918330048 13)=true := by decide +kernel
private theorem b7 : every 61 62 (finitePair 28697814 1668060440 64570080 918330048 13)=true := by decide +kernel
theorem checked : test 3 15 13=true :=
  fixedTest (h:=28697814) (A:=1668060440) (S:=64570080) (T:=918330048)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 b3)) (joinEvery (joinEvery b4 b5) (joinEvery b6 b7)))
#print axioms checked
end OMA.RankThreeAt3E15P13
