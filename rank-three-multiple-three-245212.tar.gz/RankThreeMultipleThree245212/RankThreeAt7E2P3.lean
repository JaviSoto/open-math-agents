import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt7E2P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 8 (movingRow 810 171 588 3)=true := by decide +kernel
private theorem b1 : every 9 15 (movingRow 810 171 588 3)=true := by decide +kernel
private theorem b2 : every 16 17 (movingRow 810 171 588 3)=true := by decide +kernel
private theorem b3 : every 18 19 (movingRow 810 171 588 3)=true := by decide +kernel
private theorem b4 : every 20 20 (movingRow 810 171 588 3)=true := by decide +kernel
theorem checked : test 7 2 3=true :=
  movingTest (h:=98) (A:=810) (S:=171) (T:=588)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery b0 b1) (joinEvery b2 (joinEvery b3 b4)))
#print axioms checked
end OMA.RankThreeAt7E2P3
