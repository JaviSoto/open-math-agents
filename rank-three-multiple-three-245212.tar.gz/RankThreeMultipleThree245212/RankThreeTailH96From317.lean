import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_317_0 : every 318 91 (quick 96 2247 252 1152 317)=true := by decide +kernel
private theorem b96_317_1 : every 1 25 (far 96 2247 252 1152 317 318 20)=true := by decide +kernel
private theorem b96_317_2 : every 26 50 (far 96 2247 252 1152 317 318 20)=true := by decide +kernel
private theorem b96_317_3 : every 51 72 (far 96 2247 252 1152 317 318 20)=true := by decide +kernel
private theorem r96_317 : every 317 317 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 317=true := by change (every 318 91 (quick 96 2247 252 1152 317) && every 1 72 (far 96 2247 252 1152 317 318 20))=true; rw [Bool.and_eq_true]; exact ⟨b96_317_0,(joinEvery b96_317_1 (joinEvery b96_317_2 b96_317_3))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=317 by omega] using yes
private theorem b96_317_4 : every 318 330 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_317_5 : every 332 90 (quick 96 2247 252 1152 331)=true := by decide +kernel
private theorem b96_317_6 : every 1 25 (far 96 2247 252 1152 331 332 20)=true := by decide +kernel
private theorem b96_317_7 : every 26 50 (far 96 2247 252 1152 331 332 20)=true := by decide +kernel
private theorem b96_317_8 : every 51 75 (far 96 2247 252 1152 331 332 20)=true := by decide +kernel
private theorem b96_317_9 : every 76 76 (far 96 2247 252 1152 331 332 20)=true := by decide +kernel
private theorem r96_331 : every 331 331 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 331=true := by change (every 332 90 (quick 96 2247 252 1152 331) && every 1 76 (far 96 2247 252 1152 331 332 20))=true; rw [Bool.and_eq_true]; exact ⟨b96_317_5,(joinEvery (joinEvery b96_317_6 b96_317_7) (joinEvery b96_317_8 b96_317_9))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=331 by omega] using yes
private theorem b96_317_10 : every 332 336 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_317_11 : every 338 90 (quick 96 2247 252 1152 337)=true := by decide +kernel
private theorem b96_317_12 : every 1 25 (far 96 2247 252 1152 337 338 20)=true := by decide +kernel
private theorem b96_317_13 : every 26 50 (far 96 2247 252 1152 337 338 20)=true := by decide +kernel
private theorem b96_317_14 : every 51 75 (far 96 2247 252 1152 337 338 20)=true := by decide +kernel
private theorem b96_317_15 : every 76 77 (far 96 2247 252 1152 337 338 20)=true := by decide +kernel
private theorem r96_337 : every 337 337 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 337=true := by change (every 338 90 (quick 96 2247 252 1152 337) && every 1 77 (far 96 2247 252 1152 337 338 20))=true; rw [Bool.and_eq_true]; exact ⟨b96_317_11,(joinEvery (joinEvery b96_317_12 b96_317_13) (joinEvery b96_317_14 b96_317_15))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=337 by omega] using yes
private theorem b96_317_16 : every 338 340 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_317_340 : every 317 340 (run 96 2247 252 1152)=true := (joinEvery (joinEvery r96_317 (joinEvery b96_317_4 r96_331)) (joinEvery b96_317_10 (joinEvery r96_337 b96_317_16)))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_317_340
