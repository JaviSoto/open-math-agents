import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_533_0 : every 533 540 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_533_1 : every 542 86 (quick 96 2247 252 1152 541)=true := by decide +kernel
private theorem b96_533_2 : every 1 25 (far 96 2247 252 1152 541 542 19)=true := by decide +kernel
private theorem b96_533_3 : every 26 50 (far 96 2247 252 1152 541 542 19)=true := by decide +kernel
private theorem b96_533_4 : every 51 75 (far 96 2247 252 1152 541 542 19)=true := by decide +kernel
private theorem b96_533_5 : every 76 100 (far 96 2247 252 1152 541 542 19)=true := by decide +kernel
private theorem b96_533_6 : every 101 123 (far 96 2247 252 1152 541 542 19)=true := by decide +kernel
private theorem r96_541 : every 541 541 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 541=true := by change (every 542 86 (quick 96 2247 252 1152 541) && every 1 123 (far 96 2247 252 1152 541 542 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_533_1,(joinEvery (joinEvery b96_533_2 b96_533_3) (joinEvery b96_533_4 (joinEvery b96_533_5 b96_533_6)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=541 by omega] using yes
private theorem b96_533_7 : every 542 546 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_533_8 : every 548 86 (quick 96 2247 252 1152 547)=true := by decide +kernel
private theorem b96_533_9 : every 1 25 (far 96 2247 252 1152 547 548 19)=true := by decide +kernel
private theorem b96_533_10 : every 26 50 (far 96 2247 252 1152 547 548 19)=true := by decide +kernel
private theorem b96_533_11 : every 51 75 (far 96 2247 252 1152 547 548 19)=true := by decide +kernel
private theorem b96_533_12 : every 76 100 (far 96 2247 252 1152 547 548 19)=true := by decide +kernel
private theorem b96_533_13 : every 101 124 (far 96 2247 252 1152 547 548 19)=true := by decide +kernel
private theorem r96_547 : every 547 547 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 547=true := by change (every 548 86 (quick 96 2247 252 1152 547) && every 1 124 (far 96 2247 252 1152 547 548 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_533_8,(joinEvery (joinEvery b96_533_9 b96_533_10) (joinEvery b96_533_11 (joinEvery b96_533_12 b96_533_13)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=547 by omega] using yes
private theorem b96_533_14 : every 548 556 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_533_556 : every 533 556 (run 96 2247 252 1152)=true := (joinEvery (joinEvery b96_533_0 r96_541) (joinEvery b96_533_7 (joinEvery r96_547 b96_533_14)))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_533_556
