import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_173_0 : every 174 103 (quick 96 2247 252 1152 173)=true := by decide +kernel
private theorem b96_173_1 : every 1 25 (far 96 2247 252 1152 173 174 22)=true := by decide +kernel
private theorem b96_173_2 : every 26 40 (far 96 2247 252 1152 173 174 22)=true := by decide +kernel
private theorem r96_173 : every 173 173 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 173=true := by change (every 174 103 (quick 96 2247 252 1152 173) && every 1 40 (far 96 2247 252 1152 173 174 22))=true; rw [Bool.and_eq_true]; exact ⟨b96_173_0,(joinEvery b96_173_1 b96_173_2)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=173 by omega] using yes
private theorem b96_173_3 : every 174 178 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_173_4 : every 180 102 (quick 96 2247 252 1152 179)=true := by decide +kernel
private theorem b96_173_5 : every 1 25 (far 96 2247 252 1152 179 180 22)=true := by decide +kernel
private theorem b96_173_6 : every 26 41 (far 96 2247 252 1152 179 180 22)=true := by decide +kernel
private theorem r96_179 : every 179 179 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 179=true := by change (every 180 102 (quick 96 2247 252 1152 179) && every 1 41 (far 96 2247 252 1152 179 180 22))=true; rw [Bool.and_eq_true]; exact ⟨b96_173_4,(joinEvery b96_173_5 b96_173_6)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=179 by omega] using yes
private theorem b96_173_7 : every 180 180 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_173_8 : every 182 102 (quick 96 2247 252 1152 181)=true := by decide +kernel
private theorem b96_173_9 : every 1 25 (far 96 2247 252 1152 181 182 22)=true := by decide +kernel
private theorem b96_173_10 : every 26 42 (far 96 2247 252 1152 181 182 22)=true := by decide +kernel
private theorem r96_181 : every 181 181 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 181=true := by change (every 182 102 (quick 96 2247 252 1152 181) && every 1 42 (far 96 2247 252 1152 181 182 22))=true; rw [Bool.and_eq_true]; exact ⟨b96_173_8,(joinEvery b96_173_9 b96_173_10)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=181 by omega] using yes
private theorem b96_173_11 : every 182 190 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_173_12 : every 192 101 (quick 96 2247 252 1152 191)=true := by decide +kernel
private theorem b96_173_13 : every 1 25 (far 96 2247 252 1152 191 192 22)=true := by decide +kernel
private theorem b96_173_14 : every 26 44 (far 96 2247 252 1152 191 192 22)=true := by decide +kernel
private theorem r96_191 : every 191 191 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 191=true := by change (every 192 101 (quick 96 2247 252 1152 191) && every 1 44 (far 96 2247 252 1152 191 192 22))=true; rw [Bool.and_eq_true]; exact ⟨b96_173_12,(joinEvery b96_173_13 b96_173_14)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=191 by omega] using yes
private theorem b96_173_15 : every 192 192 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_173_16 : every 194 100 (quick 96 2247 252 1152 193)=true := by decide +kernel
private theorem b96_173_17 : every 1 25 (far 96 2247 252 1152 193 194 22)=true := by decide +kernel
private theorem b96_173_18 : every 26 45 (far 96 2247 252 1152 193 194 22)=true := by decide +kernel
private theorem r96_193 : every 193 193 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 193=true := by change (every 194 100 (quick 96 2247 252 1152 193) && every 1 45 (far 96 2247 252 1152 193 194 22))=true; rw [Bool.and_eq_true]; exact ⟨b96_173_16,(joinEvery b96_173_17 b96_173_18)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=193 by omega] using yes
private theorem b96_173_19 : every 194 196 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_173_196 : every 173 196 (run 96 2247 252 1152)=true := (joinEvery (joinEvery (joinEvery r96_173 b96_173_3) (joinEvery r96_179 (joinEvery b96_173_7 r96_181))) (joinEvery (joinEvery b96_173_11 r96_191) (joinEvery b96_173_15 (joinEvery r96_193 b96_173_19))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_173_196
