import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E21P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 14 28 (finitePair 20920706406 1686731953985 47071589412 920511081864 13)=true := by decide +kernel
private theorem b1 : every 29 36 (finitePair 20920706406 1686731953985 47071589412 920511081864 13)=true := by decide +kernel
private theorem b2 : every 37 42 (finitePair 20920706406 1686731953985 47071589412 920511081864 13)=true := by decide +kernel
private theorem b3 : every 43 50 (finitePair 20920706406 1686731953985 47071589412 920511081864 13)=true := by decide +kernel
private theorem b4 : every 51 58 (finitePair 20920706406 1686731953985 47071589412 920511081864 13)=true := by decide +kernel
private theorem b5 : every 59 60 (finitePair 20920706406 1686731953985 47071589412 920511081864 13)=true := by decide +kernel
private theorem b6 : every 61 66 (finitePair 20920706406 1686731953985 47071589412 920511081864 13)=true := by decide +kernel
private theorem b7 : every 67 70 (finitePair 20920706406 1686731953985 47071589412 920511081864 13)=true := by decide +kernel
private theorem b8 : every 71 72 (finitePair 20920706406 1686731953985 47071589412 920511081864 13)=true := by decide +kernel
private theorem b9 : every 73 78 (finitePair 20920706406 1686731953985 47071589412 920511081864 13)=true := by decide +kernel
private theorem b10 : every 79 82 (finitePair 20920706406 1686731953985 47071589412 920511081864 13)=true := by decide +kernel
private theorem b11 : every 83 88 (finitePair 20920706406 1686731953985 47071589412 920511081864 13)=true := by decide +kernel
private theorem b12 : every 89 96 (finitePair 20920706406 1686731953985 47071589412 920511081864 13)=true := by decide +kernel
private theorem b13 : every 97 100 (finitePair 20920706406 1686731953985 47071589412 920511081864 13)=true := by decide +kernel
private theorem b14 : every 101 102 (finitePair 20920706406 1686731953985 47071589412 920511081864 13)=true := by decide +kernel
private theorem b15 : every 103 106 (finitePair 20920706406 1686731953985 47071589412 920511081864 13)=true := by decide +kernel
private theorem b16 : every 107 108 (finitePair 20920706406 1686731953985 47071589412 920511081864 13)=true := by decide +kernel
private theorem b17 : every 109 112 (finitePair 20920706406 1686731953985 47071589412 920511081864 13)=true := by decide +kernel
private theorem b18 : every 113 126 (finitePair 20920706406 1686731953985 47071589412 920511081864 13)=true := by decide +kernel
private theorem b19 : every 127 130 (finitePair 20920706406 1686731953985 47071589412 920511081864 13)=true := by decide +kernel
private theorem b20 : every 131 134 (finitePair 20920706406 1686731953985 47071589412 920511081864 13)=true := by decide +kernel
theorem checked : test 3 21 13=true :=
  fixedTest (h:=20920706406) (A:=1686731953985) (S:=47071589412) (T:=920511081864)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 (joinEvery b3 b4))) (joinEvery (joinEvery b5 b6) (joinEvery b7 (joinEvery b8 b9)))) (joinEvery (joinEvery (joinEvery b10 b11) (joinEvery b12 (joinEvery b13 b14))) (joinEvery (joinEvery b15 (joinEvery b16 b17)) (joinEvery b18 (joinEvery b19 b20)))))
#print axioms checked
end OMA.RankThreeAt3E21P13
