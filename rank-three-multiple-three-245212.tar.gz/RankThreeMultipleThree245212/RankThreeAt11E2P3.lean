import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt11E2P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 4 16 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b1 : every 17 18 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b2 : every 19 22 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b3 : every 23 28 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b4 : every 29 30 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b5 : every 31 36 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b6 : every 37 40 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b7 : every 41 42 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b8 : every 43 46 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b9 : every 47 52 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b10 : every 53 58 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b11 : every 59 60 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b12 : every 61 66 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b13 : every 67 70 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b14 : every 71 72 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b15 : every 73 78 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b16 : every 79 82 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b17 : every 83 88 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b18 : every 89 96 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b19 : every 97 100 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b20 : every 101 102 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b21 : every 103 106 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b22 : every 107 108 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b23 : every 109 112 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b24 : every 113 124 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b25 : every 125 130 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b26 : every 131 134 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b27 : every 135 136 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b28 : every 137 138 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b29 : every 139 140 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b30 : every 141 148 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b31 : every 149 149 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b32 : every 150 150 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b33 : every 151 151 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b34 : every 152 156 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b35 : every 157 157 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b36 : every 158 162 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b37 : every 163 163 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b38 : every 164 166 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b39 : every 167 167 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b40 : every 168 172 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b41 : every 173 173 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b42 : every 174 178 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b43 : every 179 179 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b44 : every 180 180 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b45 : every 181 181 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b46 : every 182 190 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b47 : every 191 191 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b48 : every 192 192 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b49 : every 193 193 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b50 : every 194 196 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b51 : every 197 197 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b52 : every 198 198 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b53 : every 199 199 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b54 : every 200 210 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b55 : every 211 211 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b56 : every 212 222 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b57 : every 223 223 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b58 : every 224 226 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b59 : every 227 227 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b60 : every 228 228 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b61 : every 229 229 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b62 : every 230 232 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b63 : every 233 233 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b64 : every 234 238 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b65 : every 239 239 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b66 : every 240 240 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b67 : every 241 241 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b68 : every 242 250 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b69 : every 251 251 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b70 : every 252 256 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b71 : every 257 257 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b72 : every 258 262 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b73 : every 263 263 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b74 : every 264 268 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b75 : every 269 269 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b76 : every 270 270 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b77 : every 271 271 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b78 : every 272 276 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b79 : every 277 277 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b80 : every 278 280 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b81 : every 281 281 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b82 : every 282 282 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b83 : every 283 283 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b84 : every 284 292 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b85 : every 293 293 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b86 : every 294 306 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b87 : every 307 307 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b88 : every 308 310 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b89 : every 311 311 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b90 : every 312 312 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b91 : every 313 313 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b92 : every 314 316 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b93 : every 317 317 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
private theorem b94 : every 318 322 (finitePair 242 1930 399 1452 3)=true := by decide +kernel
theorem checked : test 11 2 3=true :=
  fixedTest (h:=242) (A:=1930) (S:=399) (T:=1452)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 (joinEvery b3 b4))) (joinEvery (joinEvery b5 (joinEvery b6 b7)) (joinEvery b8 (joinEvery b9 b10)))) (joinEvery (joinEvery (joinEvery b11 (joinEvery b12 b13)) (joinEvery b14 (joinEvery b15 b16))) (joinEvery (joinEvery b17 (joinEvery b18 b19)) (joinEvery b20 (joinEvery b21 b22))))) (joinEvery (joinEvery (joinEvery (joinEvery b23 (joinEvery b24 b25)) (joinEvery b26 (joinEvery b27 b28))) (joinEvery (joinEvery b29 (joinEvery b30 b31)) (joinEvery b32 (joinEvery b33 b34)))) (joinEvery (joinEvery (joinEvery b35 (joinEvery b36 b37)) (joinEvery b38 (joinEvery b39 b40))) (joinEvery (joinEvery b41 (joinEvery b42 b43)) (joinEvery b44 (joinEvery b45 b46)))))) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b47 (joinEvery b48 b49)) (joinEvery b50 (joinEvery b51 b52))) (joinEvery (joinEvery b53 (joinEvery b54 b55)) (joinEvery b56 (joinEvery b57 b58)))) (joinEvery (joinEvery (joinEvery b59 (joinEvery b60 b61)) (joinEvery b62 (joinEvery b63 b64))) (joinEvery (joinEvery b65 (joinEvery b66 b67)) (joinEvery b68 (joinEvery b69 b70))))) (joinEvery (joinEvery (joinEvery (joinEvery b71 (joinEvery b72 b73)) (joinEvery b74 (joinEvery b75 b76))) (joinEvery (joinEvery b77 (joinEvery b78 b79)) (joinEvery b80 (joinEvery b81 b82)))) (joinEvery (joinEvery (joinEvery b83 (joinEvery b84 b85)) (joinEvery b86 (joinEvery b87 b88))) (joinEvery (joinEvery b89 (joinEvery b90 b91)) (joinEvery b92 (joinEvery b93 b94)))))))
#print axioms checked
end OMA.RankThreeAt11E2P3
