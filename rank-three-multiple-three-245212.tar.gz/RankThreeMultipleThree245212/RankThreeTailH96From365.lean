import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_365_0 : every 365 366 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_365_1 : every 368 89 (quick 96 2247 252 1152 367)=true := by decide +kernel
private theorem b96_365_2 : every 1 25 (far 96 2247 252 1152 367 368 19)=true := by decide +kernel
private theorem b96_365_3 : every 26 50 (far 96 2247 252 1152 367 368 19)=true := by decide +kernel
private theorem b96_365_4 : every 51 75 (far 96 2247 252 1152 367 368 19)=true := by decide +kernel
private theorem b96_365_5 : every 76 84 (far 96 2247 252 1152 367 368 19)=true := by decide +kernel
private theorem r96_367 : every 367 367 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 367=true := by change (every 368 89 (quick 96 2247 252 1152 367) && every 1 84 (far 96 2247 252 1152 367 368 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_365_1,(joinEvery (joinEvery b96_365_2 b96_365_3) (joinEvery b96_365_4 b96_365_5))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=367 by omega] using yes
private theorem b96_365_6 : every 368 372 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_365_7 : every 374 89 (quick 96 2247 252 1152 373)=true := by decide +kernel
private theorem b96_365_8 : every 1 25 (far 96 2247 252 1152 373 374 19)=true := by decide +kernel
private theorem b96_365_9 : every 26 50 (far 96 2247 252 1152 373 374 19)=true := by decide +kernel
private theorem b96_365_10 : every 51 75 (far 96 2247 252 1152 373 374 19)=true := by decide +kernel
private theorem b96_365_11 : every 76 85 (far 96 2247 252 1152 373 374 19)=true := by decide +kernel
private theorem r96_373 : every 373 373 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 373=true := by change (every 374 89 (quick 96 2247 252 1152 373) && every 1 85 (far 96 2247 252 1152 373 374 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_365_7,(joinEvery (joinEvery b96_365_8 b96_365_9) (joinEvery b96_365_10 b96_365_11))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=373 by omega] using yes
private theorem b96_365_12 : every 374 378 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_365_13 : every 380 89 (quick 96 2247 252 1152 379)=true := by decide +kernel
private theorem b96_365_14 : every 1 25 (far 96 2247 252 1152 379 380 19)=true := by decide +kernel
private theorem b96_365_15 : every 26 50 (far 96 2247 252 1152 379 380 19)=true := by decide +kernel
private theorem b96_365_16 : every 51 75 (far 96 2247 252 1152 379 380 19)=true := by decide +kernel
private theorem b96_365_17 : every 76 86 (far 96 2247 252 1152 379 380 19)=true := by decide +kernel
private theorem r96_379 : every 379 379 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 379=true := by change (every 380 89 (quick 96 2247 252 1152 379) && every 1 86 (far 96 2247 252 1152 379 380 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_365_13,(joinEvery (joinEvery b96_365_14 b96_365_15) (joinEvery b96_365_16 b96_365_17))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=379 by omega] using yes
private theorem b96_365_18 : every 380 382 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_365_19 : every 384 89 (quick 96 2247 252 1152 383)=true := by decide +kernel
private theorem b96_365_20 : every 1 25 (far 96 2247 252 1152 383 384 19)=true := by decide +kernel
private theorem b96_365_21 : every 26 50 (far 96 2247 252 1152 383 384 19)=true := by decide +kernel
private theorem b96_365_22 : every 51 75 (far 96 2247 252 1152 383 384 19)=true := by decide +kernel
private theorem b96_365_23 : every 76 87 (far 96 2247 252 1152 383 384 19)=true := by decide +kernel
private theorem r96_383 : every 383 383 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 383=true := by change (every 384 89 (quick 96 2247 252 1152 383) && every 1 87 (far 96 2247 252 1152 383 384 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_365_19,(joinEvery (joinEvery b96_365_20 b96_365_21) (joinEvery b96_365_22 b96_365_23))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=383 by omega] using yes
private theorem b96_365_24 : every 384 388 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_365_388 : every 365 388 (run 96 2247 252 1152)=true := (joinEvery (joinEvery (joinEvery b96_365_0 r96_367) (joinEvery b96_365_6 r96_373)) (joinEvery (joinEvery b96_365_12 r96_379) (joinEvery b96_365_18 (joinEvery r96_383 b96_365_24))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_365_388
