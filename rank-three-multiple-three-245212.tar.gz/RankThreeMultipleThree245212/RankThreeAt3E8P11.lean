import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E8P11
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 12 22 (finitePair 13122 418265 29523 236196 11)=true := by decide +kernel
private theorem b1 : every 23 30 (finitePair 13122 418265 29523 236196 11)=true := by decide +kernel
private theorem b2 : every 31 38 (finitePair 13122 418265 29523 236196 11)=true := by decide +kernel
theorem checked : test 3 8 11=true :=
  fixedTest (h:=13122) (A:=418265) (S:=29523) (T:=236196)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery b0 (joinEvery b1 b2))
#print axioms checked
end OMA.RankThreeAt3E8P11
