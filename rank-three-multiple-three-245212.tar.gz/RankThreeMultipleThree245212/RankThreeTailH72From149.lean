import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b72_149_0 : every 150 67 (quick 72 1666 195 864 149)=true := by decide +kernel
private theorem b72_149_1 : every 1 25 (far 72 1666 195 864 149 150 15)=true := by decide +kernel
private theorem b72_149_2 : every 26 36 (far 72 1666 195 864 149 150 15)=true := by decide +kernel
private theorem r72_149 : every 149 149 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 149=true := by change (every 150 67 (quick 72 1666 195 864 149) && every 1 36 (far 72 1666 195 864 149 150 15))=true; rw [Bool.and_eq_true]; exact ⟨b72_149_0,(joinEvery b72_149_1 b72_149_2)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=149 by omega] using yes
private theorem b72_149_3 : every 150 150 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_149_4 : every 152 66 (quick 72 1666 195 864 151)=true := by decide +kernel
private theorem b72_149_5 : every 1 25 (far 72 1666 195 864 151 152 15)=true := by decide +kernel
private theorem b72_149_6 : every 26 37 (far 72 1666 195 864 151 152 15)=true := by decide +kernel
private theorem r72_151 : every 151 151 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 151=true := by change (every 152 66 (quick 72 1666 195 864 151) && every 1 37 (far 72 1666 195 864 151 152 15))=true; rw [Bool.and_eq_true]; exact ⟨b72_149_4,(joinEvery b72_149_5 b72_149_6)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=151 by omega] using yes
private theorem b72_149_7 : every 152 156 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_149_8 : every 158 66 (quick 72 1666 195 864 157)=true := by decide +kernel
private theorem b72_149_9 : every 1 25 (far 72 1666 195 864 157 158 15)=true := by decide +kernel
private theorem b72_149_10 : every 26 38 (far 72 1666 195 864 157 158 15)=true := by decide +kernel
private theorem r72_157 : every 157 157 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 157=true := by change (every 158 66 (quick 72 1666 195 864 157) && every 1 38 (far 72 1666 195 864 157 158 15))=true; rw [Bool.and_eq_true]; exact ⟨b72_149_8,(joinEvery b72_149_9 b72_149_10)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=157 by omega] using yes
private theorem b72_149_11 : every 158 162 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_149_12 : every 164 65 (quick 72 1666 195 864 163)=true := by decide +kernel
private theorem b72_149_13 : every 1 25 (far 72 1666 195 864 163 164 15)=true := by decide +kernel
private theorem b72_149_14 : every 26 39 (far 72 1666 195 864 163 164 15)=true := by decide +kernel
private theorem r72_163 : every 163 163 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 163=true := by change (every 164 65 (quick 72 1666 195 864 163) && every 1 39 (far 72 1666 195 864 163 164 15))=true; rw [Bool.and_eq_true]; exact ⟨b72_149_12,(joinEvery b72_149_13 b72_149_14)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=163 by omega] using yes
private theorem b72_149_15 : every 164 166 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_149_16 : every 168 65 (quick 72 1666 195 864 167)=true := by decide +kernel
private theorem b72_149_17 : every 1 25 (far 72 1666 195 864 167 168 15)=true := by decide +kernel
private theorem b72_149_18 : every 26 40 (far 72 1666 195 864 167 168 15)=true := by decide +kernel
private theorem r72_167 : every 167 167 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 167=true := by change (every 168 65 (quick 72 1666 195 864 167) && every 1 40 (far 72 1666 195 864 167 168 15))=true; rw [Bool.and_eq_true]; exact ⟨b72_149_16,(joinEvery b72_149_17 b72_149_18)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=167 by omega] using yes
private theorem b72_149_19 : every 168 172 (run 72 1666 195 864)=true := by decide +kernel
theorem span72_149_172 : every 149 172 (run 72 1666 195 864)=true := (joinEvery (joinEvery (joinEvery r72_149 b72_149_3) (joinEvery r72_151 (joinEvery b72_149_7 r72_157))) (joinEvery (joinEvery b72_149_11 r72_163) (joinEvery b72_149_15 (joinEvery r72_167 b72_149_19))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span72_149_172
