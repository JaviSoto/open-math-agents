import RankThreeFourSmallOriginal245212
/-! Certified prime and exponent intervals for one power of three. -/
namespace OMA.RankThreeFourSmallTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallDecision245212
open OMA.RankThreeFourSmallOriginal245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000
private theorem c3_0 : every 1 2 (movingRow 2414 280 1296 5)=true := by decide +kernel
private theorem p3_5 : every 5 5 (atPrime 108 2414 280 1296)=true := by
  have localTest : atPrime 108 2414 280 1296 5=true := c3_0
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=5 by omega] using localTest
private theorem c3_1 : every 6 6 (atPrime 108 2414 280 1296)=true := by decide +kernel
private theorem c3_2 : every 1 3 (movingRow 2414 280 1296 7)=true := by decide +kernel
private theorem p3_7 : every 7 7 (atPrime 108 2414 280 1296)=true := by
  have localTest : atPrime 108 2414 280 1296 7=true := c3_2
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=7 by omega] using localTest
private theorem c3_3 : every 8 10 (atPrime 108 2414 280 1296)=true := by decide +kernel
private theorem c3_4 : every 1 7 (movingRow 2414 280 1296 11)=true := by decide +kernel
private theorem p3_11 : every 11 11 (atPrime 108 2414 280 1296)=true := by
  have localTest : atPrime 108 2414 280 1296 11=true := c3_4
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=11 by omega] using localTest
private theorem c3_5 : every 12 12 (atPrime 108 2414 280 1296)=true := by decide +kernel
private theorem c3_6 : every 1 11 (movingRow 2414 280 1296 13)=true := by decide +kernel
private theorem c3_7 : every 12 16 (movingRow 2414 280 1296 13)=true := by decide +kernel
private theorem c3_8 : every 17 17 (movingRow 2414 280 1296 13)=true := by decide +kernel
private theorem p3_13 : every 13 13 (atPrime 108 2414 280 1296)=true := by
  have localTest : atPrime 108 2414 280 1296 13=true := (joinEvery c3_6 (joinEvery c3_7 c3_8))
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=13 by omega] using localTest
private theorem c3_9 : every 14 16 (atPrime 108 2414 280 1296)=true := by decide +kernel
private theorem c3_10 : every 18 42 (fixedPair 108 2414 280 1296 17)=true := by decide +kernel
private theorem c3_11 : every 43 70 (fixedPair 108 2414 280 1296 17)=true := by decide +kernel
private theorem c3_12 : every 71 100 (fixedPair 108 2414 280 1296 17)=true := by decide +kernel
private theorem c3_13 : every 101 130 (fixedPair 108 2414 280 1296 17)=true := by decide +kernel
private theorem c3_14 : every 131 160 (fixedPair 108 2414 280 1296 17)=true := by decide +kernel
private theorem c3_15 : every 161 190 (fixedPair 108 2414 280 1296 17)=true := by decide +kernel
private theorem c3_16 : every 1 40 (moving 191 5 2414 280 1296 17)=true := by decide +kernel
private theorem c3_17 : every 41 41 (moving 191 5 2414 280 1296 17)=true := by decide +kernel
private theorem p3_17 : every 17 17 (atPrime 108 2414 280 1296)=true := by
  have localTest : atPrime 108 2414 280 1296 17=true := by change (every 18 190 (fixedPair 108 2414 280 1296 17) && every 1 41 (moving 191 5 2414 280 1296 17)) = true; rw [Bool.and_eq_true]; exact ⟨(joinEvery (joinEvery c3_10 (joinEvery c3_11 c3_12)) (joinEvery c3_13 (joinEvery c3_14 c3_15))),(joinEvery c3_16 c3_17)⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=17 by omega] using localTest
private theorem c3_18 : every 18 18 (atPrime 108 2414 280 1296)=true := by decide +kernel
private theorem c3_19 : every 20 46 (fixedPair 108 2414 280 1296 19)=true := by decide +kernel
private theorem c3_20 : every 47 72 (fixedPair 108 2414 280 1296 19)=true := by decide +kernel
private theorem c3_21 : every 73 102 (fixedPair 108 2414 280 1296 19)=true := by decide +kernel
private theorem c3_22 : every 103 117 (fixedPair 108 2414 280 1296 19)=true := by decide +kernel
private theorem c3_23 : every 1 25 (moving 118 6 2414 280 1296 19)=true := by decide +kernel
private theorem p3_19 : every 19 19 (atPrime 108 2414 280 1296)=true := by
  have localTest : atPrime 108 2414 280 1296 19=true := by change (every 20 117 (fixedPair 108 2414 280 1296 19) && every 1 25 (moving 118 6 2414 280 1296 19)) = true; rw [Bool.and_eq_true]; exact ⟨(joinEvery (joinEvery c3_19 c3_20) (joinEvery c3_21 c3_22)),c3_23⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=19 by omega] using localTest
private theorem c3_24 : every 20 22 (atPrime 108 2414 280 1296)=true := by decide +kernel
private theorem c3_25 : every 24 52 (fixedPair 108 2414 280 1296 23)=true := by decide +kernel
private theorem c3_26 : every 53 74 (fixedPair 108 2414 280 1296 23)=true := by decide +kernel
private theorem c3_27 : every 1 16 (moving 75 7 2414 280 1296 23)=true := by decide +kernel
private theorem p3_23 : every 23 23 (atPrime 108 2414 280 1296)=true := by
  have localTest : atPrime 108 2414 280 1296 23=true := by change (every 24 74 (fixedPair 108 2414 280 1296 23) && every 1 16 (moving 75 7 2414 280 1296 23)) = true; rw [Bool.and_eq_true]; exact ⟨(joinEvery c3_25 c3_26),c3_27⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=23 by omega] using localTest
private theorem c3_28 : every 24 28 (atPrime 108 2414 280 1296)=true := by decide +kernel
private theorem c3_29 : every 30 55 (fixedPair 108 2414 280 1296 29)=true := by decide +kernel
private theorem c3_30 : every 1 12 (moving 56 8 2414 280 1296 29)=true := by decide +kernel
private theorem p3_29 : every 29 29 (atPrime 108 2414 280 1296)=true := by
  have localTest : atPrime 108 2414 280 1296 29=true := by change (every 30 55 (fixedPair 108 2414 280 1296 29) && every 1 12 (moving 56 8 2414 280 1296 29)) = true; rw [Bool.and_eq_true]; exact ⟨c3_29,c3_30⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=29 by omega] using localTest
private theorem c3_31 : every 30 30 (atPrime 108 2414 280 1296)=true := by decide +kernel
private theorem c3_32 : every 32 52 (fixedPair 108 2414 280 1296 31)=true := by decide +kernel
private theorem c3_33 : every 1 11 (moving 53 8 2414 280 1296 31)=true := by decide +kernel
private theorem p3_31 : every 31 31 (atPrime 108 2414 280 1296)=true := by
  have localTest : atPrime 108 2414 280 1296 31=true := by change (every 32 52 (fixedPair 108 2414 280 1296 31) && every 1 11 (moving 53 8 2414 280 1296 31)) = true; rw [Bool.and_eq_true]; exact ⟨c3_32,c3_33⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=31 by omega] using localTest
private theorem c3_34 : every 32 36 (atPrime 108 2414 280 1296)=true := by decide +kernel
private theorem c3_35 : every 38 45 (fixedPair 108 2414 280 1296 37)=true := by decide +kernel
private theorem c3_36 : every 1 10 (moving 46 10 2414 280 1296 37)=true := by decide +kernel
private theorem p3_37 : every 37 37 (atPrime 108 2414 280 1296)=true := by
  have localTest : atPrime 108 2414 280 1296 37=true := by change (every 38 45 (fixedPair 108 2414 280 1296 37) && every 1 10 (moving 46 10 2414 280 1296 37)) = true; rw [Bool.and_eq_true]; exact ⟨c3_35,c3_36⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=37 by omega] using localTest
private theorem c3_37 : every 38 40 (atPrime 108 2414 280 1296)=true := by decide +kernel
private theorem c3_38 : every 42 43 (fixedPair 108 2414 280 1296 41)=true := by decide +kernel
private theorem c3_39 : every 1 9 (moving 44 11 2414 280 1296 41)=true := by decide +kernel
private theorem p3_41 : every 41 41 (atPrime 108 2414 280 1296)=true := by
  have localTest : atPrime 108 2414 280 1296 41=true := by change (every 42 43 (fixedPair 108 2414 280 1296 41) && every 1 9 (moving 44 11 2414 280 1296 41)) = true; rw [Bool.and_eq_true]; exact ⟨c3_38,c3_39⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=41 by omega] using localTest
private theorem c3_40 : every 42 42 (atPrime 108 2414 280 1296)=true := by decide +kernel
private theorem c3_41 : every 44 42 (fixedPair 108 2414 280 1296 43)=true := by decide +kernel
private theorem c3_42 : every 1 9 (moving 44 11 2414 280 1296 43)=true := by decide +kernel
private theorem p3_43 : every 43 43 (atPrime 108 2414 280 1296)=true := by
  have localTest : atPrime 108 2414 280 1296 43=true := by change (every 44 42 (fixedPair 108 2414 280 1296 43) && every 1 9 (moving 44 11 2414 280 1296 43)) = true; rw [Bool.and_eq_true]; exact ⟨c3_41,c3_42⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=43 by omega] using localTest
private theorem c3_43 : every 44 46 (atPrime 108 2414 280 1296)=true := by decide +kernel
private theorem c3_44 : every 48 40 (fixedPair 108 2414 280 1296 47)=true := by decide +kernel
private theorem c3_45 : every 1 8 (moving 48 12 2414 280 1296 47)=true := by decide +kernel
private theorem p3_47 : every 47 47 (atPrime 108 2414 280 1296)=true := by
  have localTest : atPrime 108 2414 280 1296 47=true := by change (every 48 40 (fixedPair 108 2414 280 1296 47) && every 1 8 (moving 48 12 2414 280 1296 47)) = true; rw [Bool.and_eq_true]; exact ⟨c3_44,c3_45⟩
  apply List.all_eq_true.mpr; intro j hj; obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa only [show j=47 by omega] using localTest
private theorem c3_46 : every 48 48 (atPrime 108 2414 280 1296)=true := by decide +kernel
theorem at3 : cert 3=true := (joinEvery (joinEvery (joinEvery (joinEvery p3_5 (joinEvery c3_1 p3_7)) (joinEvery c3_3 (joinEvery p3_11 c3_5))) (joinEvery (joinEvery p3_13 (joinEvery c3_9 p3_17)) (joinEvery (joinEvery c3_18 p3_19) (joinEvery c3_24 p3_23)))) (joinEvery (joinEvery (joinEvery c3_28 (joinEvery p3_29 c3_31)) (joinEvery p3_31 (joinEvery c3_34 p3_37))) (joinEvery (joinEvery c3_37 (joinEvery p3_41 c3_40)) (joinEvery (joinEvery p3_43 c3_43) (joinEvery p3_47 c3_46)))))
end OMA.RankThreeFourSmallTables245212
#print axioms OMA.RankThreeFourSmallTables245212.at3
