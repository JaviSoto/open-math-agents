import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E13P11
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 12 27 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b1 : every 28 36 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b2 : every 37 42 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b3 : every 43 50 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b4 : every 51 58 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b5 : every 59 60 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b6 : every 61 66 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b7 : every 67 70 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b8 : every 71 72 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b9 : every 73 78 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b10 : every 79 82 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b11 : every 83 88 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b12 : every 89 96 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b13 : every 97 100 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b14 : every 101 102 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b15 : every 103 106 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b16 : every 107 108 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b17 : every 109 112 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b18 : every 113 126 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b19 : every 127 130 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b20 : every 131 136 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b21 : every 137 138 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b22 : every 139 148 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b23 : every 149 150 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b24 : every 151 156 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b25 : every 157 162 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b26 : every 163 166 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b27 : every 167 172 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b28 : every 173 178 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
private theorem b29 : every 179 179 (finitePair 3188646 161425205 7174452 89282088 11)=true := by decide +kernel
theorem checked : test 3 13 11=true :=
  fixedTest (h:=3188646) (A:=161425205) (S:=7174452) (T:=89282088)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery b0 (joinEvery b1 b2)) (joinEvery (joinEvery b3 b4) (joinEvery b5 b6))) (joinEvery (joinEvery (joinEvery b7 b8) (joinEvery b9 b10)) (joinEvery (joinEvery b11 b12) (joinEvery b13 b14)))) (joinEvery (joinEvery (joinEvery b15 (joinEvery b16 b17)) (joinEvery (joinEvery b18 b19) (joinEvery b20 b21))) (joinEvery (joinEvery (joinEvery b22 b23) (joinEvery b24 b25)) (joinEvery (joinEvery b26 b27) (joinEvery b28 b29)))))
#print axioms checked
end OMA.RankThreeAt3E13P11
