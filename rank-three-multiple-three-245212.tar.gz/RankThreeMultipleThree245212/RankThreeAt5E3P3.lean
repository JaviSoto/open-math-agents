import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt5E3P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 6 (movingRow 2930 468 2000 3)=true := by decide +kernel
private theorem b1 : every 7 7 (movingRow 2930 468 2000 3)=true := by decide +kernel
theorem checked : test 5 3 3=true :=
  movingTest (h:=250) (A:=2930) (S:=468) (T:=2000)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery b0 b1)
#print axioms checked
end OMA.RankThreeAt5E3P3
