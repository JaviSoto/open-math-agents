import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_77_0 : every 77 78 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_77_1 : every 80 162 (quick 96 2247 252 1152 79)=true := by decide +kernel
private theorem b96_77_2 : every 1 19 (far 96 2247 252 1152 79 163 35)=true := by decide +kernel
private theorem r96_79 : every 79 79 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 79=true := by change (every 80 162 (quick 96 2247 252 1152 79) && every 1 19 (far 96 2247 252 1152 79 163 35))=true; rw [Bool.and_eq_true]; exact ⟨b96_77_1,b96_77_2⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=79 by omega] using yes
private theorem b96_77_3 : every 80 82 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_77_4 : every 84 154 (quick 96 2247 252 1152 83)=true := by decide +kernel
private theorem b96_77_5 : every 1 20 (far 96 2247 252 1152 83 155 34)=true := by decide +kernel
private theorem r96_83 : every 83 83 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 83=true := by change (every 84 154 (quick 96 2247 252 1152 83) && every 1 20 (far 96 2247 252 1152 83 155 34))=true; rw [Bool.and_eq_true]; exact ⟨b96_77_4,b96_77_5⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=83 by omega] using yes
private theorem b96_77_6 : every 84 88 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_77_7 : every 90 145 (quick 96 2247 252 1152 89)=true := by decide +kernel
private theorem b96_77_8 : every 1 21 (far 96 2247 252 1152 89 146 32)=true := by decide +kernel
private theorem r96_89 : every 89 89 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 89=true := by change (every 90 145 (quick 96 2247 252 1152 89) && every 1 21 (far 96 2247 252 1152 89 146 32))=true; rw [Bool.and_eq_true]; exact ⟨b96_77_7,b96_77_8⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=89 by omega] using yes
private theorem b96_77_9 : every 90 96 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_77_10 : every 98 136 (quick 96 2247 252 1152 97)=true := by decide +kernel
private theorem b96_77_11 : every 1 23 (far 96 2247 252 1152 97 137 30)=true := by decide +kernel
private theorem r96_97 : every 97 97 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 97=true := by change (every 98 136 (quick 96 2247 252 1152 97) && every 1 23 (far 96 2247 252 1152 97 137 30))=true; rw [Bool.and_eq_true]; exact ⟨b96_77_10,b96_77_11⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=97 by omega] using yes
private theorem b96_77_12 : every 98 100 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_77_100 : every 77 100 (run 96 2247 252 1152)=true := (joinEvery (joinEvery (joinEvery b96_77_0 r96_79) (joinEvery b96_77_3 r96_83)) (joinEvery (joinEvery b96_77_6 r96_89) (joinEvery b96_77_9 (joinEvery r96_97 b96_77_12))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_77_100
