import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt7E5P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 6 (movingRow 571905 58824 403368 3)=true := by decide +kernel
private theorem b1 : every 7 9 (movingRow 571905 58824 403368 3)=true := by decide +kernel
private theorem b2 : every 10 11 (movingRow 571905 58824 403368 3)=true := by decide +kernel
theorem checked : test 7 5 3=true :=
  movingTest (h:=33614) (A:=571905) (S:=58824) (T:=403368)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery b0 (joinEvery b1 b2))
#print axioms checked
end OMA.RankThreeAt7E5P3
