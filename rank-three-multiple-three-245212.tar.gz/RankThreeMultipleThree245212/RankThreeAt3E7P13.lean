import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E7P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 14 20 (finitePair 4374 123020 9840 69984 13)=true := by decide +kernel
theorem checked : test 3 7 13=true :=
  fixedTest (h:=4374) (A:=123020) (S:=9840) (T:=69984)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) b0
#print axioms checked
end OMA.RankThreeAt3E7P13
