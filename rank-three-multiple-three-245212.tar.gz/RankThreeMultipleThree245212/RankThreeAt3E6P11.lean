import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E6P11
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 12 18 (finitePair 1458 35540 3279 20412 11)=true := by decide +kernel
private theorem b1 : every 19 23 (finitePair 1458 35540 3279 20412 11)=true := by decide +kernel
theorem checked : test 3 6 11=true :=
  fixedTest (h:=1458) (A:=35540) (S:=3279) (T:=20412)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery b0 b1)
#print axioms checked
end OMA.RankThreeAt3E6P11
