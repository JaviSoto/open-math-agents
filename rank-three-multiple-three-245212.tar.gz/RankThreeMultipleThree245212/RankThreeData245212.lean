import RankThreeMiddle245212

/-! Verified k=1 three-prime support table. -/
namespace OMA.RankThreeData245212
open OMA.RankThreeMiddle245212
set_option maxRecDepth 65536
set_option maxHeartbeats 2400000

theorem row17_19 : Facts 19 3 17 19  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_23 : Facts 23 3 17 23  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_29 : Facts 29 3 17 29  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_31 : Facts 31 3 17 31  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_37 : Facts 37 3 17 37  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_41 : Facts 41 3 17 41  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_43 : Facts 43 3 17 43  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_47 : Facts 47 3 17 47  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_53 : Facts 53 3 17 53  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_59 : Facts 59 3 17 59  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_61 : Facts 61 3 17 61  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_67 : Facts 67 3 17 67  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_71 : Facts 71 3 17 71  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_73 : Facts 73 3 17 73  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_79 : Facts 79 3 17 79  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_83 : Facts 83 3 17 83  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_89 : Facts 89 3 17 89  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_97 : Facts 97 3 17 97  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_101 : Facts 101 3 17 101  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_103 : Facts 103 3 17 103  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_107 : Facts 107 3 17 107  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_109 : Facts 109 3 17 109  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_113 : Facts 113 3 17 113  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_127 : Facts 127 3 17 127  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_131 : Facts 131 3 17 131  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_137 : Facts 137 3 17 137  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_139 : Facts 139 3 17 139  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_149 : Facts 149 3 17 149  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_151 : Facts 151 3 17 151  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_157 : Facts 157 3 17 157  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_163 : Facts 163 3 17 163  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_167 : Facts 167 3 17 167  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_173 : Facts 173 3 17 173  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_179 : Facts 179 3 17 179  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_181 : Facts 181 3 17 181  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_191 : Facts 191 3 17 191  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_193 : Facts 193 3 17 193  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_197 : Facts 197 3 17 197  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_199 : Facts 199 3 17 199  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_211 : Facts 211 3 17 211  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_223 : Facts 223 3 17 223  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_227 : Facts 227 3 17 227  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_229 : Facts 229 3 17 229  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_233 : Facts 233 3 17 233  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_239 : Facts 239 3 17 239  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_241 : Facts 241 3 17 241  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row17_251 : Facts 251 3 17 251  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row19_23 : Facts 23 3 19 23  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row19_29 : Facts 29 3 19 29  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row19_31 : Facts 31 3 19 31  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row19_37 : Facts 37 3 19 37  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row19_41 : Facts 41 3 19 41  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row19_43 : Facts 43 3 19 43  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row19_47 : Facts 47 3 19 47  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row19_53 : Facts 53 3 19 53  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row19_59 : Facts 59 3 19 59  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row19_61 : Facts 61 3 19 61  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row19_67 : Facts 67 3 19 67  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row19_71 : Facts 71 3 19 71  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row19_73 : Facts 73 3 19 73  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row19_79 : Facts 79 3 19 79  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row19_83 : Facts 83 3 19 83  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row19_89 : Facts 89 3 19 89  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row23_29 : Facts 29 3 23 29  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row23_31 : Facts 31 3 23 31  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row23_37 : Facts 37 3 23 37  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row23_41 : Facts 41 3 23 41  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row23_43 : Facts 43 3 23 43  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row23_47 : Facts 47 3 23 47  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel
theorem row29_31 : Facts 31 3 29 31  := by constructor <;> first | (unfold OMA.RankThreeSmall245212.seed; decide +kernel) | decide +kernel

theorem data : ∀ z∈supports,Facts z.2 3 z.1 z.2 := by
  have same : supports=[(17,19),(17,23),(17,29),(17,31),(17,37),(17,41),(17,43),(17,47),(17,53),(17,59),(17,61),(17,67),(17,71),(17,73),(17,79),(17,83),(17,89),(17,97),(17,101),(17,103),(17,107),(17,109),(17,113),(17,127),(17,131),(17,137),(17,139),(17,149),(17,151),(17,157),(17,163),(17,167),(17,173),(17,179),(17,181),(17,191),(17,193),(17,197),(17,199),(17,211),(17,223),(17,227),(17,229),(17,233),(17,239),(17,241),(17,251),(19,23),(19,29),(19,31),(19,37),(19,41),(19,43),(19,47),(19,53),(19,59),(19,61),(19,67),(19,71),(19,73),(19,79),(19,83),(19,89),(23,29),(23,31),(23,37),(23,41),(23,43),(23,47),(29,31)] := by decide +kernel
  rw [same]
  simp only [List.forall_mem_cons,List.not_mem_nil]
  exact ⟨row17_19,row17_23,row17_29,row17_31,row17_37,row17_41,row17_43,row17_47,row17_53,row17_59,row17_61,row17_67,row17_71,row17_73,row17_79,row17_83,row17_89,row17_97,row17_101,row17_103,row17_107,row17_109,row17_113,row17_127,row17_131,row17_137,row17_139,row17_149,row17_151,row17_157,row17_163,row17_167,row17_173,row17_179,row17_181,row17_191,row17_193,row17_197,row17_199,row17_211,row17_223,row17_227,row17_229,row17_233,row17_239,row17_241,row17_251,row19_23,row19_29,row19_31,row19_37,row19_41,row19_43,row19_47,row19_53,row19_59,row19_61,row19_67,row19_71,row19_73,row19_79,row19_83,row19_89,row23_29,row23_31,row23_37,row23_41,row23_43,row23_47,row29_31,fun _ h => h.elim⟩

open scoped ArithmeticFunction.sigma
theorem no_middle_ge_seventeen {q r a b c : ℕ} (qp : q.Prime) (rp : r.Prime)
    (middle : 17≤q) (qr : q<r) (ap : 0<a) (bp : 0<b) (cp : 0<c) :
    OeisA245212.a (2*3^a*q^b*r^c)≠(σ 1 (2*3^a*q^b*r^c):ℤ) :=
  close data qp rp middle qr ap bp cp
end OMA.RankThreeData245212
#print axioms OMA.RankThreeData245212.no_middle_ge_seventeen
