import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E20P11
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 5 (movingRow 536093101655 15690529803 292889889684 11)=true := by decide +kernel
private theorem b1 : every 6 10 (movingRow 536093101655 15690529803 292889889684 11)=true := by decide +kernel
private theorem b2 : every 11 14 (movingRow 536093101655 15690529803 292889889684 11)=true := by decide +kernel
private theorem b3 : every 15 16 (movingRow 536093101655 15690529803 292889889684 11)=true := by decide +kernel
private theorem b4 : every 17 18 (movingRow 536093101655 15690529803 292889889684 11)=true := by decide +kernel
private theorem b5 : every 19 19 (movingRow 536093101655 15690529803 292889889684 11)=true := by decide +kernel
private theorem b6 : every 20 20 (movingRow 536093101655 15690529803 292889889684 11)=true := by decide +kernel
private theorem b7 : every 21 21 (movingRow 536093101655 15690529803 292889889684 11)=true := by decide +kernel
private theorem b8 : every 22 22 (movingRow 536093101655 15690529803 292889889684 11)=true := by decide +kernel
private theorem b9 : every 23 23 (movingRow 536093101655 15690529803 292889889684 11)=true := by decide +kernel
private theorem b10 : every 24 24 (movingRow 536093101655 15690529803 292889889684 11)=true := by decide +kernel
private theorem b11 : every 25 25 (movingRow 536093101655 15690529803 292889889684 11)=true := by decide +kernel
private theorem b12 : every 26 26 (movingRow 536093101655 15690529803 292889889684 11)=true := by decide +kernel
private theorem b13 : every 27 27 (movingRow 536093101655 15690529803 292889889684 11)=true := by decide +kernel
theorem checked : test 3 20 11=true :=
  movingTest (h:=6973568802) (A:=536093101655) (S:=15690529803) (T:=292889889684)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery b0 (joinEvery b1 b2)) (joinEvery (joinEvery b3 b4) (joinEvery b5 b6))) (joinEvery (joinEvery b7 (joinEvery b8 b9)) (joinEvery (joinEvery b10 b11) (joinEvery b12 b13))))
#print axioms checked
end OMA.RankThreeAt3E20P11
