import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_461_0 : every 462 87 (quick 96 2247 252 1152 461)=true := by decide +kernel
private theorem b96_461_1 : every 1 25 (far 96 2247 252 1152 461 462 19)=true := by decide +kernel
private theorem b96_461_2 : every 26 50 (far 96 2247 252 1152 461 462 19)=true := by decide +kernel
private theorem b96_461_3 : every 51 75 (far 96 2247 252 1152 461 462 19)=true := by decide +kernel
private theorem b96_461_4 : every 76 100 (far 96 2247 252 1152 461 462 19)=true := by decide +kernel
private theorem b96_461_5 : every 101 105 (far 96 2247 252 1152 461 462 19)=true := by decide +kernel
private theorem r96_461 : every 461 461 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 461=true := by change (every 462 87 (quick 96 2247 252 1152 461) && every 1 105 (far 96 2247 252 1152 461 462 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_461_0,(joinEvery (joinEvery b96_461_1 b96_461_2) (joinEvery b96_461_3 (joinEvery b96_461_4 b96_461_5)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=461 by omega] using yes
private theorem b96_461_6 : every 462 462 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_461_7 : every 464 87 (quick 96 2247 252 1152 463)=true := by decide +kernel
private theorem b96_461_8 : every 1 25 (far 96 2247 252 1152 463 464 19)=true := by decide +kernel
private theorem b96_461_9 : every 26 50 (far 96 2247 252 1152 463 464 19)=true := by decide +kernel
private theorem b96_461_10 : every 51 75 (far 96 2247 252 1152 463 464 19)=true := by decide +kernel
private theorem b96_461_11 : every 76 100 (far 96 2247 252 1152 463 464 19)=true := by decide +kernel
private theorem b96_461_12 : every 101 105 (far 96 2247 252 1152 463 464 19)=true := by decide +kernel
private theorem r96_463 : every 463 463 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 463=true := by change (every 464 87 (quick 96 2247 252 1152 463) && every 1 105 (far 96 2247 252 1152 463 464 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_461_7,(joinEvery (joinEvery b96_461_8 b96_461_9) (joinEvery b96_461_10 (joinEvery b96_461_11 b96_461_12)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=463 by omega] using yes
private theorem b96_461_13 : every 464 466 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_461_14 : every 468 87 (quick 96 2247 252 1152 467)=true := by decide +kernel
private theorem b96_461_15 : every 1 25 (far 96 2247 252 1152 467 468 19)=true := by decide +kernel
private theorem b96_461_16 : every 26 50 (far 96 2247 252 1152 467 468 19)=true := by decide +kernel
private theorem b96_461_17 : every 51 75 (far 96 2247 252 1152 467 468 19)=true := by decide +kernel
private theorem b96_461_18 : every 76 100 (far 96 2247 252 1152 467 468 19)=true := by decide +kernel
private theorem b96_461_19 : every 101 106 (far 96 2247 252 1152 467 468 19)=true := by decide +kernel
private theorem r96_467 : every 467 467 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 467=true := by change (every 468 87 (quick 96 2247 252 1152 467) && every 1 106 (far 96 2247 252 1152 467 468 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_461_14,(joinEvery (joinEvery b96_461_15 b96_461_16) (joinEvery b96_461_17 (joinEvery b96_461_18 b96_461_19)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=467 by omega] using yes
private theorem b96_461_20 : every 468 478 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_461_21 : every 480 87 (quick 96 2247 252 1152 479)=true := by decide +kernel
private theorem b96_461_22 : every 1 25 (far 96 2247 252 1152 479 480 19)=true := by decide +kernel
private theorem b96_461_23 : every 26 50 (far 96 2247 252 1152 479 480 19)=true := by decide +kernel
private theorem b96_461_24 : every 51 75 (far 96 2247 252 1152 479 480 19)=true := by decide +kernel
private theorem b96_461_25 : every 76 100 (far 96 2247 252 1152 479 480 19)=true := by decide +kernel
private theorem b96_461_26 : every 101 109 (far 96 2247 252 1152 479 480 19)=true := by decide +kernel
private theorem r96_479 : every 479 479 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 479=true := by change (every 480 87 (quick 96 2247 252 1152 479) && every 1 109 (far 96 2247 252 1152 479 480 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_461_21,(joinEvery (joinEvery b96_461_22 b96_461_23) (joinEvery b96_461_24 (joinEvery b96_461_25 b96_461_26)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=479 by omega] using yes
private theorem b96_461_27 : every 480 484 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_461_484 : every 461 484 (run 96 2247 252 1152)=true := (joinEvery (joinEvery (joinEvery r96_461 b96_461_6) (joinEvery r96_463 b96_461_13)) (joinEvery (joinEvery r96_467 b96_461_20) (joinEvery r96_479 b96_461_27)))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_461_484
