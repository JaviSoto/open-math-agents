import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E37P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 3 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b1 : every 4 6 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b2 : every 7 9 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b3 : every 10 12 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b4 : every 13 15 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b5 : every 16 18 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b6 : every 19 21 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b7 : every 22 24 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b8 : every 25 27 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b9 : every 28 30 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b10 : every 31 33 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b11 : every 34 35 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b12 : every 36 36 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b13 : every 37 37 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b14 : every 38 38 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b15 : every 39 39 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b16 : every 40 40 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b17 : every 41 41 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b18 : every 42 42 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b19 : every 43 43 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b20 : every 44 44 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b21 : every 45 45 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b22 : every 46 46 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b23 : every 47 47 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b24 : every 48 48 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b25 : every 49 49 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b26 : every 50 50 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b27 : every 51 51 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b28 : every 52 52 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b29 : every 53 53 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b30 : every 54 54 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b31 : every 55 55 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b32 : every 56 56 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b33 : every 57 57 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b34 : every 58 58 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b35 : every 59 59 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b36 : every 60 60 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b37 : every 61 61 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b38 : every 62 62 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b39 : every 63 63 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b40 : every 64 64 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b41 : every 65 65 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b42 : every 66 66 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b43 : every 67 67 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
private theorem b44 : every 68 68 (movingRow 126642348531843008345 2026277576509488132 68443153695431599176 13)=true := by decide +kernel
theorem checked : test 3 37 13=true :=
  movingTest (h:=900567811781994726) (A:=126642348531843008345) (S:=2026277576509488132) (T:=68443153695431599176)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 (joinEvery b3 b4))) (joinEvery (joinEvery b5 (joinEvery b6 b7)) (joinEvery b8 (joinEvery b9 b10)))) (joinEvery (joinEvery (joinEvery b11 b12) (joinEvery b13 (joinEvery b14 b15))) (joinEvery (joinEvery b16 (joinEvery b17 b18)) (joinEvery b19 (joinEvery b20 b21))))) (joinEvery (joinEvery (joinEvery (joinEvery b22 b23) (joinEvery b24 (joinEvery b25 b26))) (joinEvery (joinEvery b27 (joinEvery b28 b29)) (joinEvery b30 (joinEvery b31 b32)))) (joinEvery (joinEvery (joinEvery b33 (joinEvery b34 b35)) (joinEvery b36 (joinEvery b37 b38))) (joinEvery (joinEvery b39 (joinEvery b40 b41)) (joinEvery b42 (joinEvery b43 b44))))))
#print axioms checked
end OMA.RankThreeAt3E37P13
