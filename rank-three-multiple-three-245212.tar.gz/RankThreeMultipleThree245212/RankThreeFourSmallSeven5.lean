import RankThreeFourSmallCompact245212
/-! Independently checked consecutive interval for the compressed two-prime decision. -/
namespace OMA.RankThreeFourSmallCompactTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallCompact245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem r7_5_9 : every 5 9 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_10_14 : every 10 14 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_15_19 : every 15 19 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_20_24 : every 20 24 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_25_29 : every 25 29 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_30_34 : every 30 34 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_35_39 : every 35 39 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_40_44 : every 40 44 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_45_49 : every 45 49 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_50_54 : every 50 54 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_55_59 : every 55 59 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_60_64 : every 60 64 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_65_69 : every 65 69 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_70_74 : every 70 74 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_75_79 : every 75 79 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_80_84 : every 80 84 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_85_89 : every 85 89 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_90_94 : every 90 94 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_95_99 : every 95 99 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_100_104 : every 100 104 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_105_109 : every 105 109 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_110_114 : every 110 114 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_115_119 : every 115 119 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_120_124 : every 120 124 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_125_129 : every 125 129 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_130_134 : every 130 134 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_135_139 : every 135 139 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_140_144 : every 140 144 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_145_149 : every 145 149 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_150_154 : every 150 154 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_155_159 : every 155 159 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_160_164 : every 160 164 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_165_169 : every 165 169 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_170_174 : every 170 174 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_175_179 : every 175 179 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_180_184 : every 180 184 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_185_189 : every 185 189 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_190_194 : every 190 194 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_195_199 : every 195 199 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_200_204 : every 200 204 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_205_209 : every 205 209 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_210_214 : every 210 214 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_215_219 : every 215 219 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_220_224 : every 220 224 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_225_229 : every 225 229 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_230_234 : every 230 234 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_235_239 : every 235 239 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_240_244 : every 240 244 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_245_249 : every 245 249 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_250_251 : every 250 251 (run 8748 418268 22960 209952)=true := by decide +kernel
theorem span7_5_251 : every 5 251 (run 8748 418268 22960 209952)=true := (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery r7_5_9 (joinEvery r7_10_14 r7_15_19)) (joinEvery r7_20_24 (joinEvery r7_25_29 r7_30_34))) (joinEvery (joinEvery r7_35_39 (joinEvery r7_40_44 r7_45_49)) (joinEvery r7_50_54 (joinEvery r7_55_59 r7_60_64)))) (joinEvery (joinEvery (joinEvery r7_65_69 (joinEvery r7_70_74 r7_75_79)) (joinEvery r7_80_84 (joinEvery r7_85_89 r7_90_94))) (joinEvery (joinEvery r7_95_99 (joinEvery r7_100_104 r7_105_109)) (joinEvery (joinEvery r7_110_114 r7_115_119) (joinEvery r7_120_124 r7_125_129))))) (joinEvery (joinEvery (joinEvery (joinEvery r7_130_134 (joinEvery r7_135_139 r7_140_144)) (joinEvery r7_145_149 (joinEvery r7_150_154 r7_155_159))) (joinEvery (joinEvery r7_160_164 (joinEvery r7_165_169 r7_170_174)) (joinEvery r7_175_179 (joinEvery r7_180_184 r7_185_189)))) (joinEvery (joinEvery (joinEvery r7_190_194 (joinEvery r7_195_199 r7_200_204)) (joinEvery r7_205_209 (joinEvery r7_210_214 r7_215_219))) (joinEvery (joinEvery r7_220_224 (joinEvery r7_225_229 r7_230_234)) (joinEvery (joinEvery r7_235_239 r7_240_244) (joinEvery r7_245_249 r7_250_251))))))
end OMA.RankThreeFourSmallCompactTables245212
#print axioms OMA.RankThreeFourSmallCompactTables245212.span7_5_251
