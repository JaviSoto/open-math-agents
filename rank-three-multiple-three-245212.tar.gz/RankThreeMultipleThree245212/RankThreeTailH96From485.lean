import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_485_0 : every 485 486 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_485_1 : every 488 86 (quick 96 2247 252 1152 487)=true := by decide +kernel
private theorem b96_485_2 : every 1 25 (far 96 2247 252 1152 487 488 19)=true := by decide +kernel
private theorem b96_485_3 : every 26 50 (far 96 2247 252 1152 487 488 19)=true := by decide +kernel
private theorem b96_485_4 : every 51 75 (far 96 2247 252 1152 487 488 19)=true := by decide +kernel
private theorem b96_485_5 : every 76 100 (far 96 2247 252 1152 487 488 19)=true := by decide +kernel
private theorem b96_485_6 : every 101 111 (far 96 2247 252 1152 487 488 19)=true := by decide +kernel
private theorem r96_487 : every 487 487 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 487=true := by change (every 488 86 (quick 96 2247 252 1152 487) && every 1 111 (far 96 2247 252 1152 487 488 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_485_1,(joinEvery (joinEvery b96_485_2 b96_485_3) (joinEvery b96_485_4 (joinEvery b96_485_5 b96_485_6)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=487 by omega] using yes
private theorem b96_485_7 : every 488 490 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_485_8 : every 492 86 (quick 96 2247 252 1152 491)=true := by decide +kernel
private theorem b96_485_9 : every 1 25 (far 96 2247 252 1152 491 492 19)=true := by decide +kernel
private theorem b96_485_10 : every 26 50 (far 96 2247 252 1152 491 492 19)=true := by decide +kernel
private theorem b96_485_11 : every 51 75 (far 96 2247 252 1152 491 492 19)=true := by decide +kernel
private theorem b96_485_12 : every 76 100 (far 96 2247 252 1152 491 492 19)=true := by decide +kernel
private theorem b96_485_13 : every 101 111 (far 96 2247 252 1152 491 492 19)=true := by decide +kernel
private theorem r96_491 : every 491 491 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 491=true := by change (every 492 86 (quick 96 2247 252 1152 491) && every 1 111 (far 96 2247 252 1152 491 492 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_485_8,(joinEvery (joinEvery b96_485_9 b96_485_10) (joinEvery b96_485_11 (joinEvery b96_485_12 b96_485_13)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=491 by omega] using yes
private theorem b96_485_14 : every 492 498 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_485_15 : every 500 86 (quick 96 2247 252 1152 499)=true := by decide +kernel
private theorem b96_485_16 : every 1 25 (far 96 2247 252 1152 499 500 19)=true := by decide +kernel
private theorem b96_485_17 : every 26 50 (far 96 2247 252 1152 499 500 19)=true := by decide +kernel
private theorem b96_485_18 : every 51 75 (far 96 2247 252 1152 499 500 19)=true := by decide +kernel
private theorem b96_485_19 : every 76 100 (far 96 2247 252 1152 499 500 19)=true := by decide +kernel
private theorem b96_485_20 : every 101 113 (far 96 2247 252 1152 499 500 19)=true := by decide +kernel
private theorem r96_499 : every 499 499 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 499=true := by change (every 500 86 (quick 96 2247 252 1152 499) && every 1 113 (far 96 2247 252 1152 499 500 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_485_15,(joinEvery (joinEvery b96_485_16 b96_485_17) (joinEvery b96_485_18 (joinEvery b96_485_19 b96_485_20)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=499 by omega] using yes
private theorem b96_485_21 : every 500 502 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_485_22 : every 504 86 (quick 96 2247 252 1152 503)=true := by decide +kernel
private theorem b96_485_23 : every 1 25 (far 96 2247 252 1152 503 504 19)=true := by decide +kernel
private theorem b96_485_24 : every 26 50 (far 96 2247 252 1152 503 504 19)=true := by decide +kernel
private theorem b96_485_25 : every 51 75 (far 96 2247 252 1152 503 504 19)=true := by decide +kernel
private theorem b96_485_26 : every 76 100 (far 96 2247 252 1152 503 504 19)=true := by decide +kernel
private theorem b96_485_27 : every 101 114 (far 96 2247 252 1152 503 504 19)=true := by decide +kernel
private theorem r96_503 : every 503 503 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 503=true := by change (every 504 86 (quick 96 2247 252 1152 503) && every 1 114 (far 96 2247 252 1152 503 504 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_485_22,(joinEvery (joinEvery b96_485_23 b96_485_24) (joinEvery b96_485_25 (joinEvery b96_485_26 b96_485_27)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=503 by omega] using yes
private theorem b96_485_28 : every 504 508 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_485_508 : every 485 508 (run 96 2247 252 1152)=true := (joinEvery (joinEvery (joinEvery b96_485_0 r96_487) (joinEvery b96_485_7 r96_491)) (joinEvery (joinEvery b96_485_14 r96_499) (joinEvery b96_485_21 (joinEvery r96_503 b96_485_28))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_485_508
