import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt7E3P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 7 (movingRow 7670 1200 5488 3)=true := by decide +kernel
private theorem b1 : every 8 11 (movingRow 7670 1200 5488 3)=true := by decide +kernel
private theorem b2 : every 12 14 (movingRow 7670 1200 5488 3)=true := by decide +kernel
theorem checked : test 7 3 3=true :=
  movingTest (h:=686) (A:=7670) (S:=1200) (T:=5488)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery b0 (joinEvery b1 b2))
#print axioms checked
end OMA.RankThreeAt7E3P3
