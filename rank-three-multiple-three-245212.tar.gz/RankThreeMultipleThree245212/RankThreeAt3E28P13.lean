import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E28P13
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 14 30 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b1 : every 31 42 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b2 : every 43 52 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b3 : every 53 60 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b4 : every 61 68 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b5 : every 69 72 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b6 : every 73 78 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b7 : every 79 82 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b8 : every 83 88 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b9 : every 89 96 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b10 : every 97 100 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b11 : every 101 102 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b12 : every 103 106 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b13 : every 107 108 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b14 : every 109 112 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b15 : every 113 126 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b16 : every 127 130 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b17 : every 131 136 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b18 : every 137 138 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b19 : every 139 148 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b20 : every 149 150 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b21 : every 151 156 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b22 : every 157 162 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b23 : every 163 166 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b24 : every 167 172 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b25 : every 173 178 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b26 : every 179 180 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b27 : every 181 190 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b28 : every 191 192 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b29 : every 193 196 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b30 : every 197 198 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b31 : every 199 210 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b32 : every 211 222 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b33 : every 223 226 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b34 : every 227 228 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b35 : every 229 232 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b36 : every 233 238 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b37 : every 239 240 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b38 : every 241 250 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b39 : every 251 256 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b40 : every 257 262 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b41 : every 263 268 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b42 : every 269 270 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b43 : every 271 276 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b44 : every 277 280 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b45 : every 281 282 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b46 : every 283 292 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b47 : every 293 306 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b48 : every 307 310 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b49 : every 311 312 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b50 : every 313 316 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b51 : every 317 330 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b52 : every 331 336 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b53 : every 337 346 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b54 : every 347 348 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b55 : every 349 352 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b56 : every 353 358 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b57 : every 359 366 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b58 : every 367 372 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b59 : every 373 378 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b60 : every 379 382 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b61 : every 383 388 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b62 : every 389 396 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b63 : every 397 400 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b64 : every 401 408 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b65 : every 409 418 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b66 : every 419 420 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b67 : every 421 430 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b68 : every 431 432 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b69 : every 433 438 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b70 : every 439 442 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b71 : every 443 448 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b72 : every 449 456 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b73 : every 457 460 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b74 : every 461 462 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b75 : every 463 466 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b76 : every 467 478 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b77 : every 479 486 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b78 : every 487 490 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b79 : every 491 498 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b80 : every 499 502 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b81 : every 503 508 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b82 : every 509 520 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b83 : every 521 522 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
private theorem b84 : every 523 530 (finitePair 45753584909922 4889914387247915 102945566047323 2653707924775476 13)=true := by decide +kernel
theorem checked : test 3 28 13=true :=
  fixedTest (h:=45753584909922) (A:=4889914387247915) (S:=102945566047323) (T:=2653707924775476)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 (joinEvery b3 b4))) (joinEvery (joinEvery b5 b6) (joinEvery b7 (joinEvery b8 b9)))) (joinEvery (joinEvery (joinEvery b10 b11) (joinEvery b12 (joinEvery b13 b14))) (joinEvery (joinEvery b15 (joinEvery b16 b17)) (joinEvery b18 (joinEvery b19 b20))))) (joinEvery (joinEvery (joinEvery (joinEvery b21 b22) (joinEvery b23 (joinEvery b24 b25))) (joinEvery (joinEvery b26 b27) (joinEvery b28 (joinEvery b29 b30)))) (joinEvery (joinEvery (joinEvery b31 b32) (joinEvery b33 (joinEvery b34 b35))) (joinEvery (joinEvery b36 (joinEvery b37 b38)) (joinEvery b39 (joinEvery b40 b41)))))) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b42 b43) (joinEvery b44 (joinEvery b45 b46))) (joinEvery (joinEvery b47 b48) (joinEvery b49 (joinEvery b50 b51)))) (joinEvery (joinEvery (joinEvery b52 b53) (joinEvery b54 (joinEvery b55 b56))) (joinEvery (joinEvery b57 (joinEvery b58 b59)) (joinEvery b60 (joinEvery b61 b62))))) (joinEvery (joinEvery (joinEvery (joinEvery b63 b64) (joinEvery b65 (joinEvery b66 b67))) (joinEvery (joinEvery b68 (joinEvery b69 b70)) (joinEvery b71 (joinEvery b72 b73)))) (joinEvery (joinEvery (joinEvery b74 b75) (joinEvery b76 (joinEvery b77 b78))) (joinEvery (joinEvery b79 (joinEvery b80 b81)) (joinEvery b82 (joinEvery b83 b84)))))))
#print axioms checked
end OMA.RankThreeAt3E28P13
