import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b72_125_0 : every 125 126 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_125_1 : every 128 69 (quick 72 1666 195 864 127)=true := by decide +kernel
private theorem b72_125_2 : every 1 25 (far 72 1666 195 864 127 128 15)=true := by decide +kernel
private theorem b72_125_3 : every 26 31 (far 72 1666 195 864 127 128 15)=true := by decide +kernel
private theorem r72_127 : every 127 127 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 127=true := by change (every 128 69 (quick 72 1666 195 864 127) && every 1 31 (far 72 1666 195 864 127 128 15))=true; rw [Bool.and_eq_true]; exact ⟨b72_125_1,(joinEvery b72_125_2 b72_125_3)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=127 by omega] using yes
private theorem b72_125_4 : every 128 130 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_125_5 : every 132 69 (quick 72 1666 195 864 131)=true := by decide +kernel
private theorem b72_125_6 : every 1 25 (far 72 1666 195 864 131 132 15)=true := by decide +kernel
private theorem b72_125_7 : every 26 32 (far 72 1666 195 864 131 132 15)=true := by decide +kernel
private theorem r72_131 : every 131 131 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 131=true := by change (every 132 69 (quick 72 1666 195 864 131) && every 1 32 (far 72 1666 195 864 131 132 15))=true; rw [Bool.and_eq_true]; exact ⟨b72_125_5,(joinEvery b72_125_6 b72_125_7)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=131 by omega] using yes
private theorem b72_125_8 : every 132 136 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_125_9 : every 138 68 (quick 72 1666 195 864 137)=true := by decide +kernel
private theorem b72_125_10 : every 1 25 (far 72 1666 195 864 137 138 15)=true := by decide +kernel
private theorem b72_125_11 : every 26 33 (far 72 1666 195 864 137 138 15)=true := by decide +kernel
private theorem r72_137 : every 137 137 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 137=true := by change (every 138 68 (quick 72 1666 195 864 137) && every 1 33 (far 72 1666 195 864 137 138 15))=true; rw [Bool.and_eq_true]; exact ⟨b72_125_9,(joinEvery b72_125_10 b72_125_11)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=137 by omega] using yes
private theorem b72_125_12 : every 138 138 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_125_13 : every 140 68 (quick 72 1666 195 864 139)=true := by decide +kernel
private theorem b72_125_14 : every 1 25 (far 72 1666 195 864 139 140 15)=true := by decide +kernel
private theorem b72_125_15 : every 26 34 (far 72 1666 195 864 139 140 15)=true := by decide +kernel
private theorem r72_139 : every 139 139 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 139=true := by change (every 140 68 (quick 72 1666 195 864 139) && every 1 34 (far 72 1666 195 864 139 140 15))=true; rw [Bool.and_eq_true]; exact ⟨b72_125_13,(joinEvery b72_125_14 b72_125_15)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=139 by omega] using yes
private theorem b72_125_16 : every 140 148 (run 72 1666 195 864)=true := by decide +kernel
theorem span72_125_148 : every 125 148 (run 72 1666 195 864)=true := (joinEvery (joinEvery (joinEvery b72_125_0 r72_127) (joinEvery b72_125_4 r72_131)) (joinEvery (joinEvery b72_125_8 r72_137) (joinEvery b72_125_12 (joinEvery r72_139 b72_125_16))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span72_125_148
