import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b24_29_0 : every 30 25 (quick 24 343 60 192 29)=true := by decide +kernel
private theorem b24_29_1 : every 1 11 (far 24 343 60 192 29 30 8)=true := by decide +kernel
private theorem r24_29 : every 29 29 (run 24 343 60 192)=true := by
  have yes : run 24 343 60 192 29=true := by change (every 30 25 (quick 24 343 60 192 29) && every 1 11 (far 24 343 60 192 29 30 8))=true; rw [Bool.and_eq_true]; exact ⟨b24_29_0,b24_29_1⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=29 by omega] using yes
theorem span24_29_29 : every 29 29 (run 24 343 60 192)=true := r24_29
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span24_29_29
