import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_629_0 : every 629 630 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_629_1 : every 632 85 (quick 96 2247 252 1152 631)=true := by decide +kernel
private theorem b96_629_2 : every 1 25 (far 96 2247 252 1152 631 632 18)=true := by decide +kernel
private theorem b96_629_3 : every 26 50 (far 96 2247 252 1152 631 632 18)=true := by decide +kernel
private theorem b96_629_4 : every 51 75 (far 96 2247 252 1152 631 632 18)=true := by decide +kernel
private theorem b96_629_5 : every 76 100 (far 96 2247 252 1152 631 632 18)=true := by decide +kernel
private theorem b96_629_6 : every 101 125 (far 96 2247 252 1152 631 632 18)=true := by decide +kernel
private theorem b96_629_7 : every 126 143 (far 96 2247 252 1152 631 632 18)=true := by decide +kernel
private theorem r96_631 : every 631 631 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 631=true := by change (every 632 85 (quick 96 2247 252 1152 631) && every 1 143 (far 96 2247 252 1152 631 632 18))=true; rw [Bool.and_eq_true]; exact ⟨b96_629_1,(joinEvery (joinEvery b96_629_2 (joinEvery b96_629_3 b96_629_4)) (joinEvery b96_629_5 (joinEvery b96_629_6 b96_629_7)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=631 by omega] using yes
private theorem b96_629_8 : every 632 640 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_629_9 : every 642 85 (quick 96 2247 252 1152 641)=true := by decide +kernel
private theorem b96_629_10 : every 1 25 (far 96 2247 252 1152 641 642 18)=true := by decide +kernel
private theorem b96_629_11 : every 26 50 (far 96 2247 252 1152 641 642 18)=true := by decide +kernel
private theorem b96_629_12 : every 51 75 (far 96 2247 252 1152 641 642 18)=true := by decide +kernel
private theorem b96_629_13 : every 76 100 (far 96 2247 252 1152 641 642 18)=true := by decide +kernel
private theorem b96_629_14 : every 101 125 (far 96 2247 252 1152 641 642 18)=true := by decide +kernel
private theorem b96_629_15 : every 126 145 (far 96 2247 252 1152 641 642 18)=true := by decide +kernel
private theorem r96_641 : every 641 641 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 641=true := by change (every 642 85 (quick 96 2247 252 1152 641) && every 1 145 (far 96 2247 252 1152 641 642 18))=true; rw [Bool.and_eq_true]; exact ⟨b96_629_9,(joinEvery (joinEvery b96_629_10 (joinEvery b96_629_11 b96_629_12)) (joinEvery b96_629_13 (joinEvery b96_629_14 b96_629_15)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=641 by omega] using yes
private theorem b96_629_16 : every 642 642 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_629_17 : every 644 85 (quick 96 2247 252 1152 643)=true := by decide +kernel
private theorem b96_629_18 : every 1 25 (far 96 2247 252 1152 643 644 18)=true := by decide +kernel
private theorem b96_629_19 : every 26 50 (far 96 2247 252 1152 643 644 18)=true := by decide +kernel
private theorem b96_629_20 : every 51 75 (far 96 2247 252 1152 643 644 18)=true := by decide +kernel
private theorem b96_629_21 : every 76 100 (far 96 2247 252 1152 643 644 18)=true := by decide +kernel
private theorem b96_629_22 : every 101 125 (far 96 2247 252 1152 643 644 18)=true := by decide +kernel
private theorem b96_629_23 : every 126 146 (far 96 2247 252 1152 643 644 18)=true := by decide +kernel
private theorem r96_643 : every 643 643 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 643=true := by change (every 644 85 (quick 96 2247 252 1152 643) && every 1 146 (far 96 2247 252 1152 643 644 18))=true; rw [Bool.and_eq_true]; exact ⟨b96_629_17,(joinEvery (joinEvery b96_629_18 (joinEvery b96_629_19 b96_629_20)) (joinEvery b96_629_21 (joinEvery b96_629_22 b96_629_23)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=643 by omega] using yes
private theorem b96_629_24 : every 644 646 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_629_25 : every 648 85 (quick 96 2247 252 1152 647)=true := by decide +kernel
private theorem b96_629_26 : every 1 25 (far 96 2247 252 1152 647 648 18)=true := by decide +kernel
private theorem b96_629_27 : every 26 50 (far 96 2247 252 1152 647 648 18)=true := by decide +kernel
private theorem b96_629_28 : every 51 75 (far 96 2247 252 1152 647 648 18)=true := by decide +kernel
private theorem b96_629_29 : every 76 100 (far 96 2247 252 1152 647 648 18)=true := by decide +kernel
private theorem b96_629_30 : every 101 125 (far 96 2247 252 1152 647 648 18)=true := by decide +kernel
private theorem b96_629_31 : every 126 146 (far 96 2247 252 1152 647 648 18)=true := by decide +kernel
private theorem r96_647 : every 647 647 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 647=true := by change (every 648 85 (quick 96 2247 252 1152 647) && every 1 146 (far 96 2247 252 1152 647 648 18))=true; rw [Bool.and_eq_true]; exact ⟨b96_629_25,(joinEvery (joinEvery b96_629_26 (joinEvery b96_629_27 b96_629_28)) (joinEvery b96_629_29 (joinEvery b96_629_30 b96_629_31)))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=647 by omega] using yes
private theorem b96_629_32 : every 648 652 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_629_652 : every 629 652 (run 96 2247 252 1152)=true := (joinEvery (joinEvery (joinEvery b96_629_0 r96_631) (joinEvery b96_629_8 r96_641)) (joinEvery (joinEvery b96_629_16 r96_643) (joinEvery b96_629_24 (joinEvery r96_647 b96_629_32))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_629_652
