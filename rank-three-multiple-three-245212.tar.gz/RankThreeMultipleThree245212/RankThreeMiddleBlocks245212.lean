import RankThreeShortPrefix245212

/-! Check short intervals separately and join them without reducing the
boolean arithmetic again. All endpoints are checked in the kernel. -/
namespace OMA.RankThreeMiddle245212
open OMA.CofactorEulerPair245212

theorem joinEvery {f : ℕ→Bool} {a b c : ℕ}
    (left : every a b f=true) (right : every (b+1) c f=true) :
    every a c f=true := by
  apply List.all_eq_true.mpr
  intro i hi
  obtain ⟨lo,up⟩:=List.mem_range'_1.mp hi
  by_cases e : i≤b
  · exact List.all_eq_true.mp left i (List.mem_range'_1.mpr ⟨lo,by omega⟩)
  · exact List.all_eq_true.mp right i (List.mem_range'_1.mpr ⟨by omega,by omega⟩)

theorem range_from_every {s p L : ℕ}
    (ok : every 1 (L-1) (fun i=>test s i p)=true) : rangeCheck s p L=true := by
  apply List.all_eq_true.mpr
  intro i hi
  have h:=List.mem_range.mp hi
  exact List.all_eq_true.mp ok (i+1) (List.mem_range'_1.mpr ⟨by omega,by omega⟩)

theorem fixedTest {s i p h A S T : ℕ}
    (base : (h,A,S,T)=(2*s^i,5*OMA.Large245212.wt s i,
      3*OMA.Large245212.sig s i,4*OMA.Large245212.tax s i))
    (yes : A+S≤2*T) (pr : p.Prime) (cop : h.Coprime p)
    (gap : A*p<2*T*(p-1))
    (table : every (p+1) (2*T*(p-1)/(2*T*(p-1)-A*p)) (finitePair h A S T p)=true) :
    test s i p=true := by
  simp only [Prod.mk.injEq] at base
  obtain ⟨rfl,rfl,rfl,rfl⟩:=base
  simpa [test,nextPrime,yes,pr,cop,gap,Nat.not_lt_of_ge gap.le] using table

theorem movingTest {s i p h A S T : ℕ}
    (base : (h,A,S,T)=(2*s^i,5*OMA.Large245212.wt s i,
      3*OMA.Large245212.sig s i,4*OMA.Large245212.tax s i))
    (yes : A+S≤2*T) (pr : p.Prime) (cop : h.Coprime p)
    (gap : 2*T*(p-1)<A*p)
    (table : every 1 (2*A/(A*p-2*T*(p-1))) (movingRow A S T p)=true) :
    test s i p=true := by
  simp only [Prod.mk.injEq] at base
  obtain ⟨rfl,rfl,rfl,rfl⟩:=base
  simpa [test,nextPrime,yes,pr,cop,gap] using table

theorem singleTest {s i p : ℕ} (ok : test s i p=true) :
    every i i (fun j=>test s j p)=true := by
  apply List.all_eq_true.mpr
  intro j hj
  obtain ⟨lo,hi⟩:=List.mem_range'_1.mp hj
  simpa [show j=i by omega] using ok

end OMA.RankThreeMiddle245212
