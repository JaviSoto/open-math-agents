import OddTable245212
import OddLimit245212
import OddCofactor245212
import OddAbundancy245212

/-! Bound the largest prime in an arbitrary ordered four-prime odd exception. -/
namespace OMA.OddFaces245212
open Finset OMA.Smooth245212
open scoped ArithmeticFunction.sigma

private theorem compare4 {p u : Fin 4 → ℕ} (h : ∀ i,1<u i) (lower : ∀ i,u i≤p i) :
    (∏ i,limitX (p i))≤∏ i,limitX (u i) := by
  exact prod_le_prod (f:=fun i => limitX (p i)) (g:=fun i => limitX (u i))
    (fun i _ => x_nonneg ((h i).trans_le (lower i)) none)
    (fun i _ => cap_anti (h i) (lower i))

private theorem prime_at_least {p t : ℕ} (hp : Nat.Prime p) (lo : t≤p)
    (no : ¬Nat.Prime t) : t<p := lt_of_le_of_ne lo (fun eq => no (eq ▸ hp))

theorem small_bases {p : Fin 4 → ℕ} (hp : ∀ i,Nat.Prime (p i)) (ord : StrictMono p)
    (odd : 3≤p 0) (big : 257≤p 3) (cap : 2≤∏ i,limitX (p i)) :
    p 0=3 ∧ p 1=5 ∧ (p 2=7 ∨ p 2=11 ∨ p 2=13) := by
  have h01 := ord (by decide : (0:Fin 4)<1)
  have h12 := ord (by decide : (1:Fin 4)<2)
  have h23 := ord (by decide : (2:Fin 4)<3)
  have drop (u : Fin 4 → ℕ) (a : ∀ i,1<u i) (b : ∀ i,u i≤p i)
      (c : (∏ i,limitX (u i))<2) : False := (cap.trans (compare4 a b)).not_gt c
  have first : p 0=3 := by
    by_contra! ne
    have h0 := prime_at_least (hp 0) (by omega : 4≤p 0) (by decide)
    apply drop ![5,6,7,257] (by decide) _ (by decide +kernel)
    intro i; fin_cases i <;> simp <;> omega
  have h1 := prime_at_least (hp 1) (by omega : 4≤p 1) (by decide)
  have second : p 1=5 := by
    by_contra! ne
    have h1' := prime_at_least (hp 1) (by omega : 6≤p 1) (by decide)
    have h2 := prime_at_least (hp 2) (by omega : 8≤p 2) (by decide)
    apply drop ![3,7,9,257] (by decide) _ (by decide +kernel)
    intro i; fin_cases i <;> simp <;> omega
  have third : p 2<17 := by
    by_contra! zl
    apply drop ![3,5,17,257] (by decide) _ (by decide +kernel)
    intro i; fin_cases i <;> simp <;> omega
  refine ⟨first,second,?_⟩
  have h2 := hp 2
  have lb : 6≤p 2 := by omega
  generalize p 2=u at h2 lb third ⊢
  interval_cases u <;> norm_num at *

/-- Explicit uniform prime-support bound. No primality checks on
the cofactor are needed when taking this finite envelope. -/
def envelopeBound (t : ℕ) := t + ∑ m∈range (195^t+1), (W m+ArithmeticFunction.sigma 1 m)
abbrev primeBound := envelopeBound threshold

private theorem basic (t : ℕ) : t≤envelopeBound t := Nat.le_add_right t _
private theorem bounded (t m : ℕ) (h : m≤195^t) : W m+ArithmeticFunction.sigma 1 m≤envelopeBound t := by
  apply le_trans (single_le_sum (f:=fun m => W m+ArithmeticFunction.sigma 1 m)
    (fun _ _ => Nat.zero_le _) (mem_range.mpr (Nat.lt_succ_of_le h)))
  exact Nat.le_add_left _ t

theorem primeBound_ge : threshold≤primeBound := basic threshold

private theorem cofactor_size (a b c q t : ℕ) (ha : a≤t) (hb : b≤t) (hc : c≤t)
    (hq : q≤13) : 3^a*5^b*q^c≤195^t := by
  have h := Nat.mul_le_mul (Nat.mul_le_mul (Nat.pow_le_pow_right (by decide : 0<3) ha)
    (Nat.pow_le_pow_right (by decide : 0<5) hb))
    ((Nat.pow_le_pow_left hq c).trans (Nat.pow_le_pow_right (by decide : 0<13) hc))
  simpa only [←mul_pow,show 3*5*13=(195:ℕ) by decide] using h

theorem last_prime_le {p e : Fin 4 → ℕ} (hp : ∀ i,Nat.Prime (p i)) (ord : StrictMono p)
    (odd : 3≤p 0) (positive : ∀ i,0<e i)
    (eq : OeisA245212.a (total p e)=(σ 1 (total p e):ℤ)) : p 3≤primeBound := by
  by_cases sm : p 3≤threshold
  · exact sm.trans primeBound_ge
  have high : threshold<p 3 := by omega
  have norm := normalized_of_eq p hp ord.injective _ eq
  have cap := cap_needed p e (fun i => (hp i).one_lt) 0 (positive 0) norm
  obtain ⟨a,b,c⟩ := small_bases hp ord odd (by unfold threshold at high; omega) cap
  let q := p 2
  let r := p 3
  have qq : q=7 ∨ q=11 ∨ q=13 := c
  have q13 : q≤13 := by rcases qq with h|h|h <;> omega
  have q3 : 3≤q := by rcases qq with h|h|h <;> omega
  have qp : Nat.Prime q := hp 2
  have pp (i : Fin 3) : p i.castSucc=bases q i := by
    fin_cases i <;> simp [bases,q,a,b]
  have ps : preScore q r (e 3) e=2 := by
    unfold normalized at norm
    rw [Fin.prod_univ_castSucc (fun i => X (p i) (some (e i))),
      Fin.prod_univ_castSucc (fun i => Y (p i) (some (e i)))] at norm
    simpa only [pp,preScore,r,show Fin.last 3=(3:Fin 4) by decide] using norm
  have low (i : Fin 3) : e i.castSucc<threshold := by
    by_contra! large
    exact near_face qp q3 high e (e 3) i large ps (separation qq i e positive)
  let m := 3^(e 0)*5^(e 1)*q^(e 2)
  have fact : total p e=m*r^(e 3) := by
    simp [total,Fin.prod_univ_four,m,r,q,a,b,mul_assoc]
  have hm : 0 < m := by dsimp [m]; have := qp.pos; positivity
  have cop (i : Fin 4) (hi : i<3) : (p i).Coprime r :=
    (Nat.coprime_primes (hp i) (hp 3)).mpr (ord hi).ne
  have cm : m.Coprime r := by
    dsimp only [m]
    have r3 : (3:ℕ).Coprime r := a ▸ cop 0 (by decide)
    have r5 : (5:ℕ).Coprime r := b ▸ cop 1 (by decide)
    exact Nat.coprime_mul_iff_left.mpr ⟨Nat.coprime_mul_iff_left.mpr
      ⟨r3.pow_left _,r5.pow_left _⟩,(cop 2 (by decide)).pow_left _⟩
  have h0 := low 0
  have h1 := low 1
  have h2 := low 2
  have mb : m≤195^threshold := cofactor_size _ _ _ _ _ h0.le h1.le h2.le q13
  have divbound := OMA.OddCofactor245212.last_le hm (hp 3) cm (positive 3) (fact ▸ eq)
  exact divbound.trans (bounded threshold m mb)

end OMA.OddFaces245212
