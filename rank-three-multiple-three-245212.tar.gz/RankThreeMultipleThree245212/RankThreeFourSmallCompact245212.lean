import RankThreeFourSmallFar245212

/-! Dyadic last-prime ranges and the first-three-term divisor-count bound
keep the unrestricted cofactor test inexpensive near an Euler pole. -/
namespace OMA.RankThreeFourSmallCompact245212
open Nat ArithmeticFunction OMA.Smooth245212 OMA.CofactorEulerPair245212
open OMA.RankThreeFourSmallBounds245212 OMA.RankThreeFourSmallDecision245212
open OMA.RankThreeFourSmallBand245212 OMA.RankThreeFourSmallHarmonic245212
open OMA.RankThreeFourSmallNear245212 OMA.RankThreeFourSmallFar245212
open OMA.RankThreeFourSmallFast245212 (quick quick_sound)
open scoped ArithmeticFunction.sigma
open private OMA.CofactorEulerPair245212.checked from CofactorEulerDecision245212

def near (h A S T p Q : ℕ) :=
  if Q≤p+256 then every (p+1) Q (quick h A S T p) else
  ((2*T).primeFactorsList.all fun r=>decide (r≤p)) && every 1 (nearCap h A S p Q) (movingRow A S T p)

theorem near_sound {h p q a d Q : ℕ} (hh : 0<h) (hp : p.Prime) (hq : q.Prime)
    (op : 3≤p) (cp : h.Coprime p) (cq : h.Coprime q) (pq : p<q) (ap : 0<a) (dp : 0<d)
    (qr : q≤Q) (ck : near h (W h) (σ 1 h) (h*σ 0 h) p Q=true)
    (eqn : OeisA245212.a (h*p^a*q^d)=(σ 1 (h*p^a*q^d):ℤ)) : False := by
  unfold near at ck
  split at ck
  · exact quick_sound hh hp hq op cp cq pq ap dp (OMA.CofactorEulerPair245212.checked ck pq qr) eqn
  · simp only [Bool.and_eq_true,List.all_eq_true,decide_eq_true_eq] at ck
    have pos:=sigma_pos 0 h hh.ne'
    have good : ¬q∣2*(h*σ 0 h) := fun dv=>pq.not_ge (ck.1 q (Nat.mem_primeFactors_iff_mem_primeFactorsList.mp (hq.mem_primeFactors dv (by positivity))))
    have small:=near_bound hh hp hq op cp cq pq ap dp qr good eqn
    exact moving_row_sound hh hp hq (by omega) cp cq pq dp (OMA.CofactorEulerPair245212.checked ck.2 ap small) eqn

def capD (A S H p : ℕ) := budget A S H p 1 (lenD A S p)

theorem capD_sound {h p q b d : ℕ} (hh : 0<h) (hp : p.Prime) (hq : q.Prime)
    (cp : h.Coprime p) (cq : h.Coprime q) (pq : p<q) (bp : 0<b) (dp : 0<d)
    (eqn : OeisA245212.a (h*p^b*q^d)=(σ 1 (h*p^b*q^d):ℤ))
    (prior : d≤lenD (W h) (σ 1 h) p) : d≤capD (W h) (σ 1 h) (2*(h*σ 0 h)) p := by
  let A:=W h
  let S:=σ 1 h
  let H:=2*(h*σ 0 h)
  let L:=(b+1)*(d+1)
  obtain ⟨pos,cut⟩:=count_cap hh hp hq cp cq pq bp dp eqn
  change S<(H-A)*L at pos
  change p*((H-A)*L-S)≤2*H*L at cut
  unfold capD budget
  split
  next high =>
    change 2*H<p*(H-A) at high
    have diff:=Nat.sub_add_cancel high.le
    have rest:=Nat.sub_add_cancel pos.le
    have x : L*(p*(H-A)-2*H)≤p*S := by
      nlinarith only [cut,congrArg (fun x:ℕ=>L*x) diff,congrArg (fun x:ℕ=>p*x) rest]
    have l := (Nat.le_div_iff_mul_le (Nat.sub_pos_of_lt high)).mpr x
    have two : (d+1)*2≤L := by dsimp [L]; nlinarith only [Nat.mul_le_mul_right (d+1) (show 2≤b+1 by omega)]
    have both:=(Nat.le_div_iff_mul_le (by decide : 0<2)).mpr (two.trans l)
    apply le_min prior
    change d≤p*S/(p*(H-A)-2*H)/2-1
    omega
  next _ => exact prior

def smallFar (A S T p R BB d : ℕ) :=
  let B:=budget A S (2*T) p d BB
  if B=0 then true else if B≤64 then band A S T p R B d else clipped A S T p R B d
def run (h A S T p : ℕ) :=
  if ¬p.Prime ∨ ¬h.Coprime p then true else
  if 2*T*(p-1)<A*p then every 1 (2*A/(A*p-2*T*(p-1))) (movingRow A S T p) else
  if A*p<2*T*(p-1) then
    near h A S T p (capQ A T p) &&
    every 1 (capD A S (2*T) p) (smallFar A S T p (max (p+1) (capQ A T p+1)) (lenB A S T p))
  else false

theorem sound {h p q a d : ℕ} (hh : 0<h) (hp : p.Prime) (hq : q.Prime) (op : 3≤p)
    (cp : h.Coprime p) (cq : h.Coprime q) (pq : p<q) (ap : 0<a) (dp : 0<d)
    (ck : run h (W h) (σ 1 h) (h*σ 0 h) p=true) :
    OeisA245212.a (h*p^a*q^d)≠(σ 1 (h*p^a*q^d):ℤ) := by
  intro eqn
  let A:=W h
  let S:=σ 1 h
  let T:=h*σ 0 h
  have b : Bal A S (2*T) p q a d := by simpa [A,S,T,Bal] using normalized hh hp hq cp cq pq.ne eqn
  have wp : 0<A := by
    dsimp [A];rw [w_apply]
    exact Finset.sum_pos' (fun _ _=>Nat.zero_le _) ⟨1,Nat.one_mem_divisors.mpr hh.ne',by simp⟩
  have eligible : ¬(¬p.Prime ∨ ¬h.Coprime p) := by tauto
  change run h A S T p=true at ck
  rw [run,if_neg eligible] at ck
  by_cases high : 2*T*(p-1)<A*p
  · rw [if_pos high] at ck
    have sh:=short_first hp hq high (strict hp hq (sigma_pos 1 h hh.ne') b)
    exact moving_row_sound hh hp hq (by omega) cp cq pq dp (OMA.CofactorEulerPair245212.checked ck ap (by omega)) eqn
  rw [if_neg high] at ck
  by_cases under : A*p<2*T*(p-1)
  · rw [if_pos under,Bool.and_eq_true] at ck
    by_cases qr : q≤capQ A T p
    · exact near_sound hh hp hq op cp cq pq ap dp qr ck.1 eqn
    have sh := under_first hp hq b under
    have eb : a≤lenB A S T p := by change a≤4*S*(p-1)/_; change ¬q≤1+2*A*p/_ at qr; omega
    have low : A*p*q≤2*T*(p-1)*(q-1) := by
      let G:=2*T*(p-1)-A*p
      have val:=Nat.sub_add_cancel under.le
      have gs : 0<G := Nat.sub_pos_of_lt under
      have qq : 2*A*p/G+1≤q-1 := by change ¬q≤1+2*A*p/G at qr;omega
      have less := (Nat.div_lt_iff_lt_mul gs).mp (by omega : 2*A*p/G<q-1)
      have v:=Nat.sub_add_cancel (by omega : 1≤q)
      nlinarith only [less,congrArg (·*(q-1)) val,congrArg (A*p*·) v,Nat.zero_le (A*p)]
    have ed:=(Nat.le_div_iff_mul_le (Nat.mul_pos wp hq.pos)).mp (under_pair hp hq wp b low)
    have grow : (d+1)*(A*q)≤(2*(A+S*(p-1)))*q := by
      nlinarith only [ed,Nat.mul_le_mul_left (S*(p-1)) (Nat.sub_le q 1),Nat.le_mul_of_pos_right A hq.pos]
    have e0 : (d+1)*A≤2*(A+S*(p-1)) := Nat.le_of_mul_le_mul_right (by simpa only [mul_assoc] using grow) hq.pos
    have small : d≤lenD A S p := (Nat.le_succ _).trans ((Nat.le_div_iff_mul_le wp).mpr e0)
    have atD:=OMA.CofactorEulerPair245212.checked ck.2 dp (capD_sound hh hp hq cp cq pq ap dp eqn small)
    have bounded:=budget_ge hh hp hq cp cq pq ap dp eb eqn
    change a≤budget A S (2*T) p d (lenB A S T p) at bounded
    rw [smallFar,if_neg (Nat.ne_of_gt (ap.trans_le bounded))] at atD
    split at atD
    · exact band_sound hh hp hq cp cq pq ap dp (max_le pq (by omega)) bounded atD eqn
    · exact clipped_sound hh hp hq op cp cq pq ap dp (max_le pq (by omega)) bounded atD eqn
  · simp [under] at ck

def cert (a : ℕ) :=
  let A:=17*OMA.Large245212.wt 3 a
  let S:=7*OMA.Large245212.sig 3 a
  let T:=12*OMA.Large245212.tax 3 a
  every 5 (primeCut A S (2*T)) (run (4*3^a) A S T)

end OMA.RankThreeFourSmallCompact245212
