import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_293_0 : every 294 92 (quick 96 2247 252 1152 293)=true := by decide +kernel
private theorem b96_293_1 : every 1 25 (far 96 2247 252 1152 293 294 20)=true := by decide +kernel
private theorem b96_293_2 : every 26 50 (far 96 2247 252 1152 293 294 20)=true := by decide +kernel
private theorem b96_293_3 : every 51 67 (far 96 2247 252 1152 293 294 20)=true := by decide +kernel
private theorem r96_293 : every 293 293 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 293=true := by change (every 294 92 (quick 96 2247 252 1152 293) && every 1 67 (far 96 2247 252 1152 293 294 20))=true; rw [Bool.and_eq_true]; exact ⟨b96_293_0,(joinEvery b96_293_1 (joinEvery b96_293_2 b96_293_3))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=293 by omega] using yes
private theorem b96_293_4 : every 294 306 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_293_5 : every 308 91 (quick 96 2247 252 1152 307)=true := by decide +kernel
private theorem b96_293_6 : every 1 25 (far 96 2247 252 1152 307 308 20)=true := by decide +kernel
private theorem b96_293_7 : every 26 50 (far 96 2247 252 1152 307 308 20)=true := by decide +kernel
private theorem b96_293_8 : every 51 70 (far 96 2247 252 1152 307 308 20)=true := by decide +kernel
private theorem r96_307 : every 307 307 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 307=true := by change (every 308 91 (quick 96 2247 252 1152 307) && every 1 70 (far 96 2247 252 1152 307 308 20))=true; rw [Bool.and_eq_true]; exact ⟨b96_293_5,(joinEvery b96_293_6 (joinEvery b96_293_7 b96_293_8))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=307 by omega] using yes
private theorem b96_293_9 : every 308 310 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_293_10 : every 312 91 (quick 96 2247 252 1152 311)=true := by decide +kernel
private theorem b96_293_11 : every 1 25 (far 96 2247 252 1152 311 312 20)=true := by decide +kernel
private theorem b96_293_12 : every 26 50 (far 96 2247 252 1152 311 312 20)=true := by decide +kernel
private theorem b96_293_13 : every 51 71 (far 96 2247 252 1152 311 312 20)=true := by decide +kernel
private theorem r96_311 : every 311 311 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 311=true := by change (every 312 91 (quick 96 2247 252 1152 311) && every 1 71 (far 96 2247 252 1152 311 312 20))=true; rw [Bool.and_eq_true]; exact ⟨b96_293_10,(joinEvery b96_293_11 (joinEvery b96_293_12 b96_293_13))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=311 by omega] using yes
private theorem b96_293_14 : every 312 312 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_293_15 : every 314 91 (quick 96 2247 252 1152 313)=true := by decide +kernel
private theorem b96_293_16 : every 1 25 (far 96 2247 252 1152 313 314 20)=true := by decide +kernel
private theorem b96_293_17 : every 26 50 (far 96 2247 252 1152 313 314 20)=true := by decide +kernel
private theorem b96_293_18 : every 51 71 (far 96 2247 252 1152 313 314 20)=true := by decide +kernel
private theorem r96_313 : every 313 313 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 313=true := by change (every 314 91 (quick 96 2247 252 1152 313) && every 1 71 (far 96 2247 252 1152 313 314 20))=true; rw [Bool.and_eq_true]; exact ⟨b96_293_15,(joinEvery b96_293_16 (joinEvery b96_293_17 b96_293_18))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=313 by omega] using yes
private theorem b96_293_19 : every 314 316 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_293_316 : every 293 316 (run 96 2247 252 1152)=true := (joinEvery (joinEvery (joinEvery r96_293 b96_293_4) (joinEvery r96_307 b96_293_9)) (joinEvery (joinEvery r96_311 b96_293_14) (joinEvery r96_313 b96_293_19)))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_293_316
