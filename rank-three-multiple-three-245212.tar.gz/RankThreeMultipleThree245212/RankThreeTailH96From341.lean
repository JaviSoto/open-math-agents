import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_341_0 : every 341 346 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_341_1 : every 348 90 (quick 96 2247 252 1152 347)=true := by decide +kernel
private theorem b96_341_2 : every 1 25 (far 96 2247 252 1152 347 348 19)=true := by decide +kernel
private theorem b96_341_3 : every 26 50 (far 96 2247 252 1152 347 348 19)=true := by decide +kernel
private theorem b96_341_4 : every 51 75 (far 96 2247 252 1152 347 348 19)=true := by decide +kernel
private theorem b96_341_5 : every 76 79 (far 96 2247 252 1152 347 348 19)=true := by decide +kernel
private theorem r96_347 : every 347 347 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 347=true := by change (every 348 90 (quick 96 2247 252 1152 347) && every 1 79 (far 96 2247 252 1152 347 348 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_341_1,(joinEvery (joinEvery b96_341_2 b96_341_3) (joinEvery b96_341_4 b96_341_5))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=347 by omega] using yes
private theorem b96_341_6 : every 348 348 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_341_7 : every 350 90 (quick 96 2247 252 1152 349)=true := by decide +kernel
private theorem b96_341_8 : every 1 25 (far 96 2247 252 1152 349 350 19)=true := by decide +kernel
private theorem b96_341_9 : every 26 50 (far 96 2247 252 1152 349 350 19)=true := by decide +kernel
private theorem b96_341_10 : every 51 75 (far 96 2247 252 1152 349 350 19)=true := by decide +kernel
private theorem b96_341_11 : every 76 80 (far 96 2247 252 1152 349 350 19)=true := by decide +kernel
private theorem r96_349 : every 349 349 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 349=true := by change (every 350 90 (quick 96 2247 252 1152 349) && every 1 80 (far 96 2247 252 1152 349 350 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_341_7,(joinEvery (joinEvery b96_341_8 b96_341_9) (joinEvery b96_341_10 b96_341_11))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=349 by omega] using yes
private theorem b96_341_12 : every 350 352 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_341_13 : every 354 90 (quick 96 2247 252 1152 353)=true := by decide +kernel
private theorem b96_341_14 : every 1 25 (far 96 2247 252 1152 353 354 19)=true := by decide +kernel
private theorem b96_341_15 : every 26 50 (far 96 2247 252 1152 353 354 19)=true := by decide +kernel
private theorem b96_341_16 : every 51 75 (far 96 2247 252 1152 353 354 19)=true := by decide +kernel
private theorem b96_341_17 : every 76 80 (far 96 2247 252 1152 353 354 19)=true := by decide +kernel
private theorem r96_353 : every 353 353 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 353=true := by change (every 354 90 (quick 96 2247 252 1152 353) && every 1 80 (far 96 2247 252 1152 353 354 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_341_13,(joinEvery (joinEvery b96_341_14 b96_341_15) (joinEvery b96_341_16 b96_341_17))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=353 by omega] using yes
private theorem b96_341_18 : every 354 358 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_341_19 : every 360 89 (quick 96 2247 252 1152 359)=true := by decide +kernel
private theorem b96_341_20 : every 1 25 (far 96 2247 252 1152 359 360 19)=true := by decide +kernel
private theorem b96_341_21 : every 26 50 (far 96 2247 252 1152 359 360 19)=true := by decide +kernel
private theorem b96_341_22 : every 51 75 (far 96 2247 252 1152 359 360 19)=true := by decide +kernel
private theorem b96_341_23 : every 76 82 (far 96 2247 252 1152 359 360 19)=true := by decide +kernel
private theorem r96_359 : every 359 359 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 359=true := by change (every 360 89 (quick 96 2247 252 1152 359) && every 1 82 (far 96 2247 252 1152 359 360 19))=true; rw [Bool.and_eq_true]; exact ⟨b96_341_19,(joinEvery (joinEvery b96_341_20 b96_341_21) (joinEvery b96_341_22 b96_341_23))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=359 by omega] using yes
private theorem b96_341_24 : every 360 364 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_341_364 : every 341 364 (run 96 2247 252 1152)=true := (joinEvery (joinEvery (joinEvery b96_341_0 r96_347) (joinEvery b96_341_6 r96_349)) (joinEvery (joinEvery b96_341_12 r96_353) (joinEvery b96_341_18 (joinEvery r96_359 b96_341_24))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_341_364
