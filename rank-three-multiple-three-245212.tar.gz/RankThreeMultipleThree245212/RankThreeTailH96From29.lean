import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b96_29_0 : every 1 6 (movingRow 2247 252 1152 29)=true := by decide +kernel
private theorem r96_29 : every 29 29 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 29=true := b96_29_0
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=29 by omega] using yes
private theorem b96_29_1 : every 30 30 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_29_2 : every 1 8 (movingRow 2247 252 1152 31)=true := by decide +kernel
private theorem r96_31 : every 31 31 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 31=true := b96_29_2
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=31 by omega] using yes
private theorem b96_29_3 : every 32 36 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_29_4 : every 1 23 (movingRow 2247 252 1152 37)=true := by decide +kernel
private theorem r96_37 : every 37 37 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 37=true := b96_29_4
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=37 by omega] using yes
private theorem b96_29_5 : every 38 40 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_29_6 : every 42 222 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_7 : every 223 396 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_8 : every 397 579 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_9 : every 580 756 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_10 : every 757 940 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_11 : every 941 1116 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_12 : every 1117 1302 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_13 : every 1303 1492 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_14 : every 1493 1678 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_15 : every 1679 1870 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_16 : every 1871 2050 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_17 : every 2051 2238 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_18 : every 2239 2408 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_19 : every 2409 2608 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_20 : every 2609 2776 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_21 : every 2777 2968 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_22 : every 2969 3181 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_23 : every 3182 3372 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_24 : every 3373 3570 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_25 : every 3571 3766 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_26 : every 3767 3961 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_27 : every 3962 4158 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_28 : every 4159 4362 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_29 : every 4363 4566 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_30 : every 4567 4779 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_31 : every 4780 4974 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_32 : every 4975 5178 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_33 : every 5179 5398 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_34 : every 5399 5584 (quick 96 2247 252 1152 41)=true := by decide +kernel
private theorem b96_29_35 : every 1 10 (far 96 2247 252 1152 41 5585 1221)=true := by decide +kernel
private theorem r96_41 : every 41 41 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 41=true := by change (every 42 5584 (quick 96 2247 252 1152 41) && every 1 10 (far 96 2247 252 1152 41 5585 1221))=true; rw [Bool.and_eq_true]; exact ⟨(joinEvery (joinEvery (joinEvery (joinEvery b96_29_6 (joinEvery b96_29_7 b96_29_8)) (joinEvery (joinEvery b96_29_9 b96_29_10) (joinEvery b96_29_11 b96_29_12))) (joinEvery (joinEvery b96_29_13 (joinEvery b96_29_14 b96_29_15)) (joinEvery (joinEvery b96_29_16 b96_29_17) (joinEvery b96_29_18 b96_29_19)))) (joinEvery (joinEvery (joinEvery b96_29_20 (joinEvery b96_29_21 b96_29_22)) (joinEvery (joinEvery b96_29_23 b96_29_24) (joinEvery b96_29_25 b96_29_26))) (joinEvery (joinEvery (joinEvery b96_29_27 b96_29_28) (joinEvery b96_29_29 b96_29_30)) (joinEvery (joinEvery b96_29_31 b96_29_32) (joinEvery b96_29_33 b96_29_34))))),b96_29_35⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=41 by omega] using yes
private theorem b96_29_36 : every 42 42 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_29_37 : every 44 224 (quick 96 2247 252 1152 43)=true := by decide +kernel
private theorem b96_29_38 : every 225 400 (quick 96 2247 252 1152 43)=true := by decide +kernel
private theorem b96_29_39 : every 401 586 (quick 96 2247 252 1152 43)=true := by decide +kernel
private theorem b96_29_40 : every 587 750 (quick 96 2247 252 1152 43)=true := by decide +kernel
private theorem b96_29_41 : every 751 920 (quick 96 2247 252 1152 43)=true := by decide +kernel
private theorem b96_29_42 : every 921 1090 (quick 96 2247 252 1152 43)=true := by decide +kernel
private theorem b96_29_43 : every 1091 1270 (quick 96 2247 252 1152 43)=true := by decide +kernel
private theorem b96_29_44 : every 1271 1315 (quick 96 2247 252 1152 43)=true := by decide +kernel
private theorem b96_29_45 : every 1 11 (far 96 2247 252 1152 43 1316 288)=true := by decide +kernel
private theorem r96_43 : every 43 43 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 43=true := by change (every 44 1315 (quick 96 2247 252 1152 43) && every 1 11 (far 96 2247 252 1152 43 1316 288))=true; rw [Bool.and_eq_true]; exact ⟨(joinEvery (joinEvery (joinEvery b96_29_37 b96_29_38) (joinEvery b96_29_39 b96_29_40)) (joinEvery (joinEvery b96_29_41 b96_29_42) (joinEvery b96_29_43 b96_29_44))),b96_29_45⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=43 by omega] using yes
private theorem b96_29_46 : every 44 46 (run 96 2247 252 1152)=true := by decide +kernel
private theorem b96_29_47 : every 48 226 (quick 96 2247 252 1152 47)=true := by decide +kernel
private theorem b96_29_48 : every 227 382 (quick 96 2247 252 1152 47)=true := by decide +kernel
private theorem b96_29_49 : every 383 538 (quick 96 2247 252 1152 47)=true := by decide +kernel
private theorem b96_29_50 : every 539 564 (quick 96 2247 252 1152 47)=true := by decide +kernel
private theorem b96_29_51 : every 1 12 (far 96 2247 252 1152 47 565 123)=true := by decide +kernel
private theorem r96_47 : every 47 47 (run 96 2247 252 1152)=true := by
  have yes : run 96 2247 252 1152 47=true := by change (every 48 564 (quick 96 2247 252 1152 47) && every 1 12 (far 96 2247 252 1152 47 565 123))=true; rw [Bool.and_eq_true]; exact ⟨(joinEvery (joinEvery b96_29_47 b96_29_48) (joinEvery b96_29_49 b96_29_50)),b96_29_51⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=47 by omega] using yes
private theorem b96_29_52 : every 48 52 (run 96 2247 252 1152)=true := by decide +kernel
theorem span96_29_52 : every 29 52 (run 96 2247 252 1152)=true := (joinEvery (joinEvery (joinEvery r96_29 (joinEvery b96_29_1 r96_31)) (joinEvery b96_29_3 (joinEvery r96_37 b96_29_5))) (joinEvery (joinEvery r96_41 (joinEvery b96_29_36 r96_43)) (joinEvery b96_29_46 (joinEvery r96_47 b96_29_52))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span96_29_52
