import OddFaces245212

/-! Generated face certificates. Regenerate with odd_boundary_245212.py --lean. -/
namespace OMA.OddFaces245212
open OMA.Smooth245212
set_option maxHeartbeats 10000000
set_option maxRecDepth 100000
def initial : Box := fun _ => ⟨1,none⟩
private def b70l : Box := left initial 1 3
private def t70l : Tree := (.split 2 3 .leaf (.split 1 1 .leaf (.split 2 9 (.split 1 2 .leaf (.split 2 5 .leaf .leaf)) (.split 1 2 (.split 2 21 .leaf (.split 2 45 .leaf (.split 2 93 (.split 2 61 (.split 2 52 (.split 2 48 .leaf (.split 2 50 (.split 2 49 .leaf .leaf) .leaf)) .leaf) .leaf) .leaf))) .leaf))))
private theorem h70l : Good 7 0 b70l := fun _ h => sound (by decide) 0 t70l (by decide +kernel) h
private def b70r : Box := right initial 1 3
private def t70r : Tree := (.split 2 3 (.split 1 9 (.split 2 1 .leaf (.split 1 5 (.split 2 2 .leaf (.split 1 4 .leaf .leaf)) (.split 2 2 (.split 1 7 (.split 1 6 .leaf .leaf) .leaf) .leaf))) (.split 2 1 (.split 1 21 .leaf (.split 1 45 .leaf (.split 1 93 (.split 1 61 (.split 1 52 .leaf (.split 1 56 (.split 1 54 .leaf (.split 1 55 .leaf .leaf)) .leaf)) .leaf) .leaf))) .leaf)) .leaf)
private theorem h70r : Good 7 0 b70r := fun _ h => sound (by decide) 0 t70r (by decide +kernel) h
private theorem h70 : Good 7 0 initial := bisect initial 1 3 h70l h70r
private def b71l : Box := left initial 0 3
private def t71l : Tree := .leaf
private theorem h71l : Good 7 1 b71l := fun _ h => sound (by decide) 1 t71l (by decide +kernel) h
private def b71r : Box := right initial 0 3
private def b71rl : Box := left b71r 0 9
private def t71rl : Tree := (.split 2 3 .leaf (.split 0 5 (.split 2 9 .leaf (.split 0 4 .leaf (.split 2 21 .leaf (.split 2 45 .leaf (.split 2 93 (.split 2 61 (.split 2 52 .leaf (.split 2 56 .leaf (.split 2 58 .leaf (.split 2 59 .leaf (.split 2 60 .leaf .leaf))))) .leaf) .leaf))))) (.split 2 9 (.split 0 7 (.split 2 5 .leaf (.split 0 6 .leaf .leaf)) (.split 2 5 (.split 0 8 (.split 2 4 .leaf .leaf) .leaf) .leaf)) .leaf)))
private theorem h71rl : Good 7 1 b71rl := fun _ h => sound (by decide) 1 t71rl (by decide +kernel) h
private def b71rr : Box := right b71r 0 9
private def t71rr : Tree := (.split 2 3 (.split 0 21 (.split 2 1 .leaf (.split 0 13 (.split 2 2 .leaf .leaf) (.split 2 2 (.split 0 16 (.split 0 14 .leaf .leaf) .leaf) .leaf))) (.split 2 1 (.split 0 45 .leaf (.split 0 93 .leaf (.split 0 189 (.split 0 125 (.split 0 107 .leaf (.split 0 115 (.split 0 111 .leaf .leaf) .leaf)) .leaf) .leaf))) .leaf)) .leaf)
private theorem h71rr : Good 7 1 b71rr := fun _ h => sound (by decide) 1 t71rr (by decide +kernel) h
private theorem h71r : Good 7 1 b71r := bisect b71r 0 9 h71rl h71rr
private theorem h71 : Good 7 1 initial := bisect initial 0 3 h71l h71r
private def b72l : Box := left initial 0 3
private def t72l : Tree := .leaf
private theorem h72l : Good 7 2 b72l := fun _ h => sound (by decide) 2 t72l (by decide +kernel) h
private def b72r : Box := right initial 0 3
private def b72rl : Box := left b72r 1 3
private def t72rl : Tree := (.split 0 9 .leaf (.split 1 1 .leaf (.split 0 21 (.split 0 13 .leaf (.split 1 2 .leaf (.split 0 16 .leaf (.split 0 18 .leaf (.split 0 19 .leaf .leaf))))) (.split 0 45 (.split 1 2 .leaf .leaf) (.split 1 2 (.split 0 93 .leaf (.split 0 189 (.split 0 125 .leaf (.split 0 151 (.split 0 137 .leaf (.split 0 144 .leaf (.split 0 147 .leaf (.split 0 149 .leaf .leaf)))) .leaf)) .leaf)) .leaf)))))
private theorem h72rl : Good 7 2 b72rl := fun _ h => sound (by decide) 2 t72rl (by decide +kernel) h
private def b72rr : Box := right b72r 1 3
private def b72rrl : Box := left b72rr 0 9
private def b72rrll : Box := left b72rrl 0 5
private def t72rrll : Tree := (.split 1 9 .leaf (.split 1 21 .leaf (.split 0 4 .leaf (.split 1 45 .leaf (.split 1 93 (.split 1 61 .leaf (.split 1 74 .leaf (.split 1 83 .leaf (.split 1 88 .leaf (.split 1 90 .leaf .leaf))))) .leaf)))))
private theorem h72rrll : Good 7 2 b72rrll := fun _ h => sound (by decide) 2 t72rrll (by decide +kernel) h
private def b72rrlr : Box := right b72rrl 0 5
private def t72rrlr : Tree := (.split 1 9 (.split 0 7 .leaf (.split 1 5 .leaf (.split 1 7 (.split 0 8 (.split 1 6 .leaf .leaf) .leaf) .leaf))) (.split 0 7 (.split 1 21 (.split 1 13 (.split 0 6 .leaf .leaf) (.split 0 6 (.split 1 16 (.split 1 14 .leaf (.split 1 15 .leaf .leaf)) .leaf) .leaf)) .leaf) .leaf))
private theorem h72rrlr : Good 7 2 b72rrlr := fun _ h => sound (by decide) 2 t72rrlr (by decide +kernel) h
private theorem h72rrl : Good 7 2 b72rrl := bisect b72rrl 0 5 h72rrll h72rrlr
private def b72rrr : Box := right b72rr 0 9
private def t72rrr : Tree := (.split 0 21 (.split 1 9 (.split 0 13 (.split 1 5 (.split 0 11 (.split 1 4 .leaf .leaf) (.split 1 4 (.split 0 12 .leaf .leaf) .leaf)) .leaf) .leaf) .leaf) .leaf)
private theorem h72rrr : Good 7 2 b72rrr := fun _ h => sound (by decide) 2 t72rrr (by decide +kernel) h
private theorem h72rr : Good 7 2 b72rr := bisect b72rr 0 9 h72rrl h72rrr
private theorem h72r : Good 7 2 b72r := bisect b72r 1 3 h72rl h72rr
private theorem h72 : Good 7 2 initial := bisect initial 0 3 h72l h72r
private def b110l : Box := left initial 1 3
private def t110l : Tree := .leaf
private theorem h110l : Good 11 0 b110l := fun _ h => sound (by decide) 0 t110l (by decide +kernel) h
private def b110r : Box := right initial 1 3
private def b110rl : Box := left b110r 1 9
private def t110rl : Tree := (.split 2 3 .leaf (.split 1 5 .leaf (.split 2 9 .leaf (.split 1 7 .leaf (.split 2 21 (.split 2 13 .leaf (.split 1 8 .leaf (.split 2 16 .leaf (.split 2 18 (.split 2 17 .leaf .leaf) .leaf)))) (.split 2 45 (.split 1 8 (.split 2 29 .leaf (.split 2 36 .leaf (.split 2 40 (.split 2 38 (.split 2 37 .leaf .leaf) .leaf) .leaf))) .leaf) .leaf))))))
private theorem h110rl : Good 11 0 b110rl := fun _ h => sound (by decide) 0 t110rl (by decide +kernel) h
private def b110rr : Box := right b110r 1 9
private def b110rrl : Box := left b110rr 2 3
private def t110rrl : Tree := (.split 1 21 .leaf (.split 2 1 .leaf (.split 1 45 (.split 2 2 .leaf (.split 1 29 .leaf (.split 1 36 .leaf (.split 1 40 .leaf (.split 1 42 .leaf (.split 1 43 .leaf (.split 1 44 .leaf .leaf))))))) (.split 2 2 .leaf .leaf))))
private theorem h110rrl : Good 11 0 b110rrl := fun _ h => sound (by decide) 0 t110rrl (by decide +kernel) h
private def b110rrr : Box := right b110rr 2 3
private def b110rrrl : Box := left b110rrr 1 21
private def t110rrrl : Tree := (.split 2 9 (.split 1 13 (.split 2 5 .leaf (.split 1 11 .leaf (.split 2 7 (.split 2 6 .leaf (.split 1 12 .leaf .leaf)) .leaf))) (.split 2 5 (.split 1 16 .leaf (.split 2 4 .leaf (.split 1 18 (.split 1 17 .leaf .leaf) .leaf))) (.split 1 16 (.split 2 7 (.split 1 14 (.split 2 6 .leaf .leaf) .leaf) .leaf) .leaf))) (.split 1 13 (.split 2 21 (.split 1 11 (.split 2 13 (.split 1 10 (.split 2 11 .leaf .leaf) .leaf) .leaf) .leaf) .leaf) .leaf))
private theorem h110rrrl : Good 11 0 b110rrrl := fun _ h => sound (by decide) 0 t110rrrl (by decide +kernel) h
private def b110rrrr : Box := right b110rrr 1 21
private def t110rrrr : Tree := (.split 2 9 (.split 1 45 (.split 2 5 (.split 1 29 (.split 2 4 (.split 1 25 (.split 1 23 (.split 1 22 .leaf .leaf) .leaf) .leaf) .leaf) .leaf) .leaf) .leaf) .leaf)
private theorem h110rrrr : Good 11 0 b110rrrr := fun _ h => sound (by decide) 0 t110rrrr (by decide +kernel) h
private theorem h110rrr : Good 11 0 b110rrr := bisect b110rrr 1 21 h110rrrl h110rrrr
private theorem h110rr : Good 11 0 b110rr := bisect b110rr 2 3 h110rrl h110rrr
private theorem h110r : Good 11 0 b110r := bisect b110r 1 9 h110rl h110rr
private theorem h110 : Good 11 0 initial := bisect initial 1 3 h110l h110r
private def b111l : Box := left initial 0 3
private def t111l : Tree := .leaf
private theorem h111l : Good 11 1 b111l := fun _ h => sound (by decide) 1 t111l (by decide +kernel) h
private def b111r : Box := right initial 0 3
private def b111rl : Box := left b111r 0 9
private def t111rl : Tree := .leaf
private theorem h111rl : Good 11 1 b111rl := fun _ h => sound (by decide) 1 t111rl (by decide +kernel) h
private def b111rr : Box := right b111r 0 9
private def b111rrl : Box := left b111rr 0 21
private def b111rrll : Box := left b111rrl 2 3
private def t111rrll : Tree := .leaf
private theorem h111rrll : Good 11 1 b111rrll := fun _ h => sound (by decide) 1 t111rrll (by decide +kernel) h
private def b111rrlr : Box := right b111rrl 2 3
private def b111rrlrl : Box := left b111rrlr 0 13
private def t111rrlrl : Tree := .leaf
private theorem h111rrlrl : Good 11 1 b111rrlrl := fun _ h => sound (by decide) 1 t111rrlrl (by decide +kernel) h
private def b111rrlrr : Box := right b111rrlr 0 13
private def b111rrlrrl : Box := left b111rrlrr 2 9
private def t111rrlrrl : Tree := .leaf
private theorem h111rrlrrl : Good 11 1 b111rrlrrl := fun _ h => sound (by decide) 1 t111rrlrrl (by decide +kernel) h
private def b111rrlrrr : Box := right b111rrlrr 2 9
private def b111rrlrrrl : Box := left b111rrlrrr 0 16
private def t111rrlrrrl : Tree := (.split 2 21 .leaf (.split 0 14 .leaf (.split 2 45 .leaf (.split 0 15 .leaf (.split 2 93 .leaf (.split 2 189 (.split 2 125 (.split 2 107 .leaf .leaf) .leaf) .leaf))))))
private theorem h111rrlrrrl : Good 11 1 b111rrlrrrl := fun _ h => sound (by decide) 1 t111rrlrrrl (by decide +kernel) h
private def b111rrlrrrr : Box := right b111rrlrrr 0 16
private def t111rrlrrrr : Tree := (.split 2 21 (.split 0 18 .leaf (.split 2 13 (.split 0 19 .leaf (.split 2 11 .leaf (.split 0 20 .leaf .leaf))) (.split 0 19 (.split 2 16 .leaf (.split 2 18 (.split 2 17 .leaf .leaf) .leaf)) (.split 2 16 (.split 0 20 (.split 2 14 .leaf .leaf) .leaf) .leaf)))) (.split 0 18 (.split 2 45 (.split 2 29 (.split 0 17 .leaf (.split 2 25 (.split 2 23 .leaf .leaf) .leaf)) (.split 0 17 (.split 2 36 .leaf (.split 2 40 (.split 2 38 (.split 2 37 .leaf .leaf) .leaf) .leaf)) .leaf)) .leaf) .leaf))
private theorem h111rrlrrrr : Good 11 1 b111rrlrrrr := fun _ h => sound (by decide) 1 t111rrlrrrr (by decide +kernel) h
private theorem h111rrlrrr : Good 11 1 b111rrlrrr := bisect b111rrlrrr 0 16 h111rrlrrrl h111rrlrrrr
private theorem h111rrlrr : Good 11 1 b111rrlrr := bisect b111rrlrr 2 9 h111rrlrrl h111rrlrrr
private theorem h111rrlr : Good 11 1 b111rrlr := bisect b111rrlr 0 13 h111rrlrl h111rrlrr
private theorem h111rrl : Good 11 1 b111rrl := bisect b111rrl 2 3 h111rrll h111rrlr
private def b111rrr : Box := right b111rr 0 21
private def b111rrrl : Box := left b111rrr 2 3
private def t111rrrl : Tree := (.split 0 45 .leaf (.split 2 1 .leaf (.split 0 93 (.split 2 2 .leaf (.split 0 61 .leaf (.split 0 74 .leaf (.split 0 83 .leaf (.split 0 88 .leaf (.split 0 90 .leaf .leaf)))))) (.split 2 2 .leaf .leaf))))
private theorem h111rrrl : Good 11 1 b111rrrl := fun _ h => sound (by decide) 1 t111rrrl (by decide +kernel) h
private def b111rrrr : Box := right b111rrr 2 3
private def b111rrrrl : Box := left b111rrrr 0 45
private def b111rrrrll : Box := left b111rrrrl 2 9
private def t111rrrrll : Tree := (.split 0 29 (.split 2 5 .leaf (.split 0 25 (.split 2 7 .leaf (.split 0 23 .leaf (.split 2 8 (.split 0 24 .leaf .leaf) .leaf))) (.split 2 7 (.split 0 27 (.split 2 6 .leaf (.split 0 26 .leaf .leaf)) (.split 2 6 .leaf .leaf)) .leaf))) (.split 2 5 (.split 0 36 (.split 0 32 .leaf (.split 2 4 .leaf (.split 0 34 .leaf (.split 0 35 .leaf .leaf)))) (.split 2 4 .leaf .leaf)) .leaf))
private theorem h111rrrrll : Good 11 1 b111rrrrll := fun _ h => sound (by decide) 1 t111rrrrll (by decide +kernel) h
private def b111rrrrlr : Box := right b111rrrrl 2 9
private def t111rrrrlr : Tree := (.split 0 29 (.split 2 21 (.split 0 25 (.split 2 13 (.split 0 23 (.split 2 11 (.split 0 22 (.split 2 10 .leaf .leaf) .leaf) .leaf) .leaf) .leaf) .leaf) .leaf) .leaf)
private theorem h111rrrrlr : Good 11 1 b111rrrrlr := fun _ h => sound (by decide) 1 t111rrrrlr (by decide +kernel) h
private theorem h111rrrrl : Good 11 1 b111rrrrl := bisect b111rrrrl 2 9 h111rrrrll h111rrrrlr
private def b111rrrrr : Box := right b111rrrr 0 45
private def t111rrrrr : Tree := (.split 2 9 (.split 0 93 (.split 2 5 (.split 0 61 (.split 0 52 (.split 2 4 (.split 0 48 (.split 0 46 .leaf .leaf) .leaf) .leaf) .leaf) .leaf) .leaf) .leaf) .leaf)
private theorem h111rrrrr : Good 11 1 b111rrrrr := fun _ h => sound (by decide) 1 t111rrrrr (by decide +kernel) h
private theorem h111rrrr : Good 11 1 b111rrrr := bisect b111rrrr 0 45 h111rrrrl h111rrrrr
private theorem h111rrr : Good 11 1 b111rrr := bisect b111rrr 2 3 h111rrrl h111rrrr
private theorem h111rr : Good 11 1 b111rr := bisect b111rr 0 21 h111rrl h111rrr
private theorem h111r : Good 11 1 b111r := bisect b111r 0 9 h111rl h111rr
private theorem h111 : Good 11 1 initial := bisect initial 0 3 h111l h111r
private def b112l : Box := left initial 0 3
private def t112l : Tree := .leaf
private theorem h112l : Good 11 2 b112l := fun _ h => sound (by decide) 2 t112l (by decide +kernel) h
private def b112r : Box := right initial 0 3
private def b112rl : Box := left b112r 1 3
private def t112rl : Tree := .leaf
private theorem h112rl : Good 11 2 b112rl := fun _ h => sound (by decide) 2 t112rl (by decide +kernel) h
private def b112rr : Box := right b112r 1 3
private def b112rrl : Box := left b112rr 0 9
private def t112rrl : Tree := .leaf
private theorem h112rrl : Good 11 2 b112rrl := fun _ h => sound (by decide) 2 t112rrl (by decide +kernel) h
private def b112rrr : Box := right b112rr 0 9
private def b112rrrl : Box := left b112rrr 0 21
private def b112rrrll : Box := left b112rrrl 1 9
private def t112rrrll : Tree := .leaf
private theorem h112rrrll : Good 11 2 b112rrrll := fun _ h => sound (by decide) 2 t112rrrll (by decide +kernel) h
private def b112rrrlr : Box := right b112rrrl 1 9
private def b112rrrlrl : Box := left b112rrrlr 0 13
private def t112rrrlrl : Tree := .leaf
private theorem h112rrrlrl : Good 11 2 b112rrrlrl := fun _ h => sound (by decide) 2 t112rrrlrl (by decide +kernel) h
private def b112rrrlrr : Box := right b112rrrlr 0 13
private def b112rrrlrrl : Box := left b112rrrlrr 1 21
private def t112rrrlrrl : Tree := .leaf
private theorem h112rrrlrrl : Good 11 2 b112rrrlrrl := fun _ h => sound (by decide) 2 t112rrrlrrl (by decide +kernel) h
private def b112rrrlrrr : Box := right b112rrrlrr 1 21
private def b112rrrlrrrl : Box := left b112rrrlrrr 0 16
private def t112rrrlrrrl : Tree := (.split 1 45 .leaf (.split 1 93 .leaf (.split 0 14 .leaf (.split 1 189 .leaf (.split 0 15 .leaf (.split 1 381 (.split 1 253 .leaf (.split 1 304 (.split 1 276 (.split 1 264 .leaf (.split 1 270 .leaf (.split 1 273 (.split 1 271 .leaf .leaf) .leaf))) .leaf) .leaf)) .leaf))))))
private theorem h112rrrlrrrl : Good 11 2 b112rrrlrrrl := fun _ h => sound (by decide) 2 t112rrrlrrrl (by decide +kernel) h
private def b112rrrlrrrr : Box := right b112rrrlrrr 0 16
private def b112rrrlrrrrl : Box := left b112rrrlrrrr 1 45
private def t112rrrlrrrrl : Tree := (.split 0 18 .leaf (.split 1 29 .leaf (.split 0 19 (.split 1 36 .leaf (.split 1 40 .leaf (.split 1 42 .leaf (.split 1 43 .leaf (.split 1 44 .leaf .leaf))))) (.split 1 36 (.split 1 32 (.split 0 20 .leaf (.split 1 30 .leaf (.split 1 31 .leaf .leaf))) (.split 0 20 .leaf .leaf)) .leaf))))
private theorem h112rrrlrrrrl : Good 11 2 b112rrrlrrrrl := fun _ h => sound (by decide) 2 t112rrrlrrrrl (by decide +kernel) h
private def b112rrrlrrrrr : Box := right b112rrrlrrrr 1 45
private def t112rrrlrrrrr : Tree := (.split 0 18 (.split 1 93 (.split 1 61 (.split 0 17 .leaf (.split 1 52 .leaf (.split 1 56 .leaf (.split 1 58 .leaf (.split 1 59 .leaf (.split 1 60 .leaf .leaf)))))) (.split 0 17 .leaf .leaf)) (.split 1 189 (.split 0 17 (.split 1 125 (.split 1 107 (.split 1 100 (.split 1 96 (.split 1 94 .leaf (.split 1 95 .leaf .leaf)) .leaf) .leaf) .leaf) .leaf) .leaf) .leaf)) .leaf)
private theorem h112rrrlrrrrr : Good 11 2 b112rrrlrrrrr := fun _ h => sound (by decide) 2 t112rrrlrrrrr (by decide +kernel) h
private theorem h112rrrlrrrr : Good 11 2 b112rrrlrrrr := bisect b112rrrlrrrr 1 45 h112rrrlrrrrl h112rrrlrrrrr
private theorem h112rrrlrrr : Good 11 2 b112rrrlrrr := bisect b112rrrlrrr 0 16 h112rrrlrrrl h112rrrlrrrr
private theorem h112rrrlrr : Good 11 2 b112rrrlrr := bisect b112rrrlrr 1 21 h112rrrlrrl h112rrrlrrr
private theorem h112rrrlr : Good 11 2 b112rrrlr := bisect b112rrrlr 0 13 h112rrrlrl h112rrrlrr
private theorem h112rrrl : Good 11 2 b112rrrl := bisect b112rrrl 1 9 h112rrrll h112rrrlr
private def b112rrrr : Box := right b112rrr 0 21
private def b112rrrrl : Box := left b112rrrr 1 9
private def t112rrrrl : Tree := (.split 0 45 .leaf (.split 1 5 .leaf (.split 0 93 (.split 1 7 .leaf (.split 0 61 .leaf (.split 0 74 .leaf (.split 1 8 .leaf (.split 0 83 .leaf (.split 0 88 .leaf (.split 0 90 .leaf .leaf))))))) (.split 1 7 .leaf (.split 0 189 (.split 0 125 (.split 1 8 .leaf .leaf) (.split 1 8 .leaf .leaf)) (.split 0 381 (.split 1 8 (.split 0 253 (.split 0 217 (.split 0 202 (.split 0 195 (.split 0 192 (.split 0 190 .leaf (.split 0 191 .leaf .leaf)) .leaf) .leaf) .leaf) .leaf) .leaf) .leaf) .leaf))))))
private theorem h112rrrrl : Good 11 2 b112rrrrl := fun _ h => sound (by decide) 2 t112rrrrl (by decide +kernel) h
private def b112rrrrr : Box := right b112rrrr 1 9
private def b112rrrrrl : Box := left b112rrrrr 0 45
private def b112rrrrrll : Box := left b112rrrrrl 1 21
private def b112rrrrrlll : Box := left b112rrrrrll 0 29
private def t112rrrrrlll : Tree := (.split 1 13 .leaf (.split 0 25 .leaf (.split 1 16 .leaf (.split 1 18 (.split 0 27 .leaf (.split 1 17 .leaf .leaf)) (.split 0 27 (.split 1 19 (.split 0 26 .leaf .leaf) .leaf) .leaf)))))
private theorem h112rrrrrlll : Good 11 2 b112rrrrrlll := fun _ h => sound (by decide) 2 t112rrrrrlll (by decide +kernel) h
private def b112rrrrrllr : Box := right b112rrrrrll 0 29
private def t112rrrrrllr : Tree := (.split 1 13 (.split 0 36 .leaf (.split 1 11 .leaf (.split 0 40 (.split 1 12 .leaf (.split 0 38 .leaf .leaf)) (.split 1 12 (.split 0 42 .leaf (.split 0 43 .leaf .leaf)) .leaf)))) (.split 0 36 (.split 1 16 (.split 0 32 (.split 1 14 .leaf (.split 0 30 .leaf (.split 1 15 .leaf .leaf))) (.split 1 14 (.split 0 34 .leaf (.split 0 35 .leaf .leaf)) .leaf)) .leaf) .leaf))
private theorem h112rrrrrllr : Good 11 2 b112rrrrrllr := fun _ h => sound (by decide) 2 t112rrrrrllr (by decide +kernel) h
private theorem h112rrrrrll : Good 11 2 b112rrrrrll := bisect b112rrrrrll 0 29 h112rrrrrlll h112rrrrrllr
private def b112rrrrrlr : Box := right b112rrrrrl 1 21
private def t112rrrrrlr : Tree := (.split 0 29 (.split 1 45 (.split 0 25 (.split 1 29 (.split 0 23 (.split 1 25 (.split 1 23 .leaf (.split 0 22 .leaf (.split 1 24 .leaf .leaf))) (.split 0 22 (.split 1 27 .leaf .leaf) .leaf)) (.split 1 25 (.split 1 23 (.split 0 24 (.split 1 22 .leaf .leaf) .leaf) .leaf) .leaf)) .leaf) .leaf) .leaf) .leaf)
private theorem h112rrrrrlr : Good 11 2 b112rrrrrlr := fun _ h => sound (by decide) 2 t112rrrrrlr (by decide +kernel) h
private theorem h112rrrrrl : Good 11 2 b112rrrrrl := bisect b112rrrrrl 1 21 h112rrrrrll h112rrrrrlr
private def b112rrrrrr : Box := right b112rrrrr 0 45
private def t112rrrrrr : Tree := (.split 1 21 (.split 0 93 (.split 1 13 (.split 0 61 (.split 1 11 (.split 0 52 (.split 1 10 .leaf (.split 0 48 .leaf (.split 0 50 .leaf .leaf))) (.split 1 10 .leaf .leaf)) .leaf) (.split 1 11 (.split 0 74 (.split 1 10 (.split 0 67 (.split 0 64 (.split 0 62 .leaf (.split 0 63 .leaf .leaf)) .leaf) .leaf) .leaf) .leaf) .leaf)) .leaf) .leaf) .leaf)
private theorem h112rrrrrr : Good 11 2 b112rrrrrr := fun _ h => sound (by decide) 2 t112rrrrrr (by decide +kernel) h
private theorem h112rrrrr : Good 11 2 b112rrrrr := bisect b112rrrrr 0 45 h112rrrrrl h112rrrrrr
private theorem h112rrrr : Good 11 2 b112rrrr := bisect b112rrrr 1 9 h112rrrrl h112rrrrr
private theorem h112rrr : Good 11 2 b112rrr := bisect b112rrr 0 21 h112rrrl h112rrrr
private theorem h112rr : Good 11 2 b112rr := bisect b112rr 0 9 h112rrl h112rrr
private theorem h112r : Good 11 2 b112r := bisect b112r 1 3 h112rl h112rr
private theorem h112 : Good 11 2 initial := bisect initial 0 3 h112l h112r
private def b130l : Box := left initial 1 3
private def t130l : Tree := .leaf
private theorem h130l : Good 13 0 b130l := fun _ h => sound (by decide) 0 t130l (by decide +kernel) h
private def b130r : Box := right initial 1 3
private def b130rl : Box := left b130r 1 9
private def t130rl : Tree := .leaf
private theorem h130rl : Good 13 0 b130rl := fun _ h => sound (by decide) 0 t130rl (by decide +kernel) h
private def b130rr : Box := right b130r 1 9
private def b130rrl : Box := left b130rr 2 3
private def t130rrl : Tree := .leaf
private theorem h130rrl : Good 13 0 b130rrl := fun _ h => sound (by decide) 0 t130rrl (by decide +kernel) h
private def b130rrr : Box := right b130rr 2 3
private def b130rrrl : Box := left b130rrr 1 21
private def b130rrrll : Box := left b130rrrl 2 9
private def t130rrrll : Tree := .leaf
private theorem h130rrrll : Good 13 0 b130rrrll := fun _ h => sound (by decide) 0 t130rrrll (by decide +kernel) h
private def b130rrrlr : Box := right b130rrrl 2 9
private def b130rrrlrl : Box := left b130rrrlr 1 13
private def t130rrrlrl : Tree := .leaf
private theorem h130rrrlrl : Good 13 0 b130rrrlrl := fun _ h => sound (by decide) 0 t130rrrlrl (by decide +kernel) h
private def b130rrrlrr : Box := right b130rrrlr 1 13
private def b130rrrlrrl : Box := left b130rrrlrr 2 21
private def t130rrrlrrl : Tree := (.split 1 16 .leaf (.split 2 13 .leaf (.split 1 18 .leaf (.split 2 16 .leaf (.split 1 19 .leaf (.split 2 18 .leaf (.split 1 20 .leaf (.split 2 19 .leaf .leaf))))))))
private theorem h130rrrlrrl : Good 13 0 b130rrrlrrl := fun _ h => sound (by decide) 0 t130rrrlrrl (by decide +kernel) h
private def b130rrrlrrr : Box := right b130rrrlrr 2 21
private def b130rrrlrrrl : Box := left b130rrrlrrr 1 16
private def t130rrrlrrrl : Tree := (.split 2 45 .leaf (.split 1 14 .leaf (.split 2 93 .leaf (.split 1 15 .leaf (.split 2 189 (.split 2 125 (.split 2 107 .leaf (.split 2 115 .leaf (.split 2 120 (.split 2 117 .leaf (.split 2 118 .leaf (.split 2 119 .leaf .leaf))) .leaf))) .leaf) .leaf)))))
private theorem h130rrrlrrrl : Good 13 0 b130rrrlrrrl := fun _ h => sound (by decide) 0 t130rrrlrrrl (by decide +kernel) h
private def b130rrrlrrrr : Box := right b130rrrlrrr 1 16
private def b130rrrlrrrrl : Box := left b130rrrlrrrr 2 45
private def t130rrrlrrrrl : Tree := (.split 1 18 (.split 2 29 .leaf (.split 2 36 (.split 1 17 .leaf (.split 2 32 .leaf (.split 2 34 .leaf (.split 2 35 .leaf .leaf)))) (.split 1 17 .leaf .leaf))) (.split 2 29 (.split 1 19 (.split 2 25 .leaf (.split 2 27 .leaf .leaf)) (.split 2 25 (.split 1 20 (.split 2 23 (.split 2 22 .leaf .leaf) .leaf) .leaf) .leaf)) .leaf))
private theorem h130rrrlrrrrl : Good 13 0 b130rrrlrrrrl := fun _ h => sound (by decide) 0 t130rrrlrrrrl (by decide +kernel) h
private def b130rrrlrrrrr : Box := right b130rrrlrrrr 2 45
private def t130rrrlrrrrr : Tree := (.split 1 18 (.split 2 93 (.split 2 61 (.split 1 17 (.split 2 52 .leaf (.split 2 56 (.split 2 54 (.split 2 53 .leaf .leaf) .leaf) .leaf)) .leaf) .leaf) .leaf) .leaf)
private theorem h130rrrlrrrrr : Good 13 0 b130rrrlrrrrr := fun _ h => sound (by decide) 0 t130rrrlrrrrr (by decide +kernel) h
private theorem h130rrrlrrrr : Good 13 0 b130rrrlrrrr := bisect b130rrrlrrrr 2 45 h130rrrlrrrrl h130rrrlrrrrr
private theorem h130rrrlrrr : Good 13 0 b130rrrlrrr := bisect b130rrrlrrr 1 16 h130rrrlrrrl h130rrrlrrrr
private theorem h130rrrlrr : Good 13 0 b130rrrlrr := bisect b130rrrlrr 2 21 h130rrrlrrl h130rrrlrrr
private theorem h130rrrlr : Good 13 0 b130rrrlr := bisect b130rrrlr 1 13 h130rrrlrl h130rrrlrr
private theorem h130rrrl : Good 13 0 b130rrrl := bisect b130rrrl 2 9 h130rrrll h130rrrlr
private def b130rrrr : Box := right b130rrr 1 21
private def b130rrrrl : Box := left b130rrrr 2 9
private def b130rrrrll : Box := left b130rrrrl 1 45
private def t130rrrrll : Tree := (.split 2 5 .leaf (.split 1 29 .leaf (.split 2 7 .leaf (.split 1 36 (.split 1 32 .leaf (.split 2 8 .leaf (.split 1 34 .leaf .leaf))) (.split 1 40 (.split 2 8 (.split 1 38 .leaf (.split 1 39 .leaf .leaf)) .leaf) .leaf)))))
private theorem h130rrrrll : Good 13 0 b130rrrrll := fun _ h => sound (by decide) 0 t130rrrrll (by decide +kernel) h
private def b130rrrrlr : Box := right b130rrrrl 1 45
private def t130rrrrlr : Tree := (.split 2 5 (.split 1 93 .leaf (.split 1 189 (.split 2 4 .leaf (.split 1 125 .leaf (.split 1 151 .leaf (.split 1 168 (.split 1 159 .leaf (.split 1 163 .leaf .leaf)) .leaf)))) (.split 2 4 .leaf .leaf))) (.split 1 93 (.split 2 7 (.split 1 61 (.split 2 6 .leaf (.split 1 52 (.split 1 48 .leaf .leaf) .leaf)) (.split 1 74 (.split 2 6 (.split 1 67 .leaf (.split 1 70 (.split 1 68 .leaf (.split 1 69 .leaf .leaf)) .leaf)) .leaf) .leaf)) .leaf) .leaf))
private theorem h130rrrrlr : Good 13 0 b130rrrrlr := fun _ h => sound (by decide) 0 t130rrrrlr (by decide +kernel) h
private theorem h130rrrrl : Good 13 0 b130rrrrl := bisect b130rrrrl 1 45 h130rrrrll h130rrrrlr
private def b130rrrrr : Box := right b130rrrr 2 9
private def b130rrrrrl : Box := left b130rrrrr 1 45
private def b130rrrrrll : Box := left b130rrrrrl 2 21
private def b130rrrrrlll : Box := left b130rrrrrll 1 29
private def t130rrrrrlll : Tree := (.split 2 13 (.split 1 25 .leaf (.split 2 11 (.split 1 27 .leaf (.split 2 10 .leaf (.split 1 28 .leaf .leaf))) (.split 1 27 (.split 2 12 (.split 1 26 .leaf .leaf) .leaf) .leaf))) (.split 1 25 (.split 2 16 (.split 1 23 (.split 2 14 .leaf (.split 1 22 .leaf (.split 2 15 .leaf .leaf))) (.split 2 14 (.split 1 24 .leaf .leaf) .leaf)) (.split 1 23 (.split 2 18 (.split 1 22 (.split 2 17 .leaf .leaf) .leaf) .leaf) .leaf)) .leaf))
private theorem h130rrrrrlll : Good 13 0 b130rrrrrlll := fun _ h => sound (by decide) 0 t130rrrrrlll (by decide +kernel) h
private def b130rrrrrllr : Box := right b130rrrrrll 1 29
private def t130rrrrrllr : Tree := (.split 2 13 (.split 1 36 (.split 2 11 (.split 1 32 (.split 2 10 (.split 1 30 .leaf .leaf) .leaf) .leaf) .leaf) .leaf) .leaf)
private theorem h130rrrrrllr : Good 13 0 b130rrrrrllr := fun _ h => sound (by decide) 0 t130rrrrrllr (by decide +kernel) h
private theorem h130rrrrrll : Good 13 0 b130rrrrrll := bisect b130rrrrrll 1 29 h130rrrrrlll h130rrrrrllr
private def b130rrrrrlr : Box := right b130rrrrrl 2 21
private def t130rrrrrlr : Tree := .leaf
private theorem h130rrrrrlr : Good 13 0 b130rrrrrlr := fun _ h => sound (by decide) 0 t130rrrrrlr (by decide +kernel) h
private theorem h130rrrrrl : Good 13 0 b130rrrrrl := bisect b130rrrrrl 2 21 h130rrrrrll h130rrrrrlr
private def b130rrrrrr : Box := right b130rrrrr 1 45
private def t130rrrrrr : Tree := .leaf
private theorem h130rrrrrr : Good 13 0 b130rrrrrr := fun _ h => sound (by decide) 0 t130rrrrrr (by decide +kernel) h
private theorem h130rrrrr : Good 13 0 b130rrrrr := bisect b130rrrrr 1 45 h130rrrrrl h130rrrrrr
private theorem h130rrrr : Good 13 0 b130rrrr := bisect b130rrrr 2 9 h130rrrrl h130rrrrr
private theorem h130rrr : Good 13 0 b130rrr := bisect b130rrr 1 21 h130rrrl h130rrrr
private theorem h130rr : Good 13 0 b130rr := bisect b130rr 2 3 h130rrl h130rrr
private theorem h130r : Good 13 0 b130r := bisect b130r 1 9 h130rl h130rr
private theorem h130 : Good 13 0 initial := bisect initial 1 3 h130l h130r
private def b131l : Box := left initial 0 3
private def t131l : Tree := .leaf
private theorem h131l : Good 13 1 b131l := fun _ h => sound (by decide) 1 t131l (by decide +kernel) h
private def b131r : Box := right initial 0 3
private def b131rl : Box := left b131r 0 9
private def t131rl : Tree := .leaf
private theorem h131rl : Good 13 1 b131rl := fun _ h => sound (by decide) 1 t131rl (by decide +kernel) h
private def b131rr : Box := right b131r 0 9
private def b131rrl : Box := left b131rr 0 21
private def t131rrl : Tree := .leaf
private theorem h131rrl : Good 13 1 b131rrl := fun _ h => sound (by decide) 1 t131rrl (by decide +kernel) h
private def b131rrr : Box := right b131rr 0 21
private def b131rrrl : Box := left b131rrr 2 3
private def t131rrrl : Tree := .leaf
private theorem h131rrrl : Good 13 1 b131rrrl := fun _ h => sound (by decide) 1 t131rrrl (by decide +kernel) h
private def b131rrrr : Box := right b131rrr 2 3
private def b131rrrrl : Box := left b131rrrr 0 45
private def b131rrrrll : Box := left b131rrrrl 2 9
private def t131rrrrll : Tree := .leaf
private theorem h131rrrrll : Good 13 1 b131rrrrll := fun _ h => sound (by decide) 1 t131rrrrll (by decide +kernel) h
private def b131rrrrlr : Box := right b131rrrrl 2 9
private def b131rrrrlrl : Box := left b131rrrrlr 0 29
private def t131rrrrlrl : Tree := .leaf
private theorem h131rrrrlrl : Good 13 1 b131rrrrlrl := fun _ h => sound (by decide) 1 t131rrrrlrl (by decide +kernel) h
private def b131rrrrlrr : Box := right b131rrrrlr 0 29
private def b131rrrrlrrl : Box := left b131rrrrlrr 2 21
private def t131rrrrlrrl : Tree := (.split 0 36 .leaf (.split 2 13 .leaf (.split 0 40 .leaf (.split 2 16 .leaf (.split 0 42 (.split 2 18 .leaf (.split 0 41 .leaf (.split 2 19 .leaf (.split 2 20 .leaf .leaf)))) (.split 2 18 (.split 0 43 .leaf (.split 0 44 .leaf (.split 2 17 .leaf .leaf))) (.split 0 43 (.split 2 19 .leaf .leaf) .leaf)))))))
private theorem h131rrrrlrrl : Good 13 1 b131rrrrlrrl := fun _ h => sound (by decide) 1 t131rrrrlrrl (by decide +kernel) h
private def b131rrrrlrrr : Box := right b131rrrrlrr 2 21
private def b131rrrrlrrrl : Box := left b131rrrrlrrr 0 36
private def b131rrrrlrrrll : Box := left b131rrrrlrrrl 2 45
private def t131rrrrlrrrll : Tree := (.split 0 32 .leaf (.split 2 29 .leaf (.split 0 34 .leaf (.split 2 36 .leaf (.split 0 35 .leaf (.split 2 40 .leaf (.split 2 42 .leaf .leaf)))))))
private theorem h131rrrrlrrrll : Good 13 1 b131rrrrlrrrll := fun _ h => sound (by decide) 1 t131rrrrlrrrll (by decide +kernel) h
private def b131rrrrlrrrlr : Box := right b131rrrrlrrrl 2 45
private def b131rrrrlrrrlrl : Box := left b131rrrrlrrrlr 0 32
private def t131rrrrlrrrlrl : Tree := (.split 2 93 .leaf (.split 0 30 .leaf (.split 2 189 .leaf (.split 0 31 .leaf (.split 2 381 (.split 2 253 .leaf (.split 2 304 .leaf (.split 2 338 .leaf (.split 2 358 (.split 2 348 .leaf (.split 2 353 (.split 2 350 .leaf (.split 2 351 .leaf .leaf)) .leaf)) .leaf)))) .leaf)))))
private theorem h131rrrrlrrrlrl : Good 13 1 b131rrrrlrrrlrl := fun _ h => sound (by decide) 1 t131rrrrlrrrlrl (by decide +kernel) h
private def b131rrrrlrrrlrr : Box := right b131rrrrlrrrlr 0 32
private def b131rrrrlrrrlrrl : Box := left b131rrrrlrrrlrr 2 93
private def t131rrrrlrrrlrrl : Tree := (.split 0 34 (.split 2 61 .leaf (.split 0 33 .leaf (.split 2 74 (.split 2 67 .leaf (.split 2 70 .leaf (.split 2 72 .leaf (.split 2 73 .leaf .leaf)))) .leaf))) (.split 2 61 (.split 0 35 (.split 2 52 .leaf (.split 2 56 (.split 2 54 (.split 2 53 .leaf .leaf) .leaf) .leaf)) .leaf) .leaf))
private theorem h131rrrrlrrrlrrl : Good 13 1 b131rrrrlrrrlrrl := fun _ h => sound (by decide) 1 t131rrrrlrrrlrrl (by decide +kernel) h
private def b131rrrrlrrrlrrr : Box := right b131rrrrlrrrlrr 2 93
private def t131rrrrlrrrlrrr : Tree := (.split 0 34 (.split 2 189 (.split 0 33 (.split 2 125 (.split 2 107 .leaf (.split 2 115 .leaf (.split 2 120 (.split 2 117 .leaf (.split 2 118 .leaf (.split 2 119 .leaf .leaf))) .leaf))) .leaf) .leaf) .leaf) .leaf)
private theorem h131rrrrlrrrlrrr : Good 13 1 b131rrrrlrrrlrrr := fun _ h => sound (by decide) 1 t131rrrrlrrrlrrr (by decide +kernel) h
private theorem h131rrrrlrrrlrr : Good 13 1 b131rrrrlrrrlrr := bisect b131rrrrlrrrlrr 2 93 h131rrrrlrrrlrrl h131rrrrlrrrlrrr
private theorem h131rrrrlrrrlr : Good 13 1 b131rrrrlrrrlr := bisect b131rrrrlrrrlr 0 32 h131rrrrlrrrlrl h131rrrrlrrrlrr
private theorem h131rrrrlrrrl : Good 13 1 b131rrrrlrrrl := bisect b131rrrrlrrrl 2 45 h131rrrrlrrrll h131rrrrlrrrlr
private def b131rrrrlrrrr : Box := right b131rrrrlrrr 0 36
private def b131rrrrlrrrrl : Box := left b131rrrrlrrrr 2 45
private def t131rrrrlrrrrl : Tree := (.split 0 40 (.split 2 29 (.split 0 38 .leaf (.split 2 25 (.split 0 39 .leaf (.split 2 23 .leaf (.split 2 24 .leaf .leaf))) (.split 0 39 (.split 2 27 .leaf .leaf) .leaf))) (.split 0 38 (.split 2 36 (.split 0 37 (.split 2 32 .leaf (.split 2 34 .leaf (.split 2 35 .leaf .leaf))) (.split 2 32 (.split 2 30 .leaf (.split 2 31 .leaf .leaf)) .leaf)) .leaf) .leaf)) (.split 2 29 (.split 0 42 (.split 2 25 (.split 2 23 (.split 0 41 (.split 2 22 .leaf .leaf) .leaf) .leaf) .leaf) .leaf) .leaf))
private theorem h131rrrrlrrrrl : Good 13 1 b131rrrrlrrrrl := fun _ h => sound (by decide) 1 t131rrrrlrrrrl (by decide +kernel) h
private def b131rrrrlrrrrr : Box := right b131rrrrlrrrr 2 45
private def t131rrrrlrrrrr : Tree := .leaf
private theorem h131rrrrlrrrrr : Good 13 1 b131rrrrlrrrrr := fun _ h => sound (by decide) 1 t131rrrrlrrrrr (by decide +kernel) h
private theorem h131rrrrlrrrr : Good 13 1 b131rrrrlrrrr := bisect b131rrrrlrrrr 2 45 h131rrrrlrrrrl h131rrrrlrrrrr
private theorem h131rrrrlrrr : Good 13 1 b131rrrrlrrr := bisect b131rrrrlrrr 0 36 h131rrrrlrrrl h131rrrrlrrrr
private theorem h131rrrrlrr : Good 13 1 b131rrrrlrr := bisect b131rrrrlrr 2 21 h131rrrrlrrl h131rrrrlrrr
private theorem h131rrrrlr : Good 13 1 b131rrrrlr := bisect b131rrrrlr 0 29 h131rrrrlrl h131rrrrlrr
private theorem h131rrrrl : Good 13 1 b131rrrrl := bisect b131rrrrl 2 9 h131rrrrll h131rrrrlr
private def b131rrrrr : Box := right b131rrrr 0 45
private def b131rrrrrl : Box := left b131rrrrr 2 9
private def b131rrrrrll : Box := left b131rrrrrl 0 93
private def t131rrrrrll : Tree := (.split 2 5 .leaf (.split 0 61 .leaf (.split 0 74 (.split 2 7 .leaf (.split 0 67 .leaf (.split 2 8 .leaf (.split 0 70 (.split 0 68 .leaf (.split 0 69 .leaf .leaf)) .leaf)))) (.split 2 7 .leaf (.split 0 83 (.split 2 8 (.split 0 78 .leaf (.split 0 80 (.split 0 79 .leaf .leaf) .leaf)) .leaf) .leaf)))))
private theorem h131rrrrrll : Good 13 1 b131rrrrrll := fun _ h => sound (by decide) 1 t131rrrrrll (by decide +kernel) h
private def b131rrrrrlr : Box := right b131rrrrrl 0 93
private def b131rrrrrlrl : Box := left b131rrrrrlr 2 5
private def t131rrrrrlrl : Tree := (.split 0 189 .leaf (.split 0 381 (.split 2 4 .leaf (.split 0 253 .leaf (.split 0 304 .leaf (.split 0 338 (.split 0 320 .leaf (.split 0 329 (.split 0 324 .leaf (.split 0 326 .leaf (.split 0 327 .leaf (.split 0 328 .leaf .leaf)))) .leaf)) .leaf)))) (.split 2 4 .leaf .leaf)))
private theorem h131rrrrrlrl : Good 13 1 b131rrrrrlrl := fun _ h => sound (by decide) 1 t131rrrrrlrl (by decide +kernel) h
private def b131rrrrrlrr : Box := right b131rrrrrlr 2 5
private def t131rrrrrlrr : Tree := (.split 0 189 (.split 0 125 (.split 2 7 (.split 0 107 (.split 2 6 .leaf (.split 0 100 (.split 0 96 .leaf (.split 0 98 .leaf .leaf)) .leaf)) (.split 2 6 .leaf .leaf)) .leaf) (.split 2 7 (.split 0 151 (.split 2 6 (.split 0 137 .leaf (.split 0 144 (.split 0 140 .leaf .leaf) .leaf)) .leaf) .leaf) .leaf)) .leaf)
private theorem h131rrrrrlrr : Good 13 1 b131rrrrrlrr := fun _ h => sound (by decide) 1 t131rrrrrlrr (by decide +kernel) h
private theorem h131rrrrrlr : Good 13 1 b131rrrrrlr := bisect b131rrrrrlr 2 5 h131rrrrrlrl h131rrrrrlrr
private theorem h131rrrrrl : Good 13 1 b131rrrrrl := bisect b131rrrrrl 0 93 h131rrrrrll h131rrrrrlr
private def b131rrrrrr : Box := right b131rrrrr 2 9
private def b131rrrrrrl : Box := left b131rrrrrr 0 93
private def b131rrrrrrll : Box := left b131rrrrrrl 2 21
private def b131rrrrrrlll : Box := left b131rrrrrrll 0 61
private def b131rrrrrrllll : Box := left b131rrrrrrlll 2 13
private def t131rrrrrrllll : Tree := (.split 0 52 (.split 0 48 .leaf (.split 2 11 .leaf (.split 0 50 .leaf (.split 2 12 .leaf (.split 0 51 .leaf .leaf))))) (.split 0 56 (.split 2 11 .leaf (.split 0 54 (.split 2 12 .leaf .leaf) .leaf)) (.split 2 11 (.split 0 58 (.split 2 10 .leaf (.split 0 57 .leaf .leaf)) (.split 2 10 .leaf .leaf)) .leaf)))
private theorem h131rrrrrrllll : Good 13 1 b131rrrrrrllll := fun _ h => sound (by decide) 1 t131rrrrrrllll (by decide +kernel) h
private def b131rrrrrrlllr : Box := right b131rrrrrrlll 2 13
private def t131rrrrrrlllr : Tree := (.split 0 52 (.split 2 16 (.split 0 48 (.split 2 14 .leaf (.split 0 46 .leaf (.split 2 15 (.split 0 47 .leaf .leaf) .leaf))) (.split 0 50 (.split 2 14 (.split 0 49 .leaf .leaf) .leaf) .leaf)) .leaf) .leaf)
private theorem h131rrrrrrlllr : Good 13 1 b131rrrrrrlllr := fun _ h => sound (by decide) 1 t131rrrrrrlllr (by decide +kernel) h
private theorem h131rrrrrrlll : Good 13 1 b131rrrrrrlll := bisect b131rrrrrrlll 2 13 h131rrrrrrllll h131rrrrrrlllr
private def b131rrrrrrllr : Box := right b131rrrrrrll 0 61
private def t131rrrrrrllr : Tree := (.split 2 13 (.split 0 74 (.split 0 67 (.split 2 11 (.split 0 64 (.split 2 10 (.split 0 62 .leaf .leaf) .leaf) .leaf) .leaf) .leaf) .leaf) .leaf)
private theorem h131rrrrrrllr : Good 13 1 b131rrrrrrllr := fun _ h => sound (by decide) 1 t131rrrrrrllr (by decide +kernel) h
private theorem h131rrrrrrll : Good 13 1 b131rrrrrrll := bisect b131rrrrrrll 0 61 h131rrrrrrlll h131rrrrrrllr
private def b131rrrrrrlr : Box := right b131rrrrrrl 2 21
private def t131rrrrrrlr : Tree := .leaf
private theorem h131rrrrrrlr : Good 13 1 b131rrrrrrlr := fun _ h => sound (by decide) 1 t131rrrrrrlr (by decide +kernel) h
private theorem h131rrrrrrl : Good 13 1 b131rrrrrrl := bisect b131rrrrrrl 2 21 h131rrrrrrll h131rrrrrrlr
private def b131rrrrrrr : Box := right b131rrrrrr 0 93
private def t131rrrrrrr : Tree := .leaf
private theorem h131rrrrrrr : Good 13 1 b131rrrrrrr := fun _ h => sound (by decide) 1 t131rrrrrrr (by decide +kernel) h
private theorem h131rrrrrr : Good 13 1 b131rrrrrr := bisect b131rrrrrr 0 93 h131rrrrrrl h131rrrrrrr
private theorem h131rrrrr : Good 13 1 b131rrrrr := bisect b131rrrrr 2 9 h131rrrrrl h131rrrrrr
private theorem h131rrrr : Good 13 1 b131rrrr := bisect b131rrrr 0 45 h131rrrrl h131rrrrr
private theorem h131rrr : Good 13 1 b131rrr := bisect b131rrr 2 3 h131rrrl h131rrrr
private theorem h131rr : Good 13 1 b131rr := bisect b131rr 0 21 h131rrl h131rrr
private theorem h131r : Good 13 1 b131r := bisect b131r 0 9 h131rl h131rr
private theorem h131 : Good 13 1 initial := bisect initial 0 3 h131l h131r
private def b132l : Box := left initial 0 3
private def t132l : Tree := .leaf
private theorem h132l : Good 13 2 b132l := fun _ h => sound (by decide) 2 t132l (by decide +kernel) h
private def b132r : Box := right initial 0 3
private def b132rl : Box := left b132r 1 3
private def t132rl : Tree := .leaf
private theorem h132rl : Good 13 2 b132rl := fun _ h => sound (by decide) 2 t132rl (by decide +kernel) h
private def b132rr : Box := right b132r 1 3
private def b132rrl : Box := left b132rr 0 9
private def t132rrl : Tree := .leaf
private theorem h132rrl : Good 13 2 b132rrl := fun _ h => sound (by decide) 2 t132rrl (by decide +kernel) h
private def b132rrr : Box := right b132rr 0 9
private def b132rrrl : Box := left b132rrr 0 21
private def t132rrrl : Tree := .leaf
private theorem h132rrrl : Good 13 2 b132rrrl := fun _ h => sound (by decide) 2 t132rrrl (by decide +kernel) h
private def b132rrrr : Box := right b132rrr 0 21
private def b132rrrrl : Box := left b132rrrr 1 9
private def t132rrrrl : Tree := .leaf
private theorem h132rrrrl : Good 13 2 b132rrrrl := fun _ h => sound (by decide) 2 t132rrrrl (by decide +kernel) h
private def b132rrrrr : Box := right b132rrrr 1 9
private def b132rrrrrl : Box := left b132rrrrr 0 45
private def b132rrrrrll : Box := left b132rrrrrl 1 21
private def t132rrrrrll : Tree := .leaf
private theorem h132rrrrrll : Good 13 2 b132rrrrrll := fun _ h => sound (by decide) 2 t132rrrrrll (by decide +kernel) h
private def b132rrrrrlr : Box := right b132rrrrrl 1 21
private def b132rrrrrlrl : Box := left b132rrrrrlr 0 29
private def t132rrrrrlrl : Tree := .leaf
private theorem h132rrrrrlrl : Good 13 2 b132rrrrrlrl := fun _ h => sound (by decide) 2 t132rrrrrlrl (by decide +kernel) h
private def b132rrrrrlrr : Box := right b132rrrrrlr 0 29
private def b132rrrrrlrrl : Box := left b132rrrrrlrr 1 45
private def t132rrrrrlrrl : Tree := .leaf
private theorem h132rrrrrlrrl : Good 13 2 b132rrrrrlrrl := fun _ h => sound (by decide) 2 t132rrrrrlrrl (by decide +kernel) h
private def b132rrrrrlrrr : Box := right b132rrrrrlrr 1 45
private def b132rrrrrlrrrl : Box := left b132rrrrrlrrr 0 36
private def b132rrrrrlrrrll : Box := left b132rrrrrlrrrl 1 93
private def t132rrrrrlrrrll : Tree := .leaf
private theorem h132rrrrrlrrrll : Good 13 2 b132rrrrrlrrrll := fun _ h => sound (by decide) 2 t132rrrrrlrrrll (by decide +kernel) h
private def b132rrrrrlrrrlr : Box := right b132rrrrrlrrrl 1 93
private def b132rrrrrlrrrlrl : Box := left b132rrrrrlrrrlr 0 32
private def t132rrrrrlrrrlrl : Tree := (.split 1 189 .leaf (.split 1 381 .leaf (.split 0 30 .leaf (.split 1 765 .leaf (.split 0 31 .leaf (.split 1 1533 (.split 1 1021 .leaf (.split 1 1226 (.split 1 1114 (.split 1 1066 (.split 1 1043 .leaf (.split 1 1054 .leaf (.split 1 1060 (.split 1 1057 (.split 1 1055 .leaf .leaf) .leaf) .leaf))) .leaf) .leaf) .leaf)) .leaf))))))
private theorem h132rrrrrlrrrlrl : Good 13 2 b132rrrrrlrrrlrl := fun _ h => sound (by decide) 2 t132rrrrrlrrrlrl (by decide +kernel) h
private def b132rrrrrlrrrlrr : Box := right b132rrrrrlrrrlr 0 32
private def b132rrrrrlrrrlrrl : Box := left b132rrrrrlrrrlrr 1 189
private def t132rrrrrlrrrlrrl : Tree := (.split 0 34 .leaf (.split 1 125 .leaf (.split 1 151 (.split 0 35 .leaf (.split 1 137 (.split 1 131 (.split 1 128 .leaf (.split 1 129 .leaf (.split 1 130 .leaf .leaf))) .leaf) .leaf)) (.split 0 35 (.split 1 168 (.split 1 159 .leaf (.split 1 163 .leaf .leaf)) .leaf) .leaf))))
private theorem h132rrrrrlrrrlrrl : Good 13 2 b132rrrrrlrrrlrrl := fun _ h => sound (by decide) 2 t132rrrrrlrrrlrrl (by decide +kernel) h
private def b132rrrrrlrrrlrrr : Box := right b132rrrrrlrrrlrr 1 189
private def t132rrrrrlrrrlrrr : Tree := (.split 0 34 (.split 1 381 (.split 1 253 (.split 0 33 .leaf (.split 1 217 .leaf (.split 1 234 (.split 1 225 (.split 1 221 .leaf (.split 1 223 .leaf .leaf)) .leaf) .leaf))) (.split 0 33 (.split 1 304 .leaf (.split 1 338 .leaf (.split 1 358 .leaf (.split 1 369 (.split 1 363 (.split 1 360 .leaf (.split 1 361 .leaf .leaf)) .leaf) .leaf)))) .leaf)) .leaf) .leaf)
private theorem h132rrrrrlrrrlrrr : Good 13 2 b132rrrrrlrrrlrrr := fun _ h => sound (by decide) 2 t132rrrrrlrrrlrrr (by decide +kernel) h
private theorem h132rrrrrlrrrlrr : Good 13 2 b132rrrrrlrrrlrr := bisect b132rrrrrlrrrlrr 1 189 h132rrrrrlrrrlrrl h132rrrrrlrrrlrrr
private theorem h132rrrrrlrrrlr : Good 13 2 b132rrrrrlrrrlr := bisect b132rrrrrlrrrlr 0 32 h132rrrrrlrrrlrl h132rrrrrlrrrlrr
private theorem h132rrrrrlrrrl : Good 13 2 b132rrrrrlrrrl := bisect b132rrrrrlrrrl 1 93 h132rrrrrlrrrll h132rrrrrlrrrlr
private def b132rrrrrlrrrr : Box := right b132rrrrrlrrr 0 36
private def b132rrrrrlrrrrl : Box := left b132rrrrrlrrrr 1 93
private def b132rrrrrlrrrrll : Box := left b132rrrrrlrrrrl 0 40
private def t132rrrrrlrrrrll : Tree := (.split 1 61 .leaf (.split 1 74 .leaf (.split 0 38 .leaf (.split 1 83 (.split 0 39 .leaf (.split 1 78 (.split 1 76 .leaf .leaf) .leaf)) (.split 0 39 (.split 1 88 (.split 1 85 (.split 1 84 .leaf .leaf) .leaf) .leaf) .leaf)))))
private theorem h132rrrrrlrrrrll : Good 13 2 b132rrrrrlrrrrll := fun _ h => sound (by decide) 2 t132rrrrrlrrrrll (by decide +kernel) h
private def b132rrrrrlrrrrlr : Box := right b132rrrrrlrrrrl 0 40
private def t132rrrrrlrrrrlr : Tree := (.split 1 61 (.split 1 52 .leaf (.split 0 42 .leaf (.split 1 56 (.split 0 43 .leaf (.split 0 44 .leaf (.split 1 54 (.split 1 53 .leaf .leaf) .leaf))) (.split 0 43 (.split 1 58 .leaf (.split 1 59 .leaf (.split 1 60 .leaf .leaf))) .leaf)))) (.split 1 74 (.split 0 42 (.split 1 67 (.split 0 41 .leaf (.split 1 64 .leaf .leaf)) (.split 0 41 (.split 1 70 (.split 1 68 .leaf (.split 1 69 .leaf .leaf)) .leaf) .leaf)) .leaf) .leaf))
private theorem h132rrrrrlrrrrlr : Good 13 2 b132rrrrrlrrrrlr := fun _ h => sound (by decide) 2 t132rrrrrlrrrrlr (by decide +kernel) h
private theorem h132rrrrrlrrrrl : Good 13 2 b132rrrrrlrrrrl := bisect b132rrrrrlrrrrl 0 40 h132rrrrrlrrrrll h132rrrrrlrrrrlr
private def b132rrrrrlrrrrr : Box := right b132rrrrrlrrrr 1 93
private def t132rrrrrlrrrrr : Tree := (.split 0 40 (.split 1 189 (.split 1 125 (.split 0 38 (.split 1 107 (.split 0 37 .leaf (.split 1 100 (.split 1 96 (.split 1 94 .leaf (.split 1 95 .leaf .leaf)) .leaf) .leaf)) (.split 0 37 (.split 1 115 (.split 1 111 (.split 1 109 .leaf .leaf) .leaf) .leaf) .leaf)) .leaf) .leaf) .leaf) .leaf)
private theorem h132rrrrrlrrrrr : Good 13 2 b132rrrrrlrrrrr := fun _ h => sound (by decide) 2 t132rrrrrlrrrrr (by decide +kernel) h
private theorem h132rrrrrlrrrr : Good 13 2 b132rrrrrlrrrr := bisect b132rrrrrlrrrr 1 93 h132rrrrrlrrrrl h132rrrrrlrrrrr
private theorem h132rrrrrlrrr : Good 13 2 b132rrrrrlrrr := bisect b132rrrrrlrrr 0 36 h132rrrrrlrrrl h132rrrrrlrrrr
private theorem h132rrrrrlrr : Good 13 2 b132rrrrrlrr := bisect b132rrrrrlrr 1 45 h132rrrrrlrrl h132rrrrrlrrr
private theorem h132rrrrrlr : Good 13 2 b132rrrrrlr := bisect b132rrrrrlr 0 29 h132rrrrrlrl h132rrrrrlrr
private theorem h132rrrrrl : Good 13 2 b132rrrrrl := bisect b132rrrrrl 1 21 h132rrrrrll h132rrrrrlr
private def b132rrrrrr : Box := right b132rrrrr 0 45
private def b132rrrrrrl : Box := left b132rrrrrr 1 21
private def b132rrrrrrll : Box := left b132rrrrrrl 0 93
private def t132rrrrrrll : Tree := .leaf
private theorem h132rrrrrrll : Good 13 2 b132rrrrrrll := fun _ h => sound (by decide) 2 t132rrrrrrll (by decide +kernel) h
private def b132rrrrrrlr : Box := right b132rrrrrrl 0 93
private def b132rrrrrrlrl : Box := left b132rrrrrrlr 1 13
private def t132rrrrrrlrl : Tree := .leaf
private theorem h132rrrrrrlrl : Good 13 2 b132rrrrrrlrl := fun _ h => sound (by decide) 2 t132rrrrrrlrl (by decide +kernel) h
private def b132rrrrrrlrr : Box := right b132rrrrrrlr 1 13
private def b132rrrrrrlrrl : Box := left b132rrrrrrlrr 0 189
private def t132rrrrrrlrrl : Tree := (.split 1 16 .leaf (.split 0 125 (.split 1 18 .leaf (.split 0 107 .leaf (.split 1 19 .leaf (.split 0 115 .leaf (.split 1 20 .leaf (.split 0 120 .leaf (.split 0 122 (.split 0 121 .leaf .leaf) .leaf))))))) (.split 1 18 .leaf (.split 0 151 (.split 1 19 .leaf (.split 0 137 (.split 1 20 .leaf .leaf) (.split 1 20 (.split 0 144 (.split 0 140 .leaf .leaf) .leaf) .leaf))) (.split 1 19 (.split 0 168 .leaf (.split 0 178 (.split 0 173 (.split 0 170 .leaf .leaf) .leaf) .leaf)) .leaf)))))
private theorem h132rrrrrrlrrl : Good 13 2 b132rrrrrrlrrl := fun _ h => sound (by decide) 2 t132rrrrrrlrrl (by decide +kernel) h
private def b132rrrrrrlrrr : Box := right b132rrrrrrlrr 0 189
private def b132rrrrrrlrrrl : Box := left b132rrrrrrlrrr 1 16
private def t132rrrrrrlrrrl : Tree := (.split 0 381 .leaf (.split 1 14 .leaf (.split 0 765 (.split 1 15 .leaf (.split 0 509 .leaf (.split 0 612 .leaf (.split 0 680 .leaf (.split 0 720 .leaf (.split 0 742 (.split 0 731 (.split 0 725 (.split 0 722 .leaf (.split 0 723 .leaf (.split 0 724 .leaf .leaf))) .leaf) .leaf) .leaf)))))) (.split 1 15 .leaf .leaf))))
private theorem h132rrrrrrlrrrl : Good 13 2 b132rrrrrrlrrrl := fun _ h => sound (by decide) 2 t132rrrrrrlrrrl (by decide +kernel) h
private def b132rrrrrrlrrrr : Box := right b132rrrrrrlrrr 1 16
private def t132rrrrrrlrrrr : Tree := (.split 0 381 (.split 1 18 (.split 0 253 (.split 0 217 .leaf (.split 1 17 .leaf (.split 0 234 (.split 0 225 (.split 0 221 (.split 0 219 .leaf (.split 0 220 .leaf .leaf)) .leaf) .leaf) .leaf))) (.split 0 304 (.split 1 17 .leaf .leaf) (.split 1 17 (.split 0 338 (.split 0 320 .leaf (.split 0 329 (.split 0 324 .leaf (.split 0 326 .leaf (.split 0 327 .leaf (.split 0 328 .leaf .leaf)))) .leaf)) .leaf) .leaf))) .leaf) .leaf)
private theorem h132rrrrrrlrrrr : Good 13 2 b132rrrrrrlrrrr := fun _ h => sound (by decide) 2 t132rrrrrrlrrrr (by decide +kernel) h
private theorem h132rrrrrrlrrr : Good 13 2 b132rrrrrrlrrr := bisect b132rrrrrrlrrr 1 16 h132rrrrrrlrrrl h132rrrrrrlrrrr
private theorem h132rrrrrrlrr : Good 13 2 b132rrrrrrlrr := bisect b132rrrrrrlrr 0 189 h132rrrrrrlrrl h132rrrrrrlrrr
private theorem h132rrrrrrlr : Good 13 2 b132rrrrrrlr := bisect b132rrrrrrlr 1 13 h132rrrrrrlrl h132rrrrrrlrr
private theorem h132rrrrrrl : Good 13 2 b132rrrrrrl := bisect b132rrrrrrl 0 93 h132rrrrrrll h132rrrrrrlr
private def b132rrrrrrr : Box := right b132rrrrrr 1 21
private def b132rrrrrrrl : Box := left b132rrrrrrr 0 93
private def b132rrrrrrrll : Box := left b132rrrrrrrl 1 45
private def b132rrrrrrrlll : Box := left b132rrrrrrrll 0 61
private def b132rrrrrrrllll : Box := left b132rrrrrrrlll 1 29
private def t132rrrrrrrllll : Tree := .leaf
private theorem h132rrrrrrrllll : Good 13 2 b132rrrrrrrllll := fun _ h => sound (by decide) 2 t132rrrrrrrllll (by decide +kernel) h
private def b132rrrrrrrlllr : Box := right b132rrrrrrrlll 1 29
private def b132rrrrrrrlllrl : Box := left b132rrrrrrrlllr 0 52
private def t132rrrrrrrlllrl : Tree := (.split 1 36 .leaf (.split 0 48 .leaf (.split 1 40 .leaf (.split 0 50 (.split 1 42 .leaf (.split 1 43 .leaf (.split 0 49 (.split 1 44 .leaf .leaf) .leaf))) (.split 1 42 (.split 0 51 (.split 1 41 .leaf .leaf) .leaf) .leaf)))))
private theorem h132rrrrrrrlllrl : Good 13 2 b132rrrrrrrlllrl := fun _ h => sound (by decide) 2 t132rrrrrrrlllrl (by decide +kernel) h
private def b132rrrrrrrlllrr : Box := right b132rrrrrrrlllr 0 52
private def t132rrrrrrrlllrr : Tree := (.split 1 36 (.split 0 56 .leaf (.split 1 32 .leaf (.split 0 58 (.split 1 34 .leaf (.split 1 35 (.split 0 57 .leaf .leaf) .leaf)) (.split 1 34 (.split 0 59 .leaf (.split 1 33 (.split 0 60 .leaf .leaf) .leaf)) .leaf)))) (.split 0 56 (.split 1 40 (.split 0 54 (.split 1 38 .leaf (.split 0 53 (.split 1 39 .leaf .leaf) .leaf)) (.split 1 38 (.split 0 55 (.split 1 37 .leaf .leaf) .leaf) .leaf)) .leaf) .leaf))
private theorem h132rrrrrrrlllrr : Good 13 2 b132rrrrrrrlllrr := fun _ h => sound (by decide) 2 t132rrrrrrrlllrr (by decide +kernel) h
private theorem h132rrrrrrrlllr : Good 13 2 b132rrrrrrrlllr := bisect b132rrrrrrrlllr 0 52 h132rrrrrrrlllrl h132rrrrrrrlllrr
private theorem h132rrrrrrrlll : Good 13 2 b132rrrrrrrlll := bisect b132rrrrrrrlll 1 29 h132rrrrrrrllll h132rrrrrrrlllr
private def b132rrrrrrrllr : Box := right b132rrrrrrrll 0 61
private def b132rrrrrrrllrl : Box := left b132rrrrrrrllr 1 29
private def b132rrrrrrrllrll : Box := left b132rrrrrrrllrl 0 74
private def t132rrrrrrrllrll : Tree := (.split 1 25 .leaf (.split 0 67 .leaf (.split 1 27 .leaf (.split 0 70 (.split 1 28 .leaf (.split 0 68 .leaf (.split 0 69 .leaf .leaf))) (.split 0 72 (.split 1 28 .leaf .leaf) .leaf)))))
private theorem h132rrrrrrrllrll : Good 13 2 b132rrrrrrrllrll := fun _ h => sound (by decide) 2 t132rrrrrrrllrll (by decide +kernel) h
private def b132rrrrrrrllrlr : Box := right b132rrrrrrrllrl 0 74
private def t132rrrrrrrllrlr : Tree := (.split 1 25 (.split 0 83 .leaf (.split 1 23 .leaf (.split 0 88 (.split 1 24 .leaf (.split 0 85 (.split 0 84 .leaf .leaf) .leaf)) (.split 1 24 (.split 0 90 .leaf .leaf) .leaf)))) (.split 0 83 (.split 1 27 (.split 0 78 (.split 1 26 .leaf (.split 0 76 (.split 0 75 .leaf .leaf) .leaf)) (.split 0 80 (.split 1 26 (.split 0 79 .leaf .leaf) .leaf) .leaf)) .leaf) .leaf))
private theorem h132rrrrrrrllrlr : Good 13 2 b132rrrrrrrllrlr := fun _ h => sound (by decide) 2 t132rrrrrrrllrlr (by decide +kernel) h
private theorem h132rrrrrrrllrl : Good 13 2 b132rrrrrrrllrl := bisect b132rrrrrrrllrl 0 74 h132rrrrrrrllrll h132rrrrrrrllrlr
private def b132rrrrrrrllrr : Box := right b132rrrrrrrllr 1 29
private def t132rrrrrrrllrr : Tree := (.split 0 74 (.split 1 36 (.split 0 67 (.split 1 32 (.split 0 64 (.split 1 30 .leaf (.split 0 62 .leaf (.split 1 31 .leaf .leaf))) (.split 1 30 (.split 0 65 .leaf (.split 0 66 .leaf .leaf)) .leaf)) .leaf) .leaf) .leaf) .leaf)
private theorem h132rrrrrrrllrr : Good 13 2 b132rrrrrrrllrr := fun _ h => sound (by decide) 2 t132rrrrrrrllrr (by decide +kernel) h
private theorem h132rrrrrrrllr : Good 13 2 b132rrrrrrrllr := bisect b132rrrrrrrllr 1 29 h132rrrrrrrllrl h132rrrrrrrllrr
private theorem h132rrrrrrrll : Good 13 2 b132rrrrrrrll := bisect b132rrrrrrrll 0 61 h132rrrrrrrlll h132rrrrrrrllr
private def b132rrrrrrrlr : Box := right b132rrrrrrrl 1 45
private def t132rrrrrrrlr : Tree := (.split 0 61 (.split 1 93 (.split 0 52 (.split 1 61 (.split 0 48 (.split 1 52 (.split 1 48 (.split 0 46 .leaf (.split 0 47 .leaf (.split 1 46 .leaf .leaf))) (.split 0 46 (.split 1 50 .leaf (.split 1 51 .leaf .leaf)) .leaf)) .leaf) .leaf) .leaf) .leaf) .leaf) .leaf)
private theorem h132rrrrrrrlr : Good 13 2 b132rrrrrrrlr := fun _ h => sound (by decide) 2 t132rrrrrrrlr (by decide +kernel) h
private theorem h132rrrrrrrl : Good 13 2 b132rrrrrrrl := bisect b132rrrrrrrl 1 45 h132rrrrrrrll h132rrrrrrrlr
private def b132rrrrrrrr : Box := right b132rrrrrrr 0 93
private def t132rrrrrrrr : Tree := (.split 1 45 (.split 0 189 (.split 1 29 (.split 0 125 (.split 1 25 (.split 0 107 (.split 1 23 (.split 0 100 (.split 1 22 .leaf (.split 0 96 .leaf (.split 0 98 .leaf .leaf))) (.split 1 22 .leaf .leaf)) .leaf) (.split 1 23 (.split 0 115 (.split 1 22 (.split 0 111 (.split 0 109 (.split 0 108 .leaf .leaf) .leaf) .leaf) .leaf) .leaf) .leaf)) .leaf) .leaf) .leaf) .leaf) .leaf)
private theorem h132rrrrrrrr : Good 13 2 b132rrrrrrrr := fun _ h => sound (by decide) 2 t132rrrrrrrr (by decide +kernel) h
private theorem h132rrrrrrr : Good 13 2 b132rrrrrrr := bisect b132rrrrrrr 0 93 h132rrrrrrrl h132rrrrrrrr
private theorem h132rrrrrr : Good 13 2 b132rrrrrr := bisect b132rrrrrr 1 21 h132rrrrrrl h132rrrrrrr
private theorem h132rrrrr : Good 13 2 b132rrrrr := bisect b132rrrrr 0 45 h132rrrrrl h132rrrrrr
private theorem h132rrrr : Good 13 2 b132rrrr := bisect b132rrrr 1 9 h132rrrrl h132rrrrr
private theorem h132rrr : Good 13 2 b132rrr := bisect b132rrr 0 21 h132rrrl h132rrrr
private theorem h132rr : Good 13 2 b132rr := bisect b132rr 0 9 h132rrl h132rrr
private theorem h132r : Good 13 2 b132r := bisect b132r 1 3 h132rl h132rr
private theorem h132 : Good 13 2 initial := bisect initial 0 3 h132l h132r
theorem separation {q : ℕ} (hq : q=7 ∨ q=11 ∨ q=13) (k : Fin 3) (e : I → ℕ)
    (he : ∀ i,0<e i) : Separated (face q k e) := by
  have mem : ∀ i,(initial i).Contains (e i) := fun i => ⟨he i,by simp [initial]⟩
  rcases hq with rfl|rfl|rfl <;> fin_cases k
  · exact h70 e mem
  · exact h71 e mem
  · exact h72 e mem
  · exact h110 e mem
  · exact h111 e mem
  · exact h112 e mem
  · exact h130 e mem
  · exact h131 e mem
  · exact h132 e mem
end OMA.OddFaces245212
