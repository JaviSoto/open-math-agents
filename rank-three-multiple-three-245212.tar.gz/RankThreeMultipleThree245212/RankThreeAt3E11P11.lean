import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt3E11P11
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 12 22 (finitePair 354294 15278930 797160 8503056 11)=true := by decide +kernel
private theorem b1 : every 23 30 (finitePair 354294 15278930 797160 8503056 11)=true := by decide +kernel
private theorem b2 : every 31 40 (finitePair 354294 15278930 797160 8503056 11)=true := by decide +kernel
private theorem b3 : every 41 46 (finitePair 354294 15278930 797160 8503056 11)=true := by decide +kernel
private theorem b4 : every 47 52 (finitePair 354294 15278930 797160 8503056 11)=true := by decide +kernel
private theorem b5 : every 53 58 (finitePair 354294 15278930 797160 8503056 11)=true := by decide +kernel
private theorem b6 : every 59 62 (finitePair 354294 15278930 797160 8503056 11)=true := by decide +kernel
private theorem b7 : every 63 70 (finitePair 354294 15278930 797160 8503056 11)=true := by decide +kernel
private theorem b8 : every 71 74 (finitePair 354294 15278930 797160 8503056 11)=true := by decide +kernel
private theorem b9 : every 75 82 (finitePair 354294 15278930 797160 8503056 11)=true := by decide +kernel
private theorem b10 : every 83 85 (finitePair 354294 15278930 797160 8503056 11)=true := by decide +kernel
theorem checked : test 3 11 11=true :=
  fixedTest (h:=354294) (A:=15278930) (S:=797160) (T:=8503056)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 (joinEvery b3 b4))) (joinEvery (joinEvery b5 (joinEvery b6 b7)) (joinEvery b8 (joinEvery b9 b10))))
#print axioms checked
end OMA.RankThreeAt3E11P11
