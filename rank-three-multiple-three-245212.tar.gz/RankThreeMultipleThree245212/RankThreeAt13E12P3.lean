import RankThreeMiddleBlocks245212
/-! Fixed-cofactor arithmetic certificate. -/
namespace OMA.RankThreeAt13E12P3
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212
set_option maxRecDepth 8192
set_option maxHeartbeats 1000000
private theorem b0 : every 1 2 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b1 : every 3 4 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b2 : every 5 6 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b3 : every 7 8 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b4 : every 9 11 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b5 : every 12 14 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b6 : every 15 17 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b7 : every 18 20 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b8 : every 21 23 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b9 : every 24 26 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b10 : every 27 29 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b11 : every 30 32 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b12 : every 33 35 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b13 : every 36 38 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b14 : every 39 41 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b15 : every 42 44 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b16 : every 45 47 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b17 : every 48 50 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b18 : every 51 54 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b19 : every 55 55 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b20 : every 56 56 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b21 : every 57 57 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b22 : every 58 58 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b23 : every 59 59 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b24 : every 60 60 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b25 : every 61 61 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b26 : every 62 62 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b27 : every 63 63 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b28 : every 64 64 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b29 : every 65 65 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b30 : every 66 66 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b31 : every 67 67 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b32 : every 68 68 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b33 : every 69 69 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b34 : every 70 70 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b35 : every 71 71 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b36 : every 72 72 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
private theorem b37 : every 73 73 (movingRow 1630056997284695 75718776648063 1211500426369012 3)=true := by decide +kernel
theorem checked : test 13 12 3=true :=
  movingTest (h:=46596170244962) (A:=1630056997284695) (S:=75718776648063) (T:=1211500426369012)
    (by decide +kernel) (by decide) (by decide) (by decide) (by decide) (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery b0 b1) (joinEvery b2 b3)) (joinEvery (joinEvery b4 b5) (joinEvery b6 (joinEvery b7 b8)))) (joinEvery (joinEvery (joinEvery b9 b10) (joinEvery b11 (joinEvery b12 b13))) (joinEvery (joinEvery b14 b15) (joinEvery b16 (joinEvery b17 b18))))) (joinEvery (joinEvery (joinEvery (joinEvery b19 b20) (joinEvery b21 b22)) (joinEvery (joinEvery b23 b24) (joinEvery b25 (joinEvery b26 b27)))) (joinEvery (joinEvery (joinEvery b28 b29) (joinEvery b30 (joinEvery b31 b32))) (joinEvery (joinEvery b33 b34) (joinEvery b35 (joinEvery b36 b37))))))
#print axioms checked
end OMA.RankThreeAt13E12P3
