import RankThreeAt3E1P11
import RankThreeAt3E2P11
import RankThreeAt3E3P11
import RankThreeAt3E4P11
import RankThreeAt3E5P11
import RankThreeAt3E6P11
import RankThreeAt3E7P11
import RankThreeAt3E8P11
import RankThreeAt3E9P11
import RankThreeAt3E10P11
import RankThreeAt3E11P11
import RankThreeAt3E12P11
import RankThreeAt3E13P11
import RankThreeAt3E14P11
import RankThreeAt3E15P11
import RankThreeAt3E16P11
import RankThreeAt3E17P11
import RankThreeAt3E18P11
import RankThreeAt3E19P11
import RankThreeAt3E20P11
import RankThreeAt11E1P3
import RankThreeAt11E2P3
import RankThreeAt11E3P3
import RankThreeAt11E4P3
import RankThreeAt11E5P3
import RankThreeAt11E6P3
import RankThreeAt11E7P3
import RankThreeAt11E8P3
import RankThreeAt11E9P3
import RankThreeAt11E10P3
import RankThreeAt11E11P3
/-! Both ordered short-cofactor certificates. -/
namespace OMA.RankThreeMiddle11
open OMA.RankThreeMiddle245212 OMA.CofactorEulerPair245212 OMA.Smooth245212
theorem range0 : rangeCheck 3 11 21=true := range_from_every (joinEvery (joinEvery (joinEvery (joinEvery (singleTest OMA.RankThreeAt3E1P11.checked) (singleTest OMA.RankThreeAt3E2P11.checked)) (joinEvery (singleTest OMA.RankThreeAt3E3P11.checked) (joinEvery (singleTest OMA.RankThreeAt3E4P11.checked) (singleTest OMA.RankThreeAt3E5P11.checked)))) (joinEvery (joinEvery (singleTest OMA.RankThreeAt3E6P11.checked) (singleTest OMA.RankThreeAt3E7P11.checked)) (joinEvery (singleTest OMA.RankThreeAt3E8P11.checked) (joinEvery (singleTest OMA.RankThreeAt3E9P11.checked) (singleTest OMA.RankThreeAt3E10P11.checked))))) (joinEvery (joinEvery (joinEvery (singleTest OMA.RankThreeAt3E11P11.checked) (singleTest OMA.RankThreeAt3E12P11.checked)) (joinEvery (singleTest OMA.RankThreeAt3E13P11.checked) (joinEvery (singleTest OMA.RankThreeAt3E14P11.checked) (singleTest OMA.RankThreeAt3E15P11.checked)))) (joinEvery (joinEvery (singleTest OMA.RankThreeAt3E16P11.checked) (singleTest OMA.RankThreeAt3E17P11.checked)) (joinEvery (singleTest OMA.RankThreeAt3E18P11.checked) (joinEvery (singleTest OMA.RankThreeAt3E19P11.checked) (singleTest OMA.RankThreeAt3E20P11.checked))))))
theorem range1 : rangeCheck 11 3 12=true := range_from_every (joinEvery (joinEvery (joinEvery (singleTest OMA.RankThreeAt11E1P3.checked) (singleTest OMA.RankThreeAt11E2P3.checked)) (joinEvery (singleTest OMA.RankThreeAt11E3P3.checked) (joinEvery (singleTest OMA.RankThreeAt11E4P3.checked) (singleTest OMA.RankThreeAt11E5P3.checked)))) (joinEvery (joinEvery (singleTest OMA.RankThreeAt11E6P3.checked) (joinEvery (singleTest OMA.RankThreeAt11E7P3.checked) (singleTest OMA.RankThreeAt11E8P3.checked))) (joinEvery (singleTest OMA.RankThreeAt11E9P3.checked) (joinEvery (singleTest OMA.RankThreeAt11E10P3.checked) (singleTest OMA.RankThreeAt11E11P3.checked)))))
theorem mass : 8≤5*X 3 (some 21)*X 11 (some 12) := by decide +kernel
end OMA.RankThreeMiddle11
