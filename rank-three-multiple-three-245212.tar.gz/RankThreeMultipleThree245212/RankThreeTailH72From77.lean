import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b72_77_0 : every 77 78 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_77_1 : every 80 84 (quick 72 1666 195 864 79)=true := by decide +kernel
private theorem b72_77_2 : every 1 20 (far 72 1666 195 864 79 85 19)=true := by decide +kernel
private theorem r72_79 : every 79 79 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 79=true := by change (every 80 84 (quick 72 1666 195 864 79) && every 1 20 (far 72 1666 195 864 79 85 19))=true; rw [Bool.and_eq_true]; exact ⟨b72_77_1,b72_77_2⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=79 by omega] using yes
private theorem b72_77_3 : every 80 82 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_77_4 : every 84 81 (quick 72 1666 195 864 83)=true := by decide +kernel
private theorem b72_77_5 : every 1 21 (far 72 1666 195 864 83 84 18)=true := by decide +kernel
private theorem r72_83 : every 83 83 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 83=true := by change (every 84 81 (quick 72 1666 195 864 83) && every 1 21 (far 72 1666 195 864 83 84 18))=true; rw [Bool.and_eq_true]; exact ⟨b72_77_4,b72_77_5⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=83 by omega] using yes
private theorem b72_77_6 : every 84 88 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_77_7 : every 90 79 (quick 72 1666 195 864 89)=true := by decide +kernel
private theorem b72_77_8 : every 1 22 (far 72 1666 195 864 89 90 18)=true := by decide +kernel
private theorem r72_89 : every 89 89 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 89=true := by change (every 90 79 (quick 72 1666 195 864 89) && every 1 22 (far 72 1666 195 864 89 90 18))=true; rw [Bool.and_eq_true]; exact ⟨b72_77_7,b72_77_8⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=89 by omega] using yes
private theorem b72_77_9 : every 90 96 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_77_10 : every 98 76 (quick 72 1666 195 864 97)=true := by decide +kernel
private theorem b72_77_11 : every 1 24 (far 72 1666 195 864 97 98 17)=true := by decide +kernel
private theorem r72_97 : every 97 97 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 97=true := by change (every 98 76 (quick 72 1666 195 864 97) && every 1 24 (far 72 1666 195 864 97 98 17))=true; rw [Bool.and_eq_true]; exact ⟨b72_77_10,b72_77_11⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=97 by omega] using yes
private theorem b72_77_12 : every 98 100 (run 72 1666 195 864)=true := by decide +kernel
theorem span72_77_100 : every 77 100 (run 72 1666 195 864)=true := (joinEvery (joinEvery (joinEvery b72_77_0 r72_79) (joinEvery b72_77_3 r72_83)) (joinEvery (joinEvery b72_77_6 r72_89) (joinEvery b72_77_9 (joinEvery r72_97 b72_77_12))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span72_77_100
