import RankThreeFourSmallCompact245212
/-! Independently checked consecutive interval for the compressed two-prime decision. -/
namespace OMA.RankThreeFourSmallCompactTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallCompact245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem r5_5_12 : every 5 12 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_13_20 : every 13 20 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_21_28 : every 21 28 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_29_36 : every 29 36 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_37_44 : every 37 44 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_45_52 : every 45 52 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_53_60 : every 53 60 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_61_68 : every 61 68 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_69_76 : every 69 76 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_77_84 : every 77 84 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_85_92 : every 85 92 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_93_100 : every 93 100 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_101_108 : every 101 108 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_109_116 : every 109 116 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_117_124 : every 117 124 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_125_132 : every 125 132 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_133_140 : every 133 140 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_141_148 : every 141 148 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_149_156 : every 149 156 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_157_164 : every 157 164 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_165_172 : every 165 172 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_173_180 : every 173 180 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_181_188 : every 181 188 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_189_196 : every 189 196 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_197_204 : every 197 204 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_205_212 : every 205 212 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_213_220 : every 213 220 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_221_228 : every 221 228 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_229_236 : every 229 236 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_237_244 : every 237 244 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_245_252 : every 245 252 (run 972 34085 2548 17496)=true := by decide +kernel
private theorem r5_253_259 : every 253 259 (run 972 34085 2548 17496)=true := by decide +kernel
theorem span5_5_259 : every 5 259 (run 972 34085 2548 17496)=true := (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery r5_5_12 r5_13_20) (joinEvery r5_21_28 r5_29_36)) (joinEvery (joinEvery r5_37_44 r5_45_52) (joinEvery r5_53_60 r5_61_68))) (joinEvery (joinEvery (joinEvery r5_69_76 r5_77_84) (joinEvery r5_85_92 r5_93_100)) (joinEvery (joinEvery r5_101_108 r5_109_116) (joinEvery r5_117_124 r5_125_132)))) (joinEvery (joinEvery (joinEvery (joinEvery r5_133_140 r5_141_148) (joinEvery r5_149_156 r5_157_164)) (joinEvery (joinEvery r5_165_172 r5_173_180) (joinEvery r5_181_188 r5_189_196))) (joinEvery (joinEvery (joinEvery r5_197_204 r5_205_212) (joinEvery r5_213_220 r5_221_228)) (joinEvery (joinEvery r5_229_236 r5_237_244) (joinEvery r5_245_252 r5_253_259)))))
end OMA.RankThreeFourSmallCompactTables245212
#print axioms OMA.RankThreeFourSmallCompactTables245212.span5_5_259
