import RankThreeFourSmallCompact245212
/-! Independently checked consecutive interval for the compressed two-prime decision. -/
namespace OMA.RankThreeFourSmallCompactTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallCompact245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem r7_400_404 : every 400 404 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_405_409 : every 405 409 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_410_414 : every 410 414 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_415_419 : every 415 419 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_420_424 : every 420 424 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_425_429 : every 425 429 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_430_434 : every 430 434 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_435_439 : every 435 439 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_440_444 : every 440 444 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_445_449 : every 445 449 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_450_454 : every 450 454 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_455_459 : every 455 459 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_460_464 : every 460 464 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_465_469 : every 465 469 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_470_474 : every 470 474 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_475_479 : every 475 479 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_480_484 : every 480 484 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_485_489 : every 485 489 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_490_494 : every 490 494 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_495_499 : every 495 499 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_500_504 : every 500 504 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_505_509 : every 505 509 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_510_514 : every 510 514 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_515_519 : every 515 519 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_520_524 : every 520 524 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_525_529 : every 525 529 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_530_534 : every 530 534 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_535_539 : every 535 539 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_540_544 : every 540 544 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_545_549 : every 545 549 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_550_554 : every 550 554 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_555_559 : every 555 559 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_560_564 : every 560 564 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_565_569 : every 565 569 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_570_574 : every 570 574 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_575_579 : every 575 579 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_580_584 : every 580 584 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_585_589 : every 585 589 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_590_594 : every 590 594 (run 8748 418268 22960 209952)=true := by decide +kernel
private theorem r7_595_599 : every 595 599 (run 8748 418268 22960 209952)=true := by decide +kernel
theorem span7_400_599 : every 400 599 (run 8748 418268 22960 209952)=true := (joinEvery (joinEvery (joinEvery (joinEvery (joinEvery r7_400_404 r7_405_409) (joinEvery r7_410_414 (joinEvery r7_415_419 r7_420_424))) (joinEvery (joinEvery r7_425_429 r7_430_434) (joinEvery r7_435_439 (joinEvery r7_440_444 r7_445_449)))) (joinEvery (joinEvery (joinEvery r7_450_454 r7_455_459) (joinEvery r7_460_464 (joinEvery r7_465_469 r7_470_474))) (joinEvery (joinEvery r7_475_479 r7_480_484) (joinEvery r7_485_489 (joinEvery r7_490_494 r7_495_499))))) (joinEvery (joinEvery (joinEvery (joinEvery r7_500_504 r7_505_509) (joinEvery r7_510_514 (joinEvery r7_515_519 r7_520_524))) (joinEvery (joinEvery r7_525_529 r7_530_534) (joinEvery r7_535_539 (joinEvery r7_540_544 r7_545_549)))) (joinEvery (joinEvery (joinEvery r7_550_554 r7_555_559) (joinEvery r7_560_564 (joinEvery r7_565_569 r7_570_574))) (joinEvery (joinEvery r7_575_579 r7_580_584) (joinEvery r7_585_589 (joinEvery r7_590_594 r7_595_599))))))
end OMA.RankThreeFourSmallCompactTables245212
#print axioms OMA.RankThreeFourSmallCompactTables245212.span7_400_599
