import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b72_5_0 : every 1 2 (movingRow 1666 195 864 5)=true := by decide +kernel
private theorem r72_5 : every 5 5 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 5=true := b72_5_0
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=5 by omega] using yes
private theorem b72_5_1 : every 6 6 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_5_2 : every 1 2 (movingRow 1666 195 864 7)=true := by decide +kernel
private theorem r72_7 : every 7 7 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 7=true := b72_5_2
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=7 by omega] using yes
private theorem b72_5_3 : every 8 10 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_5_4 : every 1 3 (movingRow 1666 195 864 11)=true := by decide +kernel
private theorem r72_11 : every 11 11 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 11=true := b72_5_4
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=11 by omega] using yes
private theorem b72_5_5 : every 12 12 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_5_6 : every 1 3 (movingRow 1666 195 864 13)=true := by decide +kernel
private theorem r72_13 : every 13 13 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 13=true := b72_5_6
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=13 by omega] using yes
private theorem b72_5_7 : every 14 16 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_5_8 : every 1 4 (movingRow 1666 195 864 17)=true := by decide +kernel
private theorem r72_17 : every 17 17 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 17=true := b72_5_8
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=17 by omega] using yes
private theorem b72_5_9 : every 18 18 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_5_10 : every 1 6 (movingRow 1666 195 864 19)=true := by decide +kernel
private theorem r72_19 : every 19 19 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 19=true := b72_5_10
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=19 by omega] using yes
private theorem b72_5_11 : every 20 22 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_5_12 : every 1 11 (movingRow 1666 195 864 23)=true := by decide +kernel
private theorem r72_23 : every 23 23 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 23=true := b72_5_12
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=23 by omega] using yes
private theorem b72_5_13 : every 24 28 (run 72 1666 195 864)=true := by decide +kernel
theorem span72_5_28 : every 5 28 (run 72 1666 195 864)=true := (joinEvery (joinEvery (joinEvery r72_5 (joinEvery b72_5_1 r72_7)) (joinEvery (joinEvery b72_5_3 r72_11) (joinEvery b72_5_5 r72_13))) (joinEvery (joinEvery b72_5_7 (joinEvery r72_17 b72_5_9)) (joinEvery (joinEvery r72_19 b72_5_11) (joinEvery r72_23 b72_5_13))))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span72_5_28
