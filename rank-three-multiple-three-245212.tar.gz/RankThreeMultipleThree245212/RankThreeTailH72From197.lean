import RankThreeFourSmallFast245212
/-! Explicitly bounded kernel blocks for the two remaining prime powers. -/
namespace OMA.RankThreeFourSmallFastTables245212
open OMA.CofactorEulerPair245212 OMA.RankThreeFourSmallFast245212
open OMA.RankThreeMiddle245212 (joinEvery)
set_option maxRecDepth 65536
set_option maxHeartbeats 2200000
private theorem b72_197_0 : every 198 63 (quick 72 1666 195 864 197)=true := by decide +kernel
private theorem b72_197_1 : every 1 25 (far 72 1666 195 864 197 198 14)=true := by decide +kernel
private theorem b72_197_2 : every 26 47 (far 72 1666 195 864 197 198 14)=true := by decide +kernel
private theorem r72_197 : every 197 197 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 197=true := by change (every 198 63 (quick 72 1666 195 864 197) && every 1 47 (far 72 1666 195 864 197 198 14))=true; rw [Bool.and_eq_true]; exact ⟨b72_197_0,(joinEvery b72_197_1 b72_197_2)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=197 by omega] using yes
private theorem b72_197_3 : every 198 198 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_197_4 : every 200 63 (quick 72 1666 195 864 199)=true := by decide +kernel
private theorem b72_197_5 : every 1 25 (far 72 1666 195 864 199 200 14)=true := by decide +kernel
private theorem b72_197_6 : every 26 48 (far 72 1666 195 864 199 200 14)=true := by decide +kernel
private theorem r72_199 : every 199 199 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 199=true := by change (every 200 63 (quick 72 1666 195 864 199) && every 1 48 (far 72 1666 195 864 199 200 14))=true; rw [Bool.and_eq_true]; exact ⟨b72_197_4,(joinEvery b72_197_5 b72_197_6)⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=199 by omega] using yes
private theorem b72_197_7 : every 200 210 (run 72 1666 195 864)=true := by decide +kernel
private theorem b72_197_8 : every 212 62 (quick 72 1666 195 864 211)=true := by decide +kernel
private theorem b72_197_9 : every 1 25 (far 72 1666 195 864 211 212 14)=true := by decide +kernel
private theorem b72_197_10 : every 26 50 (far 72 1666 195 864 211 212 14)=true := by decide +kernel
private theorem b72_197_11 : every 51 51 (far 72 1666 195 864 211 212 14)=true := by decide +kernel
private theorem r72_211 : every 211 211 (run 72 1666 195 864)=true := by
  have yes : run 72 1666 195 864 211=true := by change (every 212 62 (quick 72 1666 195 864 211) && every 1 51 (far 72 1666 195 864 211 212 14))=true; rw [Bool.and_eq_true]; exact ⟨b72_197_8,(joinEvery b72_197_9 (joinEvery b72_197_10 b72_197_11))⟩
  apply List.all_eq_true.mpr;intro z hz;obtain ⟨a,b⟩:=List.mem_range'_1.mp hz
  simpa only [show z=211 by omega] using yes
private theorem b72_197_12 : every 212 220 (run 72 1666 195 864)=true := by decide +kernel
theorem span72_197_220 : every 197 220 (run 72 1666 195 864)=true := (joinEvery (joinEvery r72_197 (joinEvery b72_197_3 r72_199)) (joinEvery b72_197_7 (joinEvery r72_211 b72_197_12)))
end OMA.RankThreeFourSmallFastTables245212
#print axioms OMA.RankThreeFourSmallFastTables245212.span72_197_220
