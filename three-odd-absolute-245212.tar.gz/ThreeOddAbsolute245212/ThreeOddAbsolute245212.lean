import MiddleClose245212
import MiddleEscapeRanges245212

/-! An absolute computable whole-integer height for the three odd prime case,
also stated directly in terms of the support of an arbitrary positive integer. -/
namespace OMA.ThreeOddAbsolute245212
open Nat Finset ArithmeticFunction
open scoped ArithmeticFunction.sigma
open private OMA.MiddleClose245212.no_escape from MiddleClose245212

def cutoff := OMA.MiddleEscapeRanges245212.cap
  (OMA.MiddleBridge245212.threshold+OMA.MiddlePoleFinite245212.cutoff OMA.MiddleBridge245212.exponent+1)

theorem ordered {k p q r a b d : ℕ} (pp : p.Prime) (qp : q.Prime) (rp : r.Prime)
    (p3 : 3≤p) (pq : p<q) (qr : q<r) (ap : 0<a) (bp : 0<b) (dp : 0<d)
    (eqn : OeisA245212.a (2^k*p^a*q^b*r^d)=(σ 1 (2^k*p^a*q^b*r^d):ℤ)) :
    2^k*p^a*q^b*r^d≤cutoff := by
  let x:=OMA.MiddleBridge245212.threshold
  let y:=OMA.MiddlePoleFinite245212.cutoff OMA.MiddleBridge245212.exponent
  obtain low|⟨k0,p33,L,left,right⟩:= OMA.MiddleEscapeRanges245212.at_cap (x+y+1) pp qp rp p3 pq qr ap bp dp eqn
  · exact low
  · have xL : x≤b+1:=((Nat.le_add_right _ _).trans (Nat.le_succ _)).trans L
    have yL : y<b+1:=(Nat.lt_succ_of_le (Nat.le_add_left _ _)).trans_le L
    have mixed:=OMA.MiddleBridge245212.original pp qp rp p33 pq qr ap bp dp k0 xL left right eqn
    exact False.elim (OMA.MiddleClose245212.no_escape pp (pp.odd_of_ne_two (by omega)) qp.two_le yL mixed)

theorem odd_part {k m : ℕ} (odd : Odd m) (rank : m.primeFactors.card=3)
    (eqn : OeisA245212.a (2^k*m)=(σ 1 (2^k*m):ℤ)) : 2^k*m≤cutoff := by
  let P : Fin 3 ↪o ℕ := m.primeFactors.orderEmbOfFin rank
  let e (i : Fin 3):=m.factorization (P i)
  have mem (i : Fin 3) : P i∈m.primeFactors := m.primeFactors.orderEmbOfFin_mem rank i
  have pr (i) := prime_of_mem_primeFactors (mem i)
  have ep (i) : 0<e i := (pr i).factorization_pos_of_dvd odd.pos.ne' (dvd_of_mem_primeFactors (mem i))
  have oddp:=Nat.coprime_two_left.mp ((Nat.coprime_two_left.mpr odd).of_dvd_right (dvd_of_mem_primeFactors (mem 0)))
  have least : 3≤P 0 := by have := (pr 0).two_le;obtain ⟨j,hj⟩:=oddp;omega
  have prod:=Nat.prod_primeFactors_pow_factorization odd.pos.ne'
  have lift : Finset.univ.map P.toEmbedding=m.primeFactors := m.primeFactors.map_orderEmbOfFin_univ rank
  rw [←lift,prod_map,Fin.prod_univ_three] at prod
  change m=(P 0)^(e 0)*(P 1)^(e 1)*(P 2)^(e 2) at prod
  have repr : 2^k*m=2^k*(P 0)^(e 0)*(P 1)^(e 1)*(P 2)^(e 2) := by
    simpa only [mul_assoc] using congrArg (2^k*·) prod
  rw [repr] at eqn ⊢
  exact ordered (pr 0) (pr 1) (pr 2) least (P.strictMono (by decide : (0:Fin 3)<1))
    (P.strictMono (by decide : (1:Fin 3)<2)) (ep 0) (ep 1) (ep 2) eqn

theorem original {n : ℕ} (pos : 0<n) (rank : (n.primeFactors.erase 2).card=3)
    (eqn : OeisA245212.a n=(σ 1 n:ℤ)) : n≤cutoff := by
  let m:=ordCompl[2] n
  let k:=n.factorization 2
  have cm : Odd m:=Nat.coprime_two_left.mp (Nat.coprime_ordCompl prime_two pos.ne')
  have ss : m.primeFactors=n.primeFactors.erase 2 := by
    dsimp [m];rw [←Nat.support_factorization,Nat.factorization_ordCompl,Finsupp.support_erase,Nat.support_factorization]
  have id : 2^k*m=n:=Nat.ordProj_mul_ordCompl_eq_self n 2
  have h := odd_part (k:=k) cm (ss ▸ rank) (by rwa [id])
  rwa [id] at h

theorem finite : {n : ℕ | 0<n ∧ (n.primeFactors.erase 2).card=3 ∧ OeisA245212.a n=(σ 1 n:ℤ)}.Finite :=
  (Set.finite_Iic cutoff).subset (fun _ h=>original h.1 h.2.1 h.2.2)

end OMA.ThreeOddAbsolute245212
