import LeastTallScale245212
import PairHeight245212

/-! Explicit cutoff at which two exactly kept short factors are impossible,
and the surviving exact cofactor has polynomial height with leading constant one. -/
namespace OMA.MiddleCut245212
open Nat Finset ArithmeticFunction OMA.SingleMovingGap245212
open scoped ArithmeticFunction.sigma
open OMA.ThreeMovingOriginal245212 (F G)
open OMA.Smooth245212 (total W)
open private OMA.PairHeight245212.moment_bound from PairHeight245212

def cutoff (C E D : ℕ) := C+512+OMA.LeastTallScale245212.cutoff C E (20*D)

def scale (k L : ℕ) := 128*(F k+G k+1)*(L+1)
def exponent (E D : ℕ) := (E+1)+(2*(E+1)+3)*D

theorem size {C E D k L : ℕ} (high : cutoff C E D≤L) (dyad : 2^k≤C*(L+1)^E)
    (y : ℕ) (yp : y≤(scale k L)^D) : 2^k*y≤(L+1)^(exponent E D) := by
  have cl : C≤L+1 := by dsimp [cutoff] at high;omega
  have b : 512≤L+1:=by dsimp [cutoff] at high;omega
  let t:=2^k
  have tp : 0<t:=Nat.two_pow_pos k
  have dk : t≤(L+1)^(E+1):=by
    rw [pow_succ'];exact dyad.trans (Nat.mul_le_mul_right _ cl)
  have kg : G k≤2*t := by dsimp [G,t];rw [pow_succ];omega
  have kcap : k+1≤t:=Nat.lt_pow_self (by decide)
  have bound : F k+G k+1≤4*t^2:=by
    dsimp only [F];rw [pow_succ,←show t=2^k by rfl]
    nlinarith only [kg,Nat.mul_le_mul_right (2*t) kcap,Nat.one_le_pow 2 t tp]
  have sc : scale k L≤(L+1)^(2*(E+1)+3) := calc
    _ ≤ 128*(4*t^2)*(L+1):=Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ bound)
    _ ≤ (L+1)^2*((L+1)^(E+1))^2*(L+1):=by
      have bs : 512 ≤ (L+1)^2:=b.trans (Nat.le_self_pow (by decide) _)
      nlinarith only [Nat.mul_le_mul_right (L+1) (Nat.mul_le_mul bs (Nat.pow_le_pow_left dk 2))]
    _ = _:=by rw [pow_add (L+1) (2*(E+1)) 3,mul_comm 2 (E+1),pow_mul (L+1) (E+1) 2];ring
  dsimp [exponent]
  rw [pow_add,pow_mul]
  exact Nat.mul_le_mul dk (yp.trans (Nat.pow_le_pow_left sc D))

theorem power {C E D k L q b : ℕ} (dp : 1≤D) (dyad : 2^k≤C*(L+1)^E)
    (high : cutoff C E D≤L) (long : b+1=L) (qp : 2≤q) :
    k+1≤L ∧ 2^k≤ scale k L ∧ L≤ scale k L ∧ 128≤ scale k L ∧ 
    (scale k L)^(20*D)<q^b := by
  have ln : OMA.LeastTallScale245212.cutoff C E (20*D)≤L:=by dsimp [cutoff] at high;omega
  have large:=OMA.LeastTallScale245212.scale dyad ln (by decide : 2≤2) long
  have base : 2^k≤G k:=by dsimp [G];rw [pow_succ];have:=Nat.two_pow_pos k;omega
  let x:=scale k L
  have x1 : 2^k≤x ∧ L≤x ∧ 128≤x := by
    dsimp [x,scale]
    constructor
    · nlinarith only [base,Nat.zero_le (F k),Nat.zero_le L,Nat.zero_le ((F k+G k)*L)]
    constructor <;> nlinarith only [Nat.zero_le (F k),Nat.zero_le (G k),Nat.zero_le L,Nat.zero_le ((F k+G k)*L)]
  have gain : 2^k<2^b:= x1.1.trans_lt ((Nat.le_self_pow (by omega : 20*D≠0) x).trans_lt large)
  have kin := (pow_lt_pow_iff_right₀ (a:=(2:ℕ)) (by decide)).mp gain
  exact ⟨by omega,x1.1,x1.2.1,x1.2.2,large.trans_le (Nat.pow_le_pow_left qp b)⟩

theorem not_both {k p q r a b d Q x D : ℕ} (pp : p.Prime) (qp : q.Prime) (rp : r.Prime)
    (odd : Odd q) (pq : p<q) (qr : q<r) (bp : 0<b) (dp : 1≤D) (xb : 2≤x)
    (dyad : 2^k≤x) (bound : Q≤x^D) (power : x^(20*D)<q^b)
    (eqn : OeisA245212.a (2^k*p^a*q^b*r^d)=(σ 1 (2^k*p^a*q^b*r^d):ℤ)) :
    ¬(p^a≤Q ∧ r^d≤Q) := by
  rintro ⟨pa,rd⟩
  let m:=2^k*p^a*r^d
  let Z:=x^D
  have pow0 : 2≤Z:=xb.trans (Nat.le_self_pow (by omega : D≠0) _)
  have mB : m≤Z^3:=by
    calc
      _ ≤ Z*Z*Z:=Nat.mul_le_mul (Nat.mul_le_mul (dyad.trans (Nat.le_self_pow (by omega : D≠0) _)) (pa.trans bound)) (rd.trans bound)
      _ = _:=by ring
  have mp : 0< m:=by dsimp [m];have:=pp.pos;have:=rp.pos;positivity
  have cop : m.Coprime q:=(((Nat.coprime_two_left.mpr odd).pow_left k).mul_left
    (((Nat.coprime_primes pp qp).mpr pq.ne).pow_left a)).mul_left (((Nat.coprime_primes rp qp).mpr qr.ne').pow_left d)
  have boundQ:=OMA.PairHeight245212.last_square mp qp (by obtain ⟨z,h⟩:=odd;have:=qp.two_le;omega)
    cop bp (by simpa only [m,mul_comm,mul_left_comm,mul_assoc] using eqn)
  have moments:=OMA.PairHeight245212.moment_bound mp
  have h : q^b≤x^(20*D) := calc
    _ ≤ _:=boundQ
    _ ≤ (2*m^3)^2:=Nat.pow_le_pow_left moments 2
    _ ≤ (Z*(Z^3)^3)^2:=Nat.pow_le_pow_left (Nat.mul_le_mul pow0 (Nat.pow_le_pow_left mB 3)) 2
    _ = Z^20:=by ring
    _ = _:=by dsimp [Z];rw [←pow_mul,mul_comm D 20]
  omega

end OMA.MiddleCut245212
