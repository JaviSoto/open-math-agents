import MiddlePoleGap245212
import ThreeMovingDividend245212
import ComplementaryLocal245212

/-! Instantiate the positive bilinear gap using the two exact weighted
moments of the dyadic factor and the smallest odd-prime power. -/
namespace OMA.MiddlePoleOriginal245212
open Nat ArithmeticFunction OMA.Smooth245212 OMA.PositiveBilinearGap245212
open scoped ArithmeticFunction.sigma
open private OMA.DivisorHeight245212.dyadic_moments from ThreeMovingDividend245212

def K (k p a : ℕ) :=
  (k+1)*(a+1)*(p-1)^2*cost k (p*((a+1)*(p-1)-1)) 1

theorem original {k p a q B C : ℕ} (pr : p.Prime) (op : Odd p) (qg : 2≤q)
    (bp : 0<B) (cp : 0<C)
    (positive :
      C*W (2^k*p^a)<(q-1)*σ 1 (2^k*p^a))
    (hit :
      (2*(2^k*p^a)*σ 0 (2^k*p^a))*B*C*(q-1)^2=
      q*(W (2^k*p^a)*C*(B*(q-1)-1)+(σ 1 (2^k*p^a))*(q-1))) :
    B≤16*(K k p a)^5 := by
  let Z:=2^(k+1)
  let P:=p^a
  let g:=p*((a+1)*(p-1)-1)
  let m:=2^k*p^a
  let H:=2*m*σ 0 m
  let A:=W m
  let M:=(k+1)*(a+1)
  have cop : (2^k).Coprime (p^a):=((Nat.coprime_two_left.mpr op).pow_left k).pow_right a
  have ph : 0<p-1:=Nat.sub_pos_of_lt pr.one_lt
  have base : 1≤(a+1)*(p-1):=Nat.mul_pos (Nat.succ_pos _) ph
  have h : H=M*Z*P:=by
    dsimp only [H,m,M,Z,P]
    rw [isMultiplicative_sigma.map_mul_of_coprime cop,sigma_zero_apply_prime_pow prime_two,
      sigma_zero_apply_prime_pow pr,pow_succ]
    ring
  have localW : (p-1)^2*W (p^a)=g*P+1:=by
    dsimp only [g,P]
    zify [Nat.cast_sub pr.pos,Nat.cast_sub base]
    exact (OMA.ComplementaryLocal245212.moments pr a).2
  have w : (p-1)^2*A=(k*Z+1)*(g*P+1):=by
    dsimp only [A,m]
    rw [w_mult.map_mul_of_coprime cop,(OMA.DivisorHeight245212.dyadic_moments k).1,←localW]
    dsimp only [Z]
    ring
  have bound : σ 1 m≤H:=by
    have le : σ 1 m ≤ m*σ 0 m:=by
      rw [sigma_one_apply,sigma_zero_apply]
      calc
        _ ≤ ∑ _ ∈ m.divisors,m := Finset.sum_le_sum (fun _ hd=>Nat.divisor_le hd)
        _ = _ := by simp [mul_comm]
    dsimp only [H]
    nlinarith only [le,Nat.zero_le (m*σ 0 m)]
  exact OMA.MiddlePoleGap245212.mixed (Nat.two_pow_pos _) (pow_pos pr.pos _)
    (pow_pos ph 2) h w (by omega : 0<q-1) (by omega : q=(q-1)+1) cp bp bound positive hit

#print axioms original
end OMA.MiddlePoleOriginal245212
