import TwoTallGap245212

/-! Strict descent in a mixed moment with only two long exponents. -/
namespace OMA.TwoTallGap245212
open Nat Finset OMA.Smooth245212 OMA.TwoTallLocal245212

private theorem descend (c : Family) (b : Fin 3→Option Bool) (f g : ℕ) (gp : 0<g) (fg : c.k*g≤f)
    (moving : ∀i,i≠2 → b i≠none)
    (small : ∀i,b i=some true → c.p i≤ max (c.k+1) c.L) :
    score f g (x' c b) (y' c b)<score f g (exactX c) (exactY c) := by
  let mix (s : Finset (Fin 3)) (i : Fin 3) := if i∈s then exactX c i else x' c b i
  let miy (s : Finset (Fin 3)) (i : Fin 3) := if i∈s then exactY c i else y' c b i
  have adv (s : Finset (Fin 3)) {i} (fresh : i∉s) (bit : Bool) (bi : b i=some bit) :
      score f g (mix s) (miy s)<score f g (mix (insert i s)) (miy (insert i s)) := by
    have bound j : 1≤ mix s j ∧ 0≤ miy s j ∧ miy s j≤2/((c.e j:ℚ)+1) := by
      by_cases mem : j∈s
      · have v:=ranges (c.prime j) (c.positive j) none
        simpa only [mix,miy,if_pos mem,exactX,exactY,xx',yy'] using And.intro v.1 v.2.2
      · have v:=ranges (c.prime j) (c.positive j) (b j)
        simpa only [mix,miy,if_neg mem,x',y'] using And.intro v.1 v.2.2
    have product {j l : Fin 3} (jl : j≠l) : (miy s j*miy s l)*(c.m:ℚ)≤4 := by
      have den z : (0:ℚ)<(c.e z:ℚ)+1:=by positivity
      have L z : miy s z*((c.e z:ℚ)+1)≤2:=(le_div_iff₀ (den z)).mp (bound z).2.2
      have low (z : Fin 3) : (1:ℚ)≤(c.e z:ℚ)+1:=by have:=Nat.cast_nonneg (α:=ℚ) (c.e z);linarith
      have D z (lt : z≠2) : (c.m:ℚ)≤(c.e z:ℚ)+1:=by exact_mod_cast c.long z lt
      have mm : (c.m:ℚ)≤((c.e j:ℚ)+1)*((c.e l:ℚ)+1) := by
        by_cases j2 : j=2
        · have l2 : l≠2:=by intro h;exact jl (j2.trans h.symm)
          simpa using mul_le_mul (low j) (D l l2) (Nat.cast_nonneg c.m) (den j).le
        · simpa using mul_le_mul (D j j2) (low l) (by decide : (0:ℚ)≤1) (den j).le
      have co:=mul_le_mul (L j) (L l) (mul_nonneg (bound l).2.1 (den l).le) (by decide : (0:ℚ)≤2)
      nlinarith only [co,mul_le_mul_of_nonneg_left mm (mul_nonneg (bound j).2.1 (bound l).2.1)]
    have single {j l : Fin 3} (n : j≠i) (n' : l≠i) (jl : j≠l) :
        (f:ℚ)*mix s i*mix s j*mix s l+g*miy s i*miy s j*miy s l <
        f*mix (insert i s) i*mix (insert i s) j*mix (insert i s) l+
          g*miy (insert i s) i*miy (insert i s) j*miy (insert i s) l := by
      have size (inb : bit=true) : 4*(c.p i-1)<c.k*c.m := by
        have lim:=small i (inb ▸ bi)
        have before : c.p i-1≤ max c.k c.L := by omega
        exact (Nat.mul_le_mul_left _ before).trans_lt c.comparable
      have step:=move (c.prime i) (c.positive i) c.mp c.kp gp fg bit size
        (mix s j) (mix s l) (miy s j) (miy s l) (bound j).1 (bound l).1 (bound j).2.1 (bound l).2.1 (product jl)
      simpa [mix,miy,exactX,exactY,x',y',xx',yy',fresh,n,n',bi] using step
    dsimp [score]
    simp only [Fin.prod_univ_three]
    have choice : i=0 ∨ i=1 ∨ i=2 := by omega
    rcases choice with rfl|rfl|rfl
    · simpa only [mul_comm,mul_left_comm,mul_assoc] using single (j:=1) (l:=2) (by decide) (by decide) (by decide)
    · simpa only [mul_comm,mul_left_comm,mul_assoc] using single (j:=0) (l:=2) (by decide) (by decide) (by decide)
    · simpa only [mul_comm,mul_left_comm,mul_assoc] using single (j:=0) (l:=1) (by decide) (by decide) (by decide)
  obtain ⟨v,hv⟩ := Option.ne_none_iff_exists'.mp (moving 0 (by decide))
  obtain ⟨w,hw⟩ := Option.ne_none_iff_exists'.mp (moving 1 (by decide))
  have a:=adv ∅ (i:=0) (by decide) v hv
  have b1:=adv {0} (i:=1) (by decide) w hw
  have final : score f g (mix {1,0}) (miy {1,0})≤ score f g (mix univ) (miy univ) := by
    have setEq : insert (2:Fin 3) ({1,0} : Finset (Fin 3))=univ:=by decide
    cases h : b 2 with
    | some bit=> simpa only [setEq] using (adv {1,0} (i:=2) (by decide) bit h).le
    | none=>
      have xx : mix {1,0}=mix univ :=by funext i;fin_cases i <;> simp [mix,x',exactX,h,xx']
      have yy : miy {1,0}=miy univ :=by funext i;fin_cases i <;> simp [miy,y',exactY,h,yy']
      rw [xx,yy]
  simpa [mix,miy] using ((a.trans b1).trans_le final)

theorem nonzero (c : Family) (b : Fin 3→Option Bool) (f g l : ℕ) (gp : 0<g) (fg : c.k*g≤f)
    (moving : ∀i,i≠2 → b i≠none) (frac : f+g=(c.k+1)*l) (unit : ∀i,¬c.p i∣l)
    (actual : score f g (exactX c) (exactY c)≤(f+g:ℕ)) :
    (f+g)*dust c b ≠ f*NX c b+g*NY c b := by
  intro hit
  have less:=(descend c b f g gp fg moving (retained frac unit hit)).trans_le actual
  have val:=clear c b f g
  have id : ((f+g:ℕ):ℚ)*dust c b=((f*NX c b+g*NY c b:ℕ):ℚ) := by exact_mod_cast hit
  exact (ne_of_lt (mul_lt_mul_of_pos_right less (show (0:ℚ)<dust c b by exact_mod_cast dust_pos c b))) (val.trans id.symm)


end OMA.TwoTallGap245212
