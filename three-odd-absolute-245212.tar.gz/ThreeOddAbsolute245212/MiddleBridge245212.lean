import MiddleCut245212
import MiddleModes245212
import MiddleLeast245212
import ThreeModeMiddleEquation245212

/-! Transfer from the seven sorted integer parameters of the original equation
to the exact cofactor equation, with polynomial height independent of every prime. -/
namespace OMA.MiddleBridge245212
open Nat Finset ArithmeticFunction OMA.SingleMovingGap245212
open OMA.ThreeMovingOriginal245212 (F G)
open OMA.SingleMovingStep245212 (degree)
open OMA.SingleMovingHeight245212 (constant)
open OMA.Smooth245212 (total W)
open private OMA.SingleMovingOriginal245212.identities from SingleMovingOriginal245212
open scoped ArithmeticFunction.sigma

def output (D k p q a b d : ℕ) : Prop :=
  let h:=2^k*p^a
  let A:=W h;let S:=σ 1 h;let H:=2*h*(σ 0 h)
  let B:=b+1;let C:=d+1;let u:=q-1
  p≤4*(k+1) ∧ h≤(B+1)^D ∧ H*B*C*u^2=q*(A*C*(B*u-1)+S*u) ∧ A*C<S*u

theorem escape {C E k p q r a b d : ℕ} (dyadic : 2^k≤C*((b+1)+1)^E)
    (high : OMA.MiddleCut245212.cutoff C E degree≤b+1)
    (pp : p.Prime) (qp : q.Prime) (rp : r.Prime) (p33 : 33≤p) (pq : p<q) (qr : q<r)
    (ap : 0<a) (bp : 0<b) (dp : 0<d) (k0 : 256≤k)
    (left : 16*(a+1)<b+1) (right : 16*(d+1)<b+1)
    (eqn : OeisA245212.a (2^k*p^a*q^b*r^d)=(σ 1 (2^k*p^a*q^b*r^d):ℤ)) :
    output (OMA.MiddleCut245212.exponent E degree) k p q a b d := by
  let P : Fin 3→ℕ:=![p,q,r]
  let E' : Fin 3→ℕ:=![a,b,d]
  have pm i : (P i).Prime:=by fin_cases i <;> simp [P,pp,qp,rp]
  have od i : Odd (P i):=by
    apply (pm _).odd_of_ne_two
    fin_cases i <;> simp [P] <;> omega
  have inj : P.Injective:=by
    intro i j h
    fin_cases i <;> fin_cases j <;> simp_all [P] <;> omega
  have pos i : 0<E' i:=by fin_cases i <;> simp [E'] <;> omega
  let L:=b+1
  have lens i : E' i+1≤L:=by fin_cases i <;> simp [E',L] <;> omega
  let c : Family:=⟨P,E',k,L,pm,pos,by omega,⟨1,rfl⟩,lens,inj⟩
  let x:=OMA.MiddleCut245212.scale k L
  let f:=F k
  let g:=G k
  have kd:=OMA.SingleMovingOriginal245212.identities k
  have repr : 2^k*total P E'=2^k*p^a*q^b*r^d := by simp [total,Fin.prod_univ_three,P,E',mul_assoc]
  have actual:=OMA.SingleMovingOriginal245212.physical c k od inj (by rw [show 2^k*total c.p c.e=2^k*p^a*q^b*r^d from repr];exact eqn)
  have D0 : 1≤degree:=by decide
  obtain ⟨kL,dyad,xL,x128,pow⟩:=OMA.MiddleCut245212.power D0 dyadic high (rfl : b+1=L) qp.two_le
  have xfg : f+g≤x:=by
    dsimp only [x,OMA.MiddleCut245212.scale,f,g]
    nlinarith only [Nat.zero_le L,Nat.zero_le (F k+G k),Nat.zero_le ((F k+G k)*L)]
  obtain ⟨bits,Q,xQ,Qmax,rule,hit⟩:=OMA.MiddleWitness245212.witness c f g x x128 xfg xL actual
  have noalt : ¬(bits 0=none ∧ bits 2=none):=by
    rintro ⟨z,t⟩
    have extract (j) (h : bits j=none) : c.p j^c.e j≤Q := by
      by_contra no
      have v:=rule j
      simp [h,no] at v
    exact OMA.MiddleCut245212.not_both pp qp rp (od 1) pq qr bp D0 (by omega) dyad Qmax pow eqn
      ⟨extract 0 z,extract 2 t⟩
  have sm i : ¬c.p i∣2^(k+1):=by
    intro div
    have t:=(c.prime i).dvd_of_dvd_pow div
    have pr : c.p i≠2:=by obtain ⟨t,et⟩:=od i; change P i≠2; omega
    exact pr ((Nat.prime_dvd_prime_iff_eq (c.prime i) Nat.prime_two).mp t)
  have modes:=OMA.MiddleModes245212.force c bits kd.1 (by change k*G k≤F k;rw [kd.2.2];exact Nat.le_add_right _ _)
    rfl k0 kL pq (by change 2*a≤b;omega) right
    (by change L^6<q^b;exact (Nat.pow_le_pow_left xL 6).trans_lt
          ((Nat.pow_le_pow_right (by omega : 1≤x) (by omega : 6≤20*degree)).trans_lt pow))
    (Qmax.trans_lt ((Nat.pow_le_pow_right (by omega : 1≤x) (by omega : degree≤20*degree)).trans_lt pow))
    (xL.trans xQ) rule noalt (retained kd.2.1 sm hit) hit actual
  obtain ⟨m0,m1,m2,sgn⟩:=modes
  have eqm:=OMA.ThreeModeMiddleEquation245212.adapter c (od 0) bits m0 m1 m2 hit sgn
  have lp : ∀i,c.p 0≤c.p i:=by intro i;fin_cases i <;> change p≤_ <;> first | exact le_rfl | exact pq.le | exact (pq.trans qr).le
  have LB : 32≤L:=by
    have t : 512≤OMA.MiddleCut245212.cutoff C E degree :=by
      unfold OMA.MiddleCut245212.cutoff;omega
    omega
  have pB:=OMA.MiddleLeast245212.bound c (v:=1) rfl lp p33 LB actual
  have xp : p^a≤Q:=by
    by_contra off
    have no:c.p 0^c.e 0>Q:=Nat.lt_of_not_ge off
    have w:=rule 0
    rw [m0,if_neg no.not_ge] at w
    cases w
  exact ⟨pB,OMA.MiddleCut245212.size high dyadic _ (xp.trans Qmax),eqm⟩

def threshold := OMA.MiddleCut245212.cutoff (constant degree) (2*degree) degree
def exponent := OMA.MiddleCut245212.exponent (2*degree) degree

theorem original {k p q r a b d : ℕ} (pp : p.Prime) (qp : q.Prime) (rp : r.Prime)
    (p33 : 33≤p) (pq : p<q) (qr : q<r) (ap : 0<a) (bp : 0<b) (dp : 0<d)
    (k0 : 256≤k) (high : threshold≤b+1)
    (left : 16*(a+1)<b+1) (right : 16*(d+1)<b+1)
    (eqn : OeisA245212.a (2^k*p^a*q^b*r^d)=(σ 1 (2^k*p^a*q^b*r^d):ℤ)) :
    output exponent k p q a b d := by
  apply escape _ high pp qp rp p33 pq qr ap bp dp k0 left right eqn
  let P : Fin 3→ℕ:=![p,q,r]
  let E : Fin 3→ℕ:=![a,b,d]
  have pm i : (P i).Prime:=by fin_cases i <;> simp [P,pp,qp,rp]
  have od i : Odd (P i):=by apply (pm _).odd_of_ne_two;fin_cases i <;> simp [P] <;> omega
  have inj : P.Injective:=by intro i j h;fin_cases i <;> fin_cases j <;> simp_all [P] <;> omega
  have pos i : 0<E i:=by fin_cases i <;> simp [E] <;> omega
  have repr : 2^k*total P E=2^k*p^a*q^b*r^d := by simp [total,Fin.prod_univ_three,P,E,mul_assoc]
  exact OMA.SingleMovingHeight245212.original k (b+1) P E pm od inj pos ⟨1,rfl⟩
    (fun i=>by fin_cases i <;> simp [E] <;> omega) (by rw [repr];exact eqn)

end OMA.MiddleBridge245212
