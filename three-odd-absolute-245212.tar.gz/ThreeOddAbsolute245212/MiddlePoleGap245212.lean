import PositiveBilinearGap245212

/-! A one-sided separation bound for the exact cofactor of the small odd
prime. It is polynomial in its parameters, even if both powers are huge. -/
namespace OMA.MiddlePoleGap245212
open OMA.PositiveBilinearGap245212

theorem relative {k g Z P L M H A U V R : ℕ} (zp : 0<Z) (pp : 0<P) (lp : 0<L)
    (h : H=M*Z*P) (a : L*A=(k*Z+1)*(g*P+1)) (rp : 0<R) (diff : V*A+R=U*H) :
    H≤M*L*cost (V*k) (V*g) V*R := by
  let C:=U*M*L-V*k*g
  have full : U*M*L*(Z*P)=V*k*g*(Z*P)+L*R+(V*k)*Z+(V*g)*P+V:=by
    nlinarith only [congrArg (L*·) diff,congrArg (V*·) a,congrArg ((U*L)*·) h]
  have left : V*k*g*(Z*P)≤U*M*L*(Z*P):=by omega
  have low:=Nat.le_of_mul_le_mul_right left (Nat.mul_pos zp pp)
  have key:=Nat.sub_add_cancel low
  have core : C*Z*P=L*R+(V*k)*Z+(V*g)*P+V:=by
    dsimp only [C]
    nlinarith only [full,congrArg (·*(Z*P)) key]
  have gap:=OMA.PositiveBilinearGap245212.gap (Nat.mul_pos lp rp) core
  rw [h]
  simpa only [mul_assoc,mul_comm,mul_left_comm] using Nat.mul_le_mul_left M gap

private theorem scale {q k g : ℕ} (qp : 0<q) :
    cost (q*k) (q*g) q≤q^3*cost k g 1 := by
  unfold cost
  rw [←mul_pow]
  apply Nat.pow_le_pow_left
  nlinarith only [show 1≤q from qp]

/-- If the middle-prime asymptotic moment hits exactly, its exponent
length is bounded without using the middle prime or either large power. -/
theorem mixed {k g Z P L M H A S u q B C : ℕ} (zp : 0<Z) (pp : 0<P) (lp : 0<L)
    (mh : H=M*Z*P) (ma : L*A=(k*Z+1)*(g*P+1)) (up : 0<u) (qu : q=u+1)
    (cp : 0<C) (bp : 0<B) (ss : S≤H) (positive : C*A<u*S)
    (hit : H*B*C*u^2=q*(A*C*(B*u-1)+S*u)) :
    let K:=M*L*cost k g 1
    B≤16*K^5 := by
  let K:=M*L*cost k g 1
  let E:=H*u-A*q
  let Δ:=H-A
  have qp : 0<q:=by omega
  have bu:=Nat.sub_add_cancel (show 1≤B*u from Nat.mul_pos bp up)
  have raw : B*u*C*(H*u)+q*(A*C)=B*u*C*(A*q)+q*(u*S):=by
    nlinarith only [hit,congrArg (fun z : ℕ=>q*(A*C)*z) bu]
  have strict : A*q<H*u:=by
    by_contra! no
    have small:=Nat.mul_le_mul_left (B*u*C) no
    have sign:=Nat.mul_lt_mul_of_pos_left positive qp
    nlinarith only [raw,small,sign]
  have ep : 0<E:=Nat.sub_pos_of_lt strict
  have ee : q*A+E=u*H:=by
    rw [Nat.mul_comm q A,Nat.mul_comm u H,Nat.add_comm]
    exact Nat.sub_add_cancel strict.le
  have ah : A<H:=by
    by_contra! no
    have bad:=Nat.mul_le_mul_right u no
    rw [qu,Nat.mul_add,Nat.mul_one] at strict
    omega
  have dp : 0<Δ:=Nat.sub_pos_of_lt ah
  have de : 1*A+Δ=1*H:=by dsimp [Δ];omega
  have small : H≤K*Δ:=by
    simpa only [one_mul] using relative zp pp lp mh ma dp de
  have kp : 0<K:=by
    by_contra! no
    have zero : K=0:=by omega
    rw [zero,zero_mul] at small
    omega
  have sb : B*E≤q*H:=by
    have prod : B*u*C*E+q*(A*C)=q*(u*S):=by
      nlinarith only [raw,congrArg (fun z : ℕ=>B*u*C*z) ee]
    have main : (B*E*C)*u≤(q*S)*u:=by nlinarith only [prod,Nat.zero_le (q*(A*C))]
    have bare:=Nat.le_of_mul_le_mul_right main up
    exact (Nat.le_mul_of_pos_right _ cp).trans (bare.trans (Nat.mul_le_mul_left q ss))
  have iden : q*Δ=E+H:=by
    simp only [one_mul] at de
    nlinarith only [ee,congrArg (q*·) de,congrArg (·*H) qu]
  change B≤16*K^5
  by_cases large : 2*K≤q
  · have high:=Nat.mul_le_mul_right Δ large
    have two : q*Δ≤2*E:=by nlinarith only [high,iden,small]
    have chain : B*E≤(2*K)*E:=by
      calc
        B*E ≤ q*H := sb
        _ ≤ K*(q*Δ) := by simpa only [mul_assoc,mul_left_comm,mul_comm] using Nat.mul_le_mul_left q small
        _ ≤ (2*K)*E := by simpa only [mul_assoc,mul_left_comm,mul_comm] using Nat.mul_le_mul_left K two
    have bsmall:=Nat.le_of_mul_le_mul_right chain ep
    have pow : K≤K^5:=by simpa only [pow_one] using Nat.pow_le_pow_right kp (by decide : 1≤5)
    omega
  · have rel:=relative zp pp lp mh ma ep ee
    have cap : H≤q^3*K*E:=by
      exact rel.trans (by
        have s:=Nat.mul_le_mul_right E (Nat.mul_le_mul_left (M*L) (scale (k:=k) (g:=g) qp))
        simpa only [K,mul_comm,mul_left_comm,mul_assoc] using s)
    have tight : B*E≤(q^4*K)*E:=sb.trans (by
      calc
        q*H ≤ q*(q^3*K*E) := Nat.mul_le_mul_left q cap
        _ = _ := by ring)
    have bnd:=Nat.le_of_mul_le_mul_right tight ep
    calc
      B ≤ q^4*K := bnd
      _ ≤ (2*K)^4*K := Nat.mul_le_mul_right K (Nat.pow_le_pow_left (by omega) _)
      _ = 16*K^5 := by ring

#print axioms mixed
end OMA.MiddlePoleGap245212
