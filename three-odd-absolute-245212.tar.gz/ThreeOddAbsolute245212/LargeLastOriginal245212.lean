import LargeLastInteger245212
import LargeLastSize245212
import LargeLastCofactor245212
import DyadicLeast245212

/-! The largest of three odd prime bases cannot carry an exponent
arbitrarily larger than the sum of the other two, uniformly in k. -/
namespace OMA.LargeLastOriginal245212
open Nat Finset ArithmeticFunction OMA.Smooth245212 OMA.LargeLastPhysical245212
open scoped ArithmeticFunction.sigma

theorem largest {k p q r a b d : ℕ} (pp : p.Prime) (qp : q.Prime) (rp : r.Prime)
    (p3 : 3≤p) (pq : p<q) (qr : q<r) (ap : 0<a) (bp : 0<b) (dp : 0<d)
    (eqn : OeisA245212.a (2^k*p^a*q^b*r^d)=(σ 1 (2^k*p^a*q^b*r^d):ℤ)) :
    d≤4*(a+b)+31 := by
  by_contra! long
  let h:=p^a*q^b
  let A:=W h
  let S:=σ 1 h
  let T:=h*σ 0 h
  let n:=a+b
  let D:=B r d
  let X:=w r d
  let Y:=s r
  have r5 : 5≤r:=by omega
  have r1:=rp.pos
  have po:=pp.odd_of_ne_two (by omega)
  have qo:=qp.odd_of_ne_two (by omega)
  have ro:=rp.odd_of_ne_two (by omega)
  have ho : Odd h:=(po.pow).mul (qo.pow)
  have op : Odd (h*r^d):=ho.mul ro.pow
  have localEq : OeisA245212.a (2^k*h*r^d)=(σ 1 (2^k*h*r^d):ℤ) := by
    simpa only [h,mul_assoc] using eqn
  have br : r∈(h*r^d).primeFactors := mem_primeFactors.mpr
    ⟨rp,dvd_mul_of_dvd_right (dvd_pow_self _ dp.ne') _,op.pos.ne'⟩
  have kcap:=OMA.DyadicLeast245212.exponent_lt_twice_prime op br (by simpa only [mul_assoc] using localEq)
  have cop : h.Coprime r:=(((coprime_primes pp rp).mpr (pq.trans qr).ne).pow_left a).mul_left
    (((coprime_primes qp rp).mpr qr.ne).pow_left b)
  have idn:=identity ho.pos ho rp ro cop localEq
  have ext1 : OMA.LargestPrimeExponent245212.extra p q r≤1 := by unfold OMA.LargestPrimeExponent245212.extra;split <;> decide
  have coarse:=OMA.LargestPrimeExponent245212.triple_of_power pp qp rp p3 pq qr (Nat.pow_le_pow_left r5 k) eqn
  have d2 : d+1≤2*k := by omega
  have dyad : r^(n+10)≤2^k := by
    by_contra! small
    have fives : 5^k ≤ r^(3*(n+10)) := calc
      _ ≤ (2^3)^k := Nat.pow_le_pow_left (by decide) _
      _ = (2^k)^3 := by rw [←pow_mul,←pow_mul,mul_comm 3 k]
      _ ≤ (r^(n+10))^3 := Nat.pow_le_pow_left small.le _
      _ = _ := by rw [←pow_mul,mul_comm]
    have sharper:=OMA.LargestPrimeExponent245212.triple_of_power pp qp rp p3 pq qr fives eqn
    dsimp [n] at sharper;omega
  have cf:=OMA.LargeLastCofactor245212.pair pp qp p3 pq qr ap bp
  change 0<A ∧ T≤A ∧ 2*S≤A ∧ A≤r^(n+2) ∧ σ 0 h=(a+1)*(b+1) at cf
  obtain ⟨apos,tA,sA,aCap,tau⟩:=cf
  have sz:=OMA.LargeLastSize245212.sizes (A:=A) (T:=T) (S:=S) r5 kcap d2 aCap
    (by omega) tA (by dsimp [n];omega) dyad
  have wden : D≤X := by
    have rpos := Nat.sub_add_cancel (by omega : 1≤r)
    have du : 1≤(d+1)*(r-1) := Nat.mul_pos (Nat.succ_pos _) (by omega)
    have sub:=Nat.sub_add_cancel du
    have delta:=Nat.mul_le_mul (by omega : 2≤d+1) (le_refl (r-1))
    dsimp [D,X,B,w,u]
    nlinarith only [rpos,congrArg ((r:ℕ)*·) sub,congrArg (fun z=> (d+1)*(r-1)*z) rpos,delta,r5]
  let J:ℤ:=(k+1)*(T:ℤ)*D-k*(A:ℤ)*X-S*(Y:ℤ)
  let U:ℤ:=(k:ℤ)*A-(u r:ℤ)*S
  let V:ℤ:=((k:ℤ)+1)*((A:ℤ)*X-T*(D:ℤ))
  have rposZ : (0:ℤ)<(r:ℤ)^d:=by have:=rp.pos;positivity
  have gp : 1≤G k := by dsimp [G];rw [pow_succ];have:=Nat.two_pow_pos k;omega
  have vz : 0≤V := by
    have zz : (T:ℤ)*D≤(A:ℤ)*X:=by exact_mod_cast Nat.mul_le_mul tA wden
    dsimp [V];positivity
  have mag : |U|≤(k*A+u r*S:ℕ):=by
    change |(k:ℤ)*A-(u r:ℤ)*S|≤_
    rw [abs_le];push_cast
    constructor <;> nlinarith only [Nat.cast_nonneg (k*A) (α:=ℤ),Nat.cast_nonneg (u r*S) (α:=ℤ)]
  have sm : 4*(|U|+((k:ℤ)+1)*A)≤(r:ℤ)^d := by
    have mg : 4*(((k*A+u r*S:ℕ):ℤ)+(k+1)*A) ≤ (r:ℤ)^d := by exact_mod_cast sz.1
    linarith only [mag,mg]
  have sm' : 4*V≤(G k:ℤ) := by
    have mg : (4:ℤ)*((k+1)*((A:ℤ)*X+T*(D:ℤ)))≤G k := by exact_mod_cast sz.2
    have extra : 0≤((k:ℤ)+1)*(T*D:ℕ):=by positivity
    push_cast at extra
    dsimp [V];nlinarith only [extra,mg]
  change (G k:ℤ)*r^d*J=(G k)*U+((k:ℤ)+1)*A+(r:ℤ)^d*V at idn
  have Z:=OMA.LargeLastInteger245212.zero (by exact_mod_cast gp) rposZ (by positivity) sm vz sm' idn
  have natJ : (k+1)*T*D=k*A*X+S*Y := by
    dsimp [J] at Z
    exact_mod_cast (show ((k:ℤ)+1)*T*D=k*(A:ℤ)*X+S*(Y:ℤ) by linarith only [Z])
  have near : r≤2*k+1 := by
    by_contra! far
    have dv : r∣(k+1)*T*D := natJ ▸ dvd_add
      (dvd_mul_of_dvd_right (dvd_mul_right r _) _) (dvd_mul_of_dvd_right (dvd_mul_right r _) _)
    have none (v : ℕ) (vpos : 0<v) (vlt : v<r) := Nat.not_dvd_of_pos_of_lt vpos vlt
    have kk:=none (k+1) (by omega) (by omega)
    have aa:=none (a+1) (by omega) (by omega)
    have bb:=none (b+1) (by omega) (by omega)
    have dd:=none (d+1) (by omega) (by omega)
    have uu:=none (u r) (by dsimp [u];omega) (by dsimp [u];omega)
    have cr : ¬r∣h:=rp.coprime_iff_not_dvd.mp cop.symm
    dsimp [T,D,B] at dv
    rw [tau] at dv
    rcases rp.dvd_mul.mp dv with left|right
    · rcases rp.dvd_mul.mp left with hit|hit
      · exact kk hit
      rcases rp.dvd_mul.mp hit with hit|hit
      · exact cr hit
      exact (rp.dvd_mul.mp hit).elim aa bb
    · exact (rp.dvd_mul.mp right).elim dd (fun w=>uu (rp.dvd_of_dvd_pow w))
  have positive : 0≤U := by
    have ub : u r≤2*k := by dsimp [u];omega
    have start : u r*S≤k*A := (Nat.mul_le_mul_right S ub).trans
      ((show 2*k*S=k*(2*S) by ring) ▸ Nat.mul_le_mul_left k sA)
    exact sub_nonneg.mpr (by exact_mod_cast start)
  rw [Z,mul_zero] at idn
  have ga : 0≤(G k:ℤ)*U:=mul_nonneg (by positivity) positive
  have wa : 0<((k:ℤ)+1)*A:=mul_pos (by positivity) (by exact_mod_cast apos)
  have ra : 0≤(r:ℤ)^d*V:=mul_nonneg rposZ.le vz
  linarith only [idn,ga,wa,ra]

end OMA.LargeLastOriginal245212
