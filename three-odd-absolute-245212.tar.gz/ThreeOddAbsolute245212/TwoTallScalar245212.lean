import ComplementarySize245212

/-! Integer growth estimates and an empty multiplicative interval for three bases and the third prime power. -/
namespace OMA.TwoTallScalar245212

def cut (x j : ℕ) := x^(16^j)

theorem cut_succ (x i : ℕ) : cut x (i+1)=(cut x i)^16 := by
  rw [cut,cut,pow_succ,pow_mul]

theorem cut_mono {x : ℕ} (pos : 1≤x) : Monotone (cut x) :=
  fun _ _ le=>Nat.pow_le_pow_right pos (Nat.pow_le_pow_right (by decide) le)

theorem empty_interval (x : ℕ) (hx : 1≤x) (p : Fin 4→ℕ) :
    ∃j : Fin 5,∀i, p i ≤ cut x j.val ∨ cut x (j.val+1) < p i := by
  by_contra! no
  choose f above below using no
  have inj:Function.Injective f := by
    intro j k eqn
    rcases lt_trichotomy j k with lt|eq|gt
    · have h := cut_mono hx (show j.val+1≤k.val from lt)
      have impossible:=(below j).trans h
      rw [eqn] at impossible
      exact False.elim ((above k).not_ge impossible)
    · exact eq
    · have h := cut_mono hx (show k.val+1≤j.val from gt)
      have impossible:=(below k).trans h
      rw [←eqn] at impossible
      exact False.elim ((above j).not_ge impossible)
  have:=Fintype.card_le_of_injective _ inj
  norm_num at this

def budget := 16^5

def base (k L : ℕ) := 128*(k+2)*(L+1)

-- The larger exponent covers substitution of the exact dyadic numerator.
def degree := (budget+4)*budget

def minimumCut := 64*(degree+1)^2

private theorem square_product (p m F : ℕ) : ((p^14*m^2)^F)^2=p^(28*F)*m^(4*F) := by
  rw [←pow_mul,mul_pow,←pow_mul,←pow_mul,show 14*(F*2)=28*F by ring,show 2*(F*2)=4*F by ring]

theorem scale {m k L p e : ℕ} (hp : 3≤p) (hk : k<2*p) (hm : minimumCut ≤ m)
    (comparable : L ≤ k*m^2) (low : m≤e+1) :
    (base k L)^degree ≤ p^e := by
  let F:=degree
  have fp : 1≤F := by decide
  change 64*(F+1)^2≤ m at hm
  have mp : 1≤ m:=by nlinarith only [hm,Nat.zero_le (F^2),Nat.zero_le F]
  have pp : 1≤p:=by omega
  have kcap : k+2≤4*p := by omega
  have Lcap : L+1≤3*p*m^2 := by
    have mpos:=Nat.mul_pos (show 0<p by omega) (pow_pos mp 2)
    nlinarith only [comparable,Nat.mul_le_mul_right (m^2) hk.le,mpos]
  have scale : base k L≤p^14*m^2 := by
    have sixteen : 1536≤p^12 := (by decide : 1536≤3^12).trans (Nat.pow_le_pow_left hp _)
    have b:=Nat.mul_le_mul kcap Lcap
    dsimp [base]
    nlinarith only [Nat.mul_le_mul_left 128 b,Nat.mul_le_mul_right (p^2*m^2) sixteen]
  have grow := OMA.ComplementarySize245212.absorb (d:=2*F) (b:=m) (by nlinarith only [hm,Nat.zero_le F])
  have poly : m^(4*F)≤p^m := (by convert grow using 1; ring : m^(4*F)≤2^m).trans (Nat.pow_le_pow_left (by omega) _)
  have gain : 28*F+m≤2*e := by
    nlinarith only [hm,low,Nat.zero_le (F^2)]
  apply (pow_le_pow_iff_left₀ (show 0≤(base k L)^degree from Nat.zero_le _) (Nat.zero_le _) (by decide : 2≠0)).mp
  change ((base k L)^F)^2≤(p^e)^2
  calc
    _ ≤ ((p^14*m^2)^F)^2 := Nat.pow_le_pow_left (Nat.pow_le_pow_left scale _) _
    _ = p^(28*F)*m^(4*F) := square_product p m F
    _ ≤ p^(28*F)*p^m := Nat.mul_le_mul_left _ poly
    _ = p^(28*F+m) := (pow_add ..).symm
    _ ≤ p^(2*e) := Nat.pow_le_pow_right pp gain
    _ = (p^e)^2 := by rw [mul_comm,pow_mul]

end OMA.TwoTallScalar245212
