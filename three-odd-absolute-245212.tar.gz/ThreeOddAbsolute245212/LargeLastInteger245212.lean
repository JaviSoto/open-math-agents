import Mathlib

/-! Integer separation when a large final prime power and a large dyadic
power occur together. All errors are kept as signed integers. -/
namespace OMA.LargeLastInteger245212

theorem zero {G R J U V A : ℤ} (gp : 1≤G) (rp : 0<R) (ap : 0≤A)
    (small : 4*(|U|+A)≤R) (lower : 0≤V) (upper : 4*V≤G)
    (idn : G*R*J=G*U+A+R*V) : J=0 := by
  have g0 : 0≤G:=by omega
  have gu : 4*(G*U+A)≤G*R := by
    have h:=mul_le_mul_of_nonneg_left small g0
    have m:=mul_le_mul_of_nonneg_left (le_abs_self U) g0
    have n:=mul_le_mul_of_nonneg_right gp ap
    nlinarith only [h,m,n]
  have gl : -(G*R)≤4*(G*U+A) := by
    have hh:=mul_le_mul_of_nonneg_left small g0
    have mm:=mul_le_mul_of_nonneg_left (neg_le_abs U) g0
    have ga:=mul_nonneg g0 ap
    nlinarith only [hh,mm,ga,ap]
  have rv:=mul_le_mul_of_nonneg_left upper rp.le
  have rl:=mul_nonneg rp.le lower
  have prod : 0<G*R:=mul_pos (by omega) rp
  by_contra! ne
  rcases lt_or_gt_of_ne ne with neg|pos
  · have jneg : J≤ -1:=by omega
    have bad:=mul_le_mul_of_nonneg_left jneg prod.le
    nlinarith only [idn,gl,rl,bad,prod]
  · have jpos : 1≤J:=by omega
    have bad:=mul_le_mul_of_nonneg_left jpos prod.le
    nlinarith only [idn,gu,rv,bad,prod]

end OMA.LargeLastInteger245212
