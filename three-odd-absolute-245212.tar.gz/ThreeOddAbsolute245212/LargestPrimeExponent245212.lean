import PrimePowerDiv245212

/-! At the largest odd prime, the exponent is bounded almost additively
by the other exponents. This works with moving primes and moving dyadic order. -/
namespace OMA.LargestPrimeExponent245212
open Finset Nat ArithmeticFunction OMA.Smooth245212
open scoped ArithmeticFunction.sigma

private theorem updates {p : ℕ} (pr : p.Prime) (e : ℕ) :
    σ 1 (p^(e+1))=p*σ 1 (p^e)+1 ∧
    W (p^(e+1))=p*W (p^e)+σ 1 (p^(e+1)) := by
  constructor
  · rw [sigma_one_apply_prime_pow pr,sigma_one_apply_prime_pow pr,sum_range_succ']
    simp only [pow_succ',←mul_sum,pow_zero]
  · rw [w_pow pr,w_pow pr,sigma_one_apply_prime_pow pr,
      sum_range_succ' (fun j=>p^j*(j+1)) (e+1),sum_range_succ' (fun j=>p^j) (e+1)]
    simp only [pow_zero,zero_add,mul_one,pow_succ']
    rw [←add_assoc]
    congr 1
    rw [mul_sum,←sum_add_distrib]
    apply sum_congr rfl
    intro i _;ring

theorem local_bounds {p : ℕ} (pr : p.Prime) (e : ℕ) :
    σ 1 (p^e)≤(p+1)^e ∧ W (p^e)≤(p+1)^(e+1) ∧ W (p^e)≤(2*p+1)^e := by
  induction e with
  | zero=>simp [w_mult.map_one]
  | succ e ih=>
    obtain ⟨s,w⟩:=updates pr e
    have pp : 0 < (p+1)^e:=pow_pos (Nat.succ_pos _) _
    have sBound : σ 1 (p^(e+1))≤(p+1)^(e+1) := by
      rw [s,pow_succ];nlinarith only [Nat.mul_le_mul_left p ih.1,pp]
    have s2 : σ 1 (p^(e+1))≤(p+1)*(2*p+1)^e := by
      calc
        _ ≤ (p+1)^(e+1) := sBound
        _ = (p+1)*(p+1)^e := pow_succ' _ _
        _ ≤ _ := Nat.mul_le_mul_left _ (Nat.pow_le_pow_left (by omega) _)
    refine ⟨sBound,?_,?_⟩
    · rw [w,pow_succ (p+1) (e+1)]
      nlinarith only [Nat.mul_le_mul_left p ih.2.1,sBound]
    · rw [w,pow_succ (2*p+1) e]
      nlinarith only [Nat.mul_le_mul_left p ih.2.2,s2]

private theorem weighted_pos {h : ℕ} (pos : 0 < h) : 0<W h := by
  rw [w_apply]
  exact sum_pos' (fun _ _=>Nat.zero_le _) ⟨1,Nat.one_mem_divisors.mpr pos.ne',by simp⟩

/-- Strictness at the last coordinate saves one unit in the exponent. -/
private theorem compare {h P c E : ℕ} (pos : 0 < h) (pr : P.Prime) (odd : P≠2)
    (cop : h.Coprime P) (eqn : OeisA245212.a (h*P^c)=(σ 1 (h*P^c):ℤ))
    (wa : W h≤P^(E+1)) (sb : σ 1 h≤P^E) : c≤E := by
  have pb:=OMA.PrimePowerDiv245212.cofactor_bound pos pr odd cop c eqn
  have sp:=sigma_pos 1 h pos.ne'
  have wp:=weighted_pos pos
  have pp:=pr.one_lt
  have prod : (P-1)*σ 1 h<P^(E+1) := by
    rw [pow_succ']
    exact (Nat.mul_le_mul_left _ sb).trans_lt (Nat.mul_lt_mul_of_pos_right (by omega) (pow_pos pr.pos _))
  have lt : ((W h:ℤ)-((P:ℤ)-1)*(σ 1 h:ℤ)).natAbs<P^(E+1) := by
    have v : 0<(P-1)*σ 1 h:=Nat.mul_pos (by omega) sp
    have z : ((P-1)*σ 1 h:ℕ)=((P:ℤ)-1)*(σ 1 h:ℤ) := by push_cast [Nat.cast_sub pr.pos];rfl
    apply Int.ofNat_lt.mp
    rw [Int.natCast_natAbs,abs_lt]
    constructor <;> omega
  by_contra! no
  exact (pb.trans_lt lt).not_ge (Nat.pow_le_pow_right pr.pos no)

def extra (p q P : ℕ) := if P<2*p+1 ∧ P<2*q+1 then 1 else 0

theorem triple_of_power {k j p q P a b c : ℕ} (pp : p.Prime) (qp : q.Prime) (rp : P.Prime)
    (op : 3≤p) (pq : p<q) (qr : q<P) (base : 5^k≤P^j)
    (eqn : OeisA245212.a (2^k*p^a*q^b*P^c)=(σ 1 (2^k*p^a*q^b*P^c):ℤ)) :
    c≤j+a+b+extra p q P := by
  have twoP : (2^k).Coprime p:=((coprime_primes prime_two pp).mpr (by omega)).pow_left k
  have twoQ : (2^k).Coprime q:=((coprime_primes prime_two qp).mpr (by omega)).pow_left k
  have twoR : (2^k).Coprime P:=((coprime_primes prime_two rp).mpr (by omega)).pow_left k
  have smallQ:= ((coprime_primes pp qp).mpr pq.ne).pow_left a
  have smallR:= ((coprime_primes pp rp).mpr (pq.trans qr).ne).pow_left a
  have midR:= ((coprime_primes qp rp).mpr qr.ne).pow_left b
  have cube:=local_bounds prime_two k
  have sw : W (2^k)≤P^j:=cube.2.2.trans base
  have ss : σ 1 (2^k)≤P^j:=cube.1.trans ((Nat.pow_le_pow_left (by decide : 2+1≤5) _).trans base)
  have small {z : ℕ} (pz : z.Prime) (lt : z<P) (n : ℕ) :
      σ 1 (z^n)≤P^n ∧ W (z^n)≤P^(n+1) ∧ (2*z+1≤P → W (z^n)≤P^n) := by
    obtain ⟨s,w,u⟩:=local_bounds pz n
    exact ⟨s.trans (Nat.pow_le_pow_left lt _),w.trans (Nat.pow_le_pow_left lt _),
      fun le=>u.trans (Nat.pow_le_pow_left le _)⟩
  obtain ⟨ps,pw,pt⟩:=small pp (pq.trans qr) a
  obtain ⟨qs,qw,qt⟩:=small qp qr b
  apply compare (by have :=pp.pos;have :=qp.pos;positivity) rp (by omega)
    ((twoR.mul_left smallR).mul_left midR) eqn
  · rw [w_mult.map_mul_of_coprime ((twoQ.mul_left smallQ).pow_right b),
      w_mult.map_mul_of_coprime (twoP.pow_right a)]
    by_cases near : P<2*p+1 ∧ P<2*q+1
    · simp only [extra,if_pos near]
      simpa only [pow_add,mul_assoc,mul_comm,mul_left_comm] using Nat.mul_le_mul (Nat.mul_le_mul sw pw) qw
    · simp only [extra,if_neg near,add_zero]
      rcases not_and_or.mp near with far|far
      · simpa only [pow_add,mul_assoc,mul_comm,mul_left_comm] using Nat.mul_le_mul (Nat.mul_le_mul sw (pt (by omega))) qw
      · simpa only [pow_add,mul_assoc,mul_comm,mul_left_comm] using Nat.mul_le_mul (Nat.mul_le_mul sw pw) (qt (by omega))
  · rw [isMultiplicative_sigma.map_mul_of_coprime ((twoQ.mul_left smallQ).pow_right b),
      isMultiplicative_sigma.map_mul_of_coprime (twoP.pow_right a)]
    apply (Nat.mul_le_mul (Nat.mul_le_mul ss ps) qs).trans
    rw [←pow_add,←pow_add]
    exact Nat.pow_le_pow_right rp.pos (Nat.le_add_right _ _)

theorem triple {k j t p q P a b c : ℕ} (pp : p.Prime) (qp : q.Prime) (rp : P.Prime)
    (op : 3≤p) (pq : p<q) (qr : q<P) (scale : 5^t≤P) (dyad : k≤t*j)
    (eqn : OeisA245212.a (2^k*p^a*q^b*P^c)=(σ 1 (2^k*p^a*q^b*P^c):ℤ)) :
    c≤j+a+b+extra p q P := by
  apply triple_of_power pp qp rp op pq qr _ eqn
  exact (Nat.pow_le_pow_right (by decide : 0<5) dyad).trans (by
    rw [pow_mul];exact Nat.pow_le_pow_left scale _)

#print axioms triple_of_power
#print axioms triple
end OMA.LargestPrimeExponent245212
