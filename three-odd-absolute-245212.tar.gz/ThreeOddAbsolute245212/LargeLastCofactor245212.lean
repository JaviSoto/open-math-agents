import LargestPrimeExponent245212
import ComplementaryLocal245212

/-! Elementary bounds on the two smaller prime-power factors. -/
namespace OMA.LargeLastCofactor245212
open Nat Finset ArithmeticFunction OMA.Smooth245212
open scoped ArithmeticFunction.sigma
open private OMA.LargestPrimeExponent245212.updates from LargestPrimeExponent245212

private theorem ratio {p a : ℕ} (pr : p.Prime) (ap : 0<a) : 3*σ 1 (p^a) ≤ 2*W (p^a) := by
  cases a with
  | zero=>omega
  | succ i=>
    induction i with
    | zero=>
      rw [sigma_one_apply_prime_pow pr,w_pow pr]
      simp [sum_range_succ]
      have:=pr.two_le;omega
    | succ i ih=>
      obtain ⟨s,w⟩:=OMA.LargestPrimeExponent245212.updates pr (i+1)
      rw [w,s]
      have b:=Nat.mul_le_mul_left p (ih (by omega))
      have z:=sigma_pos 1 (p^(i+1)) (pow_ne_zero _ pr.ne_zero)
      have lo:=Nat.mul_le_mul pr.two_le z
      nlinarith only [b,lo]

theorem pair {p q r a b : ℕ} (pp : p.Prime) (qp : q.Prime) (_p3 : 3≤p) (pq : p<q) (qr : q<r)
    (ap : 0<a) (bp : 0<b) :
    let h := p^a*q^b
    0<W h ∧ h*σ 0 h≤W h ∧ 2*σ 1 h≤W h ∧ W h≤r^(a+b+2) ∧
      σ 0 h=(a+1)*(b+1) := by
  let co:=(((Nat.coprime_primes pp qp).mpr pq.ne).pow_left a).pow_right b
  dsimp only
  rw [w_mult.map_mul_of_coprime co,isMultiplicative_sigma.map_mul_of_coprime co,
    isMultiplicative_sigma.map_mul_of_coprime co,sigma_zero_apply_prime_pow pp,sigma_zero_apply_prime_pow qp]
  have weight {z : ℕ} (prime : z.Prime) (e : ℕ) : (e+1)*z^e ≤ W (z^e) := by
    rw [w_pow prime,sum_range_succ];nlinarith only [Nat.zero_le (∑ i∈range e,z^i*(i+1))]
  have wp:=weight pp a
  have wq:=weight qp b
  have lp:=ratio pp ap
  have lq:=ratio qp bp
  have upperp:=(OMA.LargestPrimeExponent245212.local_bounds pp a).2.1.trans
    (Nat.pow_le_pow_left (by omega : p+1≤r) _)
  have upperq:=(OMA.LargestPrimeExponent245212.local_bounds qp b).2.1.trans
    (Nat.pow_le_pow_left (by omega : q+1≤r) _)
  refine ⟨Nat.mul_pos (lt_of_lt_of_le (Nat.mul_pos (Nat.succ_pos _) (pow_pos pp.pos a)) wp)
    (lt_of_lt_of_le (Nat.mul_pos (Nat.succ_pos _) (pow_pos qp.pos b)) wq),?_,?_,?_,rfl⟩
  · nlinarith only [Nat.mul_le_mul wp wq]
  · nlinarith only [Nat.mul_le_mul lp lq,Nat.zero_le (σ 1 (p^a)*σ 1 (q^b))]
  · convert Nat.mul_le_mul upperp upperq using 1
    rw [←pow_add];congr 1;omega

end OMA.LargeLastCofactor245212
