import MiddleBridge245212
import MiddlePoleOriginal245212
import MiddlePoleFinite245212

/-! Whole-integer absolute bound in the three-odd-prime case from the
sorted-range cover, exact mixed equation, and integral cofactor gap. -/
namespace OMA.MiddleClose245212
open Nat ArithmeticFunction
open OMA.Smooth245212 (W)
open scoped ArithmeticFunction.sigma

private theorem no_escape {D k p q a b d : ℕ} (pp : p.Prime) (op : Odd p) (qg : 2≤q)
    (high : OMA.MiddlePoleFinite245212.cutoff D < b+1)
    (mixed : OMA.MiddleBridge245212.output D k p q a b d) : False := by
  obtain ⟨small,cofactor,formula,side⟩:=mixed
  have gt : (d+1)*W (2^k*p^a)<(q-1)*σ 1 (2^k*p^a):=by
    simpa only [mul_comm] using side
  have poly := OMA.MiddlePoleOriginal245212.original pp op qg (Nat.succ_pos b) (Nat.succ_pos d) gt formula
  exact high.not_ge (OMA.MiddlePoleFinite245212.bounded pp.two_le
    (small.trans (Nat.le_add_left _ _)) poly cofactor)

theorem finish
    (ranges : ∀ N : ℕ, ∃ K : ℕ, ∀ {k p q r a b d : ℕ}, p.Prime → q.Prime → r.Prime →
      3≤p → p<q → q<r → 0<a → 0<b → 0<d →
      OeisA245212.a (2^k*p^a*q^b*r^d)=(σ 1 (2^k*p^a*q^b*r^d):ℤ) →
      2^k*p^a*q^b*r^d≤K ∨ (256≤k ∧ 33≤p ∧ N≤b+1 ∧ 16*(a+1)<b+1 ∧ 16*(d+1)<b+1)) :
    ∃ K : ℕ, ∀ {k p q r a b d : ℕ}, p.Prime → q.Prime → r.Prime →
      3≤p → p<q → q<r → 0<a → 0<b → 0<d →
      OeisA245212.a (2^k*p^a*q^b*r^d)=(σ 1 (2^k*p^a*q^b*r^d):ℤ) →
      2^k*p^a*q^b*r^d≤K := by
  let x:=OMA.MiddleBridge245212.threshold
  let y:=OMA.MiddlePoleFinite245212.cutoff OMA.MiddleBridge245212.exponent
  obtain ⟨K,cover⟩:=ranges (x+y+1)
  refine ⟨K,?_⟩
  intro k p q r a b d pp qp rp p3 pq qr ap bp dp eqn
  obtain small|⟨k0,p33,L,left,right⟩:=cover pp qp rp p3 pq qr ap bp dp eqn
  · exact small
  · have xL : x≤b+1:=((Nat.le_add_right _ _).trans (Nat.le_succ _)).trans L
    have yL : y<b+1:=(Nat.lt_succ_of_le (Nat.le_add_left _ _)).trans_le L
    have mixed:=OMA.MiddleBridge245212.original pp qp rp p33 pq qr ap bp dp k0 xL left right eqn
    exact False.elim (no_escape pp (pp.odd_of_ne_two (by omega)) qp.two_le yL mixed)

end OMA.MiddleClose245212
