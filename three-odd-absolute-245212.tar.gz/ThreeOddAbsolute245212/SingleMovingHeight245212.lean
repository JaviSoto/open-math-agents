import SingleMovingOriginal245212

/-! Explicit polynomial control on the dyadic prime power in terms of
the largest odd exponent length alone. -/
namespace OMA.SingleMovingHeight245212
open Nat Finset ArithmeticFunction
open OMA.ThreeMovingOriginal245212 (G)
open OMA.TwoTallScalar245212 (base)
open OMA.SingleMovingStep245212 (degree)
open OMA.SingleMovingGap245212 (Family)
open OMA.Smooth245212 (total)
open scoped ArithmeticFunction.sigma

def constant (D : ℕ) := 2^(16*(D+2)^2+8)+(16*128^D)^2

private theorem eliminate {k L D : ℕ}
    (h : 2^k ≤ 8*(k+1)*(base k L)^D) :
    2^k ≤ constant D*(L+1)^(2*D) := by
  have pos : 1≤(L+1)^(2*D):=Nat.one_le_pow _ _ (by omega)
  by_cases large : 16*(D+2)^2≤k+2
  · have grow:=OMA.ComplementarySize245212.absorb (b:=k+2) (d:=D+1) (by simpa [Nat.add_assoc] using large)
    let C : ℕ := 8*128^D
    have e : 2^k≤C*(k+2)^(D+1)*(L+1)^D := calc
      _ ≤ _ := h
      _ ≤ 8*(k+2)*(base k L)^D := Nat.mul_le_mul_right _ (by omega)
      _ = _ := by simp only [base,mul_pow,C,pow_succ];ring
    have z:=Nat.pow_le_pow_left e 2
    have powers : ((k+2)^(D+1))^2 ≤ 2^k*4 := by
      rw [←pow_mul,mul_comm (D+1) 2,←show (2:ℕ)^(k+2)=2^k*4 by rw [pow_add];rfl]
      exact grow
    have w : 2^k*2^k ≤ 2^k*((16*128^D)^2*(L+1)^(2*D)) := calc
      _ = (2^k)^2 := (sq _).symm
      _ ≤ _ := z
      _ = C^2*((k+2)^(D+1))^2*((L+1)^D)^2 := by ring
      _ ≤ C^2*(2^k*4)*((L+1)^D)^2 := Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ powers)
      _ = _ := by rw [←pow_mul,mul_comm D 2];dsimp [C];ring
    exact (Nat.le_of_mul_le_mul_left w (Nat.two_pow_pos k)).trans
      (Nat.mul_le_mul_right _ (Nat.le_add_left _ _))
  · have top : k≤16*(D+2)^2+8:=by omega
    have bounded := Nat.pow_le_pow_right (by decide : 1≤2) top
    exact bounded.trans ((Nat.le_add_right _ _).trans (Nat.le_mul_of_pos_right _ pos))

private theorem all_k {k L D : ℕ}
    (coarse : 8≤k → G k < 8*(k+1)*(base k L)^D) :
    2^k ≤constant D*(L+1)^(2*D) := by
  by_cases hk : 8≤k
  · have h := coarse hk
    have ge : 2^k≤G k:=by
      have := Nat.two_pow_pos k
      dsimp [G];rw [pow_succ];omega
    exact eliminate (ge.trans h.le)
  · have : 2^k≤(2:ℕ)^8:=Nat.pow_le_pow_right (by decide) (by omega)
    have high : (2:ℕ)^8≤2^(16*(D+2)^2+8):=Nat.pow_le_pow_right (by decide) (Nat.le_add_left _ _)
    exact this.trans (high.trans ((Nat.le_add_right _ _).trans (Nat.le_mul_of_pos_right _
      (pow_pos (by omega) _))))

theorem original (k L : ℕ) (p e : Fin 3→ℕ) (prime : ∀ i,(p i).Prime)
    (odd : ∀ i,Odd (p i)) (distinct : p.Injective) (positive : ∀i,0<e i)
    (longest : ∃ i,e i+1=L) (cap : ∀i,e i+1≤L)
    (eqn : OeisA245212.a (2^k*total p e)=(σ 1 (2^k*total p e):ℤ)) :
    2^k≤constant degree*(L+1)^(2*degree) := by
  apply all_k
  intro hk
  let c : Family := ⟨p,e,k,L,prime,positive,hk,longest,cap,distinct⟩
  exact OMA.SingleMovingOriginal245212.coarse c odd eqn

end OMA.SingleMovingHeight245212
