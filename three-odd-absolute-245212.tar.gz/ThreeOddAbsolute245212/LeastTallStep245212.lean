import LeastTallStrict245212

/-! Six-scale separation when only a specified long coordinate must move. -/
namespace OMA.LeastTallStep245212
open Nat Finset OMA.SingleMovingGap245212 OMA.TwoTallLocal245212 OMA.ThreeMovingLocal245212
open OMA.TwoTallScalar245212 (cut cut_mono cut_succ)
open OMA.SingleMovingStep245212 (empty_six degree)
open private OMA.SingleMovingStep245212.integer_gap OMA.SingleMovingStep245212.difference from SingleMovingStep245212
theorem contradiction (c : Family) (f g x : ℕ) (big : 128≤x) (cf : f+g≤x) (cl : c.L≤x)
    (separated : ∀ b, b 0≠none → (f+g)*dust c b ≠ f*NX c b+g*NY c b)
    (longPower : x^degree<c.p 0^c.e 0)
    (close : |score f g (exactX c) (exactY c)-(f+g:ℕ)| ≤ 1/((x^degree:ℕ):ℚ)) : False := by
  let point : Fin 6 → ℕ := ![c.p 0,c.p 1,c.p 2,c.p 0^c.e 0,c.p 1^c.e 1,c.p 2^c.e 2]
  obtain ⟨j,band⟩:=empty_six x (by omega) point
  have bp (i:Fin 3) : c.p i≤cut x j.val ∨ cut x (j.val+1)<c.p i := by
    fin_cases i <;> first | exact band 0 | exact band 1 | exact band 2
  have bd (i:Fin 3) : c.p i^c.e i≤cut x j.val ∨ cut x (j.val+1)<c.p i^c.e i := by
    fin_cases i <;> first | exact band 3 | exact band 4 | exact band 5
  let Q:=cut x j.val
  let N:=cut x (j.val+1)
  let b (i:Fin 3) : Option Bool := if c.p i^c.e i≤Q then none else some (decide (c.p i≤Q))
  have next : N=Q^16 := cut_succ x _
  have xQ : x≤Q := by
    have old:=cut_mono (show 1≤x by omega) (Nat.zero_le j.val)
    simpa [cut,Q] using old
  have np : 0<N := by rw [next];exact pow_pos (by omega) _
  have nb : N≤x^degree:=cut_mono (by omega) (show j.val+1≤7 by omega)
  have space (i) (t:Bool) (mode:b i=some t) : N ≤ (if t then c.p i^c.e i else c.p i) := by
    dsimp [b] at mode
    split at mode
    next=>contradiction
    next off=>
      obtain rfl:=Option.some.inj mode
      by_cases lo : c.p i≤Q
      · simp [lo]
        exact ((bd i).resolve_left off).le
      · simpa [lo] using ((bp i).resolve_left lo).le
  have ds : dust c b≤Q^9 := by
    have per i : Dn (c.p i) (c.e i) (b i)≤Q^3 := by
      have el := (c.cap i).trans (cl.trans xQ)
      by_cases exactMode : c.p i^c.e i≤Q
      · rw [show b i=none from if_pos exactMode]
        change (c.e i+1)*(c.p i^c.e i)≤Q^3
        exact
          (Nat.mul_le_mul el exactMode).trans (show Q*Q≤Q^3 by rw [←sq];exact Nat.pow_le_pow_right (by omega) (by decide))
      · by_cases keep:c.p i≤Q
        · simpa [b,exactMode,keep,Dn,den] using
            (Nat.mul_le_mul el (Nat.pow_le_pow_left (show c.p i-1≤Q by omega) 2)).trans_eq (by ring : Q*Q^2=Q^3)
        · simpa [b,exactMode,keep,Dn,den] using el.trans (Nat.le_self_pow (by decide : 3≠0) Q)
    dsimp [dust]
    exact (prod_le_prod' (fun i _=>per i)).trans_eq (by simp;ring)
  have maxcut : Q≤x^degree:=cut_mono (by omega) (show j.val≤7 by omega)
  have off : ¬c.p 0^c.e 0≤Q:=(maxcut.trans_lt longPower).not_ge
  have nz:=separated b (by simp [b,off])
  have iga:=OMA.SingleMovingStep245212.integer_gap c b f g nz
  let orig:=score f g (exactX c) (exactY c)
  let approx:=score f g (x' c b) (y' c b)
  let W:ℚ:=(f+g:ℕ)
  have lite : |orig-W|≤1/(N:ℚ) := close.trans (one_div_le_one_div_of_le (by positivity) (by exact_mod_cast nb))
  have diff:=OMA.SingleMovingStep245212.difference c b f g N np space
  change |approx-orig|≤_ at diff
  change (1:ℚ)≤|approx-W| * dust c b at iga
  have err : |approx-W| * (N:ℚ)≤48*((f:ℚ)+g)+1 := by
    have t:=abs_sub_le approx orig W
    have wn : (0:ℚ)<N:=by exact_mod_cast np
    nlinarith only [mul_le_mul_of_nonneg_right t wn.le,(le_div_iff₀ wn).mp diff,(le_div_iff₀ wn).mp lite]
  have sep : N≤(48*(f+g)+1)*dust c b := by
    have z : (N:ℚ)≤(48*((f:ℚ)+g)+1)*dust c b := by
      nlinarith only [mul_le_mul_of_nonneg_right iga (Nat.cast_nonneg N : (0:ℚ)≤N),
        mul_le_mul_of_nonneg_right err (Nat.cast_nonneg (dust c b) : (0:ℚ)≤_)]
    exact_mod_cast z
  have qr : 128≤Q:=big.trans xQ
  have cfq : f+g≤Q:=cf.trans xQ
  have cf' : 48*(f+g)+1<Q^2 := by
    nlinarith only [cfq,Nat.mul_le_mul_left Q qr,qr]
  have bad : N<Q^11 := sep.trans_lt ((Nat.mul_lt_mul_of_lt_of_le cf' ds (pow_pos (by omega) 9)).trans_eq (by ring))
  have natural : Q^11≤N:=next ▸ Nat.pow_le_pow_right (by omega) (by decide)
  omega


end OMA.LeastTallStep245212
