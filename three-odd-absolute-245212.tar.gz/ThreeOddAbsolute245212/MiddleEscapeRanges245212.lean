import LeastTallOriginal245212
import TwoTallConsequences245212

/-! Outside a computably bounded set, only a long middle-prime exponent
can occur, and each of the other two lengths is less than a sixteenth of it. -/
namespace OMA.MiddleEscapeRanges245212
open Nat Finset ArithmeticFunction OMA.Smooth245212 OMA.TwoTallFinite245212 OMA.TwoTallConsequences245212
open scoped ArithmeticFunction.sigma
open private OMA.TwoTallConsequences245212.from_order from TwoTallConsequences245212

def cap (N : ℕ) := (∑ j∈range 256, OMA.RankThreeEffective245212.bound j) +
  OMA.LeastTallOriginal245212.bound + valueCap 20 + valueCap N + valueCap 16

theorem at_cap (N : ℕ) {k p q r a b d : ℕ} (pp : p.Prime) (qp : q.Prime) (rp : r.Prime)
    (p3 : 3≤p) (pq : p<q) (qr : q<r) (ap : 0<a) (bp : 0<b) (dp : 0<d)
    (eqn : OeisA245212.a (2^k*p^a*q^b*r^d)=(σ 1 (2^k*p^a*q^b*r^d):ℤ)) :
    2^k*p^a*q^b*r^d≤cap N ∨
    (256≤k ∧ 33≤p ∧ N≤b+1 ∧ 16*(a+1)<b+1 ∧ 16*(d+1)<b+1) := by
  classical
  have op:=pp.odd_of_ne_two (by omega)
  have oq:=qp.odd_of_ne_two (by omega)
  have hr:=rp.odd_of_ne_two (by omega)
  let P : Fin 3→ℕ:=![p,q,r]
  let E : Fin 3→ℕ:=![a,b,d]
  have hp (i) : (P i).Prime:=by fin_cases i <;> simp [P,pp,qp,rp]
  have odd (i) : Odd (P i):=by fin_cases i <;> simp [P,op,oq,hr]
  have inj : P.Injective:=by intro i j h;fin_cases i <;> fin_cases j <;> simp_all [P] <;> omega
  have pos (i) : 0<E i:=by fin_cases i <;> simp [E,ap,bp,dp]
  have repr : 2^k*total P E=2^k*p^a*q^b*r^d:=by simp [total,Fin.prod_univ_three,P,E,mul_assoc]
  have ev : OeisA245212.a (2^k*total P E)=(σ 1 (2^k*total P E):ℤ):=by rwa [repr]
  by_cases biga : max b d≤a
  · have bound:=OMA.LeastTallOriginal245212.original k P E hp odd inj pos
      (by intro i;fin_cases i <;> simp [P] <;> omega)
      (by intro i;fin_cases i <;> simp [E] <;> omega) ev
    rw [repr] at bound
    left; unfold cap; omega
  by_cases bigd : max a b≤d
  · have bound:=OMA.TwoTallConsequences245212.largest_at_largest pp qp rp p3 pq qr ap bp dp bigd eqn
    left; unfold cap; omega
  have ab : a≤b:=by omega
  have db : d≤b:=by omega
  by_cases short : b+1<N
  · have bound:=OMA.TwoTallConsequences245212.from_order (C:=N) pp qp rp op oq hr pq.ne (pq.trans qr).ne qr.ne ap bp dp
      (m:=1) (L:=b+1) (by omega) (by omega) (by omega) (by simpa using short.le) eqn
    left; unfold cap; omega
  by_cases tall : b+1≤16*(a+1)
  · have bound:=OMA.TwoTallConsequences245212.from_order (C:=16) pp qp rp op oq hr pq.ne (pq.trans qr).ne qr.ne ap bp dp
      (m:=a+1) (L:=b+1) (by omega) (by omega) (by omega) tall eqn
    left; unfold cap; omega
  by_cases tail : b+1≤16*(d+1)
  · have aux:=OMA.TwoTallConsequences245212.from_order (C:=16) (k:=k) (a:=b) (b:=d) (d:=a) qp rp pp oq hr op qr.ne pq.ne.symm
      (pq.trans qr).ne.symm bp dp ap (m:=d+1) (L:=b+1) (by omega) (by omega) (by omega) tail
      (by simpa only [mul_comm,mul_assoc,mul_left_comm] using eqn)
    have bound : 2^k*p^a*q^b*r^d≤valueCap 16:=by simpa only [mul_comm,mul_assoc,mul_left_comm] using aux
    left; unfold cap; omega
  have om : Odd (total P E) := Nat.coprime_two_left.mp
    (Coprime.prod_right (fun i _ => (Nat.coprime_two_left.mpr (odd i)).pow_right _))
  have dv i : P i∣total P E := (dvd_pow_self _ (pos i).ne').trans
    (dvd_prod_of_mem (fun j => P j^E j) (mem_univ i))
  have mem i : P i∈(total P E).primeFactors:=mem_primeFactors.mpr ⟨hp i,dv i,om.pos.ne'⟩
  by_cases low : k<256
  · have image : (total P E).primeFactors=univ.image P := by
      ext z
      constructor
      · intro hz
        have pr:=prime_of_mem_primeFactors hz
        obtain ⟨i,_,di⟩:=(pr.prime.dvd_finsetProd_iff _).mp (dvd_of_mem_primeFactors hz : z∣∏i,P i^E i)
        exact mem_image.mpr ⟨i,mem_univ _,((prime_dvd_prime_iff_eq pr (hp i)).mp (pr.dvd_of_dvd_pow di)).symm⟩
      · rintro hz
        obtain ⟨i,_,rfl⟩:=mem_image.mp hz
        exact mem i
    have rk : (total P E).primeFactors.card=3:=by rw [image,card_image_of_injective _ inj];simp
    have bound:=OMA.RankThreeEffective245212.original om rk ev
    rw [repr] at bound
    have sum:=single_le_sum (f:=OMA.RankThreeEffective245212.bound) (fun _ _=>Nat.zero_le _) (mem_range.mpr low)
    left; unfold cap; omega
  have lim:=OMA.DyadicLeast245212.exponent_lt_twice_prime om (mem 0) ev
  change k<2*p at lim
  right; omega

theorem ranges (N : ℕ) : ∃ K : ℕ, ∀ {k p q r a b d : ℕ}, p.Prime → q.Prime → r.Prime →
    3≤p → p<q → q<r → 0<a → 0<b → 0<d →
    OeisA245212.a (2^k*p^a*q^b*r^d)=(σ 1 (2^k*p^a*q^b*r^d):ℤ) →
    2^k*p^a*q^b*r^d≤K ∨ (256≤k ∧ 33≤p ∧ N≤b+1 ∧ 16*(a+1)<b+1 ∧ 16*(d+1)<b+1) :=
  ⟨cap N, fun {_ _ _ _ _ _ _} => at_cap N⟩
end OMA.MiddleEscapeRanges245212
