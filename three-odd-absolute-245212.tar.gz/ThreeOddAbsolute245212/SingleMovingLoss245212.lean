import SingleMovingGap245212
import ThreeMovingOriginal245212

/-! A negative contribution when a retained coordinate returns to its true
moment is dominated by the deficit of the dyadic linearization. -/
namespace OMA.SingleMovingLoss245212
open Nat Finset OMA.Smooth245212 OMA.TwoTallLocal245212 OMA.SingleMovingGap245212
open OMA.ThreeMovingLocal245212 (xx yy)
open private OMA.ThreeMovingLocal245212.quotients from ThreeMovingLocal245212
open private OMA.DyadicLeast245212.x_two_terms from DyadicLeast245212

theorem single_lb {p e : ℕ} (hp : p.Prime) (he : 0<e) :
    1≤(2*(p:ℚ))*(X p (some e)-1) := by
  have r:=OMA.DyadicLeast245212.x_two_terms hp he
  change 1+(e:ℚ)/((e+1)*p)≤_ at r
  have z : 0<((e:ℚ)+1)*p := by have:=hp.pos;positivity
  have z' := (div_le_iff₀ z).mp (by linarith only [r] : (e:ℚ)/((e+1)*p)≤X p (some e)-1)
  have q : (1:ℚ)≤e:=by exact_mod_cast he
  by_contra! bad
  have mul:=mul_lt_mul_of_pos_right bad (by positivity : 0<(e:ℚ)+1)
  nlinarith only [z',q,mul]

theorem scalar {k p e : ℕ} (hk : 8≤k) (kp : k+1<p) (len : p≤e+1) :
    8*p*(2^(k+1)-1)≤p^e := by
  have k4 : 4≤k:=by omega
  have c : 16≤2^k := (by decide : 16≤2^4).trans (Nat.pow_le_pow_right (by decide) k4)
  have ep : k+1≤e:=by omega
  calc
    _ ≤ 8*p*(2^(k+1)) := Nat.mul_le_mul_left _ (Nat.sub_le _ _)
    _ = p*(2^k*16) := by rw [pow_succ];ring
    _ ≤ p*(2^k*2^k) := Nat.mul_le_mul_left _ (Nat.mul_le_mul_left _ c)
    _ = p*(2*2)^k := by rw [mul_pow]
    _ ≤ p*p^k := Nat.mul_le_mul_left _ (Nat.pow_le_pow_left (by omega) _)
    _ = p^(k+1) := (pow_succ' ..).symm
    _ ≤ p^e := Nat.pow_le_pow_right (by omega) ep

/-- Returns a coordinate from any of the three proxy choices. The comparison
tests u*y*y' against k, keeping the product of the *other* ordinary factors. -/
theorem restore {p e k : ℕ} (hp : p.Prime) (ep : 0<e) (kp : 0<k) (mode : Option Bool)
    (x x' y y' allowance : ℚ) (xp : 1≤x) (xp' : 1≤x') (yp : 0≤y) (yp' : 0≤y')
    (yl : y*y'≤1) (dl : 0≤allowance)
    (bad : mode=some true → (k:ℚ)<((p:ℚ)-1)*(y*y') → 1/(p:ℚ)^e≤allowance) :
    (k:ℚ)*xx' p e mode*x*x'+yy' p e mode*y*y' ≤
    (k:ℚ)*X p (some e)*x*x'+Y p (some e)*y*y'+allowance := by
  cases mode with
  | none=> dsimp [xx',yy'];linarith
  | some t=>
    cases t with
    | false=>
      have v:=OMA.TwoTallLocal245212.move hp ep (by decide : 0 < (1:ℕ)) kp (by decide : 0<(1:ℕ))
        (le_refl (k*1)) false (by simp) x x' y y' xp xp' yp yp' (by norm_num;linarith)
      dsimp [xx',yy'];push_cast at v;linarith only [v,dl]
    | true=>
      let u:ℚ:=(p:ℚ)-1
      let H:ℚ:=(e:ℚ)+1
      let d:ℚ:=1/(H*u^2*(p:ℚ)^e)
      have u1 : 1≤u:=by dsimp [u];have z:=(by exact_mod_cast hp.two_le : (2:ℚ)≤p);linarith
      have h1 : 1≤H:=by dsimp [H];have z:=Nat.cast_nonneg (α:=ℚ) e;linarith
      have po : (0:ℚ)<(p:ℚ)^e:=pow_pos (by exact_mod_cast hp.pos) _
      have dpos : 0<d:=by dsimp [d];positivity
      have vk : 0≤(k:ℚ)*(x*x'):=mul_nonneg (by positivity) (mul_nonneg (by linarith) (by linarith))
      have xy : 1≤x*x':=one_le_mul_of_one_le_of_one_le xp xp'
      have m:=OMA.ThreeMovingLocal245212.quotients hp (e:=e)
      change X p (some e)=xx p e true+d ∧ Y p (some e)=yy p e true-u*d at m
      change _*xx p e true*x*x'+yy p e true*y*y'≤_
      rw [m.1,m.2]
      by_cases good : u*(y*y')≤k
      · have more:=(mul_le_mul_of_nonneg_left xy (Nat.cast_nonneg (α:=ℚ) k))
        have dif : 0≤(k:ℚ)*x*x'-u*(y*y'):=by linarith [good,more]
        nlinarith only [mul_nonneg dpos.le dif,dl]
      · have limit:=bad rfl (lt_of_not_ge good)
        have ud : u*d=1/((H*u)*(p:ℚ)^e) := by dsimp [d];field_simp
        have abd : u*d≤1/(p:ℚ)^e := by
          rw [ud]
          exact one_div_le_one_div_of_le po (le_mul_of_one_le_left po.le (one_le_mul_of_one_le_of_one_le h1 u1))
        have loss:=mul_le_mul_of_nonneg_left yl (mul_nonneg (by linarith : 0≤u) dpos.le)
        nlinarith only [loss,abd,limit,mul_nonneg dpos.le vk]

end OMA.SingleMovingLoss245212
