import SinglePrefixEffective245212
import CofactorEffectiveTree245212
import PairHeight245212

/-! An explicit, unconditional numerical bound on any solution with three
distinct odd prime factors, at each fixed dyadic exponent. -/
namespace OMA.RankThreeEffective245212
open Finset Nat ArithmeticFunction OMA.Smooth245212 OMA.CofactorEffectiveOriginal245212
open scoped ArithmeticFunction.sigma
open private OMA.PairHeight245212.combine from PairHeight245212

def stepBound (h r : ℕ) := h*(primeHeight h r+1)^(height h r)
def bound (k : ℕ) :=
  let afterOne:=stepBound (2^k) 3
  let afterTwo:=(range (afterOne+1)).sup (fun h=>stepBound h 2)
  4*afterTwo^7

private theorem step_le {h r p e : ℕ} (pb : p≤primeHeight h r) (eb : e≤height h r) :
    h*p^e ≤ stepBound h r :=
  Nat.mul_le_mul_left _ ((Nat.pow_le_pow_left (pb.trans (Nat.le_succ _)) _).trans
    (Nat.pow_le_pow_right (Nat.succ_pos _) eb))

theorem original {k m : ℕ} (odd : Odd m) (rank : m.primeFactors.card=3)
    (eqn : OeisA245212.a (2^k*m)=(σ 1 (2^k*m):ℤ)) : 2^k*m≤bound k := by
  have larger {u : ℕ} (up : 0 < u) (many : 0<u.primeFactors.card) : 1 < u := by
    by_contra! low
    have one : u=1:=by omega
    simp [one] at many
  obtain ⟨p,mp,pb,pa⟩:=dyadic (larger odd.pos (by omega)) odd eqn
  rw [rank] at pb pa
  let a:=m.factorization p
  let h:=2^k*p^a
  let u:=ordCompl[p] m
  have hp:=prime_of_mem_primeFactors mp
  have ap:=hp.factorization_pos_of_dvd odd.pos.ne' (dvd_of_mem_primeFactors mp)
  have op:=Nat.coprime_two_left.mp ((Nat.coprime_two_left.mpr odd).of_dvd_right (dvd_of_mem_primeFactors mp))
  have ou:=Nat.coprime_two_left.mp ((Nat.coprime_two_left.mpr odd).of_dvd_right (Nat.ordCompl_dvd m p))
  have hc : h.Coprime u :=
    ((Nat.coprime_two_left.mpr ou).pow_left k).mul_left ((Nat.coprime_ordCompl hp odd.pos.ne').pow_left a)
  have ur : u.primeFactors.card=2 := by
    rw [show u.primeFactors=m.primeFactors.erase p from OMA.CofactorEffectiveTree245212.support_rest m p,
      card_erase_of_mem mp,rank]
  have id : h*u=2^k*m := by change 2^k*p^a*u=_; rw [mul_assoc,Nat.ordProj_mul_ordCompl_eq_self]
  have eq1 : OeisA245212.a (h*u)=(σ 1 (h*u):ℤ) := by rwa [id]
  obtain ⟨q,mq,qb,qe⟩:=OMA.SinglePrefixEffective245212.next_atom hp op ap
    (larger ou.pos (by omega : 0<u.primeFactors.card)) hc eq1
  rw [ur] at qb qe
  let b:=u.factorization q
  let v:=ordCompl[q] u
  let g:=h*q^b
  have qq:=prime_of_mem_primeFactors mq
  have ov:=Nat.coprime_two_left.mp ((Nat.coprime_two_left.mpr ou).of_dvd_right (Nat.ordCompl_dvd u q))
  have gc : g.Coprime v :=
    (hc.of_dvd_right (Nat.ordCompl_dvd u q)).mul_left ((Nat.coprime_ordCompl qq ou.pos.ne').pow_left b)
  have gr : v.primeFactors.card=1 := by
    rw [show v.primeFactors=u.primeFactors.erase q from OMA.CofactorEffectiveTree245212.support_rest u q,
      card_erase_of_mem mq,ur]
  have old : g*v=h*u := by change h*q^b*v=_;rw [mul_assoc,Nat.ordProj_mul_ordCompl_eq_self]
  obtain ⟨z,zs⟩:=card_eq_one.mp gr
  have mz : z∈v.primeFactors := by simp [zs]
  have zp:=prime_of_mem_primeFactors mz
  have ez:=zp.factorization_pos_of_dvd ov.pos.ne' (dvd_of_mem_primeFactors mz)
  have nz : z≠2 := by
    intro same
    have dv:=dvd_of_mem_primeFactors mz
    have od:=Nat.odd_iff.mp ov
    rw [same] at dv
    omega
  have rep:=Nat.prod_primeFactors_pow_factorization ov.pos.ne'
  rw [zs,prod_singleton] at rep
  change v=z^(v.factorization z) at rep
  have eq2 : OeisA245212.a (g*z^(v.factorization z))=(σ 1 (g*z^(v.factorization z)):ℤ) := by
    rw [←rep,old];exact eq1
  have gp : 0<g:=Nat.mul_pos (Nat.mul_pos (Nat.two_pow_pos k) (pow_pos hp.pos a)) (pow_pos qq.pos b)
  have hb : h ≤ stepBound (2^k) 3 := step_le pb pa
  let L:=stepBound (2^k) 3
  let M:=(range (L+1)).sup (fun j=>stepBound j 2)
  have gb : g≤M := (step_le qb qe).trans (le_sup (f:=fun j=>stepBound j 2) (mem_range.mpr (Nat.lt_succ_of_le hb)))
  have last:=OMA.PairHeight245212.last_square gp zp nz (gc.of_dvd_right (dvd_of_mem_primeFactors mz)) ez eq2
  have fin:=OMA.PairHeight245212.combine gp gb last
  rwa [←rep,old,id] at fin

#print axioms original
end OMA.RankThreeEffective245212
