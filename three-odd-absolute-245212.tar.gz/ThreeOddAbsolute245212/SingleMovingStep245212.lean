import SingleMovingProxy245212
import TwoTallScalar245212
import CofactorEffectiveAtom245212

/-! A missing interval among six local scales makes the local tail
smaller than a nonzero integer's reciprocal denominator. -/
namespace OMA.SingleMovingStep245212
open Nat Finset OMA.TwoTallLocal245212 OMA.ThreeMovingLocal245212 OMA.SingleMovingGap245212
open OMA.TwoTallScalar245212 (cut cut_mono cut_succ)
open private OMA.CofactorEffectiveAtom245212.product_error from CofactorEffectiveAtom245212

theorem empty_six (x : ℕ) (hx : 1≤x) (p : Fin 6→ℕ) :
    ∃j : Fin 7,∀i, p i ≤ cut x j.val ∨ cut x (j.val+1) < p i := by
  by_contra! no
  choose f above below using no
  have inj:Function.Injective f := by
    intro j k eqn
    rcases lt_trichotomy j k with lt|eq|gt
    · have h := cut_mono hx (show j.val+1≤k.val from lt)
      have impossible:=(below j).trans h
      rw [eqn] at impossible
      exact False.elim ((above k).not_ge impossible)
    · exact eq
    · have h := cut_mono hx (show k.val+1≤j.val from gt)
      have impossible:=(below k).trans h
      rw [←eqn] at impossible
      exact False.elim ((above j).not_ge impossible)
  have:=Fintype.card_le_of_injective _ inj
  norm_num at this

def degree : ℕ := 16^7

private theorem integer_gap (c : Family) (bits : Fin 3→Option Bool) (f g : ℕ)
    (different : (f+g)*dust c bits ≠ f*NX c bits+g*NY c bits) :
    (1:ℚ)≤|score f g (x' c bits) (y' c bits)-(f+g:ℕ)| * dust c bits := by
  let B:=dust c bits
  let T:=f*NX c bits+g*NY c bits
  let L:ℤ:=(T:ℤ)-((f+g)*B:ℕ)
  have nz : L≠0 := fun h => different (by exact_mod_cast (sub_eq_zero.mp h).symm)
  have la : (1:ℤ)≤|L| := by have:=abs_pos.mpr nz;omega
  have raw : (1:ℚ)≤|(T:ℚ)-((f+g)*B:ℕ)| := by dsimp [L] at la;exact_mod_cast la
  have ab:=congrArg (fun w:ℚ=>|w|) (show (score f g (x' c bits) (y' c bits)-(f+g:ℕ))*B =
      (T:ℚ)-((f+g)*B:ℕ) by rw [sub_mul];push_cast;rw [show score f g (x' c bits) (y' c bits)*B=(T:ℚ) from clear ..])
  rw [abs_mul,abs_of_nonneg (Nat.cast_nonneg B : (0:ℚ)≤B)] at ab
  exact ab.trans_ge raw

private theorem difference (c : Family) (b : Fin 3→Option Bool) (f g N : ℕ) (n0 : 0<N)
    (space : ∀ i t, b i=some t → N ≤ (if t then (c.p i)^(c.e i) else c.p i)) :
    |score f g (x' c b) (y' c b)-score f g (exactX c) (exactY c)|≤48*((f:ℚ)+g)/N := by
  have bp i := ranges (c.prime i) (c.positive i) (b i)
  have ex i := ranges (c.prime i) (c.positive i) none
  have er (i) : |exactX c i-x' c b i|≤2/(N:ℚ) ∧ |exactY c i-y' c b i|≤2/(N:ℚ) := by
    cases h:b i with
    | none=>simp [exactX,x',exactY,y',h,xx',yy'];positivity
    | some t=>simpa [exactX,x',exactY,y',h,xx',yy'] using error (c.prime i) (c.positive i) n0 t (space i t h)
  have eps : (0:ℚ)≤2/N := by positivity
  have one i : 2/((c.e i:ℚ)+1)≤2 := div_le_self (by decide) (by have:=Nat.cast_nonneg (α:=ℚ) (c.e i);linarith)
  have x:=OMA.CofactorEffectiveAtom245212.product_error (univ:Finset (Fin 3)) (exactX c) (x' c b) eps
    (fun i _=>⟨zero_le_one.trans (ex i).1,(ex i).2.1,zero_le_one.trans (bp i).1,(bp i).2.1,(er i).1⟩)
  have y:=OMA.CofactorEffectiveAtom245212.product_error (univ:Finset (Fin 3)) (exactY c) (y' c b) eps
    (fun i _=>⟨(ex i).2.2.1,(ex i).2.2.2.trans (one i),(bp i).2.2.1,(bp i).2.2.2.trans (one i),(er i).2⟩)
  norm_num at x y
  dsimp [score]
  rw [abs_sub_comm]
  calc
    _ = |(f:ℚ)*((∏i,exactX c i)-∏i,x' c b i)+(g:ℚ)*((∏i,exactY c i)-∏i,y' c b i)| := by congr 1;ring
    _ ≤ _ := (abs_add_le ..).trans (by
      rw [abs_mul,abs_of_nonneg (Nat.cast_nonneg f : (0:ℚ)≤f),abs_mul,
        abs_of_nonneg (Nat.cast_nonneg g : (0:ℚ)≤g)]
      simp only [div_eq_mul_inv] at x y ⊢
      nlinarith only [mul_le_mul_of_nonneg_left x (Nat.cast_nonneg f : (0:ℚ)≤f),
        mul_le_mul_of_nonneg_left y (Nat.cast_nonneg g : (0:ℚ)≤g)])

theorem contradiction (c : Family) (f g x : ℕ) (big : 128≤x) (cf : f+g≤x) (cl : c.L≤x)
    (separated : ∀ b, (f+g)*dust c b ≠ f*NX c b+g*NY c b)
    (close : |score f g (exactX c) (exactY c)-(f+g:ℕ)| ≤ 1/((x^degree:ℕ):ℚ)) : False := by
  let point : Fin 6 → ℕ := ![c.p 0,c.p 1,c.p 2,c.p 0^c.e 0,c.p 1^c.e 1,c.p 2^c.e 2]
  obtain ⟨j,band⟩:=empty_six x (by omega) point
  have bp (i:Fin 3) : c.p i≤cut x j.val ∨ cut x (j.val+1)<c.p i := by
    fin_cases i <;> first | exact band 0 | exact band 1 | exact band 2
  have bd (i:Fin 3) : c.p i^c.e i≤cut x j.val ∨ cut x (j.val+1)<c.p i^c.e i := by
    fin_cases i <;> first | exact band 3 | exact band 4 | exact band 5
  let Q:=cut x j.val
  let N:=cut x (j.val+1)
  let b (i:Fin 3) : Option Bool := if c.p i^c.e i≤Q then none else some (decide (c.p i≤Q))
  have next : N=Q^16 := cut_succ x _
  have xQ : x≤Q := by
    have old:=cut_mono (show 1≤x by omega) (Nat.zero_le j.val)
    simpa [cut,Q] using old
  have np : 0<N := by rw [next];exact pow_pos (by omega) _
  have nb : N≤x^degree:=cut_mono (by omega) (show j.val+1≤7 by omega)
  have space (i) (t:Bool) (mode:b i=some t) : N ≤ (if t then c.p i^c.e i else c.p i) := by
    dsimp [b] at mode
    split at mode
    next=>contradiction
    next off=>
      obtain rfl:=Option.some.inj mode
      by_cases lo : c.p i≤Q
      · simp [lo]
        exact ((bd i).resolve_left off).le
      · simpa [lo] using ((bp i).resolve_left lo).le
  have ds : dust c b≤Q^9 := by
    have per i : Dn (c.p i) (c.e i) (b i)≤Q^3 := by
      have el := (c.cap i).trans (cl.trans xQ)
      by_cases exactMode : c.p i^c.e i≤Q
      · rw [show b i=none from if_pos exactMode]
        change (c.e i+1)*(c.p i^c.e i)≤Q^3
        exact
          (Nat.mul_le_mul el exactMode).trans (show Q*Q≤Q^3 by rw [←sq];exact Nat.pow_le_pow_right (by omega) (by decide))
      · by_cases keep:c.p i≤Q
        · simpa [b,exactMode,keep,Dn,den] using
            (Nat.mul_le_mul el (Nat.pow_le_pow_left (show c.p i-1≤Q by omega) 2)).trans_eq (by ring : Q*Q^2=Q^3)
        · simpa [b,exactMode,keep,Dn,den] using el.trans (Nat.le_self_pow (by decide : 3≠0) Q)
    dsimp [dust]
    exact (prod_le_prod' (fun i _=>per i)).trans_eq (by simp;ring)
  have nz:=separated b
  have iga:=integer_gap c b f g nz
  let orig:=score f g (exactX c) (exactY c)
  let approx:=score f g (x' c b) (y' c b)
  let W:ℚ:=(f+g:ℕ)
  have lite : |orig-W|≤1/(N:ℚ) := close.trans (one_div_le_one_div_of_le (by positivity) (by exact_mod_cast nb))
  have diff:=difference c b f g N np space
  change |approx-orig|≤_ at diff
  change (1:ℚ)≤|approx-W| * dust c b at iga
  have err : |approx-W| * (N:ℚ)≤48*((f:ℚ)+g)+1 := by
    have t:=abs_sub_le approx orig W
    have wn : (0:ℚ)<N:=by exact_mod_cast np
    nlinarith only [mul_le_mul_of_nonneg_right t wn.le,(le_div_iff₀ wn).mp diff,(le_div_iff₀ wn).mp lite]
  have sep : N≤(48*(f+g)+1)*dust c b := by
    have z : (N:ℚ)≤(48*((f:ℚ)+g)+1)*dust c b := by
      nlinarith only [mul_le_mul_of_nonneg_right iga (Nat.cast_nonneg N : (0:ℚ)≤N),
        mul_le_mul_of_nonneg_right err (Nat.cast_nonneg (dust c b) : (0:ℚ)≤_)]
    exact_mod_cast z
  have qr : 128≤Q:=big.trans xQ
  have cfq : f+g≤Q:=cf.trans xQ
  have cf' : 48*(f+g)+1<Q^2 := by
    nlinarith only [cfq,Nat.mul_le_mul_left Q qr,qr]
  have bad : N<Q^11 := sep.trans_lt ((Nat.mul_lt_mul_of_lt_of_le cf' ds (pow_pos (by omega) 9)).trans_eq (by ring))
  have natural : Q^11≤N:=next ▸ Nat.pow_le_pow_right (by omega) (by decide)
  omega

end OMA.SingleMovingStep245212
