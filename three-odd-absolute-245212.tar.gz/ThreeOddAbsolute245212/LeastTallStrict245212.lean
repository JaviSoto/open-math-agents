import LeastTallFactor245212

/-! Strict restoration when the smallest base carries the longest exponent. -/

namespace OMA.LeastTallStrict245212
open Nat Finset OMA.TwoTallLocal245212 OMA.SingleMovingGap245212
open OMA.ThreeMovingLocal245212 (xx yy xn yn den)
open OMA.Smooth245212
open OMA.Abundance245212
open ArithmeticFunction
open scoped ArithmeticFunction.sigma
open private OMA.ThreeMovingLocal245212.quotients from ThreeMovingLocal245212

private theorem upward {p e f g k : ℕ} (hp : p.Prime) (pe : 0<e)
    (ku : 0<k) (gu : 0<g) (fk : k*g≤f) (b : Bool)
    (x x' y y' : ℚ) (x0 : 1≤x) (x1 : 1≤x') (y0 : 0≤y) (y1 : 0≤y')
    (slope : b=true → (g:ℚ)*((p:ℚ)-1)*(y*y') < f) :
    (f:ℚ)*xx p e b*x*x'+g*yy p e b*y*y' < f*X p (some e)*x*x'+g*Y p (some e)*y*y' := by
  have pp : (1:ℚ)<p:=by exact_mod_cast hp.one_lt
  have fg : (k:ℚ)*g≤f:=by exact_mod_cast fk
  have g0 : (0:ℚ)<g:=by exact_mod_cast gu
  have kp : (0:ℚ)<k:=by exact_mod_cast ku
  have fm : (0:ℚ)<f := lt_of_lt_of_le (mul_pos kp g0) fg
  have xl : (1:ℚ)≤x*x' := one_le_mul_of_one_le_of_one_le x0 x1
  have ylo := mul_nonneg y0 y1
  cases b with
  | false =>
    have ysum : 1/((e:ℚ)+1)≤Y p (some e) := by
      have id:=y_factor hp e
      have big : (p:ℚ)^e ≤ σ 1 (p^e) := by
        exact_mod_cast (show p^e ≤ σ 1 (p^e) by rw [sigma_one_apply_prime_pow hp,Finset.sum_range_succ];omega)
      apply (div_le_iff₀ (by positivity : (0:ℚ)<(e:ℚ)+1)).mpr
      apply le_of_mul_le_mul_right (a:=(p:ℚ)^e) _ (by positivity)
      nlinarith only [id,big]
    have ylt := y_strict hp.one_lt (show 0<e from pe)
    have xstrict : 1<X p (some e) := by
      dsimp [X];apply lt_add_of_pos_right;apply _root_.div_pos _ (by linarith)
      exact sub_pos.mpr (ylt.trans_le (y_one hp.one_lt _))
    have minus : 0<(f:ℚ)*(X p (some e)-1)*(x*x') := by positivity
    have plus := mul_nonneg (mul_nonneg g0.le (sub_nonneg.mpr ysum)) ylo
    have xx0 : xx p e false=1 := by simp [xx,xn,den,show (e:ℚ)+1≠0 by positivity]
    have yy0 : yy p e false=1/((e:ℚ)+1) := by simp [yy,yn,den]
    rw [xx0,yy0]
    nlinarith only [minus,plus]
  | true =>
    let u:ℚ:=(p:ℚ)-1
    let d:ℚ:=1/(((e:ℚ)+1)*u^2*(p:ℚ)^e)
    have dp : 0<d := by dsimp [d,u];positivity
    have us : (0:ℚ)≤u:=by dsimp [u];linarith
    have diff : 0<(f:ℚ)*x*x'-g*u*y*y' := by
      nlinarith only [mul_le_mul_of_nonneg_left xl fm.le,slope rfl]
    have q:=OMA.ThreeMovingLocal245212.quotients hp (e:=e)
    change X p (some e)=xx p e true+d ∧ Y p (some e)=yy p e true-u*d at q
    rw [q.1,q.2]
    nlinarith only [mul_pos dp diff]


theorem descend (c : Family) (b : Fin 3→Option Bool) (f g : ℕ) (gp : 0<g) (fg : c.k*g≤f)
    (long : c.e 0+1=c.L) (least : ∀i,c.p 0≤c.p i) (large : 33≤c.p 0) (tall : 32≤c.L)
    (moving : b 0≠none) (small : ∀i,b i=some true → c.p i≤ max (c.k+1) c.L)
    (actual : score f g (exactX c) (exactY c)=(f+g:ℕ)) :
    score f g (x' c b) (y' c b)<score f g (exactX c) (exactY c) := by
  let mix (s : Finset (Fin 3)) (i : Fin 3) := if i∈s then exactX c i else x' c b i
  let miy (s : Finset (Fin 3)) (i : Fin 3) := if i∈s then exactY c i else y' c b i
  have cap (s : Finset (Fin 3)) (i) : miy s i≤33/64 := by
    by_cases si:i∈s
    · simpa only [miy,if_pos si,exactY,yy'] using
        OMA.LeastTallFactor245212.localY (c.prime i) (c.positive i) (large.trans (least i)) none
    · simpa only [miy,if_neg si,y'] using
        OMA.LeastTallFactor245212.localY (c.prime i) (c.positive i) (large.trans (least i)) (b i)
  have adv (s : Finset (Fin 3)) {i} (fresh : i∉s) (bit : Bool) (bi : b i=some bit) :
      score f g (mix s) (miy s)<score f g (mix (insert i s)) (miy (insert i s)) := by
    have bound j : 1≤ mix s j ∧ 0≤ miy s j ∧ miy s j≤2/((c.e j:ℚ)+1) := by
      by_cases mem : j∈s
      · have v:=ranges (c.prime j) (c.positive j) none
        simpa only [mix,miy,if_pos mem,exactX,exactY,xx',yy'] using And.intro v.1 v.2.2
      · have v:=ranges (c.prime j) (c.positive j) (b j)
        simpa only [mix,miy,if_neg mem,x',y'] using And.intro v.1 v.2.2
    have single {j l : Fin 3} (n : j≠i) (n' : l≠i) (jl : j≠l) :
        (f:ℚ)*mix s i*mix s j*mix s l+g*miy s i*miy s j*miy s l <
        f*mix (insert i s) i*mix (insert i s) j*mix (insert i s) l+
          g*miy (insert i s) i*miy (insert i s) j*miy (insert i s) l := by
      have step:=upward (c.prime i) (c.positive i) (by have:=c.kp;omega : 0<c.k) gp fg bit
        (mix s j) (mix s l) (miy s j) (miy s l) (bound j).1 (bound l).1 (bound j).2.1 (bound l).2.1
      suffices slope : bit=true → (g:ℚ)*((c.p i:ℚ)-1)*(miy s j*miy s l) < f by
        simpa [mix,miy,exactX,exactY,x',y',xx',yy',fresh,n,n',bi] using step slope
      intro on
      have up :=small i (on ▸ bi)
      have upos : 0≤(c.p i:ℚ)-1:=by
        have t : (1:ℚ)≤c.p i:=by exact_mod_cast (c.prime i).one_le
        linarith
      by_cases iz : i=0
      · subst i
        have mm:=OMA.LeastTallFactor245212.margin c long least large tall gp actual
        have h:=mul_le_mul (cap s j) (cap s l) (bound l).2.1 (by norm_num : (0:ℚ)≤33/64)
        rw [sq] at mm
        exact (mul_le_mul_of_nonneg_left h (mul_nonneg (by positivity) upos)).trans_lt mm
      · have zeroPerm : j=0 ∨ l=0:=by omega
        have hl : (miy s j*miy s l)*(c.L:ℚ)≤2 := by
          have at0 := (le_div_iff₀ (by positivity)).mp (bound 0).2.2
          have L : (c.L:ℚ)=(c.e 0:ℚ)+1:=by exact_mod_cast long.symm
          have u j : miy s j≤1:=(cap s j).trans (by norm_num)
          rcases zeroPerm with rfl|rfl
          · nlinarith only [mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left (u l) (bound 0).2.1)
              (Nat.cast_nonneg (α:=ℚ) c.L),L ▸ at0]
          · nlinarith only [mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right (u j) (bound 0).2.1)
              (Nat.cast_nonneg (α:=ℚ) c.L),L ▸ at0]
        have g0 : (0:ℚ)<g:=by exact_mod_cast gp
        have fk : (c.k:ℚ)*g≤f:=by exact_mod_cast fg
        have k8 : (8:ℚ)≤c.k:=by exact_mod_cast c.kp
        have hprod := mul_nonneg (bound j).2.1 (bound l).2.1
        have pq : ((c.p i:ℚ)-1)*(miy s j*miy s l)<c.k := by
          rcases (le_max_iff.mp up) with ks|ls
          · have v:(c.p i:ℚ)≤c.k+1:=by exact_mod_cast ks
            have h:=mul_le_mul (cap s j) (cap s l) (bound l).2.1 (by norm_num : (0:ℚ)≤33/64)
            nlinarith only [mul_le_mul_of_nonneg_right (by linarith : (c.p i:ℚ)-1≤c.k) hprod,
              mul_le_mul_of_nonneg_left h (Nat.cast_nonneg (α:=ℚ) c.k),k8]
          · have v:(c.p i:ℚ)≤c.L:=by exact_mod_cast ls
            nlinarith only [hl,mul_le_mul_of_nonneg_right v hprod,hprod,k8]
        nlinarith only [mul_lt_mul_of_pos_left pq g0,fk]
    dsimp [OMA.SingleMovingGap245212.score];simp only [Fin.prod_univ_three]
    have choice : i=0 ∨ i=1 ∨ i=2 := by omega
    rcases choice with rfl|rfl|rfl
    · simpa only [mul_comm,mul_left_comm,mul_assoc] using single (j:=1) (l:=2) (by decide) (by decide) (by decide)
    · simpa only [mul_comm,mul_left_comm,mul_assoc] using single (j:=0) (l:=2) (by decide) (by decide) (by decide)
    · simpa only [mul_comm,mul_left_comm,mul_assoc] using single (j:=0) (l:=1) (by decide) (by decide) (by decide)
  have advance (s : Finset (Fin 3)) {i} (fresh : i∉s) :
      score f g (mix s) (miy s)≤ score f g (mix (insert i s)) (miy (insert i s)) := by
    cases h:b i with
    | some bit=>exact (adv s fresh bit h).le
    | none=>
      have eq (j : Fin 3) : mix s j=mix (insert i s) j ∧ miy s j=miy (insert i s) j := by
        by_cases n:j=i
        · subst j;simp [mix,miy,fresh,x',y',exactX,exactY,h,xx',yy']
        · simp [mix,miy,n]
      rw [funext (fun j=>(eq j).1),funext (fun j=>(eq j).2)]
  obtain ⟨bit,b0⟩:=Option.ne_none_iff_exists'.mp moving
  have a:=adv ∅ (i:=0) (by decide) bit b0
  have b1:=advance {0} (i:=1) (by decide)
  have d:=advance {1,0} (i:=2) (by decide)
  have un : insert (2:Fin 3) ({1,0}:Finset (Fin 3))=univ:=by decide
  rw [un] at d
  simpa [mix,miy] using ((a.trans_le b1).trans_le d)

end OMA.LeastTallStrict245212
