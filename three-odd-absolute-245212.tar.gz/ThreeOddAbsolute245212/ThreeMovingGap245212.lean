import ThreeMovingLocal245212

/-! Every prefix of three signed, rounded local moments is separated if
its shortest length squared dominates its longest length relative to k. -/
namespace OMA.ThreeMovingGap245212
open Nat Finset OMA.Smooth245212 OMA.ThreeMovingLocal245212

structure Family where
  p : Fin 3→ℕ
  e : Fin 3→ℕ
  k : ℕ
  m : ℕ
  L : ℕ
  prime : ∀i,(p i).Prime
  positive : ∀i,0<e i
  kp : 0<k
  mp : 0 < m
  lengths : ∀i,m≤e i+1 ∧ e i+1≤L
  comparable : 4*max k L < k*m^2

def exactX (c : Family) (i : Fin 3) := X (c.p i) (some (c.e i))
def exactY (c : Family) (i : Fin 3) := Y (c.p i) (some (c.e i))
def x' (c : Family) (b : Fin 3→Bool) (i : Fin 3) := xx (c.p i) (c.e i) (b i)
def y' (c : Family) (b : Fin 3→Bool) (i : Fin 3) := yy (c.p i) (c.e i) (b i)
def dust (c : Family) (b : Fin 3→Bool) := ∏i,den (c.p i) (c.e i) (b i)
def NX (c : Family) (b : Fin 3→Bool) := ∏i,xn (c.p i) (c.e i) (b i)
def NY (c : Family) (b : Fin 3→Bool) := ∏i,yn (c.p i) (c.e i) (b i)
def score (f g : ℕ) (x y : Fin 3→ℚ) := (f:ℚ)*(∏i,x i)+(g:ℚ)*(∏i,y i)

theorem dust_pos (c : Family) (b : Fin 3→Bool) : 0<dust c b :=
  prod_pos (fun i _=>den_pos (c.prime i).two_le _ _)

theorem clear (c : Family) (b : Fin 3→Bool) (f g : ℕ) :
    score f g (x' c b) (y' c b)*dust c b=(f*NX c b+g*NY c b:ℕ) := by
  have w : (∏i,x' c b i)*(dust c b:ℚ)=NX c b := by
    dsimp [dust,NX,x',xx];push_cast;rw [←prod_mul_distrib]
    apply prod_congr rfl;intro i _
    exact div_mul_cancel₀ _ (by exact_mod_cast (den_pos (c.prime i).two_le (c.e i) (b i)).ne')
  have s : (∏i,y' c b i)*(dust c b:ℚ)=NY c b := by
    dsimp [dust,NY,y',yy];push_cast;rw [←prod_mul_distrib]
    apply prod_congr rfl;intro i _
    exact div_mul_cancel₀ _ (by exact_mod_cast (den_pos (c.prime i).two_le (c.e i) (b i)).ne')
  dsimp [score];push_cast
  linear_combination (f:ℚ)*w+(g:ℚ)*s

private theorem descend (c : Family) (b : Fin 3→Bool) (f g : ℕ) (gp : 0<g) (fg : c.k*g≤f)
    (small : ∀i,b i=true → c.p i≤ max (c.k+1) c.L) :
    score f g (x' c b) (y' c b)<score f g (exactX c) (exactY c) := by
  let mix (s : Finset (Fin 3)) (i : Fin 3) := if i∈s then exactX c i else x' c b i
  let miy (s : Finset (Fin 3)) (i : Fin 3) := if i∈s then exactY c i else y' c b i
  have adv (s : Finset (Fin 3)) {i} (fresh : i∉s) :
      score f g (mix s) (miy s)<score f g (mix (insert i s)) (miy (insert i s)) := by
    let all j:=bounds (c.prime j) (c.positive j) c.mp (c.lengths j).1 (b j)
    have xpos s j : 1≤ mix s j := by
      dsimp [mix];split <;> first | exact (all j).1 | exact (all j).2.2.2.2.1
    have ylo s j : 0≤ miy s j := by
      dsimp [miy];split <;> first | exact (all j).2.2.1 | exact (all j).2.2.2.2.2.2.1
    have yhi s j : miy s j≤2/(c.m:ℚ) := by
      dsimp [miy];split <;> first | exact (all j).2.2.2.1 | exact (all j).2.2.2.2.2.2.2
    have single {j l : Fin 3} (n : j≠i) (n' : l≠i) :
        (f:ℚ)*mix s i*mix s j*mix s l+g*miy s i*miy s j*miy s l <
        f*mix (insert i s) i*mix (insert i s) j*mix (insert i s) l+
          g*miy (insert i s) i*miy (insert i s) j*miy (insert i s) l := by
      have size (inb : b i=true) : 4*(c.p i-1)<c.k*c.m^2 := by
        have lim:=small i inb
        have before : c.p i-1≤ max c.k c.L := by omega
        exact (Nat.mul_le_mul_left _ before).trans_lt c.comparable
      have step:=move (c.prime i) (c.positive i) c.mp c.kp gp fg (b i) size
        (mix s j) (mix s l) (miy s j) (miy s l) (xpos s j) (xpos s l) (ylo s j) (ylo s l) (yhi s j) (yhi s l)
      simpa [mix,miy,exactX,exactY,x',y',fresh,n,n'] using step
    dsimp [score]
    simp only [Fin.prod_univ_three]
    have choice : i=0 ∨ i=1 ∨ i=2 := by omega
    rcases choice with rfl|rfl|rfl
    · simpa only [mul_comm,mul_left_comm,mul_assoc] using single (j:=1) (l:=2) (by decide) (by decide)
    · simpa only [mul_comm,mul_left_comm,mul_assoc] using single (j:=0) (l:=2) (by decide) (by decide)
    · simpa only [mul_comm,mul_left_comm,mul_assoc] using single (j:=0) (l:=1) (by decide) (by decide)
  have a:=adv ∅ (i:=0) (by decide)
  have b1:=adv {0} (i:=1) (by decide)
  have d:=adv {1,0} (i:=2) (by decide)
  have endset : insert (2:Fin 3) ({1,0}:Finset (Fin 3))=univ := by decide
  simpa [mix,miy,endset] using (a.trans b1).trans d

private theorem largest {c : Family} {b : Fin 3→Bool} {f g l : ℕ} (frac : f+g=(c.k+1)*l)
    (unit : ∀i,¬c.p i∣l) (hit : (f+g)*dust c b=f*NX c b+g*NY c b) :
    ∀i,b i=true → c.p i≤ max (c.k+1) c.L := by
  classical
  let s:=univ.filter (fun j=>b j=true)
  intro i hi
  have im : i∈s:=mem_filter.mpr ⟨mem_univ _,hi⟩
  obtain ⟨j,jm,top⟩:=s.exists_max_image c.p ⟨i,im⟩
  have sh: b j=true := (mem_filter.mp jm).2
  let q:=c.p j
  have pr:=c.prime j
  have dn : q∣NX c b := by
    apply dvd_trans (b:=xn (c.p j) (c.e j) (b j)) _ (dvd_prod_of_mem (fun i=>xn (c.p i) (c.e i) (b i)) (mem_univ j))
    simp [xn,sh,q]
  have ds : q∣NY c b := by
    apply dvd_trans (b:=yn (c.p j) (c.e j) (b j)) _ (dvd_prod_of_mem (fun i=>yn (c.p i) (c.e i) (b i)) (mem_univ j))
    simp [yn,sh,q]
  have total : q∣(f+g)*dust c b := hit ▸ dvd_add (dvd_mul_of_dvd_right dn f) (dvd_mul_of_dvd_right ds g)
  apply (top _ im).trans
  by_contra! no
  change max (c.k+1) c.L < q at no
  rw [frac] at total
  rcases pr.dvd_mul.mp total with h|h
  · rcases pr.dvd_mul.mp h with small|bad
    · exact (Nat.not_dvd_of_pos_of_lt (by omega) (by omega)) small
    · exact unit j bad
  · obtain ⟨i',_,v⟩:=(pr.prime.dvd_finsetProd_iff _).mp h
    have le0:= (c.lengths i').2
    have absent := Nat.not_dvd_of_pos_of_lt (by omega : 0<c.e i'+1) (by omega : c.e i'+1<q)
    dsimp [den] at v
    split at v
    next on =>
      have mt : i'∈s:=mem_filter.mpr ⟨mem_univ _,on⟩
      have sz:=top i' mt
      rcases pr.dvd_mul.mp v with bad|bad
      · exact absent bad
      · exact Nat.not_dvd_of_pos_of_lt (by have:=(c.prime i').two_le;omega : 0<c.p i'-1)
          (by omega) (pr.dvd_of_dvd_pow bad)
    next off => exact absent v

theorem nonzero (c : Family) (b : Fin 3→Bool) (f g l : ℕ) (gp : 0<g) (fg : c.k*g≤f)
    (frac : f+g=(c.k+1)*l) (unit : ∀i,¬c.p i∣l)
    (actual : score f g (exactX c) (exactY c)≤(f+g:ℕ)) :
    (f+g)*dust c b ≠ f*NX c b+g*NY c b := by
  intro hit
  have less:=(descend c b f g gp fg (largest frac unit hit)).trans_le actual
  have val:=clear c b f g
  have id : ((f+g:ℕ):ℚ)*dust c b=((f*NX c b+g*NY c b:ℕ):ℚ) := by exact_mod_cast hit
  exact (ne_of_lt (mul_lt_mul_of_pos_right less (show (0:ℚ)<dust c b by exact_mod_cast dust_pos c b))) (val.trans id.symm)

end OMA.ThreeMovingGap245212
