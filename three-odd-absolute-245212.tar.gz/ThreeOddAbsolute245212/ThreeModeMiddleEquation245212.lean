import MiddleWitness245212
import ThreeMovingOriginal245212

/-! With the least odd prime exact, the middle base retained, and the
last base dropped, the cleared three-factor score is an equation in the
two divisor moments of the exact prefix. Restoring the middle factor
with a negative sign selects the strict side of that equation. -/
namespace OMA.ThreeModeMiddleEquation245212
open Nat Finset ArithmeticFunction OMA.Smooth245212
open OMA.SingleMovingGap245212 OMA.TwoTallLocal245212 OMA.ThreeMovingLocal245212
open OMA.ThreeMovingOriginal245212 (F G)
open scoped ArithmeticFunction.sigma
open private OMA.ComplementaryLocal245212.binary from ComplementaryLocal245212
open private OMA.ThreeMovingOriginal245212.identities from ThreeMovingOriginal245212

private theorem prefixData (k p e : ℕ) (pr : p.Prime) (odd : Odd p) :
    let h:=2^k*p^e
    W h=F k*W (p^e) ∧ σ 1 h=G k*σ 1 (p^e) ∧
    2*h*(σ 0 h)=(F k+G k)*((e+1)*p^e) := by
  dsimp only
  have cop:=((Nat.coprime_two_left.mpr odd).pow_left k).pow_right e
  have sum : σ 1 (2^k)=G k := by
    dsimp [G];zify [Nat.cast_sub (show 1≤2^(k+1) from Nat.two_pow_pos _)]
    exact (OMA.ComplementaryLocal245212.binary k).1
  have weight : W (2^k)=F k := by exact_mod_cast (OMA.ComplementaryLocal245212.binary k).2
  rw [w_mult.map_mul_of_coprime cop,isMultiplicative_sigma.map_mul_of_coprime cop,
    isMultiplicative_sigma.map_mul_of_coprime cop,sigma_zero_apply_prime_pow Nat.prime_two,
    sigma_zero_apply_prime_pow pr,sum,weight,(OMA.ThreeMovingOriginal245212.identities k).2.1,pow_succ]
  exact ⟨rfl,rfl,by ring⟩

theorem adapter (c : Family) (odd : Odd (c.p 0)) (b : Fin 3→Option Bool)
    (b0 : b 0=none) (b1 : b 1=some true) (b2 : b 2=some false)
    (hit : (F c.k+G c.k)*dust c b=F c.k*NX c b+G c.k*NY c b)
    (negative : (F c.k:ℚ)*(x' c b 0*x' c b 2)<
      (G c.k:ℚ)*((c.p 1:ℚ)-1)*(y' c b 0*y' c b 2)) :
    let h:=2^c.k*(c.p 0)^(c.e 0)
    let A:=W h;let S:=σ 1 h;let H:=2*h*(σ 0 h)
    let B:=c.e 1+1;let C:=c.e 2+1;let u:=c.p 1-1
    H*B*C*u^2=c.p 1*(A*C*(B*u-1)+S*u) ∧ A*C<S*u := by
  dsimp only
  obtain ⟨av,sv,hv⟩:=prefixData c.k (c.p 0) (c.e 0) (c.prime 0) odd
  rw [av,sv,hv]
  constructor
  · simp only [dust,NX,NY,Fin.prod_univ_three,b0,b1,b2,Dn,Nx,Ny,den,xn,yn,
      if_true,Bool.false_eq_true,if_false,mul_one] at hit
    linear_combination hit
  · let D i:=Dn (c.p i) (c.e i) (b i)
    have dp (i:Fin 3) : 0 < (D i:ℚ):= by exact_mod_cast Dpos (c.prime i) (c.e i) (b i)
    have wx (i:Fin 3) : x' c b i*(D i:ℚ)=Nx (c.p i) (c.e i) (b i) :=
      (moments (c.prime i) (c.e i) (b i)).1
    have sy (i:Fin 3) : y' c b i*(D i:ℚ)=Ny (c.p i) (c.e i) (b i) :=
      (moments (c.prime i) (c.e i) (b i)).2
    have scale:=mul_lt_mul_of_pos_right negative (mul_pos (dp 0) (dp 2))
    have ex : (x' c b 0*x' c b 2)*((D 0:ℚ)*D 2)=
        Nx (c.p 0) (c.e 0) (b 0)*(Nx (c.p 2) (c.e 2) (b 2):ℚ) := by
      rw [←wx 0,←wx 2];ring
    have ey : (y' c b 0*y' c b 2)*((D 0:ℚ)*D 2)=
        Ny (c.p 0) (c.e 0) (b 0)*(Ny (c.p 2) (c.e 2) (b 2):ℚ) := by
      rw [←sy 0,←sy 2];ring
    rw [mul_assoc (F c.k:ℚ),mul_assoc ((G c.k:ℚ)*_),ex,ey] at scale
    simp only [b0,b2,Nx,Ny,xn,yn,Bool.false_eq_true,if_false,Nat.cast_one,mul_one] at scale
    have pos:=(c.prime 1).pos
    rw [←Nat.cast_one (R:=ℚ),←Nat.cast_sub pos] at scale
    exact_mod_cast (by linarith only [scale] :
      (F c.k:ℚ)*W (c.p 0^c.e 0)*(c.e 2+1:ℕ) <
        (G c.k:ℚ)*σ 1 (c.p 0^c.e 0)*(c.p 1-1:ℕ))

#print axioms adapter
end OMA.ThreeModeMiddleEquation245212
