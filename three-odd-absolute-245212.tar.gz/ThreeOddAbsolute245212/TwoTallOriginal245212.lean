import TwoTallStep245212
import DyadicLeast245212

/-! Absolute bounds for the shortest of three moving odd prime exponents
if the longest is not too large. The dyadic exponent is unrestricted. -/
namespace OMA.TwoTallOriginal245212
open Nat Finset ArithmeticFunction OMA.TwoTallGap245212 OMA.TwoTallScalar245212
open OMA.Smooth245212 (total W)
open scoped ArithmeticFunction.sigma
open private OMA.ComplementaryLocal245212.binary from ComplementaryLocal245212

def F (k : ℕ) := 1+k*2^(k+1)
def G (k : ℕ) := 2^(k+1)-1

private theorem identities (k : ℕ) : 0<G k ∧ F k+G k=(k+1)*2^(k+1) ∧ F k=k*G k+(k+1) := by
  have g:=Nat.two_pow_pos k
  dsimp [F,G];rw [pow_succ]
  have sub:=Nat.sub_add_cancel (show 1≤2^k*2 by omega)
  exact ⟨by omega,by nlinarith only [sub],by nlinarith only [congrArg (k*·) sub]⟩

theorem physical (c : Family) (k : ℕ) (op : ∀i,Odd (c.p i)) (inj : c.p.Injective)
    (eqn : OeisA245212.a (2^k*total c.p c.e)=(σ 1 (2^k*total c.p c.e):ℤ)) :
    score (F k) (G k) (exactX c) (exactY c)=(F k+G k:ℕ) := by
  let t:=2^k*σ 0 (2^k)
  have t0 : 0<t := Nat.mul_pos (Nat.two_pow_pos k) (sigma_pos 0 _ (Nat.two_pow_pos k).ne')
  have norm:=OMA.CofactorCrossOriginal245212.normalized_extension (p:=c.p) (e:=c.e) (Nat.two_pow_pos k)
    c.prime inj (fun i=>(Nat.coprime_two_left.mpr (op i)).pow_left k) eqn
  change ((W (2^k):ℚ)/t)*(∏i,exactX c i)+((σ 1 (2^k):ℚ)/t)*(∏i,exactY c i)=2 at norm
  field_simp [show (t:ℚ)≠0 by exact_mod_cast t0.ne'] at norm
  have z0:=Nat.two_pow_pos (k+1)
  have gold : σ 1 (2^k)=G k := by
    dsimp [G];zify [Nat.cast_sub (show 1≤2^(k+1) from z0)]
    exact (OMA.ComplementaryLocal245212.binary k).1
  have fold : W (2^k)=F k := by exact_mod_cast (OMA.ComplementaryLocal245212.binary k).2
  have ht : 2*t=F k+G k := by
    dsimp [t];rw [sigma_zero_apply_prime_pow Nat.prime_two,(identities k).2.1,pow_succ];ring
  rw [gold,fold] at norm
  dsimp [score];rw [←ht];push_cast;linarith only [norm]

private theorem small_case (c : Family) (hp : ∀i,3≤c.p i) (hk : ∀i,c.k<2*c.p i) (high : minimumCut≤c.m)
    (exact : score (F c.k) (G c.k) (exactX c) (exactY c)=(F c.k+G c.k:ℕ)) : False := by
  let x:=base c.k c.L
  have big : 128≤x := by dsimp [base,x];nlinarith only [Nat.zero_le (c.k*c.L),Nat.zero_le c.k,Nat.zero_le c.L]
  have cf : c.k+1≤x := by dsimp [base,x];nlinarith only [Nat.zero_le (c.k*c.L),Nat.zero_le c.k,Nat.zero_le c.L]
  have cl : c.L≤x := by dsimp [base,x];nlinarith only [Nat.zero_le (c.k*c.L),Nat.zero_le c.k,Nat.zero_le c.L]
  have comp : c.L≤c.k*c.m^2 := by
    have small : c.L≤c.k*c.m:=by have:=c.comparable;omega
    exact small.trans (Nat.mul_le_mul_left _ (Nat.le_self_pow (by decide : 2≠0) _))
  have powers i (ni : i≠2) : x^degree≤c.p i^c.e i := scale (hp i) (hk i) high comp (c.long i ni)
  have dx : 1≤x:=by omega
  have r0 := (identities c.k).1
  let PX:=∏i,exactX c i
  let PY:=∏i,exactY c i
  have xb i := OMA.ThreeMovingLocal245212.bounds (c.prime i) (c.positive i) (Nat.succ_pos (c.e i)) (le_refl _) true
  have low : (1:ℚ)≤PX:=one_le_prod (fun i _=>(xb i).1)
  have top : PX≤8 := calc
    _ ≤ ∏_i:Fin 3,(2:ℚ) := prod_le_prod (fun i _=>zero_le_one.trans (xb i).1) (fun i _=>(xb i).2.1)
    _ = _ := by norm_num
  have id : (G c.k:ℚ)*((c.k:ℚ)+1-score c.k 1 (exactX c) (exactY c))=((c.k:ℚ)+1)*(PX-1) := by
    change (F c.k:ℚ)*PX+(G c.k:ℚ)*PY=(F c.k+G c.k:ℕ) at exact
    change _*((c.k:ℚ)+1-((c.k:ℚ)*PX+(1:ℕ)*PY))=_
    have f : (F c.k:ℚ)=(c.k:ℚ)*G c.k+(c.k+1:ℕ) := by exact_mod_cast (identities c.k).2.2
    push_cast at f exact ⊢
    linear_combination -exact+(PX-1)*f
  have gp : (0:ℚ)<G c.k := by exact_mod_cast r0
  by_cases ample : 8*(c.k+1)*x^budget≤G c.k
  · have below : score c.k 1 (exactX c) (exactY c)≤(c.k+1:ℕ):=by
      push_cast
      exact sub_nonneg.mp (nonneg_of_mul_nonneg_right (id ▸ mul_nonneg (by positivity) (sub_nonneg.mpr low)) gp)
    have close : |score c.k 1 (exactX c) (exactY c)-(c.k+1:ℕ)|≤1/((x^budget:ℕ):ℚ) := by
      rw [abs_of_nonpos (sub_nonpos.mpr below),neg_sub]
      have h : (((c.k+1:ℕ):ℚ)-score c.k 1 (exactX c) (exactY c))*(x^budget:ℕ)≤1 := by
        apply le_of_mul_le_mul_left (a:=(G c.k:ℚ)) _ gp
        have g0 : (8:ℚ)*(c.k+1)*(x^budget:ℕ)≤G c.k:=by exact_mod_cast ample
        push_cast at g0 ⊢
        nlinarith only [congrArg (·*(x:ℚ)^budget) id,g0,
          mul_le_mul_of_nonneg_right (show PX-1≤8 by linarith) (show 0≤((c.k:ℚ)+1)*x^budget by positivity)]
      exact (le_div_iff₀ (by exact_mod_cast pow_pos dx budget : (0:ℚ)<(x^budget:ℕ))).mpr h
    apply OMA.TwoTallStep245212.contradiction c c.k 1 1 x (by decide) (by simp) (by simp) _ big cf cl
      (fun i ni=>(Nat.pow_le_pow_right dx (show budget≤degree by decide)).trans (powers i ni)) below close
    intro i; exact Nat.not_dvd_of_pos_of_lt (by decide) (c.prime i).one_lt
  · let x':=x^(budget+4)
    have lift : x≤x':=Nat.le_self_pow (by omega : budget+4≠0) _
    have fcap : F c.k+G c.k≤x' := by
      have gcap : G c.k+1≤8*(c.k+1)*x^budget:=by omega
      have zid : 2^(c.k+1)=G c.k+1 := by dsimp [G];have:=Nat.two_pow_pos (c.k+1);omega
      rw [(identities c.k).2.1,zid]
      calc
        _ ≤ (c.k+1)*(8*(c.k+1)*x^budget) := Nat.mul_le_mul_left _ gcap
        _ = (c.k+1)*(8*((c.k+1)*x^budget)) := by ring
        _ ≤ x*(x*(x*x^budget)) := Nat.mul_le_mul cf (Nat.mul_le_mul (by omega) (Nat.mul_le_mul_right _ cf))
        _ = x^(budget+3) := by rw [pow_add];ring
        _ ≤ x' := Nat.pow_le_pow_right dx (by omega)
    apply OMA.TwoTallStep245212.contradiction c (F c.k) (G c.k) (2^(c.k+1)) x' r0
      (by have:=(identities c.k).2.2;omega) (identities c.k).2.1 _ (big.trans lift) fcap (cl.trans lift)
      (fun i ni=>by dsimp [x'];rw [←pow_mul];exact powers i ni) exact.le (by rw [exact,sub_self,abs_zero];positivity)
    intro i d
    have dv:=(c.prime i).dvd_of_dvd_pow d
    exact (Nat.not_dvd_of_pos_of_lt (by decide) (hp i)) dv

theorem shortest {k m L : ℕ} (p e : Fin 3→ℕ) (hp : ∀i,(p i).Prime) (op : ∀i,Odd (p i)) (inj : p.Injective)
    (ep : ∀i,0<e i) (kp : 0<k) (mp : 0 < m) (long : ∀i,i≠2 → m≤e i+1) (cap : ∀i,e i+1≤L)
    (comp : 4*max k L < k*m)
    (eqn : OeisA245212.a (2^k*total p e)=(σ 1 (2^k*total p e):ℤ)) : m < minimumCut := by
  by_contra! high
  let c : Family := ⟨p,e,k,m,L,hp,ep,kp,mp,long,cap,inj,comp⟩
  have p3 i : 3≤p i := by have:=(hp i).two_le;obtain ⟨j,ju⟩:=op i;omega
  have odd : Odd (total p e) := Nat.coprime_two_left.mp (Coprime.prod_right (fun i _=>(Nat.coprime_two_left.mpr (op i)).pow_right _))
  have inF i : p i∈(total p e).primeFactors := Nat.mem_primeFactors.mpr ⟨hp i,
    (dvd_pow_self _ (ep i).ne').trans (dvd_prod_of_mem (fun j=>p j^e j) (mem_univ i)),odd.pos.ne'⟩
  exact small_case c p3 (fun i=>OMA.DyadicLeast245212.exponent_lt_twice_prime odd (inF i) eqn) high (physical c k op inj eqn)

end OMA.TwoTallOriginal245212
