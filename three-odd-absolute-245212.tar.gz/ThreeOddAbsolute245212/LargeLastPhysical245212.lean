import ComplementaryLocal245212

/-! Exact integer identity after rounding only the final prime and the
dyadic moment, with all other odd prime powers kept exact. -/
namespace OMA.LargeLastPhysical245212
open Nat Finset ArithmeticFunction OMA.Smooth245212
open scoped ArithmeticFunction.sigma
open private OMA.ComplementaryLocal245212.binary from ComplementaryLocal245212

def u (r : ℕ) := r-1
def B (r d : ℕ) := (d+1)*(u r)^2
def w (r d : ℕ) := r*((d+1)*u r-1)
def s (r : ℕ) := r*u r
def G (k : ℕ) := 2^(k+1)-1

theorem identity {h r k d : ℕ} (hp : 0<h) (ho : Odd h) (pr : r.Prime)
    (ro : Odd r) (cop : h.Coprime r)
    (eqn : OeisA245212.a (2^k*h*r^d)=(σ 1 (2^k*h*r^d):ℤ)) :
    let A : ℤ := W h
    let S : ℤ := σ 1 h
    let T : ℤ := h*σ 0 h
    let J : ℤ := (k+1)*T*(B r d)-k*A*(w r d)-S*(s r)
    let U : ℤ := k*A-(u r)*S
    let V : ℤ := (k+1)*(A*(w r d)-T*(B r d))
    (G k:ℤ)*r^d*J=(G k)*U+(k+1)*A+(r:ℤ)^d*V := by
  have c1 : (2^k).Coprime h := (coprime_two_left.mpr ho).pow_left k
  have c2 : (2^k*h).Coprime (r^d) := (((coprime_two_left.mpr ro).pow_left k).mul_left cop).pow_right d
  have pos : 0<2^k*h*r^d:=Nat.mul_pos (Nat.mul_pos (Nat.two_pow_pos k) hp) (pow_pos pr.pos _)
  have natbal:=OMA.Abundance245212.balance pos.ne' eqn
  rw [w_mult.map_mul_of_coprime c2,w_mult.map_mul_of_coprime c1,
    isMultiplicative_sigma.map_mul_of_coprime c2,isMultiplicative_sigma.map_mul_of_coprime c1,
    isMultiplicative_sigma.map_mul_of_coprime c2,isMultiplicative_sigma.map_mul_of_coprime c1,
    sigma_zero_apply_prime_pow prime_two,sigma_zero_apply_prime_pow pr] at natbal
  have bal:=congrArg ((↑):ℕ→ℤ) natbal
  push_cast at bal
  have zm:=OMA.ComplementaryLocal245212.binary k
  rw [zm.1,zm.2] at bal
  have m:=OMA.ComplementaryLocal245212.moments pr d
  have ru : 1≤(d+1)*u r:=mul_pos (Nat.succ_pos _) (Nat.sub_pos_of_lt pr.one_lt)
  have gz : 1≤2^(k+1):=Nat.two_pow_pos _
  dsimp only
  unfold G B w s u
  unfold u at ru
  push_cast [Nat.cast_sub gz,Nat.cast_sub pr.pos,Nat.cast_sub ru]
  rw [pow_succ' (2:ℤ) k] at bal ⊢
  linear_combination -((r:ℤ)-1)^2*bal+
    ((1+(k:ℤ)*(2*2^k))*(W h:ℤ))*m.2+
    (((2:ℤ)*2^k-1)*(σ 1 h:ℤ)*((r:ℤ)-1))*m.1

end OMA.LargeLastPhysical245212
