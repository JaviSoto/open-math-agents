import CofactorPrimeChain245212

/-! A fixed-rank family with no cross divisibility between its prime
bases and its exponent lengths is finite. The induction absorbs one
bounded prime power into the cofactor. -/
namespace OMA.CofactorCrossCount245212
open Finset Nat OMA.Smooth245212
open private OMA.FixedExponents245212.y_pos from FixedExponents245212
open scoped ArithmeticFunction.sigma

def balance {K : ℕ} (A T : ℕ) (d : ℚ) (p e : Fin K→ℕ) : Prop :=
  ((A:ℚ)/T)*(∏ i,X (p i) (some (e i)))+d*(∏ i,Y (p i) (some (e i)))=2

structure Admissible {K : ℕ} (T : ℕ) (p e : Fin K→ℕ) : Prop where
  prime (i) : (p i).Prime
  odd (i) : Odd (p i)
  positive (i) : 0<e i
  distinct : Function.Injective p
  avoid (i) : ¬p i∣2*T
  cross (i j) : i≠j → ¬p i∣e j+1

private theorem below {K A T : ℕ} {d : ℚ} {p e : Fin K→ℕ}
    (tp : 0<T) (dp : 0<d) (ok : Admissible T p e) (eqn : balance A T d p e) : A<2*T := by
  have one (i) : 1≤X (p i) (some (e i)) :=
    le_add_of_nonneg_right (div_nonneg (sub_nonneg.mpr (y_one (ok.prime i).one_lt _))
      (sub_nonneg.mpr (by exact_mod_cast (ok.prime i).one_le)))
  have all : 1≤∏i,X (p i) (some (e i)) := by
    calc
      1 = ∏ _i : Fin K,(1:ℚ) := by simp
      _ ≤ _ := prod_le_prod (fun _ _=>by norm_num) (fun i _=>one i)
  have yp := prod_pos (s:=univ) (fun i _=>OMA.FixedExponents245212.y_pos (ok.prime i) (e i))
  have c0 : 0≤(A:ℚ)/T := by positivity
  have small : (A:ℚ)/T<2 := by unfold balance at eqn;nlinarith only [eqn,mul_pos dp yp,mul_nonneg c0 (sub_nonneg.mpr all)]
  exact_mod_cast (div_lt_iff₀ (by exact_mod_cast tp : (0:ℚ)<T)).mp small

private theorem atom {K A T : ℕ} {d : ℚ} (kp : 0<K) (tp : 0<T) (cut : A<2*T)
    (dp : 0<d) (ds : d≤1) :
    ∃ B : ℕ, ∀ p e : Fin K→ℕ, Admissible T p e → balance A T d p e → ∃i,p i≤B ∧ e i≤B := by
  classical
  obtain ⟨L,alt⟩:=OMA.CofactorPrimeChain245212.alternative K A T tp cut d dp.le ds
  let F : Set (Fin K→ℕ) := {e | ∀i,0<e i ∧ e i≤L}
  let bases (e : Fin K→ℕ) : Set (Fin K→ℕ) := {p | (∀i,(p i).Prime) ∧ balance A T d p e}
  have cf : F.Finite := (Set.Finite.pi' (fun _ : Fin K=>Set.finite_Iic L)).subset
    (fun _ h i=>(h i).2)
  have bf := cf.biUnion (fun e he=>(show (bases e).Finite from
    OMA.FixedExponents245212.finite_bases e (fun i=>(he i).1) ((A:ℚ)/T) d 2 (by positivity) dp))
  obtain ⟨M,cap⟩:=(bf.biUnion (fun p _=>Set.finite_range p)).bddAbove
  refine ⟨max L M,?_⟩
  intro p e ok eqn
  rcases alt p e ok.prime ok.odd ok.avoid eqn with low|⟨i,pi,ei⟩
  · let i : Fin K:=⟨0,kp⟩
    have ef : e∈F:=fun j=>⟨ok.positive j,low j⟩
    have mem : p∈⋃ t∈F,bases t:=Set.mem_iUnion₂.mpr ⟨e,ef,ok.prime,eqn⟩
    have pm:=cap (Set.mem_iUnion₂.mpr ⟨p,mem,i,rfl⟩)
    exact ⟨i,pm.trans (le_max_right _ _),(low i).trans (le_max_left _ _)⟩
  · exact ⟨i,pi.trans (le_max_left _ _),ei.trans (le_max_left _ _)⟩

private def scale (p e : ℕ) := (e+1)*p^e

private theorem peel {K A T : ℕ} {d : ℚ} {p e : Fin (K+1)→ℕ} (j : Fin (K+1))
    (tp : 0<T) (ok : Admissible T p e) (eqn : balance A T d p e) :
    Admissible (T*scale (p j) (e j)) (p ∘ j.succAbove) (e ∘ j.succAbove) ∧
    balance (A*W (p j^e j)) (T*scale (p j) (e j)) (d*Y (p j) (some (e j)))
      (p ∘ j.succAbove) (e ∘ j.succAbove) := by
  constructor
  · refine ⟨fun i=>ok.prime _,fun i=>ok.odd _,fun i=>ok.positive _,ok.distinct.comp j.succAbove_right_injective,?_,?_⟩
    · intro i dv
      let l:=j.succAbove i
      change p l∣2*(T*scale (p j) (e j)) at dv
      rw [←mul_assoc] at dv
      rcases (ok.prime l).dvd_mul.mp dv with a|a
      · exact ok.avoid l a
      rcases (ok.prime l).dvd_mul.mp a with b|b
      · exact ok.cross l j (Fin.succAbove_ne _ _) b
      exact Fin.succAbove_ne j i (ok.distinct ((prime_dvd_prime_iff_eq (ok.prime l) (ok.prime j)).mp
        ((ok.prime l).dvd_of_dvd_pow b)))
    · intro i k neq
      exact ok.cross _ _ (fun same=>neq (j.succAbove_right_injective same))
  · have hscale : 0<scale (p j) (e j) := by unfold scale;have:= (ok.prime j).pos;positivity
    have fx:=x_factor (ok.prime j) (e j)
    have val : ((A*W (p j^e j):ℕ):ℚ)/(T*scale (p j) (e j):ℕ)=((A:ℚ)/T)*X (p j) (some (e j)) := by
      push_cast
      field_simp [show (scale (p j) (e j):ℚ)≠0 by exact_mod_cast hscale.ne',
        show (T:ℚ)≠0 by exact_mod_cast tp.ne']
      unfold scale
      push_cast
      linear_combination -(A:ℚ)*fx
    unfold balance at eqn ⊢
    rw [Fin.prod_univ_succAbove (fun i=>X (p i) (some (e i))) j,
      Fin.prod_univ_succAbove (fun i=>Y (p i) (some (e i))) j] at eqn
    simpa only [val,Function.comp_apply,mul_assoc] using eqn

theorem bounded (K : ℕ) : ∀ (A T : ℕ) (d : ℚ), 0<T → 0<d → d≤1 →
    ∃ B : ℕ,∀ p e : Fin K→ℕ, Admissible T p e → balance A T d p e → total p e≤B := by
  classical
  induction K with
  | zero =>
    intro A T d _ _ _
    exact ⟨1,fun p e _ _=>by simp [total]⟩
  | succ K ih =>
    intro A T d tp dp ds
    by_cases cut : A<2*T
    · obtain ⟨L,cap⟩:=atom (K:=K+1) (Nat.succ_pos _) tp cut dp ds
      let bound (r z : ℕ) : ℕ := if good : r.Prime then
        Classical.choose (ih (A*W (r^z)) (T*scale r z) (d*Y r (some z))
          (by unfold scale;have:=good.pos;positivity) (mul_pos dp (OMA.FixedExponents245212.y_pos good z))
          ((mul_le_of_le_one_right dp.le (y_one good.one_lt _)).trans ds)) else 0
      let maxRest:=((range (L+1)).product (range (L+1))).sup (fun k=>bound k.1 k.2)
      refine ⟨(L+1)^L*maxRest,?_⟩
      intro p e ok eqn
      obtain ⟨j,pj,ej⟩:=cap p e ok eqn
      have rest:=peel j tp ok eqn
      have rule : total (p ∘ j.succAbove) (e ∘ j.succAbove)≤bound (p j) (e j) := by
        unfold bound
        rw [dif_pos (ok.prime j)]
        exact Classical.choose_spec (ih (A*W (p j^e j)) (T*scale (p j) (e j)) (d*Y (p j) (some (e j)))
          (by unfold scale;have:=(ok.prime j).pos;positivity)
          (mul_pos dp (OMA.FixedExponents245212.y_pos (ok.prime j) _))
          ((mul_le_of_le_one_right dp.le (y_one (ok.prime j).one_lt _)).trans ds))
          _ _ rest.1 rest.2
      have member : (p j,e j)∈(range (L+1)).product (range (L+1)) :=
        mem_product.mpr ⟨mem_range.mpr (by omega),mem_range.mpr (by omega)⟩
      have hi : bound (p j) (e j) ≤ maxRest := le_sup (f:=fun k : ℕ×ℕ=>bound k.1 k.2) member
      have pw : p j^e j≤(L+1)^L := (Nat.pow_le_pow_left (pj.trans (Nat.le_succ L)) _).trans
        (Nat.pow_le_pow_right (Nat.succ_pos _) ej)
      rw [total,Fin.prod_univ_succAbove _ j]
      exact Nat.mul_le_mul pw (rule.trans hi)
    · exact ⟨0,fun p e ok eqn=>False.elim (cut (below tp dp ok eqn))⟩

#print axioms bounded
end OMA.CofactorCrossCount245212
