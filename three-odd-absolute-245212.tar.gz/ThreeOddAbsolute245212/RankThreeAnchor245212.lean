import ParityBudget245212

/-! A single bounded odd factor supplying the dyadic excess prevents
resonance with any coprime product of Euler numerators. -/
namespace OMA.RankThreeAnchor245212
open Nat Finset ArithmeticFunction OMA.Smooth245212
open scoped ArithmeticFunction.sigma

private theorem dyadic_weight (k : ℕ) : W (2^k)=k*2^(k+1)+1 := by
  rw [w_pow Nat.prime_two]
  induction k with
  | zero => norm_num
  | succ k ih =>
    rw [sum_range_succ _ (k+1),ih,pow_succ (2:ℕ) (k+1)]
    ring

private theorem weight_unit {r : ℕ} (pr : r.Prime) (a : ℕ) : r.Coprime (W (r^a)) := by
  apply pr.coprime_iff_not_dvd.mpr
  intro dv
  let : Fact r.Prime := ⟨pr⟩
  have zero := (ZMod.natCast_eq_zero_iff (W (r^a)) r).mpr dv
  rw [w_pow pr,sum_range_succ'] at zero
  push_cast at zero
  simp [pow_succ] at zero

theorem high {k r a : ℕ} (hr : 2 ≤ r)
    (hex : k + OMA.WeightVal245212.val (k+1) < OMA.ParityBudget245212.excess a) :
    W (2^k) < r^a := by
  have hv : k+2 ≤ (a+2).factorization 2 := by
    unfold OMA.ParityBudget245212.excess OMA.WeightVal245212.val at hex; omega
  have dv : 2^(k+2) ∣ a+2 := (pow_dvd_pow _ hv).trans (Nat.ordProj_dvd (a+2) 2)
  have bound := Nat.le_of_dvd (by omega : 0 < a+2) dv
  have size (j : ℕ) : 2*j+4 ≤ 2^(j+2) := by
    induction j with
    | zero => decide
    | succ j ih => rw [pow_succ 2 (j+2)]; omega
  have exp : 2*(k+1) ≤ a := by have := size k; omega
  have power := (Nat.pow_le_pow_right (by decide : 0<2) exp).trans (Nat.pow_le_pow_left hr a)
  apply lt_of_lt_of_le _ power
  rw [dyadic_weight,show 2*(k+1)=(k+1)+(k+1) by omega,pow_add 2 (k+1) (k+1)]
  have inc : k+1 < 2^(k+1) := Nat.lt_two_pow_self
  have gap := Nat.mul_le_mul_right (2^(k+1)) inc
  have nz := Nat.two_pow_pos (k+1)
  nlinarith only [gap,nz,inc]

/-- The Euler numerator U may contain any number of other primes. -/
theorem no_resonance {k r a U V : ℕ} (pr : r.Prime) (odd : r≠2)
    (cop : r.Coprime U) (large : W (2^k) < r^a) :
    W (2^k*r^a)*U ≠ 2*(2^k*r^a)*(σ 0 (2^k*r^a))*V := by
  intro eq
  have base := ((Nat.coprime_primes Nat.prime_two pr).mpr odd.symm).pow_left k
  rw [w_mult.map_mul_of_coprime (base.pow_right a),mul_assoc] at eq
  have d : r^a ∣ 2*(2^k*r^a)*(σ 0 (2^k*r^a))*V := by
    exact dvd_mul_of_dvd_left (dvd_mul_of_dvd_left (dvd_mul_of_dvd_right (dvd_mul_left _ _) _) _) _
  have fac := ((weight_unit pr a).mul_right cop).pow_left a
  have divides : r^a ∣ W (2^k) := fac.dvd_of_dvd_mul_right (eq ▸ d)
  have pos : 0 < W (2^k) := by rw [dyadic_weight]; omega
  exact large.not_ge (Nat.le_of_dvd pos divides)

#print axioms high
#print axioms no_resonance
end OMA.RankThreeAnchor245212
