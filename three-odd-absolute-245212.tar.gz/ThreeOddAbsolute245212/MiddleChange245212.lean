import MiddleWitness245212
import LeastTallFactor245212

/-! Exact and one-sided changes on restoring one coordinate, with arbitrary
values of the other two moments already multiplied together. -/
namespace OMA.MiddleChange245212
open Nat Finset ArithmeticFunction OMA.Smooth245212 OMA.TwoTallLocal245212
open OMA.ThreeMovingLocal245212 (xx yy xn yn den)
open scoped ArithmeticFunction.sigma
open private OMA.ThreeMovingLocal245212.quotients from ThreeMovingLocal245212

def inc (p e f g : ℕ) (b : Option Bool) (x y : ℚ) :=
  (f:ℚ)*(X p (some e)-xx' p e b)*x+(g:ℚ)*(Y p (some e)-yy' p e b)*y

theorem exact_inc (p e f g : ℕ) (x y : ℚ) : inc p e f g none x y=0 := by
  simp [inc,xx',yy']

theorem dropped {p e f g : ℕ} (hp : p.Prime) (ep : 0<e) {x y : ℚ} (xo : 1≤x) (yo : 0≤y) :
    (f:ℚ)/(2*p)≤ inc p e f g (some false) x y := by
  have ps : (0:ℚ)<p:=by exact_mod_cast hp.pos
  have B : (0:ℚ)<(e:ℚ)+1:=by positivity
  have low:=OMA.SingleMovingLoss245212.single_lb hp ep
  have low' : 1/(2*(p:ℚ))≤X p (some e)-1 :=
    (div_le_iff₀ (by positivity)).mpr (by linarith only [low])
  have xx : xx' p e (some false)=1:=by simp [xx',OMA.ThreeMovingLocal245212.xx,xn,den,B.ne']
  have yy : yy' p e (some false)=1/((e:ℚ)+1):=by simp [yy',OMA.ThreeMovingLocal245212.yy,yn,den]
  have ys : 1/((e:ℚ)+1)≤Y p (some e):=by
    have id:=y_factor hp e
    have high : (p:ℚ)^e≤σ 1 (p^e):=by
      exact_mod_cast (show p^e ≤ σ 1 (p^e) by rw [sigma_one_apply_prime_pow hp,sum_range_succ];omega)
    apply (div_le_iff₀ B).mpr
    apply le_of_mul_le_mul_right (a:=(p:ℚ)^e) _ (by positivity)
    nlinarith only [id,high]
  rw [inc,xx,yy]
  have dy:=mul_nonneg (mul_nonneg (Nat.cast_nonneg (α:=ℚ) g) (sub_nonneg.mpr ys)) yo
  have dx : (f:ℚ)*(X p (some e)-1)≥f/(2*p):=by
    rw [div_eq_mul_inv,←one_div]
    exact mul_le_mul_of_nonneg_left low' (by positivity)
  nlinarith only [dx,dy,mul_nonneg (mul_nonneg (Nat.cast_nonneg (α:=ℚ) f)
    (le_trans (by positivity) low')) (sub_nonneg.mpr xo)]

theorem retained {p e f g : ℕ} (hp : p.Prime) (x y : ℚ) :
    inc p e f g (some true) x y =
      ((f:ℚ)*x-g*((p:ℚ)-1)*y)/(((e:ℚ)+1)*((p:ℚ)-1)^2*(p:ℚ)^e) := by
  have z:=OMA.ThreeMovingLocal245212.quotients (e:=e) hp
  rw [inc,z.1,z.2]; dsimp [xx',yy'];ring

theorem retained_loss {p e f g : ℕ} (hp : p.Prime) {x y : ℚ} (xo : 0≤x) (yo : y≤1) :
    -(g:ℚ)/(p:ℚ)^e ≤ inc p e f g (some true) x y := by
  have pp : (2:ℚ)≤p:=by exact_mod_cast hp.two_le
  let u:ℚ:=(p:ℚ)-1
  have up : 1≤u:=by dsimp [u];linarith
  have ppw : 0<(p:ℚ)^e:=by positivity
  rw [retained hp]
  change _≤(_-g*u*y)/(((e:ℚ)+1)*u^2*(p:ℚ)^e)
  apply (div_le_div_iff₀ ppw (by positivity)).mpr
  have sz : u ≤ ((e:ℚ)+1)*u^2 := by
    nlinarith only [mul_nonneg (zero_le_one.trans up) (sub_nonneg.mpr up),mul_nonneg (Nat.cast_nonneg (α:=ℚ) e) (sq_nonneg u),up]
  have v := mul_le_mul_of_nonneg_left yo (mul_nonneg (Nat.cast_nonneg (α:=ℚ) g) (by linarith : 0≤u))
  nlinarith only [mul_le_mul_of_nonneg_right v ppw.le,
    mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left sz (Nat.cast_nonneg (α:=ℚ) g)) ppw.le,
    mul_nonneg (mul_nonneg (Nat.cast_nonneg (α:=ℚ) f) xo) ppw.le]

theorem retained_gain {p e f g k L : ℕ} (hp : p.Prime) (hk : 8≤k) (fg : k*g≤f)
    (base : p≤L) (len : e+1≤L) {x y : ℚ} (xo : 1≤x) (yo : 0≤y) (short : y*L≤2) :
    (g:ℚ)/((L:ℚ)^3*(p:ℚ)^e) ≤ inc p e f g (some true) x y := by
  have pp : (1:ℚ)<p:=by exact_mod_cast hp.one_lt
  have lp : (0:ℚ)<L:=by exact_mod_cast (hp.pos.trans_le base)
  let u:ℚ:=(p:ℚ)-1
  have up : 0<u:=by dsimp [u];linarith
  have ub : u≤L:=by
    have v : (p:ℚ)≤L:=by exact_mod_cast base
    dsimp [u];linarith
  have ecap : (e:ℚ)+1≤L:=by exact_mod_cast len
  have dx : ((e:ℚ)+1)*u^2 ≤(L:ℚ)^3:=by
    calc
      _ ≤ (L:ℚ)*(L:ℚ)^2:=mul_le_mul ecap (pow_le_pow_left₀ up.le ub _) (sq_nonneg _) lp.le
      _ = _ := by ring
  have fk : (k:ℚ)*g≤f:=by exact_mod_cast fg
  have k8 : (8:ℚ)≤k:=by exact_mod_cast hk
  have ft : (g:ℚ)≤(f:ℚ)*x-g*u*y:=by
    nlinarith only [mul_le_mul_of_nonneg_left xo (Nat.cast_nonneg (α:=ℚ) f),
      mul_le_mul_of_nonneg_left short (Nat.cast_nonneg (α:=ℚ) g),
      mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right ub yo) (Nat.cast_nonneg (α:=ℚ) g),
      mul_le_mul_of_nonneg_right k8 (Nat.cast_nonneg (α:=ℚ) g),fk,Nat.cast_nonneg (α:=ℚ) g]
  rw [retained hp]
  exact (div_le_div_of_nonneg_left (Nat.cast_nonneg g) (by dsimp [u] at *;positivity)
    (mul_le_mul_of_nonneg_right dx (by positivity))).trans (div_le_div_of_nonneg_right ft (by dsimp [u] at *;positivity))

end OMA.MiddleChange245212
