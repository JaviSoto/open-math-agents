import LargeLastPhysical245212
import LargestPrimeExponent245212

/-! Both error denominators dominate the one unperturbed integer coefficient
when the largest prime has exponent greater than 4(a+b)+31. -/
namespace OMA.LargeLastSize245212
open Nat OMA.LargeLastPhysical245212

theorem sizes {r k d n A S T : ℕ} (r5 : 5≤r) (cap : k<2*r) (short : d+1≤2*k)
    (aA : A≤r^(n+2)) (sA : S≤A) (tA : T≤A) (long : n+10≤d)
    (dyad : r^(n+10)≤2^k) :
    4*(k*A+(u r)*S+(k+1)*A)≤r^d ∧
    4*((k+1)*(A*w r d+T*B r d))≤G k := by
  have r1 : 1≤r:=by omega
  have rr : r*r≥5*r:=Nat.mul_le_mul_right r r5
  have kk : k+1≤r^2 := by rw [sq];omega
  have dcap : d+1≤r^2:=by rw [sq];omega
  have wcap : w r d≤r^4 := by
    dsimp [w,u]
    calc
      _ ≤ r*((d+1)*r) := Nat.mul_le_mul_left _ ((Nat.sub_le _ _).trans (Nat.mul_le_mul_left _ (Nat.sub_le _ _)))
      _ ≤ r*(r^2*r) := Nat.mul_le_mul_left _ (Nat.mul_le_mul_right _ dcap)
      _ = _ := by ring
  have bcap : B r d≤r^4 := by
    dsimp [B,u]
    exact (Nat.mul_le_mul dcap (Nat.pow_le_pow_left (Nat.sub_le _ _) 2)).trans_eq (by ring)
  have up := Nat.mul_le_mul (show u r≤r from Nat.sub_le _ _) (sA.trans aA)
  have ka := Nat.mul_le_mul (by omega : k≤r^2) aA
  have kua := Nat.mul_le_mul kk aA
  have single : r*r^(n+2)≤r^2*r^(n+2) := Nat.mul_le_mul_right _ (Nat.le_self_pow (by decide : 2≠0) _)
  have rmin : 12≤r^2 := (by decide : 12≤5^2).trans (Nat.pow_le_pow_left r5 _)
  have sum : 4*(k*A+(u r)*S+(k+1)*A) ≤ r^(n+6) := by
    calc
      _ ≤ 12*(r^2*r^(n+2)) := by omega
      _ ≤ r^2*(r^2*r^(n+2)) := Nat.mul_le_mul_right _ rmin
      _ = _ := by rw [show n+6=n+2+2+2 by omega,pow_add,pow_add];ring
  have big := Nat.add_le_add (Nat.mul_le_mul aA wcap) (Nat.mul_le_mul (tA.trans aA) bcap)
  have endcap : 4*((k+1)*(A*w r d+T*B r d))≤r^(n+10) := by
    calc
      _ ≤ 4*(r^2*(r^(n+2)*r^4+r^(n+2)*r^4)) := Nat.mul_le_mul_left _ (Nat.mul_le_mul kk big)
      _ = 8*(r^(n+2)*r^4*r^2) := by ring
      _ ≤ r^2*(r^(n+2)*r^4*r^2) := Nat.mul_le_mul_right _ (by omega)
      _ = _ := by rw [show n+10=n+2+8 by omega,pow_add];ring
  dsimp [G]
  rw [pow_succ]
  have g:=Nat.two_pow_pos k
  exact ⟨sum.trans (Nat.pow_le_pow_right r1 (by omega)),by omega⟩

end OMA.LargeLastSize245212
