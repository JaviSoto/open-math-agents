import BoundedAtom245212
import PrimePowerDiv245212
import OddCofactor245212

/-! Finiteness for a fixed dyadic exponent and at most two distinct odd primes. -/
namespace OMA.TwoOddFinite245212
open Nat Finset ArithmeticFunction OMA.Smooth245212
open scoped ArithmeticFunction.sigma

/-- A bound on every odd prime power that can extend this positive cofactor
at equality. The extra one also permits the empty extension. -/
def lastBound (a : ℕ) : ℕ := 1+∑ q∈(W a+σ 1 a).divisors,
  ((W a:ℤ)-((q:ℤ)-1)*(σ 1 a:ℤ)).natAbs

theorem last_power_le {a q f : ℕ} (ha : 0<a) (hq : q.Prime) (odd : q≠2)
    (cop : a.Coprime q) (hf : 0<f) (eq : OeisA245212.a (a*q^f)=(σ 1 (a*q^f):ℤ)) :
    q^f≤lastBound a := by
  have divides := OMA.OddCofactor245212.last_dvd ha hq cop hf eq
  have spos := sigma_pos 1 a ha.ne'
  have member := mem_divisors.mpr ⟨divides,by omega⟩
  have bound := OMA.PrimePowerDiv245212.cofactor_bound ha hq odd cop f eq
  have part := single_le_sum (f:=fun q : ℕ =>
    ((W a:ℤ)-((q:ℤ)-1)*(σ 1 a:ℤ)).natAbs) (fun i _ => Nat.zero_le _) member
  unfold lastBound
  omega

private theorem extend {k m r : ℕ} (om : Odd m) (hr : r∈m.primeFactors)
    (rank : m.primeFactors.card≤2) (eq : OeisA245212.a (2^k*m)=(σ 1 (2^k*m):ℤ)) :
    m≤r^(m.factorization r)*lastBound (2^k*r^(m.factorization r)) := by
  let F := m.primeFactors.erase r
  have card : F.card≤1 := by dsimp [F]; rw [card_erase_of_mem hr]; omega
  have repr : m=r^(m.factorization r)*∏ q∈F,q^(m.factorization q) := by
    calc
      m = ∏ q∈m.primeFactors,q^(m.factorization q) := Nat.prod_primeFactors_pow_factorization om.pos.ne'
      _ = _ := (prod_erase_mul _ _ hr).symm.trans (mul_comm _ _)
  have rpr := prime_of_mem_primeFactors hr
  rcases F.eq_empty_or_nonempty with empty|⟨q,hq⟩
  · rw [empty,prod_empty,mul_one] at repr
    exact repr.trans_le (Nat.le_mul_of_pos_right _ (by unfold lastBound; omega))
  · have singleton : F={q} := by
      ext x
      simpa only [mem_singleton] using
        (show x∈F ↔ x=q from ⟨fun hx => card_le_one.mp card x hx q hq,fun h => h ▸ hq⟩)
    rw [singleton,prod_singleton] at repr
    have qmem := (mem_erase.mp hq).2
    have qp := prime_of_mem_primeFactors qmem
    have qodd := Nat.coprime_two_left.mp
      ((Nat.coprime_two_left.mpr om).of_dvd_right (dvd_of_mem_primeFactors qmem))
    have nottwo : q≠2 := by intro z; rw [z] at qodd; exact (by decide : ¬Odd 2) qodd
    have cb : (2^k*r^(m.factorization r)).Coprime q :=
      ((Nat.coprime_two_left.mpr qodd).pow_left k).mul_left
        (((Nat.coprime_primes rpr qp).mpr (mem_erase.mp hq).1.symm).pow_left _)
    have ep := qp.factorization_pos_of_dvd om.pos.ne' (dvd_of_mem_primeFactors qmem)
    have pos : 0<2^k*r^(m.factorization r) := by have := rpr.pos; positivity
    have target : 2^k*m=2^k*r^(m.factorization r)*q^(m.factorization q) := by
      exact (congrArg (2^k*·) repr).trans (mul_assoc _ _ _).symm
    rw [target] at eq
    exact repr.trans_le (Nat.mul_le_mul_left _ (last_power_le pos qp nottwo cb ep eq))

/-- Both odd primes and their exponents are free; only the power of two is fixed. -/
theorem finite_two (k : ℕ) : {m : ℕ | Odd m ∧ m.primeFactors.card≤2 ∧
    OeisA245212.a (2^k*m)=(σ 1 (2^k*m):ℤ)}.Finite := by
  obtain ⟨B,atom⟩ := OMA.BoundedAtom245212.bounded_atom k 2
  let F := ⋃ r∈Set.Iic B, ⋃ e∈Set.Iic B, Set.Iic (r^e*lastBound (2^k*r^e))
  have fin : F.Finite := (Set.finite_Iic B).biUnion fun r _ =>
    (Set.finite_Iic B).biUnion fun e _ => Set.finite_Iic _
  apply ((OMA.SquareFinite245212.square_finite k 2).union fin).subset
  rintro m ⟨om,rank,eq⟩
  by_cases sq : IsSquare m
  · exact Or.inl ⟨om,sq,rank,eq⟩
  · obtain ⟨r,hr,_,rb,eb⟩ := atom m om sq rank eq
    exact Or.inr (Set.mem_iUnion₂.mpr ⟨r,rb,Set.mem_iUnion₂.mpr
      ⟨m.factorization r,eb,extend om hr rank eq⟩⟩)

#print axioms finite_two
end OMA.TwoOddFinite245212
