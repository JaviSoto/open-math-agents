import SingleMovingHeight245212

/-! The ordinary moments at the other two primes can never reverse the sign
for the smallest base when it carries the longest exponent. -/
namespace OMA.LeastTallFactor245212
open Nat Finset OMA.TwoTallLocal245212 OMA.SingleMovingGap245212
open OMA.Smooth245212 (X Y y_nonneg)
open OMA.ThreeMovingLocal245212 (yy yn den)
open private OMA.ThreeMovingLocal245212.quotients from ThreeMovingLocal245212

theorem localY {p e : ℕ} (hp : p.Prime) (he : 0<e) (big : 33≤p) (mode : Option Bool) :
    yy' p e mode≤33/64 := by
  have pr : (33:ℚ)≤p:=by exact_mod_cast big
  have ep : (1:ℚ)≤e:=by exact_mod_cast he
  have B : (0:ℚ)<(e:ℚ)+1:=by positivity
  have u : (0:ℚ)<(p:ℚ)-1:=by linarith
  have yn : yy p e true = (p:ℚ)/(((e:ℚ)+1)*(p-1)) := by
    dsimp [yy,OMA.ThreeMovingLocal245212.yn,den]
    push_cast [Nat.cast_sub hp.one_le];field_simp
  have yb : yy p e true≤33/64 := by
    rw [yn,div_le_iff₀ (mul_pos B u)]
    nlinarith only [pr,mul_nonneg (sub_nonneg.mpr ep) u.le]
  rcases mode with _|b
  · have q:=(OMA.ThreeMovingLocal245212.quotients (e:=e) hp).2
    change Y p (some e)≤33/64
    have pw : 0< (p:ℚ)^e := by positivity
    have dn : 0≤1/(((e:ℚ)+1)*((p:ℚ)-1)^2*(p:ℚ)^e):=by positivity
    linarith only [q,mul_nonneg u.le dn,yb]
  · cases b
    · change yy p e false≤_
      simp [yy,OMA.ThreeMovingLocal245212.yn,den]
      rw [←one_div];apply (div_le_iff₀ B).mpr;linarith only [ep]
    · exact yb

private theorem localX {z p e : ℕ} (zp : 33≤z) (le : z≤p) (hp : p.Prime) (ep : 0<e) :
    1≤X p (some e) ∧ X p (some e)≤33/32 ∧ ((z:ℚ)-1)*(X p (some e)-1)≤1 := by
  have low : 1≤X p (some e):=(ranges hp ep none).1
  have zlow : (32:ℚ)≤(z:ℚ)-1:=by
    have h : (33:ℚ)≤z:=by exact_mod_cast zp
    linarith
  have v : (z:ℚ)≤p:=by exact_mod_cast le
  have den : (0:ℚ)<(p:ℚ)-1:=by linarith
  have eq : ((p:ℚ)-1)*(X p (some e)-1) = 1-Y p (some e) := by
    dsimp [X];field_simp;ring
  have Y0:=y_nonneg hp.one_lt (some e)
  have h : ((z:ℚ)-1)*(X p (some e)-1)≤1 := by
    nlinarith only [eq,Y0,mul_nonneg (sub_nonneg.mpr v) (sub_nonneg.mpr low)]
  refine ⟨low,?_,h⟩
  nlinarith only [h,mul_nonneg (sub_nonneg.mpr zlow) (sub_nonneg.mpr low)]

theorem margin (c : Family) {f g : ℕ} {v : Fin 3} (long : c.e v+1=c.L)
    (least : ∀i,c.p v≤c.p i) (large : 33≤c.p v) (tall : 32≤c.L) (gp : 0<g)
    (actual : score f g (exactX c) (exactY c)=(f+g:ℕ)) :
    (g:ℚ)*((c.p v:ℚ)-1)*(33/64)^2 < f := by
  let P:=∏i,exactX c i
  let S:=∏i,exactY c i
  let u:ℚ:=(c.p v:ℚ)-1
  have loc i := localX large (least i) (c.prime i) (c.positive i)
  change ∀i, 1≤exactX c i ∧ exactX c i≤33/32 ∧ u*(exactX c i-1)≤1 at loc
  have p0 i := (zero_le_one.trans (loc i).1)
  have Xprod : u*(P-1) ≤ 13/4 := by
    let x:=exactX c
    have a:=mul_le_mul_of_nonneg_right (loc 0).2.2 (mul_nonneg (p0 1) (p0 2))
    have b:=mul_le_mul_of_nonneg_right (loc 1).2.2 (p0 2)
    have d:=mul_le_mul (loc 1).2.1 (loc 2).2.1 (p0 2) (by norm_num : (0:ℚ)≤33/32)
    dsimp only [P];rw [Fin.prod_univ_three]
    nlinarith only [a,b,d,(loc 2).2.2,(loc 2).2.1]
  have nonY i : 0≤exactY c i := (ranges (c.prime i) (c.positive i) none).2.2.1
  have bound i : exactY c i≤1 := (localY (c.prime i) (c.positive i) (large.trans (least i)) none).trans (by norm_num)
  have s := (ranges (c.prime v) (c.positive v) none).2.2.2
  change exactY c v≤2/((c.e v:ℚ)+1) at s
  have T : (32:ℚ)≤(c.e v:ℚ)+1:=by exact_mod_cast (long ▸ tall : 32≤c.e v+1)
  have lowS : S≤1/16 := by
    calc
      _ = (∏ i∈univ.erase v,exactY c i)*exactY c v := (prod_erase_mul _ _ (mem_univ v)).symm
      _ ≤ exactY c v := mul_le_of_le_one_left (nonY v) (prod_le_one (fun j _=>nonY j) (fun j _=>bound j))
      _ ≤ _ := s.trans ((div_le_iff₀ (by positivity)).mpr (by linarith only [T]))
  change (f:ℚ)*P+(g:ℚ)*S=(f+g:ℕ) at actual
  push_cast at actual
  have m : 0≤P-1:=sub_nonneg.mpr (one_le_prod (fun i _=>(loc i).1))
  have g0 : (0:ℚ)<g:=by exact_mod_cast gp
  by_contra! neg
  change (f:ℚ)≤(g:ℚ)*u*(33/64)^2 at neg
  nlinarith only [actual,mul_le_mul_of_nonneg_right neg m,mul_le_mul_of_nonneg_left Xprod g0.le,
    mul_le_mul_of_nonneg_left lowS g0.le,g0]

end OMA.LeastTallFactor245212
