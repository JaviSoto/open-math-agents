import TwoTallFinite245212
import LargeLastOriginal245212

/-! In particular the largest prime can carry the largest exponent only
finitely often. The exponents at the two smaller primes cannot be
linearly comparable in an infinite family either. -/
namespace OMA.TwoTallConsequences245212
open Nat Finset ArithmeticFunction OMA.Smooth245212 OMA.TwoTallFinite245212
open scoped ArithmeticFunction.sigma

private theorem from_order {C k p q r a b d m L : ℕ} (pp : p.Prime) (qp : q.Prime) (rp : r.Prime)
    (op : Odd p) (oq : Odd q) (or' : Odd r) (pq : p≠q) (pr : p≠r) (qr : q≠r)
    (ap : 0<a) (bp : 0<b) (dp : 0<d) (hm : 0 < m) (lo : m≤a+1 ∧ m≤b+1)
    (hi : a+1≤L ∧ b+1≤L ∧ d+1≤L) (width : L≤C*m)
    (eqn : OeisA245212.a (2^k*p^a*q^b*r^d)=(σ 1 (2^k*p^a*q^b*r^d):ℤ)) :
    2^k*p^a*q^b*r^d ≤ valueCap C := by
  let P : Fin 3→ℕ:=![p,q,r]
  let E : Fin 3→ℕ:=![a,b,d]
  have prime (i) : (P i).Prime:=by fin_cases i <;> simp [P,pp,qp,rp]
  have odd (i) : Odd (P i):=by fin_cases i <;> simp [P,op,oq,or']
  have inj : P.Injective:=by intro i j h;fin_cases i <;> fin_cases j <;> simp_all [P]
  have pos (i):0<E i:=by fin_cases i <;> simpa [E] using (show 0<_ by first | exact ap | exact bp | exact dp)
  have lon (i) (ne:i≠2) : m≤E i+1:=by fin_cases i <;> simp [E] at * <;> omega
  have cap (i):E i+1≤L := by fin_cases i <;> simp [E] <;> omega
  have repr : 2^k*total P E=2^k*p^a*q^b*r^d := by simp [total,Fin.prod_univ_three,P,E,mul_assoc]
  have result:=bounded P E prime odd inj pos hm lon cap width (by rw [repr];exact eqn)
  rwa [repr] at result

theorem lower_comparable {C k p q r a b d : ℕ} (pp : p.Prime) (qp : q.Prime) (rp : r.Prime)
    (p3 : 3≤p) (pq : p<q) (qr : q<r) (ap : 0<a) (bp : 0<b) (dp : 0<d)
    (width : max (a+1) (b+1) ≤ C*min (a+1) (b+1))
    (eqn : OeisA245212.a (2^k*p^a*q^b*r^d)=(σ 1 (2^k*p^a*q^b*r^d):ℤ)) :
    2^k*p^a*q^b*r^d ≤ valueCap (20*C) := by
  have ld:=OMA.LargeLastOriginal245212.largest pp qp rp p3 pq qr ap bp dp eqn
  let t:=max (a+1) (b+1)
  apply from_order pp qp rp (pp.odd_of_ne_two (by omega)) (qp.odd_of_ne_two (by omega))
    (rp.odd_of_ne_two (by omega)) pq.ne (pq.trans qr).ne qr.ne ap bp dp
    (m:=min (a+1) (b+1)) (L:=20*t) (by omega) ⟨min_le_left ..,min_le_right ..⟩
    (by dsimp [t];omega) _ eqn
  simpa only [Nat.mul_assoc] using Nat.mul_le_mul_left 20 width

theorem largest_at_largest {k p q r a b d : ℕ} (pp : p.Prime) (qp : q.Prime) (rp : r.Prime)
    (p3 : 3≤p) (pq : p<q) (qr : q<r) (ap : 0<a) (bp : 0<b) (dp : 0<d)
    (big : max a b≤d)
    (eqn : OeisA245212.a (2^k*p^a*q^b*r^d)=(σ 1 (2^k*p^a*q^b*r^d):ℤ)) :
    2^k*p^a*q^b*r^d ≤ valueCap 20 := by
  have ld:=OMA.LargeLastOriginal245212.largest pp qp rp p3 pq qr ap bp dp eqn
  have op:=pp.odd_of_ne_two (by omega)
  have oq:=qp.odd_of_ne_two (by omega)
  have or':=rp.odd_of_ne_two (by omega)
  by_cases ab : a≤b
  · have out:=from_order (C:=20) (k:=k) (a:=b) (b:=d) (d:=a) qp rp pp oq or' op qr.ne pq.ne.symm
      (pq.trans qr).ne.symm bp dp ap (m:=b+1) (L:=d+1) (by omega) (by omega) (by omega)
      (by omega) (by simpa only [mul_comm,mul_assoc,mul_left_comm] using eqn)
    simpa only [mul_comm,mul_assoc,mul_left_comm] using out
  · have out:=from_order (C:=20) (k:=k) (a:=a) (b:=d) (d:=b) pp rp qp op or' oq (pq.trans qr).ne
      pq.ne qr.ne.symm ap dp bp (m:=a+1) (L:=d+1) (by omega) (by omega) (by omega)
      (by omega) (by simpa only [mul_comm,mul_assoc,mul_left_comm] using eqn)
    simpa only [mul_comm,mul_assoc,mul_left_comm] using out

end OMA.TwoTallConsequences245212
