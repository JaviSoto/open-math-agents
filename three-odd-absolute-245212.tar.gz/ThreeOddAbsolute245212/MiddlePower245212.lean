import LeastTallScale245212

/-! A retained short right-hand power cannot offset the loss at the unique
long coordinate, whether the middle base is larger or smaller than sqrt L. -/
namespace OMA.MiddlePower245212
open Nat

theorem left {L q a b : ℕ} (qp : 2≤q) (head : L^6 < q^b) (sep : 2*a≤b) :
    L^3*q^a<q^b := by
  apply (pow_lt_pow_iff_left₀ (Nat.zero_le _) (Nat.zero_le _) (by decide : 2≠0)).mp
  calc
    (L^3*q^a)^2 = L^6*q^(2*a) := by rw [mul_pow,←pow_mul,←pow_mul,mul_comm a 2]
    _ < q^b*q^b := Nat.mul_lt_mul_of_lt_of_le head (Nat.pow_le_pow_right (by omega) sep) (pow_pos (by omega) _)
    _ = (q^b)^2 := (sq _).symm

theorem right {k L q r b d : ℕ} (k0 : 256≤k) (q0 : 2≤q) (rb : r≤L)
    (slope : k*(d+1)<4*q) (sep : 16*(d+1)<b+1) (long : b+1=L) :
    L^3*r^d<q^b := by
  have qp : 1≤q:=by omega
  have high : L^3*r^d≤L^(d+3):=by
    rw [pow_add,mul_comm (L^d)]
    exact Nat.mul_le_mul_left _ (Nat.pow_le_pow_left rb d)
  apply high.trans_lt
  by_cases near : L≤q^2
  · calc
      _ ≤ (q^2)^(d+3) := Nat.pow_le_pow_left near _
      _ = q^(2*(d+3)) := (pow_mul ..).symm
      _ < _ := Nat.pow_lt_pow_right (by omega) (by omega)
  · have qle : 4*(d+4)≤q:=by
      have := Nat.mul_le_mul_right (d+1) k0
      omega
    have h0 : 16*((d+3)+1)^2≤L:=by
      have h:=Nat.pow_le_pow_left qle 2
      nlinarith only [h,Nat.lt_of_not_ge near]
    have grow := OMA.ComplementarySize245212.absorb (b:=L) (d:=d+3) h0
    apply (pow_lt_pow_iff_left₀ (Nat.zero_le _) (Nat.zero_le _) (by decide : 2≠0)).mp
    calc
      _ = L^(2*(d+3)):=by rw [mul_comm 2 (d+3),pow_mul]
      _ ≤ 2^L:=grow
      _ ≤ q^L:=Nat.pow_le_pow_left q0 _
      _ < q^(b*2):=Nat.pow_lt_pow_right (by omega) (by omega)
      _ = _ := pow_mul .. 

end OMA.MiddlePower245212
