import LeastTallStep245212
import LeastTallScale245212
import TwoTallFinite245212

/-! Effective absolute finiteness when the smallest odd prime carries a
largest exponent: all primes, all exponents and the dyadic exponent may move. -/
namespace OMA.LeastTallOriginal245212
open Nat Finset ArithmeticFunction OMA.SingleMovingGap245212
open OMA.Smooth245212 (total)
open OMA.ThreeMovingOriginal245212 (F G)
open OMA.SingleMovingStep245212 (degree)
open OMA.SingleMovingHeight245212 (constant)
open private OMA.SingleMovingOriginal245212.identities from SingleMovingOriginal245212
open scoped ArithmeticFunction.sigma

private theorem out (c : Family) {C E : ℕ} (wide : 2^c.k≤C*(c.L+1)^E)
    (long : c.e 0+1=c.L) (least : ∀i,c.p 0≤c.p i) (large : 33≤c.p 0)
    (op : ∀i,Odd (c.p i))
    (eqn : OeisA245212.a (2^c.k*total c.p c.e)=(σ 1 (2^c.k*total c.p c.e):ℤ)) :
    c.L < OMA.LeastTallScale245212.cutoff C E degree := by
  by_contra! big
  let f:=F c.k
  let g:=G c.k
  let x:=128*(f+g+1)*(c.L+1)
  have tg:=OMA.SingleMovingOriginal245212.identities c.k
  have actual:=OMA.SingleMovingOriginal245212.physical c c.k op c.inj eqn
  have pwr:=OMA.LeastTallScale245212.scale wide big (c.prime 0).two_le long
  have h32 : 32≤c.L := by
    apply le_trans _ big
    exact (Nat.le_add_left 64 _).trans' (by decide : 32≤64)
  apply OMA.LeastTallStep245212.contradiction c f g x _ _ _ _ pwr
    (by rw [actual,sub_self,abs_zero];positivity)
  · dsimp only [x];nlinarith only [Nat.zero_le ((f+g)*c.L),Nat.zero_le (f+g),Nat.zero_le c.L]
  · dsimp only [x];nlinarith only [Nat.zero_le ((f+g)*c.L),Nat.zero_le (f+g),Nat.zero_le c.L]
  · dsimp only [x];nlinarith only [Nat.zero_le ((f+g)*c.L),Nat.zero_le (f+g),Nat.zero_le c.L]
  · intro b moving hit
    have unit i : ¬c.p i∣2^(c.k+1):=by
      intro dvd
      have d:=(c.prime i).dvd_of_dvd_pow dvd
      exact (Nat.not_dvd_of_pos_of_lt (by decide) (by have:=large.trans (least i);omega : 2<c.p i)) d
    have retained := OMA.SingleMovingGap245212.retained tg.2.1 unit hit
    have less:=(OMA.LeastTallStrict245212.descend c b f g tg.1 (by have:=tg.2.2;dsimp [f,g];omega)
      long least large h32 moving retained actual).trans_le actual.le
    have val := clear c b f g
    have same : ((f+g:ℕ):ℚ)*dust c b=((f*NX c b+g*NY c b:ℕ):ℚ) := by exact_mod_cast hit
    exact (ne_of_lt (mul_lt_mul_of_pos_right less (show (0:ℚ)<dust c b by exact_mod_cast dust_pos c b))) (val.trans same.symm)

def value (C E : ℕ) := (∑ j∈range 67, OMA.RankThreeEffective245212.bound j)+
  OMA.TwoTallFinite245212.valueCap (OMA.LeastTallScale245212.cutoff C E degree)

private theorem sector (C E k : ℕ) (p e : Fin 3→ℕ) (hp : ∀i,(p i).Prime) (op : ∀i,Odd (p i)) (inj : p.Injective)
    (he : ∀i,0<e i) (least : ∀i,p 0≤p i) (long : ∀i,e i≤e 0)
    (power : 2^k≤C*(e 0+2)^E)
    (eqn : OeisA245212.a (2^k*total p e)=(σ 1 (2^k*total p e):ℤ)) :
    2^k*total p e≤value C E := by
  classical
  have odd : Odd (total p e) := Nat.coprime_two_left.mp
    (Coprime.prod_right (fun i _ => (Nat.coprime_two_left.mpr (op i)).pow_right _))
  have dvd i : p i∣total p e := (dvd_pow_self _ (he i).ne').trans
    (dvd_prod_of_mem (fun j => p j^e j) (mem_univ i))
  have big : 1<total p e := (hp 0).one_lt.trans_le (Nat.le_of_dvd odd.pos (dvd 0))
  have image : (total p e).primeFactors=univ.image p := by
    ext q
    constructor
    · intro mem
      have pr:=prime_of_mem_primeFactors mem
      obtain ⟨i,_,di⟩:=(pr.prime.dvd_finsetProd_iff _).mp (dvd_of_mem_primeFactors mem :
        q∣∏i,p i^e i)
      exact mem_image.mpr ⟨i,mem_univ _,((prime_dvd_prime_iff_eq pr (hp i)).mp (pr.dvd_of_dvd_pow di)).symm⟩
    · rintro mem
      obtain ⟨i,_,rfl⟩:=mem_image.mp mem
      exact mem_primeFactors.mpr ⟨hp i,dvd i,odd.pos.ne'⟩
  by_cases low : k≤66
  · have rk : (total p e).primeFactors.card=3:=by rw [image,card_image_of_injective _ inj];simp
    have sz:=OMA.RankThreeEffective245212.original odd rk eqn
    exact sz.trans ((single_le_sum (f:=OMA.RankThreeEffective245212.bound) (fun _ _=>Nat.zero_le _)
      (mem_range.mpr (show k<67 by omega))).trans (Nat.le_add_right _ _))
  have k0:=OMA.DyadicLeast245212.exponent_lt_twice_prime odd (mem_primeFactors.mpr ⟨hp 0,dvd 0,odd.pos.ne'⟩) eqn
  let L := e 0+1
  have lengths i : e i+1≤L:=Nat.succ_le_succ (long i)
  let c : Family := ⟨p,e,k,L,hp,he,by omega,⟨0,rfl⟩,lengths,inj⟩
  have high : L<OMA.LeastTallScale245212.cutoff C E degree := out c power rfl least (by change 33≤p 0;omega) op eqn
  have sm:=OMA.TwoTallFinite245212.bounded (c:=OMA.LeastTallScale245212.cutoff C E degree) (m:=1) (L:=L) p e hp op inj he (by decide)
    (fun _ _=>Nat.succ_pos _) lengths (high.le.trans_eq (Nat.mul_one _).symm) eqn
  exact sm.trans (Nat.le_add_left _ _)

def bound := value (constant degree) (2*degree)

theorem original (k : ℕ) (p e : Fin 3→ℕ) (hp : ∀i,(p i).Prime) (op : ∀i,Odd (p i)) (inj : p.Injective)
    (he : ∀i,0<e i) (least : ∀i,p 0≤p i) (long : ∀i,e i≤e 0)
    (eqn : OeisA245212.a (2^k*total p e)=(σ 1 (2^k*total p e):ℤ)) :
    2^k*total p e≤bound := by
  apply sector _ _ k p e hp op inj he least long _ eqn
  exact OMA.SingleMovingHeight245212.original k (e 0+1) p e hp op inj he ⟨0,rfl⟩
    (fun i=>Nat.succ_le_succ (long i)) eqn

end OMA.LeastTallOriginal245212
