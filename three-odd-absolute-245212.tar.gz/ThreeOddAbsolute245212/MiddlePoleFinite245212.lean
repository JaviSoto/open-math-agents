import MiddlePoleOriginal245212
import ComplementarySize245212

/-! Close the mixed branch: logarithmically bounded small exponents can
never support an unbounded middle exponent. All bounds are Nat terms. -/
namespace OMA.MiddlePoleFinite245212
open OMA.PositiveBilinearGap245212 OMA.MiddlePoleOriginal245212

def cutoff (D : ℕ) :=
  let j:=82*D
  (8*(16*(j+1)^2+68+6*j))^81

theorem cost_bound {k p a : ℕ} (small : p≤32+4*(k+1)) :
    16*(K k p a)^5≤(8*(k+a+34))^81 := by
  let X:=8*(k+a+34)
  have big : 16≤X:=by dsimp [X];omega
  have xp : p≤X:=by dsimp [X];omega
  have xa : a+1≤X:=by dsimp [X];omega
  have xk : k+2≤X:=by dsimp [X];omega
  have xle : X≤X^3:=by simpa only [pow_one] using Nat.pow_le_pow_right (by omega : 0<X) (by decide : 1≤3)
  have xl : p-1≤X:=by omega
  have g : p*((a+1)*(p-1)-1)≤X^3:=calc
    _ ≤ X*(X*X) := Nat.mul_le_mul xp ((Nat.sub_le _ _).trans (Nat.mul_le_mul xa xl))
    _ = _ := by ring
  have coeff : 4*(k+p*((a+1)*(p-1)-1)+1+1)+1≤X^4:=by
    have nine:=Nat.mul_le_mul_right (X^3) (show 9≤X by omega)
    have pos:=Nat.one_le_pow 3 X (by omega)
    rw [pow_succ X 3]
    nlinarith only [xk,xle,g,nine,pos,Nat.zero_le (X^3)]
  have core : K k p a≤X^16:=by
    unfold K cost
    calc
      _ ≤ ((X*X)*X^2)*(X^4)^3 :=
        Nat.mul_le_mul (Nat.mul_le_mul (Nat.mul_le_mul (by omega) xa) (Nat.pow_le_pow_left xl _))
          (Nat.pow_le_pow_left coeff _)
      _ = _ := by rw [←pow_mul,←sq,←pow_add,←pow_add]
  change 16*(K k p a)^5≤X^81
  exact (Nat.mul_le_mul big (Nat.pow_le_pow_left core 5)).trans_eq
    (by rw [←pow_mul,mul_comm,pow_succ X 80])

theorem bounded {k p a B D : ℕ} (pr : 2≤p) (small : p≤32+4*(k+1))
    (poly : B≤16*(K k p a)^5) (little : 2^k*p^a≤(B+1)^D) : B≤cutoff D := by
  let n:=k+a+34
  let X:=8*n
  let j:=82*D
  have large : 16≤X:=by dsimp [X,n];omega
  have bnd : B≤X^81:=poly.trans (cost_bound small)
  have plus : B+1≤X^82:=by
    have pos : 0<X^81:=pow_pos (by omega) _
    have dbl:=Nat.mul_le_mul_left (X^81) (show 2≤X by omega)
    rw [show (82:ℕ)=81+1 by decide,pow_succ]
    omega
  have raw : 2^(k+a)≤X^j:=calc
    _ = 2^k*2^a := pow_add .. 
    _ ≤ 2^k*p^a := Nat.mul_le_mul_left _ (Nat.pow_le_pow_left pr _)
    _ ≤ (B+1)^D := little
    _ ≤ (X^82)^D := Nat.pow_le_pow_left plus _
    _ = X^j := (pow_mul ..).symm
  have nbound : n≤16*(j+1)^2+68+6*j:=by
    by_cases high : 16*(j+1)^2≤n
    · have abs:=OMA.ComplementarySize245212.absorb high
      have sq:=Nat.pow_le_pow_left raw 2
      have dbl : 2^(2*(k+a))≤2^(6*j)*n^(2*j):=by
        dsimp only [X] at sq
        have form : ((8*n)^j)^2=2^(6*j)*n^(2*j):=by
          rw [←pow_mul,mul_pow,show (8:ℕ)=2^3 by decide,←pow_mul]
          rw [show 3*(j*2)=6*j by ring,show j*2=2*j by ring]
        simpa only [form,←pow_mul,Nat.mul_comm (k+a) 2] using sq
      have join : 2^(2*(k+a))≤2^(6*j+n):=by
        rw [pow_add]
        exact dbl.trans (Nat.mul_le_mul_left _ abs)
      have ex:=(pow_le_pow_iff_right₀ (a:=(2:ℕ)) (by decide)).mp join
      dsimp only [n] at ex ⊢
      omega
    · omega
  exact bnd.trans (Nat.pow_le_pow_left (Nat.mul_le_mul_left 8 nbound) 81)

#print axioms bounded
end OMA.MiddlePoleFinite245212
