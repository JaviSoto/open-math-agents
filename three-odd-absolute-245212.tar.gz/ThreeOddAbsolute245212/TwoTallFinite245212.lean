import TwoTallOriginal245212
import ThreeMovingDividend245212
import RankThreeEffective245212

/-! Effective whole-integer height whenever two out of three exponent
lengths are within a fixed multiplicative factor of the longest. -/
namespace OMA.TwoTallFinite245212
open Nat Finset ArithmeticFunction OMA.Smooth245212 OMA.TwoTallScalar245212
open scoped ArithmeticFunction.sigma Function

def divisorCap (c : ℕ) := (c*minimumCut)^3
def valueCap (c : ℕ) :=
  (∑ j∈range (4*c+1),OMA.RankThreeEffective245212.bound j) +
  ∑ t∈range (divisorCap c+1),2^OMA.DivisorHeight245212.exponentLimit t*OMA.DivisorHeight245212.coreLimit t

theorem bounded {c k m L : ℕ} (p e : Fin 3→ℕ) (hp : ∀i,(p i).Prime) (op : ∀i,Odd (p i)) (inj : p.Injective)
    (he : ∀i,0<e i) (hm : 0 < m) (long : ∀i,i≠2 → m≤e i+1) (cap : ∀i,e i+1≤L)
    (width : L≤c*m)
    (eqn : OeisA245212.a (2^k*total p e)=(σ 1 (2^k*total p e):ℤ)) :
    2^k*total p e≤valueCap c := by
  classical
  have odd : Odd (total p e) := Nat.coprime_two_left.mp
    (Coprime.prod_right (fun i _ => (Nat.coprime_two_left.mpr (op i)).pow_right _))
  have dvd i : p i∣total p e := (dvd_pow_self _ (he i).ne').trans
    (dvd_prod_of_mem (fun j => p j^e j) (mem_univ i))
  have big : 1<total p e := (hp 0).one_lt.trans_le (Nat.le_of_dvd odd.pos (dvd 0))
  have image : (total p e).primeFactors=univ.image p := by
    ext q
    constructor
    · intro mem
      have pr:=prime_of_mem_primeFactors mem
      obtain ⟨i,_,di⟩:=(pr.prime.dvd_finsetProd_iff _).mp (dvd_of_mem_primeFactors mem :
        q∣∏i,p i^e i)
      exact mem_image.mpr ⟨i,mem_univ _,((prime_dvd_prime_iff_eq pr (hp i)).mp (pr.dvd_of_dvd_pow di)).symm⟩
    · rintro mem
      obtain ⟨i,_,rfl⟩:=mem_image.mp mem
      exact mem_primeFactors.mpr ⟨hp i,dvd i,odd.pos.ne'⟩
  by_cases sk : k≤4*c
  · have rank : (total p e).primeFactors.card=3:=by rw [image,card_image_of_injective _ inj];simp
    have one:=OMA.RankThreeEffective245212.original odd rank eqn
    have sm:=single_le_sum (f:=OMA.RankThreeEffective245212.bound) (fun _ _=>Nat.zero_le _)
      (mem_range.mpr (show k<4*c+1 by omega))
    dsimp only [valueCap];omega
  have kp : 0<k:=by omega
  have small : m≤ minimumCut := by
    by_cases tiny : m≤4
    · exact tiny.trans (by decide)
    have comp : 4*max k L < k*m := by
      rw [mul_max_of_nonneg _ _ (by decide : (0:ℕ)≤4)]
      apply max_lt
      · calc
          4*k=k*4:=by ring
          _ < k*m:=Nat.mul_lt_mul_of_pos_left (by omega) kp
      · calc
          4*L ≤ 4*(c*m):=Nat.mul_le_mul_left _ width
          _ = (4*c)*m:=by ring
          _ < k*m:=Nat.mul_lt_mul_of_pos_right (by omega) hm
    exact (OMA.TwoTallOriginal245212.shortest p e hp op inj he kp hm long cap comp eqn).le
  have pair : (↑(univ : Finset (Fin 3)) : Set (Fin 3)).Pairwise
      (Nat.Coprime on (fun i => p i^e i)) := by
    intro i _ j _ ne
    exact (((Nat.coprime_primes (hp i) (hp j)).mpr (inj.ne ne)).pow_left _).pow_right _
  have count : (total p e).divisors.card=∏i,(e i+1) := by
    rw [←sigma_zero_apply]
    simpa [total,sigma_zero_apply_prime_pow (hp _)] using
      IsMultiplicative.map_prod (fun i => p i^e i) (isMultiplicative_sigma (k:=0)) univ pair
  have lc : L≤c*minimumCut:=width.trans (Nat.mul_le_mul_left _ small)
  have tc : (total p e).divisors.card≤divisorCap c := by
    rw [count]
    calc
      _ ≤ ∏_i : Fin 3,c*minimumCut := prod_le_prod' (fun i _=>(cap i).trans lc)
      _ = _ := by simp [divisorCap]
  have ⟨ke,co⟩:=OMA.DivisorHeight245212.effective_box odd big eqn
  have h:= (Nat.mul_le_mul (Nat.pow_le_pow_right (by decide : 0<2) ke.le) co).trans
    (single_le_sum (f:=fun t=>2^OMA.DivisorHeight245212.exponentLimit t*OMA.DivisorHeight245212.coreLimit t)
      (fun _ _=>Nat.zero_le _) (mem_range.mpr (Nat.lt_succ_of_le tc)))
  exact h.trans (Nat.le_add_left _ _)

end OMA.TwoTallFinite245212
