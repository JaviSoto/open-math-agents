import MiddleChange245212

/-! Telescope the three changes in the order: middle prime, left prime, right prime. -/
namespace OMA.MiddleOrder245212
open Nat Finset OMA.SingleMovingGap245212 OMA.TwoTallLocal245212 OMA.MiddleChange245212

def others (exact approx : Fin 3→ℚ) (i : Fin 3) :=
  if i=1 then approx 0*approx 2 else if i=0 then exact 1*approx 2 else exact 0*exact 1

def otherX (c : Family) (b : Fin 3→Option Bool) := others (exactX c) (x' c b)
def otherY (c : Family) (b : Fin 3→Option Bool) := others (exactY c) (y' c b)
def change (c : Family) (b : Fin 3→Option Bool) (f g : ℕ) (i : Fin 3) :=
  inc (c.p i) (c.e i) f g (b i) (otherX c b i) (otherY c b i)

theorem zero_sum (c : Family) (b : Fin 3→Option Bool) (f g : ℕ)
    (hit : (f+g)*dust c b=f*NX c b+g*NY c b)
    (actual : score f g (exactX c) (exactY c)=(f+g:ℕ)) :
    change c b f g 1+change c b f g 0+change c b f g 2=0 := by
  have clr:=clear c b f g
  rw [←hit] at clr
  push_cast at clr
  have dp : (0:ℚ)<dust c b:=by exact_mod_cast dust_pos c b
  have tgt := mul_right_cancel₀ dp.ne' clr
  have eq : score f g (exactX c) (exactY c)=score f g (x' c b) (y' c b):=by
    rw [actual,tgt];push_cast;rfl
  dsimp [score] at eq
  simp only [Fin.prod_univ_three] at eq
  simp [change,otherX,otherY,others,inc,exactX,exactY,x',y'] at *
  linarith only [eq]

theorem other_bounds (c : Family) (b : Fin 3→Option Bool) (i : Fin 3) :
    1≤otherX c b i ∧ 0≤otherY c b i ∧ otherY c b i≤1 := by
  have loc (j : Fin 3) (mode) := ranges (c.prime j) (c.positive j) mode
  have one (j : Fin 3) (mode) : yy' (c.p j) (c.e j) mode≤1 := (loc j mode).2.2.2.trans
    ((div_le_iff₀ (by positivity)).mpr (by
      have e : (1:ℚ)≤c.e j:=by exact_mod_cast c.positive j
      linarith))
  have box (j l : Fin 3) (v w : Option Bool) :
    1≤xx' (c.p j) (c.e j) v*xx' (c.p l) (c.e l) w ∧
    0≤yy' (c.p j) (c.e j) v*yy' (c.p l) (c.e l) w ∧
    yy' (c.p j) (c.e j) v*yy' (c.p l) (c.e l) w≤1 :=
      ⟨one_le_mul_of_one_le_of_one_le (loc j v).1 (loc l w).1,
       mul_nonneg (loc j v).2.2.1 (loc l w).2.2.1,mul_le_one₀ (one j v) (loc l w).2.2.1 (one l w)⟩
  fin_cases i
  · exact box 1 2 none (b 2)
  · exact box 0 2 (b 0) (b 2)
  · exact box 0 1 none none

theorem shortY (c : Family) (b : Fin 3→Option Bool) (long : c.e 1+1=c.L)
    {i : Fin 3} (short : i≠1) : otherY c b i*c.L≤2 := by
  have range0 (j : Fin 3) (m) := ranges (c.prime j) (c.positive j) m
  have one j m : yy' (c.p j) (c.e j) m≤1:=(range0 j m).2.2.2.trans
    ((div_le_iff₀ (by positivity)).mpr (by
      have ep : (1:ℚ)≤c.e j:=by exact_mod_cast c.positive j
      linarith))
  have up := (le_div_iff₀ (by positivity)).mp (range0 1 none).2.2.2
  have L : (c.L:ℚ)=c.e 1+1:=by exact_mod_cast long.symm
  rw [←L] at up
  have go j m : (yy' (c.p 1) (c.e 1) none*yy' (c.p j) (c.e j) m)*c.L≤2 := by
    have h:=mul_le_mul_of_nonneg_left (one j m) (range0 1 none).2.2.1
    exact (mul_le_mul_of_nonneg_right (by simpa using h) (Nat.cast_nonneg c.L)).trans up
  by_cases zero : i=0
  · subst i;exact go 2 (b 2)
  · have two:i=2:=by omega
    subst i
    simpa [otherY,others,y',exactY,yy',mul_comm] using go 0 none

theorem short_nonneg (c : Family) (b : Fin 3→Option Bool) {f g : ℕ} (gp : 0<g) (fg : c.k*g≤f)
    (long : c.e 1+1=c.L) (bound : ∀i,b i=some true → c.p i≤c.L) {i : Fin 3} (short : i≠1) :
    0≤change c b f g i ∧ (b i≠none → 0<change c b f g i) := by
  have v:=other_bounds c b i
  have fp : 0<f:=(Nat.mul_pos (by have:=c.kp;omega) gp).trans_le fg
  cases mode:b i with
  | none=>simp [change,mode,exact_inc]
  | some tag=>
    have positive : 0<change c b f g i := by
      cases tag
      · have h:=dropped (f:=f) (g:=g) (c.prime i) (c.positive i) v.1 v.2.1
        change 0< inc _ _ _ _ _ _ _
        rw [mode]
        exact (by have:=(c.prime i).pos;positivity : (0:ℚ)<f/(2*(c.p i:ℚ))).trans_le h
      · have h:=retained_gain (g:=g) (c.prime i) c.kp fg (bound i mode) (c.cap i) v.1 v.2.1 (shortY c b long short)
        change 0< inc _ _ _ _ _ _ _
        rw [mode]
        have lm:=c.cap i
        have cp:=(c.prime i).pos
        have lp : 0<c.L:=by omega
        exact (by positivity : (0:ℚ)<g/((c.L:ℚ)^3*(c.p i:ℚ)^(c.e i))).trans_le h
    exact ⟨positive.le,fun _=>positive⟩

end OMA.MiddleOrder245212
