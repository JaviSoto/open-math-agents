import MiddleOrder245212
import MiddlePower245212

/-! The only possible mixed score has an exact left power, a retained
middle base, and a discarded right base. -/
namespace OMA.MiddleModes245212
open Nat Finset OMA.SingleMovingGap245212 OMA.TwoTallLocal245212
open OMA.MiddleChange245212 (inc)
open OMA.MiddleOrder245212

private theorem risk {c : Family} {b : Fin 3→Option Bool} {f g : ℕ} (gp : 0<g) (fg : c.k*g≤f)
    (negative : (f:ℚ)*otherX c b 1 < (g:ℚ)*((c.p 1:ℚ)-1)*otherY c b 1) :
    c.k*(c.e 2+1)<4*c.p 1 := by
  let u:ℚ:=(c.p 1:ℚ)-1
  have v:=other_bounds c b 1
  have fk : (c.k:ℚ)*g≤f:=by exact_mod_cast fg
  have g0 : (0:ℚ)<g:=by exact_mod_cast gp
  have lim : (c.k:ℚ)<u*otherY c b 1 := by
    apply lt_of_mul_lt_mul_right (a:=(g:ℚ)) _ g0.le
    nlinarith only [negative,mul_le_mul_of_nonneg_left v.1 (Nat.cast_nonneg (α:=ℚ) f),fk]
  have range0 j := ranges (c.prime j) (c.positive j) (b j)
  have one : y' c b 0≤1:=(range0 0).2.2.2.trans ((div_le_iff₀ (by positivity)).mpr (by
    have ep : (1:ℚ)≤c.e 0:=by exact_mod_cast c.positive 0
    linarith))
  have up := (le_div_iff₀ (by positivity)).mp (range0 2).2.2.2
  change y' c b 2*((c.e 2:ℚ)+1)≤2 at up
  have prod : otherY c b 1*((c.e 2:ℚ)+1)≤2 := by
    change (y' c b 0*y' c b 2)*_≤2
    have z:=mul_le_mul_of_nonneg_right one (range0 2).2.2.1
    change y' c b 0*y' c b 2≤1*y' c b 2 at z
    nlinarith only [up,mul_le_mul_of_nonneg_right z (by positivity : 0≤(c.e 2:ℚ)+1)]
  have pp := c.prime 1
  have pos : (1:ℚ)<c.p 1:=by exact_mod_cast pp.one_lt
  have pp' : (0:ℚ)≤u:=by dsimp [u];linarith
  exact_mod_cast (show (c.k:ℚ)*((c.e 2:ℚ)+1)<4*(c.p 1:ℚ) by
    have w := mul_lt_mul_of_pos_right lim (by positivity : 0<(c.e 2:ℚ)+1)
    have h:=mul_le_mul_of_nonneg_left prod pp'
    dsimp [u] at w h; nlinarith only [w,h,pos])

theorem force (c : Family) (b : Fin 3→Option Bool) {f g Q : ℕ} (gp : 0<g) (fg : c.k*g≤f)
    (long : c.e 1+1=c.L) (k0 : 256≤c.k) (smallK : c.k+1≤c.L)
    (pq : c.p 0<c.p 1) (sep0 : 2*c.e 0≤c.e 1) (sep2 : 16*(c.e 2+1)<c.e 1+1)
    (power : c.L^6<c.p 1^c.e 1) (cut :Q<c.p 1^c.e 1) (cover : c.L≤Q)
    (rule : ∀i,b i=if c.p i^c.e i≤Q then none else some (decide (c.p i≤Q)))
    (notboth : ¬(b 0=none ∧ b 2=none))
    (small : ∀i,b i=some true → c.p i≤ max (c.k+1) c.L)
    (hit : (f+g)*dust c b=f*NX c b+g*NY c b)
    (actual : score f g (exactX c) (exactY c)=(f+g:ℕ)) :
    b 0=none ∧ b 1=some true ∧ b 2=some false ∧
    (f:ℚ)*(x' c b 0*x' c b 2)<(g:ℚ)*((c.p 1:ℚ)-1)*(y' c b 0*y' c b 2) := by
  have bounds (i : Fin 3) (h : b i=some true) : c.p i≤c.L:=by simpa [max_eq_right smallK] using small i h
  have nonneg {i : Fin 3} (sh : i≠1) := short_nonneg c b gp fg long bounds sh
  have short0:=nonneg (i:=0) (by decide)
  have short2:=nonneg (i:=2) (by decide)
  have total:=zero_sum c b f g hit actual
  have one : b 1=some true := by
    have sm : b 1=some (decide (c.p 1≤Q)):=by simpa [cut.not_ge] using rule 1
    by_contra no
    have mode : b 1=some false := by simpa [sm] using (show decide (c.p 1≤Q)=false by cases tag:decide (c.p 1≤Q) <;> simp_all)
    have v:=other_bounds c b 1
    have plus:=OMA.MiddleChange245212.dropped (f:=f) (g:=g) (c.prime 1) (c.positive 1) v.1 v.2.1
    have ne : 0<change c b f g 1:=by
      dsimp only [change];rw [mode]
      have fp : 0<f:=(Nat.mul_pos (by omega : 0<c.k) gp).trans_le fg
      have pp:=(c.prime 1).pos
      exact (show (0:ℚ)<f/(2*(c.p 1:ℚ)) by positivity).trans_le plus
    linarith only [ne,short0.1,short2.1,total]
  have qcap := bounds 1 one
  have minus : change c b f g 1<0 := by
    by_cases a : b 0=none
    · have ne : b 2≠none:=fun h=>notboth ⟨a,h⟩
      linarith only [short0.1,short2.2 ne,total]
    · linarith only [short0.2 a,short2.1,total]
  have positive : (f:ℚ)*otherX c b 1<(g:ℚ)*((c.p 1:ℚ)-1)*otherY c b 1 := by
    dsimp only [change] at minus;rw [one,OMA.MiddleChange245212.retained (c.prime 1)] at minus
    have pp : (1:ℚ)<c.p 1:=by exact_mod_cast (c.prime 1).one_lt
    by_contra! bad
    exact (not_lt_of_ge (div_nonneg (sub_nonneg.mpr bad) (by positivity))) minus
  have sr:=risk gp fg positive
  have v:=other_bounds c b 1
  have cost : -((g:ℚ)/(c.p 1:ℚ)^(c.e 1)) ≤ change c b f g 1 := by
    dsimp only [change];rw [one]
    simpa only [neg_div] using OMA.MiddleChange245212.retained_loss (f:=f) (g:=g)
      (c.prime 1) (e:=c.e 1) (zero_le_one.trans v.1) v.2.2
  have cannot {i : Fin 3} (short : i≠1) (pow : c.L^3*c.p i^c.e i<c.p 1^c.e 1)
      (opp : 0≤change c b f g (if i=0 then 2 else 0)) : b i≠some true := by
    intro mode
    have v:=other_bounds c b i
    have gain:=OMA.MiddleChange245212.retained_gain (c.prime i) c.kp fg (bounds i mode) (c.cap i)
      v.1 v.2.1 (shortY c b long short)
    have strict : (g:ℚ)/(c.p 1:ℚ)^(c.e 1)<change c b f g i := by
      dsimp only [change];rw [mode]
      apply lt_of_lt_of_le _ gain
      have lp : 0<c.L:=by omega
      have pp:=(c.prime i).pos
      exact div_lt_div_of_pos_left (by exact_mod_cast gp) (by positivity) (by exact_mod_cast pow)
    by_cases i0 : i=0
    · subst i;change 0≤change c b f g 2 at opp
      linarith only [strict,cost,opp,total]
    · have i2:i=2:=by omega
      subst i;simp at opp
      linarith only [strict,cost,opp,total]
  have leftPow : c.L^3*c.p 0^c.e 0<c.p 1^c.e 1 := (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left pq.le _)).trans_lt
    (OMA.MiddlePower245212.left (c.prime 1).two_le power sep0)
  have leftNo:=cannot (i:=0) (by decide) leftPow (by exact short2.1)
  have zero : b 0=none:=by
    by_contra no
    have cap0 : c.p 0≤Q:=pq.le.trans (qcap.trans cover)
    by_cases small : c.p 0^c.e 0≤Q
    · exact no (by simpa [small] using rule 0)
    · exact leftNo (by simpa [small,cap0] using rule 0)
  have two : b 2=some false := by
    have ne : b 2≠none:=fun h=>notboth ⟨zero,h⟩
    cases h:b 2 with
    | none=>contradiction
    | some tag=>
      cases tag with
      | false=>rfl
      | true=>
        have pow:=OMA.MiddlePower245212.right k0 (c.prime 1).two_le (bounds 2 h) sr sep2 long
        exact False.elim (cannot (i:=2) (by decide) pow (by exact short0.1) h)
  exact ⟨zero,one,two,positive⟩

end OMA.MiddleModes245212
