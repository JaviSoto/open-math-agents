import EulerSupportUnique245212
import RankThreeAnchor245212

/-! A number with exactly one distinct odd prime factor never divides its
own weighted divisor sum. Hence no such cofactor can have an Euler resonance. -/
namespace OMA.SinglePrefixEffective245212
open Nat ArithmeticFunction OMA.Smooth245212 OMA.WeightVal245212
open OMA.CofactorEffectiveOriginal245212 OMA.CofactorEulerSeparation245212
open scoped ArithmeticFunction.sigma
open private OMA.RankThreeAnchor245212.weight_unit OMA.RankThreeAnchor245212.dyadic_weight
  from RankThreeAnchor245212

private theorem weight_pos {p a : ℕ} (pr : p.Prime) : 0<W (p^a) := by
  rw [w_pow pr]
  exact Finset.sum_pos' (fun _ _=>Nat.zero_le _) ⟨0,Finset.mem_range.mpr (by omega),by simp⟩

private theorem large_power {p k a : ℕ} (hp : 3≤p) (ap : 0<a) (size : 2^(k+1)≤a+2) :
    W (2^k)<p^a := by
  rw [OMA.RankThreeAnchor245212.dyadic_weight]
  cases k with
  | zero =>
    have one:=Nat.pow_le_pow_right (by omega : 0<p) (show 1≤a by omega)
    simp only [pow_one] at one
    omega
  | succ j =>
    cases j with
    | zero =>
      have a2 : 2≤a:=by norm_num at size;omega
      have pw:=(Nat.pow_le_pow_left hp 2).trans (Nat.pow_le_pow_right (by omega : 0<p) a2)
      norm_num at pw ⊢
      omega
    | succ t =>
      let k:=t+2
      have exp (s : ℕ) : 2*((s+2)+1)+2≤2^((s+2)+1) := by
        induction s with
        | zero=>decide
        | succ s ih=>
          calc
            2*(s+1+2+1)+2 ≤ 2*(2*(s+2+1)+2) := by omega
            _ ≤ 2*2^(s+2+1) := Nat.mul_le_mul_left _ ih
            _ = 2^(s+1+2+1) := by rw [show s+1+2+1=(s+2+1)+1 by omega,pow_succ 2 (s+2+1),mul_comm]
      have enough : 2*(k+1)≤a:=by have := exp t;change 2^(t+2+1)≤a+2 at size;dsimp [k];omega
      have power := (Nat.pow_le_pow_right (by decide : 0<2) enough).trans (Nat.pow_le_pow_left (by omega : 2≤p) a)
      apply lt_of_lt_of_le _ power
      change k*2^(k+1)+1<2^(2*(k+1))
      rw [show 2*(k+1)=(k+1)+(k+1) by omega,pow_add 2 (k+1) (k+1)]
      have inc : k+1<2^(k+1):=Nat.lt_two_pow_self
      have gap:=Nat.mul_le_mul_right (2^(k+1)) inc
      have nz:=Nat.two_pow_pos (k+1)
      nlinarith only [gap,nz,inc]

theorem not_divides {k p a : ℕ} (pr : p.Prime) (odd : Odd p) (ap : 0<a) :
    ¬2^k*p^a∣W (2^k*p^a) := by
  have pc:=(Nat.coprime_two_left.mpr odd).pow_left k
  intro hit
  rw [w_mult.map_mul_of_coprime (pc.pow_right a)] at hit
  have pd : p^a∣W (2^k) := ((OMA.RankThreeAnchor245212.weight_unit pr a).pow_left a).dvd_of_dvd_mul_right
    ((dvd_mul_left _ _).trans hit)
  have td : 2^k∣W (p^a) := ((Nat.coprime_two_left.mpr (OMA.DyadicPower245212.dyadic_odd k)).pow_left k).dvd_of_dvd_mul_left
    ((dvd_mul_right _ _).trans hit)
  have order : k≤val (W (p^a)) := (prime_two.pow_dvd_iff_le_factorization (weight_pos pr).ne').mp td
  have localOrder:=weight_local pr odd a
  have size (j : ℕ) (pos : 0<j) (v : k+1≤val j) : 2^(k+1)≤j :=
    Nat.le_of_dvd pos ((pow_dvd_pow 2 v).trans (Nat.ordProj_dvd j 2))
  have big : 2^(k+1)≤a+2 := by
    rcases Nat.even_or_odd (a+1) with ev|od
    · have v:=val_odd (show Odd (a+2) from ev.add_one)
      exact (size (a+1) (by omega) (by omega)).trans (by omega)
    · have v:=val_odd od
      exact size (a+2) (by omega) (by omega)
  have p3 : 3≤p:=by obtain ⟨u,hu⟩:=odd;have := pr.two_le;omega
  exact (large_power p3 ap big).not_ge (Nat.le_of_dvd (by rw [OMA.RankThreeAnchor245212.dyadic_weight];omega) pd)

/-- One whole remaining prime power is bounded even when the cofactor
already contains any prescribed power of a different odd prime. -/
theorem next_atom {k p a m : ℕ} (pr : p.Prime) (odd : Odd p) (ap : 0<a)
    (hm : 1 < m) (cop : (2^k*p^a).Coprime m)
    (eqn : OeisA245212.a (2^k*p^a*m)=(σ 1 (2^k*p^a*m):ℤ)) :
    ∃q∈m.primeFactors,q≤primeHeight (2^k*p^a) m.primeFactors.card ∧
      m.factorization q≤height (2^k*p^a) m.primeFactors.card := by
  apply original (Nat.mul_pos (Nat.two_pow_pos _) (pow_pos pr.pos _)) hm cop _ eqn
  intro t sub eq
  exact not_divides pr odd ap (OMA.EulerSupportUnique245212.cofactor_divides
    (fun q mq=>cop.of_dvd_right (dvd_of_mem_primeFactors (sub mq))) eq)

#print axioms not_divides
#print axioms next_atom
end OMA.SinglePrefixEffective245212
