import Mathlib

/-! A positive integral gap below a rectangular bilinear form cannot be
arbitrarily small relative to the product of its two variables. Neither
variable nor the coefficient of their product enters the gap multiplier. -/
namespace OMA.PositiveBilinearGap245212

def cost (I J K : ℕ) := (4*(I+J+K+1)+1)^3

private theorem short {C Z P G I J K N : ℕ} (gp : 0<G)
    (eqn : C*Z*P=G+I*Z+J*P+K) (zle : Z≤N) (ile : I≤N) (kle : K+1≤N) :
    Z*P≤(N+1)^3*G := by
  have pos : J<C*Z:=by
    by_contra! no
    have :=Nat.mul_le_mul_right P no
    omega
  have mul := Nat.mul_le_mul_right P (Nat.succ_le_of_lt pos)
  have small : P≤G+(I*Z+K):=by nlinarith only [mul,eqn]
  have kg := Nat.mul_le_mul_left (I*Z+K) (show 1≤G from gp)
  have cut : P≤(I*Z+K+1)*G:=by nlinarith only [small,kg]
  have lim : I*Z+K+1≤(N+1)^2:=by
    have :=Nat.mul_le_mul ile zle
    nlinarith only [this,kle,Nat.zero_le N]
  calc
    _ ≤ (N+1)*((N+1)^2*G) := Nat.mul_le_mul (by omega) (cut.trans (Nat.mul_le_mul_right G lim))
    _ = _ := by ring

theorem gap {C Z P G I J K : ℕ} (gp : 0<G) (eqn : C*Z*P=G+I*Z+J*P+K) :
    Z*P≤cost I J K*G := by
  let h:=I+J+K+1
  have hi : I≤h:=by dsimp [h];omega
  have hj : J≤h:=by dsimp [h];omega
  have hk : K+1≤h:=by dsimp [h];omega
  change Z*P≤(4*h+1)^3*G
  by_cases sz : Z≤4*h
  · exact short gp eqn sz (by omega) (by omega)
  by_cases sp : P≤4*h
  · have e : C*P*Z=G+J*P+I*Z+K:=by nlinarith only [eqn]
    simpa only [Nat.mul_comm P Z] using short gp e sp (by omega) (by omega)
  have iz:=Nat.mul_le_mul_left Z (show 4*I≤P by omega)
  have jp:=Nat.mul_le_mul_left P (show 4*J≤Z by omega)
  have zp : 0<Z:=by omega
  have pk:=Nat.le_mul_of_pos_left P zp
  have kp : 4*K≤Z*P:=by omega
  have cp : 0<C:=by by_contra! zero;rw [Nat.eq_zero_of_le_zero zero] at eqn;simp at eqn;omega
  have large:=Nat.mul_le_mul_right (Z*P) (show 1≤C from cp)
  have four : Z*P≤4*G:=by nlinarith only [eqn,iz,jp,kp,large]
  have top : 4≤(4*h+1)^3:=by
    have nh : 1≤h:=by omega
    exact (by decide : 4≤5^3).trans (Nat.pow_le_pow_left (by omega) _)
  exact four.trans (Nat.mul_le_mul_right G top)

#print axioms gap
end OMA.PositiveBilinearGap245212
