import LeastTallFactor245212

/-! An absolute harmonic bound on the least prime, independent of which
coordinate carries the longest exponent. -/
namespace OMA.MiddleLeast245212
open Nat Finset OMA.TwoTallLocal245212 OMA.SingleMovingGap245212
open OMA.LeastTallFactor245212 (localY)
open OMA.ThreeMovingOriginal245212 (F G)
open private OMA.LeastTallFactor245212.localX from LeastTallFactor245212
open private OMA.SingleMovingOriginal245212.identities from SingleMovingOriginal245212

theorem bound (c : Family) {v : Fin 3} (long : c.e v+1=c.L)
    (least : ∀i,c.p 0≤c.p i) (large : 33≤c.p 0) (tall : 32≤c.L)
    (actual : score (F c.k) (G c.k) (exactX c) (exactY c)=(F c.k+G c.k:ℕ)) :
    c.p 0≤4*(c.k+1) := by
  let f:=F c.k
  let g:=G c.k
  let P:=∏i,exactX c i
  let S:=∏i,exactY c i
  let u:ℚ:=(c.p 0:ℚ)-1
  have loc i := OMA.LeastTallFactor245212.localX large (least i) (c.prime i) (c.positive i)
  change ∀i, 1≤exactX c i ∧ exactX c i≤33/32 ∧ u*(exactX c i-1)≤1 at loc
  have p0 i := (zero_le_one.trans (loc i).1)
  have Xprod : u*(P-1) ≤ 13/4 := by
    let x:=exactX c
    have a:=mul_le_mul_of_nonneg_right (loc 0).2.2 (mul_nonneg (p0 1) (p0 2))
    have b:=mul_le_mul_of_nonneg_right (loc 1).2.2 (p0 2)
    have d:=mul_le_mul (loc 1).2.1 (loc 2).2.1 (p0 2) (by norm_num : (0:ℚ)≤33/32)
    dsimp only [P];rw [Fin.prod_univ_three]
    nlinarith only [a,b,d,(loc 2).2.2,(loc 2).2.1]
  have nonY i : 0≤exactY c i := (ranges (c.prime i) (c.positive i) none).2.2.1
  have bound i : exactY c i≤1 := (localY (c.prime i) (c.positive i) (large.trans (least i)) none).trans (by norm_num)
  have s := (ranges (c.prime v) (c.positive v) none).2.2.2
  change exactY c v≤2/((c.e v:ℚ)+1) at s
  have T : (32:ℚ)≤(c.e v:ℚ)+1:=by exact_mod_cast (long ▸ tall : 32≤c.e v+1)
  have lowS : S≤1/16 := by
    calc
      _ = (∏ i∈univ.erase v,exactY c i)*exactY c v := (prod_erase_mul _ _ (mem_univ v)).symm
      _ ≤ exactY c v := mul_le_of_le_one_left (nonY v) (prod_le_one (fun j _=>nonY j) (fun j _=>bound j))
      _ ≤ _ := s.trans ((div_le_iff₀ (by positivity)).mpr (by linarith only [T]))
  change (f:ℚ)*P+(g:ℚ)*S=(f+g:ℕ) at actual
  push_cast at actual

  have old:=OMA.SingleMovingOriginal245212.identities c.k
  have k0:=Nat.two_pow_pos c.k
  have gm : c.k+1≤g:=by
    dsimp [g,G];rw [pow_succ]
    have z : c.k+1≤2^c.k:=Nat.lt_pow_self (by decide)
    omega
  have fg : (f:ℚ)≤((c.k:ℚ)+1)*g:=by
    exact_mod_cast (show f≤(c.k+1)*g by
      dsimp [f,g];rw [old.2.2,Nat.add_mul,one_mul];exact Nat.add_le_add_left gm _)
  have up : 0≤u:=by
    dsimp [u]
    have h : (33:ℚ)≤c.p 0:=by exact_mod_cast large
    linarith
  have g0 : (0:ℚ)<g:=by exact_mod_cast old.1
  have p1 : u*g ≤ 13/4*f+(1/16)*(u*g):=by
    nlinarith only [congrArg (fun z:ℚ=>z*u) actual,mul_le_mul_of_nonneg_right Xprod
      (Nat.cast_nonneg (α:=ℚ) f),mul_le_mul_of_nonneg_left lowS (mul_nonneg up g0.le)]
  by_contra! huge
  have hh : 4*((c.k:ℚ)+1)<c.p 0 := by exact_mod_cast huge
  have k8 : (8:ℚ)≤c.k:=by exact_mod_cast c.kp
  dsimp only [u] at p1
  nlinarith only [p1,fg,mul_lt_mul_of_pos_right hh g0,mul_le_mul_of_nonneg_right k8 g0.le,g0]

end OMA.MiddleLeast245212
