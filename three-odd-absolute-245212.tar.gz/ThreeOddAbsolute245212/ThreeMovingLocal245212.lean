import ComplementaryLocal245212
import CapOrder245212

/-! Cleared rational proxies for three independently moving odd prime powers. -/
namespace OMA.ThreeMovingLocal245212
open Nat Finset ArithmeticFunction OMA.Smooth245212 OMA.Abundance245212
open scoped ArithmeticFunction.sigma

def den (p e : ℕ) (round : Bool) := if round then (e+1)*(p-1)^2 else e+1
def xn (p e : ℕ) (round : Bool) := if round then p*((e+1)*(p-1)-1) else e+1
def yn (p _e : ℕ) (round : Bool) := if round then p*(p-1) else 1
def xx (p e : ℕ) (b : Bool) : ℚ := (xn p e b:ℚ)/den p e b
def yy (p e : ℕ) (b : Bool) : ℚ := (yn p e b:ℚ)/den p e b

theorem den_pos {p : ℕ} (hp : 2≤p) (e) (b) : 0<den p e b := by
  have:0<p-1:=by omega
  cases b <;> simp [den]
  positivity

private theorem quotients {p e : ℕ} (hp : p.Prime) :
    let u:ℚ:=(p:ℚ)-1
    let B:ℚ:=(e:ℚ)+1
    let P:ℚ:=(p:ℚ)^e
    let δ : ℚ:=1/(B*u^2*P)
    X p (some e) = xx p e true+δ ∧
    Y p (some e) = yy p e true-u*δ := by
  have p2:=hp.two_le
  have pp : (1:ℚ)<p:=by exact_mod_cast hp.one_lt
  have Bp : (0:ℚ)<(e:ℚ)+1:=by positivity
  have uu : (p-1)*(e+1)≥1:=Nat.mul_pos (by omega) (by omega)
  have uu' : 1≤(e+1)*(p-1):=by simpa [mul_comm] using uu
  have id:=OMA.ComplementaryLocal245212.moments hp e
  have w:((p:ℚ)-1)^2*W (p^e)=p*(((e:ℚ)+1)*(p-1)-1)*(p:ℚ)^e+1 := by exact_mod_cast id.2
  have s:((p:ℚ)-1)*σ 1 (p^e)=p*(p:ℚ)^e-1 := by exact_mod_cast id.1
  have x:=x_factor hp e
  have y:=y_factor hp e
  dsimp [xx,yy,xn,yn,den]
  push_cast [Nat.cast_sub hp.one_le,Nat.cast_sub uu']
  constructor
  · field_simp [sub_ne_zero.mpr pp.ne',Bp.ne',(show (0:ℚ)<p by positivity).ne']
    linear_combination ((p:ℚ)-1)^2*x+w
  · field_simp [sub_ne_zero.mpr pp.ne',Bp.ne',(show (0:ℚ)<p by positivity).ne']
    linear_combination ((p:ℚ)-1)*y+s

theorem bounds {p e m : ℕ} (hp : p.Prime) (pe : 0<e) (mp : 0 < m) (sl : m≤e+1) (b : Bool) :
    1≤X p (some e) ∧ X p (some e)≤2 ∧ 0≤Y p (some e) ∧ Y p (some e)≤2/(m:ℚ) ∧
    1≤xx p e b ∧ xx p e b≤2 ∧ 0≤yy p e b ∧ yy p e b≤2/(m:ℚ) := by
  have pp : (2:ℚ)≤p := by exact_mod_cast hp.two_le
  have ep : (1:ℚ)≤e := by exact_mod_cast pe
  have md : (0:ℚ) < m := by exact_mod_cast mp
  have hl : (m:ℚ)≤(e:ℚ)+1 := by exact_mod_cast sl
  have bpos : (0:ℚ)<(e:ℚ)+1:=by positivity
  have ypos := y_nonneg hp.one_lt (some e)
  have ysm := y_one hp.one_lt (some e)
  have ub : Y p (some e)≤2/(m:ℚ) := (le_div_iff₀ md).mpr <|
    (mul_le_mul_of_nonneg_left hl ypos).trans (OMA.CapOrder245212.y_short hp e).le
  have xb : 1≤X p (some e) := le_add_of_nonneg_right (div_nonneg (sub_nonneg.mpr ysm) (by linarith))
  have xb' : X p (some e)≤2 := by
    dsimp [X]
    suffices (1-Y p (some e))/((p:ℚ)-1)≤1 by linarith
    apply (div_le_one₀ (by linarith)).mpr;linarith
  refine ⟨xb,xb',ypos,ub,?_⟩
  cases b with
  | false =>
    have a0 : xx p e false=1 := by simp [xx,xn,den,bpos.ne']
    have b0 : yy p e false=1/((e:ℚ)+1) := by simp [yy,yn,den]
    rw [a0,b0]
    refine ⟨by norm_num,by norm_num,by positivity,(div_le_div_iff₀ bpos md).mpr ?_⟩
    linarith
  | true =>
    have u : (0:ℚ)<(p:ℚ)-1:=by linarith
    have yw : yy p e true=(p:ℚ)/(((e:ℚ)+1)*(p-1)) := by
      dsimp [yy,yn,den];push_cast [Nat.cast_sub hp.one_le];field_simp
    have yw2 : yy p e true≤2/(m:ℚ) := by
      rw [yw,div_le_div_iff₀ (mul_pos bpos u) md]
      nlinarith only [mul_le_mul_of_nonneg_left hl (show (0:ℚ)≤p by positivity),
        mul_nonneg bpos.le (sub_nonneg.mpr pp)]
    have d0 : 0≤1/(((e:ℚ)+1)*((p:ℚ)-1)^2*(p:ℚ)^e) := by positivity
    have one : 1≤xx p e true := by
      dsimp [xx,xn,den]
      push_cast [Nat.cast_sub hp.one_le,Nat.cast_sub (Nat.mul_pos (by omega : 0<e+1) (by have:=hp.two_le;omega : 0<p-1))]
      rw [le_div_iff₀ (mul_pos bpos (sq_pos_of_pos u)),one_mul]
      nlinarith only [mul_nonneg (sub_nonneg.mpr ep) u.le,pp]
    exact ⟨one,(by linarith only [(quotients hp (e:=e)).1,xb',d0]),by rw [yw];positivity,yw2⟩

theorem move {p e f g m k : ℕ} (hp : p.Prime) (pe : 0<e) (mp : 0 < m)
    (ku : 0<k) (gu : 0<g) (fk : k*g≤f) (b : Bool)
    (small : b=true → 4*(p-1)<k*m^2)
    (x x' y y' : ℚ) (x0 : 1≤x) (x1 : 1≤x') (y0 : 0≤y) (y1 : 0≤y')
    (yl : y≤2/(m:ℚ)) (yl' : y'≤2/(m:ℚ)) :
    (f:ℚ)*xx p e b*x*x'+g*yy p e b*y*y' < f*X p (some e)*x*x'+g*Y p (some e)*y*y' := by
  have pp : (1:ℚ)<p:=by exact_mod_cast hp.one_lt
  have fg : (k:ℚ)*g≤f:=by exact_mod_cast fk
  have g0 : (0:ℚ)<g:=by exact_mod_cast gu
  have kp : (0:ℚ)<k:=by exact_mod_cast ku
  have fm : (0:ℚ)<f := lt_of_lt_of_le (mul_pos kp g0) fg
  have xl : (1:ℚ)≤x*x' := one_le_mul_of_one_le_of_one_le x0 x1
  have ylo := mul_nonneg y0 y1
  cases b with
  | false =>
    have ysum : 1/((e:ℚ)+1)≤Y p (some e) := by
      have id:=y_factor hp e
      have big : (p:ℚ)^e ≤ σ 1 (p^e) := by
        exact_mod_cast (show p^e ≤ σ 1 (p^e) by rw [sigma_one_apply_prime_pow hp,Finset.sum_range_succ];omega)
      apply (div_le_iff₀ (by positivity : (0:ℚ)<(e:ℚ)+1)).mpr
      apply le_of_mul_le_mul_right (a:=(p:ℚ)^e) _ (by positivity)
      nlinarith only [id,big]
    have ylt := y_strict hp.one_lt (show 0<e from pe)
    have xstrict : 1<X p (some e) := by
      dsimp [X];apply lt_add_of_pos_right;apply _root_.div_pos _ (by linarith)
      exact sub_pos.mpr (ylt.trans_le (y_one hp.one_lt _))
    have minus : 0<(f:ℚ)*(X p (some e)-1)*(x*x') := by positivity
    have plus := mul_nonneg (mul_nonneg g0.le (sub_nonneg.mpr ysum)) ylo
    have xx0 : xx p e false=1 := by simp [xx,xn,den,show (e:ℚ)+1≠0 by positivity]
    have yy0 : yy p e false=1/((e:ℚ)+1) := by simp [yy,yn,den]
    rw [xx0,yy0]
    nlinarith only [minus,plus]
  | true =>
    let u:ℚ:=(p:ℚ)-1
    let d:ℚ:=1/(((e:ℚ)+1)*u^2*(p:ℚ)^e)
    have dp : 0<d := by dsimp [d,u];positivity
    have us : (0:ℚ)≤u:=by dsimp [u];linarith
    have cap0 := mul_le_mul yl yl' y1 (by positivity)
    have cap : (y*y')*(m:ℚ)^2≤4 := by
      apply (le_div_iff₀ (sq_pos_of_pos (show (0:ℚ) < m by exact_mod_cast mp))).mp
      convert cap0 using 1; ring
    have gate : 4*u < (k:ℚ)*m^2 := by
      have sc : (4:ℚ)*((p-1:ℕ):ℚ)<k*(m:ℚ)^2 := by exact_mod_cast small rfl
      simpa [u,Nat.cast_sub hp.one_le] using sc
    have unc : u*(y*y')<(k:ℚ) := by
      apply lt_of_mul_lt_mul_right (a:=(m:ℚ)^2) _ (by positivity)
      nlinarith only [gate,mul_le_mul_of_nonneg_left cap us]
    have diff : 0<(f:ℚ)*x*x'-g*u*y*y' := by
      nlinarith only [mul_lt_mul_of_pos_left unc g0,mul_le_mul_of_nonneg_left xl fm.le,fg]
    have q:=quotients hp (e:=e)
    change X p (some e)=xx p e true+d ∧ Y p (some e)=yy p e true-u*d at q
    rw [q.1,q.2]
    nlinarith only [mul_pos dp diff]

/-- A rounded factor costs at most 2/p^e; a base omitted to infinity
costs at most 2/p. Both local moments obey the same estimate. -/
theorem error {p e N : ℕ} (hp : p.Prime) (he : 0<e) (hN : 0<N) (b : Bool)
    (space : N ≤ (if b then p^e else p)) :
    |X p (some e)-xx p e b|≤2/(N:ℚ) ∧ |Y p (some e)-yy p e b|≤2/(N:ℚ) := by
  let u:ℚ:=(p:ℚ)-1
  let B:ℚ:=(e:ℚ)+1
  let P:ℚ:=(p:ℚ)^e
  have ulo : 1≤u := by dsimp [u];linarith only [show (2:ℚ)≤p by exact_mod_cast hp.two_le]
  have blo : 1≤B := by dsimp [B];linarith only [Nat.cast_nonneg (α:=ℚ) e]
  have up : 0<u := by linarith
  have bp : 0<B := by linarith
  have pp : 0<P := pow_pos (by exact_mod_cast hp.pos) _
  have np : (0:ℚ)<N := by exact_mod_cast hN
  let d:=1/(B*u^2*P)
  have dp : 0≤d := by dsimp [d];positivity
  have pairs:=quotients hp (e:=e)
  change X p (some e)=xx p e true+d ∧ Y p (some e)=yy p e true-u*d at pairs
  cases b with
  | true =>
    change N≤p^e at space
    have sg : (N:ℚ)≤P:=by dsimp [P];exact_mod_cast space
    have du : u*d=1/(B*u*P) := by dsimp [d];field_simp
    have ud : u*d≤2/(N:ℚ) := by
      rw [du,div_le_div_iff₀ (by positivity) np]
      have big : P≤B*u*P := le_mul_of_one_le_left pp.le (one_le_mul_of_one_le_of_one_le blo ulo)
      linarith
    rw [pairs.1,pairs.2,add_sub_cancel_left,sub_sub_cancel_left,abs_neg,abs_of_nonneg dp,abs_of_nonneg (mul_nonneg up.le dp)]
    exact ⟨(le_mul_of_one_le_left dp ulo).trans ud,ud⟩
  | false =>
    change N≤p at space
    have small : (N:ℚ)≤2*u := by
      have pp : (2:ℚ)≤p:=by exact_mod_cast hp.two_le
      dsimp [u];linarith only [pp,show (N:ℚ)≤p by exact_mod_cast space]
    have frac : 1/u ≤ 2/(N:ℚ):= (div_le_div_iff₀ up np).mpr (by linarith)
    have xr:= (bounds hp he (by decide : 0<1) (by omega) false).1
    have xe : X p (some e)-1≤1/u := by dsimp [X,u];rw [add_sub_cancel_left];gcongr;exact sub_le_self _ (y_nonneg hp.one_lt _)
    have yupper : yy p e true-1/B=1/(B*u) := by
      dsimp [yy,yn,den,u,B];push_cast [Nat.cast_sub hp.one_le];field_simp [show (p:ℚ)-1≠0 from up.ne'];ring
    have lower : 1/B≤Y p (some e) := by
      apply (div_le_iff₀ bp).mpr
      apply le_of_mul_le_mul_right (a:=P) _ pp
      have big : (p:ℚ)^e ≤ σ 1 (p^e) := by
        exact_mod_cast (show p^e ≤ σ 1 (p^e) by rw [sigma_one_apply_prime_pow hp,Finset.sum_range_succ];omega)
      dsimp [B,P];nlinarith only [y_factor hp e,big]
    have pre : Y p (some e)-1/B≤1/(B*u) := by
      nlinarith only [pairs.2,yupper,mul_nonneg up.le dp]
    have s : 1/(B*u) ≤ 1/u := one_div_le_one_div_of_le up (le_mul_of_one_le_left up.le blo)
    have xx0 : xx p e false=1 := by simp [xx,xn,den,show (e:ℚ)+1≠0 by positivity]
    have yy0 : yy p e false=1/B := by simp [yy,yn,den,B]
    rw [xx0,yy0,abs_of_nonneg (sub_nonneg.mpr xr),abs_of_nonneg (sub_nonneg.mpr lower)]
    exact ⟨xe.trans frac,pre.trans (s.trans frac)⟩

end OMA.ThreeMovingLocal245212
