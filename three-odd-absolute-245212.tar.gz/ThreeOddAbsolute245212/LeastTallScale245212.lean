import SingleMovingHeight245212

/-! Absorb all polynomial scales into a single sufficiently long prime power. -/
namespace OMA.LeastTallScale245212
open Nat
open OMA.ThreeMovingOriginal245212 (F G)

def cutoff (C E D : ℕ) :=
  2*(512*(C+1)^2)^D+16*((2*E+1)*D+1)^2+64

theorem scale {C E D k L p e : ℕ} (dyadic : 2^k≤C*(L+1)^E)
    (large : cutoff C E D≤L) (hp : 2≤p) (long : e+1=L) :
    (128*(F k+G k+1)*(L+1))^D<p^e := by
  let w:=2^k
  have wp : 0<w:=Nat.two_pow_pos _
  have kw : k+1≤w:=Nat.lt_pow_self (by decide)
  have id : F k+G k=(k+1)*(2*w) := by
    have sub:=Nat.sub_add_cancel (show 1≤2*w by omega)
    dsimp [F,G];rw [pow_succ,←show w=2^k by rfl]
    nlinarith only [sub,Nat.sub_add_cancel (by omega : 1≤w*2)]
  have v : F k+G k+1≤4*w^2:=by
    rw [id]
    nlinarith only [Nat.mul_le_mul_right (2*w) kw,Nat.one_le_pow 2 w wp]
  let A := (512*(C+1)^2)^D
  let B := (2*E+1)*D
  have pre : 128*(F k+G k+1)*(L+1) ≤ 512*(C+1)^2*(L+1)^(2*E+1) := calc
    _ ≤ 128*(4*w^2)*(L+1) := Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ v)
    _ ≤ 128*(4*((C+1)*(L+1)^E)^2)*(L+1) := by
      apply Nat.mul_le_mul_right
      apply Nat.mul_le_mul_left
      apply Nat.mul_le_mul_left
      exact Nat.pow_le_pow_left (dyadic.trans (Nat.mul_le_mul_right _ (Nat.le_succ _))) _
    _ = _ := by rw [pow_succ (L+1) (2*E),mul_comm 2 E,pow_mul];ring
  have upper : (128*(F k+G k+1)*(L+1))^D ≤ A*(L+1)^B := by
    simpa only [A,B,mul_pow,pow_mul] using Nat.pow_le_pow_left pre D
  change 2*A+16*(B+1)^2+64≤L at large
  have absorb:=OMA.ComplementarySize245212.absorb (d:=B) (b:=L+1) (by omega)
  have grow : A^2≤2^(2*A) := by
    rw [mul_comm 2 A,pow_mul]
    exact Nat.pow_le_pow_left (Nat.lt_pow_self (by decide : 1<2)).le 2
  have small : 2*A+(L+1)<e*2:=by omega
  have sq : (A*(L+1)^B)^2<(p^e)^2 := calc
    _ = A^2*(L+1)^(2*B) := by rw [mul_pow,mul_comm 2 B,pow_mul (L+1) B 2]
    _ ≤ 2^(2*A)*2^(L+1) := Nat.mul_le_mul grow absorb
    _ = 2^(2*A+(L+1)) := (pow_add ..).symm
    _ < 2^(e*2) := Nat.pow_lt_pow_right (by decide) small
    _ ≤ _ := by rw [pow_mul];exact Nat.pow_le_pow_left (Nat.pow_le_pow_left hp e) 2
  exact upper.trans_lt ((pow_lt_pow_iff_left₀ (Nat.zero_le _) (Nat.zero_le _) (by decide : 2≠0)).mp sq)

end OMA.LeastTallScale245212
