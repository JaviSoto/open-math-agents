import SingleMovingLoss245212

/-! The actual dyadic deficit exceeds the total possible loss caused by
all risky rounded coordinates, without any comparability assumption. -/
namespace OMA.SingleMovingProxy245212
open Nat Finset OMA.SingleMovingGap245212 OMA.TwoTallLocal245212
open OMA.ThreeMovingOriginal245212 (G)
def deficit (c : Family) : ℚ := (c.k:ℚ)+1-score c.k 1 (exactX c) (exactY c)

theorem lower (c : Family) (link : deficit c*(G c.k:ℕ)=((c.k:ℚ)+1)*((∏i,exactX c i)-1)) (i) :
    1≤(2*(c.p i:ℚ))*(G c.k)*(deficit c) := by
  have xb j : 1≤exactX c j:=(ranges (c.prime j) (c.positive j) none).1
  have xi : exactX c i≤∏j,exactX c j := by
    rw [←prod_erase_mul (univ : Finset (Fin 3)) (exactX c) (mem_univ i)]
    exact le_mul_of_one_le_left (zero_le_one.trans (xb _)) (one_le_prod (fun j _=>xb j))
  have localBound:=OMA.SingleMovingLoss245212.single_lb (c.prime i) (c.positive i)
  change 1≤(2*(c.p i:ℚ))*(exactX c i-1) at localBound
  have xm : 0≤(∏j,exactX c j)-1:=by linarith only [xi,xb i]
  have more:=mul_nonneg (Nat.cast_nonneg (α:=ℚ) c.k) xm
  have cc : 0≤2*(c.p i:ℚ):=by positivity
  nlinarith only [localBound,mul_le_mul_of_nonneg_left xi cc,mul_nonneg cc more,
    congrArg (fun z:ℚ=>2*(c.p i:ℚ)*z) link]

theorem positive (c : Family) (link : deficit c*(G c.k:ℕ)=((c.k:ℚ)+1)*((∏i,exactX c i)-1)) : 0<deficit c := by
  have h:=lower c link 0
  by_contra! n
  have t:=mul_nonpos_of_nonneg_of_nonpos (show 0≤2*(c.p 0:ℚ)*(G c.k:ℕ) by positivity) n
  linarith

theorem separated (c : Family) (b : Fin 3→Option Bool)
    (link : deficit c*(G c.k:ℕ)=((c.k:ℚ)+1)*((∏i,exactX c i)-1)) :
    (c.k+1)*dust c b ≠ c.k*NX c b+NY c b := by
  intro hit
  have gd : 0<deficit c:=positive c link
  have scale:=retained (b:=b) (f:=c.k) (g:=1) (l:=1) (by simp)
    (fun i=>Nat.not_dvd_of_pos_of_lt (by decide) (c.prime i).one_lt) (by simpa using hit)
  let mix (s : Finset (Fin 3)) (i : Fin 3) := if i∈s then exactX c i else x' c b i
  let miy (s : Finset (Fin 3)) (i : Fin 3) := if i∈s then exactY c i else y' c b i
  have adv (s : Finset (Fin 3)) {i} (fresh : i∉s) :
      score c.k 1 (mix s) (miy s)≤ score c.k 1 (mix (insert i s)) (miy (insert i s))+deficit c/4 := by
    have bound j : 1≤ mix s j ∧ 0≤ miy s j ∧ miy s j≤2/((c.e j:ℚ)+1) := by
      by_cases mem : j∈s
      · have v:=ranges (c.prime j) (c.positive j) none
        simpa only [mix,miy,if_pos mem,exactX,exactY,xx',yy'] using And.intro v.1 v.2.2
      · have v:=ranges (c.prime j) (c.positive j) (b j)
        simpa only [mix,miy,if_neg mem,x',y'] using And.intro v.1 v.2.2
    have size j : miy s j≤1:= (bound j).2.2.trans ((div_le_iff₀ (by positivity)).mpr (by
      have:= (by exact_mod_cast c.positive j : (1:ℚ)≤c.e j);linarith))
    have single {j l : Fin 3} (n : j≠i) (n' : l≠i) (jl : j≠l) :
        (c.k:ℚ)*mix s i*mix s j*mix s l+miy s i*miy s j*miy s l ≤
        c.k*mix (insert i s) i*mix (insert i s) j*mix (insert i s) l+
          miy (insert i s) i*miy (insert i s) j*miy (insert i s) l+deficit c/4 := by
      have prod : miy s j*miy s l≤1:=mul_le_one₀ (size j) (bound l).2.1 (size l)
      have step:=OMA.SingleMovingLoss245212.restore (c.prime i) (c.positive i) (by have:=c.kp;omega : 0<c.k)
        (b i) (mix s j) (mix s l) (miy s j) (miy s l) (deficit c/4)
        (bound j).1 (bound l).1 (bound j).2.1 (bound l).2.1 prod (by positivity)
      suffices bad : b i=some true → (c.k:ℚ)<((c.p i:ℚ)-1)*(miy s j*miy s l) →
          1/(c.p i:ℚ)^(c.e i)≤deficit c/4 by
        simpa [mix,miy,exactX,exactY,x',y',fresh,n,n'] using step bad
      intro bit risk
      have pk : c.k+1<c.p i := by
        have h:=mul_le_mul_of_nonneg_left prod (show (0:ℚ)≤(c.p i:ℚ)-1 by have:= (by exact_mod_cast (c.prime i).one_le : (1:ℚ)≤c.p i);linarith)
        exact_mod_cast (show (c.k:ℚ)+1<c.p i by linarith only [h,risk])
      have pL : c.p i≤c.L:=by have:=scale i bit;omega
      have excluded (z z' : Fin 3) (prod' : miy s j*miy s l=miy s z*miy s z') (maximal : c.e z+1=c.L) : False := by
        have up:=mul_le_mul_of_nonneg_left (size z') (bound z).2.1
        have Y:= (le_div_iff₀ (by positivity)).mp (bound z).2.2
        have PL : (c.p i:ℚ)-1≤(c.e z:ℚ)+1:=by
          have hh : c.p i≤c.e z+1:=by omega
          have v : (c.p i:ℚ)≤c.e z+1:=by exact_mod_cast hh
          linarith
        have cp:=mul_nonneg (bound z).2.1 (bound z').2.1
        have t1:=mul_le_mul_of_nonneg_right PL cp
        have t2:=mul_le_mul_of_nonneg_right up (show (0:ℚ)≤(c.e z:ℚ)+1 by positivity)
        rw [prod'] at risk
        have k8 : (8:ℚ)≤c.k:=by exact_mod_cast c.kp
        nlinarith only [risk,Y,t1,t2,k8]
      obtain ⟨v,vbig⟩:=c.longest
      have caseV : v=i ∨ v=j ∨ v=l:=by omega
      have len : c.p i≤c.e i+1 := by
        rcases caseV with rfl|rfl|rfl
        · omega
        · exact False.elim (excluded _ _ rfl vbig)
        · exact False.elim (excluded _ _ (mul_comm _ _) vbig)
      have pw:=OMA.SingleMovingLoss245212.scalar c.kp pk len
      have more:=lower c link i
      have pwq : 8*(c.p i:ℚ)*(G c.k)≤(c.p i:ℚ)^(c.e i):=by exact_mod_cast pw
      apply (div_le_iff₀ (by have:=(c.prime i).pos;positivity : (0:ℚ)<(c.p i:ℚ)^(c.e i))).mpr
      nlinarith only [more,mul_le_mul_of_nonneg_right pwq gd.le]
    dsimp [score];simp only [Fin.prod_univ_three,one_mul]
    have choice : i=0 ∨ i=1 ∨ i=2 := by omega
    rcases choice with rfl|rfl|rfl
    · simpa only [mul_comm,mul_left_comm,mul_assoc] using single (j:=1) (l:=2) (by decide) (by decide) (by decide)
    · simpa only [mul_comm,mul_left_comm,mul_assoc] using single (j:=0) (l:=2) (by decide) (by decide) (by decide)
    · simpa only [mul_comm,mul_left_comm,mul_assoc] using single (j:=0) (l:=1) (by decide) (by decide) (by decide)
  have a:=adv ∅ (i:=0) (by decide)
  have b1:=adv {0} (i:=1) (by decide)
  have d:=adv {1,0} (i:=2) (by decide)
  have un : insert (2:Fin 3) ({1,0}:Finset (Fin 3))=univ:=by decide
  rw [un] at d
  have a' : score c.k 1 (x' c b) (y' c b)≤ score c.k 1 (mix {0}) (miy {0})+deficit c/4:=by simpa only [mix,miy,notMem_empty,if_false,Finset.insert_empty] using a
  have d' : score c.k 1 (mix {1,0}) (miy {1,0}) ≤ score c.k 1 (exactX c) (exactY c)+deficit c/4:=by simpa only [mix,miy,mem_univ,if_true] using d
  have eq:=clear c b c.k 1
  simp only [one_mul] at eq
  rw [←hit] at eq
  push_cast at eq
  have dp : (0:ℚ)<dust c b:=by exact_mod_cast dust_pos c b
  have eq' : score c.k 1 (x' c b) (y' c b)=(c.k:ℚ)+1:=mul_right_cancel₀ dp.ne' eq
  dsimp only [deficit] at a' b1 d' gd
  linarith only [a',b1,d',eq',gd]

end OMA.SingleMovingProxy245212
