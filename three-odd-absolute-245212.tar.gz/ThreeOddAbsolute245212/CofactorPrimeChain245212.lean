import CohortAtom245212

/-! The largest prime in a nonempty Euler resonance must divide the
target numerator. Thus a fixed cofactor forces a bounded prime power
unless a remaining prime divides the cofactor's divisor count. -/
namespace OMA.CofactorPrimeChain245212
open Finset Nat Filter Topology OMA.Smooth245212 OMA.SquareCompact245212
open private OMA.CohortAtom245212.at_two from CohortAtom245212
open scoped ArithmeticFunction.sigma

private def EulerTerm (H u v : ℕ) : Prop :=
  (u=1 ∧ v=1) ∨ (u.Prime ∧ ¬u∣H ∧ v=u-1)

private theorem no_product {K A H : ℕ} (below : A<H) (u v : Fin K→ℕ)
    (terms : ∀i,EulerTerm H (u i) (v i)) :
    A*(∏ i,u i)≠H*(∏ i,v i) := by
  classical
  by_cases one : ∀i,u i=1
  · have neutral (i) : v i=1 := by
      rcases terms i with z|z
      · exact z.2
      · have := z.1.one_lt; rw [one i] at this; omega
    simpa [one,neutral] using below.ne
  push Not at one
  obtain ⟨j,hj⟩:=one
  obtain ⟨m,_,maxim⟩:=univ.exists_max_image u ⟨j,mem_univ _⟩
  have far : 1<u j := by rcases terms j with z|z; exact False.elim (hj z.1); exact z.1.one_lt
  have big := far.trans_le (maxim j (mem_univ _))
  rcases terms m with z|⟨pr,avoid,_⟩
  · omega
  intro eqn
  have dvd : u m∣H*(∏ i,v i) := eqn ▸ dvd_mul_of_dvd_right (Finset.dvd_prod_of_mem u (mem_univ m)) A
  obtain target|rest:=pr.dvd_mul.mp dvd
  · exact avoid target
  obtain ⟨i,_,iv⟩:= (pr.prime.dvd_finsetProd_iff v).mp rest
  have upper := maxim i (mem_univ _)
  rcases terms i with z|z
  · rw [z.2] at iv
    exact (not_le_of_gt big) (Nat.le_of_dvd (by decide) iv)
  · have pos := z.1.one_lt
    have gap : 0<v i ∧ v i<u m := by rw [z.2.2];omega
    exact gap.2.not_ge (Nat.le_of_dvd gap.1 iv)

private theorem no_limit {K A T : ℕ} (tpos : 0<T) (below : A<2*T) (x : Fin K→ℚ)
    (repr : ∀i,∃ u v : ℕ,EulerTerm (2*T) u v ∧ x i=(u:ℚ)/v) :
    ((A:ℚ)/T)*(∏ i,x i)≠2 := by
  classical
  choose u v uv frac using repr
  have pos (i) : 0<v i := by
    rcases uv i with z|z
    · rw [z.2];decide
    · rw [z.2.2];have := z.1.one_lt;omega
  have nonzero : (∏ i,(v i:ℚ))≠0 := (prod_pos (fun i _=>by exact_mod_cast pos i)).ne'
  have original := no_product below u v uv
  intro bad
  simp only [frac,prod_div_distrib] at bad
  field_simp [nonzero,show (T:ℚ)≠0 by exact_mod_cast tpos.ne'] at bad
  apply original
  exact_mod_cast (show (A:ℚ)*(∏ i,(u i:ℚ))=(2*T)*(∏ i,(v i:ℚ)) by linarith only [bad])

private theorem cap_repr {p H : ℕ} (pr : p.Prime) (avoid : ¬p∣H) :
    ∃ u v : ℕ,EulerTerm H u v ∧ X p none=(u:ℚ)/v := by
  refine ⟨p,p-1,Or.inr ⟨pr,avoid,rfl⟩,?_⟩
  have pp : (1:ℚ)<p := by exact_mod_cast pr.one_lt
  simp only [X,Y,sub_zero,Nat.cast_sub pr.one_le,Nat.cast_one]
  field_simp [show (p:ℚ)-1≠0 by linarith];ring

theorem alternative (K A T : ℕ) (tpos : 0<T) (below : A<2*T)
    (d : ℚ) (d0 : 0≤d) (d1 : d≤1) :
    ∃ B : ℕ, ∀ p e : Fin K→ℕ, (∀i,(p i).Prime) → (∀i,Odd (p i)) → (∀i,¬p i∣2*T) →
      ((A:ℚ)/T)*(∏ i,X (p i) (some (e i)))+d*(∏ i,Y (p i) (some (e i)))=2 →
      (∀i,e i≤B) ∨ ∃i,p i≤B ∧ e i≤B := by
  by_contra! bad
  choose p e hp ho avoid eqn large leave using bad
  let seq (n : ℕ) := (p n,e n)
  obtain ⟨g,sorted⟩ := wellQuasiOrdered_le.exists_monotone_subseq seq
  have points (i : Fin K) : ∃ x : ℚ,(∃ u v : ℕ,EulerTerm (2*T) u v ∧ x=(u:ℚ)/v) ∧
      Tendsto (fun n => X (p (g n) i) (some (e (g n) i))) atTop (𝓝 x) := by
    apply factor_limit_restricted _ _ _ (fun _ _ le => (sorted _ _ le).1 i)
      (fun _ _ le => (sorted _ _ le).2 i) (fun n=>hp (g n) i) (fun n=>ho (g n) i)
      ⟨1,1,Or.inl ⟨rfl,rfl⟩,by norm_num⟩
    · intro P pr _ fixed
      obtain ⟨n,same⟩:=fixed.exists
      exact cap_repr pr (same ▸ avoid (g n) i)
    · intro P E hP hE
      have big:=g.strictMono.tendsto_atTop.eventually (eventually_ge_atTop (max P E))
      obtain ⟨n,pn,en,gn⟩:=(hP.and (hE.and big)).exists
      change p (g n) i=P at pn
      change e (g n) i=E at en
      have both:=leave (g n) i
      rw [pn,en] at both
      exact False.elim ((not_lt_of_ge ((le_max_right P E).trans gn)) (both ((le_max_left P E).trans gn)))
  choose x ox conv using points
  have limit:=(tendsto_finsetProd univ (fun i _=>conv i)).const_mul ((A:ℚ)/T)
  have two:=(OMA.CohortAtom245212.at_two _ d d0 d1 p e hp large eqn).comp g.strictMono.tendsto_atTop
  exact no_limit tpos below x ox (tendsto_nhds_unique limit two)

#print axioms alternative
end OMA.CofactorPrimeChain245212
