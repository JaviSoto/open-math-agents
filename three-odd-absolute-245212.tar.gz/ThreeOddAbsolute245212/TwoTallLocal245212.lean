import ThreeMovingLocal245212

/-! Local rounding with one exactly retained prime allowed. -/
namespace OMA.TwoTallLocal245212
open Nat Finset ArithmeticFunction OMA.Smooth245212 OMA.Abundance245212 OMA.ThreeMovingLocal245212
open scoped ArithmeticFunction.sigma
open private OMA.ThreeMovingLocal245212.quotients from ThreeMovingLocal245212

def Dn (p e : ℕ) : Option Bool → ℕ
  | none => (e+1)*p^e
  | some b => den p e b
def Nx (p e : ℕ) : Option Bool → ℕ
  | none => W (p^e)
  | some b => xn p e b
def Ny (p e : ℕ) : Option Bool → ℕ
  | none => σ 1 (p^e)
  | some b => yn p e b
def xx' (p e : ℕ) : Option Bool → ℚ
  | none => X p (some e)
  | some b => xx p e b
def yy' (p e : ℕ) : Option Bool → ℚ
  | none => Y p (some e)
  | some b => yy p e b
theorem Dpos {p : ℕ} (hp : p.Prime) (e : ℕ) (mode : Option Bool) : 0<Dn p e mode := by
  cases mode with
  | none =>exact Nat.mul_pos (Nat.succ_pos _) (pow_pos hp.pos _)
  | some b=>exact den_pos hp.two_le e b

theorem moments {p : ℕ} (hp : p.Prime) (e : ℕ) (mode : Option Bool) :
    xx' p e mode*(Dn p e mode:ℕ)=Nx p e mode ∧ yy' p e mode*(Dn p e mode:ℕ)=Ny p e mode := by
  cases mode with
  | none =>simpa [xx',yy',Dn,Nx,Ny,mul_assoc] using And.intro (x_factor hp e) (y_factor hp e)
  | some b=>
    have dp : (den p e b:ℚ)≠0:=by exact_mod_cast (den_pos hp.two_le e b).ne'
    simp [xx',yy',Dn,Nx,Ny,xx,yy,div_mul_cancel₀ _ dp]

theorem ranges {p e : ℕ} (hp : p.Prime) (pe : 0<e) (mode : Option Bool) :
    1≤xx' p e mode ∧ xx' p e mode≤2 ∧ 0≤yy' p e mode ∧ yy' p e mode≤2/((e:ℚ)+1) := by
  have a (b : Bool):=bounds hp pe (Nat.succ_pos e) (le_refl (e+1)) b
  cases mode with
  | none =>simpa [xx',yy'] using And.intro (a false).1 (And.intro (a false).2.1
      (And.intro (a false).2.2.1 (a false).2.2.2.1))
  | some b=>simpa [xx',yy'] using (a b).2.2.2.2

theorem move {p e f g m k : ℕ} (hp : p.Prime) (pe : 0<e) (mp : 0 < m)
    (ku : 0<k) (gu : 0<g) (fk : k*g≤f) (b : Bool)
    (small : b=true → 4*(p-1)<k*m)
    (x x' y y' : ℚ) (x0 : 1≤x) (x1 : 1≤x') (y0 : 0≤y) (y1 : 0≤y')
    (cap : (y*y')*(m:ℚ)≤4) :
    (f:ℚ)*xx p e b*x*x'+g*yy p e b*y*y' < f*X p (some e)*x*x'+g*Y p (some e)*y*y' := by
  have pp : (1:ℚ)<p:=by exact_mod_cast hp.one_lt
  have fg : (k:ℚ)*g≤f:=by exact_mod_cast fk
  have g0 : (0:ℚ)<g:=by exact_mod_cast gu
  have kp : (0:ℚ)<k:=by exact_mod_cast ku
  have fm : (0:ℚ)<f := lt_of_lt_of_le (mul_pos kp g0) fg
  have xl : (1:ℚ)≤x*x' := one_le_mul_of_one_le_of_one_le x0 x1
  have ylo := mul_nonneg y0 y1
  cases b with
  | false =>
    have ysum : 1/((e:ℚ)+1)≤Y p (some e) := by
      have id:=y_factor hp e
      have big : (p:ℚ)^e ≤ σ 1 (p^e) := by
        exact_mod_cast (show p^e ≤ σ 1 (p^e) by rw [sigma_one_apply_prime_pow hp,Finset.sum_range_succ];omega)
      apply (div_le_iff₀ (by positivity : (0:ℚ)<(e:ℚ)+1)).mpr
      apply le_of_mul_le_mul_right (a:=(p:ℚ)^e) _ (by positivity)
      nlinarith only [id,big]
    have ylt := y_strict hp.one_lt (show 0<e from pe)
    have xstrict : 1<X p (some e) := by
      dsimp [X];apply lt_add_of_pos_right;apply _root_.div_pos _ (by linarith)
      exact sub_pos.mpr (ylt.trans_le (y_one hp.one_lt _))
    have minus : 0<(f:ℚ)*(X p (some e)-1)*(x*x') := by positivity
    have plus := mul_nonneg (mul_nonneg g0.le (sub_nonneg.mpr ysum)) ylo
    have xx0 : xx p e false=1 := by simp [xx,xn,den,show (e:ℚ)+1≠0 by positivity]
    have yy0 : yy p e false=1/((e:ℚ)+1) := by simp [yy,yn,den]
    rw [xx0,yy0]
    nlinarith only [minus,plus]
  | true =>
    let u:ℚ:=(p:ℚ)-1
    let d:ℚ:=1/(((e:ℚ)+1)*u^2*(p:ℚ)^e)
    have dp : 0<d := by dsimp [d,u];positivity
    have us : (0:ℚ)≤u:=by dsimp [u];linarith
    have gate : 4*u < (k:ℚ)*m := by
      have sc : (4:ℚ)*((p-1:ℕ):ℚ)<k*(m:ℚ) := by exact_mod_cast small rfl
      simpa [u,Nat.cast_sub hp.one_le] using sc
    have unc : u*(y*y')<(k:ℚ) := by
      apply lt_of_mul_lt_mul_right (a:=(m:ℚ)) _ (by positivity)
      nlinarith only [gate,mul_le_mul_of_nonneg_left cap us]
    have diff : 0<(f:ℚ)*x*x'-g*u*y*y' := by
      nlinarith only [mul_lt_mul_of_pos_left unc g0,mul_le_mul_of_nonneg_left xl fm.le,fg]
    have q:=OMA.ThreeMovingLocal245212.quotients hp (e:=e)
    change X p (some e)=xx p e true+d ∧ Y p (some e)=yy p e true-u*d at q
    rw [q.1,q.2]
    nlinarith only [mul_pos dp diff]

end OMA.TwoTallLocal245212
