import BoundedAtom245212

/-! Finiteness at bounded rank when the finite odd prime-power factors
cannot cancel the full dyadic denominator of the weighted factor at two. -/
namespace OMA.ParityBudget245212
open Nat Finset Filter Topology OMA.Smooth245212 OMA.SquareCompact245212
open scoped ArithmeticFunction.sigma
open private OMA.SquareCompact245212.infinite_factor from SquareCompact245212
local notation "v₂" => OMA.WeightVal245212.val

private theorem odd_fraction {N D : ℕ} (nz : 0<N) (dz : 0<D) (dv : 2^(v₂ N)∣D) :
    OddNum ((N:ℚ)/D) := by
  obtain ⟨B,db⟩ := dv
  let A := ordCompl[2] N
  have na : 2^(v₂ N)*A=N := Nat.ordProj_mul_ordCompl_eq_self N 2
  have oa : Odd A := Nat.not_even_iff_odd.mp (fun h =>
    Nat.not_dvd_ordCompl Nat.prime_two nz.ne' (even_iff_two_dvd.mp h))
  have bp : 0<B := by
    by_contra! neg
    have zero : B=0 := by omega
    rw [db,zero,mul_zero] at dz
    omega
  refine ⟨A,B,oa,bp,?_⟩
  rw [←na,db]
  push_cast; field_simp

private theorem scale_down {x : ℚ} (ox : OddNum x) (w : ℕ) : OddNum (x/(2:ℚ)^w) := by
  obtain ⟨A,B,odd,bp,rfl⟩ := ox
  exact ⟨A,B*2^w,odd,Nat.mul_pos bp (Nat.two_pow_pos _),by push_cast; ring⟩

/-- Each odd prime contributes at most this many factors of two to the
reduced numerator of the local weighted ratio. -/
def excess (e : ℕ) := v₂ (e+2)-1

private theorem scale_local {p e w : ℕ} (pr : p.Prime) (op : Odd p) (hw : excess e≤w) :
    OddNum (X p (some e)/(2:ℚ)^w) := by
  let N := W (p^e)
  let D := (e+1)*p^e*2^w
  have np : 0<N := by
    dsimp [N]; rw [w_pow pr]
    exact sum_pos' (fun i _ => Nat.zero_le _) ⟨0,mem_range.mpr (Nat.succ_pos _),by simp⟩
  have dp : 0<D := by dsimp [D]; have := pr.pos; positivity
  have ord := OMA.WeightVal245212.weight_local pr op e
  change v₂ N+1=v₂ (e+1)+v₂ (e+2) at ord
  have inc : v₂ N≤v₂ (e+1)+w := by unfold excess at hw; omega
  have divides : 2^(v₂ N)∣D := by
    apply (pow_dvd_pow 2 inc).trans
    rw [pow_add]
    have dv := Nat.ordProj_dvd (e+1) 2
    exact mul_dvd_mul (dvd_mul_of_dvd_left dv (p^e)) (dvd_refl _)
  have ofrac := odd_fraction np dp divides
  have fx := x_factor pr e
  have eqx : X p (some e)=(N:ℚ)/(((e:ℚ)+1)*p^e) := by
    apply (eq_div_iff (by
      have pos : (0:ℚ)<p := by exact_mod_cast pr.pos
      positivity)).mpr
    exact fx
  rw [eqx,div_div]
  simpa [D] using ofrac

private theorem scaled_coefficient {k b : ℕ} (low : b≤k+v₂ (k+1)) :
    OddNum (X 2 (some k)*(2:ℚ)^b) := by
  let D := (k+1)*2^k
  have dv : 2^b∣D := by
    apply (pow_dvd_pow 2 low).trans
    rw [pow_add,Nat.mul_comm]
    exact mul_dvd_mul (Nat.ordProj_dvd (k+1) 2) (dvd_refl _)
  obtain ⟨B,db⟩ := dv
  have dp : 0<D := by dsimp [D]; positivity
  have bp : 0<B := by
    by_contra! neg
    have z : B=0 := by omega
    rw [db,z,mul_zero] at dp
    omega
  have fx := x_factor Nat.prime_two k
  have bd := congrArg (Nat.cast : ℕ → ℚ) db
  dsimp only [D] at bd
  push_cast at bd
  refine ⟨W (2^k),B,OMA.DyadicPower245212.dyadic_odd k,bp,?_⟩
  apply (eq_div_iff (by exact_mod_cast bp.ne' : (B:ℚ)≠0)).mpr
  linear_combination fx - X 2 (some k)*bd

/-- Only count dyadic excess carried by an exactly bounded base and exponent. -/
def visible (B p e : ℕ) := if p≤B ∧ e≤B then excess e else 0

private theorem visible_gap (k K : ℕ) :
    ∃ B : ℕ, ∃ δ : ℚ, 0<δ ∧ ∀ p e : Fin K → ℕ, (∀ i,Nat.Prime (p i)) → (∀ i,Odd (p i)) →
      (∑ i,visible B (p i) (e i))≤k+v₂ (k+1) →
      δ≤|X 2 (some k)*(∏ i,X (p i) (some (e i)))-2| := by
  by_contra! bad
  have pick (n : ℕ) := bad n (1/((n:ℚ)+1)) (by positivity)
  choose p e hp ho he close using pick
  let seq (n : ℕ) := (p n,e n)
  obtain ⟨g,sorted⟩ := wellQuasiOrdered_le.exists_monotone_subseq seq
  let Capture (i : Fin K) (x : ℚ) := ∃ w : ℕ, OddNum (x/(2:ℚ)^w) ∧
    ∀ᶠ n in atTop,w≤visible (g n) (p (g n) i) (e (g n) i)
  have points (i : Fin K) : ∃ x : ℚ,Capture i x ∧
      Tendsto (fun n => X (p (g n) i) (some (e (g n) i))) atTop (𝓝 x) := by
    have trivialWeight (x : ℚ) (hx : OddNum x) : Capture i x :=
      ⟨0,by simpa using hx,Eventually.of_forall fun _ => Nat.zero_le _⟩
    apply factor_limit_by (Capture i) _ _
      (fun _ _ le => (sorted _ _ le).1 i) (fun _ _ le => (sorted _ _ le).2 i)
      (fun n => hp (g n) i) (fun n => ho (g n) i) (trivialWeight _ OMA.SquareCompact245212.one)
      (fun _ pr op => trivialWeight _ (OMA.SquareCompact245212.infinite_factor pr op))
    intro P E pP eE
    obtain ⟨n,pn,en⟩ := (pP.and eE).exists
    change p (g n) i=P at pn
    refine ⟨excess E,scale_local (pn ▸ hp (g n) i) (pn ▸ ho (g n) i) le_rfl,?_⟩
    have large := g.strictMono.tendsto_atTop.eventually (eventually_ge_atTop (max P E))
    filter_upwards [pP,eE,large] with j pj ej big
    change p (g j) i=P at pj
    change e (g j) i=E at ej
    simp [visible,pj,ej,(le_max_left P E).trans big,(le_max_right P E).trans big]
  choose x capture conv using points
  choose w ox see using capture
  obtain ⟨n,hn⟩ := (Filter.eventually_all.mpr see).exists
  have low := (sum_le_sum (s:=univ) (fun i _ => hn i)).trans (he (g n))
  have prod (s : Finset (Fin K)) : OddNum (∏ i∈s,x i/(2:ℚ)^(w i)) := by
    induction s using Finset.induction_on with
    | empty => simpa using OMA.SquareCompact245212.one
    | @insert i s hi ih => simpa only [prod_insert hi] using OMA.SquareCompact245212.mul (ox i) ih
  have od := OMA.SquareCompact245212.mul (scaled_coefficient low) (prod univ)
  rw [prod_div_distrib,prod_pow_eq_pow_sum] at od
  let c := X 2 (some k)
  have distinct := ne_two (show OddNum (c*∏ i,x i) by
    dsimp only [c]; convert od using 1; field_simp)
  have limit := (tendsto_finsetProd univ (fun i _ => conv i)).const_mul c
  have t2 : Tendsto (fun n => c*∏ i,X (p n i) (some (e n i))) atTop (𝓝 2) := by
    have hz := tendsto_one_div_add_atTop_nhds_zero_nat (𝕜:=ℚ)
    apply tendsto_of_tendsto_of_tendsto_of_le_of_le
      (show Tendsto (fun n : ℕ => 2-1/((n:ℚ)+1)) atTop (𝓝 2) by simpa using tendsto_const_nhds.sub hz)
      (show Tendsto (fun n : ℕ => 2+1/((n:ℚ)+1)) atTop (𝓝 2) by simpa using hz.const_add 2)
    · intro n; linarith only [(abs_lt.mp (close n)).1]
    · intro n; linarith only [(abs_lt.mp (close n)).2]
  exact distinct (tendsto_nhds_unique limit (t2.comp g.strictMono.tendsto_atTop))

private def Config {K : ℕ} (c d : ℚ) (B H : ℕ)
    (v : (Fin K → ℕ) × (Fin K → ℕ)) :=
  (∀ i,Nat.Prime (v.1 i)) ∧ (∀ i,Odd (v.1 i)) ∧ (∀ i,0<v.2 i) ∧
  (∑ i,visible B (v.1 i) (v.2 i))≤H ∧
  c*(∏ i,X (v.1 i) (some (v.2 i)))+d*(∏ i,Y (v.1 i) (some (v.2 i)))=2

private theorem configs (K k : ℕ) (d : ℚ) (d0 : 0<d) (d1 : d≤1) :
    ∃ B, {v | Config (K:=K) (X 2 (some k)) d B (k+v₂ (k+1)) v}.Finite := by
  let c := X 2 (some k)
  have c0 := x_nonneg (by decide : 1<2) (some k)
  obtain ⟨B,δ,hδ,sep⟩ := visible_gap k K
  refine ⟨B,?_⟩
  obtain ⟨L,hL⟩ := exists_nat_gt (2/δ)
  have size (p e : Fin K → ℕ) (cfg : Config c d B (k+v₂ (k+1)) (p,e)) (i : Fin K) : e i<L := by
    obtain ⟨hp,ho,_,he,eq⟩ := cfg
    have bound := sep p e hp ho he
    change δ≤|c*(∏ j,X (p j) (some (e j)))-2| at bound
    have y0 (j) := y_nonneg (hp j).one_lt (some (e j))
    have yp := prod_nonneg (s:=univ) (fun j _ => y0 j)
    have z := mul_nonneg d0.le yp
    change c*(∏ j,X (p j) (some (e j)))+d*(∏ j,Y (p j) (some (e j)))=2 at eq
    rw [abs_of_nonpos (by linarith only [eq,z])] at bound
    have upper : δ≤Y (p i) (some (e i)) := by
      apply (show δ≤d*∏ j,Y (p j) (some (e j)) by linarith only [eq,bound]).trans
      apply (mul_le_of_le_one_left yp d1).trans
      rw [←prod_erase_mul _ _ (mem_univ i)]
      exact mul_le_of_le_one_left (y0 i) (prod_le_one (fun j _ => y0 j)
        (fun j _ => y_one (hp j).one_lt _))
    have hh := OMA.CapOrder245212.y_short (hp i) (e i)
    have mult := mul_le_mul_of_nonneg_right upper (show 0≤(e i:ℚ)+1 by positivity)
    have le : (e i:ℚ)<2/δ := (lt_div_iff₀ hδ).mpr (by linarith only [hh,mult,hδ])
    exact_mod_cast le.trans hL
  apply Set.Finite.of_finite_fibers Prod.snd
  · apply (Set.Finite.pi' (fun _ : Fin K => Set.finite_Iio L)).subset
    rintro e ⟨⟨p,v⟩,h,rfl⟩
    exact size _ _ h
  · rintro e ⟨⟨p,v⟩,cfg,rfl⟩
    have finite := OMA.FixedExponents245212.finite_bases v cfg.2.2.1 c d 2 c0 d0
    apply (finite.image (fun q => (q,v))).subset
    rintro ⟨q,f⟩ ⟨hf,hv⟩
    have same : f=v := hv
    subst f
    exact ⟨q,⟨hf.1,hf.2.2.2.2⟩,rfl⟩

private theorem rank_finite (k K : ℕ) :
    ∃ B : ℕ,{m : ℕ | Odd m ∧ m.primeFactors.card=K ∧
      (∑ q∈m.primeFactors,visible B q (m.factorization q))≤k+v₂ (k+1) ∧
      OeisA245212.a (2^k*m)=(σ 1 (2^k*m):ℤ)}.Finite := by
  classical
  let c := X 2 (some k)
  let d := Y 2 (some k)
  have dp : 0<d := by
    dsimp [d]; rw [y_avg (by decide : 1<2)]
    exact div_pos (sum_pos' (fun i _ => by positivity) ⟨0,by simp,by simp⟩) (by positivity)
  obtain ⟨B,fin⟩ := configs K k d dp (y_one (by decide) _)
  refine ⟨B,?_⟩
  apply (fin.image (fun v => total v.1 v.2)).subset
  rintro m ⟨om,card,budget,eq⟩
  let S := m.primeFactors
  let p := S.orderEmbOfFin card
  let e (i : Fin K) := m.factorization (p i)
  have mem (i) : p i∈m.primeFactors := orderEmbOfFin_mem S card i
  have hp (i) := Nat.prime_of_mem_primeFactors (mem i)
  have op (i) := Nat.coprime_two_left.mp ((Nat.coprime_two_left.mpr om).of_dvd_right
    (Nat.dvd_of_mem_primeFactors (mem i)))
  have ep (i) := (hp i).factorization_pos_of_dvd om.pos.ne' (Nat.dvd_of_mem_primeFactors (mem i))
  have repr : total p e=m := by
    exact (Fintype.prod_equiv (S.orderIsoOfFin card).toEquiv _
      (fun j : S => j.val^(m.factorization j.val)) (fun _ => rfl)).trans
      (Nat.prod_primeFactors_coe_pow_factorization om.pos.ne').symm
  let w (i : Fin K) := visible B (p i) (e i)
  have wsum : ∑ i,w i = ∑ q∈m.primeFactors,visible B q (m.factorization q) := by
    exact (Fintype.sum_equiv (S.orderIsoOfFin card).toEquiv _
      (fun j : S => visible B j.val (m.factorization j.val)) (fun _ => rfl)).trans
      (Finset.sum_coe_sort S (fun q => visible B q (m.factorization q)))
  have norm := OMA.BoundedAtom245212.normalized_dyadic k p e hp op p.injective (by rw [repr];exact eq)
  exact ⟨(p,e),⟨hp,op,ep,wsum.le.trans budget,norm⟩,repr⟩

/-- Apart from finitely many solutions, bounded exceptional prime powers
must together supply enough powers of two for the fixed dyadic coefficient.
Large primes and large exponents do not count towards the required sum. -/
theorem finite_visible_budget (k K : ℕ) :
    ∃ B : ℕ,{m : ℕ | Odd m ∧ m.primeFactors.card≤K ∧
      (∑ q∈m.primeFactors,visible B q (m.factorization q))≤k+v₂ (k+1) ∧
      OeisA245212.a (2^k*m)=(σ 1 (2^k*m):ℤ)}.Finite := by
  choose L fin using rank_finite k
  let B := ∑ j∈range (K+1),L j
  refine ⟨B,((Set.finite_Iic K).biUnion (fun j _ => fin j)).subset ?_⟩
  rintro m ⟨om,card,v,eq⟩
  refine Set.mem_iUnion₂.mpr ⟨m.primeFactors.card,card,om,rfl,?_,eq⟩
  have less : L m.primeFactors.card≤B := single_le_sum (fun j _ => Nat.zero_le (L j))
    (mem_range.mpr (Nat.lt_succ_of_le card))
  apply (sum_le_sum (s:=m.primeFactors) (f:=fun q => visible (L m.primeFactors.card) q (m.factorization q))
    (g:=fun q => visible B q (m.factorization q)) ?_).trans v
  intro q hq
  unfold visible
  split_ifs <;> omega

/-- No upper bound on any prime or any individual exponent: only finitely
many positive odd parts with bounded rank and bounded total dyadic excess
can satisfy the original equality, for each fixed power of two. -/
theorem finite_budget (k K : ℕ) :
    {m : ℕ | Odd m ∧ m.primeFactors.card≤K ∧
      (∑ q∈m.primeFactors,excess (m.factorization q))≤k+v₂ (k+1) ∧
      OeisA245212.a (2^k*m)=(σ 1 (2^k*m):ℤ)}.Finite := by
  obtain ⟨B,fin⟩ := finite_visible_budget k K
  apply fin.subset
  rintro m ⟨om,card,v,eq⟩
  exact ⟨om,card,(sum_le_sum (fun q _ => show visible B q (m.factorization q)≤_ by
    unfold visible; split_ifs <;> omega)).trans v,eq⟩

#print axioms finite_budget
#print axioms finite_visible_budget
end OMA.ParityBudget245212
