import CofactorEffectiveOriginal245212

/-! A computable bound on an entire cross-divisibility-free solution, by
absorbing a bounded whole prime power at each successive cofactor. -/
namespace OMA.CofactorEffectiveTree245212
open Nat Finset ArithmeticFunction OMA.Smooth245212
open OMA.CofactorEffectiveOriginal245212 OMA.CofactorEulerSeparation245212
open scoped ArithmeticFunction.sigma

/-- Every branch removes one distinct prime. The enlarged finite boxes
include nonprime bases; these are harmless upper bounds. -/
def ceiling : ℕ → ℕ → ℕ
  | 0,h => h
  | k+1,h => ((range (primeHeight h (k+1)+1)).product (range (height h (k+1)+1))).sup
      (fun t => ceiling k (h*t.1^t.2))

theorem support_rest (m p : ℕ) : (ordCompl[p] m).primeFactors=m.primeFactors.erase p := by
  rw [←Nat.support_factorization, Nat.factorization_ordCompl, Finsupp.support_erase,
    Nat.support_factorization]

/-- A single recursion works for any condition preserved when removing a
whole prime power, provided that condition rules out a resonant subproduct. -/
theorem bounded_by (Good : ℕ→ℕ→Prop)
    (apart : ∀ {h m : ℕ}, 0 < h → h.Coprime m → Odd m → W h<2*(h*σ 0 h) →
      Good h m → miss (W h) (2*(h*σ 0 h)) m.primeFactors)
    (peel : ∀ {h m p : ℕ}, 0 < h → 0 < m → h.Coprime m → Odd m → p∈m.primeFactors →
      Good h m → Good (h*ordProj[p] m) (ordCompl[p] m))
    (r : ℕ) {h m : ℕ} (hh : 0 < h) (hm : 0 < m) (cop : h.Coprime m)
    (odd : Odd m) (rank : m.primeFactors.card=r)
    (good : Good h m)
    (eqn : OeisA245212.a (h*m)=(σ 1 (h*m):ℤ)) : h*m≤ceiling r h := by
  induction r generalizing h m with
  | zero =>
    have emp:=Nat.primeFactors_eq_empty.mp (card_eq_zero.mp rank)
    have one : m=1:=by omega
    simp [one,ceiling]
  | succ k ih =>
    have bigger : 1 < m := by
      by_contra! small
      have one : m=1:=by omega
      simp [one] at rank
    have g:=(OMA.CofactorHarmonic245212.gap hh bigger cop eqn).1
    have below : W h<2*(h*σ 0 h) := by
      by_contra! no
      have b:=Nat.mul_le_mul_right (σ 0 m) no
      omega
    obtain ⟨p,mem,pbound,ebound⟩:=original hh bigger cop (apart hh cop odd below good) eqn
    rw [rank] at pbound ebound
    let e:=m.factorization p
    let t:=ordCompl[p] m
    have pp:=prime_of_mem_primeFactors mem
    have tp : 0<t := Nat.ordCompl_pos p hm.ne'
    have repr : p^e*t=m := Nat.ordProj_mul_ordCompl_eq_self m p
    have td : t∣m:=Nat.ordCompl_dvd m p
    have nextCop : (h*p^e).Coprime t :=
      (cop.of_dvd_right td).mul_left ((Nat.coprime_ordCompl pp hm.ne').pow_left e)
    have id : h*p^e*t=h*m := by rw [mul_assoc,repr]
    have result : h*p^e*t≤ceiling k (h*p^e) := by
      apply ih (Nat.mul_pos hh (pow_pos pp.pos e)) tp nextCop
        (Nat.coprime_two_left.mp ((Nat.coprime_two_left.mpr odd).of_dvd_right td))
      · rw [show t.primeFactors=m.primeFactors.erase p from support_rest m p,card_erase_of_mem mem,rank]; omega
      · exact peel hh hm cop odd mem good
      · rwa [id]
    have box : (p,e)∈(range (primeHeight h (k+1)+1)).product (range (height h (k+1)+1)) :=
      mem_product.mpr ⟨mem_range.mpr (by omega),mem_range.mpr (Nat.lt_succ_of_le ebound)⟩
    rw [←id]
    exact result.trans (le_sup (f:=fun t : ℕ×ℕ=>ceiling k (h*t.1^t.2)) box)

private def no_edges (h m : ℕ) : Prop :=
  (∀q∈m.primeFactors, ¬q∣σ 0 h) ∧
  (∀p∈m.primeFactors,∀q∈m.primeFactors,p≠q → ¬p∣m.factorization q+1)

theorem bounded {h m : ℕ} (hh : 0 < h) (hm : 0 < m) (cop : h.Coprime m) (odd : Odd m)
    (avoid : ∀q∈m.primeFactors, ¬q∣σ 0 h)
    (cross : ∀p∈m.primeFactors,∀q∈m.primeFactors,p≠q → ¬p∣m.factorization q+1)
    (eqn : OeisA245212.a (h*m)=(σ 1 (h*m):ℤ)) : h*m≤ceiling m.primeFactors.card h := by
  apply bounded_by no_edges _ _ _ hh hm cop odd rfl ⟨avoid,cross⟩ eqn
  · intro h m _ cop odd below good
    apply miss_avoids below.ne (fun _ mem=>prime_of_mem_primeFactors mem)
    intro q mem dvd
    have pr:=prime_of_mem_primeFactors mem
    have qd:=dvd_of_mem_primeFactors mem
    have oq:=Nat.coprime_two_left.mp ((Nat.coprime_two_left.mpr odd).of_dvd_right qd)
    rcases pr.dvd_mul.mp dvd with two|other
    · have same:=(prime_dvd_prime_iff_eq pr prime_two).mp two
      obtain ⟨j,hj⟩:=oq
      omega
    rcases pr.dvd_mul.mp other with dh|dt
    · exact (pr.coprime_iff_not_dvd.mp (cop.of_dvd_right qd).symm) dh
    · exact good.1 q mem dt
  · intro h m p _ _ cop _ mem good
    have pp:=prime_of_mem_primeFactors mem
    have hcop:=cop.of_dvd_right (dvd_of_mem_primeFactors mem)
    obtain ⟨av,cr⟩:=good
    unfold no_edges
    rw [support_rest,isMultiplicative_sigma.map_mul_of_coprime (hcop.pow_right _),sigma_zero_apply_prime_pow pp]
    constructor
    · intro q mq dv
      obtain ⟨neq,old⟩:=mem_erase.mp mq
      exact ((prime_of_mem_primeFactors old).dvd_mul.mp dv).elim (av q old) (cr q old p mem neq)
    · intro a ma b mb ne
      rw [Nat.factorization_ordCompl,Finsupp.erase_ne (ne_of_mem_erase mb)]
      exact cr a (mem_of_mem_erase ma) b (mem_of_mem_erase mb) ne

#print axioms bounded_by
#print axioms bounded
end OMA.CofactorEffectiveTree245212
