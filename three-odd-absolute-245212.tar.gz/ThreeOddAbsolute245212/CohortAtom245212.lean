import RankThreeAnchor245212

/-! A cofactor whose prime-power denominator survives in the weighted
moment forces another bounded prime and exponent in any fixed-rank extension. -/
namespace OMA.CohortAtom245212
open Nat Finset Filter Topology OMA.Smooth245212 OMA.SquareCompact245212
open scoped ArithmeticFunction.sigma

private def UnitNum (r : ℕ) (x : ℚ) := ∃ U V : ℕ, r.Coprime U ∧ 0<V ∧ x=(U:ℚ)/V

private theorem one (r : ℕ) : UnitNum r 1 := ⟨1,1,by simp,by decide,by norm_num⟩

private theorem mul {r : ℕ} {x y : ℚ} (ux : UnitNum r x) (uy : UnitNum r y) : UnitNum r (x*y) := by
  obtain ⟨A,B,ca,hb,rfl⟩ := ux
  obtain ⟨U,V,cu,hv,rfl⟩ := uy
  exact ⟨A*U,B*V,ca.mul_right cu,Nat.mul_pos hb hv,by push_cast; ring⟩

private theorem cap {r p : ℕ} (pr : p.Prime) (cop : r.Coprime p) : UnitNum r (X p none) := by
  refine ⟨p,p-1,cop,by have := pr.one_lt; omega,?_⟩
  have pp : (1:ℚ)<p := by exact_mod_cast pr.one_lt
  simp only [X,Y,sub_zero,Nat.cast_sub pr.one_le,Nat.cast_one]
  field_simp [show (p:ℚ)-1≠0 by linarith]; ring

private theorem product {K r : ℕ} (x : Fin K → ℚ) (unit : ∀ i,UnitNum r (x i)) :
    UnitNum r (∏ i,x i) := by
  have aux (s : Finset (Fin K)) : UnitNum r (∏ i∈s,x i) := by
    induction s using Finset.induction_on with
    | empty => simpa using one r
    | @insert i s hi ih => simpa only [prod_insert hi] using mul (unit i) ih
  exact aux univ

private theorem at_two {K : ℕ} (c d : ℚ) (d0 : 0≤d) (d1 : d≤1)
    (p e : ℕ → Fin K → ℕ) (hp : ∀ n i,Nat.Prime (p n i)) (large : ∀ n,∃ i,n<e n i)
    (eqn : ∀ n,c*(∏ i,X (p n i) (some (e n i)))+d*(∏ i,Y (p n i) (some (e n i)))=2) :
    Tendsto (fun n => c*∏ i,X (p n i) (some (e n i))) atTop (𝓝 2) := by
  have error (n : ℕ) : 0 ≤ d*∏ i,Y (p n i) (some (e n i)) ∧
      d*(∏ i,Y (p n i) (some (e n i))) ≤ 2/((n:ℚ)+1) := by
    have y0 (j) := y_nonneg (hp n j).one_lt (some (e n j))
    have pos := prod_nonneg (s:=univ) (fun j _ => y0 j)
    obtain ⟨i,gi⟩ := large n
    refine ⟨mul_nonneg d0 pos,(mul_le_of_le_one_left pos d1).trans ?_⟩
    calc
      _ ≤ Y (p n i) (some (e n i)) := by
        rw [←prod_erase_mul _ _ (mem_univ i)]
        exact mul_le_of_le_one_left (y0 i) (prod_le_one (fun j _ => y0 j) (fun j _ => y_one (hp n j).one_lt _))
      _ ≤ 2/((e n i:ℚ)+1) := ((lt_div_iff₀ (by positivity)).mpr (OMA.CapOrder245212.y_short (hp n i) _)).le
      _ ≤ _ := by gcongr
  have zero : Tendsto (fun n : ℕ => 2/((n:ℚ)+1)) atTop (𝓝 0) := by
    simpa [div_eq_mul_inv] using (tendsto_one_div_add_atTop_nhds_zero_nat (𝕜:=ℚ)).const_mul 2
  have err := tendsto_of_tendsto_of_tendsto_of_le_of_le tendsto_const_nhds zero
    (fun n => (error n).1) (fun n => (error n).2)
  apply (show Tendsto (fun n => 2-d*∏ i,Y (p n i) (some (e n i))) atTop (𝓝 2) by
    simpa using (tendsto_const_nhds (x:=(2:ℚ))).sub err).congr
  intro n; linarith only [eqn n]

/-- Either all exponents are bounded, or at least one entire prime-power
factor has its base and exponent simultaneously bounded. -/
theorem alternative (K r : ℕ) (c d : ℚ) (d0 : 0≤d) (d1 : d≤1)
    (miss : ∀ U V : ℕ,r.Coprime U → 0<V → c*((U:ℚ)/V)≠2) :
    ∃ B : ℕ, ∀ p e : Fin K → ℕ, (∀ i,Nat.Prime (p i)) → (∀ i,Odd (p i)) → (∀ i,r.Coprime (p i)) →
      c*(∏ i,X (p i) (some (e i)))+d*(∏ i,Y (p i) (some (e i)))=2 →
      (∀ i,e i≤B) ∨ ∃ i,p i≤B ∧ e i≤B := by
  by_contra! bad
  choose p e hp ho cop eqn large avoid using bad
  let seq (n : ℕ) := (p n,e n)
  obtain ⟨g,sorted⟩ := wellQuasiOrdered_le.exists_monotone_subseq seq
  have points (i : Fin K) : ∃ x : ℚ,UnitNum r x ∧
      Tendsto (fun n => X (p (g n) i) (some (e (g n) i))) atTop (𝓝 x) := by
    apply factor_limit_restricted _ _ _ (fun _ _ le => (sorted _ _ le).1 i)
      (fun _ _ le => (sorted _ _ le).2 i) (fun n => hp (g n) i) (fun n => ho (g n) i) (one r)
    · intro P pr _ hP
      obtain ⟨n,hn⟩ := hP.exists
      exact cap pr (hn ▸ cop (g n) i)
    · intro P E hP hE
      have big := g.strictMono.tendsto_atTop.eventually (eventually_ge_atTop (max P E))
      obtain ⟨n,pn,en,gn⟩ := (hP.and (hE.and big)).exists
      change p (g n) i=P at pn
      change e (g n) i=E at en
      have a := avoid (g n) i
      rw [pn,en] at a
      exact False.elim ((not_lt_of_ge ((le_max_right P E).trans gn)) (a ((le_max_left P E).trans gn)))
  choose x ox conv using points
  obtain ⟨U,V,unit,vpos,prod⟩ := product x ox
  have limit := (tendsto_finsetProd univ (fun i _ => conv i)).const_mul c
  have two := (at_two c d d0 d1 p e hp large eqn).comp g.strictMono.tendsto_atTop
  exact miss U V unit vpos (prod ▸ tendsto_nhds_unique limit two)

#print axioms alternative

/-- Positive exponents on a nonempty support turn the alternative into a
bounded pair: for bounded exponent vectors, only finitely many bases work. -/
theorem atom {K : ℕ} (pos : 0<K) (r : ℕ) (c d : ℚ) (c0 : 0≤c) (d0 : 0<d) (d1 : d≤1)
    (miss : ∀ U V : ℕ,r.Coprime U → 0<V → c*((U:ℚ)/V)≠2) :
    ∃ B : ℕ, ∀ p e : Fin K → ℕ, (∀ i,Nat.Prime (p i)) → (∀ i,Odd (p i)) → (∀ i,r.Coprime (p i)) →
      (∀ i,0<e i) → c*(∏ i,X (p i) (some (e i)))+d*(∏ i,Y (p i) (some (e i)))=2 →
      ∃ i,p i≤B ∧ e i≤B := by
  classical
  obtain ⟨L,alt⟩ := alternative K r c d d0.le d1 miss
  let F : Set (Fin K → ℕ) := {e | ∀ i,0<e i ∧ e i≤L}
  let bases (e : Fin K → ℕ) : Set (Fin K → ℕ) := {p | (∀ i,Nat.Prime (p i)) ∧
    c*(∏ i,X (p i) (some (e i)))+d*(∏ i,Y (p i) (some (e i)))=2}
  have cf : F.Finite := (Set.Finite.pi' (fun _ : Fin K => Set.finite_Iic L)).subset
    (fun _ h i => (h i).2)
  have bf := cf.biUnion (fun e he => (show (bases e).Finite from
    OMA.FixedExponents245212.finite_bases e (fun i => (he i).1) c d 2 c0 d0))
  obtain ⟨M,cap⟩ := (bf.biUnion (fun p _ => Set.finite_range p)).bddAbove
  refine ⟨max L M,?_⟩
  intro p e hp ho cop ep eq
  rcases alt p e hp ho cop eq with low | ⟨i,pi,ei⟩
  · let i : Fin K := ⟨0,pos⟩
    have ef : e∈F := fun j => ⟨ep j,low j⟩
    have member : p∈⋃ t∈F,bases t := Set.mem_iUnion₂.mpr ⟨e,ef,hp,eq⟩
    have pm := cap (Set.mem_iUnion₂.mpr ⟨p,member,i,rfl⟩)
    exact ⟨i,pm.trans (le_max_right _ _),(low i).trans (le_max_left _ _)⟩
  · exact ⟨i,pi.trans (le_max_left _ _),ei.trans (le_max_left _ _)⟩

theorem miss_core {k r a : ℕ} (pr : r.Prime) (odd : r≠2) (large : W (2^k)<r^a)
    (U V : ℕ) (unit : r.Coprime U) (vpos : 0<V) :
    (X 2 (some k)*X r (some a))*((U:ℚ)/V)≠2 := by
  intro eq
  let d2 := (k+1)*2^k
  let dr := (a+1)*r^a
  have fx : X 2 (some k)*(d2:ℚ)=W (2^k) := by simpa [d2] using x_factor Nat.prime_two k
  have fy : X r (some a)*(dr:ℚ)=W (r^a) := by simpa [dr] using x_factor pr a
  have diff := OMA.RankThreeAnchor245212.no_resonance pr odd unit large (V:=V)
  apply diff
  have cp := ((Nat.coprime_primes Nat.prime_two pr).mpr odd.symm).pow_left k
  rw [w_mult.map_mul_of_coprime (cp.pow_right a),ArithmeticFunction.isMultiplicative_sigma.map_mul_of_coprime
      (cp.pow_right a),ArithmeticFunction.sigma_zero_apply_prime_pow Nat.prime_two,
      ArithmeticFunction.sigma_zero_apply_prime_pow pr]
  have rhs : 2*(2^k*r^a)*((k+1)*(a+1))*V=2*d2*dr*V := by unfold d2 dr; ring
  rw [rhs]
  have eq' : (X 2 (some k)*X r (some a))*U=2*V := by
    rw [←mul_div_assoc] at eq
    exact (div_eq_iff (by exact_mod_cast vpos.ne')).mp eq
  exact_mod_cast (show (W (2^k):ℚ)*W (r^a)*U=2*d2*dr*V by
    rw [←fx,←fy]; linear_combination ((d2:ℚ)*dr)*eq')

#print axioms atom
#print axioms miss_core
end OMA.CohortAtom245212
