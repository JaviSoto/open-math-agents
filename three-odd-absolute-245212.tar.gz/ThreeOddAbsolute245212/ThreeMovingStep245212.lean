import ThreeMovingGap245212
import ThreeMovingScalar245212
import CofactorEffectiveAtom245212

/-! A missing interval among four ordered cutoffs makes the local tail
smaller than a nonzero integer's reciprocal denominator. -/
namespace OMA.ThreeMovingStep245212
open Nat Finset OMA.ThreeMovingLocal245212 OMA.ThreeMovingGap245212 OMA.ThreeMovingScalar245212
open private OMA.CofactorEffectiveAtom245212.product_error from CofactorEffectiveAtom245212

private theorem integer_gap (c : Family) (bits : Fin 3→Bool) (f g : ℕ)
    (different : (f+g)*dust c bits ≠ f*NX c bits+g*NY c bits) :
    (1:ℚ)≤|score f g (x' c bits) (y' c bits)-(f+g:ℕ)| * dust c bits := by
  let B:=dust c bits
  let T:=f*NX c bits+g*NY c bits
  let L:ℤ:=(T:ℤ)-((f+g)*B:ℕ)
  have nz : L≠0 := fun h => different (by exact_mod_cast (sub_eq_zero.mp h).symm)
  have la : (1:ℤ)≤|L| := by have:=abs_pos.mpr nz;omega
  have raw : (1:ℚ)≤|(T:ℚ)-((f+g)*B:ℕ)| := by dsimp [L] at la;exact_mod_cast la
  have ab:=congrArg (fun w:ℚ=>|w|) (show (score f g (x' c bits) (y' c bits)-(f+g:ℕ))*B =
      (T:ℚ)-((f+g)*B:ℕ) by rw [sub_mul];push_cast;rw [show score f g (x' c bits) (y' c bits)*B=(T:ℚ) from clear ..])
  rw [abs_mul,abs_of_nonneg (Nat.cast_nonneg B : (0:ℚ)≤B)] at ab
  exact ab.trans_ge raw

private theorem difference (c : Family) (b : Fin 3→Bool) (f g N : ℕ) (n0 : 0<N)
    (space : ∀i,N ≤ (if b i then (c.p i)^(c.e i) else c.p i)) :
    |score f g (x' c b) (y' c b)-score f g (exactX c) (exactY c)|≤48*((f:ℚ)+g)/N := by
  have bp (i) := bounds (c.prime i) (c.positive i) c.mp (c.lengths i).1 (b i)
  have er (i) := error (c.prime i) (c.positive i) n0 (b i) (space i)
  have eps : (0:ℚ)≤2/N := by positivity
  have one : 2/(c.m:ℚ)≤2 := div_le_self (by decide) (by exact_mod_cast c.mp)
  have x:=OMA.CofactorEffectiveAtom245212.product_error (univ:Finset (Fin 3)) (exactX c) (x' c b) eps
    (fun i _=>⟨zero_le_one.trans (bp i).1,(bp i).2.1,zero_le_one.trans (bp i).2.2.2.2.1,
      (bp i).2.2.2.2.2.1,(er i).1⟩)
  have y:=OMA.CofactorEffectiveAtom245212.product_error (univ:Finset (Fin 3)) (exactY c) (y' c b) eps
    (fun i _=>⟨(bp i).2.2.1,(bp i).2.2.2.1.trans one,(bp i).2.2.2.2.2.2.1,
      (bp i).2.2.2.2.2.2.2.trans one,(er i).2⟩)
  norm_num at x y
  dsimp [score]
  rw [abs_sub_comm]
  calc
    _ = |(f:ℚ)*((∏i,exactX c i)-∏i,x' c b i)+(g:ℚ)*((∏i,exactY c i)-∏i,y' c b i)| := by congr 1;ring
    _ ≤ _ := (abs_add_le ..).trans (by
      rw [abs_mul,abs_of_nonneg (Nat.cast_nonneg f : (0:ℚ)≤f),abs_mul,
        abs_of_nonneg (Nat.cast_nonneg g : (0:ℚ)≤g)]
      simp only [div_eq_mul_inv] at x y ⊢
      nlinarith only [mul_le_mul_of_nonneg_left x (Nat.cast_nonneg f : (0:ℚ)≤f),
        mul_le_mul_of_nonneg_left y (Nat.cast_nonneg g : (0:ℚ)≤g)])

theorem contradiction (c : Family) (f g l x : ℕ) (gp : 0<g) (fg : c.k*g≤f)
    (frac : f+g=(c.k+1)*l) (unit : ∀i,¬c.p i∣l)
    (big : 128≤x) (cf : f+g≤x) (cl : c.L≤x)
    (powers : ∀i,x^budget≤(c.p i)^(c.e i))
    (actual : score f g (exactX c) (exactY c)≤(f+g:ℕ))
    (close : |score f g (exactX c) (exactY c)-(f+g:ℕ)| ≤ 1/((x^budget:ℕ):ℚ)) : False := by
  obtain ⟨j,band⟩:=empty_interval x (by omega) c.p
  let Q:=cut x j.val
  let N:=cut x (j.val+1)
  let b (i:Fin 3):Bool:=decide (c.p i≤Q)
  have next : N=Q^16 := cut_succ x _
  have xQ : x≤Q := by
    have old:=cut_mono (show 1≤x by omega) (Nat.zero_le j.val)
    simpa [cut,Q] using old
  have np : 0<N := by rw [next];exact pow_pos (by omega) _
  have nb : N≤x^budget:=cut_mono (by omega) (show j.val+1≤4 by omega)
  have space (i) : N ≤ (if b i then c.p i^c.e i else c.p i) := by
    dsimp [b];split
    · exact nb.trans (powers i)
    next h=>exact ((band i).resolve_left (by simpa using h)).le
  have ds : dust c b≤Q^9 := by
    have per i : den (c.p i) (c.e i) (b i)≤Q^3 := by
      have el := (c.lengths i).2.trans (cl.trans xQ)
      dsimp [den,b]
      split
      next h =>
        have small : c.p i≤Q:=by simpa using h
        exact (Nat.mul_le_mul el (Nat.pow_le_pow_left (show c.p i-1≤Q by omega) 2)).trans_eq (by ring)
      next=>exact el.trans (Nat.le_self_pow (by decide : 3≠0) Q)
    dsimp [dust]
    exact (prod_le_prod' (fun i _=>per i)).trans_eq (by simp;ring)
  have nz:=nonzero c b f g l gp fg frac unit actual
  have iga:=integer_gap c b f g nz
  let orig:=score f g (exactX c) (exactY c)
  let approx:=score f g (x' c b) (y' c b)
  let W:ℚ:=(f+g:ℕ)
  have lite : |orig-W|≤1/(N:ℚ) := close.trans (one_div_le_one_div_of_le (by positivity) (by exact_mod_cast nb))
  have diff:=difference c b f g N np space
  change |approx-orig|≤_ at diff
  change (1:ℚ)≤|approx-W| * dust c b at iga
  have err : |approx-W| * (N:ℚ)≤48*((f:ℚ)+g)+1 := by
    have t:=abs_sub_le approx orig W
    have wn : (0:ℚ)<N:=by exact_mod_cast np
    nlinarith only [mul_le_mul_of_nonneg_right t wn.le,(le_div_iff₀ wn).mp diff,(le_div_iff₀ wn).mp lite]
  have sep : N≤(48*(f+g)+1)*dust c b := by
    have z : (N:ℚ)≤(48*((f:ℚ)+g)+1)*dust c b := by
      nlinarith only [mul_le_mul_of_nonneg_right iga (Nat.cast_nonneg N : (0:ℚ)≤N),
        mul_le_mul_of_nonneg_right err (Nat.cast_nonneg (dust c b) : (0:ℚ)≤_)]
    exact_mod_cast z
  have qr : 128≤Q:=big.trans xQ
  have cfq : f+g≤Q:=cf.trans xQ
  have cf' : 48*(f+g)+1<Q^2 := by
    nlinarith only [cfq,Nat.mul_le_mul_left Q qr,qr]
  have bad : N<Q^11 := sep.trans_lt ((Nat.mul_lt_mul_of_lt_of_le cf' ds (pow_pos (by omega) 9)).trans_eq (by ring))
  have natural : Q^11≤N:=next ▸ Nat.pow_le_pow_right (by omega) (by decide)
  omega

end OMA.ThreeMovingStep245212
